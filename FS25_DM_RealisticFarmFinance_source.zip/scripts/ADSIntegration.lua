RFF_ADSIntegration = {}

-- Called only for a newly delivered RFF dealer order, not for used purchases.
-- ADS owns the date, systems snapshot, hours, ids and savegame serialization.
function RFF_ADSIntegration:recordDealerHandover(vehicle)
    local spec=vehicle and vehicle.spec_AdvancedDamageSystem
    if not spec or spec.isExcludedVehicle or type(vehicle.addEntryToMaintenanceLog)~="function" then
        return "ADS unavailable or unsupported"
    end
    if vehicle._rffDealerPdiRecorded then return "ADS inspection and service recorded" end
    if (vehicle.operatingTime or 0)>0 or (spec.realOperatingTime or 0)>0 then
        return "ADS record skipped: vehicle has existing operating hours"
    end
    local previousWorkshop=spec.workshopType
    spec.workshopType=self.WORKSHOP_DEALER
    local ok,err=pcall(function()
        vehicle:addEntryToMaintenanceLog(self.STATUS_INSPECTION,self.INSPECTION_COMPLETE,"NONE",false,0,true)
        local entry=spec.maintenanceLog[#spec.maintenanceLog];if entry then entry.isVisible=true end
        vehicle:addEntryToMaintenanceLog(self.STATUS_MAINTENANCE,self.MAINTENANCE_STANDARD,self.PART_OEM,false,0,true)
        entry=spec.maintenanceLog[#spec.maintenanceLog];if entry then entry.isVisible=true end
    end)
    spec.workshopType=previousWorkshop
    if not ok then print("[RFF dealership] ADS handover: "..tostring(err));return "ADS handover record incomplete; inspect maintenance history" end
    vehicle._rffDealerPdiRecorded=true
    return "ADS pre-delivery inspection and initial service recorded (no charge)"
end

-- Advanced Damage System's own leased-vehicle return logic treats service below
-- 0.5 as overdue. RFF mirrors that public behaviour rather than inventing a
-- second maintenance standard.
RFF_ADSIntegration.SERVICE_EXPIRED_THRESHOLD = 0.5

-- ADS public specialization function arguments. These are stable string IDs used
-- by ADS itself and let RFF call vehicle methods without requiring ADS globals to
-- be visible across mod Lua environments.
RFF_ADSIntegration.STATUS_MAINTENANCE = "ads_spec_state_maintenance"
RFF_ADSIntegration.STATUS_INSPECTION = "ads_spec_state_inspection"
RFF_ADSIntegration.STATUS_REPAIR = "ads_spec_state_repair"
RFF_ADSIntegration.MAINTENANCE_STANDARD = "ads_spec_maintenance_standard"
RFF_ADSIntegration.INSPECTION_COMPLETE = "ads_spec_inspection_complete"
RFF_ADSIntegration.REPAIR_MEDIUM = "ads_spec_repair_type_replacement"
RFF_ADSIntegration.REPAIR_REPLACEMENT = "ads_spec_repair_type_replacement"
RFF_ADSIntegration.PART_OEM = "ads_spec_part_types_oem"
RFF_ADSIntegration.WORKSHOP_DEALER = "ads_spec_workshop_dealer"

local function number(value, fallback)
    local n = tonumber(value)
    if n == nil then return fallback or 0 end
    return n
end

local function clamp01(value)
    return math.max(0, math.min(1, number(value, 0)))
end

local function call(vehicle, methodName, ...)
    if vehicle == nil or type(vehicle[methodName]) ~= "function" then return false, nil end
    local ok, value = pcall(vehicle[methodName], vehicle, ...)
    if not ok then return false, nil end
    return true, value
end

local function callNumber(vehicle, methodName, fallback, ...)
    local ok, value = call(vehicle, methodName, ...)
    if not ok then return fallback or 0 end
    return number(value, fallback or 0)
end

local function getBreakdownDetails(value)
    local count = 0
    local ids = {}
    if type(value) ~= "table" then return count, ids end

    for key, breakdown in pairs(value) do
        if type(breakdown) ~= "table" or breakdown.isActive ~= false then
            count = count + 1
            local id = type(breakdown) == "table" and (breakdown.id or breakdown.name or breakdown.breakdownId) or nil
            if id == nil and type(key) == "string" then id = key end
            if id ~= nil then ids[#ids + 1] = tostring(id) end
        end
    end

    table.sort(ids)
    return count, ids
end

local function getVisibleBreakdownCount(value)
    local count = 0
    if type(value) ~= "table" then return count end

    for _, breakdown in pairs(value) do
        if type(breakdown) == "table" and breakdown.isActive ~= false and breakdown.isVisible == true then
            count = count + 1
        end
    end
    return count
end

local function getMaintenanceLog(vehicle)
    local spec = vehicle ~= nil and vehicle.spec_AdvancedDamageSystem or nil
    return type(spec) == "table" and type(spec.maintenanceLog) == "table" and spec.maintenanceLog or nil
end

function RFF_ADSIntegration:getLocalControlledVehicle()
    if g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function" then
        local ok, vehicle = pcall(g_localPlayer.getCurrentVehicle, g_localPlayer)
        if ok and vehicle ~= nil then return vehicle end
    end

    if g_currentMission ~= nil then
        if g_currentMission.controlledVehicle ~= nil then return g_currentMission.controlledVehicle end
        local player = g_currentMission.player
        if player ~= nil and type(player.getCurrentVehicle) == "function" then
            local ok, vehicle = pcall(player.getCurrentVehicle, player)
            if ok and vehicle ~= nil then return vehicle end
        end
    end

    return nil
end

function RFF_ADSIntegration:isVehicleSupported(vehicle)
    if vehicle == nil then return false end
    local spec = vehicle.spec_AdvancedDamageSystem
    if type(spec) == "table" then return spec.isExcludedVehicle ~= true end

    -- Compatibility fallback for ADS builds where the specialization table is not
    -- visible cross-mod but its registered vehicle functions are.
    return type(vehicle.getServiceLevel) == "function"
        and type(vehicle.getConditionLevel) == "function"
        and type(vehicle.getServicePrice) == "function"
end

function RFF_ADSIntegration:isAvailable()
    return g_modIsLoaded ~= nil and g_modIsLoaded["FS25_AdvancedDamageSystem"] == true
end

-- Claims use the ADS maintenance-log id at the instant of impact as an evidence
-- boundary. Only a completed inspection or repair after this id can satisfy the
-- accident claim, so earlier workshop work cannot be reused accidentally.
function RFF_ADSIntegration:getClaimEvidenceCheckpoint(vehicle)
    if not self:isVehicleSupported(vehicle) then return 0 end
    local checkpoint = 0
    for index, entry in ipairs(getMaintenanceLog(vehicle) or {}) do
        checkpoint = math.max(checkpoint, math.floor(number(entry ~= nil and entry.id, index)))
    end
    return checkpoint
end

-- ADS remains authoritative for workshop work and price calculation. RFF only
-- reads completed log entries and the current visible-fault state. A full
-- defectoscopy is required first; any subsequent repair must use OEM parts.
function RFF_ADSIntegration:getAccidentClaimEvidence(vehicle, checkpointId)
    local result = {
        adsApplied = false,
        inspectionCompleted = false,
        inspectionLogId = 0,
        inspectionCost = 0,
        inspectionIssueCount = 0,
        oemRepairCompleted = false,
        repairCost = 0,
        warrantyRepair = false,
        nonOemRepairCompleted = false,
        remainingVisibleBreakdowns = 0
    }
    if not self:isVehicleSupported(vehicle) then return result end

    result.adsApplied = true
    checkpointId = math.max(0, math.floor(number(checkpointId, 0)))
    local log = getMaintenanceLog(vehicle) or {}

    for index, entry in ipairs(log) do
        local entryId = math.max(0, math.floor(number(entry ~= nil and entry.id, index)))
        if not result.inspectionCompleted and entryId > checkpointId and type(entry) == "table" and entry.isCompleted ~= false
                and entry.type == self.STATUS_INSPECTION and entry.optionOne == self.INSPECTION_COMPLETE
                then
            result.inspectionCompleted = true
            result.inspectionLogId = entryId
            result.inspectionCost = math.max(0, number(entry.price, 0))
            local conditionData = type(entry.conditionData) == "table" and entry.conditionData or nil
            result.inspectionIssueCount = getVisibleBreakdownCount(conditionData ~= nil and conditionData.activeBreakdowns or nil)
        end
    end

    if result.inspectionCompleted then
        for index, entry in ipairs(log) do
            local entryId = math.max(0, math.floor(number(entry ~= nil and entry.id, index)))
            if entryId > result.inspectionLogId and type(entry) == "table" and entry.isCompleted ~= false
                    and entry.type == self.STATUS_REPAIR then
                if entry.optionTwo == self.PART_OEM then
                    result.oemRepairCompleted = true
                    result.repairCost = result.repairCost + math.max(0, number(entry.price, 0))
                else
                    result.nonOemRepairCompleted = true
                end
            end
        end
    end

    local okBreakdowns, breakdowns = call(vehicle, "getActiveBreakdowns")
    if not okBreakdowns or type(breakdowns) ~= "table" then
        local spec = vehicle.spec_AdvancedDamageSystem or {}
        breakdowns = spec.activeBreakdowns
    end
    result.remainingVisibleBreakdowns = getVisibleBreakdownCount(breakdowns)
    result.warrantyRepair = result.oemRepairCompleted and result.repairCost <= 0
    return result
end

-- Read-only fleet diary data. ADS remains authoritative for the inspection and
-- maintenance history as well as its operating-hour service interval.
function RFF_ADSIntegration:getFleetMaintenanceRecord(vehicle)
    local result = {
        adsApplied = false,
        lastInspectionDate = nil,
        lastMaintenanceDate = nil,
        maintenanceIntervalHours = 0,
        hoursSinceMaintenance = 0
    }

    if not self:isVehicleSupported(vehicle) then return result end
    result.adsApplied = true

    local okInspection, inspectionDate = call(vehicle, "getLastInspectionDate")
    if okInspection and type(inspectionDate) == "table" then
        result.lastInspectionDate = {
            day = math.max(1, math.floor(number(inspectionDate.day, 1))),
            month = math.max(1, math.min(12, math.floor(number(inspectionDate.month, 1)))),
            year = math.max(0, math.floor(number(inspectionDate.year, 0)))
        }
    end

    local okMaintenance, maintenanceDate = call(vehicle, "getLastMaintenanceDate")
    if okMaintenance and type(maintenanceDate) == "table" then
        result.lastMaintenanceDate = {
            day = math.max(1, math.floor(number(maintenanceDate.day, 1))),
            month = math.max(1, math.min(12, math.floor(number(maintenanceDate.month, 1)))),
            year = math.max(0, math.floor(number(maintenanceDate.year, 0)))
        }
    end

    result.maintenanceIntervalHours = math.max(0, callNumber(vehicle, "getMaintenanceInterval", 0))
    result.hoursSinceMaintenance = math.max(0, callNumber(vehicle, "getHoursSinceLastMaintenance", 0))
    return result
end

function RFF_ADSIntegration:getTechnicalAssessment(vehicle)
    local result = {
        adsApplied = false,
        serviceLevel = 0,
        conditionLevel = 0,
        breakdownCount = 0,
        breakdownIds = {},
        maintenancePenalty = 0,
        repairCost = 0,
        technicalPenalty = 0
    }

    if not self:isVehicleSupported(vehicle) then return result end

    local spec = vehicle.spec_AdvancedDamageSystem or {}
    result.adsApplied = true
    result.serviceLevel = clamp01(callNumber(vehicle, "getServiceLevel", number(spec.serviceLevel, 1)))
    result.conditionLevel = clamp01(callNumber(vehicle, "getConditionLevel", number(spec.conditionLevel, 1)))

    local okBreakdowns, breakdowns = call(vehicle, "getActiveBreakdowns")
    if not okBreakdowns or type(breakdowns) ~= "table" then breakdowns = spec.activeBreakdowns end
    result.breakdownCount, result.breakdownIds = getBreakdownDetails(breakdowns)

    local threshold = math.max(self.SERVICE_EXPIRED_THRESHOLD, 0.0001)
    local overdueRatio = math.max(threshold - result.serviceLevel, 0) / threshold

    local standardServicePrice = math.max(0, callNumber(
        vehicle,
        "getServicePrice",
        0,
        self.STATUS_MAINTENANCE,
        self.MAINTENANCE_STANDARD,
        self.PART_OEM,
        false,
        self.WORKSHOP_DEALER
    ))

    result.maintenancePenalty = overdueRatio * standardServicePrice
    result.repairCost = math.max(0, callNumber(
        vehicle,
        "getServicePrice",
        0,
        self.STATUS_REPAIR,
        self.REPAIR_REPLACEMENT,
        self.PART_OEM,
        false,
        self.WORKSHOP_DEALER,
        true
    ))
    result.technicalPenalty = result.maintenancePenalty + result.repairCost

    return result
end
