RFF_ForbearanceService = {}
RFF_ForbearanceService.__index = RFF_ForbearanceService

RFF_ForbearanceService.TYPE_HOLIDAY = "PAYMENT_HOLIDAY"
RFF_ForbearanceService.TYPE_INTEREST_ONLY = "INTEREST_ONLY"
RFF_ForbearanceService.TYPE_RESTRUCTURE = "RESTRUCTURE"
RFF_ForbearanceService.OFFERED = "OFFERED"
RFF_ForbearanceService.ACCEPTED = "ACCEPTED"
RFF_ForbearanceService.DECLINED = "DECLINED"
RFF_ForbearanceService.EXPIRED = "EXPIRED"
RFF_ForbearanceService.OFFER_VALID_PERIODS = 1
RFF_ForbearanceService.OFFER_COOLDOWN_PERIODS = 6

local function safeNumber(value)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then return value end
    return 0
end

local function feeMoneyType()
    if MoneyType ~= nil then return MoneyType.LOAN_INTEREST or MoneyType.OTHER end
    return nil
end

function RFF_ForbearanceService.new(repository, loanService, relationshipService, marketService)
    local self = setmetatable({}, RFF_ForbearanceService)
    self.repository = repository
    self.loanService = loanService
    self.relationshipService = relationshipService
    self.marketService = marketService
    return self
end

function RFF_ForbearanceService:getLoanById(farmId, loanId)
    for _, loan in ipairs(self.repository ~= nil and self.repository.loans or {}) do
        if safeNumber(loan.id) == safeNumber(loanId) and safeNumber(loan.farmId) == safeNumber(farmId) then return loan end
    end
    return nil
end

function RFF_ForbearanceService:getRelationshipCode(loan)
    if self.relationshipService == nil or loan == nil then return "NEW" end
    local benefits = self.relationshipService:getBenefits(loan.farmId, loan.lenderId or "PRIMARY_BANK")
    return benefits ~= nil and benefits.code or "NEW"
end

function RFF_ForbearanceService:getTierRank(code)
    return ({STRAINED=0, NEW=1, DEVELOPING=2, PROVEN=3, TRUSTED=4})[code or "NEW"] or 1
end

function RFF_ForbearanceService:getMaxArrangements(code)
    if code == "TRUSTED" then return 3 end
    if code == "PROVEN" then return 2 end
    if code == "DEVELOPING" or code == "NEW" then return 1 end
    return 0
end

function RFF_ForbearanceService:isSupportedLoan(loan)
    if loan == nil or loan.paidOff then return false end
    return loan.type == RFF_LoanService.TYPE_TERM or loan.type == RFF_LoanService.TYPE_BULLET
end

function RFF_ForbearanceService:canRequestHelp(loan)
    if not self:isSupportedLoan(loan) then return false, "product" end
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(loan) or math.max(0, safeNumber(loan.arrearsBalance))
    if arrears <= 0.01 then return false, "no_arrears" end
    if loan.recoveryEligible == true or loan.arrearsStage == "RECOVERY" then return false, "recovery" end
    if safeNumber(loan.forbearanceRemainingPeriods) > 0 then return false, "active" end

    local code = self:getRelationshipCode(loan)
    local maxArrangements = self:getMaxArrangements(code)
    if maxArrangements <= 0 then return false, "relationship" end
    if safeNumber(loan.forbearanceCount) >= maxArrangements then return false, "used" end
    if code == "NEW" and safeNumber(loan.paymentsMade) < 6 then return false, "history" end
    return true, nil
end

function RFF_ForbearanceService:buildPlan(loan)
    local eligible, reason = self:canRequestHelp(loan)
    if not eligible then return nil, reason end

    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(loan) or math.max(0, safeNumber(loan.arrearsBalance))
    local code = self:getRelationshipCode(loan)
    local rank = self:getTierRank(code)
    local age = math.max(1, math.floor(safeNumber(loan.arrearsAgeMonths)))
    local principal = math.max(0, safeNumber(loan.principal))
    local capitalised = principal + arrears
    local remaining = math.max(1, math.floor(safeNumber(loan.remainingMonths)))
    local planType
    local duration = 0
    local extension = 0
    local rateUplift = 0

    if age <= 1 and rank >= 1 then
        planType = self.TYPE_HOLIDAY
        duration = code == "TRUSTED" and 2 or 1
    elseif age <= 2 and rank >= 2 then
        planType = self.TYPE_INTEREST_ONLY
        if code == "TRUSTED" then duration = 6
        elseif code == "PROVEN" then duration = 4
        else duration = 3 end
    else
        planType = self.TYPE_RESTRUCTURE
        if code == "TRUSTED" then extension, rateUplift = 24, 0.35
        elseif code == "PROVEN" then extension, rateUplift = 18, 0.50
        elseif code == "DEVELOPING" then extension, rateUplift = 12, 0.75
        else extension, rateUplift = 12, 1.00 end
    end

    local newRate = math.max(0, safeNumber(loan.interestRate) + rateUplift)
    local paymentMonths = planType == self.TYPE_RESTRUCTURE and (remaining + extension) or remaining
    local newPayment
    if loan.type == RFF_LoanService.TYPE_BULLET then
        newPayment = capitalised * (newRate / 100) / 12
    else
        newPayment = self.loanService:calculateAnnuityPayment(capitalised, newRate, paymentMonths)
    end

    return {
        loanId=loan.id,
        farmId=loan.farmId,
        type=planType,
        relationshipCode=code,
        capitalisedArrears=arrears,
        principal=capitalised,
        durationPeriods=duration,
        extensionMonths=extension,
        interestRate=newRate,
        rateUplift=rateUplift,
        remainingMonths=paymentMonths,
        monthlyPayment=newPayment,
        oldPayment=safeNumber(loan.monthlyPayment),
        oldRate=safeNumber(loan.interestRate),
        createdPeriod=self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    }, nil
end

function RFF_ForbearanceService:applyPlan(loan, plan, source)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or plan == nil then return false, "server_only", nil end
    local fresh, reason = self:buildPlan(loan)
    if fresh == nil then return false, reason, nil end
    if tostring(fresh.type) ~= tostring(plan.type) then plan = fresh end

    local oldPayment = safeNumber(loan.monthlyPayment)
    local oldRate = safeNumber(loan.interestRate)
    loan.principal = math.max(0, safeNumber(plan.principal))
    loan.forbearanceCount = math.max(0, math.floor(safeNumber(loan.forbearanceCount))) + 1
    loan.forbearanceLastPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    loan.forbearanceLastType = plan.type
    loan.forbearanceCapitalisedArrears = safeNumber(loan.forbearanceCapitalisedArrears) + math.max(0, safeNumber(plan.capitalisedArrears))
    loan.forbearanceOriginalPayment = oldPayment
    loan.forbearanceOriginalRate = oldRate
    loan.forbearanceSource = source or "GUI"
    loan.forbearanceBroken = false

    if plan.type == self.TYPE_RESTRUCTURE then
        loan.interestRate = safeNumber(plan.interestRate)
        loan.remainingMonths = math.max(1, math.floor(safeNumber(plan.remainingMonths)))
        loan.termMonths = math.max(math.floor(safeNumber(loan.termMonths)), loan.remainingMonths) + math.max(0, math.floor(safeNumber(plan.extensionMonths)))
        loan.monthlyPayment = safeNumber(plan.monthlyPayment)
        loan.forbearanceMode = ""
        loan.forbearanceRemainingPeriods = 0
    else
        loan.interestRate = safeNumber(plan.interestRate)
        loan.monthlyPayment = safeNumber(plan.monthlyPayment)
        loan.termMonths = math.max(1, math.floor(safeNumber(loan.termMonths))) + math.max(0, math.floor(safeNumber(plan.durationPeriods)))
        loan.forbearanceMode = plan.type
        loan.forbearanceRemainingPeriods = math.max(0, math.floor(safeNumber(plan.durationPeriods)))
    end

    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(loan, self.repository) end
    if self.relationshipService ~= nil then
        self.relationshipService:recordArrearsCleared(loan)
        if self.relationshipService.recordForbearance ~= nil then self.relationshipService:recordForbearance(loan, plan.type) end
    end

    loan.forbearanceOfferStatus = self.ACCEPTED
    loan.forbearanceOfferType = ""
    loan.forbearanceOfferCreatedPeriod = 0
    loan.forbearanceOfferExpiryPeriod = 0

    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(loan.lenderNameKey, "Lender")
        local title = RFF_NotificationService:getText("rff_phone_title_forbearance_accepted", "Payment Arrangement Agreed")
        local message = RFF_NotificationService:formatText("rff_phone_forbearance_accepted",
            "Your payment arrangement has been agreed. The lender has capitalised %s of arrears and revised the facility terms.",
            g_i18n ~= nil and g_i18n:formatMoney(plan.capitalisedArrears or 0, 0, true, true) or tostring(plan.capitalisedArrears or 0))
        RFF_NotificationService:send(loan.farmId, sender, title, message, "forbearance", message, false)
    end

    print(string.format("[RealisticFarmFinance] Forbearance accepted loan=%d lender=%s type=%s arrears=%.2f duration=%d extension=%d rate=%.2f payment=%.2f relationship=%s",
        loan.id or 0, tostring(loan.lenderId), tostring(plan.type), plan.capitalisedArrears or 0, plan.durationPeriods or 0, plan.extensionMonths or 0,
        loan.interestRate or 0, loan.monthlyPayment or 0, tostring(plan.relationshipCode)))
    return true, nil, plan
end

function RFF_ForbearanceService:processTemporaryArrangement(loan)
    local remaining = math.max(0, math.floor(safeNumber(loan.forbearanceRemainingPeriods)))
    if remaining <= 0 then return false end
    local mode = loan.forbearanceMode or ""
    if mode ~= self.TYPE_HOLIDAY and mode ~= self.TYPE_INTEREST_ONLY then return false end

    local principal = math.max(0, safeNumber(loan.principal))
    local interest = principal * (math.max(0, safeNumber(loan.interestRate)) / 100) / 12
    if mode == self.TYPE_HOLIDAY then
        loan.principal = principal + interest
        loan.forbearanceCapitalisedInterest = safeNumber(loan.forbearanceCapitalisedInterest) + interest
    else
        if not self.loanService:canAfford(loan.farmId, interest) then
            if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordMissed(loan, self.repository, 0, interest, 0) end
            if self.relationshipService ~= nil then
                self.relationshipService:recordMissedPayment(loan)
                if self.relationshipService.recordForbearanceBroken ~= nil then self.relationshipService:recordForbearanceBroken(loan) end
            end
            loan.forbearanceBroken = true
            loan.forbearanceMode = ""
            loan.forbearanceRemainingPeriods = 0
            return true
        end
        self.loanService:charge(loan.farmId, interest, MoneyType ~= nil and (MoneyType.LOAN_INTEREST or MoneyType.OTHER) or nil)
        loan.interestPaid = safeNumber(loan.interestPaid) + interest
        loan.paymentsMade = safeNumber(loan.paymentsMade) + 1
        if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordSuccessfulScheduledPayment(loan, self.repository) end
        if self.relationshipService ~= nil then self.relationshipService:recordSuccessfulPayment(loan) end
    end

    remaining = remaining - 1
    loan.forbearanceRemainingPeriods = remaining
    if remaining <= 0 then
        loan.forbearanceMode = ""
        if loan.type == RFF_LoanService.TYPE_TERM then
            loan.monthlyPayment = self.loanService:calculateAnnuityPayment(math.max(0, safeNumber(loan.principal)), safeNumber(loan.interestRate), math.max(1, math.floor(safeNumber(loan.remainingMonths))))
        elseif loan.type == RFF_LoanService.TYPE_BULLET then
            loan.monthlyPayment = math.max(0, safeNumber(loan.principal)) * (safeNumber(loan.interestRate) / 100) / 12
        end
        if RFF_NotificationService ~= nil then
            local sender = RFF_NotificationService:getSender(loan.lenderNameKey, "Lender")
            local title = RFF_NotificationService:getText("rff_phone_title_forbearance_complete", "Payment Arrangement Update")
            local message = RFF_NotificationService:formatText("rff_phone_forbearance_complete", "Your temporary payment arrangement has ended. Normal scheduled payments resume next period at %s per month.",
                g_i18n ~= nil and g_i18n:formatMoney(loan.monthlyPayment or 0, 0, true, true) or tostring(loan.monthlyPayment or 0))
            RFF_NotificationService:send(loan.farmId, sender, title, message, "forbearance", message, false)
        end
    end
    return true
end

function RFF_ForbearanceService:createPhoneOffer(loan)
    local plan, reason = self:buildPlan(loan)
    if plan == nil then return false, reason end
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local last = math.max(0, math.floor(safeNumber(loan.forbearanceOfferLastPeriod)))
    if last > 0 and current - last < self.OFFER_COOLDOWN_PERIODS then return false, "cooldown" end

    loan.forbearanceOfferStatus = self.OFFERED
    loan.forbearanceOfferType = plan.type
    loan.forbearanceOfferCreatedPeriod = current
    loan.forbearanceOfferExpiryPeriod = current + self.OFFER_VALID_PERIODS
    loan.forbearanceOfferLastPeriod = current

    if RFF_NotificationService ~= nil and RFF_NotificationService.pushPhoneForbearanceActionable ~= nil then
        local sender = RFF_NotificationService:getSender(loan.lenderNameKey, "Lender")
        local title = RFF_NotificationService:getText("rff_phone_title_forbearance_offer", "Payment Support Available")
        local typeText = RFF_NotificationService:getText("rff_forbearance_type_" .. string.lower(plan.type), plan.type)
        local message = RFF_NotificationService:formatText("rff_phone_forbearance_offer",
            "Following your missed payment, we can offer a %s arrangement. Arrears of %s would be capitalised. Accept or decline this temporary support.",
            typeText, g_i18n ~= nil and g_i18n:formatMoney(plan.capitalisedArrears or 0, 0, true, true) or tostring(plan.capitalisedArrears or 0))
        local token = string.format("forbearance:%d:%d", loan.id or 0, current)
        if RFF_NotificationService:pushPhoneForbearanceActionable(loan.farmId, sender, title, message, token, self) then
            print(string.format("[RealisticFarmFinance] Forbearance phone offer loan=%d type=%s relationship=%s expires=%d", loan.id or 0, tostring(plan.type), tostring(plan.relationshipCode), loan.forbearanceOfferExpiryPeriod or 0))
            return true, nil
        end
    end
    loan.forbearanceOfferStatus = ""
    loan.forbearanceOfferType = ""
    loan.forbearanceOfferCreatedPeriod = 0
    loan.forbearanceOfferExpiryPeriod = 0
    loan.forbearanceOfferLastPeriod = 0
    return false, "phone_unavailable"
end

function RFF_ForbearanceService:handlePhoneDecision(context, decision)
    if context == nil then return false, "Offer no longer available" end
    local token = tostring(context.token or "")
    local loanId, period = token:match("^forbearance:(%d+):(%d+)$")
    if loanId == nil then return false, "Offer no longer available" end
    local farmId = safeNumber(context.farmId)
    local loan = self:getLoanById(farmId, tonumber(loanId))
    if loan == nil or loan.forbearanceOfferStatus ~= self.OFFERED or safeNumber(loan.forbearanceOfferCreatedPeriod) ~= tonumber(period) then
        return false, "Offer no longer available"
    end
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    if current > safeNumber(loan.forbearanceOfferExpiryPeriod) then
        loan.forbearanceOfferStatus = self.EXPIRED
        return false, "Offer has expired"
    end
    if decision == "decline" then
        loan.forbearanceOfferStatus = self.DECLINED
        print(string.format("[RealisticFarmFinance] Mobile Phone declined forbearance offer loan=%d", loan.id or 0))
        return true, "DECLINED"
    end
    local plan, reason = self:buildPlan(loan)
    if plan == nil then return false, reason or "Offer no longer available" end
    local ok, applyReason = self:applyPlan(loan, plan, "PHONE")
    if ok then
        print(string.format("[RealisticFarmFinance] Mobile Phone accepted forbearance offer loan=%d", loan.id or 0))
        return true, "ACCEPTED"
    end
    return false, applyReason or "Offer no longer available"
end

function RFF_ForbearanceService:isRescueEligible(loan)
    if not self:isSupportedLoan(loan) then return false, "product" end
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(loan) or math.max(0, safeNumber(loan.arrearsBalance))
    if arrears <= 0.01 then return false, "no_arrears" end
    local age = math.max(0, math.floor(safeNumber(loan.arrearsAgeMonths)))
    if age < 2 and loan.currentDefault ~= true and safeNumber(loan.forbearanceCount) <= 0 then return false, "too_early" end
    if loan.recoveryEligible == true or loan.arrearsStage == "RECOVERY" then return false, "recovery" end
    return true, nil
end

function RFF_ForbearanceService:getSourceDebtService(loan)
    if loan == nil then return 0 end
    if loan.type == RFF_LoanService.TYPE_BULLET then return math.max(0, safeNumber(loan.principal)) * (safeNumber(loan.interestRate) / 100) / 12 end
    return math.max(0, safeNumber(loan.monthlyPayment))
end

function RFF_ForbearanceService:buildRescueQuote(loan)
    local eligible, reason = self:isRescueEligible(loan)
    if not eligible then return nil, reason end
    if self.marketService == nil or self.loanService == nil then return nil, "service" end
    local farmId = loan.farmId
    local settlement = self.loanService:getLoanOutstanding(loan)
    if settlement < 1000 then return nil, "balance" end
    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    local existingDebtService = math.max(0, self.loanService:getMonthlyDebtService(farmId) - self:getSourceDebtService(loan))
    local existingLiabilities = math.max(0, safeNumber(valuation.liabilities) - settlement)
    local quotes = {}
    local declineReasons = {}
    local rescueConfig = {
        PRIMARY_BANK={minDscr=0.90,maxLtv=0.85,premium=1.00,fee=0.0075,term=60},
        RURAL_AGRI_BANK={minDscr=0.90,maxLtv=0.82,premium=1.10,fee=0.0100,term=72},
        COUNTY_COMMERCIAL={minDscr=0.82,maxLtv=0.88,premium=1.25,fee=0.0125,term=72},
        AGRIGROWTH_FINANCE={minDscr=0.80,maxLtv=0.88,premium=1.50,fee=0.0150,term=84},
        FRONTIER_CAPITAL={minDscr=0.70,maxLtv=0.95,premium=1.75,fee=0.0200,term=84}
    }

    for _, lenderId in ipairs(self.marketService.LENDER_ORDER or {}) do
        if lenderId ~= (loan.lenderId or "PRIMARY_BANK") then
            local profile = self.marketService:getProfile(lenderId)
            local market = self.marketService:getMarketAdjustment(lenderId)
            local fit = self.marketService:getDealAdjustment(lenderId, RFF_LoanService.TYPE_TERM, "RESCUE_FINANCE", settlement, "D")
            local benefits = self.relationshipService ~= nil and self.relationshipService:getBenefits(farmId, lenderId) or {code="NEW",rateAdjustment=0,arrangementFeeFactor=1,ltvBonus=0,dscrTolerance=0}
            local cfg = rescueConfig[lenderId] or rescueConfig.COUNTY_COMMERCIAL
            if fit.available ~= true then
                declineReasons[lenderId] = "out_of_appetite"
            else
                local collateral = math.max(0, safeNumber(credit.collateral)) * math.max(0.85, safeNumber(market.collateralFactor)) * math.max(0.85, safeNumber(fit.collateralFactor))
                local income = math.max(0, safeNumber(credit.monthlyIncome)) * math.max(0.85, safeNumber(market.incomeFactor)) * math.max(0.85, safeNumber(fit.incomeFactor))
                local ltv = collateral > 0 and (existingLiabilities + settlement) / collateral or math.huge
                local maxLtv = math.max(0.60, cfg.maxLtv + safeNumber(market.ltvAdjustment) + safeNumber(fit.ltvAdjustment) + safeNumber(benefits.ltvBonus))
                local term = math.max(math.floor(safeNumber(loan.remainingMonths)) + 24, cfg.term)
                term = math.min(96, math.max(36, term))
                local rate = math.max(5.0, self.loanService:getBaseRate() + self.loanService:getPricingSpread("D") + safeNumber(profile.baseRateAdjustment)
                    + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment) + safeNumber(benefits.rateAdjustment) + cfg.premium)
                local payment = self.loanService:calculateAnnuityPayment(settlement, rate, term)
                local dscr = existingDebtService + payment > 0 and income / (existingDebtService + payment) or math.huge
                local minDscr = math.max(0.60, cfg.minDscr + safeNumber(market.dscrFloorAdjustment) + safeNumber(fit.dscrFloorAdjustment) - safeNumber(benefits.dscrTolerance))
                if ltv > maxLtv then
                    declineReasons[lenderId] = "security"
                elseif safeNumber(credit.trackedPeriods) >= 3 and (income <= 0 or dscr < minDscr) then
                    declineReasons[lenderId] = "affordability"
                else
                    local fee = settlement * (safeNumber(profile.feePercent) + cfg.fee) * math.max(0.5, safeNumber(market.feeFactor)) * math.max(0.5, safeNumber(fit.feeFactor)) * math.max(0.5, safeNumber(benefits.arrangementFeeFactor))
                    fee = math.floor(fee / 10 + 0.5) * 10
                    local interest = math.max(0, payment * term - settlement)
                    table.insert(quotes, {
                        farmId=farmId, sourceLoanId=loan.id, settlement=settlement, lenderId=lenderId, lenderNameKey=profile.nameKey,
                        marketState=market.state, dealFit=fit.code, relationshipTier=benefits.code or "NEW", interestRate=rate,
                        monthlyPayment=payment, termMonths=term, arrangementFee=fee, grade="D", dscr=dscr, ltv=ltv,
                        projectedInterest=interest, totalFinanceCost=interest+fee, createdPeriod=self.repository:getCurrentPeriodIndex(),
                        previousPayment=self:getSourceDebtService(loan), previousLenderId=loan.lenderId or "PRIMARY_BANK",
                        previousLenderNameKey=loan.lenderNameKey or "rff_lender_primary_bank"
                    })
                end
            end
        end
    end

    if #quotes == 0 then return nil, "no_offers", declineReasons end
    table.sort(quotes, function(a,b)
        if math.abs(safeNumber(a.totalFinanceCost)-safeNumber(b.totalFinanceCost)) < 0.01 then return safeNumber(a.monthlyPayment) < safeNumber(b.monthlyPayment) end
        return safeNumber(a.totalFinanceCost) < safeNumber(b.totalFinanceCost)
    end)
    local best = quotes[1]
    best.allQuotes = quotes
    best.monthlyDifference = safeNumber(best.previousPayment) - safeNumber(best.monthlyPayment)
    return best, nil
end

function RFF_ForbearanceService:completeRescueQuote(quote)
    if g_currentMission == nil or not g_currentMission:getIsServer() or quote == nil then return nil, "server_only" end
    if safeNumber(quote.createdPeriod) ~= safeNumber(self.repository:getCurrentPeriodIndex()) then return nil, "quote_expired" end
    local source = self:getLoanById(quote.farmId, quote.sourceLoanId)
    if source == nil then return nil, "changed" end
    local eligible = self:isRescueEligible(source)
    if not eligible then return nil, "changed" end
    local settlement = self.loanService:getLoanOutstanding(source)
    if math.abs(settlement - safeNumber(quote.settlement)) > 1 then return nil, "changed" end
    local fee = math.max(0, safeNumber(quote.arrangementFee))
    if fee > 0 and not self.loanService:canAfford(quote.farmId, fee) then return nil, "funds" end

    local offer = {approved=true, interestRate=quote.interestRate, monthlyPayment=quote.monthlyPayment, grade="D", lenderId=quote.lenderId,
        lenderNameKey=quote.lenderNameKey, arrangementFee=fee, brokerFee=0, brokered=true, brokerCaseId=0}
    local newLoan, reason = self.loanService:createLoanFromOffer(quote.farmId, settlement, quote.termMonths, RFF_LoanService.TYPE_TERM, "RESCUE_FINANCE", offer,
        {disburse=false, allowDistressedCredit=true})
    if newLoan == nil then return nil, reason or "loan_create_failed" end

    local sourcePrincipal = math.max(0, safeNumber(source.principal))
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(source) or math.max(0, safeNumber(source.arrearsBalance))
    local arrearsPrincipal = math.max(0, safeNumber(source.arrearsPrincipal))
    local arrearsInterest = math.max(0, safeNumber(source.arrearsInterest))
    local arrearsFees = math.max(0, safeNumber(source.arrearsFees))
    source.principalPaid = safeNumber(source.principalPaid) + sourcePrincipal + arrearsPrincipal
    source.interestPaid = safeNumber(source.interestPaid) + arrearsInterest
    source.adminChargesPaid = safeNumber(source.adminChargesPaid) + arrearsFees
    source.principal = 0
    source.remainingMonths = 0
    source.paidOff = true
    source.completedPeriod = self.repository:getCurrentPeriodIndex()
    source.rescueRefinanced = true
    source.rescueRefinancedPeriod = source.completedPeriod
    source.rescueRefinancedByLoanId = newLoan.id or 0
    source.rescueSettlementAmount = settlement
    source.currentDefault = false
    source.recoveryEligible = false
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(source, self.repository) end

    newLoan.rescueFinance = true
    newLoan.rescueSourceLoanId = source.id or 0
    newLoan.rescueSettlementAmount = settlement
    newLoan.rescuePreviousPayment = quote.previousPayment or 0
    newLoan.rescuePreviousLenderId = quote.previousLenderId or "PRIMARY_BANK"
    newLoan.rescueMarketState = quote.marketState or "SELECTIVE"
    newLoan.rescueDealFit = quote.dealFit or "STANDARD"
    newLoan.rescueRelationshipTier = quote.relationshipTier or "NEW"

    if fee > 0 then
        if self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(quote.farmId, "Rescue finance arrangement fee") end
        g_currentMission:addMoney(-fee, quote.farmId, feeMoneyType(), true, true)
    end
    if self.relationshipService ~= nil then
        if self.relationshipService.recordRescueExit ~= nil then self.relationshipService:recordRescueExit(source) end
        if self.relationshipService.recordRescueDeal ~= nil then self.relationshipService:recordRescueDeal(newLoan, settlement) end
    end

    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(quote.lenderNameKey, "Rescue Lender")
        local title = RFF_NotificationService:getText("rff_phone_title_rescue_complete", "Rescue Refinance Complete")
        local message = RFF_NotificationService:formatText("rff_phone_rescue_complete",
            "Your distressed borrowing has been refinanced. %s has replaced %s of debt at %.2f%% over %d months.",
            sender, g_i18n ~= nil and g_i18n:formatMoney(settlement, 0, true, true) or tostring(settlement), quote.interestRate or 0, quote.termMonths or 0)
        RFF_NotificationService:send(quote.farmId, sender, title, message, "rescueFinance", message, true)
    end

    print(string.format("[RealisticFarmFinance] Rescue refinance completed source=%d newLoan=%d lender=%s settlement=%.2f rate=%.2f term=%d payment=%.2f fee=%.2f arrearsSettled=%.2f",
        source.id or 0, newLoan.id or 0, tostring(newLoan.lenderId), settlement, newLoan.interestRate or 0, newLoan.termMonths or 0, newLoan.monthlyPayment or 0, fee, arrears))
    return newLoan, nil
end

function RFF_ForbearanceService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for _, loan in ipairs(self.repository.loans or {}) do
        if self:isSupportedLoan(loan) and not loan.paidOff then
            if loan.forbearanceOfferStatus == self.OFFERED and current > safeNumber(loan.forbearanceOfferExpiryPeriod) then
                loan.forbearanceOfferStatus = self.EXPIRED
            end
            local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(loan) or math.max(0, safeNumber(loan.arrearsBalance))
            local rank = self:getTierRank(self:getRelationshipCode(loan))
            if arrears > 0.01 and rank >= 2 and (loan.arrearsStage == "REMINDER" or loan.arrearsStage == "ARREARS_WARNING")
                and loan.forbearanceOfferStatus ~= self.OFFERED then
                self:createPhoneOffer(loan)
            end
        end
    end
end
