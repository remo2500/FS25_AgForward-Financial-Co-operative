RFF_NotificationService = {}

RFF_NotificationService.SOURCE_ID = "FS25_DM_RealisticFarmFinance"
RFF_NotificationService.PHONE_ACTION_ACCEPT_PREAPPROVED = "acceptPreApprovedOffer"
RFF_NotificationService.PHONE_ACTION_DECLINE_PREAPPROVED = "declinePreApprovedOffer"
RFF_NotificationService.PHONE_ACTION_ACCEPT_FORBEARANCE = "acceptForbearanceOffer"
RFF_NotificationService.PHONE_ACTION_DECLINE_FORBEARANCE = "declineForbearanceOffer"
RFF_NotificationService.PHONE_ACTION_ACCEPT_TENANCY_RENEWAL = "acceptTenancyRenewal"
RFF_NotificationService.PHONE_ACTION_DECLINE_TENANCY_RENEWAL = "declineTenancyRenewal"
RFF_NotificationService._actionHandlersRegistered = false
RFF_NotificationService._registeredPhone = nil
RFF_NotificationService._registeredMarketService = nil
RFF_NotificationService._forbearanceHandlersRegistered = false
RFF_NotificationService._registeredForbearanceService = nil
RFF_NotificationService._tenancyHandlersRegistered = false
RFF_NotificationService._registeredTenancyService = nil

function RFF_NotificationService:getText(key, fallback)
    if g_i18n ~= nil and key ~= nil then
        local text = g_i18n:getText(key)
        if text ~= nil and text ~= "" and text ~= key then
            return text
        end
    end
    return fallback or key or ""
end

function RFF_NotificationService:formatText(key, fallback, ...)
    local text = self:getText(key, fallback)
    local ok, formatted = pcall(string.format, text, ...)
    return ok and formatted or text
end

function RFF_NotificationService:getSender(nameKey, fallback)
    if nameKey ~= nil and nameKey ~= "" then
        return self:getText(nameKey, fallback)
    end
    return fallback or "Farm Finance"
end

function RFF_NotificationService:getPhone()
    local phone = g_currentMission ~= nil and g_currentMission.derwenPhoneAPI or nil
    if phone ~= nil and type(phone.sendNotification) == "function" then
        return phone
    end
    return nil
end

function RFF_NotificationService:getPhoneVersion()
    local phone = self:getPhone()
    if phone == nil then return 0 end
    return tonumber(phone.version) or 0
end

function RFF_NotificationService:resetActionHandlers()
    self._actionHandlersRegistered = false
    self._forbearanceHandlersRegistered = false
    self._tenancyHandlersRegistered = false
    self._registeredPhone = nil
    self._registeredMarketService = nil
    self._registeredForbearanceService = nil
    self._registeredTenancyService = nil
end

function RFF_NotificationService:registerLenderMarketActionHandlers(marketService)
    local phone = self:getPhone()
    if phone == nil or self:getPhoneVersion() < 3 or type(phone.registerActionHandler) ~= "function" then
        return false
    end
    if g_currentMission == nil or not g_currentMission:getIsServer() or marketService == nil then
        return false
    end

    if self._actionHandlersRegistered and self._registeredPhone == phone and self._registeredMarketService == marketService then
        return true
    end

    local sourceId = self.SOURCE_ID
    local acceptId = self.PHONE_ACTION_ACCEPT_PREAPPROVED
    local declineId = self.PHONE_ACTION_DECLINE_PREAPPROVED

    local okAccept, acceptError = pcall(phone.registerActionHandler, sourceId, acceptId, function(context)
        return marketService:handlePhoneDecision(context, "accept")
    end)
    if not okAccept then
        print(string.format("[RealisticFarmFinance] Warning: unable to register Mobile Phone Accept handler: %s", tostring(acceptError)))
        return false
    end

    local okDecline, declineError = pcall(phone.registerActionHandler, sourceId, declineId, function(context)
        return marketService:handlePhoneDecision(context, "decline")
    end)
    if not okDecline then
        print(string.format("[RealisticFarmFinance] Warning: unable to register Mobile Phone Decline handler: %s", tostring(declineError)))
        return false
    end

    self._actionHandlersRegistered = true
    self._registeredPhone = phone
    self._registeredMarketService = marketService
    print("[RealisticFarmFinance] Derwen Mobile Phone API v3 decision handlers registered")
    return true
end

function RFF_NotificationService:registerForbearanceActionHandlers(forbearanceService)
    local phone = self:getPhone()
    if phone == nil or self:getPhoneVersion() < 3 or type(phone.registerActionHandler) ~= "function" then return false end
    if g_currentMission == nil or not g_currentMission:getIsServer() or forbearanceService == nil then return false end
    if self._forbearanceHandlersRegistered and self._registeredPhone == phone and self._registeredForbearanceService == forbearanceService then return true end

    local okAccept, acceptError = pcall(phone.registerActionHandler, self.SOURCE_ID, self.PHONE_ACTION_ACCEPT_FORBEARANCE, function(context)
        return forbearanceService:handlePhoneDecision(context, "accept")
    end)
    if not okAccept then
        print(string.format("[RealisticFarmFinance] Warning: unable to register Mobile Phone forbearance Accept handler: %s", tostring(acceptError)))
        return false
    end
    local okDecline, declineError = pcall(phone.registerActionHandler, self.SOURCE_ID, self.PHONE_ACTION_DECLINE_FORBEARANCE, function(context)
        return forbearanceService:handlePhoneDecision(context, "decline")
    end)
    if not okDecline then
        print(string.format("[RealisticFarmFinance] Warning: unable to register Mobile Phone forbearance Decline handler: %s", tostring(declineError)))
        return false
    end
    self._forbearanceHandlersRegistered = true
    self._registeredPhone = phone
    self._registeredForbearanceService = forbearanceService
    print("[RealisticFarmFinance] Derwen Mobile Phone API v3 forbearance decision handlers registered")
    return true
end

function RFF_NotificationService:pushPhoneForbearanceActionable(farmId, sender, title, message, token, forbearanceService)
    local phone = self:getPhone()
    if phone == nil or self:getPhoneVersion() < 3 then return false end
    if not self:registerForbearanceActionHandlers(forbearanceService) then return false end
    local acceptLabel = string.upper(self:getText("rff_phone_accept", "Accept"))
    local declineLabel = string.upper(self:getText("rff_phone_decline", "Decline"))
    local ok, result = pcall(phone.sendNotification, sender, title, message, {
        sourceId=self.SOURCE_ID, category="forbearance", farmId=farmId,
        actions={
            token=tostring(token or ""), scope="farm",
            left={id=self.PHONE_ACTION_ACCEPT_FORBEARANCE,label=acceptLabel,resultLabel="ACCEPTED"},
            right={id=self.PHONE_ACTION_DECLINE_FORBEARANCE,label=declineLabel,resultLabel="DECLINED"}
        }
    })
    if not ok then
        print(string.format("[RealisticFarmFinance] Warning: Derwen Mobile Phone forbearance notification failed: %s", tostring(result)))
        return false
    end
    return result ~= false
end

function RFF_NotificationService:registerTenancyActionHandlers(propertyFinanceService)
    local phone = self:getPhone()
    if phone == nil or self:getPhoneVersion() < 3 or type(phone.registerActionHandler) ~= "function" then return false end
    if g_currentMission == nil or not g_currentMission:getIsServer() or propertyFinanceService == nil then return false end
    if self._tenancyHandlersRegistered and self._registeredPhone == phone and self._registeredTenancyService == propertyFinanceService then return true end

    local okAccept, acceptError = pcall(phone.registerActionHandler, self.SOURCE_ID, self.PHONE_ACTION_ACCEPT_TENANCY_RENEWAL, function(context)
        return propertyFinanceService:handleTenancyPhoneDecision(context, "accept")
    end)
    if not okAccept then
        print(string.format("[RealisticFarmFinance] Warning: unable to register Mobile Phone tenancy renewal Accept handler: %s", tostring(acceptError)))
        return false
    end
    local okDecline, declineError = pcall(phone.registerActionHandler, self.SOURCE_ID, self.PHONE_ACTION_DECLINE_TENANCY_RENEWAL, function(context)
        return propertyFinanceService:handleTenancyPhoneDecision(context, "decline")
    end)
    if not okDecline then
        print(string.format("[RealisticFarmFinance] Warning: unable to register Mobile Phone tenancy renewal Decline handler: %s", tostring(declineError)))
        return false
    end
    self._tenancyHandlersRegistered = true
    self._registeredPhone = phone
    self._registeredTenancyService = propertyFinanceService
    print("[RealisticFarmFinance] Derwen Mobile Phone API v3 tenancy renewal decision handlers registered")
    return true
end

function RFF_NotificationService:pushPhoneTenancyRenewalActionable(farmId, sender, title, message, token, propertyFinanceService)
    local phone = self:getPhone()
    if phone == nil or self:getPhoneVersion() < 3 then return false end
    if not self:registerTenancyActionHandlers(propertyFinanceService) then return false end
    local acceptLabel = string.upper(self:getText("rff_phone_accept", "Accept"))
    local declineLabel = string.upper(self:getText("rff_phone_decline", "Decline"))
    local ok, result = pcall(phone.sendNotification, sender, title, message, {
        sourceId=self.SOURCE_ID, category="tenancy", farmId=farmId,
        actions={
            token=tostring(token or ""), scope="farm",
            left={id=self.PHONE_ACTION_ACCEPT_TENANCY_RENEWAL,label=acceptLabel,resultLabel="ACCEPTED"},
            right={id=self.PHONE_ACTION_DECLINE_TENANCY_RENEWAL,label=declineLabel,resultLabel="DECLINED"}
        }
    })
    if not ok then
        print(string.format("[RealisticFarmFinance] Warning: Derwen Mobile Phone tenancy renewal notification failed: %s", tostring(result)))
        return false
    end
    return result ~= false
end

function RFF_NotificationService:pushPhone(farmId, sender, title, message, category)
    local phone = self:getPhone()
    if phone == nil then return false end

    local ok, result = pcall(phone.sendNotification, sender, title, message, {
        sourceId = self.SOURCE_ID,
        farmId = farmId,
        category = category or "finance"
    })
    if not ok then
        print(string.format("[RealisticFarmFinance] Warning: Derwen Mobile Phone notification failed: %s", tostring(result)))
        return false
    end
    return result ~= false
end

function RFF_NotificationService:pushPhoneActionable(farmId, sender, title, message, category, token, marketService, acceptKey, declineKey)
    local phone = self:getPhone()
    if phone == nil or self:getPhoneVersion() < 3 then return false end
    if not self:registerLenderMarketActionHandlers(marketService) then return false end

    local acceptLabel = string.upper(self:getText(acceptKey or "rff_phone_accept", "Accept"))
    local declineLabel = string.upper(self:getText(declineKey or "rff_phone_decline", "Decline"))

    local ok, result = pcall(phone.sendNotification, sender, title, message, {
        sourceId = self.SOURCE_ID,
        category = category or "finance",
        farmId = farmId,
        actions = {
            token = tostring(token or ""),
            scope = "farm",
            left = {
                id = self.PHONE_ACTION_ACCEPT_PREAPPROVED,
                label = acceptLabel,
                resultLabel = "ACCEPTED"
            },
            right = {
                id = self.PHONE_ACTION_DECLINE_PREAPPROVED,
                label = declineLabel,
                resultLabel = "DECLINED"
            }
        }
    })
    if not ok then
        print(string.format("[RealisticFarmFinance] Warning: Derwen Mobile Phone actionable notification failed: %s", tostring(result)))
        return false
    end
    return result ~= false
end

function RFF_NotificationService:isLocalHudFarm(farmId)
    -- GIANTS' top-right notification queue is local/global UI, not farm-scoped.
    -- RFF may process several legitimate farms on the authoritative server, but a
    -- failed/unavailable farm-targeted phone delivery must never fall back into
    -- another farm's local HUD. Only the current player's farm may use HUD fallback.
    if g_currentMission == nil or g_currentMission.getFarmId == nil then return false end
    local ok, localFarmId = pcall(g_currentMission.getFarmId, g_currentMission)
    if not ok then return false end
    local targetFarmId = tonumber(farmId) or 0
    local currentFarmId = tonumber(localFarmId) or 0
    return targetFarmId > 0 and currentFarmId > 0 and targetFarmId == currentFarmId
end

function RFF_NotificationService:send(farmId, sender, title, message, category, fallbackText, critical)
    if self:pushPhone(farmId, sender, title, message, category) then
        return true
    end

    if fallbackText ~= nil and fallbackText ~= ""
        and self:isLocalHudFarm(farmId)
        and g_currentMission ~= nil and g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        local notificationType = critical and FSBaseMission.INGAME_NOTIFICATION_CRITICAL or FSBaseMission.INGAME_NOTIFICATION_INFO
        g_currentMission:addIngameNotification(notificationType, fallbackText)
        return true
    end
    return false
end
