-- RFF gameplay limits, not a statement of real-world road certification.
RFF_RoadSpeedRules = {}
RFF_RoadSpeedRules.DIMENSION_CAP_KMH = 30

function RFF_RoadSpeedRules.formatSpeed(value, i18n)
    if value == nil then return "-" end
    if i18n ~= nil and type(i18n.getSpeed) == "function" and type(i18n.getSpeedMeasuringUnit) == "function" then
        return string.format("%.0f %s", i18n:getSpeed(value), i18n:getSpeedMeasuringUnit())
    end
    return string.format("%.0f km/h", value)
end

local function positive(value)
    value = tonumber(value)
    if value ~= nil and value == value and value > 0 and value < 500 then return value end
    return nil
end

function RFF_RoadSpeedRules.getRoadInfo(fleet, vehicle, context)
    local result = {detected=false, limitKmh=nil}
    local x, y, z, node = fleet:getVehiclePosition(vehicle, context)
    local traffic = g_currentMission ~= nil and g_currentMission.trafficSystem or nil
    if x == nil or traffic == nil or traffic.trafficSystemId == nil or traffic.trafficSystemId == 0
        or type(findTrafficSystemBlockingPositionInformation) ~= "function" then return result end
    local dx, dy, dz = 0, 0, 1
    if node ~= nil and type(localDirectionToWorld) == "function" then
        local ok, a, b, c = pcall(localDirectionToWorld, node, 0, 0, 1)
        if ok and a ~= nil and c ~= nil then dx, dy, dz = a, b or 0, c end
    end
    local ok, spline = pcall(findTrafficSystemBlockingPositionInformation, traffic.trafficSystemId,
        x, y or 0, z, dx, dy, dz, fleet.ROAD_SPLINE_DISTANCE)
    if not ok or type(spline) ~= "number" or spline <= 0 then return result end
    result.detected, result.splineId = true, spline
    -- GIANTS returns the spline node. Its speedLimit user attribute is km/h;
    -- it is map-authored traffic guidance, not the displayed roadside sign.
    if type(getUserAttribute) == "function" then
        local okAttribute, value = pcall(getUserAttribute, spline, "speedLimit")
        if okAttribute then result.limitKmh = positive(value) end
    end
    return result
end

function RFF_RoadSpeedRules.getVehicleMaximum(vehicle)
    local motor = vehicle ~= nil and vehicle.spec_motorized ~= nil and vehicle.spec_motorized.motor or nil
    if motor == nil and vehicle ~= nil and type(vehicle.getMotor) == "function" then
        local ok, value = pcall(vehicle.getMotor, vehicle)
        if ok then motor = value end
    end
    if motor == nil then return nil end
    -- GIANTS stores the original configured/physical maximum after loading the
    -- selected motor AND wheel configuration, in m/s. Do not use cruise-control
    -- speed, setSpeedLimit, current speed or ADS condition-limited speed.
    local original = positive(tonumber(motor.maxForwardSpeedOrigin) ~= nil and motor.maxForwardSpeedOrigin * 3.6 or nil)
    if original ~= nil then return original end
    -- Non-standard mod motors may not expose the GIANTS original value.
    if type(motor.getMaximumForwardSpeed) == "function" then
        local ok, value = pcall(motor.getMaximumForwardSpeed, motor)
        if ok and tonumber(value) ~= nil then return positive(tonumber(value) * 3.6) end
    end
    return nil
end

function RFF_RoadSpeedRules.calculate(roadLimit, vehicleLimit, width, mass, penalty, fallback)
    local result = {
        roadLimitKmh=positive(roadLimit), vehicleLimitKmh=positive(vehicleLimit),
        widthLimitKmh=(tonumber(width) or 0) > 3.001 and RFF_RoadSpeedRules.DIMENSION_CAP_KMH or nil,
        weightLimitKmh=(tonumber(mass) or 0) > 44.001 and RFF_RoadSpeedRules.DIMENSION_CAP_KMH or nil,
        penaltyLimitKmh=positive(penalty), limitKmh=nil, reason=nil
    }
    -- Vehicle/road missing: no made-up road cap. If neither is usable, retain a
    -- clearly labelled compatibility fallback, including during licence tests.
    if result.vehicleLimitKmh == nil and result.roadLimitKmh == nil then
        result.fallbackLimitKmh=positive(fallback) or 40
    end
    for _, entry in ipairs({{"ROAD","roadLimitKmh"},{"VEHICLE","vehicleLimitKmh"},
        {"WIDTH","widthLimitKmh"},{"WEIGHT","weightLimitKmh"},{"PENALTY","penaltyLimitKmh"},
        {"FALLBACK","fallbackLimitKmh"}}) do
        local value = result[entry[2]]
        if value ~= nil and (result.limitKmh == nil or value < result.limitKmh) then
            result.limitKmh, result.reason = value, entry[1]
        end
    end
    return result
end
