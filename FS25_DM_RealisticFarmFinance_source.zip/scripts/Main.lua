RFF_RealisticFarmFinance = {}
RFF_RealisticFarmFinance.modDirectory = g_currentModDirectory
RFF_RealisticFarmFinance.modName = g_currentModName
RFF_RealisticFarmFinance.manager = nil
RFF_RealisticFarmFinance.guiFrame = nil
RFF_RealisticFarmFinance._balancePatched = false
RFF_RealisticFarmFinance._vanillaLoanUiPatched = false

source(RFF_RealisticFarmFinance.modDirectory .. "scripts/NewSaveSetup.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/LivestockAssetRegistry.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/FarmValuation.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/FinanceRepository.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/TenancyAccessService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/PaymentConduct.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/CreditProfile.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/LenderRelationshipService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/NotificationService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/LoanService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/BankingService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/BusinessAdministrationService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/InsuranceClaimService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/InsuranceHistoryAPI.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/TaxComplianceService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/DefaultManagementService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/ADSIntegration.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/RoadSpeedRules.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/RoadSpeedHud.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/FleetManagementService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/VehicleComplianceService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/SpeedingEnforcementService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/RoadsideCheckService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/AssetFinanceService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/AssetFinanceShopExtension.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/ShopCredit.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/UsedEquipmentYardsIntegration.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/ApplicationService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/NpcNarrativeService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/PropertyFinanceService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/BrokerService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/LenderMarketService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/RefinanceService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/ForbearanceService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/LegacyFinanceMigration.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/FarmlandMapExtension.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/DocumentFontCharacter.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/DocumentFontRenderer.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/FinanceFrame.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/LandFinanceDialog.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/TenancyManagementDialog.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/EquityReleaseDialog.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/SecurityReleaseDialog.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/AssetFinanceDialog.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/TaxReturnDialog.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/InsuranceClaimDialog.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/CropAdvanceService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/EconomyService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/SavingsService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/InvestmentService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/DealershipService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/DemoDayService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/DealerHandover.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/DealershipShop.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/DealershipPage.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/DealerShopMenu.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/FinancialAdviserService.lua")
source(RFF_RealisticFarmFinance.modDirectory .. "scripts/gui/ClaimDecisionDialog.lua")

RFF_TenancyAccessService:install()
RFF_FarmlandMapExtension.install()

local function patchFarmBalance()
    if RFF_RealisticFarmFinance._balancePatched or Farm == nil or Farm.changeBalance == nil then
        return
    end

    Farm.changeBalance = Utils.appendedFunction(Farm.changeBalance, function(farm, amount, moneyType)
        local manager = RFF_RealisticFarmFinance.manager
        if manager ~= nil and manager.repository ~= nil then
            manager.repository:onMoneyChange(farm, amount, moneyType)
        end
    end)

    RFF_RealisticFarmFinance._balancePatched = true
end

-- RFF replaces the native farm-loan workflow once the existing balance has been
-- migrated. Disable the GIANTS borrow/repay controls so a second vanilla liability
-- cannot be created alongside RFF agreements. This leaves the standard Finance
-- statistics themselves intact; only the native loan action permission is removed.
local function patchVanillaLoanUi()
    if RFF_RealisticFarmFinance._vanillaLoanUiPatched then return end
    if InGameMenuStatisticsFrame == nil or InGameMenuStatisticsFrame.hasPlayerLoanPermission == nil then return end

    InGameMenuStatisticsFrame.hasPlayerLoanPermission = Utils.overwrittenFunction(
        InGameMenuStatisticsFrame.hasPlayerLoanPermission,
        function() return false end
    )
    RFF_RealisticFarmFinance._vanillaLoanUiPatched = true
end

local function registerFinanceMenu(frame)
    local inGameMenu = g_gui ~= nil and g_gui.screenControllers[InGameMenu] or nil
    if inGameMenu == nil or inGameMenu.pagingElement == nil then
        print("[RealisticFarmFinance] Warning: InGameMenu unavailable; Finance tab not registered")
        return false
    end

    local pageName = "rffFinanceFrame"
    if inGameMenu.controlIDs ~= nil then
        inGameMenu.controlIDs[pageName] = nil
    end

    inGameMenu[pageName] = frame
    inGameMenu.pagingElement:addElement(frame)
    inGameMenu:exposeControlsAsFields(pageName)

    local position = math.max(1, #inGameMenu.pagingElement.elements - 1)

    for i = 1, #inGameMenu.pagingElement.elements do
        if inGameMenu.pagingElement.elements[i] == frame then
            table.remove(inGameMenu.pagingElement.elements, i)
            table.insert(inGameMenu.pagingElement.elements, position, frame)
            break
        end
    end

    if inGameMenu.pagingElement.pages ~= nil then
        for i = 1, #inGameMenu.pagingElement.pages do
            local page = inGameMenu.pagingElement.pages[i]
            if page ~= nil and page.element == frame then
                table.remove(inGameMenu.pagingElement.pages, i)
                table.insert(inGameMenu.pagingElement.pages, position, page)
                break
            end
        end
    end

    inGameMenu.pagingElement:updateAbsolutePosition()
    inGameMenu.pagingElement:updatePageMapping()
    inGameMenu:registerPage(frame, position, nil)

    local iconFileName = Utils.getFilename("images/menuIcon.dds", RFF_RealisticFarmFinance.modDirectory)
    inGameMenu:addPageTab(frame, iconFileName, GuiUtils.getUVs({0, 0, 1024, 1024}))

    for i = 1, #inGameMenu.pageFrames do
        if inGameMenu.pageFrames[i] == frame then
            table.remove(inGameMenu.pageFrames, i)
            table.insert(inGameMenu.pageFrames, position, frame)
            break
        end
    end

    inGameMenu:rebuildTabList()
    return true
end

function RFF_RealisticFarmFinance:loadMap()
    -- Development credit overrides are deliberately session/save-load transient.
    RFF_TestCreditOverride = {}

    -- Mission-scoped discovery route for external livestock holders such as
    -- Freeform Pastures and Golden Hoof. The common global publication in
    -- LivestockAssetRegistry.lua remains the early/cross-mod discovery route.
    if g_currentMission ~= nil then
        g_currentMission.rffLivestockAssetRegistry = RFF_LivestockAssetRegistry
        g_currentMission.rffInsuranceHistoryApi = RFF_InsuranceHistoryAPI
    end
    local repository = RFF_FinanceRepository.new()
    self.manager = {
        repository = repository,
        loanService = RFF_LoanService.new(repository)
    }
    self.manager.relationshipService = RFF_LenderRelationshipService.new(repository)
    self.manager.adviser = RFF_FinancialAdviserService.new(self.manager)
    self.manager.savings = RFF_SavingsService.new(repository)
    self.manager.investments = RFF_InvestmentService.new(repository,self.manager.savings)
    self.manager.dealership = RFF_DealershipService.new(self.manager)
    self.manager.dealerHandover = RFF_DealerHandover.new(self.manager.dealership)
    self.manager.demoDays = RFF_DemoDayService.new(self.manager)
    addConsoleCommand("rffDemo", "Demo days: STATUS or TOMORROW (test reschedule)", "console", self.manager.demoDays)
    addConsoleCommand("rffDealer", "Dealer orders: STATUS or READY <ID> (test)", "consoleStatus", self.manager.dealership)
    addConsoleCommand("rffInvestments", "Investments: STATUS or SIMULATE 60 (read-only copy)", "consoleStatus", self.manager.investments)
    addConsoleCommand("rffSavings", "Print savings records", "consoleStatus", self.manager.savings)
    self.manager.economy = RFF_EconomyService.new(repository)
    addConsoleCommand("rffEconomy", "Economy: STATUS or SIMULATE 60 (read-only copy)", "consoleTest", self.manager.economy)
    self.manager.cropAdvances = RFF_CropAdvanceService.new(repository, self.manager.loanService)
    addConsoleCommand("rffCropAdvanceTest", "Crop advances: STATUS or EXPIRE <id> (creates a real shortfall loan)", "consoleTest", self.manager.cropAdvances)
    if self.manager.loanService.setRelationshipService ~= nil then self.manager.loanService:setRelationshipService(self.manager.relationshipService) end
    self.manager.bankingService = RFF_BankingService.new(repository, self.manager.loanService)
    self.manager.businessAdministration = RFF_BusinessAdministrationService.new(repository, self.manager.bankingService)
    self.manager.fleetManagement = RFF_FleetManagementService.new(repository, self.manager.businessAdministration)
    self.manager.vehicleCompliance = RFF_VehicleComplianceService.new(repository, self.manager.fleetManagement)
    self.manager.roadSpeedHud = RFF_RoadSpeedHud.new(self.manager.vehicleCompliance, RFF_RealisticFarmFinance.modDirectory)
    self.manager.speedingEnforcement = RFF_SpeedingEnforcementService.new(repository,self.manager.vehicleCompliance)
    self.manager.roadsideChecks = RFF_RoadsideCheckService.new(repository,self.manager.vehicleCompliance,self.manager.speedingEnforcement)
    addConsoleCommand("rffRoadsideTest", "Roadside check tests: rffRoadsideTest [STATUS|ARM]", "consoleTest", self.manager.roadsideChecks)
    addConsoleCommand("rffSpeedingTest", "Speeding notice tests: rffSpeedingTest [STATUS|ARM]", "consoleTest", self.manager.speedingEnforcement)
    self.manager.fleetManagement.vehicleCompliance = self.manager.vehicleCompliance
    self.manager.insuranceClaims = RFF_InsuranceClaimService.new(repository, self.manager.businessAdministration, self.manager.fleetManagement, self.manager.vehicleCompliance)
    self.manager.taxCompliance = RFF_TaxComplianceService.new(repository, self.manager.businessAdministration)
    self.manager.defaultManagement = RFF_DefaultManagementService.new(repository)
    self.manager.assetFinance = RFF_AssetFinanceService.new(repository, self.manager.loanService)
    if self.manager.assetFinance.setRelationshipService ~= nil then self.manager.assetFinance:setRelationshipService(self.manager.relationshipService) end
    self.manager.defaultManagement:setAssetFinanceService(self.manager.assetFinance)
    self.manager.applicationService = RFF_ApplicationService.new(repository, self.manager.loanService)
    if self.manager.applicationService.setRelationshipService ~= nil then self.manager.applicationService:setRelationshipService(self.manager.relationshipService) end
    self.manager.npcNarrative = RFF_NpcNarrativeService.new(repository)
    self.manager.propertyFinance = RFF_PropertyFinanceService.new(repository, self.manager.loanService, self.manager.npcNarrative)
    if self.manager.propertyFinance.setRelationshipService ~= nil then self.manager.propertyFinance:setRelationshipService(self.manager.relationshipService) end
    self.manager.defaultManagement:setPropertyFinanceService(self.manager.propertyFinance)
    self.manager.applicationService:setPropertyFinanceService(self.manager.propertyFinance)
    self.manager.brokerService = RFF_BrokerService.new(repository, self.manager.loanService, self.manager.applicationService, self.manager.propertyFinance)
    if self.manager.brokerService.setRelationshipService ~= nil then self.manager.brokerService:setRelationshipService(self.manager.relationshipService) end
    self.manager.lenderMarketService = RFF_LenderMarketService.new(repository, self.manager.loanService, self.manager.relationshipService)
    self.manager.refinanceService = RFF_RefinanceService.new(repository, self.manager.loanService, self.manager.relationshipService, self.manager.lenderMarketService)
    self.manager.forbearanceService = RFF_ForbearanceService.new(repository, self.manager.loanService, self.manager.relationshipService, self.manager.lenderMarketService)
    self.manager.legacyFinanceMigration = RFF_LegacyFinanceMigration.new(self.manager)
    if self.manager.loanService.setForbearanceService ~= nil then self.manager.loanService:setForbearanceService(self.manager.forbearanceService) end
    if self.manager.brokerService.setMarketService ~= nil then self.manager.brokerService:setMarketService(self.manager.lenderMarketService) end
    if self.manager.assetFinance.setMarketService ~= nil then self.manager.assetFinance:setMarketService(self.manager.lenderMarketService) end
    if self.manager.applicationService.setMarketService ~= nil then self.manager.applicationService:setMarketService(self.manager.lenderMarketService) end
    if self.manager.propertyFinance.setMarketService ~= nil then self.manager.propertyFinance:setMarketService(self.manager.lenderMarketService) end
    if g_currentMission ~= nil then g_currentMission.realisticFarmFinance = self.manager end
    if RFF_NotificationService ~= nil and RFF_NotificationService.registerLenderMarketActionHandlers ~= nil then
        RFF_NotificationService:registerLenderMarketActionHandlers(self.manager.lenderMarketService)
    end
    if RFF_NotificationService ~= nil and RFF_NotificationService.registerForbearanceActionHandlers ~= nil then
        RFF_NotificationService:registerForbearanceActionHandlers(self.manager.forbearanceService)
    end
    RFF_FarmlandMapExtension.install()
    RFF_AssetFinanceShopExtension.install()
    RFF_ShopCredit.install()
    RFF_DealershipShop.install()
    RFF_DemoDayService.install()

    patchFarmBalance()
    patchVanillaLoanUi()

    if g_messageCenter ~= nil then
        g_messageCenter:subscribe(MessageType.PERIOD_CHANGED, self.onPeriodChanged, self)
        g_messageCenter:subscribe(MessageType.DAY_CHANGED, self.onDayChanged, self)
        g_messageCenter:subscribe(MessageType.HOUR_CHANGED, self.onHourChanged, self)
    end

    g_gui:loadProfiles(self.modDirectory .. "gui/RFF_guiProfiles.xml")
    local frame = RFF_FinanceFrame.new(g_i18n, self.manager)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_financeFrame.xml", "RFFFinanceFrame", frame, true)

    local landFinanceDialog = RFF_LandFinanceDialog.new(frame)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_landFinanceDialog.xml", "RFFLandFinanceDialog", landFinanceDialog)

    local tenancyManagementDialog = RFF_TenancyManagementDialog.new(frame)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_tenancyManagementDialog.xml", "RFFTenancyManagementDialog", tenancyManagementDialog)

    local equityReleaseDialog = RFF_EquityReleaseDialog.new(frame)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_equityReleaseDialog.xml", "RFFEquityReleaseDialog", equityReleaseDialog)

    local securityReleaseDialog = RFF_SecurityReleaseDialog.new(frame)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_securityReleaseDialog.xml", "RFFSecurityReleaseDialog", securityReleaseDialog)

    local assetFinanceDialog = RFF_AssetFinanceDialog.new(frame)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_assetFinanceDialog.xml", "RFFAssetFinanceDialog", assetFinanceDialog)
    RFF_UsedEquipmentYardsIntegration:install()

    local taxReturnDialog = RFF_TaxReturnDialog.new(frame)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_taxReturnDialog.xml", "RFFTaxReturnDialog", taxReturnDialog)

    local insuranceClaimDialog = RFF_InsuranceClaimDialog.new(frame)
    g_gui:loadGui(self.modDirectory .. "gui/RFF_claimDecisionDialog.xml", "RFFClaimDecisionDialog", RFF_ClaimDecisionDialog.new())
    g_gui:loadGui(self.modDirectory .. "gui/RFF_insuranceClaimDialog.xml", "RFFInsuranceClaimDialog", insuranceClaimDialog)

    if registerFinanceMenu(frame) then
        frame:initialize()
        self.guiFrame = frame
        -- Retry UI hooks after the InGameMenu controller definitely exists.
        RFF_AssetFinanceShopExtension:installVehicleMenuSellHook()
        RFF_AssetFinanceShopExtension:installShopControllerSellHook()
        RFF_AssetFinanceShopExtension:installVehicleNameHook()
        print("[RealisticFarmFinance] Finance menu registered")
    end

    if RFF_LivestockAssetRegistry ~= nil then
        print(string.format("[RFF] Livestock asset provider API v%d ready; registeredProviders=%d", RFF_LivestockAssetRegistry.API_VERSION or 1, RFF_LivestockAssetRegistry:getProviderCount()))
    end
    if RFF_InsuranceHistoryAPI ~= nil then
        print(string.format("[RFF] Insurance/mortality history API v%d ready (read-only, server-authoritative)", RFF_InsuranceHistoryAPI.API_VERSION or 1))
    end

    if RFF_NotificationService ~= nil and RFF_NotificationService:getPhone() ~= nil then
        print(string.format("[RealisticFarmFinance] Derwen Mobile Phone API v%d detected; finance notifications will use the phone inbox", RFF_NotificationService:getPhoneVersion()))
    else
        print("[RealisticFarmFinance] Derwen Mobile Phone API not detected; standard RFF notifications remain active")
    end

    local daysPerPeriod = self.manager.applicationService:getDaysPerPeriod()
    if daysPerPeriod < 3 then
        print(string.format("[RealisticFarmFinance] Note: save uses %d day month(s). RFF financial administration is designed around a minimum 3-day month; underwriting timing will still scale to this save setting.", daysPerPeriod))
    else
        print(string.format("[RealisticFarmFinance] Calendar pacing: %d day month(s); underwriting delays scale to this setting.", daysPerPeriod))
    end

    addConsoleCommand("rffStatus", "Print Realistic Farm Finance status", "consoleStatus", self)
    addConsoleCommand("rffSnapshot", "Capture a Realistic Farm Finance valuation snapshot", "consoleSnapshot", self)
    addConsoleCommand("rffLivestockAssets", "Print RFF livestock asset valuation/provider breakdown", "consoleLivestockAssets", self)
    addConsoleCommand("rffLoans", "Print Realistic Farm Finance active lending agreements", "consoleLoans", self)
    addConsoleCommand("rffProperty", "Print Realistic Farm Finance property agreements", "consoleProperty", self)
    addConsoleCommand("rffApplications", "Print Realistic Farm Finance credit applications", "consoleApplications", self)
    addConsoleCommand("rffDecisionNow", "Process pending Realistic Farm Finance credit applications now", "consoleDecisionNow", self)
    addConsoleCommand("rffBroker", "Print Realistic Farm Finance broker cases", "consoleBroker", self)
    addConsoleCommand("rffBrokerNow", "Process pending Realistic Farm Finance broker cases now", "consoleBrokerNow", self)
    addConsoleCommand("rffAssets", "Print Realistic Farm Finance asset-finance agreements", "consoleAssets", self)
    addConsoleCommand("rffADSAssessment", "Inspect ADS condition and RFF return/recovery deductions for the controlled vehicle", "consoleADSAssessment", self)
    addConsoleCommand("rffConduct", "Print Realistic Farm Finance arrears and payment conduct", "consoleConduct", self)
    addConsoleCommand("rffPhoneTest", "Send a Realistic Farm Finance phone integration test", "consolePhoneTest", self)
    addConsoleCommand("rffBank", "Print Realistic Farm Finance bank account / overdraft position", "consoleBank", self)
    addConsoleCommand("rffDefaults", "Print Realistic Farm Finance arrears escalation / default state", "consoleDefaults", self)
    addConsoleCommand("rffTestCreditReset", "Temporarily use a healthy credit/DSCR profile for testing: rffTestCreditReset [monthlyIncome|off]", "consoleTestCreditReset", self)
    addConsoleCommand("rffRelationships", "Print lender and broker relationship status", "consoleRelationships", self)
    addConsoleCommand("rffMarket", "Print Realistic Farm Finance lender market and proactive offers", "consoleMarket", self)
    addConsoleCommand("rffMarketNow", "Force proactive lender-offer check: rffMarketNow [test]", "consoleMarketNow", self)
    addConsoleCommand("rffRefinance", "Quote RFF refinance/consolidation: rffRefinance [loanId|all]", "consoleRefinance", self)
    addConsoleCommand("rffForbearance", "Show RFF payment-help/rescue options: rffForbearance [loanId]", "consoleForbearance", self)
    addConsoleCommand("rffBusiness", "Print RFF tax/admin/insurance position", "consoleBusiness", self)
    addConsoleCommand("rffInsuranceNow", "Force the next RFF business insurance renewal for testing", "consoleInsuranceNow", self)
    addConsoleCommand("rffVehicleInsurance", "Print RFF per-vehicle insurance policy status", "consoleVehicleInsurance", self)
    addConsoleCommand("rffVehicleCompliance", "Print the controlled vehicle's RFF road-compliance assessment", "consoleVehicleCompliance", self)
    addConsoleCommand("rffQualificationTest", "Set test driver entitlements: rffQualificationTest [B|F|H|C|ADR|ALL|RESET|REVOKE]", "consoleQualificationTest", self)
    addConsoleCommand("rffDriverOffenceTest", "Create or clear a driver offence: rffDriverOffenceTest [MINOR|MODERATE|SERIOUS|SEVERE|CLEAR]", "consoleDriverOffenceTest", self)
    addConsoleCommand("rffDriverPenaltyTest", "Speed penalty testing: rffDriverPenaltyTest [STATUS|ON|OFF|EXPIRE|EXPIREPOINTS]", "consoleDriverPenaltyTest", self)
    addConsoleCommand("rffInsurancePricingTest", "Read-only vehicle pricing check: rffInsurancePricingTest [STATUS|EXAMPLES]", "consoleInsurancePricingTest", self)
    addConsoleCommand("rffRoadRules", "Show current vehicle speed-rule breakdown (read-only)", "consoleRoadRules", self)
    addConsoleCommand("rffVehicleClaimTest", "Submit a test vehicle claim from the controlled vehicle: rffVehicleClaimTest [own|third|legal|mixed] [amount] [auto|road|farmland|other] [grossTonnes]", "consoleVehicleClaimTest", self)
    addConsoleCommand("rffClaims", "Print RFF business and vehicle insurance claims", "consoleClaims", self)
    addConsoleCommand("rffWelfareHistory", "Print read-only RFF mortality/claim history API summary: rffWelfareHistory [periods]", "consoleWelfareHistory", self)
    addConsoleCommand("rffClaimTest", "Create a livestock loss record for claim testing: rffClaimTest [accident|health|age] [value]", "consoleClaimTest", self)
    addConsoleCommand("rffVetTest", "Create a veterinary treatment expense for insurance testing: rffVetTest [cost]", "consoleVetTest", self)
    addConsoleCommand("rffClaimDecisionNow", "Force pending insurance claim decisions and settlements: rffClaimDecisionNow [claimId]", "consoleClaimDecisionNow", self)
    addConsoleCommand("rffTax", "Print RFF annual tax-return/compliance state", "consoleTax", self)
    addConsoleCommand("rffTaxNow", "Open/create an RFF annual tax return from current Red Tape books for testing", "consoleTaxNow", self)
    addConsoleCommand("rffTaxAuditNow", "Force a compliance review of the currently filed RFF tax return", "consoleTaxAuditNow", self)
    addConsoleCommand("rffTenancyGrant", "Create a tenancy contract: rffTenancyGrant <farmlandIds> [term] [frequency] [breakAtMonth] [breakNotice] [rentReviewInterval]", "consoleTenancyGrant", self)
    addConsoleCommand("rffTenancyRevoke", "End the current farm tenancy containing farmland: rffTenancyRevoke <farmlandId>", "consoleTenancyRevoke", self)
    addConsoleCommand("rffTenancyStatus", "Print current farm tenancy contracts, financial state and land access", "consoleTenancyStatus", self)
    addConsoleCommand("rffTenancyRestrictive", "Force the selected active tenancy to restrictive test covenants: rffTenancyRestrictive [farmlandId]", "consoleTenancyRestrictive", self)
    addConsoleCommand("rffTenancyInspectNow", "Run a covenant inspection on the selected active tenancy: rffTenancyInspectNow [farmlandId]", "consoleTenancyInspectNow", self)
    addConsoleCommand("rffTenancyRemedyNow", "Run the follow-up review for an open covenant remedy case: rffTenancyRemedyNow [farmlandId]", "consoleTenancyRemedyNow", self)
    addConsoleCommand("rffTenancyHandbackNow", "Run or complete tenancy handback testing: rffTenancyHandbackNow [farmlandId] [end]", "consoleTenancyHandbackNow", self)
    addConsoleCommand("rffTenancyLandlordChangeNow", "Serve a formal landlord covenant-variation notice for testing: rffTenancyLandlordChangeNow [farmlandId]", "consoleTenancyLandlordChangeNow", self)
    addConsoleCommand("rffTenancyApplicationNow", "Advance the latest initial tenancy application by one procedural stage: rffTenancyApplicationNow [farmlandId]", "consoleTenancyApplicationNow", self)
end

function RFF_RealisticFarmFinance:deleteMap()
    if self.manager and self.manager.dealerHandover then self.manager.dealerHandover:delete() end
    if self.manager and self.manager.demoDays then self.manager.demoDays:delete() end
    removeConsoleCommand("rffDemo")
    removeConsoleCommand("rffSavings")
    removeConsoleCommand("rffInvestments")
    removeConsoleCommand("rffDealer")
    removeConsoleCommand("rffEconomy")
    removeConsoleCommand("rffCropAdvanceTest")
    if self.manager ~= nil and self.manager.cropAdvances ~= nil then self.manager.cropAdvances:shutdown() end
    if self.manager ~= nil and self.manager.roadSpeedHud ~= nil then self.manager.roadSpeedHud:delete() end
    if g_messageCenter ~= nil then
        g_messageCenter:unsubscribeAll(self)
    end
    removeConsoleCommand("rffStatus")
    removeConsoleCommand("rffSnapshot")
    removeConsoleCommand("rffLivestockAssets")
    removeConsoleCommand("rffLoans")
    removeConsoleCommand("rffProperty")
    removeConsoleCommand("rffApplications")
    removeConsoleCommand("rffDecisionNow")
    removeConsoleCommand("rffBroker")
    removeConsoleCommand("rffBrokerNow")
    removeConsoleCommand("rffAssets")
    removeConsoleCommand("rffADSAssessment")
    removeConsoleCommand("rffConduct")
    removeConsoleCommand("rffPhoneTest")
    removeConsoleCommand("rffBank")
    removeConsoleCommand("rffDefaults")
    removeConsoleCommand("rffTestCreditReset")
    removeConsoleCommand("rffRelationships")
    removeConsoleCommand("rffMarket")
    removeConsoleCommand("rffMarketNow")
    removeConsoleCommand("rffRefinance")
    removeConsoleCommand("rffForbearance")
    removeConsoleCommand("rffBusiness")
    removeConsoleCommand("rffInsuranceNow")
    removeConsoleCommand("rffVehicleInsurance")
    removeConsoleCommand("rffSpeedingTest")
    removeConsoleCommand("rffRoadsideTest")
    removeConsoleCommand("rffVehicleCompliance")
    removeConsoleCommand("rffQualificationTest")
    removeConsoleCommand("rffDriverOffenceTest")
    removeConsoleCommand("rffDriverPenaltyTest")
    removeConsoleCommand("rffInsurancePricingTest")
    removeConsoleCommand("rffRoadRules")
    removeConsoleCommand("rffVehicleClaimTest")
    removeConsoleCommand("rffClaims")
    removeConsoleCommand("rffWelfareHistory")
    removeConsoleCommand("rffClaimTest")
    removeConsoleCommand("rffVetTest")
    removeConsoleCommand("rffClaimDecisionNow")
    removeConsoleCommand("rffTax")
    removeConsoleCommand("rffTaxNow")
    removeConsoleCommand("rffTaxAuditNow")
    removeConsoleCommand("rffTenancyGrant")
    removeConsoleCommand("rffTenancyRevoke")
    removeConsoleCommand("rffTenancyStatus")
    removeConsoleCommand("rffTenancyRestrictive")
    removeConsoleCommand("rffTenancyInspectNow")
    removeConsoleCommand("rffTenancyRemedyNow")
    removeConsoleCommand("rffTenancyHandbackNow")
    removeConsoleCommand("rffTenancyLandlordChangeNow")
    removeConsoleCommand("rffTenancyApplicationNow")
    if self.manager ~= nil and self.manager.insuranceClaims ~= nil and self.manager.insuranceClaims.shutdownTrafficCourtesyHook ~= nil then self.manager.insuranceClaims:shutdownTrafficCourtesyHook() end
    if self.manager ~= nil and self.manager.vehicleCompliance ~= nil and self.manager.vehicleCompliance.shutdownTrafficCourtesyHook ~= nil then self.manager.vehicleCompliance:shutdownTrafficCourtesyHook() end
    if self.manager ~= nil and self.manager.taxCompliance ~= nil and self.manager.taxCompliance.restoreRedTapeHook ~= nil then self.manager.taxCompliance:restoreRedTapeHook() end
    if g_currentMission ~= nil and g_currentMission.realisticFarmFinance == self.manager then g_currentMission.realisticFarmFinance = nil end
    if g_currentMission ~= nil and g_currentMission.rffLivestockAssetRegistry == RFF_LivestockAssetRegistry then g_currentMission.rffLivestockAssetRegistry = nil end
    if g_currentMission ~= nil and g_currentMission.rffInsuranceHistoryApi == RFF_InsuranceHistoryAPI then g_currentMission.rffInsuranceHistoryApi = nil end
    if RFF_NotificationService ~= nil and RFF_NotificationService.resetActionHandlers ~= nil then RFF_NotificationService:resetActionHandlers() end
    self.guiFrame = nil
    self.manager = nil
end

function RFF_RealisticFarmFinance:onHourChanged()
    if self.manager ~= nil and self.manager.applicationService ~= nil then
        self.manager.applicationService:onHourChanged()
    end
    if self.manager ~= nil and self.manager.brokerService ~= nil then
        self.manager.brokerService:onHourChanged()
    end
    if self.manager ~= nil and self.manager.fleetManagement ~= nil and self.manager.fleetManagement.onHourChanged ~= nil then
        self.manager.fleetManagement:onHourChanged()
    end
end

function RFF_RealisticFarmFinance:update(dt)
    if self.manager ~= nil and self.manager.savings ~= nil then self.manager.savings:update(dt) end
    if self.manager ~= nil and self.manager.investments ~= nil then self.manager.investments:update(dt) end
    if self.manager ~= nil and self.manager.dealership ~= nil then self.manager.dealership:update(dt) end
    if self.manager ~= nil and self.manager.dealerHandover ~= nil then self.manager.dealerHandover:update(dt) end
    if self.manager ~= nil and self.manager.demoDays ~= nil then self.manager.demoDays:update(dt) end
    if self.manager ~= nil then RFF_DealerShopMenu.tryRegister() end
    if self.manager ~= nil and self.manager.adviser ~= nil then self.manager.adviser:update(dt) end
    if self.manager ~= nil and self.manager.cropAdvances ~= nil then self.manager.cropAdvances:update(dt) end
    if self.manager ~= nil and self.manager.roadsideChecks ~= nil then self.manager.roadsideChecks:update(dt) end
    if self.manager ~= nil and self.manager.speedingEnforcement ~= nil then self.manager.speedingEnforcement:update(dt) end
    if self.manager ~= nil and self.manager.roadSpeedHud ~= nil then self.manager.roadSpeedHud:update(dt) end
    if RFF_UsedEquipmentYardsIntegration ~= nil and RFF_UsedEquipmentYardsIntegration.update ~= nil then
        RFF_UsedEquipmentYardsIntegration:update(dt)
    end
    if self.manager ~= nil and self.manager.vehicleCompliance ~= nil and self.manager.vehicleCompliance.update ~= nil then
        self.manager.vehicleCompliance:update(dt)
    end
    if self.manager ~= nil and self.manager.insuranceClaims ~= nil and self.manager.insuranceClaims.update ~= nil then
        self.manager.insuranceClaims:update(dt)
    end
end

function RFF_RealisticFarmFinance:draw()
    if self.manager ~= nil and self.manager.roadsideChecks ~= nil then self.manager.roadsideChecks:draw() end
    if self.manager ~= nil and self.manager.roadSpeedHud ~= nil then self.manager.roadSpeedHud:draw() end
    if self.manager ~= nil and self.manager.vehicleCompliance ~= nil and self.manager.vehicleCompliance.draw ~= nil then
        self.manager.vehicleCompliance:draw()
    end
end

function RFF_RealisticFarmFinance:onDayChanged()
    if self.manager ~= nil and self.manager.vehicleCompliance ~= nil and self.manager.vehicleCompliance.onDayChanged ~= nil then
        self.manager.vehicleCompliance:onDayChanged()
    end
    if self.manager ~= nil and self.manager.applicationService ~= nil then
        self.manager.applicationService:onDayChanged()
    end
    if self.manager ~= nil and self.manager.brokerService ~= nil then
        self.manager.brokerService:onDayChanged()
    end
    if self.manager ~= nil and self.manager.bankingService ~= nil then
        self.manager.bankingService:onDayChanged()
    end
    if self.manager ~= nil and self.manager.assetFinance ~= nil and self.manager.assetFinance.onDayChanged ~= nil then
        self.manager.assetFinance:onDayChanged()
    end
    if self.manager ~= nil and self.manager.insuranceClaims ~= nil and self.manager.insuranceClaims.onDayChanged ~= nil then
        self.manager.insuranceClaims:onDayChanged()
    end
    if self.manager ~= nil and self.manager.propertyFinance ~= nil and self.manager.propertyFinance.onDayChanged ~= nil then
        self.manager.propertyFinance:onDayChanged()
        if self.guiFrame ~= nil and self.guiFrame.updatePropertyContent ~= nil then self.guiFrame:updatePropertyContent() end
    end
end

function RFF_RealisticFarmFinance:onPeriodChanged()
    if self.manager ~= nil and self.manager.cropAdvances ~= nil then self.manager.cropAdvances:processDue() end
    if self.manager ~= nil then
        if self.manager.loanService ~= nil then
            self.manager.loanService:onPeriodChanged()
        end
        if self.manager.assetFinance ~= nil then
            self.manager.assetFinance:onPeriodChanged()
        end
        if self.manager.propertyFinance ~= nil then
            self.manager.propertyFinance:onPeriodChanged()
        end
        if self.manager.defaultManagement ~= nil then
            self.manager.defaultManagement:onPeriodChanged()
        end
        if self.manager.forbearanceService ~= nil then
            self.manager.forbearanceService:onPeriodChanged()
        end
        if self.manager.bankingService ~= nil then
            self.manager.bankingService:onPeriodChanged()
        end
        -- Settle the elapsed month at its existing bank rate before reviewing rates.
        if self.manager.savings ~= nil then self.manager.savings:process() end
        if self.manager.economy ~= nil then self.manager.economy:advance() end
        if self.manager.businessAdministration ~= nil then
            self.manager.businessAdministration:onPeriodChanged()
        end
        if self.manager.fleetManagement ~= nil and self.manager.fleetManagement.onPeriodChanged ~= nil then
            self.manager.fleetManagement:onPeriodChanged()
        end
        if self.manager.taxCompliance ~= nil then
            self.manager.taxCompliance:onPeriodChanged()
        end
        if self.manager.insuranceClaims ~= nil and self.manager.insuranceClaims.onPeriodChanged ~= nil then
            self.manager.insuranceClaims:onPeriodChanged()
        end
        if self.manager.repository ~= nil then
            self.manager.repository:onPeriodChanged()
        end
        if self.manager.lenderMarketService ~= nil then
            self.manager.lenderMarketService:onPeriodChanged()
        end
    end
end

function RFF_RealisticFarmFinance:consoleSnapshot()
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil then
        return
    end
    local farmId = g_currentMission:getFarmId()
    self.manager.repository:captureSnapshot(farmId)
    print(string.format("[RealisticFarmFinance] Snapshot captured for farm %d", farmId))
    if RFF_FarmValuation ~= nil and RFF_FarmValuation.printLivestockBreakdown ~= nil then
        RFF_FarmValuation:printLivestockBreakdown(farmId, true)
    end
end

function RFF_RealisticFarmFinance:consoleLivestockAssets()
    if g_currentMission == nil or RFF_FarmValuation == nil then return end
    local farmId = g_currentMission:getFarmId()
    RFF_FarmValuation:printLivestockBreakdown(farmId, false)
    if RFF_LivestockAssetRegistry ~= nil then
        local providerIds = RFF_LivestockAssetRegistry:getProviderIds()
        print(string.format("[RFF] Livestock provider API v%d registered=%d providers=%s", RFF_LivestockAssetRegistry.API_VERSION or 1, #providerIds, #providerIds > 0 and table.concat(providerIds, ",") or "none"))
    end
end

function RFF_RealisticFarmFinance:consoleStatus()
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil then
        print("[RealisticFarmFinance] Not initialized")
        return
    end

    local farmId = g_currentMission:getFarmId()
    local valuation = RFF_FarmValuation:calculate(farmId, self.manager.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.manager.repository)

    print(string.format(
        "[RealisticFarmFinance] farm=%d assets=%.2f liabilities=%.2f netWorth=%.2f collateral=%.2f trackedPeriods=%d incomeBasis=%.2f securedHeadroom=%.2f",
        farmId,
        valuation.totalAssets,
        valuation.liabilities,
        valuation.netWorth,
        credit.collateral,
        credit.trackedPeriods,
        credit.monthlyIncome,
        credit.securedHeadroom
    ))
end

function RFF_RealisticFarmFinance:consoleLoans()
    if self.manager == nil or self.manager.repository == nil or self.manager.loanService == nil or g_currentMission == nil then
        print("[RealisticFarmFinance] Not initialized")
        return
    end

    local farmId = g_currentMission:getFarmId()
    local loans = self.manager.repository:getLoansByFarm(farmId, true)
    print(string.format("[RealisticFarmFinance] farm=%d activeFacilities=%d outstanding=%.2f monthlyDebtService=%.2f",
        farmId, #loans, self.manager.loanService:getOutstandingBalance(farmId), self.manager.loanService:getMonthlyDebtService(farmId)))

    for _, loan in ipairs(loans) do
        local outstanding = self.manager.loanService:getLoanOutstanding(loan)
        print(string.format("[RealisticFarmFinance] loan=%d type=%s legacy=%s outstanding=%.2f rate=%.2f grade=%s remainingMonths=%d missed=%d",
            loan.id or -1, tostring(loan.type), tostring(loan.legacyImported == true), outstanding, loan.interestRate or 0, tostring(loan.riskGrade), loan.remainingMonths or 0, loan.missedPayments or 0))
    end
end

function RFF_RealisticFarmFinance:consoleProperty()
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local count, balance, payment = self.manager.propertyFinance:getMortgageSummary(farmId)
    local security = self.manager.propertyFinance:getPropertySecuritySummary(farmId)
    local tenancies = self.manager.repository:getTenanciesByFarm(farmId, true)
    print(string.format("[RealisticFarmFinance] property farm=%d land=%.2f buildings=%.2f propertyEquity=%.2f mortgages=%d mortgageBalance=%.2f mortgagePayments=%.2f unencumberedLand=%d unencumberedValue=%.2f indicativeSecurityCapacity=%.2f tenancies=%d monthlyRent=%.2f deposits=%.2f", farmId, security.farmlandValue or 0, security.buildingValue or 0, security.propertyEquity or 0, count, balance, payment, security.unencumberedCount or 0, security.unencumberedLandValue or 0, security.indicativeSecurityHeadroom or 0, #tenancies, self.manager.repository:getMonthlyTenancyRent(farmId), self.manager.repository:getRefundableTenancyDeposits(farmId)))
    for _, loan in ipairs(self.manager.repository:getLoansByFarm(farmId, true) or {}) do
        if loan.type == RFF_LoanService.TYPE_MORTGAGE then
            local securityLabel = self.manager.propertyFinance:getMortgageSecurityLabel(loan)
            local recoveryFixtures = self.manager.propertyFinance:getMortgageRecoveryFixtures(loan, false)
            print(string.format("[RealisticFarmFinance]   mortgage=%d mode=%s security=%s balance=%.2f lenderValue=%.2f propertyLtv=%.3f fixedPlaceables=%d fixtureValue=%.2f affectedAnimals=%d forcedAnimalValue=%.2f", loan.id or 0, loan.propertyFinanceMode ~= "" and tostring(loan.propertyFinanceMode) or "LEGACY/PURCHASE", securityLabel, loan.principal or 0, loan.lenderValuation or 0, loan.propertyLtv or 0, recoveryFixtures.placeableCount or 0, recoveryFixtures.fixtureMarketValue or 0, recoveryFixtures.animalCount or 0, recoveryFixtures.livestockRealisedValue or 0))
        end
    end
end

function RFF_RealisticFarmFinance:consoleApplications()
    if self.manager == nil or self.manager.repository == nil or self.manager.applicationService == nil or g_currentMission == nil then
        print("[RealisticFarmFinance] Not initialized")
        return
    end
    local farmId = g_currentMission:getFarmId()
    local service = self.manager.applicationService
    local apps = self.manager.repository:getApplicationsByFarm(farmId)
    local nowHour = service:getCurrentHourStamp()
    print(string.format("[RealisticFarmFinance] farm=%d applications=%d day=%d hour=%d daysPerMonth=%d", farmId, #apps, service:getCurrentDay(), service:getCurrentHourOfDay(), service:getDaysPerPeriod()))
    for _, app in ipairs(apps) do
        service:normaliseApplicationTiming(app)
        local remaining = service:isPending(app) and math.max(0, (app.decisionHour or nowHour) - nowHour) or 0
        print(string.format("[RealisticFarmFinance] application=%d product=%s purpose=%s status=%s route=%s market=%s fit=%s requested=%.2f offered=%.2f land=%d lenderValue=%.2f requestedDeposit=%.2f offeredDeposit=%.2f decisionHour=%d remainingHours=%d expiryHour=%d outcome=%s",
            app.id or 0, tostring(app.product), tostring(app.purpose or "GENERAL"), tostring(app.status), tostring(app.route), tostring(app.marketState or "SELECTIVE"), tostring(app.dealFit or "STANDARD"), app.requestedAmount or 0, app.offeredAmount or 0,
            app.farmlandId or 0, app.lenderValuation or 0, app.requestedDepositAmount or 0, app.offeredDeposit or 0,
            app.decisionHour or 0, remaining, app.offerExpiryHour or 0, tostring(app.outcome)))
    end
end

function RFF_RealisticFarmFinance:consoleDecisionNow()
    if self.manager == nil or self.manager.applicationService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local count = self.manager.applicationService:forceProcessAll(farmId)
    print(string.format("[RealisticFarmFinance] Processed %d pending application(s) for farm %d", count, farmId))
end


function RFF_RealisticFarmFinance:consoleBroker()
    if self.manager == nil or self.manager.brokerService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local service = self.manager.brokerService
    local cases = service:getCasesByFarm(farmId)
    print(string.format("[RealisticFarmFinance] broker farm=%d cases=%d", farmId, #cases))
    for _, case in ipairs(cases) do
        print(string.format("[RealisticFarmFinance] brokerCase=%d sourceApp=%d product=%s status=%s requested=%.2f offers=%d acceptedLender=%s linkedLoan=%d",
            case.id or 0, case.sourceApplicationId or 0, tostring(case.product), tostring(case.status), case.requestedAmount or 0, #(case.offers or {}), tostring(case.acceptedLenderId or ""), case.linkedLoanId or 0))
        for i, offer in ipairs(case.offers or {}) do
            print(string.format("[RealisticFarmFinance]   offer=%d lender=%s appetite=%s fit=%s amount=%.2f rate=%.2f payment=%.2f arrangementFee=%.2f brokerFee=%.2f deposit=%.2f",
                i, tostring(offer.lenderId), tostring(offer.marketState or "SELECTIVE"), tostring(offer.dealFit or "STANDARD"), offer.amount or 0, offer.interestRate or 0, offer.monthlyPayment or 0, offer.arrangementFee or 0, offer.brokerFee or 0, offer.deposit or 0))
        end
    end
end

function RFF_RealisticFarmFinance:consoleBrokerNow()
    if self.manager == nil or self.manager.brokerService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local count = self.manager.brokerService:forceProcessAll(farmId)
    print(string.format("[RealisticFarmFinance] Processed %d pending broker case(s) for farm %d", count, farmId))
end

function RFF_RealisticFarmFinance:consoleMarket()
    if self.manager == nil or self.manager.lenderMarketService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local service = self.manager.lenderMarketService
    print(string.format("[RealisticFarmFinance] lender market farm=%d currentPeriod=%d", farmId, service:getCurrentPeriod()))
    for _, profile in ipairs(service:getProfiles()) do
        local market = service:getMarketAdjustment(profile.id)
        local rel, benefits = self.manager.relationshipService:getSummary(farmId, profile.id)
        local focus = service:getFocusSummary(profile.id) or {}
        local focusParts = {}
        for _, item in ipairs(focus) do table.insert(focusParts, string.format("%s=%s", tostring(item.purpose or item.key), tostring(item.fit))) end
        print(string.format("[RealisticFarmFinance]   lender=%s appetite=%s tier=%s points=%.1f successfulPayments=%d completed=%d proactiveMade=%d accepted=%d declined=%d lastOfferPeriod=%d focus=[%s]",
            profile.id, tostring(market.state), tostring(benefits.code), rel.relationshipPoints or 0, rel.successfulPayments or 0, rel.completedAgreements or 0,
            rel.proactiveOffersMade or 0, rel.proactiveOffersAccepted or 0, rel.proactiveOffersDeclined or 0, rel.lastProactiveOfferPeriod or 0, table.concat(focusParts, ", ")))
    end
    for _, offer in ipairs(service:getOffersByFarm(farmId)) do
        print(string.format("[RealisticFarmFinance]   proactiveOffer=%d lender=%s status=%s fit=%s amount=%.2f rate=%.2f term=%d fee=%.2f created=%d expiry=%d linkedLoan=%d",
            offer.id or 0, tostring(offer.lenderId), tostring(offer.status), tostring(offer.dealFit or "STANDARD"), offer.amount or 0, offer.interestRate or 0, offer.months or 0,
            offer.arrangementFee or 0, offer.createdPeriod or 0, offer.expiryPeriod or 0, offer.linkedLoanId or 0))
    end
end

function RFF_RealisticFarmFinance:consoleMarketNow(mode)
    if self.manager == nil or self.manager.lenderMarketService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local lowerMode = string.lower(tostring(mode or ""))
    local useTestCredit = lowerMode == "test"
    local previousOverride = nil

    if useTestCredit and RFF_CreditProfile ~= nil then
        previousOverride = RFF_CreditProfile:getTestOverride(farmId)
        local existingCommitments = self.manager.loanService ~= nil and (self.manager.loanService:getMonthlyDebtService(farmId) or 0) or 0
        existingCommitments = existingCommitments + (self.manager.repository:getMonthlyTenancyRent(farmId) or 0)
        local targetIncome = math.max(25000, existingCommitments * 2.5)
        RFF_CreditProfile:setTestOverride(farmId, true, targetIncome)
        print(string.format("[RealisticFarmFinance] TEST MODE: proactive-offer check is temporarily using %.2f/month underwriting income. Persisted finance history is unchanged.", targetIncome))
    end

    local offer, reason, diagnostics = self.manager.lenderMarketService:evaluateFarm(farmId, true)

    if useTestCredit and RFF_CreditProfile ~= nil then
        if previousOverride ~= nil then
            RFF_CreditProfile:setTestOverride(farmId, true, previousOverride.monthlyIncome or 0)
        else
            RFF_CreditProfile:setTestOverride(farmId, false)
        end
    end

    if offer ~= nil then
        print(string.format("[RealisticFarmFinance] Forced proactive-offer check created offer #%d from %s for %.2f at %.2f%%", offer.id or 0, tostring(offer.lenderId), offer.amount or 0, offer.interestRate or 0))
    else
        print(string.format("[RealisticFarmFinance] Forced proactive-offer check produced no offer: %s", tostring(reason)))
        if diagnostics ~= nil then
            local valuation = diagnostics.valuation or {}
            local credit = diagnostics.credit or {}
            local effectiveCredit = diagnostics.effectiveCredit or credit
            local evaluation = diagnostics.evaluation or {}
            local tried = diagnostics.triedAmounts or {}
            local triedParts = {}
            for _, amount in ipairs(tried) do table.insert(triedParts, tostring(amount)) end
            local triedText = #triedParts > 0 and table.concat(triedParts, ",") or "none"
            print(string.format("[RealisticFarmFinance]   underwriting reason=%s income=%.2f effectiveIncome=%.2f collateral=%.2f effectiveCollateral=%.2f liabilities=%.2f netWorth=%.2f trackedPeriods=%d",
                tostring(evaluation.reason or "unknown"), credit.monthlyIncome or 0, effectiveCredit.monthlyIncome or 0, credit.collateral or 0, effectiveCredit.collateral or 0,
                valuation.liabilities or 0, valuation.netWorth or 0, credit.trackedPeriods or 0))
            print(string.format("[RealisticFarmFinance]   candidate amounts tried=%s lastLTV=%s lastDSCR=%s", triedText,
                evaluation.ltv ~= nil and string.format("%.3f", evaluation.ltv) or "n/a", evaluation.dscr ~= nil and string.format("%.3f", evaluation.dscr) or "n/a"))
        end
        if not useTestCredit and string.sub(tostring(reason or ""), 1, 13) == "underwriting:" then
            print("[RealisticFarmFinance] For feature testing only, use 'rffMarketNow test' to repeat the check with a temporary healthy-income profile. Natural collateral/payment-conduct rules still apply.")
        end
    end
end

function RFF_RealisticFarmFinance:consoleRefinance(value)
    if self.manager == nil or self.manager.refinanceService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local service = self.manager.refinanceService
    local text = string.lower(tostring(value or "all"))
    local quote, reason, diagnostics

    if text == "all" or text == "" then
        quote, reason, diagnostics = service:getBestConsolidationQuote(farmId)
    else
        local loanId = tonumber(value)
        local target = nil
        for _, loan in ipairs(self.manager.repository:getLoansByFarm(farmId, true)) do
            if loanId ~= nil and (loan.id or 0) == loanId then target = loan; break end
        end
        if target == nil then
            print(string.format("[RealisticFarmFinance] Refinance quote failed: loan '%s' was not found or is not active", tostring(value)))
            return
        end
        quote, reason, diagnostics = service:getBestRefinanceQuote(farmId, target)
    end

    if quote == nil then
        print(string.format("[RealisticFarmFinance] Refinance quote unavailable: %s", tostring(reason)))
        if diagnostics ~= nil and diagnostics.declines ~= nil then
            for lenderId, declineReason in pairs(diagnostics.declines) do
                print(string.format("[RealisticFarmFinance]   lender=%s decline=%s", tostring(lenderId), tostring(declineReason)))
            end
        end
        return
    end

    print(string.format("[RealisticFarmFinance] refinance mode=%s sources=%d settlement=%.2f existingMonthly=%.2f existingProjectedInterest=%.2f term=%d bestLender=%s appetite=%s fit=%s tier=%s rate=%.2f payment=%.2f fee=%.2f monthlyDifference=%+.2f projectedInterestDifference=%+.2f",
        tostring(quote.mode), quote.targetLoanCount or 0, quote.amount or 0, quote.existingDebtService or 0, quote.existingProjectedInterest or 0,
        quote.termMonths or 0, tostring(quote.lenderId), tostring(quote.marketState), tostring(quote.dealFit or "STANDARD"), tostring(quote.relationshipTier), quote.interestRate or 0,
        quote.monthlyPayment or 0, quote.arrangementFee or 0, quote.monthlyDifference or 0, quote.projectedInterestDifference or 0))
    for index, offer in ipairs(quote.allQuotes or {}) do
        print(string.format("[RealisticFarmFinance]   quote=%d lender=%s appetite=%s fit=%s tier=%s rate=%.2f payment=%.2f fee=%.2f totalFinanceCost=%.2f dscr=%.3f",
            index, tostring(offer.lenderId), tostring(offer.marketState), tostring(offer.dealFit or "STANDARD"), tostring(offer.relationshipTier), offer.interestRate or 0, offer.monthlyPayment or 0,
            offer.arrangementFee or 0, offer.totalFinanceCost or 0, offer.dscr or 0))
    end
end

function RFF_RealisticFarmFinance:consoleConduct()
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local record = self.manager.repository:getRepaymentRecord(farmId)
    local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(self.manager.repository, farmId) or nil
    print(string.format("[RealisticFarmFinance] conduct farm=%d status=%s arrears=%.2f agreementsInArrears=%d missed=%d consecutive=%d maxConsecutive=%d lastMissedPeriod=%d rateAdjustment=%.2f declineNewCredit=%s",
        farmId, conduct ~= nil and tostring(conduct.code) or "UNKNOWN", record.currentArrears or 0, record.agreementsInArrears or 0,
        record.missedPayments or 0, record.consecutiveMissedPayments or 0, record.maxConsecutiveMissedPayments or 0,
        record.lastMissedPeriod or 0, conduct ~= nil and (conduct.rateAdjustment or 0) or 0, tostring(conduct ~= nil and conduct.declineNewCredit == true)))
end


function RFF_RealisticFarmFinance:consoleTestCreditReset(value)
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil or RFF_CreditProfile == nil then return end
    local farmId = g_currentMission:getFarmId()
    local text = value ~= nil and tostring(value) or ""
    local lower = string.lower(text)
    if lower == "off" or lower == "clear" or lower == "disable" then
        RFF_CreditProfile:setTestOverride(farmId, false)
        print(string.format("[RealisticFarmFinance] TEST CREDIT override disabled for farm %d. Natural DSCR/payment conduct are active again.", farmId))
        return
    end

    local existingCommitments = 0
    if self.manager.loanService ~= nil then
        existingCommitments = self.manager.loanService:getMonthlyDebtService(farmId) or 0
    end
    existingCommitments = existingCommitments + (self.manager.repository:getMonthlyTenancyRent(farmId) or 0)
    local requestedIncome = tonumber(value)
    local targetIncome = requestedIncome ~= nil and math.max(1000, requestedIncome) or math.max(25000, existingCommitments * 2.0)
    RFF_CreditProfile:setTestOverride(farmId, true, targetIncome)

    local valuation = RFF_FarmValuation:calculate(farmId, self.manager.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.manager.repository)
    print(string.format("[RealisticFarmFinance] TEST CREDIT override enabled for farm %d: Established / Excellent conduct, underwriting income %.2f per month. Existing liabilities/collateral are NOT changed.", farmId, credit.monthlyIncome or targetIncome))
    print("[RealisticFarmFinance] This override is session-only and is not saved. Use 'rffTestCreditReset off' to restore the natural profile immediately.")
end

function RFF_RealisticFarmFinance:consolePhoneTest()
    if g_currentMission == nil or RFF_NotificationService == nil then
        print("[RealisticFarmFinance] Phone integration service is unavailable")
        return
    end
    local phone = RFF_NotificationService:getPhone()
    if phone == nil then
        print("[RealisticFarmFinance] Derwen Mobile Phone is not detected")
        return
    end
    local farmId = g_currentMission:getFarmId()
    RFF_NotificationService:pushPhone(farmId, RFF_NotificationService:getText("rff_lender_primary_bank", "Primary Farm Bank"), RFF_NotificationService:getText("rff_phone_title_application", "Application Update"), "RFF phone integration is working correctly.", "test")
    print("[RealisticFarmFinance] RFF phone integration test message sent")
end

function RFF_RealisticFarmFinance:consoleBank()
    if self.manager == nil or self.manager.bankingService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local position = self.manager.bankingService:getAccountPosition(farmId)
    print(string.format("[RealisticFarmFinance] bank farm=%d balance=%.2f creditRate=%.2f overdraftLimit=%.2f used=%.2f available=%.2f overLimit=%.2f suspended=%s lastCredit=%.2f",
        farmId, position.balance or 0, self.manager.bankingService:getCreditInterestRate(), position.limit or 0,
        position.used or 0, position.available or 0, position.overLimit or 0, tostring(position.suspended), self.manager.bankingService:getLastInterestCredit(farmId)))
end

function RFF_RealisticFarmFinance:consoleDefaults()
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    for _, loan in ipairs(self.manager.repository:getLoansByFarm(farmId, false)) do
        if (loan.arrearsBalance or 0) > 0.01 or (loan.defaultEvents or 0) > 0 or loan.currentDefault == true or loan.recoveryLiability == true then
            print(string.format("[RealisticFarmFinance] default loan=%d type=%s stage=%s age=%d balance=%.2f arrears=%.2f defaultInterest=%.2f admin=%.2f recoveryEligible=%s recoveryLiability=%s sourceAsset=%d events=%d",
                loan.id or 0, tostring(loan.type), tostring(loan.arrearsStage or "CURRENT"), loan.arrearsAgeMonths or 0,
                self.manager.loanService:getLoanOutstanding(loan), loan.arrearsBalance or 0, loan.defaultInterestAccrued or 0, loan.adminChargesAccrued or 0,
                tostring(loan.recoveryEligible == true), tostring(loan.recoveryLiability == true), loan.sourceAssetAgreementId or 0, loan.defaultEvents or 0))
        end
    end
    for _, agreement in ipairs(self.manager.repository:getAssetFinanceByFarm(farmId, false)) do
        if (agreement.arrearsBalance or 0) > 0.01 or (agreement.defaultEvents or 0) > 0 then
            print(string.format("[RealisticFarmFinance] default asset=%d product=%s vehicle=%s stage=%s age=%d arrears=%.2f defaultInterest=%.2f admin=%.2f recoveryEligible=%s events=%d",
                agreement.id or 0, tostring(agreement.product), tostring(agreement.vehicleName), tostring(agreement.arrearsStage or "CURRENT"), agreement.arrearsAgeMonths or 0,
                agreement.arrearsBalance or 0, agreement.defaultInterestAccrued or 0, agreement.adminChargesAccrued or 0, tostring(agreement.recoveryEligible == true), agreement.defaultEvents or 0))
        end
    end
end

function RFF_RealisticFarmFinance:consoleADSAssessment()
    if g_currentMission == nil then return end
    local vehicle = RFF_ADSIntegration ~= nil and RFF_ADSIntegration:getLocalControlledVehicle() or nil
    if vehicle == nil then
        print("[RealisticFarmFinance] ADS assessment: enter/control a vehicle first")
        return
    end
    local name = vehicle.getFullName ~= nil and vehicle:getFullName() or vehicle.getName ~= nil and vehicle:getName() or "vehicle"
    local assessment = RFF_ADSIntegration ~= nil and RFF_ADSIntegration:getTechnicalAssessment(vehicle) or nil
    if assessment == nil or assessment.adsApplied ~= true then
        local vanillaRepair = 0
        if vehicle.getRepairPrice ~= nil then
            local ok, value = pcall(vehicle.getRepairPrice, vehicle)
            if ok then vanillaRepair = tonumber(value) or 0 end
        end
        print(string.format("[RealisticFarmFinance] ADS assessment vehicle=%s detected=NONE vanillaRepair=%.2f", tostring(name), vanillaRepair))
        return
    end
    local breakdownText = "none"
    if type(assessment.breakdownIds) == "table" and #assessment.breakdownIds > 0 then
        breakdownText = table.concat(assessment.breakdownIds, ",")
    end
    print(string.format("[RealisticFarmFinance] ADS assessment vehicle=%s detected=ADS condition=%.3f service=%.3f activeBreakdowns=%d breakdowns=%s overdueMaintenancePenalty=%.2f dealerRepair=%.2f technicalPenalty=%.2f",
        tostring(name), assessment.conditionLevel or 0, assessment.serviceLevel or 0, assessment.breakdownCount or 0, tostring(breakdownText),
        assessment.maintenancePenalty or 0, assessment.repairCost or 0, assessment.technicalPenalty or 0))
end

function RFF_RealisticFarmFinance:consoleAssets()
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local agreements = self.manager.repository:getAssetFinanceByFarm(farmId, false)
    print(string.format("[RealisticFarmFinance] assetFinance farm=%d agreements=%d", farmId, #agreements))
    for _, agreement in ipairs(agreements) do
        print(string.format("[RealisticFarmFinance] asset=%d product=%s lender=%s vehicle=%s status=%s price=%.2f principal=%.2f payment=%.2f balloon=%.2f months=%d missed=%d arrears=%.2f consecutive=%d recoveryMethod=%s market=%.2f realised=%.2f costs=%.2f shortfall=%.2f liabilityLoan=%d",
            agreement.id or 0, tostring(agreement.product), tostring(agreement.lenderId or "UNASSIGNED"), tostring(agreement.vehicleName), tostring(agreement.status), agreement.basePrice or 0,
            agreement.principal or 0, agreement.monthlyPayment or 0, agreement.balloonAmount or 0, agreement.remainingMonths or 0, agreement.missedPayments or 0,
            agreement.arrearsBalance or 0, agreement.consecutiveMissedPayments or 0, tostring(agreement.recoveryMethod or ""), agreement.recoveryMarketValue or 0,
            agreement.recoveryRealisedValue or 0, agreement.recoveryCosts or 0, agreement.recoveryShortfall or 0, agreement.recoveryLiabilityLoanId or 0))
    end
end

local function loadRepository()
    local manager = RFF_RealisticFarmFinance.manager
    if manager ~= nil and manager.repository ~= nil then
        manager.repository:loadFromXMLFile()
        if manager.economy ~= nil then manager.economy:advance() end
        if manager.cropAdvances ~= nil then manager.cropAdvances:install(); manager.cropAdvances:processDue() end
        if manager.relationshipService ~= nil and manager.relationshipService.migrateExistingHistory ~= nil then manager.relationshipService:migrateExistingHistory() end
        if manager.loanService ~= nil and manager.loanService.migrateLegacyArrears ~= nil then manager.loanService:migrateLegacyArrears() end
        if manager.assetFinance ~= nil and manager.assetFinance.migrateLegacyArrears ~= nil then manager.assetFinance:migrateLegacyArrears() end
        if manager.bankingService ~= nil and g_currentMission ~= nil then
            local farmId = g_currentMission:getFarmId()
            if farmId ~= nil and farmId > 0 then manager.bankingService:syncOverdraft(farmId) end
        end
        if manager.applicationService ~= nil then
            manager.applicationService:onDayChanged()
        end
        if manager.brokerService ~= nil then
            manager.brokerService:onDayChanged()
        end
        if manager.lenderMarketService ~= nil and manager.lenderMarketService.onLoaded ~= nil then
            manager.lenderMarketService:onLoaded()
        end
        if manager.businessAdministration ~= nil and manager.businessAdministration.onLoaded ~= nil then
            manager.businessAdministration:onLoaded()
        end
        if manager.fleetManagement ~= nil and manager.fleetManagement.onLoaded ~= nil then
            manager.fleetManagement:onLoaded()
        end
        if manager.insuranceClaims ~= nil and manager.insuranceClaims.onLoaded ~= nil then
            manager.insuranceClaims:onLoaded()
        end
        if manager.taxCompliance ~= nil and manager.taxCompliance.onLoaded ~= nil then
            manager.taxCompliance:onLoaded()
        end
        if manager.propertyFinance ~= nil and manager.propertyFinance.onLoaded ~= nil then
            manager.propertyFinance:onLoaded()
        end
        if RFF_NotificationService ~= nil and RFF_NotificationService.registerLenderMarketActionHandlers ~= nil and manager.lenderMarketService ~= nil then
            RFF_NotificationService:registerLenderMarketActionHandlers(manager.lenderMarketService)
        end
        if RFF_NotificationService ~= nil and RFF_NotificationService.registerForbearanceActionHandlers ~= nil and manager.forbearanceService ~= nil then
            RFF_NotificationService:registerForbearanceActionHandlers(manager.forbearanceService)
        end
    end
end

local function saveRepository()
    local manager = RFF_RealisticFarmFinance.manager
    if manager ~= nil and manager.repository ~= nil then
        manager.repository:saveToXMLFile()
    end
end

-- Vanilla farm loans are not reliably available at loadItemsFinished. Convert them
-- after the mission has fully started, matching the proven Enhanced Loan System
-- lifecycle. Iterate every real farm so an established save is not dependent on
-- whichever farm happens to be the local player's current farm at load time.
local function migrateVanillaLoansOnStartMission()
    local manager = RFF_RealisticFarmFinance.manager
    if manager == nil or manager.loanService == nil or manager.loanService.migrateVanillaLoan == nil then return end
    if g_currentMission == nil or not g_currentMission:getIsServer() or g_farmManager == nil then return end

    local farms = g_farmManager:getFarms() or {}
    for _, farm in pairs(farms) do
        local farmId = farm ~= nil and tonumber(farm.farmId) or 0
        if farmId ~= nil and farmId > 0 then
            local imported, result = manager.loanService:migrateVanillaLoan(farmId)
            if not imported and result ~= "already_migrated" and result ~= "no_vanilla_loan" then
                print(string.format("[RealisticFarmFinance] Legacy loan migration skipped farm=%d reason=%s", farmId, tostring(result)))
            end
        end
    end

    if manager.legacyFinanceMigration ~= nil and manager.legacyFinanceMigration.migrateInactiveLegacyMods ~= nil then
        manager.legacyFinanceMigration:migrateInactiveLegacyMods()
    end

    if RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService.normalizeLegacyOwnership ~= nil then
        local converted = RFF_TenancyAccessService:normalizeLegacyOwnership()
        if converted > 0 then
            print(string.format("[RealisticFarmFinance] Tenancy POC normalized %d legacy tenancy ownership record(s)", converted))
        end
    end

    -- Legacy land normalisation can make GIANTS recalculate every linked
    -- placeable owner. Re-apply the active tenancy's operational fixture
    -- possession after that authoritative farmland pass has completed.
    if RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService.synchronizeTenancyFixturePossession ~= nil then
        RFF_TenancyAccessService:synchronizeTenancyFixturePossession()
    end

end

Mission00.loadItemsFinished = Utils.appendedFunction(Mission00.loadItemsFinished, loadRepository)
Mission00.onStartMission = Utils.appendedFunction(Mission00.onStartMission, migrateVanillaLoansOnStartMission)
FSCareerMissionInfo.saveToXMLFile = Utils.appendedFunction(FSCareerMissionInfo.saveToXMLFile, saveRepository)

function RFF_RealisticFarmFinance:consoleTenancyRestrictive(value)
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil or g_currentMission == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then return "Server only" end
    local farmId = g_currentMission:getFarmId()
    local farmlandId = math.floor(tonumber(value) or 0)
    local tenancy = nil
    if farmlandId > 0 then
        tenancy = self.manager.propertyFinance:getActiveTenancyForFarmland(farmlandId, farmId)
    else
        local possession = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true}
        for index = #(self.manager.repository.tenancies or {}), 1, -1 do
            local candidate = self.manager.repository.tenancies[index]
            if candidate ~= nil and tonumber(candidate.farmId) == tonumber(farmId) and possession[candidate.status or ""] then
                tenancy = candidate
                break
            end
        end
    end
    if tenancy == nil then return "No active tenancy found" end
    local ok, reason = self.manager.propertyFinance:setRestrictiveTestCovenants(tenancy)
    if not ok then
        if reason == "no_grass" then
            return string.format("Cannot apply permanent-grass test covenant to %s: its commencement survey records no grass parcel", tenancy.agreementId or "tenancy")
        end
        return "Unable to apply restrictive tenancy covenants: " .. tostring(reason or "unknown")
    end
    if self.guiFrame ~= nil and self.guiFrame.updatePropertyContent ~= nil then self.guiFrame:updatePropertyContent() end
    return string.format("Restrictive covenants applied to %s: livestock use, permanent grass retained, boundary consent and improvement consent required",
        tenancy.agreementId or "tenancy")
end

function RFF_RealisticFarmFinance:consoleTenancyInspectNow(value)
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil or g_currentMission == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then return "Server only" end
    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end
    local farmlandId = math.floor(tonumber(value) or 0)
    local tenancy = farmlandId > 0 and self.manager.propertyFinance:getActiveTenancyForFarmland(farmlandId, farmId) or nil
    if tenancy == nil and farmlandId <= 0 then
        local possession = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true}
        for index = #(self.manager.repository.tenancies or {}), 1, -1 do
            local candidate = self.manager.repository.tenancies[index]
            if candidate ~= nil and tonumber(candidate.farmId) == tonumber(farmId) and possession[candidate.status or ""] then
                tenancy = candidate
                break
            end
        end
    end
    if tenancy == nil then return "No active tenancy found" end
    local report, reason = self.manager.propertyFinance:performTenancyInspection(tenancy, "TEST")
    if report == nil then return "Unable to complete tenancy inspection: " .. tostring(reason or "unknown") end
    if self.guiFrame ~= nil and self.guiFrame.updatePropertyContent ~= nil then self.guiFrame:updatePropertyContent() end
    return string.format("Inspection %s completed for %s: %s (%d breach(es), %d authorised)",
        report.reference or "-", tenancy.agreementId or tenancy.id, report.status or "CLEAR",
        report.breachCount or 0, report.authorisedCount or 0)
end

function RFF_RealisticFarmFinance:consoleTenancyRemedyNow(value)
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil or g_currentMission == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then return "Server only" end
    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end
    local farmlandId = math.floor(tonumber(value) or 0)
    local tenancy = farmlandId > 0 and self.manager.propertyFinance:getActiveTenancyForFarmland(farmlandId, farmId) or nil
    if tenancy == nil and farmlandId <= 0 then
        local possession = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true}
        for index = #(self.manager.repository.tenancies or {}), 1, -1 do
            local candidate = self.manager.repository.tenancies[index]
            if candidate ~= nil and tonumber(candidate.farmId) == tonumber(farmId) and possession[candidate.status or ""] then
                tenancy = candidate
                break
            end
        end
    end
    if tenancy == nil then return "No active tenancy found" end
    local breachCase = self.manager.propertyFinance:getOpenTenancyBreachCase(tenancy)
    if breachCase == nil then return string.format("No open covenant remedy case exists for %s", tenancy.agreementId or tenancy.id) end
    local report, reason = self.manager.propertyFinance:performTenancyInspection(tenancy, "REMEDY_REVIEW")
    if report == nil then return "Unable to complete remedy review: " .. tostring(reason or "unknown") end
    breachCase = self.manager.propertyFinance:getLatestTenancyBreachCase(tenancy)
    if self.guiFrame ~= nil and self.guiFrame.updatePropertyContent ~= nil then self.guiFrame:updatePropertyContent() end
    return string.format("Remedy review %s completed for case %s: %s, %d unresolved breach(es), costs outstanding %s",
        report.reference or "-", breachCase ~= nil and breachCase.reference or "-",
        breachCase ~= nil and tostring(breachCase.status or "UPDATED"):gsub("_", " ") or "UPDATED",
        breachCase ~= nil and breachCase.unresolvedCount or 0,
        g_i18n:formatMoney(breachCase ~= nil and breachCase.feeOutstanding or 0, 0, true, true))
end

function RFF_RealisticFarmFinance:consoleTenancyHandbackNow(value, modeValue)
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil or g_currentMission == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then return "Server only" end
    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end
    local farmlandId = math.floor(tonumber(value) or 0)
    local tenancy = farmlandId > 0 and self.manager.propertyFinance:getActiveTenancyForFarmland(farmlandId, farmId) or nil
    if tenancy == nil and farmlandId <= 0 then
        local possession = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true}
        for index = #(self.manager.repository.tenancies or {}), 1, -1 do
            local candidate = self.manager.repository.tenancies[index]
            if candidate ~= nil and tonumber(candidate.farmId) == tonumber(farmId) and possession[candidate.status or ""] then
                tenancy = candidate
                break
            end
        end
    end
    if tenancy == nil then return "No active tenancy found" end
    if tenancy.renewalOfferStatus == "ACCEPTED" and (tenancy.successorAgreementId or 0) > 0 then
        return string.format("%s has an executed successor tenancy, so no handback is due", tenancy.agreementId or tenancy.id)
    end
    local mode = tostring(modeValue or ""):upper()
    if mode == "END" or mode == "FINAL" then
        local ok = self.manager.propertyFinance:releaseTenancy(tenancy, true, "ENDED")
        if self.guiFrame ~= nil and self.guiFrame.updatePropertyContent ~= nil then self.guiFrame:updatePropertyContent() end
        if not ok then return "Unable to complete final tenancy handback" end
        return string.format("Final handback completed for %s: dilapidations %s, deposit applied %s, deposit returned %s, balance %s",
            tenancy.agreementId or tenancy.id,
            g_i18n:formatMoney(tenancy.settlementDilapidationCosts or 0, 0, true, true),
            g_i18n:formatMoney(tenancy.settlementDepositApplied or 0, 0, true, true),
            g_i18n:formatMoney(tenancy.settlementDepositReturned or 0, 0, true, true),
            g_i18n:formatMoney(tenancy.settlementFinalBalance or 0, 0, true, true))
    end
    self.manager.propertyFinance:ensureTenancyHandbackState(tenancy)
    local trigger = tenancy.handbackStatus == "NONE" and "TEST" or "REINSPECTION"
    local assessment, reason = self.manager.propertyFinance:performTenancyHandbackInspection(tenancy, trigger)
    if assessment == nil then return "Unable to complete handback inspection: " .. tostring(reason or "unknown") end
    if self.guiFrame ~= nil and self.guiFrame.updatePropertyContent ~= nil then self.guiFrame:updatePropertyContent() end
    return string.format("Handback %s for %s: %s, %d outstanding item(s), estimated exposure %s, remedy date %s",
        assessment.reference or "-", tenancy.agreementId or tenancy.id,
        tostring(assessment.status or "UPDATED"):gsub("_", " "), assessment.itemCount or 0,
        g_i18n:formatMoney(assessment.totalCost or 0, 0, true, true),
        self.manager.propertyFinance:formatTenancyPeriod(tenancy.handbackRemedyDeadlinePeriod or 0))
end

function RFF_RealisticFarmFinance:consoleTenancyApplicationNow(value)
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil or g_currentMission == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then return "Server only" end
    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end
    local farmlandId = math.floor(tonumber(value) or 0)
    local tenancy = farmlandId > 0 and self.manager.propertyFinance:getOpenTenancyApplicationForFarmland(farmlandId, farmId) or nil
    if tenancy == nil then
        for index = #(self.manager.repository.tenancies or {}), 1, -1 do
            local candidate = self.manager.repository.tenancies[index]
            if candidate ~= nil and tonumber(candidate.farmId) == tonumber(farmId)
                and self.manager.propertyFinance:getOpenTenancyApplicationForFarmland(candidate.farmlandId, farmId) == candidate then
                tenancy = candidate
                break
            end
        end
    end
    if tenancy == nil then return "No open initial tenancy application found" end
    if tenancy.applicationStage == "HEADS_OFFERED" then return "Heads of terms are already available; accept, negotiate or withdraw from the Tenancy Agreements screen" end
    local currentDay = self.manager.propertyFinance:getCurrentDay()
    tenancy.applicationNextActionDay = currentDay
    local progressed, reason = self.manager.propertyFinance:processInitialTenancyApplicationDay(tenancy, currentDay)
    if not progressed then return "Unable to advance tenancy application: " .. tostring(reason or tenancy.applicationStage or "unavailable") end
    if self.guiFrame ~= nil and self.guiFrame.updatePropertyContent ~= nil then self.guiFrame:updatePropertyContent() end
    return string.format("Application %s advanced to %s", tenancy.applicationReference or tenancy.agreementId or "-",
        tostring(tenancy.applicationStage or tenancy.status or "updated"):gsub("_", " "))
end

function RFF_RealisticFarmFinance:consoleTenancyGrant(value, termValue, frequencyValue, breakAtValue, breakNoticeValue, reviewValue)
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil or g_farmlandManager == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then
        return "Server only"
    end

    local farmlandIds = {}
    for token in string.gmatch(tostring(value or ""), "[^,]+") do
        local farmlandId = tonumber(token)
        if farmlandId == nil or not g_farmlandManager:getIsValidFarmlandId(farmlandId) then
            return "Usage: rffTenancyGrant <farmlandIds> [term] [frequency] [breakAtMonth] [breakNotice] [rentReviewInterval]"
        end
        table.insert(farmlandIds, math.floor(farmlandId))
    end
    if #farmlandIds == 0 then return "No farmland IDs supplied" end

    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end

    for _, farmlandId in ipairs(farmlandIds) do
        if g_farmlandManager:getFarmlandOwner(farmlandId) == farmId then return string.format("Farmland %d is already legally owned by farm %d", farmlandId, farmId) end
    end
    local termMonths = math.max(1, math.floor(tonumber(termValue) or 60))
    local frequency = string.upper(tostring(frequencyValue or "MONTHLY"))
    local breakAt = math.max(0, math.floor(tonumber(breakAtValue) or 0))
    local breakNotice = math.max(0, math.floor(tonumber(breakNoticeValue) or 0))
    local current = self.manager.repository:getCurrentPeriodIndex()
    local terms = {termMonths=termMonths, paymentFrequency=frequency, holdingName="Test Holding"}
    if breakAt > 0 then
        terms.breakEnabled = true
        terms.earliestBreakPeriod = current + breakAt
        terms.breakNoticeMonths = math.max(1, breakNotice)
    end
    if reviewValue ~= nil and tostring(reviewValue) ~= "" then terms.rentReviewIntervalMonths = math.max(0, math.floor(tonumber(reviewValue) or 0)) end
    local tenancy, reason = self.manager.propertyFinance:createTenancyAgreement(farmId, farmlandIds, terms)
    if tenancy == nil then return "Unable to create tenancy contract: " .. tostring(reason) end
    return string.format("Created tenancy %s for %d parcel(s), %d months, %s rent", tenancy.agreementId or tenancy.id, #farmlandIds, termMonths, tenancy.paymentFrequency)
end

function RFF_RealisticFarmFinance:consoleTenancyRevoke(value)
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil or g_farmlandManager == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then return "Server only" end

    local farmlandId = tonumber(value)
    if farmlandId == nil then return "Usage: rffTenancyRevoke <farmlandId>" end
    farmlandId = math.floor(farmlandId)
    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end

    local tenancy = self.manager.repository:getTenancyByFarmland(farmlandId, true)
    if tenancy == nil or tenancy.farmId ~= farmId then
        return string.format("No active RFF tenancy for farm %d on farmland %d", farmId, farmlandId)
    end

    local ok = false
    if self.manager.propertyFinance ~= nil and self.manager.propertyFinance.releaseTenancy ~= nil then
        ok = self.manager.propertyFinance:releaseTenancy(tenancy, true, "ENDED")
    else
        tenancy.status = "ENDED"
        tenancy.remainingMonths = 0
        ok = true
    end

    local ownerFarmId = g_farmlandManager:getFarmlandOwner(farmlandId)
    print(string.format("[RealisticFarmFinance] Tenancy POC REVOKE tenancy=%d farm=%d land=%d GIANTS owner=%d result=%s",
        tenancy.id or 0, farmId, farmlandId, ownerFarmId or 0, tostring(ok)))
    return ok and string.format("Revoked RFF tenancy access to farmland %d", farmlandId) or "Unable to revoke tenancy"
end

function RFF_RealisticFarmFinance:consoleTenancyLandlordChangeNow(value)
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil or g_currentMission == nil then
        return "RFF tenancy engine unavailable"
    end
    if not g_currentMission:getIsServer() then return "Server only" end
    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end
    local farmlandId = tonumber(value)
    local tenancy = nil
    if farmlandId ~= nil then
        tenancy = self.manager.repository:getTenancyByFarmland(math.floor(farmlandId), true)
    else
        for _, candidate in ipairs(self.manager.repository:getTenanciesByFarm(farmId, true) or {}) do
            if tenancy == nil or (candidate.id or 0) > (tenancy.id or 0) then tenancy = candidate end
        end
    end
    if tenancy == nil or tenancy.farmId ~= farmId then return "No current tenancy found for this farm" end
    local ok, reason, request = self.manager.propertyFinance:createLandlordVariationProposal(tenancy, true)
    if not ok then return "Unable to serve landlord variation notice: " .. tostring(reason) end
    local effectiveDate = self.manager.propertyFinance:formatTenancyPeriod(
        request ~= nil and (request.effectivePeriod or 0) or 0)
    return string.format("Formal landlord notice %s served for %s. The farm legal adviser will respond next day; the change takes effect in %s after the agreed notice.",
        tostring(request ~= nil and request.reference or "-"), tostring(tenancy.agreementId or tenancy.id),
        effectiveDate)
end

function RFF_RealisticFarmFinance:consoleTenancyStatus()
    if self.manager == nil or self.manager.repository == nil or g_currentMission == nil or g_farmlandManager == nil then return end
    local farmId = g_currentMission:getFarmId()
    local tenancies = self.manager.repository:getTenanciesByFarm(farmId, false)
    print(string.format("[RealisticFarmFinance] tenancy contracts farm=%d total=%d", farmId or 0, #tenancies))
    for _, tenancy in ipairs(tenancies) do
        local farmlandId = tenancy.farmlandId or 0
        local ownerFarmId = g_farmlandManager:getFarmlandOwner(farmlandId)
        local access = RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService:hasAgriculturalAccess(farmId, farmlandId) or false
        local landlordBrief = self.manager.propertyFinance ~= nil and self.manager.propertyFinance:getTenancyLandlordBrief(tenancy) or nil
        print(string.format("[RealisticFarmFinance] agreement=%s land=%d parcels=%d landlord=%s landlordRelationship=%s relationshipPoints=%.2f tenantFarm=%d GIANTSowner=%d status=%s access=%s annualRent=%.2f frequency=%s due=%.2f arrears=%.2f depositHeld=%.2f monthsRemaining=%d renewal=%s negotiation=%s round=%d nextDay=%d document=%s legalRef=%s successor=%d noticeEnd=%d landlordChangeNoticeMonths=%d landlordChangeCooldownMonths=%d",
            tostring(tenancy.agreementId or tenancy.id), farmlandId, #(tenancy.farmlandIds or {farmlandId}), tostring(tenancy.landlord or "PRIVATE_LANDOWNER"),
            landlordBrief ~= nil and landlordBrief.relationshipCode or "PROFESSIONAL", landlordBrief ~= nil and landlordBrief.relationshipPoints or 0,
            tenancy.farmId or 0, ownerFarmId or 0, tostring(tenancy.status), tostring(access), tenancy.annualRent or ((tenancy.monthlyRent or 0)*12), tostring(tenancy.paymentFrequency or "MONTHLY"), tenancy.rentDue or 0, tenancy.arrears or 0, tenancy.depositHeld or tenancy.securityDeposit or 0, tenancy.remainingMonths or 0, tostring(tenancy.renewalOfferStatus or "NONE"), tostring(tenancy.renewalNegotiationStatus or "NOT_STARTED"), tenancy.renewalNegotiationAttempts or 0, tenancy.renewalNegotiationNextDay or 0, tostring(tenancy.renewalDocumentStatus or "NONE"), tostring(tenancy.renewalLegalReference or ""), tenancy.successorAgreementId or 0, tenancy.noticeEffectivePeriod or 0, tenancy.landlordVariationNoticeMonths or 3, tenancy.landlordVariationCooldownMonths or 12))
        local latestConsent = self.manager.propertyFinance ~= nil and self.manager.propertyFinance:getLatestTenancyConsentRequest(tenancy) or nil
        if latestConsent ~= nil then
            print(string.format("[RealisticFarmFinance]   consent reference=%s initiator=%s type=%s target=%s status=%s submittedDay=%d reviewDay=%d decisionDay=%d nextDay=%d expiresPeriod=%d noticeServedPeriod=%d effectivePeriod=%d cooldownUntilPeriod=%d fee=%.2f paid=%.2f outstanding=%.2f payer=%s",
                tostring(latestConsent.reference or "-"), tostring(latestConsent.initiator or "TENANT"),
                tostring(latestConsent.requestType or "-"), tostring(latestConsent.target or "-"),
                tostring(latestConsent.status or "-"), latestConsent.submittedDay or 0,
                latestConsent.reviewDay or 0, latestConsent.decisionDay or 0, latestConsent.nextActionDay or 0,
                latestConsent.expiresPeriod or 0, latestConsent.noticeServedPeriod or 0,
                latestConsent.effectivePeriod or 0, latestConsent.cooldownUntilPeriod or 0,
                latestConsent.professionalFee or 0, latestConsent.feePaid or 0,
                latestConsent.feeOutstanding or 0, tostring(latestConsent.feePayer or latestConsent.initiator or "TENANT")))
        end
        local latestBreachCase = self.manager.propertyFinance ~= nil and self.manager.propertyFinance:getLatestTenancyBreachCase(tenancy) or nil
        if latestBreachCase ~= nil then
            print(string.format("[RealisticFarmFinance]   breachCase reference=%s status=%s approach=%s relationshipAtOpen=%s remedyMonths=%d remedyDeadline=%d nextReview=%d terminationEffective=%d breaches=%d unresolved=%d reviews=%d fee=%.2f paid=%.2f outstanding=%.2f latestInspection=%s",
                tostring(latestBreachCase.reference or "-"), tostring(latestBreachCase.status or "-"),
                tostring(latestBreachCase.landlordApproach or "-"), tostring(latestBreachCase.relationshipCodeAtOpen or "-"),
                latestBreachCase.remedyMonths or 0, latestBreachCase.remedyDeadlinePeriod or 0,
                latestBreachCase.nextReviewPeriod or 0, latestBreachCase.terminationEffectivePeriod or 0,
                latestBreachCase.breachCount or 0,
                latestBreachCase.unresolvedCount or 0, latestBreachCase.reviewCount or 0,
                latestBreachCase.professionalFee or 0, latestBreachCase.feePaid or 0,
                latestBreachCase.feeOutstanding or 0, tostring(latestBreachCase.latestInspectionReference or "-")))
        end
        if self.manager.propertyFinance ~= nil then
            self.manager.propertyFinance:ensureTenancyHandbackState(tenancy)
            if tenancy.handbackStatus ~= "NONE" then
                print(string.format("[RealisticFarmFinance]   handback reference=%s status=%s inspection=%d remedyDeadline=%d finalInspection=%d reviews=%d items=%d unresolved=%d estimate=%.2f professionalFee=%.2f finalCost=%.2f settlementApplied=%.2f",
                    tostring(tenancy.handbackReference or "-"), tostring(tenancy.handbackStatus or "NONE"),
                    tenancy.handbackInspectionPeriod or 0, tenancy.handbackRemedyDeadlinePeriod or 0,
                    tenancy.handbackFinalInspectionPeriod or 0, tenancy.handbackReviewCount or 0,
                    tenancy.handbackItemCount or 0, tenancy.handbackUnresolvedCount or 0,
                    tenancy.handbackEstimatedCost or 0, tenancy.handbackProfessionalFee or 0,
                    tenancy.handbackFinalCost or 0, tenancy.settlementDilapidationCostsApplied or 0))
                for _, item in ipairs(tenancy.handbackItems or {}) do
                    print(string.format("[RealisticFarmFinance]     handbackItem id=%d code=%s land=%d cost=%.2f status=%s description=%s remedy=%s",
                        item.id or 0, tostring(item.code or "-"), item.farmlandId or 0,
                        item.estimatedCost or 0, tostring(item.status or "OUTSTANDING"),
                        tostring(item.description or ""), tostring(item.remedy or "")))
                end
            end
        end
    end
end

function RFF_RealisticFarmFinance:consoleForbearance(value)
    if self.manager == nil or self.manager.forbearanceService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local targetId = tonumber(value)
    local found = false
    for _, loan in ipairs(self.manager.repository:getLoansByFarm(farmId, true)) do
        if targetId == nil or (loan.id or 0) == targetId then
                local arrears = loan.arrearsBalance or 0
                if arrears > 0.01 or (loan.forbearanceRemainingPeriods or 0) > 0 or (loan.forbearanceCount or 0) > 0 then
                    found = true
                    local plan, reason = self.manager.forbearanceService:buildPlan(loan)
                    print(string.format("[RealisticFarmFinance] paymentHelp loan=%d type=%s lender=%s stage=%s arrears=%.2f count=%d activeMode=%s remaining=%d plan=%s reason=%s",
                        loan.id or 0, tostring(loan.type), tostring(loan.lenderId), tostring(loan.arrearsStage or "CURRENT"), arrears, loan.forbearanceCount or 0,
                        tostring(loan.forbearanceMode or ""), loan.forbearanceRemainingPeriods or 0, plan ~= nil and tostring(plan.type) or "none", tostring(reason or "-")))
                    if plan ~= nil then
                        print(string.format("[RealisticFarmFinance]   plan relationship=%s capitalise=%.2f duration=%d extension=%d rate=%.2f payment=%.2f",
                            tostring(plan.relationshipCode), plan.capitalisedArrears or 0, plan.durationPeriods or 0, plan.extensionMonths or 0, plan.interestRate or 0, plan.monthlyPayment or 0))
                    end
                    local quote, rescueReason, declines = self.manager.forbearanceService:buildRescueQuote(loan)
                    if quote ~= nil then
                        print(string.format("[RealisticFarmFinance]   rescue lender=%s appetite=%s fit=%s tier=%s settlement=%.2f term=%d rate=%.2f payment=%.2f fee=%.2f dscr=%.3f ltv=%.3f",
                            tostring(quote.lenderId), tostring(quote.marketState), tostring(quote.dealFit), tostring(quote.relationshipTier), quote.settlement or 0, quote.termMonths or 0, quote.interestRate or 0, quote.monthlyPayment or 0, quote.arrangementFee or 0, quote.dscr or 0, quote.ltv or 0))
                    elseif rescueReason ~= "too_early" and rescueReason ~= "no_arrears" then
                        print(string.format("[RealisticFarmFinance]   rescue unavailable=%s", tostring(rescueReason)))
                        for lenderId, decline in pairs(declines or {}) do print(string.format("[RealisticFarmFinance]     lender=%s decline=%s", tostring(lenderId), tostring(decline))) end
                    end
                end
        end
    end
    if not found then print("[RealisticFarmFinance] No active borrowing currently has a payment-help state to report") end
end

function RFF_RealisticFarmFinance:consoleBusiness()
    if self.manager == nil or self.manager.businessAdministration == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local summary = self.manager.businessAdministration:getSummary(farmId)
    local state = summary.state or {}
    local tax = summary.tax or {}
    print(string.format("[RealisticFarmFinance] business farm=%d monthlyAdmin=%.2f adminArrears=%.2f adminPaid=%.2f filingEstimate=%.2f businessInsurance=%s nextCover=%s status=%s insurable=%.2f premiumEstimate=%.2f premiumDue=%.2f renewalIn=%d businessLiability=%.2f",
        farmId, summary.monthlyAdminCost or 0, summary.adminArrears or 0, state.adminTotalPaid or 0, summary.annualFilingEstimate or 0,
        tostring(summary.insuranceTier), tostring(summary.insuranceNextTier), tostring(summary.insuranceStatus), summary.insuranceInsurableValue or 0,
        summary.insurancePremiumEstimate or 0, summary.insurancePremiumDue or 0, summary.insuranceMonthsToRenewal or 0, summary.outstandingLiabilities or 0))
    local fleet = self.manager.fleetManagement ~= nil and self.manager.fleetManagement:getFleet(farmId) or {}
    print(string.format("[RealisticFarmFinance] vehicleInsurance policies=%d covered=%d uninsured=%d expired=%d outsidePolicy=%d",
        fleet.policyCount or 0, fleet.insuredCount or 0, fleet.uninsuredCount or 0, fleet.expiredCount or 0, fleet.leasedCount or 0))
    local counts = summary.counts or {}
    print(string.format("[RealisticFarmFinance] admin complexity land=%d managedFacilities=%d rawPlaceables=%d excludedPlaceables=%d vehicles=%d loans=%d tenancies=%d assetFinance=%d",
        counts.farmland or 0, counts.placeables or 0, counts.rawPlaceables or 0, counts.excludedPlaceables or 0, counts.vehicles or 0,
        counts.loans or 0, counts.tenancies or 0, counts.assetFinance or 0))
    print(string.format("[RealisticFarmFinance] tax source=%s available=%s enabled=%s rate=%.2f%% ytdIncome=%.2f ytdExpenses=%.2f ytdTaxEstimate=%.2f rollover=%.2f annualAssessmentExists=%s annualAssessment=%.2f redTapePaid=%s calculationMonth=%s paymentMonth=%s",
        tostring(tax.source), tostring(tax.available), tostring(tax.enabled), (tax.taxRate or 0) * 100, tax.currentTaxableIncome or 0, tax.currentExpenses or 0,
        tax.currentTax or 0, tax.lossRollover or 0, tostring(tax.lastAssessmentExists), tax.lastTax or 0, tostring(tax.lastPaid), tostring(tax.calculationMonth), tostring(tax.paymentMonth)))
    if self.manager.insuranceClaims ~= nil and self.manager.repository ~= nil then
        local losses = self.manager.repository.getInsuranceLossesByFarm ~= nil and self.manager.repository:getInsuranceLossesByFarm(farmId) or {}
        local claims = self.manager.repository:getInsuranceClaimsByFarm(farmId)
        local vetExpenses = self.manager.repository.getInsuranceVeterinaryExpensesByFarm ~= nil and self.manager.repository:getInsuranceVeterinaryExpensesByFarm(farmId) or {}
        local vetEligibleTotal, vetEligibleCount = self.manager.insuranceClaims:getEligibleVeterinaryExpenseTotal(farmId)
        local claimable, expired, open, paid, declined = 0, 0, 0, 0, 0
        for _, loss in ipairs(losses) do
            if loss.status == RFF_InsuranceClaimService.LOSS_CLAIMABLE then claimable = claimable + 1
            elseif loss.status == RFF_InsuranceClaimService.LOSS_EXPIRED then expired = expired + 1 end
        end
        for _, claim in ipairs(claims) do
            if claim.status == RFF_InsuranceClaimService.STATUS_PAID then paid = paid + 1
            elseif claim.status == RFF_InsuranceClaimService.STATUS_DECLINED then declined = declined + 1
            else open = open + 1 end
        end
        print(string.format("[RealisticFarmFinance] livestock deaths=%d eligible=%d expired=%d vetExpenses=%d vetEligible=%d vetEligibleTotal=%.2f claims=%d open=%d paid=%d declined=%d rlrHook=%s treatmentHook=%s safetyHook=%s", #losses, claimable, expired, #vetExpenses, vetEligibleCount, vetEligibleTotal, #claims, open, paid, declined, tostring(self.manager.insuranceClaims.rlrHookAvailable == true), tostring(self.manager.insuranceClaims.rlrTreatmentHookAvailable == true), tostring(self.manager.insuranceClaims.rlrSafetyHookAvailable == true)))
    end
end

function RFF_RealisticFarmFinance:consoleInsuranceNow()
    if self.manager == nil or self.manager.businessAdministration == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local ok, reason = self.manager.businessAdministration:forceInsuranceRenewalForTest(farmId)
    local summary = self.manager.businessAdministration:getSummary(farmId)
    print(string.format("[RealisticFarmFinance] forced insurance renewal farm=%d ok=%s reason=%s status=%s premiumDue=%.2f nextRenewalIn=%d",
        farmId, tostring(ok), tostring(reason), tostring(summary.insuranceStatus), summary.insurancePremiumDue or 0, summary.insuranceMonthsToRenewal or 0))
end

function RFF_RealisticFarmFinance:consoleVehicleInsurance()
    if self.manager == nil or self.manager.fleetManagement == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local fleet = self.manager.fleetManagement:getFleet(farmId)
    print(string.format("[RealisticFarmFinance] vehicle insurance farm=%d vehicles=%d policies=%d covered=%d uninsured=%d expired=%d outsidePolicy=%d",
        farmId, fleet.vehicleCount or 0, fleet.policyCount or 0, fleet.insuredCount or 0, fleet.uninsuredCount or 0, fleet.expiredCount or 0, fleet.outsidePolicyCount or 0))
    for _, row in ipairs(fleet.vehicles or {}) do
        local policy = row.insurancePolicy
        local compliance = self.manager.fleetManagement:getPolicyCompliance(farmId, row.uniqueId)
        print(string.format("[RealisticFarmFinance]   vehicle=%s uniqueId=%s ownership=%s status=%s policy=%s cover=%s legal=%s use=%s weightLimit=%.1ft currentMass=%.1ft currentUse=%s compliant=%s start=%d expiry=%d due=%.2f source=%s",
            tostring(row.name), tostring(row.uniqueId), tostring(row.ownership), tostring(row.insuranceStatus),
            policy ~= nil and string.format("RFF-VI-%06d", policy.id or 0) or "none",
            tostring(row.insuranceCoverType or "NONE"), tostring(policy ~= nil and policy.legalCover == true),
            policy ~= nil and tostring(policy.useScope or "AGRICULTURAL_ROAD") or "NONE",
            policy ~= nil and (policy.maxGrossWeight or 0) or 0,
            compliance ~= nil and (compliance.grossWeight or 0) or 0,
            compliance ~= nil and tostring(compliance.locationType or "UNKNOWN") or "UNKNOWN",
            tostring(compliance ~= nil and compliance.compliant == true),
            policy ~= nil and (policy.startPeriod or 0) or 0,
            policy ~= nil and (policy.endPeriod or 0) or 0, policy ~= nil and (policy.premiumDue or 0) or 0,
            policy ~= nil and tostring(policy.source or "UNKNOWN") or "none"))
    end
end

function RFF_RealisticFarmFinance:consoleVehicleCompliance()
    if self.manager == nil or self.manager.vehicleCompliance == nil or g_currentMission == nil then return "RFF vehicle compliance unavailable" end
    local farmId = g_currentMission:getFarmId()
    local assessment, reason = self.manager.vehicleCompliance:getControlledVehicleAssessment(farmId)
    if assessment == nil then return "Enter a driveable farm vehicle before using rffVehicleCompliance (" .. tostring(reason or "vehicle") .. ")" end
    local technical = assessment.adsTechnical or {}
    print(string.format("[RealisticFarmFinance] compliance vehicle=%s id=%s storeCategory=%s required=%s basis=%s location=%s entitlement=%s speed=%.1f/%.1fkmh width=%.2fm mass=%.2ft trailerMass=%.2ft ADRLoad=%s ADRHeld=%s ADS=%s breakdowns=%d insurance=%s widthAuthorised=%s remaining=%.2fh overall=%s",
        tostring(assessment.vehicleName), tostring(assessment.vehicleUniqueId), tostring(assessment.storeCategory),
        tostring(assessment.requiredCategory), tostring(assessment.classificationBasis), tostring(assessment.locationType),
        tostring(assessment.entitlementHeld), assessment.speedKmh or 0, assessment.speedLimitKmh or 0,
        assessment.widthMetres or 0, assessment.grossMassTonnes or 0, assessment.trailerMassTonnes or 0,
        tostring(assessment.hazardousLoadName ~= "" and assessment.hazardousLoadName or "none"), tostring(assessment.adrHeld),
        assessment.adsRoadworthy == nil and "not_assessed" or tostring(assessment.adsRoadworthy), technical.breakdownCount or 0,
        tostring(assessment.insuranceStatus or "UNINSURED"), tostring(assessment.movementAuthorisationActive == true),
        assessment.movementAuthorisationRemainingHours or 0, tostring(assessment.overallStatus)))
    if assessment.movementAuthorisationRequired then
        if assessment.massAuthorisationRequired then
            print("[RealisticFarmFinance]   The combination exceeds 44 tonnes; mass authorisation is not available in this first community-test build.")
        else
            print("[RealisticFarmFinance]   Width exceeds 3.00 metres; request a four-hour movement authorisation from Vehicles > Compliance.")
        end
    end
    return string.format("RFF assessment: %s requires %s; %s (%s).", assessment.vehicleName, assessment.requiredCategory, assessment.overallStatus, assessment.locationType)
end

function RFF_RealisticFarmFinance:consoleQualificationTest(action)
    if self.manager == nil or self.manager.vehicleCompliance == nil or g_currentMission == nil then return "RFF vehicle compliance unavailable" end
    local farmId = g_currentMission:getFarmId()
    local ok, reason, record = self.manager.vehicleCompliance:setQualificationForTest(farmId, action)
    if not ok then return "Usage: rffQualificationTest [B|F|H|C|ADR|ALL|RESET|REVOKE]" end
    if self.guiFrame ~= nil and self.guiFrame.updateVehicleComplianceContent ~= nil then self.guiFrame:updateVehicleComplianceContent() end
    return string.format("Qualifications updated: mode=%s effective B=%s F=%s H=%s C=%s ADR=%s; earned F=%s H=%s C=%s ADR=%s; points=%d specialistRevoked=%s",
        tostring(record.licenceMode),
        tostring(record.categoryB), tostring(record.categoryF), tostring(record.categoryH), tostring(record.categoryC),
        tostring(record.adr), tostring(record.earnedCategoryF), tostring(record.earnedCategoryH), tostring(record.earnedCategoryC),
        tostring(record.earnedAdr), record.penaltyPoints or 0, tostring(record.specialistRevoked))
end

function RFF_RealisticFarmFinance:consoleDriverOffenceTest(action)
    if self.manager == nil or self.manager.vehicleCompliance == nil or g_currentMission == nil then return "RFF vehicle compliance unavailable" end
    if not g_currentMission:getIsServer() then return "Server only" end
    local farmId = g_currentMission:getFarmId()
    action = string.upper(tostring(action or "MODERATE"))
    local ok, reason, offence
    if action == "CLEAR" then
        ok, reason = self.manager.vehicleCompliance:clearDriverOffencesForTest(farmId)
    else
        ok, reason, offence = self.manager.vehicleCompliance:addDriverOffenceForTest(farmId, action)
    end
    if not ok then return "Usage: rffDriverOffenceTest [MINOR|MODERATE|SERIOUS|SEVERE|CLEAR]" end
    if self.guiFrame ~= nil then
        if self.guiFrame.updateRoadComplianceSettingsContent ~= nil then self.guiFrame:updateRoadComplianceSettingsContent() end
        if self.guiFrame.updateVehicleComplianceContent ~= nil then self.guiFrame:updateVehicleComplianceContent() end
    end
    if action == "CLEAR" then return "RFF driver offences, penalty points and speed restriction cleared for this farm" end
    return string.format("Driver offence RFF-O-%06d recorded: severity=%s points=%d activeTotal=%d",
        offence.id or 0, tostring(offence.severityClass), offence.points or 0, offence.pointsTotalAfter or 0)
end

function RFF_RealisticFarmFinance:consoleRoadRules()
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil or g_currentMission == nil then return "RFF compliance unavailable" end
    local assessment = service:getControlledVehicleAssessment(g_currentMission:getFarmId())
    if assessment == nil then return "Enter a vehicle first." end
    local rules = assessment.speedRules
    return string.format("%s | location=%s | spline=%s | road=%s vehicle=%s width=%s weight=%s penalty=%s fallback=%s | limit=%.2f km/h (%s) | %.2f m / %.2f t",
        assessment.vehicleName, assessment.locationType, tostring(rules.splineId or "none"),
        tostring(rules.roadLimitKmh), tostring(rules.vehicleLimitKmh), tostring(rules.widthLimitKmh),
        tostring(rules.weightLimitKmh), tostring(rules.penaltyLimitKmh), tostring(rules.fallbackLimitKmh),
        rules.limitKmh, rules.reason, assessment.widthMetres, assessment.grossMassTonnes)
end

function RFF_RealisticFarmFinance:consoleInsurancePricingTest(action)
    local fleet = self.manager ~= nil and self.manager.fleetManagement or nil
    if fleet == nil or g_currentMission == nil then return "RFF fleet unavailable" end
    action = string.upper(tostring(action or "STATUS"))
    if action == "EXAMPLES" then
        for _, example in ipairs({{0,0}, {6,0}, {12,0}, {24,0}, {0,1}, {0,3}, {0,5}}) do
            local premium = fleet:calculateHistoryAdjustedPremium(1000, example[1], example[2])
            print(string.format("[RFF pricing example] base=1000 insuredClaimFreeMonths=%d claims=%d annual=%d", example[1], example[2], premium))
        end
        return "Read-only examples; no policy, claims or money changed."
    end
    if action ~= "STATUS" then return "Usage: rffInsurancePricingTest [STATUS|EXAMPLES]" end
    local vehicle = g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil and g_localPlayer:getCurrentVehicle() or nil
    if vehicle == nil then return "Enter a farm vehicle to inspect its quote." end
    local farmId = g_currentMission:getFarmId()
    local policy = self.manager.repository:getVehicleInsurancePolicyByVehicle(farmId, tostring(vehicle.uniqueId or ""))
    local quote, reason = fleet:getPolicyQuote(farmId, tostring(vehicle.uniqueId or ""),
        policy ~= nil and policy.coverType or "COMPREHENSIVE", policy ~= nil and policy.legalCover == true,
        policy ~= nil and policy.useScope or "AGRICULTURAL_ROAD", policy ~= nil and policy.maxGrossWeight or 0)
    if quote == nil then return "Quote unavailable: " .. tostring(reason) end
    return string.format("%s: base=%d cleanInsuredMonths=%d discount=%d settledFaultClaims=%d loading=%d annual=%d previous=%d credit=%d due=%d pointsPricing=%s activePoints=%d pointsLoading=%d",
        quote.vehicleName, quote.basePremium, quote.claimFreeMonths, quote.discountAmount, quote.recentClaims,
        quote.claimsLoadingAmount, quote.annualPremium, quote.previousAnnualPremium, quote.currentPolicyCredit, quote.payableToday,
        quote.pointsPricingEnabled and "ON" or "OFF", quote.activePenaltyPoints, quote.pointsLoadingAmount)
end

function RFF_RealisticFarmFinance:consoleDriverPenaltyTest(action)
    if self.manager == nil or self.manager.vehicleCompliance == nil or g_currentMission == nil then return "RFF vehicle compliance unavailable" end
    if not g_currentMission:getIsServer() then return "Server only" end
    local service = self.manager.vehicleCompliance
    local farmId = g_currentMission:getFarmId()
    local state = service:ensureQualificationRecord(farmId)
    if state == nil then return "No active farm" end
    action = string.upper(tostring(action or "STATUS"))
    if action == "ON" or action == "OFF" then
        service:setDrivingPenalties(farmId, action == "ON")
    elseif action == "EXPIRE" then
        if state.driverRestrictionEnd > 0 then
            state.driverRestrictionEnd = service:getPenaltyClock()
            service:expireSpeedPenalty(farmId, state)
        end
    elseif action == "EXPIREPOINTS" then
        for _, offence in ipairs(service:getDriverOffences(farmId)) do
            if offence.status == "ACTIVE" then offence.pointsExpireAt = service:getPenaltyClock() end
        end
        service:expireSpeedPenalty(farmId, state)
    elseif action ~= "STATUS" then return "Usage: rffDriverPenaltyTest [STATUS|ON|OFF|EXPIRE|EXPIREPOINTS]" end
    if self.guiFrame ~= nil and self.guiFrame.updateRoadComplianceSettingsContent ~= nil then
        self.guiFrame:updateRoadComplianceSettingsContent()
    end
    return service:getRestrictionSummary(farmId)
end

function RFF_RealisticFarmFinance:consoleVehicleClaimTest(lossTypeValue, amountValue, locationValue, grossWeightValue)
    if self.manager == nil or self.manager.insuranceClaims == nil or g_currentMission == nil then return "RFF vehicle insurance unavailable" end
    if not g_currentMission:getIsServer() then return "Server only" end
    local vehicle = g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil and g_localPlayer:getCurrentVehicle() or nil
    if vehicle == nil then return "Enter the insured vehicle before using rffVehicleClaimTest" end
    local farmId = g_currentMission:getFarmId()
    if farmId == nil or farmId <= 0 then return "No active farm" end

    local lossType = string.upper(tostring(lossTypeValue or "OWN"))
    if lossType == "OWN" or lossType == "DAMAGE" then lossType = "OWN_DAMAGE"
    elseif lossType == "THIRD" or lossType == "LIABILITY" then lossType = "THIRD_PARTY"
    elseif lossType ~= "LEGAL" and lossType ~= "MIXED" then
        return "Usage: rffVehicleClaimTest [own|third|legal|mixed] [amount] [auto|road|farmland|other] [grossTonnes]"
    end
    local location = string.upper(tostring(locationValue or ""))
    if location == "AUTO" then location = "" end
    if location ~= "" and location ~= "ROAD" and location ~= "FARMLAND" and location ~= "OTHER" then
        return "Location must be auto, road, farmland or other"
    end
    local amount = math.max(1, tonumber(amountValue) or 5000)
    local grossWeight = tonumber(grossWeightValue)
    local ok, reason, claim = self.manager.insuranceClaims:createVehicleClaim(farmId, tostring(vehicle.uniqueId or ""), {
        source = "RFF_TEST",
        lossType = lossType,
        amount = amount,
        locationType = location ~= "" and location or nil,
        grossWeight = grossWeight,
        description = "Test vehicle insurance incident"
    })
    if not ok or claim == nil then return "Unable to submit test vehicle claim: " .. tostring(reason or "unknown") end
    if self.guiFrame ~= nil and self.guiFrame.updateInsuranceClaimsContent ~= nil then self.guiFrame:updateInsuranceClaimsContent(true) end
    return string.format("Submitted %s for %s: type=%s amount=%s cover=%s status=%s location=%s mass=%.1ft limit=%.1ft licence=%s category=%s held=%s ADRrequired=%s ADRheld=%s estimated=%s. Use rffClaimDecisionNow %d to process the decision and settlement.",
        self.manager.insuranceClaims:getClaimReference(claim), tostring(claim.vehicleName or "Vehicle"), lossType,
        g_i18n:formatMoney(claim.amountClaimed or 0, 0, true, true), tostring(claim.policyCoverType or "NONE"),
        tostring(claim.policyStatusAtIncident or "UNINSURED"), tostring(claim.incidentLocationType or "UNKNOWN"),
        claim.incidentGrossWeight or 0, claim.policyMaxGrossWeight or 0,
        tostring(claim.licenceComplianceStatus or "NOT_ASSESSED"), tostring(claim.licenceRequiredCategory or ""),
        tostring(claim.licenceEntitlementHeld == true), tostring(claim.licenceAdrRequired == true),
        tostring(claim.licenceAdrHeld == true), g_i18n:formatMoney(claim.estimatedPayout or 0, 0, true, true), claim.id or 0)
end

function RFF_RealisticFarmFinance:consoleWelfareHistory(value)
    if g_currentMission == nil or RFF_InsuranceHistoryAPI == nil then
        print("[RealisticFarmFinance] Insurance history API not available")
        return
    end
    local farmId = g_currentMission:getFarmId()
    local periods = tonumber(value) or 6
    periods = math.max(1, math.floor(periods))
    local summary, reason = RFF_InsuranceHistoryAPI:getFarmSummary(farmId, periods)
    if summary == nil then
        print(string.format("[RealisticFarmFinance] welfareHistory unavailable farm=%s reason=%s", tostring(farmId), tostring(reason)))
        return
    end
    print(string.format("[RealisticFarmFinance] welfareHistory api=%d farm=%d periods=%d mortality=%d claimedDeaths=%d unclaimedDeaths=%d claims=%d mortalityClaims=%d vetClaims=%d underReview=%d declined=%d paid=%d claimedValue=%.2f paidValue=%.2f",
        summary.apiVersion or 1, farmId, periods, summary.mortalityCount or 0, summary.claimedMortalityCount or 0,
        summary.unclaimedMortalityCount or 0, summary.claimCount or 0, summary.mortalityClaimCount or 0,
        summary.veterinaryClaimCount or 0, summary.underReviewClaimCount or 0, summary.declinedClaimCount or 0,
        summary.paidClaimCount or 0, summary.totalAmountClaimed or 0, summary.totalPaidAmount or 0))
    local causes = {}
    for cause, count in pairs(summary.causeCounts or {}) do causes[#causes + 1] = string.format("%s=%d", tostring(cause), count or 0) end
    table.sort(causes)
    print(string.format("[RealisticFarmFinance] welfareHistory causes=%s", #causes > 0 and table.concat(causes, ",") or "none"))
end

function RFF_RealisticFarmFinance:consoleClaims()
    if self.manager == nil or self.manager.insuranceClaims == nil or self.manager.repository == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local losses = self.manager.repository.getInsuranceLossesByFarm ~= nil and self.manager.repository:getInsuranceLossesByFarm(farmId) or {}
    local claims = self.manager.repository:getInsuranceClaimsByFarm(farmId)
    local trafficIncidents = self.manager.repository.getTrafficCourtesyIncidentsByFarm ~= nil and self.manager.repository:getTrafficCourtesyIncidentsByFarm(farmId) or {}
    local vetExpenses = self.manager.repository.getInsuranceVeterinaryExpensesByFarm ~= nil and self.manager.repository:getInsuranceVeterinaryExpensesByFarm(farmId) or {}
    local vetEligibleTotal, vetEligibleCount = self.manager.insuranceClaims:getEligibleVeterinaryExpenseTotal(farmId)
    print(string.format("[RealisticFarmFinance] insurance farm=%d deathRecords=%d vetExpenses=%d vetEligible=%d vetEligibleTotal=%.2f trafficIncidents=%d claims=%d trafficCourtesyHook=%s rlrHook=%s treatmentHook=%s safetyHook=%s", farmId, #losses, #vetExpenses, vetEligibleCount, vetEligibleTotal, #trafficIncidents, #claims, tostring(self.manager.insuranceClaims._trafficCourtesyRegistered == true), tostring(self.manager.insuranceClaims.rlrHookAvailable == true), tostring(self.manager.insuranceClaims.rlrTreatmentHookAvailable == true), tostring(self.manager.insuranceClaims.rlrSafetyHookAvailable == true)))
    for _, loss in ipairs(losses) do
        print(string.format("[RealisticFarmFinance] death=%s status=%s source=%s animalType=%s animal=%s breed=%s age=%d health=%.1f cause=%s valueAtDeath=%.2f policyTierAtDeath=%s incidentPeriod=%d deadlinePeriod=%d monthsRemaining=%d claimId=%d",
            self.manager.insuranceClaims:getLossReference(loss), tostring(loss.status), tostring(loss.source), tostring(loss.animalType),
            tostring(loss.animalUniqueId), tostring(loss.animalBreed), loss.animalAge or 0, loss.animalHealth or 0, tostring(loss.deathReason),
            loss.incidentValue or 0, tostring(loss.policyTier), loss.incidentPeriod or 0, loss.deadlinePeriod or 0,
            self.manager.insuranceClaims:getLossMonthsRemaining(loss), loss.claimId or 0))
    end
    for _, expense in ipairs(vetExpenses) do
        print(string.format("[RealisticFarmFinance] vetExpense=VET-%04d status=%s animal=%s breed=%s diseases=%s cost=%.2f tier=%s incidentPeriod=%d deadlinePeriod=%d monthsRemaining=%d claimId=%d",
            expense.id or 0, tostring(expense.status), tostring(expense.animalUniqueId), tostring(expense.animalBreed), tostring(expense.diseaseNames),
            expense.treatmentCost or 0, tostring(expense.policyTier), expense.incidentPeriod or 0, expense.deadlinePeriod or 0,
            self.manager.insuranceClaims:getVeterinaryExpenseMonthsRemaining(expense), expense.claimId or 0))
    end
    for _, incident in ipairs(trafficIncidents) do
        print(string.format("[RealisticFarmFinance] trafficIncident=%s external=%s status=%s vehicle=%s part=%s targetType=%s target=%s severity=%s closing=%.1fkm/h location=%s mass=%.2ft cover=%s policyStatus=%s use=%s limit=%.2ft licence=%s category=%s held=%s adrRequired=%s adrHeld=%s own=%.2f third=%.2f legal=%.2f estimatedPayout=%.2f claimId=%d",
            self.manager.insuranceClaims:getTrafficCourtesyIncidentReference(incident), tostring(incident.externalIncidentId), tostring(incident.status),
            tostring(incident.vehicleName), tostring(incident.partName), tostring(incident.targetType), tostring(incident.targetName),
            tostring(incident.severityClass), (incident.closingSpeedMps or 0)*3.6, tostring(incident.locationType),
            (incident.combinationMassKg or 0)/1000, tostring(incident.policyCoverType), tostring(incident.policyStatusAtIncident),
            tostring(incident.policyUseScope), incident.policyMaxGrossWeight or 0, tostring(incident.licenceComplianceStatus or "NOT_ASSESSED"),
            tostring(incident.licenceRequiredCategory or ""), tostring(incident.licenceEntitlementHeld == true),
            tostring(incident.licenceAdrRequired == true), tostring(incident.licenceAdrHeld == true), incident.ownDamageEstimate or 0,
            incident.thirdPartyEstimate or 0, incident.legalCostEstimate or 0, incident.estimatedPayout or 0, incident.claimId or 0))
        if (incident.groupedIncidentCount or 1) > 1 then
            print(string.format("[RealisticFarmFinance] trafficIncidentGroup=%s count=%d externalIds=%s",
                self.manager.insuranceClaims:getTrafficCourtesyIncidentReference(incident), incident.groupedIncidentCount or 1,
                tostring(incident.groupedExternalIncidentIds or incident.externalIncidentId or "")))
        end
    end
    for _, claim in ipairs(claims) do
        print(string.format("[RealisticFarmFinance] claim=%s type=%s status=%s lossId=%d source=%s insuredItem=%s itemId=%s cause=%s value=%.2f cover=%s policyStatus=%s use=%s location=%s mass=%.2ft limit=%.2ft own=%.2f third=%.2f legal=%.2f excess=%.2f approved=%.2f paid=%.2f outcome=%s incidentDay=%d decisionDay=%d settlementDay=%d",
            self.manager.insuranceClaims:getClaimReference(claim), tostring(claim.claimType or "MORTALITY"), tostring(claim.status), claim.lossId or 0, tostring(claim.source), claim.claimType == "VEHICLE" and tostring(claim.vehicleName or "Vehicle") or tostring(claim.animalType),
            claim.claimType == "VEHICLE" and tostring(claim.vehicleUniqueId or "") or tostring(claim.animalUniqueId), tostring(claim.deathReason),
            claim.incidentValue or 0, tostring(claim.policyCoverType or claim.policyTier), tostring(claim.policyStatusAtIncident),
            tostring(claim.policyUseScope or ""), tostring(claim.incidentLocationType or ""), claim.incidentGrossWeight or 0,
            claim.policyMaxGrossWeight or 0, claim.vehicleDamageCost or 0, claim.thirdPartyLiability or 0, claim.legalCosts or 0,
            claim.excess or 0, claim.approvedAmount or 0, claim.paidAmount or 0,
            tostring(claim.outcomeReason or ""), claim.incidentDay or 0, claim.decisionDay or 0, claim.settlementDay or 0))
        if self.manager.insuranceClaims:isTrafficWorkflowClaim(claim) then
            print(string.format("[RealisticFarmFinance] trafficClaim=%s liability=%s responseDeadlineDay=%d warning=%s liabilityInsurer=%.2f policyShortfall=%.2f licenceRecovery=%.2f liabilityFarm=%.2f licence=%s category=%s held=%s adrRequired=%s adrHeld=%s ownStatus=%s ownReserve=%.2f adsRequired=%s inspection=%.2f repair=%.2f warranty=%s actualOwn=%.2f ownPaid=%.2f grouped=%d",
                self.manager.insuranceClaims:getClaimReference(claim), tostring(claim.liabilityStatus), claim.responseDeadlineDay or 0,
                tostring(claim.responseWarningSent == true), claim.liabilityInsurerPaid or 0, claim.liabilityPolicyShortfall or 0,
                claim.liabilityInsurerRecovery or 0, claim.liabilityFarmCharge or 0, tostring(claim.licenceComplianceStatus or "NOT_ASSESSED"),
                tostring(claim.licenceRequiredCategory or ""), tostring(claim.licenceEntitlementHeld == true),
                tostring(claim.licenceAdrRequired == true), tostring(claim.licenceAdrHeld == true),
                tostring(claim.ownDamageStatus), claim.ownDamageEstimate or 0, tostring(claim.adsRequired == true),
                claim.adsInspectionCost or 0, claim.adsRepairCost or 0, tostring(claim.adsWarrantyRepair == true),
                claim.actualOwnDamageCost or 0, claim.ownPaidAmount or 0, claim.groupedIncidentCount or 1))
        end
    end
end

function RFF_RealisticFarmFinance:consoleClaimTest(reason, value)
    if self.manager == nil or self.manager.insuranceClaims == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local loss, result = self.manager.insuranceClaims:createTestLoss(farmId, reason, tonumber(value))
    if loss == nil then
        print(string.format("[RealisticFarmFinance] test livestock loss failed: %s", tostring(result)))
        return
    end
    print(string.format("[RealisticFarmFinance] test livestock death recorded: %s cause=%s value=%.2f status=%s. No claim exists. START CLAIM will open the claim form; the animal must be selected there before the two-month deadline.",
        self.manager.insuranceClaims:getLossReference(loss), tostring(loss.deathReason), loss.incidentValue or 0, tostring(loss.status)))
end

function RFF_RealisticFarmFinance:consoleVetTest(value)
    if self.manager == nil or self.manager.insuranceClaims == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local expense, result = self.manager.insuranceClaims:createTestVeterinaryExpense(farmId, tonumber(value))
    if expense == nil then
        print(string.format("[RealisticFarmFinance] test veterinary expense failed: %s", tostring(result)))
        return
    end
    local total, count = self.manager.insuranceClaims:getEligibleVeterinaryExpenseTotal(farmId)
    print(string.format("[RealisticFarmFinance] test veterinary expense recorded: VET-%04d cost=%.2f tier=%s status=%s eligibleNow=%s eligibleCount=%d eligibleTotal=%.2f. No claim exists until the player uses CLAIM VET EXPENSES.",
        expense.id or 0, expense.treatmentCost or 0, tostring(expense.policyTier), tostring(expense.policyStatusAtIncident),
        tostring(expense.status == RFF_InsuranceClaimService.VET_EXPENSE_RECORDED and self.manager.insuranceClaims:getTerms(expense.policyTier).veterinaryCovered == true and self.manager.insuranceClaims:isPolicyInForce(expense.policyStatusAtIncident)), count, total))
end

function RFF_RealisticFarmFinance:consoleClaimDecisionNow(value)
    if self.manager == nil or self.manager.insuranceClaims == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local claimId = tonumber(value)
    local processed = self.manager.insuranceClaims:forceProcess(farmId, claimId)
    print(string.format("[RealisticFarmFinance] forced insurance claim processing farm=%d claim=%s stagesProcessed=%d", farmId, claimId ~= nil and tostring(claimId) or "ALL", processed))
end

function RFF_RealisticFarmFinance:consoleTax()
    if self.manager == nil or self.manager.taxCompliance == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local summary = self.manager.taxCompliance:getSummary(farmId)
    local state = summary.state or {}
    print(string.format("[RealisticFarmFinance] taxReturn farm=%d available=%s year=%d status=%s method=%s bookIncome=%.2f bookExpenses=%.2f bookTax=%.2f declaredIncome=%.2f declaredExpenses=%.2f filedTax=%.2f saving=%.2f complianceFlags=%d aggressiveFilings=%d cleanFilings=%d liability=%.2f investigation=%s lastOutcome=%s",
        farmId, tostring(summary.available), state.taxReturnYear or 0, tostring(state.taxReturnStatus or "NONE"), tostring(state.taxReturnMethod or "NONE"),
        state.taxReturnBookIncome or 0, state.taxReturnBookExpenses or 0, state.taxReturnBookTax or 0, state.taxReturnDeclaredIncome or 0, state.taxReturnDeclaredExpenses or 0,
        state.taxReturnFiledTax or 0, state.taxReturnTaxSaving or 0, state.taxComplianceFlags or 0, state.taxComplianceAggressiveFilings or 0, state.taxComplianceCleanFilings or 0,
        state.taxComplianceLiability or 0, tostring(state.taxInvestigationStatus or "NONE"), tostring(state.taxInvestigationLastOutcome or "NONE")))
    local annual = self.manager.taxCompliance:getLatestTaxStatement(farmId)
    print(string.format("[RealisticFarmFinance] taxReturn bridge month=%s annualStatement=%s annualPaid=%s statementMonth=%s filingWindowEligible=%s",
        tostring(self.manager.taxCompliance:getCurrentMonth()), tostring(annual ~= nil), tostring(annual ~= nil and annual.paid == true),
        tostring(annual ~= nil and annual.month or nil), tostring(self.manager.taxCompliance:isCurrentAnnualStatement(annual))))
end

function RFF_RealisticFarmFinance:consoleTaxNow()
    if self.manager == nil or self.manager.taxCompliance == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local state, reason = self.manager.taxCompliance:forceReturnForTest(farmId)
    print(string.format("[RealisticFarmFinance] forced tax-return task farm=%d ok=%s reason=%s", farmId, tostring(state ~= nil), tostring(reason)))
    if state ~= nil then print("[RealisticFarmFinance] DEVELOPMENT TEST: this return uses Red Tape current-year-to-date figures and is not the natural April annual statement / September bill") end
    if state ~= nil and self.guiFrame ~= nil then self.guiFrame:updateBusinessAdministrationContent() end
end

function RFF_RealisticFarmFinance:consoleTaxAuditNow()
    if self.manager == nil or self.manager.taxCompliance == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    local ok, reason = self.manager.taxCompliance:forceAuditForTest(farmId)
    print(string.format("[RealisticFarmFinance] forced tax compliance review farm=%d ok=%s reason=%s", farmId, tostring(ok), tostring(reason)))
end

function RFF_RealisticFarmFinance:consoleRelationships()
    if self.manager == nil or self.manager.relationshipService == nil or g_currentMission == nil then return end
    local farmId = g_currentMission:getFarmId()
    print(string.format("[RealisticFarmFinance] lender relationships farm=%d", farmId))
    for _, lender in ipairs(self.manager.relationshipService:getLenders()) do
        local rel, benefits = self.manager.relationshipService:getSummary(farmId, lender.id)
        print(string.format("[RealisticFarmFinance] lender=%s tier=%s points=%.2f apps=%d deals=%d payments=%d missed=%d completed=%d forbearance=%d brokenSupport=%d rescueDeals=%d rescueExits=%d recoveries=%d possessions=%d volume=%.2f rateAdj=%+.2f feeFactor=%.3f timingFactor=%.3f",
            lender.id, benefits.code, rel.relationshipPoints or 0, rel.applications or 0, rel.acceptedDeals or 0,
            rel.successfulPayments or 0, rel.missedPayments or 0, rel.completedAgreements or 0, rel.forbearanceArrangements or 0, rel.brokenForbearanceArrangements or 0,
            rel.rescueDeals or 0, rel.rescueExits or 0, rel.forcedRecoveries or 0, rel.mortgagePossessions or 0, rel.totalVolume or 0,
            benefits.rateAdjustment or 0, benefits.arrangementFeeFactor or 1, benefits.timingFactor or 1))
    end
end

addModEventListener(RFF_RealisticFarmFinance)
