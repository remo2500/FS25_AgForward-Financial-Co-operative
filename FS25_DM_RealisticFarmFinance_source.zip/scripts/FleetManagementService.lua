RFF_FleetManagementService = {}
RFF_FleetManagementService.__index = RFF_FleetManagementService

RFF_FleetManagementService.INSPECTION_INTERVAL_PERIODS = 12
RFF_FleetManagementService.COVER_THIRD_PARTY = "THIRD_PARTY"
RFF_FleetManagementService.COVER_COMPREHENSIVE = "COMPREHENSIVE"
RFF_FleetManagementService.USE_FARMLAND_ONLY = "FARMLAND_ONLY"
RFF_FleetManagementService.USE_AGRICULTURAL_ROAD = "AGRICULTURAL_ROAD"
RFF_FleetManagementService.POLICY_TERM_PERIODS = 12
RFF_FleetManagementService.DEALERSHIP_COVER_HOURS = 6
RFF_FleetManagementService.WEIGHT_LIMIT_LIGHT = 15
RFF_FleetManagementService.WEIGHT_LIMIT_STANDARD = 30
RFF_FleetManagementService.ROAD_SPLINE_DISTANCE = 6
RFF_FleetManagementService.CLAIMS_PRICING_WINDOW = 12
RFF_FleetManagementService.CLAIM_FREE_STEP_MONTHS = 6
RFF_FleetManagementService.CLAIM_FREE_STEP_RATE = 0.05
RFF_FleetManagementService.CLAIM_FREE_MAX_RATE = 0.20
RFF_FleetManagementService.CLAIM_LOADING_RATE = 0.10
RFF_FleetManagementService.CLAIM_LOADING_MAX_RATE = 0.30
RFF_FleetManagementService.POINT_LOADING_RATE = 0.01
RFF_FleetManagementService.POINT_LOADING_MAX_RATE = 0.15

local function safeNumber(value, fallback)
    local numberValue = tonumber(value)
    if numberValue == nil then return fallback or 0 end
    return numberValue
end

local function callVehicle(vehicle, methodName, ...)
    if vehicle == nil or type(vehicle[methodName]) ~= "function" then return false, nil end
    local ok, value = pcall(vehicle[methodName], vehicle, ...)
    if not ok then return false, nil end
    return true, value
end

local function getOwnerFarmId(vehicle)
    local ok, farmId = callVehicle(vehicle, "getOwnerFarmId")
    if ok and farmId ~= nil then return math.floor(safeNumber(farmId, 0)) end
    return math.floor(safeNumber(vehicle ~= nil and vehicle.ownerFarmId or 0, 0))
end

local function getVehicleName(vehicle)
    local ok, name = callVehicle(vehicle, "getFullName")
    if ok and name ~= nil and tostring(name) ~= "" then return tostring(name) end
    ok, name = callVehicle(vehicle, "getName")
    if ok and name ~= nil and tostring(name) ~= "" then return tostring(name) end
    if vehicle ~= nil and vehicle.typeName ~= nil and tostring(vehicle.typeName) ~= "" then return tostring(vehicle.typeName) end
    return "Vehicle"
end

local function isPlayableFarm(farmId, farm)
    if farmId == nil or farmId <= 0 or farm == nil then return false end
    if FarmManager ~= nil and FarmManager.SPECTATOR_FARM_ID ~= nil and farmId == FarmManager.SPECTATOR_FARM_ID then return false end
    if FarmlandManager ~= nil and FarmlandManager.NO_OWNER_FARM_ID ~= nil and farmId == FarmlandManager.NO_OWNER_FARM_ID then return false end
    return farm.isSpectator ~= true
end

function RFF_FleetManagementService.new(repository, businessAdministration)
    local self = setmetatable({}, RFF_FleetManagementService)
    self.repository = repository
    self.businessAdministration = businessAdministration
    return self
end

function RFF_FleetManagementService:isDriveableFarmVehicle(vehicle, farmId)
    if vehicle == nil or vehicle.spec_drivable == nil then return false end
    if getOwnerFarmId(vehicle) ~= farmId then return false end

    -- Contract/mission and shop-preview vehicles can temporarily share a farm id,
    -- but they are not part of that farm's managed fleet.
    local ownedState = VehiclePropertyState ~= nil and VehiclePropertyState.OWNED or 2
    local leasedState = VehiclePropertyState ~= nil and VehiclePropertyState.LEASED or 3
    if vehicle.propertyState ~= nil and vehicle.propertyState ~= ownedState and vehicle.propertyState ~= leasedState then
        return false
    end

    local ok, show = callVehicle(vehicle, "getShowInVehiclesOverview")
    if ok and show == false then return false end
    return true
end

function RFF_FleetManagementService:getOwnership(vehicle)
    local uniqueId = tostring(vehicle ~= nil and vehicle.uniqueId or "")
    local agreement = self.repository ~= nil and self.repository:getAssetFinanceByVehicle(uniqueId, true) or nil
    if agreement ~= nil then
        if agreement.product == "OPERATING_LEASE" then return "OPERATING_LEASE", agreement end
        if agreement.product == "BALLOON_FINANCE" then return "BALLOON_FINANCE", agreement end
        if agreement.product == "HIRE_PURCHASE" then return "HIRE_PURCHASE", agreement end
    end

    local leasedState = VehiclePropertyState ~= nil and VehiclePropertyState.LEASED or 3
    if vehicle ~= nil and vehicle.propertyState == leasedState then return "NATIVE_LEASE", nil end
    return "OWNED", agreement
end

function RFF_FleetManagementService:getOperatingHours(vehicle)
    local ok, operatingTime = callVehicle(vehicle, "getOperatingTime")
    if not ok then operatingTime = vehicle ~= nil and vehicle.operatingTime or 0 end
    return math.max(0, safeNumber(operatingTime, 0) / (60 * 60 * 1000))
end

function RFF_FleetManagementService:getVehicleValue(vehicle)
    local ok, value = callVehicle(vehicle, "getSellPrice")
    return ok and math.max(0, safeNumber(value, 0)) or 0
end

function RFF_FleetManagementService:getInsurableValue(vehicle, ownership, agreement)
    local value = self:getVehicleValue(vehicle)
    if ownership == "OPERATING_LEASE" and agreement ~= nil then
        -- The leasing company owns the asset. Its recorded invoice value remains
        -- the insured interest even when the tenant's current sell value is lower.
        value = math.max(value, safeNumber(agreement.basePrice, 0))
    end
    return value
end

function RFF_FleetManagementService:getVehicleGrossWeight(vehicle)
    local ok, weight = callVehicle(vehicle, "getTotalMass")
    if not ok then return 0 end
    -- GIANTS Vehicle:getTotalMass reports metric tonnes and includes attached
    -- equipment when called without the onlyGivenVehicle flag.
    return math.max(0, safeNumber(weight, 0))
end

function RFF_FleetManagementService:normaliseWeightLimit(maxGrossWeight)
    local limit = safeNumber(maxGrossWeight, 0)
    if limit > 0 and limit <= self.WEIGHT_LIMIT_LIGHT then return self.WEIGHT_LIMIT_LIGHT end
    if limit > self.WEIGHT_LIMIT_LIGHT and limit <= self.WEIGHT_LIMIT_STANDARD then return self.WEIGHT_LIMIT_STANDARD end
    return 0
end

function RFF_FleetManagementService:getVehiclePosition(vehicle, context)
    context = context or {}
    local suppliedX = tonumber(context.x)
    local suppliedY = tonumber(context.y)
    local suppliedZ = tonumber(context.z)
    if suppliedX ~= nil and suppliedZ ~= nil then return suppliedX, suppliedY or 0, suppliedZ, nil end
    local node = vehicle ~= nil and (vehicle.rootNode or (vehicle.components ~= nil and vehicle.components[1] ~= nil and vehicle.components[1].node)) or nil
    if node == nil or node == 0 or getWorldTranslation == nil then return nil, nil, nil, nil end
    local ok, x, y, z = pcall(getWorldTranslation, node)
    if not ok then return nil, nil, nil, node end
    return x, y, z, node
end

function RFF_FleetManagementService:classifyVehicleUse(farmId, vehicle, context)
    context = context or {}
    local supplied = string.upper(tostring(context.locationType or context.useType or ""))
    if supplied == "ROAD" or supplied == "FARMLAND" or supplied == "OTHER" then return supplied end

    local x, y, z = self:getVehiclePosition(vehicle, context)
    if x == nil or z == nil then return "UNKNOWN" end
    local roadInfo = RFF_RoadSpeedRules.getRoadInfo(self, vehicle, context)
    if roadInfo.detected then return "ROAD", roadInfo end

    if g_farmlandManager ~= nil and g_farmlandManager.getCanAccessLandAtWorldPosition ~= nil then
        local ok, canAccess = pcall(g_farmlandManager.getCanAccessLandAtWorldPosition, g_farmlandManager, farmId, x, z)
        if ok and canAccess == true then return "FARMLAND" end
    end
    return "OTHER"
end

function RFF_FleetManagementService:getPolicyCompliance(farmId, vehicleUniqueId, context)
    local vehicle = self:findVehicle(farmId, vehicleUniqueId)
    if vehicle == nil then return nil, "vehicle" end
    context = context or {}
    local ownership = self:getOwnership(vehicle)
    local insuranceStatus, inForce, policy = self:getInsurance(vehicle, farmId, ownership)
    local positionX, positionY, positionZ = self:getVehiclePosition(vehicle, context)
    local locationType = self:classifyVehicleUse(farmId, vehicle, {
        x = positionX,
        y = positionY,
        z = positionZ,
        locationType = context.locationType,
        useType = context.useType
    })
    local grossWeight = safeNumber(context.grossWeight, self:getVehicleGrossWeight(vehicle))
    local violations = {}
    if not inForce then violations[#violations + 1] = "NO_COVER" end
    if policy ~= nil and policy.useScope == self.USE_FARMLAND_ONLY and locationType ~= "FARMLAND" and locationType ~= "UNKNOWN" then
        violations[#violations + 1] = "ROAD_USE_EXCLUDED"
    end
    local weightLimit = policy ~= nil and self:normaliseWeightLimit(policy.maxGrossWeight) or 0
    if weightLimit > 0 and grossWeight > weightLimit + 0.001 then violations[#violations + 1] = "WEIGHT_LIMIT_EXCEEDED" end
    return {
        vehicle = vehicle,
        vehicleUniqueId = tostring(vehicleUniqueId or ""),
        vehicleName = getVehicleName(vehicle),
        ownership = ownership,
        insuranceStatus = insuranceStatus,
        inForce = inForce,
        policy = policy,
        locationType = locationType,
        positionX = positionX,
        positionY = positionY,
        positionZ = positionZ,
        grossWeight = grossWeight,
        weightLimit = weightLimit,
        compliant = #violations == 0,
        violations = violations
    }, "checked"
end

function RFF_FleetManagementService:getCurrentAbsoluteHour()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    if env == nil then return 0 end
    local day = math.max(0, math.floor(safeNumber(env.currentMonotonicDay or env.currentDay, 0)))
    local hour = math.max(0, math.min(23, math.floor(safeNumber(env.currentHour, 0))))
    return day * 24 + hour
end

function RFF_FleetManagementService:getTemporaryCoverHoursRemaining(policy)
    if policy == nil or tostring(policy.status or "") ~= "TEMPORARY" then return 0 end
    return math.max(0, math.floor(safeNumber(policy.temporaryCoverEndHour, 0) - self:getCurrentAbsoluteHour()))
end

function RFF_FleetManagementService:findVehicle(farmId, vehicleUniqueId)
    vehicleUniqueId = tostring(vehicleUniqueId or "")
    if vehicleUniqueId == "" or g_currentMission == nil or g_currentMission.vehicleSystem == nil then return nil end
    for _, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles or {}) do
        if tostring(vehicle.uniqueId or "") == vehicleUniqueId and self:isDriveableFarmVehicle(vehicle, farmId) then return vehicle end
    end
    return nil
end

function RFF_FleetManagementService:ensurePricingHistory(policy)
    if policy == nil then return end
    if type(policy.pricingCoverage) ~= "table" then policy.pricingCoverage = {} end
    if (policy.pricingHistoryVersion or 0) >= 1 then return end
    policy.pricingHistoryVersion = 1
    -- Only recorded paid annual cover earns credit; no assumed history before
    -- the latest term in an old save, and no credit for free dealership cover.
    if policy.source ~= "DEALERSHIP_TEMPORARY" and safeNumber(policy.lastPremium, 0) > 0
        and safeNumber(policy.endPeriod, 0) > safeNumber(policy.startPeriod, 0) then
        self:addPricingCoverage(policy, policy.startPeriod, policy.endPeriod)
    end
end

function RFF_FleetManagementService:addPricingCoverage(policy, startPeriod, endPeriod)
    self:ensurePricingHistory(policy)
    startPeriod, endPeriod = safeNumber(startPeriod, 0), safeNumber(endPeriod, 0)
    if endPeriod <= startPeriod then return end
    table.insert(policy.pricingCoverage, {startPeriod=startPeriod, endPeriod=endPeriod})
    table.sort(policy.pricingCoverage, function(a, b) return a.startPeriod < b.startPeriod end)
    local merged = {}
    for _, span in ipairs(policy.pricingCoverage) do
        local previous = merged[#merged]
        if previous ~= nil and span.startPeriod <= previous.endPeriod then
            previous.endPeriod = math.max(previous.endPeriod, span.endPeriod)
        else
            merged[#merged + 1] = {startPeriod=span.startPeriod, endPeriod=span.endPeriod}
        end
    end
    policy.pricingCoverage = merged
end

function RFF_FleetManagementService:getClaimPricingHistory(farmId, vehicleUniqueId, policy)
    local current = self.repository:getCurrentPeriodIndex()
    local lastFaultPeriod = 0
    local cases = {}
    for _, claim in ipairs(self.repository.insuranceClaims or {}) do
        local fault = tostring(claim.incidentFaultAssessment or "UNKNOWN")
        local atFault = fault == "PRESUMED_PLAYER" or fault == "OWN_PROPERTY" or fault == "AT_FAULT" or fault == "PLAYER"
        if claim.farmId == farmId and tostring(claim.vehicleUniqueId or "") == tostring(vehicleUniqueId)
            and claim.claimType == "VEHICLE" and (claim.status == "SETTLED" or claim.status == "PAID")
            and atFault and safeNumber(claim.paidAmount, 0) > 0.01 then
            local period = math.floor(safeNumber(claim.incidentPeriod, 0))
            if period > 0 and period <= current then
                local caseKey
                if safeNumber(claim.trafficIncidentId, 0) > 0 then caseKey = "TC:" .. tostring(claim.trafficIncidentId)
                elseif tostring(claim.externalIncidentId or "") ~= "" then caseKey = "EXT:" .. claim.externalIncidentId
                else caseKey = "CLAIM:" .. tostring(claim.id) end
                -- A grouped claim contributes once, however many collision parts it contains.
                cases[caseKey] = math.max(cases[caseKey] or 0, period)
                lastFaultPeriod = math.max(lastFaultPeriod, period)
            end
        end
    end
    local recentClaims = 0
    for _, period in pairs(cases) do
        if current - period < self.CLAIMS_PRICING_WINDOW then recentClaims = recentClaims + 1 end
    end
    self:ensurePricingHistory(policy)
    local claimFreeMonths = 0
    for _, span in ipairs(policy ~= nil and policy.pricingCoverage or {}) do
        local first = math.max(span.startPeriod, lastFaultPeriod)
        local last = math.min(span.endPeriod, current)
        claimFreeMonths = claimFreeMonths + math.max(0, last - first)
    end
    return math.floor(claimFreeMonths), recentClaims
end

function RFF_FleetManagementService:calculateHistoryAdjustedPremium(basePremium, claimFreeMonths, recentClaims)
    basePremium = math.max(1, math.floor(safeNumber(basePremium, 1) + 0.5))
    local discountRate = math.min(self.CLAIM_FREE_MAX_RATE,
        math.floor(math.max(0, claimFreeMonths) / self.CLAIM_FREE_STEP_MONTHS) * self.CLAIM_FREE_STEP_RATE)
    local loadingRate = math.min(self.CLAIM_LOADING_MAX_RATE, math.max(0, recentClaims) * self.CLAIM_LOADING_RATE)
    local discount = math.floor(basePremium * discountRate + 0.5)
    local loading = math.floor(basePremium * loadingRate + 0.5)
    return math.max(1, basePremium - discount + loading), discountRate, discount, loadingRate, loading
end

function RFF_FleetManagementService:setPointsInsurancePricing(farmId, enabled)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or farmId <= 0 then return false end
    local state = self.repository:getFarmState(farmId, true)
    if state == nil then return false end
    state.vehicleInsurancePointsEnabled = enabled == true
    return true
end

function RFF_FleetManagementService:getPointsInsuranceAdjustment(farmId, basePremium)
    local state = self.repository:getFarmState(farmId, true)
    local enabled = state ~= nil and state.vehicleInsurancePointsEnabled == true
    local points = 0
    if self.vehicleCompliance ~= nil then
        -- Use the authoritative live record, which expires aged points and clears
        -- served restrictions even if no hourly maintenance tick has run yet.
        local record = self.vehicleCompliance:getQualificationRecord(farmId)
        if record == nil and enabled then return nil end
        points = math.max(0, math.floor(safeNumber(record ~= nil and record.penaltyPoints, 0)))
    elseif enabled then
        -- Never charge from a stale saved total when the expiry service is absent.
        return nil
    end
    local rate = enabled and math.min(self.POINT_LOADING_MAX_RATE, points * self.POINT_LOADING_RATE) or 0
    return {enabled=enabled, activePoints=points, rate=rate, amount=math.floor(basePremium * rate + 0.5)}
end

function RFF_FleetManagementService:getPolicyQuote(farmId, vehicleUniqueId, coverType, legalCover, useScope, maxGrossWeight)
    if self.repository == nil then return nil, "service" end
    self:ensurePerVehiclePolicyMigration(farmId)
    local vehicle = self:findVehicle(farmId, vehicleUniqueId)
    if vehicle == nil then return nil, "vehicle" end
    local ownership, agreement = self:getOwnership(vehicle)
    if ownership == "NATIVE_LEASE" then return nil, "lease" end

    coverType = coverType == self.COVER_THIRD_PARTY and self.COVER_THIRD_PARTY or self.COVER_COMPREHENSIVE
    if ownership == "OPERATING_LEASE" then coverType = self.COVER_COMPREHENSIVE end
    useScope = useScope == self.USE_FARMLAND_ONLY and self.USE_FARMLAND_ONLY or self.USE_AGRICULTURAL_ROAD
    legalCover = legalCover == true
    maxGrossWeight = self:normaliseWeightLimit(maxGrossWeight)
    local value = self:getInsurableValue(vehicle, ownership, agreement)
    local operatingHours = self:getOperatingHours(vehicle)
    local premium
    if coverType == self.COVER_THIRD_PARTY then
        premium = math.max(175, 95 + value * 0.0045)
    else
        premium = math.max(300, 160 + value * 0.0125)
    end
    if useScope == self.USE_AGRICULTURAL_ROAD then premium = premium * 1.30 end
    if maxGrossWeight == self.WEIGHT_LIMIT_LIGHT then premium = premium * 0.88
    elseif maxGrossWeight == self.WEIGHT_LIMIT_STANDARD then premium = premium * 0.98
    else premium = premium * 1.12 end
    premium = premium * (1 + math.min(0.25, operatingHours / 12000))
    if legalCover then premium = premium + 90 + math.min(160, value * 0.0004) end
    if ownership == "OPERATING_LEASE" then premium = premium * 1.05 end
    premium = math.max(1, math.floor(premium + 0.5))

    local current = self.repository:getCurrentPeriodIndex()
    local policy = self.repository:getVehicleInsurancePolicyByVehicle(farmId, vehicleUniqueId)
    local basePremium = premium
    local claimFreeMonths, recentClaims = self:getClaimPricingHistory(farmId, vehicleUniqueId, policy)
    local discountRate, discountAmount, loadingRate, loadingAmount
    premium, discountRate, discountAmount, loadingRate, loadingAmount = self:calculateHistoryAdjustedPremium(basePremium, claimFreeMonths, recentClaims)
    local pointsAdjustment = self:getPointsInsuranceAdjustment(farmId, basePremium)
    if pointsAdjustment == nil then return nil, "points_unavailable" end
    premium = premium + pointsAdjustment.amount
    local previousPremium = policy ~= nil and math.max(0, safeNumber(policy.lastPremium, 0)) or 0
    local outstanding = policy ~= nil and math.max(0, safeNumber(policy.premiumDue, 0)) or 0
    local credit = 0
    if policy ~= nil and policy.source == "RFF_VEHICLE_POLICY" and policy.status == "ACTIVE" and safeNumber(policy.lastPremium, 0) > 0 then
        local remaining = math.max(0, math.min(self.POLICY_TERM_PERIODS, safeNumber(policy.endPeriod, current) - current))
        credit = math.floor(safeNumber(policy.lastPremium, 0) * remaining / self.POLICY_TERM_PERIODS + 0.5)
    end
    local payable = math.max(0, math.floor(premium + outstanding - credit + 0.5))
    return {
        farmId = farmId,
        vehicleUniqueId = tostring(vehicleUniqueId),
        vehicleName = getVehicleName(vehicle),
        coverType = coverType,
        legalCover = legalCover,
        useScope = useScope,
        maxGrossWeight = maxGrossWeight,
        currentGrossWeight = self:getVehicleGrossWeight(vehicle),
        insuredValue = value,
        annualPremium = premium,
        basePremium = basePremium,
        claimFreeMonths = claimFreeMonths,
        recentClaims = recentClaims,
        discountRate = discountRate,
        discountAmount = discountAmount,
        claimsLoadingRate = loadingRate,
        claimsLoadingAmount = loadingAmount,
        pointsPricingEnabled = pointsAdjustment.enabled,
        activePenaltyPoints = pointsAdjustment.activePoints,
        pointsLoadingRate = pointsAdjustment.rate,
        pointsLoadingAmount = pointsAdjustment.amount,
        previousAnnualPremium = previousPremium,
        annualPremiumChange = previousPremium > 0 and premium - previousPremium or nil,
        currentPolicyCredit = credit,
        outstandingPremium = outstanding,
        payableToday = payable,
        startPeriod = current,
        endPeriod = current + self.POLICY_TERM_PERIODS,
        replacingPolicy = policy ~= nil,
        ownership = ownership,
        lessorInterested = ownership == "OPERATING_LEASE",
        lessorNameKey = agreement ~= nil and tostring(agreement.lenderNameKey or "") or "",
        assetAgreementId = agreement ~= nil and (agreement.id or 0) or 0
    }, "quoted"
end

function RFF_FleetManagementService:purchasePolicy(farmId, vehicleUniqueId, coverType, legalCover, useScope, maxGrossWeight, acceptedQuote, automaticRenewal)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or self.businessAdministration == nil then return nil, "server" end
    local quote, reason = self:getPolicyQuote(farmId, vehicleUniqueId, coverType, legalCover, useScope, maxGrossWeight)
    if quote == nil then return nil, reason end
    if acceptedQuote ~= nil and (quote.annualPremium ~= acceptedQuote.annualPremium or quote.payableToday ~= acceptedQuote.payableToday) then
        return nil, "quote_changed", quote
    end
    if quote.payableToday > 0 and not self.businessAdministration:charge(farmId, quote.payableToday, "Individual vehicle insurance policy") then return nil, "funds" end

    local policy = self.repository:getVehicleInsurancePolicyByVehicle(farmId, vehicleUniqueId)
    if policy == nil then
        policy = {id=self.repository:getNextVehicleInsurancePolicyId(), farmId=farmId, vehicleUniqueId=tostring(vehicleUniqueId), totalPaid=0}
        self.repository:addVehicleInsurancePolicy(policy)
    end
    self:addPricingCoverage(policy, quote.startPeriod, quote.endPeriod)
    policy.autoRenew = policy.autoRenew == true
    policy.vehicleName = quote.vehicleName
    policy.coverType = quote.coverType
    policy.status = "ACTIVE"
    policy.source = "RFF_VEHICLE_POLICY"
    policy.startPeriod = quote.startPeriod
    policy.endPeriod = quote.endPeriod
    policy.lastRenewalPeriod = quote.startPeriod
    policy.graceUntilPeriod = 0
    policy.premiumDue = 0
    policy.lastPremium = quote.annualPremium
    policy.pricingBasePremium = quote.basePremium
    policy.pricingDiscountRate = quote.discountRate
    policy.pricingDiscountAmount = quote.discountAmount
    policy.pricingLoadingRate = quote.claimsLoadingRate
    policy.pricingLoadingAmount = quote.claimsLoadingAmount
    policy.pricingClaimCount = quote.recentClaims
    policy.pricingClaimFreeMonths = quote.claimFreeMonths
    policy.pricingPointsEnabled = quote.pointsPricingEnabled
    policy.pricingActivePoints = quote.activePenaltyPoints
    policy.pricingPointsRate = quote.pointsLoadingRate
    policy.pricingPointsAmount = quote.pointsLoadingAmount
    policy.totalPaid = math.max(0, safeNumber(policy.totalPaid, 0)) + quote.payableToday
    policy.insuredValue = quote.insuredValue
    policy.legalCover = quote.legalCover
    policy.useScope = quote.useScope
    policy.maxGrossWeight = quote.maxGrossWeight
    policy.temporaryCoverEndHour = 0
    policy.migrationSourceTier = ""
    policy.expiryNotified = false
    policy.lessorInterested = quote.lessorInterested == true
    policy.lessorNameKey = quote.lessorNameKey or ""
    policy.assetAgreementId = quote.assetAgreementId or 0
    local coverText = quote.coverType == self.COVER_THIRD_PARTY and "third-party" or "comprehensive"
    local paidText = g_i18n ~= nil and g_i18n.formatMoney ~= nil and g_i18n:formatMoney(quote.payableToday, 0, true, true) or tostring(quote.payableToday)
    if automaticRenewal == true then
        self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_auto_renewed_phone", "%s has automatically renewed for 12 months with the same cover, legal protection, use and weight terms. Premium paid: %s. Current discounts and loadings are included.", quote.vehicleName, paidText)
    elseif quote.lessorInterested then
        local lessorName = g_i18n ~= nil and quote.lessorNameKey ~= "" and g_i18n:getText(quote.lessorNameKey) or "the leasing company"
        self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_lease_policy_purchased_phone", "%s is insured under an individual comprehensive policy for 12 months. %s is recorded as the interested owner. Premium paid by the farm: %s.", quote.vehicleName, lessorName, paidText)
    else
        self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_policy_purchased_phone", "%s is insured under an individual %s policy for 12 months. Premium paid: %s.", quote.vehicleName, coverText, paidText)
    end
    return policy, "purchased", quote
end

function RFF_FleetManagementService:grantDealershipCover(farmId, vehicle)
    if self.repository == nil or vehicle == nil or not self:isDriveableFarmVehicle(vehicle, farmId) then return nil, "vehicle" end
    local ownership, agreement = self:getOwnership(vehicle)
    if ownership == "NATIVE_LEASE" then return nil, "lease" end
    local uniqueId = tostring(vehicle.uniqueId or "")
    if uniqueId == "" then return nil, "vehicle" end
    local existing = self.repository:getVehicleInsurancePolicyByVehicle(farmId, uniqueId)
    if existing ~= nil then return existing, "existing" end
    local current = self.repository:getCurrentPeriodIndex()
    local policy = {
        id = self.repository:getNextVehicleInsurancePolicyId(), farmId = farmId, vehicleUniqueId = uniqueId,
        vehicleName = getVehicleName(vehicle), coverType = ownership == "OPERATING_LEASE" and self.COVER_COMPREHENSIVE or self.COVER_THIRD_PARTY, status = "TEMPORARY",
        source = "DEALERSHIP_TEMPORARY", startPeriod = current, endPeriod = current + 1,
        lastRenewalPeriod = 0, graceUntilPeriod = 0, premiumDue = 0, lastPremium = 0, totalPaid = 0,
        insuredValue = self:getInsurableValue(vehicle, ownership, agreement), legalCover = false, useScope = self.USE_AGRICULTURAL_ROAD,
        maxGrossWeight = 0, temporaryCoverEndHour = self:getCurrentAbsoluteHour() + self.DEALERSHIP_COVER_HOURS,
        migrationSourceTier = "", expiryNotified = false,
        lessorInterested = ownership == "OPERATING_LEASE",
        lessorNameKey = agreement ~= nil and tostring(agreement.lenderNameKey or "") or "",
        assetAgreementId = agreement ~= nil and (agreement.id or 0) or 0
    }
    self.repository:addVehicleInsurancePolicy(policy)
    if self.businessAdministration ~= nil and self.businessAdministration.notify ~= nil then
        if ownership == "OPERATING_LEASE" then
            self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_lease_handover_cover_phone", "%s has %d in-game hours of temporary comprehensive handover cover because it is held under an operating lease. Arrange the farm's annual comprehensive policy before it expires.", policy.vehicleName, self.DEALERSHIP_COVER_HOURS)
        else
            self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_dealership_cover_phone", "%s has %d in-game hours of temporary third-party dealership cover. Arrange an annual policy before it expires.", policy.vehicleName, self.DEALERSHIP_COVER_HOURS)
        end
    end
    print(string.format("[RealisticFarmFinance] Dealership vehicle cover policy=RFF-VI-%06d farm=%d vehicle=%s hours=%d", policy.id or 0, farmId, uniqueId, self.DEALERSHIP_COVER_HOURS))
    return policy, "granted"
end

function RFF_FleetManagementService:ensurePerVehiclePolicyMigration(farmId)
    if self.repository == nil or g_currentMission == nil or g_currentMission.vehicleSystem == nil then return false, 0 end
    local state = self.repository:getFarmState(farmId, true)
    if state == nil or state.vehicleInsurancePerVehicleMigrated == true then return false, 0 end

    local candidates = {}
    local totalValue = 0
    for _, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles or {}) do
        if self:isDriveableFarmVehicle(vehicle, farmId) then
            local ownership = self:getOwnership(vehicle)
            if ownership ~= "OPERATING_LEASE" and ownership ~= "NATIVE_LEASE" then
                local value = self:getVehicleValue(vehicle)
                candidates[#candidates + 1] = {vehicle=vehicle, value=value}
                totalValue = totalValue + value
            end
        end
    end

    local current = self.repository:getCurrentPeriodIndex()
    local count = #candidates
    local migrated = 0
    for _, candidate in ipairs(candidates) do
        local vehicle = candidate.vehicle
        local uniqueId = tostring(vehicle.uniqueId or "")
        if uniqueId ~= "" and self.repository:getVehicleInsurancePolicyByVehicle(farmId, uniqueId) == nil then
            local share = totalValue > 0 and candidate.value / totalValue or (count > 0 and 1 / count or 0)
            local status = tostring(state.vehicleInsuranceStatus or "ACTIVE")
            local policy = {
                id = self.repository:getNextVehicleInsurancePolicyId(),
                farmId = farmId,
                vehicleUniqueId = uniqueId,
                vehicleName = getVehicleName(vehicle),
                coverType = self.COVER_COMPREHENSIVE,
                status = status,
                source = "MIGRATED_FARM_POLICY",
                startPeriod = (state.vehicleInsuranceLastRenewalPeriod or 0) > 0 and state.vehicleInsuranceLastRenewalPeriod or current,
                endPeriod = math.max(current + 1, state.vehicleInsuranceNextRenewalPeriod or current + 1),
                lastRenewalPeriod = state.vehicleInsuranceLastRenewalPeriod or 0,
                graceUntilPeriod = status == "GRACE" and math.max(current + 1, state.vehicleInsuranceGraceUntilPeriod or 0) or 0,
                premiumDue = math.max(0, safeNumber(state.vehicleInsurancePremiumDue, 0)) * share,
                lastPremium = math.max(0, safeNumber(state.vehicleInsuranceLastPremium, 0)) * share,
                totalPaid = math.max(0, safeNumber(state.vehicleInsuranceTotalPaid, 0)) * share,
                insuredValue = candidate.value,
                legalCover = false,
                useScope = "AGRICULTURAL_ROAD",
                maxGrossWeight = 0,
                temporaryCoverEndHour = 0,
                migrationSourceTier = tostring(state.vehicleInsuranceTier or "STANDARD"),
                expiryNotified = false
            }
            self.repository:addVehicleInsurancePolicy(policy)
            migrated = migrated + 1
        end
    end

    -- The individual records are now authoritative. Clear the transitional
    -- aggregate balance so it cannot be charged or counted a second time.
    state.vehicleInsurancePremiumDue = 0
    state.vehicleInsurancePerVehicleMigrated = true
    print(string.format("[RealisticFarmFinance] Migrated vehicle insurance farm=%d policies=%d currentVehicles=%d", farmId, migrated, count))
    return true, migrated
end

function RFF_FleetManagementService:getPolicyForVehicle(farmId, vehicle)
    if vehicle == nil or self.repository == nil then return nil end
    self:ensurePerVehiclePolicyMigration(farmId)
    local policy = self.repository:getVehicleInsurancePolicyByVehicle(farmId, tostring(vehicle.uniqueId or ""))
    if policy ~= nil then policy.vehicleName = getVehicleName(vehicle) end
    return policy
end

function RFF_FleetManagementService:getInsurance(vehicle, farmId, ownership)
    if ownership == "NATIVE_LEASE" then
        return "LEASED", false, nil
    end

    local policy = self:getPolicyForVehicle(farmId, vehicle)
    if policy == nil then return "UNINSURED", false, nil end
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local status = tostring(policy.status or "UNINSURED")
    if status == "TEMPORARY" and self:getTemporaryCoverHoursRemaining(policy) <= 0 then
        status = "EXPIRED"
        policy.status = status
    elseif status == "ACTIVE" and (policy.endPeriod or 0) <= current then
        status = "EXPIRED"
        policy.status = status
    end
    if status == "ACTIVE" or status == "GRACE" or status == "TEMPORARY" then return status, true, policy end
    return status, false, policy
end

function RFF_FleetManagementService:canSetAutoRenew(farmId, vehicleUniqueId)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return false end
    local policy = self.repository:getVehicleInsurancePolicyByVehicle(farmId, vehicleUniqueId)
    local vehicle = self:findVehicle(farmId, vehicleUniqueId)
    return policy ~= nil and policy.source == "RFF_VEHICLE_POLICY"
        and vehicle ~= nil and self:getOwnership(vehicle) ~= "NATIVE_LEASE"
end

function RFF_FleetManagementService:setAutoRenew(farmId, vehicleUniqueId, enabled)
    if not self:canSetAutoRenew(farmId, vehicleUniqueId) then return false end
    local policy = self.repository:getVehicleInsurancePolicyByVehicle(farmId, vehicleUniqueId)
    -- Enabling on an expired policy must not trigger an unexpected purchase or
    -- backdate cover. Buy/reinstate cover first; turning off remains available.
    if enabled == true and (policy.status ~= "ACTIVE" or (policy.endPeriod or 0) <= self.repository:getCurrentPeriodIndex()) then return false end
    policy.autoRenew = enabled == true
    return true
end

function RFF_FleetManagementService:tryAutoRenewPolicy(farmId, policy, current)
    if g_currentMission == nil or not g_currentMission:getIsServer() then return end
    if policy.autoRenew ~= true or policy.source ~= "RFF_VEHICLE_POLICY" then return end
    local endPeriod = safeNumber(policy.endPeriod, 0)
    if endPeriod <= 0 or current < endPeriod or safeNumber(policy.autoRenewAttemptEndPeriod, 0) >= endPeriod then return end
    if policy.status ~= "ACTIVE" and policy.status ~= "EXPIRED" then return end
    -- Persist one attempt per expiring term, including failures. A failed
    -- payment requires a manual purchase, not hourly silent retries.
    policy.autoRenewAttemptEndPeriod = endPeriod
    local vehicle = self:findVehicle(farmId, policy.vehicleUniqueId)
    if vehicle == nil or self:getOwnership(vehicle) == "NATIVE_LEASE" then return end
    local renewed, reason = self:purchasePolicy(farmId, policy.vehicleUniqueId, policy.coverType,
        policy.legalCover, policy.useScope, policy.maxGrossWeight, nil, true)
    if renewed == nil then
        policy.status = "EXPIRED"
        policy.expiryNotified = true
        local key = reason == "funds" and "rff_vehicle_auto_renew_failed_funds" or "rff_vehicle_auto_renew_failed"
        local fallback = reason == "funds"
            and "Auto-renewal for %s failed because the farm could not afford the premium. Cover has expired. Purchase a policy in Vehicles > Insurance to restore cover; no further automatic payment attempts will be made for this expiry."
            or "Auto-renewal for %s could not be completed. Cover has expired. Review and purchase a policy in Vehicles > Insurance to restore cover."
        if self.businessAdministration ~= nil then
            self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", key, fallback, tostring(policy.vehicleName or "Vehicle"))
        end
    end
end

function RFF_FleetManagementService:processPolicies(farmId, current)
    if g_currentMission == nil or not g_currentMission:getIsServer() then return end
    self:ensurePerVehiclePolicyMigration(farmId)
    for _, policy in ipairs(self.repository ~= nil and self.repository:getVehicleInsurancePoliciesByFarm(farmId) or {}) do
        self:tryAutoRenewPolicy(farmId, policy, current)
        local status = tostring(policy.status or "UNINSURED")
        if status == "GRACE" and current > (policy.graceUntilPeriod or 0) then
            policy.status = "LAPSED"
            status = "LAPSED"
        elseif status == "TEMPORARY" and self:getTemporaryCoverHoursRemaining(policy) <= 0 then
            policy.status = "EXPIRED"
            status = "EXPIRED"
        elseif status == "ACTIVE" and current >= (policy.endPeriod or 0) then
            policy.status = "EXPIRED"
            status = "EXPIRED"
        end
        if (status == "EXPIRED" or status == "LAPSED") and policy.expiryNotified ~= true then
            policy.expiryNotified = true
            if self.businessAdministration ~= nil and self.businessAdministration.notify ~= nil then
                self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_policy_expired_phone", "%s is now uninsured because its individual vehicle policy has expired.", tostring(policy.vehicleName or "Vehicle"))
            end
        end
    end
end

function RFF_FleetManagementService:payPolicyPremium(farmId, vehicleUniqueId)
    if self.repository == nil or self.businessAdministration == nil then return false, "service" end
    local policy = self.repository:getVehicleInsurancePolicyByVehicle(farmId, vehicleUniqueId)
    if policy == nil or safeNumber(policy.premiumDue, 0) <= 0.01 then return false, "nothing_due" end
    local premium = policy.premiumDue
    if not self.businessAdministration:charge(farmId, premium, "Outstanding individual vehicle insurance premium") then return false, "funds" end
    local current = self.repository:getCurrentPeriodIndex()
    policy.premiumDue = 0
    self:addPricingCoverage(policy, current, current + self.POLICY_TERM_PERIODS)
    policy.status = "ACTIVE"
    policy.startPeriod = current
    policy.lastRenewalPeriod = current
    policy.endPeriod = current + self.POLICY_TERM_PERIODS
    policy.graceUntilPeriod = 0
    policy.lastPremium = premium
    policy.totalPaid = math.max(0, safeNumber(policy.totalPaid, 0)) + premium
    policy.source = "RFF_VEHICLE_POLICY"
    policy.temporaryCoverEndHour = 0
    policy.expiryNotified = false
    self.businessAdministration:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_policy_reinstated_phone", "The outstanding premium for %s has been paid. Its individual vehicle policy is active.", tostring(policy.vehicleName or "Vehicle"))
    return true, "paid", policy
end

function RFF_FleetManagementService:onLoaded()
    if g_farmManager == nil then return end
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    for farmId, farm in pairs(g_farmManager.farmIdToFarm or {}) do
        if isPlayableFarm(farmId, farm) then
            self:ensurePerVehiclePolicyMigration(farmId)
            self:processPolicies(farmId, current)
        end
    end
end

function RFF_FleetManagementService:onHourChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or g_farmManager == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for farmId, farm in pairs(g_farmManager.farmIdToFarm or {}) do
        if isPlayableFarm(farmId, farm) then self:processPolicies(farmId, current) end
    end
end

function RFF_FleetManagementService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or g_farmManager == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for farmId, farm in pairs(g_farmManager.farmIdToFarm or {}) do
        if isPlayableFarm(farmId, farm) then
            self:processPolicies(farmId, current)
        end
    end
end

function RFF_FleetManagementService:getFleet(farmId)
    farmId = math.floor(safeNumber(farmId, 0))
    local result = {
        vehicles = {},
        vehicleCount = 0,
        adsAvailable = RFF_ADSIntegration ~= nil and RFF_ADSIntegration:isAvailable() or false,
        adsTrackedCount = 0,
        inspectionDueCount = 0,
        serviceDueCount = 0,
        insuredCount = 0,
        uninsuredCount = 0,
        expiredCount = 0,
        leasedCount = 0,
        outsidePolicyCount = 0,
        policyCount = 0
    }
    if farmId <= 0 or g_currentMission == nil or g_currentMission.vehicleSystem == nil then return result end

    self:ensurePerVehiclePolicyMigration(farmId)
    local currentPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0

    for _, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles or {}) do
        if self:isDriveableFarmVehicle(vehicle, farmId) then
            local ownership, agreement = self:getOwnership(vehicle)
            local ads = RFF_ADSIntegration ~= nil and RFF_ADSIntegration:getFleetMaintenanceRecord(vehicle) or {adsApplied=false}
            local lastInspection = ads.lastInspectionDate
            local inspectionDuePeriod = nil
            local inspectionDue = false
            if ads.adsApplied then
                if lastInspection ~= nil then
                    inspectionDuePeriod = lastInspection.year * 12 + lastInspection.month + self.INSPECTION_INTERVAL_PERIODS
                    inspectionDue = inspectionDuePeriod <= currentPeriod
                else
                    inspectionDue = true
                end
            end

            local serviceRemaining = nil
            local serviceDue = false
            if ads.adsApplied and safeNumber(ads.maintenanceIntervalHours, 0) > 0 then
                serviceRemaining = ads.maintenanceIntervalHours - safeNumber(ads.hoursSinceMaintenance, 0)
                serviceDue = serviceRemaining <= 0
            end

            local insuranceStatus, insured, policy = self:getInsurance(vehicle, farmId, ownership)
            local row = {
                vehicle = vehicle,
                uniqueId = tostring(vehicle.uniqueId or ""),
                name = getVehicleName(vehicle),
                ownership = ownership,
                assetAgreementId = agreement ~= nil and agreement.id or nil,
                assetAgreement = agreement,
                operatingHours = self:getOperatingHours(vehicle),
                adsApplied = ads.adsApplied == true,
                lastInspectionDate = lastInspection,
                inspectionDuePeriod = inspectionDuePeriod,
                inspectionDue = inspectionDue,
                lastServiceDate = ads.lastMaintenanceDate,
                serviceRemainingHours = serviceRemaining,
                serviceDue = serviceDue,
                insuranceStatus = insuranceStatus,
                insuranceCoverType = policy ~= nil and policy.coverType or nil,
                insurancePolicyId = policy ~= nil and policy.id or nil,
                insurancePolicy = policy,
                insured = insured
            }
            result.vehicles[#result.vehicles + 1] = row

            if row.adsApplied then result.adsTrackedCount = result.adsTrackedCount + 1 end
            if row.inspectionDue then result.inspectionDueCount = result.inspectionDueCount + 1 end
            if row.serviceDue then result.serviceDueCount = result.serviceDueCount + 1 end
            if row.insured then result.insuredCount = result.insuredCount + 1 end
            if insuranceStatus == "UNINSURED" then result.uninsuredCount = result.uninsuredCount + 1 end
            if insuranceStatus == "EXPIRED" or insuranceStatus == "LAPSED" then result.expiredCount = result.expiredCount + 1 end
            if policy ~= nil then result.policyCount = result.policyCount + 1 end
            if ownership == "OPERATING_LEASE" or ownership == "NATIVE_LEASE" then result.leasedCount = result.leasedCount + 1 end
            if ownership == "NATIVE_LEASE" then result.outsidePolicyCount = result.outsidePolicyCount + 1 end
        end
    end

    table.sort(result.vehicles, function(a, b)
        local aName = string.lower(tostring(a.name or ""))
        local bName = string.lower(tostring(b.name or ""))
        if aName == bName then return tostring(a.uniqueId or "") < tostring(b.uniqueId or "") end
        return aName < bName
    end)
    result.vehicleCount = #result.vehicles
    return result
end
