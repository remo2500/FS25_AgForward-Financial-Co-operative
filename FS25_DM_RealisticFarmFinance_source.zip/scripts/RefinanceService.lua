RFF_RefinanceService = {}
RFF_RefinanceService.__index = RFF_RefinanceService

RFF_RefinanceService.MODE_REFINANCE = "REFINANCE"
RFF_RefinanceService.MODE_CONSOLIDATE = "CONSOLIDATE"
RFF_RefinanceService.MIN_SETTLEMENT = 1000
RFF_RefinanceService.MAX_TERM_MONTHS = 240

local function safeNumber(value)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then return value end
    return 0
end

local function feeMoneyType()
    if MoneyType ~= nil then return MoneyType.LOAN_INTEREST or MoneyType.OTHER end
    return nil
end

local function copyTable(source)
    local result = {}
    for key, value in pairs(source or {}) do result[key] = value end
    return result
end

function RFF_RefinanceService.new(repository, loanService, relationshipService, marketService)
    local self = setmetatable({}, RFF_RefinanceService)
    self.repository = repository
    self.loanService = loanService
    self.relationshipService = relationshipService
    self.marketService = marketService
    return self
end

function RFF_RefinanceService:isEligibleLoan(loan)
    if loan == nil or loan.paidOff == true then return false, "inactive" end
    if loan.type ~= RFF_LoanService.TYPE_TERM
        and loan.type ~= RFF_LoanService.TYPE_BULLET
        and loan.type ~= RFF_LoanService.TYPE_REVOLVING then
        return false, "product"
    end
    if safeNumber(loan.arrearsBalance) > 0.01 or loan.currentDefault == true then return false, "arrears" end
    if self.loanService == nil or self.loanService:getLoanOutstanding(loan) < self.MIN_SETTLEMENT then return false, "balance" end
    return true, nil
end

function RFF_RefinanceService:getEligibleLoans(farmId)
    local result = {}
    if self.repository == nil then return result end
    for _, loan in ipairs(self.repository:getLoansByFarm(farmId, true)) do
        local eligible = self:isEligibleLoan(loan)
        if eligible then table.insert(result, loan) end
    end
    table.sort(result, function(a, b) return safeNumber(a.id) < safeNumber(b.id) end)
    return result
end

function RFF_RefinanceService:getLoanDebtService(loan)
    if loan == nil or loan.paidOff == true then return 0 end
    if loan.type == RFF_LoanService.TYPE_REVOLVING then
        return math.max(0, safeNumber(loan.drawnAmount)) * (safeNumber(loan.interestRate) / 100) / 12
    elseif loan.type == RFF_LoanService.TYPE_BULLET then
        return math.max(0, safeNumber(loan.principal)) * (safeNumber(loan.interestRate) / 100) / 12
    end
    return math.max(0, safeNumber(loan.monthlyPayment))
end

function RFF_RefinanceService:getSettlementTotal(loans)
    local total = 0
    for _, loan in ipairs(loans or {}) do total = total + self.loanService:getLoanOutstanding(loan) end
    return total
end

function RFF_RefinanceService:getExcludedDebtService(loans)
    local total = 0
    for _, loan in ipairs(loans or {}) do total = total + self:getLoanDebtService(loan) end
    return total
end

function RFF_RefinanceService:getTargetTerm(loans)
    local target = 12
    for _, loan in ipairs(loans or {}) do
        local remaining = math.max(12, safeNumber(loan.remainingMonths))
        if loan.type == RFF_LoanService.TYPE_REVOLVING then remaining = 36 end
        target = math.max(target, remaining)
    end
    return math.max(12, math.min(self.MAX_TERM_MONTHS, math.ceil(target / 12) * 12))
end

function RFF_RefinanceService:estimateRemainingInterest(loan)
    if loan == nil or loan.paidOff == true then return 0 end
    local principal = self.loanService:getLoanOutstanding(loan)
    if principal <= 0 then return 0 end
    if loan.type == RFF_LoanService.TYPE_REVOLVING then
        return principal * (safeNumber(loan.interestRate) / 100) / 12 * 36
    end
    local remaining = math.max(1, math.floor(safeNumber(loan.remainingMonths)))
    local schedule = self.loanService:getProjectedSchedule(loan, remaining)
    local interest = 0
    for _, row in ipairs(schedule or {}) do interest = interest + math.max(0, safeNumber(row.interest)) end
    return interest
end

function RFF_RefinanceService:getExistingProjectedInterest(loans)
    local total = 0
    for _, loan in ipairs(loans or {}) do total = total + self:estimateRemainingInterest(loan) end
    return total
end

function RFF_RefinanceService:getTargetsForLoan(loan)
    local eligible, reason = self:isEligibleLoan(loan)
    if not eligible then return nil, reason end
    return {loan}, nil
end

function RFF_RefinanceService:getConsolidationTargets(farmId)
    local loans = self:getEligibleLoans(farmId)
    if #loans < 2 then return nil, "not_enough_loans" end
    return loans, nil
end

function RFF_RefinanceService:buildEffectiveCredit(farmId, lenderId, credit, product, purpose, amount)
    local benefits = self.relationshipService ~= nil and self.relationshipService:getBenefits(farmId, lenderId)
        or {code="NEW", rateAdjustment=0, arrangementFeeFactor=1, ltvBonus=0, dscrTolerance=0}
    local market = self.marketService ~= nil and self.marketService:getMarketAdjustment(lenderId)
        or {state="SELECTIVE", rateAdjustment=0, feeFactor=1, collateralFactor=1, incomeFactor=1, dscrFloorAdjustment=0}
    local fit = self.marketService ~= nil and self.marketService:getDealAdjustment(lenderId, product, purpose, amount, nil)
        or {code="STANDARD", key="rff_market_fit_standard", available=true, rateAdjustment=0, feeFactor=1, collateralFactor=1, incomeFactor=1, dscrFloorAdjustment=0}
    if fit.available ~= true then return nil, benefits, market, fit end
    local effective = copyTable(credit)
    effective.monthlyIncome = math.max(0, safeNumber(credit ~= nil and credit.monthlyIncome))
        * math.max(0.75, safeNumber(market.incomeFactor)) * math.max(0.75, safeNumber(fit.incomeFactor))
        * math.max(0.75, 1 + safeNumber(benefits.dscrTolerance))
    effective.collateral = math.max(0, safeNumber(credit ~= nil and credit.collateral))
        * math.max(0.75, safeNumber(market.collateralFactor)) * math.max(0.75, safeNumber(fit.collateralFactor))
        * math.max(0.75, 1 + safeNumber(benefits.ltvBonus))
    return effective, benefits, market, fit
end

function RFF_RefinanceService:buildLenderQuote(farmId, lenderId, targets, settlement, termMonths, valuation, credit, excludedDebtService, purpose)
    local profile = self.marketService ~= nil and self.marketService:getProfile(lenderId) or nil
    if profile == nil then return nil, "lender" end

    purpose = purpose or "REFINANCE"
    local effectiveCredit, benefits, market, fit = self:buildEffectiveCredit(farmId, lenderId, credit, RFF_LoanService.TYPE_TERM, purpose, settlement)
    if effectiveCredit == nil or fit.available ~= true then return nil, "specialism_out_of_appetite" end
    local evaluation = self.loanService:evaluateApplication(
        farmId,
        settlement,
        termMonths,
        RFF_LoanService.TYPE_TERM,
        valuation,
        effectiveCredit,
        {excludedLiabilities=settlement, excludedDebtService=excludedDebtService}
    )
    if evaluation == nil or evaluation.approved ~= true then return nil, evaluation ~= nil and evaluation.reason or "underwriting" end

    fit = self.marketService ~= nil and self.marketService:getDealAdjustment(lenderId, RFF_LoanService.TYPE_TERM, purpose, settlement, evaluation.grade) or fit
    if fit.available ~= true then return nil, "specialism_out_of_appetite" end
    local rate = math.max(2.50,
        safeNumber(evaluation.interestRate)
        + safeNumber(profile.baseRateAdjustment)
        + safeNumber(benefits.rateAdjustment)
        + safeNumber(market.rateAdjustment)
        + safeNumber(fit.rateAdjustment))
    local payment = self.loanService:calculateMonthlyPayment(settlement, rate, termMonths, RFF_LoanService.TYPE_TERM)

    local remainingDebtService = math.max(0, safeNumber(evaluation.existingDebtService))
    local income = math.max(0, safeNumber(effectiveCredit.monthlyIncome))
    local finalDscr = remainingDebtService + payment > 0 and income / (remainingDebtService + payment) or math.huge
    if safeNumber(effectiveCredit.trackedPeriods) >= 3 and income > 0 then
        local floor = math.max(0.70, 0.80 + safeNumber(market.dscrFloorAdjustment) + safeNumber(fit.dscrFloorAdjustment))
        if finalDscr < floor then return nil, "affordability_after_pricing" end
    end

    local fee = settlement * safeNumber(profile.feePercent)
        * math.max(0.5, safeNumber(benefits.arrangementFeeFactor))
        * math.max(0.5, safeNumber(market.feeFactor))
        * math.max(0.5, safeNumber(fit.feeFactor))
    fee = math.floor(fee / 10 + 0.5) * 10

    local projectedInterest = math.max(0, payment * termMonths - settlement)
    return {
        approved=true,
        farmId=farmId,
        lenderId=lenderId,
        lenderNameKey=profile.nameKey,
        relationshipTier=benefits.code or "NEW",
        marketState=market.state or "SELECTIVE",
        dealFit=fit.code or "STANDARD",
        amount=settlement,
        termMonths=termMonths,
        interestRate=rate,
        monthlyPayment=payment,
        arrangementFee=fee,
        grade=evaluation.grade or "C",
        dscr=finalDscr,
        ltv=evaluation.ltv,
        projectedInterest=projectedInterest,
        totalFinanceCost=projectedInterest + fee
    }, nil
end

function RFF_RefinanceService:buildQuote(farmId, targets, mode)
    if self.repository == nil or self.loanService == nil or self.marketService == nil then return nil, "service" end
    if targets == nil or #targets == 0 then return nil, "targets" end
    if mode == self.MODE_CONSOLIDATE and #targets < 2 then return nil, "not_enough_loans" end

    local targetIds = {}
    for _, loan in ipairs(targets) do
        local eligible, reason = self:isEligibleLoan(loan)
        if not eligible or safeNumber(loan.farmId) ~= safeNumber(farmId) then return nil, reason or "invalid_target" end
        table.insert(targetIds, loan.id or 0)
    end

    local settlement = self:getSettlementTotal(targets)
    if settlement < self.MIN_SETTLEMENT then return nil, "balance" end
    local excludedDebtService = self:getExcludedDebtService(targets)
    local termMonths = self:getTargetTerm(targets)
    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    local conduct = self.loanService:getPaymentConduct(farmId)
    if conduct ~= nil and conduct.declineNewCredit then return nil, "payment_conduct" end

    local quotes = {}
    local declines = {}
    local purpose = mode == self.MODE_CONSOLIDATE and "DEBT_CONSOLIDATION" or "REFINANCE"
    for _, lenderId in ipairs(self.marketService.LENDER_ORDER or {}) do
        local quote, reason = self:buildLenderQuote(farmId, lenderId, targets, settlement, termMonths, valuation, credit, excludedDebtService, purpose)
        if quote ~= nil then table.insert(quotes, quote) else declines[lenderId] = reason end
    end
    if #quotes == 0 then return nil, "no_offers", {declines=declines, settlement=settlement, termMonths=termMonths} end

    table.sort(quotes, function(a, b)
        if math.abs(safeNumber(a.totalFinanceCost) - safeNumber(b.totalFinanceCost)) < 0.01 then
            return safeNumber(a.interestRate) < safeNumber(b.interestRate)
        end
        return safeNumber(a.totalFinanceCost) < safeNumber(b.totalFinanceCost)
    end)

    local best = quotes[1]
    best.mode = mode or self.MODE_REFINANCE
    best.targetLoanIds = targetIds
    best.targetLoanCount = #targetIds
    best.existingDebtService = excludedDebtService
    best.existingProjectedInterest = self:getExistingProjectedInterest(targets)
    best.monthlyDifference = excludedDebtService - safeNumber(best.monthlyPayment)
    best.projectedInterestDifference = best.existingProjectedInterest - (safeNumber(best.projectedInterest) + safeNumber(best.arrangementFee))
    best.createdPeriod = self.repository:getCurrentPeriodIndex()
    best.allQuotes = quotes
    return best, nil
end

function RFF_RefinanceService:getBestRefinanceQuote(farmId, loan)
    local targets, reason = self:getTargetsForLoan(loan)
    if targets == nil then return nil, reason end
    return self:buildQuote(farmId, targets, self.MODE_REFINANCE)
end

function RFF_RefinanceService:getBestConsolidationQuote(farmId)
    local targets, reason = self:getConsolidationTargets(farmId)
    if targets == nil then return nil, reason end
    return self:buildQuote(farmId, targets, self.MODE_CONSOLIDATE)
end

function RFF_RefinanceService:getLoansByIds(farmId, ids)
    local wanted = {}
    for _, id in ipairs(ids or {}) do wanted[safeNumber(id)] = true end
    local result = {}
    for _, loan in ipairs(self.repository ~= nil and self.repository:getLoansByFarm(farmId, true) or {}) do
        if wanted[safeNumber(loan.id)] then table.insert(result, loan) end
    end
    table.sort(result, function(a, b) return safeNumber(a.id) < safeNumber(b.id) end)
    return result
end

function RFF_RefinanceService:completeQuote(quote)
    if g_currentMission == nil or not g_currentMission:getIsServer() or quote == nil then return nil, "server_only" end
    if self.repository == nil or self.loanService == nil then return nil, "service" end
    local farmId = safeNumber(quote.farmId)
    if farmId <= 0 or safeNumber(quote.createdPeriod) ~= safeNumber(self.repository:getCurrentPeriodIndex()) then return nil, "quote_expired" end

    local targets = self:getLoansByIds(farmId, quote.targetLoanIds)
    if #targets ~= safeNumber(quote.targetLoanCount) then return nil, "changed" end
    local currentSettlement = self:getSettlementTotal(targets)
    if math.abs(currentSettlement - safeNumber(quote.amount)) > 1 then return nil, "changed" end
    for _, loan in ipairs(targets) do
        local eligible = self:isEligibleLoan(loan)
        if not eligible then return nil, "changed" end
    end

    local fee = math.max(0, safeNumber(quote.arrangementFee))
    if fee > 0 and not self.loanService:canAfford(farmId, fee) then return nil, "funds" end

    local formal = {
        approved=true,
        interestRate=quote.interestRate,
        monthlyPayment=quote.monthlyPayment,
        grade=quote.grade,
        lenderId=quote.lenderId,
        lenderNameKey=quote.lenderNameKey,
        arrangementFee=fee,
        brokerFee=0,
        brokered=false,
        brokerCaseId=0
    }
    local purpose = quote.mode == self.MODE_CONSOLIDATE and "DEBT_CONSOLIDATION" or "REFINANCE"
    local newLoan, reason = self.loanService:createLoanFromOffer(
        farmId,
        quote.amount,
        quote.termMonths,
        RFF_LoanService.TYPE_TERM,
        purpose,
        formal,
        {disburse=false}
    )
    if newLoan == nil then return nil, reason or "loan_create_failed" end

    local sourceIds = {}
    local sourceLenders = {}
    for _, loan in ipairs(targets) do
        table.insert(sourceIds, tostring(loan.id or 0))
        sourceLenders[loan.lenderId or "PRIMARY_BANK"] = true
        self.loanService:closeLoanAsRefinanced(loan, newLoan.id)
    end

    if fee > 0 then
        if self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(farmId, "Refinance arrangement fee") end
        g_currentMission:addMoney(-fee, farmId, feeMoneyType(), true, true)
    end

    newLoan.refinance = true
    newLoan.consolidation = quote.mode == self.MODE_CONSOLIDATE
    newLoan.refinanceSourceLoanIds = table.concat(sourceIds, ",")
    newLoan.refinanceSourceCount = #targets
    newLoan.refinanceSettlementAmount = quote.amount
    newLoan.refinancePreviousDebtService = quote.existingDebtService or 0
    newLoan.refinancePreviousProjectedInterest = quote.existingProjectedInterest or 0
    newLoan.refinanceMarketState = quote.marketState or "SELECTIVE"
    newLoan.refinanceDealFit = quote.dealFit or "STANDARD"
    newLoan.refinanceRelationshipTier = quote.relationshipTier or "NEW"

    if self.relationshipService ~= nil then
        self.relationshipService:recordOffer(farmId, quote.lenderId)
        self.relationshipService:recordAcceptedDeal(farmId, quote.lenderId, quote.amount, false)
    end

    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(quote.lenderNameKey, "Lender")
        local title = RFF_NotificationService:getText("rff_phone_title_refinance_complete", "Refinance Complete")
        local message = RFF_NotificationService:formatText("rff_phone_refinance_complete",
            "Your refinance has completed. %s has replaced %d existing agreement(s) at %.2f%% over %d months.",
            g_i18n ~= nil and g_i18n:formatMoney(quote.amount or 0, 0, true, true) or tostring(quote.amount or 0), #targets, quote.interestRate or 0, quote.termMonths or 0)
        RFF_NotificationService:send(farmId, sender, title, message, "refinance", message, false)
    end

    print(string.format("[RealisticFarmFinance] Refinance completed farm=%d newLoan=%d lender=%s settlement=%.2f sources=%s rate=%.2f term=%d fee=%.2f",
        farmId, newLoan.id or 0, tostring(newLoan.lenderId), quote.amount or 0, table.concat(sourceIds, ","), quote.interestRate or 0, quote.termMonths or 0, fee))
    return newLoan, nil
end
