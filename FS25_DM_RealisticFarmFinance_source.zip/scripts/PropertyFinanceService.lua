RFF_PropertyFinanceService = {}
RFF_PropertyFinanceService.__index = RFF_PropertyFinanceService

RFF_PropertyFinanceService.MORTGAGE_DOWN_PAYMENTS = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50}
RFF_PropertyFinanceService.MORTGAGE_TERMS = {60, 120, 180, 240, 300, 360}
RFF_PropertyFinanceService.EQUITY_RELEASE_ADVANCE_PCTS = {10, 20, 30, 40, 50, 60}
RFF_PropertyFinanceService.EQUITY_RELEASE_TERMS = {60, 120, 180, 240, 300, 360}
RFF_PropertyFinanceService.EQUITY_RELEASE_BASE_MAX_LTV = 0.60
RFF_PropertyFinanceService.EQUITY_RELEASE_MAX_OVERALL_LTV = 0.75
RFF_PropertyFinanceService.EQUITY_RELEASE_RATE_UPLIFT = 0.35
RFF_PropertyFinanceService.EQUITY_RELEASE_SECURED_RATE_UPLIFT = 1.00
RFF_PropertyFinanceService.TENANCY_TERMS = {12, 24, 36, 60}
RFF_PropertyFinanceService.MAX_TENANCY_MISSED = 3
RFF_PropertyFinanceService.MORTGAGE_RESTRUCTURE_EXTENSION_MONTHS = 12
RFF_PropertyFinanceService.MORTGAGE_RESTRUCTURE_RATE_UPLIFT = 0.75
RFF_PropertyFinanceService.MORTGAGE_RESTRUCTURE_MAX_LTV = 0.90
RFF_PropertyFinanceService.MORTGAGE_VOLUNTARY_REALISATION_FACTOR = 0.97
RFF_PropertyFinanceService.MORTGAGE_FORCED_REALISATION_FACTOR = 0.90
RFF_PropertyFinanceService.MORTGAGE_VOLUNTARY_COST_RATE = 0.01
RFF_PropertyFinanceService.MORTGAGE_FORCED_COST_RATE = 0.04
RFF_PropertyFinanceService.MORTGAGE_MIN_RECOVERY_COST = 500
RFF_PropertyFinanceService.MORTGAGE_MAX_RECOVERY_COST = 15000
RFF_PropertyFinanceService.FIXTURE_VOLUNTARY_REALISATION_FACTOR = 0.90
RFF_PropertyFinanceService.FIXTURE_FORCED_REALISATION_FACTOR = 0.70
RFF_PropertyFinanceService.FORCED_LIVESTOCK_REALISATION_FACTOR = 0.80
-- Asset-backed agricultural mortgage route. A mainstream lender can still support a
-- weak-DSCR farm where the advance is modest against both the property and wider security.
RFF_PropertyFinanceService.MORTGAGE_SECURED_MAX_PROPERTY_LTV = 0.60
RFF_PropertyFinanceService.MORTGAGE_SECURED_MAX_OVERALL_LTV = 0.70
RFF_PropertyFinanceService.MORTGAGE_SECURED_RATE_UPLIFT = 1.50

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local TENANCY_MONTH_KEYS = {
    "rff_month_january", "rff_month_february", "rff_month_march", "rff_month_april",
    "rff_month_may", "rff_month_june", "rff_month_july", "rff_month_august",
    "rff_month_september", "rff_month_october", "rff_month_november", "rff_month_december"
}

local TENANCY_MONTH_FALLBACKS = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
}

local function formatTenancyPeriod(period)
    period = math.max(0, math.floor(safeNumber(period)))
    if period <= 0 then return "unscheduled" end
    local year = math.floor((period - 1) / 12)
    local seasonPeriod = ((period - 1) % 12) + 1
    local calendarMonth = ((seasonPeriod + 1) % 12) + 1
    local monthName = TENANCY_MONTH_FALLBACKS[calendarMonth]
    if g_i18n ~= nil and g_i18n.formatPeriod ~= nil then
        monthName = g_i18n:formatPeriod(seasonPeriod, false)
    elseif g_i18n ~= nil and g_i18n.getText ~= nil then
        local translated = g_i18n:getText(TENANCY_MONTH_KEYS[calendarMonth])
        if translated ~= nil and translated ~= "" and translated ~= TENANCY_MONTH_KEYS[calendarMonth] then
            monthName = translated
        end
    end
    return string.format("%s Y%d", monthName, year)
end

local function tenancyHasRecordedGrass(tenancy)
    if tenancy == nil or type(tenancy.parcelConditions) ~= "table" or #tenancy.parcelConditions == 0 then return nil end
    for _, parcel in ipairs(tenancy.parcelConditions) do
        if tostring(parcel.initialUse or parcel.currentUse or ""):upper() == "GRASS" then return true end
    end
    return false
end

local function deterministicUnit(value)
    local hash = 0
    for index = 1, #tostring(value or "") do
        hash = (hash * 31 + string.byte(tostring(value), index)) % 2147483647
    end
    return (hash % 10001) / 10000
end

local function getSavegameDirectory()
    if g_currentMission == nil or g_currentMission.missionInfo == nil then return nil end
    local path = g_currentMission.missionInfo.savegameDirectory
    if path == nil and g_currentMission.missionInfo.savegameIndex ~= nil then
        path = string.format("%ssavegame%d", getUserProfileAppPath(), g_currentMission.missionInfo.savegameIndex)
    end
    return path
end

local function getFarmlandMarketEnvironment()
    if type(g_modIsLoaded) ~= "table" or g_modIsLoaded["FS25_FarmlandMarket"] ~= true then return nil end
    if type(_G) ~= "table" then return nil end
    -- GIANTS gives each mod its own _G, with shared mod environments
    -- inherited through __index. rawget here incorrectly reports it absent.
    local environment = _G["FS25_FarmlandMarket"]
    return type(environment) == "table" and environment or nil
end

local function parseIdList(value)
    local result = {}
    local seen = {}
    for token in tostring(value or ""):gmatch("[^,]+") do
        local id = math.floor(tonumber(token) or 0)
        if id > 0 and not seen[id] then
            seen[id] = true
            table.insert(result, id)
        end
    end
    table.sort(result)
    return result
end

local function joinIdList(ids)
    local parts = {}
    for _, id in ipairs(ids or {}) do
        id = math.floor(safeNumber(id))
        if id > 0 then table.insert(parts, tostring(id)) end
    end
    return table.concat(parts, ",")
end

local function farmMoney(farmId)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    return farm ~= nil and safeNumber(farm.money) or 0
end

local function moneyTypeFallback()
    if MoneyType ~= nil then
        return MoneyType.FIELD_BUY or MoneyType.FIELD_LEASE or MoneyType.OTHER
    end
    return nil
end

local function nonOperatingLiquidationMoneyType()
    if MoneyType ~= nil then
        return MoneyType.OTHER or MoneyType.PROPERTY_INCOME or MoneyType.FIELD_BUY or MoneyType.FIELD_LEASE
    end
    return nil
end

function RFF_PropertyFinanceService.new(repository, loanService, narrativeService)
    local self = setmetatable({}, RFF_PropertyFinanceService)
    self.repository = repository
    self.loanService = loanService
    self.narrativeService = narrativeService
    self.relationshipService = nil
    self.marketService = nil
    self.farmlandMarketAvailabilityLoaded = false
    self.farmlandMarketAvailabilityEnabled = false
    self.farmlandMarketAvailability = {}
    self.farmlandMarketAvailabilityKnown = false
    return self
end

function RFF_PropertyFinanceService:setRelationshipService(service)
    self.relationshipService = service
end

function RFF_PropertyFinanceService:setMarketService(service)
    self.marketService = service
end

function RFF_PropertyFinanceService:formatTenancyPeriod(period)
    return formatTenancyPeriod(period)
end

function RFF_PropertyFinanceService:getFarmland(farmlandId)
    return g_farmlandManager ~= nil and g_farmlandManager:getFarmlandById(farmlandId) or nil
end

-- Farmland Market remains authoritative while it is active. Its public
-- availability function accounts for both the current preset and live daily
-- listing changes. The saved XML is only a fallback when the active mod has
-- been positively detected but its public API is temporarily unavailable.
function RFF_PropertyFinanceService:loadSavedFarmlandMarketAvailability()
    if self.farmlandMarketAvailabilityLoaded then return end
    self.farmlandMarketAvailabilityLoaded = true
    self.farmlandMarketAvailabilityEnabled = false
    self.farmlandMarketAvailability = {}

    local directory = getSavegameDirectory()
    if directory == nil then return end
    local xmlFile = XMLFile.loadIfExists("rffFarmlandMarketCompatibility", directory .. "/rm_FarmlandMarket.xml", "rmFarmlandMarket")
    if xmlFile == nil then return end
    self.farmlandMarketAvailabilityKnown = true

    local preset = xmlFile:getInt("rmFarmlandMarket.settings#availabilityPreset")
    self.farmlandMarketAvailabilityEnabled = preset == nil or preset ~= 1
    local index = 0
    local unavailable = 0
    while self.farmlandMarketAvailabilityEnabled do
        local key = string.format("rmFarmlandMarket.availability.farmland(%d)", index)
        if not xmlFile:hasProperty(key) then break end
        local farmlandId = math.floor(safeNumber(xmlFile:getInt(key .. "#id")))
        if farmlandId > 0 then
            local isForSale = xmlFile:getBool(key .. "#isForSale") == true
            self.farmlandMarketAvailability[farmlandId] = isForSale
            if not isForSale then unavailable = unavailable + 1 end
        end
        index = index + 1
    end
    xmlFile:delete()

    print(string.format("[RealisticFarmFinance] Farmland Market compatibility loaded: preset=%s entries=%d unavailable=%d",
        tostring(preset or "legacy"), index, unavailable))
end

function RFF_PropertyFinanceService:isFarmlandAvailableForAcquisition(farmlandId)
    farmlandId = math.floor(safeNumber(farmlandId))
    if farmlandId <= 0 then return false end

    -- The active-mod flag, not successful API resolution, decides whether
    -- this integration applies. Stale XML must never block an inactive mod.
    if type(g_modIsLoaded) ~= "table" or g_modIsLoaded["FS25_FarmlandMarket"] ~= true then return true end
    local environment = getFarmlandMarketEnvironment()
    local liveAvailability = environment ~= nil and environment.RmFmAvailability or nil
    if type(liveAvailability) == "table" and type(liveAvailability.isForSale) == "function" then
        local ok, isForSale = pcall(liveAvailability.isForSale, farmlandId)
        if ok and type(isForSale) == "boolean" then return isForSale end
    end

    self:loadSavedFarmlandMarketAvailability()
    if not self.farmlandMarketAvailabilityKnown then return false end
    if not self.farmlandMarketAvailabilityEnabled then return true end
    local saved = self.farmlandMarketAvailability[farmlandId]
    return saved == true
end

function RFF_PropertyFinanceService:getMortgageSecurityFarmlandIds(loan)
    if loan == nil then return {} end
    local ids = parseIdList(loan.securityFarmlandIds)
    if #ids == 0 and safeNumber(loan.securityFarmlandId) > 0 then
        table.insert(ids, math.floor(safeNumber(loan.securityFarmlandId)))
    end
    return ids
end

function RFF_PropertyFinanceService:getMortgageSecurityLabel(loan)
    local ids = self:getMortgageSecurityFarmlandIds(loan)
    if #ids == 0 then return "Property security" end
    if #ids == 1 then return string.format("Land %d", ids[1]) end
    return string.format("%d land parcels (%s)", #ids, table.concat(ids, ", "))
end

function RFF_PropertyFinanceService:getPlaceableOwnerFarmId(placeable)
    if placeable == nil then return 0 end
    if RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService.getPlaceableLegalOwnerFarmId ~= nil then
        return math.floor(safeNumber(RFF_TenancyAccessService:getPlaceableLegalOwnerFarmId(placeable)))
    end
    if placeable.getOwnerFarmId ~= nil then
        local ok, farmId = pcall(placeable.getOwnerFarmId, placeable)
        if ok and farmId ~= nil then return math.floor(safeNumber(farmId)) end
    end
    return math.floor(safeNumber(placeable.ownerFarmId))
end

function RFF_PropertyFinanceService:getPlaceableFarmlandId(placeable)
    if placeable == nil or g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return 0 end
    local node = placeable.rootNode or placeable.nodeId
    if node == nil or node == 0 then return 0 end
    local okPos, x, _, z = pcall(getWorldTranslation, node)
    if not okPos then return 0 end
    local okLand, farmlandId = pcall(g_farmlandManager.getFarmlandIdAtWorldPosition, g_farmlandManager, x, z)
    if not okLand then return 0 end
    return math.floor(safeNumber(farmlandId))
end

function RFF_PropertyFinanceService:getPlaceableSellValue(placeable)
    if placeable == nil or placeable.getSellPrice == nil then return 0 end
    local ok, value = pcall(placeable.getSellPrice, placeable)
    if ok then return math.max(0, safeNumber(value)) end
    return 0
end

function RFF_PropertyFinanceService:getPlaceableDisplayName(placeable)
    if placeable ~= nil and placeable.getName ~= nil then
        local ok, name = pcall(placeable.getName, placeable)
        if ok and name ~= nil and name ~= "" then return tostring(name) end
    end
    local storeItem = placeable ~= nil and placeable.storeItem or nil
    return storeItem ~= nil and tostring(storeItem.name or storeItem.rawName or "Tenant fixture") or "Tenant fixture"
end

function RFF_PropertyFinanceService:getPlaceableCategory(placeable)
    if placeable ~= nil and (placeable.spec_husbandryAnimals ~= nil or placeable.spec_husbandry ~= nil) then return "HUSBANDRY" end
    if placeable ~= nil and (placeable.spec_fence ~= nil or placeable.spec_newFence ~= nil) then return "FENCE" end
    local storeItem = placeable ~= nil and placeable.storeItem or nil
    return tostring(storeItem ~= nil and (storeItem.categoryName or storeItem.categoryNameLong or storeItem.category) or "PLACEABLE")
end

-- Once possession ends, a fixture left behind is not a late opportunity to
-- liquidate an asset from land the former tenant no longer occupies. Transfer
-- every tenant-owned placeable still rooted on the holding to the underlying
-- farmland owner. RFF tenancies normally use GIANTS'
-- no-owner estate identity, which represents the NPC landlord without creating
-- a playable farm. Placeable:setOwnerFarmId() persists and synchronises the
-- change, so the former tenant cannot sell the asset after access is withdrawn.
function RFF_PropertyFinanceService:forfeitTenantPlaceables(tenancy, reason)
    local result = {count=0, value=0, failed=0}
    if tenancy == nil or g_currentMission == nil or not g_currentMission:getIsServer()
        or g_currentMission.placeableSystem == nil then return result end
    if tenancy.forfeitureProcessed == true then
        result.count = math.max(0, math.floor(safeNumber(tenancy.forfeitedPlaceableCount)))
        result.value = math.max(0, safeNumber(tenancy.forfeitedPlaceableValue))
        return result
    end

    local tenantFarmId = math.floor(safeNumber(tenancy.farmId))
    local farmlandSet = {}
    for _, value in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
        local farmlandId = math.floor(safeNumber(value))
        if farmlandId > 0 then farmlandSet[farmlandId] = true end
    end
    if tenantFarmId <= 0 or next(farmlandSet) == nil then
        tenancy.forfeitureProcessed = true
        return result
    end

    local noOwnerFarmId = FarmlandManager ~= nil and FarmlandManager.NO_OWNER_FARM_ID or 0
    local currentPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local currentDay = self:getCurrentDay()
    tenancy.alterations = tenancy.alterations or {}
    tenancy.alterationNextId = math.max(1, math.floor(safeNumber(tenancy.alterationNextId or 1)))

    for _, placeable in pairs(g_currentMission.placeableSystem.placeables or {}) do
        if placeable ~= nil and placeable.isDeleted ~= true
            and self:getPlaceableOwnerFarmId(placeable) == tenantFarmId then
            local farmlandId = self:getPlaceableFarmlandId(placeable)
            if farmlandSet[farmlandId] then
                local landlordFarmId = noOwnerFarmId
                if g_farmlandManager ~= nil and g_farmlandManager.getFarmlandOwner ~= nil then
                    landlordFarmId = math.floor(safeNumber(g_farmlandManager:getFarmlandOwner(farmlandId)))
                end
                if landlordFarmId == tenantFarmId then landlordFarmId = noOwnerFarmId end

                local assetName = self:getPlaceableDisplayName(placeable)
                local sellValue = self:getPlaceableSellValue(placeable)
                local node = placeable.rootNode or placeable.nodeId
                local worldX, worldZ = 0, 0
                if node ~= nil and node ~= 0 then
                    local okPosition, x, _, z = pcall(getWorldTranslation, node)
                    if okPosition then worldX, worldZ = safeNumber(x), safeNumber(z) end
                end

                -- A few placeable types can purchase their supporting farmland when
                -- ownership changes. Disable that side effect for this transfer only;
                -- the tenancy land itself must remain with the NPC landlord.
                local buysFarmland = placeable.buysFarmland
                if buysFarmland == true then placeable.buysFarmland = false end
                local transferred = placeable.setOwnerFarmId ~= nil
                    and pcall(placeable.setOwnerFarmId, placeable, landlordFarmId) or false
                if buysFarmland == true then placeable.buysFarmland = true end

                if transferred and self:getPlaceableOwnerFarmId(placeable) ~= tenantFarmId then
                    result.count = result.count + 1
                    result.value = result.value + sellValue
                    -- The fixture is no longer an independently tradeable tenant
                    -- asset. GIANTS uses this savegame override when farmland is
                    -- sold so ownership follows the land on every later transfer.
                    -- Set the runtime flag too because PlaceableSystem's sale check
                    -- reads the base field directly during the current session.
                    self:promotePlaceableToFarmlandAsset(placeable)
                    placeable.rffCovenantForfeitedAgreementId = tenancy.agreementId or tenancy.id
                    local handback = tostring(reason or ""):upper() == "HAND_BACK"
                    local alteration = {
                        id=tenancy.alterationNextId, alterationType="PLACEABLE_FORFEITED",
                        farmlandId=farmlandId, period=currentPeriod, day=currentDay,
                        ownerFarmId=landlordFarmId, assetOwnership="LANDLORD",
                        assetName=assetName, category=self:getPlaceableCategory(placeable),
                        worldX=worldX, worldZ=worldZ, value=sellValue, quantity=1,
                        status="FORFEITED", consentReference="",
                        details=handback
                            and "Tenant fixture left on the holding transferred to the landlord without compensation at handback"
                            or "Tenant fixture transferred to the landlord without compensation following covenant termination"
                    }
                    tenancy.alterationNextId = tenancy.alterationNextId + 1
                    tenancy.alterationLatestId = alteration.id
                    table.insert(tenancy.alterations, alteration)
                    print(string.format("[RealisticFarmFinance] Covenant fixture forfeited agreement=%s land=%d asset=%s formerOwner=%d landlordOwner=%d formerSellValue=%.2f",
                        tostring(tenancy.agreementId or tenancy.id), farmlandId, assetName,
                        tenantFarmId, landlordFarmId, sellValue))
                else
                    result.failed = result.failed + 1
                    print(string.format("[RealisticFarmFinance] Covenant fixture forfeiture failed agreement=%s land=%d asset=%s owner=%d",
                        tostring(tenancy.agreementId or tenancy.id), farmlandId, assetName,
                        self:getPlaceableOwnerFarmId(placeable)))
                end
            end
        end
    end

    tenancy.forfeitedPlaceableCount = math.max(0, math.floor(safeNumber(tenancy.forfeitedPlaceableCount))) + result.count
    tenancy.forfeitedPlaceableValue = math.max(0, safeNumber(tenancy.forfeitedPlaceableValue)) + result.value
    tenancy.forfeiturePeriod = math.max(0, math.floor(safeNumber(currentPeriod)))
    tenancy.forfeitureProcessed = result.failed == 0
    result.count = tenancy.forfeitedPlaceableCount
    result.value = tenancy.forfeitedPlaceableValue
    if g_messageCenter ~= nil then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, tenantFarmId) end
    print(string.format("[RealisticFarmFinance] Covenant fixture forfeiture completed agreement=%s count=%d formerSellValue=%.2f failed=%d",
        tostring(tenancy.agreementId or tenancy.id), result.count, result.value, result.failed))
    return result
end

-- v1.1.11.2 transferred surviving fixtures to the landlord, but did not mark
-- them as assets conveyed with the farmland. Match those already-recorded
-- forfeitures by their persistent alteration position, apply GIANTS' farmland
-- conveyance override and synchronise ownership with the land's current owner.
-- Running this on every load also restores the runtime base flag which GIANTS'
-- placeable sale check reads directly rather than through the savegame override.
function RFF_PropertyFinanceService:reconcileForfeitedPlaceableConveyance(tenancy)
    local result = {matched=0, changed=0}
    if tenancy == nil or g_currentMission == nil or not g_currentMission:getIsServer()
        or g_currentMission.placeableSystem == nil then return result end

    local records = {}
    for _, alteration in ipairs(tenancy.alterations or {}) do
        if alteration.alterationType == "PLACEABLE_FORFEITED" then
            table.insert(records, alteration)
        end
    end
    if #records == 0 then return result end

    local matchedPlaceables = {}
    for _, alteration in ipairs(records) do
        local recordedFarmlandId = math.floor(safeNumber(alteration.farmlandId))
        local recordedX = safeNumber(alteration.worldX)
        local recordedZ = safeNumber(alteration.worldZ)
        local bestPlaceable, bestDistanceSq = nil, nil

        for _, placeable in pairs(g_currentMission.placeableSystem.placeables or {}) do
            if placeable ~= nil and placeable.isDeleted ~= true and matchedPlaceables[placeable] ~= true
                and self:getPlaceableFarmlandId(placeable) == recordedFarmlandId then
                local node = placeable.rootNode or placeable.nodeId
                if node ~= nil and node ~= 0 then
                    local okPosition, x, _, z = pcall(getWorldTranslation, node)
                    if okPosition then
                        local dx = safeNumber(x) - recordedX
                        local dz = safeNumber(z) - recordedZ
                        local distanceSq = dx * dx + dz * dz
                        if distanceSq <= 25 and (bestDistanceSq == nil or distanceSq < bestDistanceSq) then
                            bestPlaceable = placeable
                            bestDistanceSq = distanceSq
                        end
                    end
                end
            end
        end

        if bestPlaceable ~= nil then
            matchedPlaceables[bestPlaceable] = true
            result.matched = result.matched + 1
            local ownerBefore = self:getPlaceableOwnerFarmId(bestPlaceable)
            local hadConveyanceOverride = bestPlaceable.boughtWithFarmlandSavegameOverwrite == true
            self:promotePlaceableToFarmlandAsset(bestPlaceable)
            bestPlaceable.rffCovenantForfeitedAgreementId = tenancy.agreementId or tenancy.id

            if bestPlaceable.updateOwnership ~= nil then
                local buysFarmland = bestPlaceable.buysFarmland
                if buysFarmland == true then bestPlaceable.buysFarmland = false end
                pcall(bestPlaceable.updateOwnership, bestPlaceable)
                if buysFarmland == true then bestPlaceable.buysFarmland = true end
            end

            local ownerAfter = self:getPlaceableOwnerFarmId(bestPlaceable)
            if hadConveyanceOverride ~= true or ownerAfter ~= ownerBefore then
                result.changed = result.changed + 1
                print(string.format("[RealisticFarmFinance] Covenant fixture attached to farmland agreement=%s land=%d asset=%s ownerBefore=%d ownerAfter=%d",
                    tostring(tenancy.agreementId or tenancy.id), recordedFarmlandId,
                    self:getPlaceableDisplayName(bestPlaceable), ownerBefore, ownerAfter))
            end
        end
    end

    if result.changed > 0 and g_messageCenter ~= nil then
        g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, math.floor(safeNumber(tenancy.farmId)))
    end
    return result
end

function RFF_PropertyFinanceService:getHusbandryLivestockValue(placeable)
    local result = {animalCount=0, marketValue=0}
    if placeable == nil then return result end
    local animalSpec = placeable.spec_husbandryAnimals
    local clusterSystem = animalSpec ~= nil and animalSpec.clusterSystem or nil
    local animalSystem = g_currentMission ~= nil and g_currentMission.animalSystem or nil
    if clusterSystem == nil or animalSystem == nil then return result end

    local function directSellValue(animal)
        if animal ~= nil and animal.getSellPrice ~= nil then
            local ok, value = pcall(animal.getSellPrice, animal)
            if ok and type(value) == "number" and value == value and value > 0 then return value end
        end
        return nil
    end

    local function countOf(animal)
        if animal == nil then return 0 end
        if animal.getNumAnimals ~= nil then
            local ok, value = pcall(animal.getNumAnimals, animal)
            if ok and safeNumber(value) > 0 then return math.max(1, math.floor(safeNumber(value))) end
        end
        return math.max(1, math.floor(safeNumber(animal.numAnimals or 1)))
    end

    local function fallbackUnitValue(cluster)
        local direct = directSellValue(cluster)
        if direct ~= nil then return direct end
        local subTypeIndex = cluster ~= nil and (cluster.subTypeIndex or (cluster.getSubTypeIndex ~= nil and cluster:getSubTypeIndex())) or nil
        local subType = subTypeIndex ~= nil and animalSystem.subTypes ~= nil and animalSystem.subTypes[subTypeIndex] or nil
        if subType ~= nil and subType.sellPrice ~= nil and subType.sellPrice.get ~= nil then
            local age = cluster.age or (cluster.getAge ~= nil and cluster:getAge()) or 0
            local ok, unitPrice = pcall(subType.sellPrice.get, subType.sellPrice, age)
            if ok and safeNumber(unitPrice) > 0 then
                local health = math.max(0, math.min(100, safeNumber(cluster.health))) / 100
                return math.max(0, safeNumber(unitPrice) * (0.4 + 0.6 * health))
            end
        end
        return 0
    end

    local usedIndividuals = false
    if type(clusterSystem.animals) == "table" then
        for _, animal in pairs(clusterSystem.animals) do
            local value = directSellValue(animal)
            if value ~= nil then
                local count = countOf(animal)
                result.animalCount = result.animalCount + count
                result.marketValue = result.marketValue + value * count
                usedIndividuals = true
            end
        end
    end

    if not usedIndividuals then
        local clusters = nil
        if clusterSystem.getClusters ~= nil then
            local ok, values = pcall(clusterSystem.getClusters, clusterSystem)
            if ok then clusters = values end
        end
        clusters = clusters or clusterSystem.clusters or {}
        for _, cluster in pairs(clusters) do
            local count = countOf(cluster)
            result.animalCount = result.animalCount + count
            result.marketValue = result.marketValue + fallbackUnitValue(cluster) * count
        end
    end
    return result
end

function RFF_PropertyFinanceService:getMortgageRecoveryFixtures(loan, voluntary)
    local result = {
        placeables={}, placeableCount=0, husbandryCount=0,
        fixtureMarketValue=0, fixtureRealisedValue=0,
        animalCount=0, livestockMarketValue=0, livestockRealisedValue=0
    }
    if loan == nil or g_currentMission == nil or g_currentMission.placeableSystem == nil then return result end
    local securitySet = {}
    for _, farmlandId in ipairs(self:getMortgageSecurityFarmlandIds(loan)) do securitySet[farmlandId] = true end
    if next(securitySet) == nil then return result end

    for _, placeable in pairs(g_currentMission.placeableSystem.placeables or {}) do
        if placeable ~= nil and placeable.isDeleted ~= true and self:getPlaceableOwnerFarmId(placeable) == loan.farmId then
            local farmlandId = self:getPlaceableFarmlandId(placeable)
            if securitySet[farmlandId] then
                local sellValue = self:getPlaceableSellValue(placeable)
                local livestock = self:getHusbandryLivestockValue(placeable)
                local item = {
                    placeable=placeable, farmlandId=farmlandId, sellValue=sellValue,
                    animalCount=livestock.animalCount, livestockMarketValue=livestock.marketValue
                }
                table.insert(result.placeables, item)
                result.placeableCount = result.placeableCount + 1
                result.fixtureMarketValue = result.fixtureMarketValue + sellValue
                if placeable.spec_husbandryAnimals ~= nil then result.husbandryCount = result.husbandryCount + 1 end
                result.animalCount = result.animalCount + livestock.animalCount
                result.livestockMarketValue = result.livestockMarketValue + livestock.marketValue
            end
        end
    end

    local fixtureFactor = voluntary == true and self.FIXTURE_VOLUNTARY_REALISATION_FACTOR or self.FIXTURE_FORCED_REALISATION_FACTOR
    result.fixtureRealisedValue = result.fixtureMarketValue * fixtureFactor
    if voluntary ~= true then
        result.livestockRealisedValue = result.livestockMarketValue * self.FORCED_LIVESTOCK_REALISATION_FACTOR
    end
    return result
end

function RFF_PropertyFinanceService:clearRecoveredHusbandryLivestock(placeable)
    if placeable == nil or placeable.spec_husbandryAnimals == nil then return 0, true end
    local clusterSystem = placeable.spec_husbandryAnimals.clusterSystem
    if clusterSystem == nil then return 0, true end

    local clusters = nil
    if clusterSystem.getClusters ~= nil then
        local ok, values = pcall(clusterSystem.getClusters, clusterSystem)
        if ok then clusters = values end
    end
    clusters = clusters or clusterSystem.clusters or {}
    local snapshot = {}
    for _, cluster in pairs(clusters) do table.insert(snapshot, cluster) end
    if #snapshot == 0 then return 0, true end

    local removed = 0
    if clusterSystem.addPendingRemoveCluster ~= nil then
        for _, cluster in ipairs(snapshot) do
            local ok = pcall(clusterSystem.addPendingRemoveCluster, clusterSystem, cluster)
            if ok then removed = removed + 1 end
        end
        if clusterSystem.updateNow ~= nil then pcall(clusterSystem.updateNow, clusterSystem)
        elseif clusterSystem.updateClusters ~= nil then pcall(clusterSystem.updateClusters, clusterSystem) end
    elseif clusterSystem.removeCluster ~= nil then
        for i = #snapshot, 1, -1 do
            local ok = pcall(clusterSystem.removeCluster, clusterSystem, i)
            if ok then removed = removed + 1 end
        end
        if clusterSystem.updateIdMapping ~= nil then pcall(clusterSystem.updateIdMapping, clusterSystem) end
    else
        return 0, false
    end
    return removed, removed == #snapshot
end

function RFF_PropertyFinanceService:getPlaceableFollowsFarmland(placeable)
    if placeable == nil then return false end
    if placeable.boughtWithFarmlandSavegameOverwrite ~= nil then
        return placeable.boughtWithFarmlandSavegameOverwrite == true
    end
    return placeable.boughtWithFarmland == true
end

function RFF_PropertyFinanceService:promotePlaceableToFarmlandAsset(placeable)
    if placeable == nil then return false end
    local alreadyFollowedFarmland = self:getPlaceableFollowsFarmland(placeable)
    placeable.boughtWithFarmland = true
    placeable.boughtWithFarmlandSavegameOverwrite = true

    -- Player-built placeables were not subscribed when GIANTS finalised their
    -- loading. Subscribe only on the first promotion; on later save loads the
    -- persisted overwrite makes GIANTS perform the subscription itself.
    if not alreadyFollowedFarmland and g_messageCenter ~= nil and MessageType ~= nil
        and MessageType.FARMLAND_OWNER_CHANGED ~= nil and placeable.onFarmlandStateChanged ~= nil then
        local subscribed = pcall(g_messageCenter.subscribe, g_messageCenter,
            MessageType.FARMLAND_OWNER_CHANGED, placeable.onFarmlandStateChanged, placeable)
        if not subscribed and Logging ~= nil and Logging.warning ~= nil then
            Logging.warning("[RealisticFarmFinance] Failed to subscribe forfeited placeable to future farmland ownership changes")
        end
        return subscribed
    end
    return true
end

function RFF_PropertyFinanceService:prepareRecoveredPlaceablesForNativeSale(fixtureAssessment, voluntary)
    local promotedToFarmland = 0
    local promotionFailures = 0
    local animalClusterFailures = 0

    for _, item in ipairs(fixtureAssessment ~= nil and fixtureAssessment.placeables or {}) do
        local placeable = item.placeable
        if placeable ~= nil and placeable.isDeleted ~= true then
            if voluntary ~= true and (item.animalCount or 0) > 0 then
                local _, animalsCleared = self:clearRecoveredHusbandryLivestock(placeable)
                if not animalsCleared then
                    animalClusterFailures = animalClusterFailures + 1
                    if Logging ~= nil and Logging.warning ~= nil then
                        Logging.warning("[RealisticFarmFinance] Could not fully clear livestock from recovered husbandry on farmland %d before native farmland sale", item.farmlandId or 0)
                    end
                end
            end

            -- Map/default placeables that GIANTS already marks as boughtWithFarmland are
            -- intentionally left alone. They will receive FARMLAND_OWNER_CHANGED through
            -- the normal base-game subscription and update their own ownership.
            --
            -- A player-placed fixed placeable normally does not follow farmland ownership.
            -- At mortgage possession only, promote it to the native boughtWithFarmland
            -- behaviour so the same base-game farmland-sale event transfers it now and on
            -- any later repurchase. The overwrite is persisted by Placeable:saveToXMLFile.
            if not self:getPlaceableFollowsFarmland(placeable) then
                placeable.boughtWithFarmlandSavegameOverwrite = true

                local subscribed = true
                if g_messageCenter ~= nil and MessageType ~= nil and MessageType.FARMLAND_OWNER_CHANGED ~= nil and placeable.onFarmlandStateChanged ~= nil then
                    subscribed = pcall(g_messageCenter.subscribe, g_messageCenter, MessageType.FARMLAND_OWNER_CHANGED, placeable.onFarmlandStateChanged, placeable)
                end

                if subscribed then
                    promotedToFarmland = promotedToFarmland + 1
                else
                    promotionFailures = promotionFailures + 1
                    if Logging ~= nil and Logging.warning ~= nil then
                        Logging.warning("[RealisticFarmFinance] Failed to subscribe recovered player placeable on farmland %d to native farmland ownership changes", item.farmlandId or 0)
                    end
                end
            end
        end
    end

    return promotedToFarmland, promotionFailures, animalClusterFailures
end

function RFF_PropertyFinanceService:transferFarmlandByNativeSale(farmlandId)
    farmlandId = math.floor(safeNumber(farmlandId))
    if farmlandId <= 0 or g_farmlandManager == nil then return false end

    local receiverFarmId = FarmlandManager ~= nil and FarmlandManager.NO_OWNER_FARM_ID or 0

    -- This is the same event/path used by the base-game farmland sell command/UI.
    -- A zero price is intentional: RFF already performs the lender recovery accounting,
    -- so the native event is used only for authoritative ownership propagation.
    if FarmlandStateEvent ~= nil and FarmlandStateEvent.new ~= nil and g_server ~= nil and g_server.broadcastEvent ~= nil then
        local event = FarmlandStateEvent.new(farmlandId, receiverFarmId, 0)
        local ok = pcall(g_server.broadcastEvent, g_server, event, true)
        if ok and g_farmlandManager:getFarmlandOwner(farmlandId) == receiverFarmId then
            return true
        end
    end

    -- Defensive fallback for unusual server contexts. setLandOwnership is the same
    -- authoritative core called from FarmlandStateEvent and publishes FARMLAND_OWNER_CHANGED.
    local oldOwner = g_farmlandManager:getFarmlandOwner(farmlandId)
    local ok = g_farmlandManager:setLandOwnership(farmlandId, receiverFarmId)
    if ok and g_messageCenter ~= nil then
        if oldOwner ~= receiverFarmId then
            g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, oldOwner)
        end
        if receiverFarmId ~= FarmlandManager.NO_OWNER_FARM_ID then
            g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, receiverFarmId)
        end
    end
    return ok == true and g_farmlandManager:getFarmlandOwner(farmlandId) == receiverFarmId
end

function RFF_PropertyFinanceService:countRecoveredPlaceableOwnership(fixtureAssessment, formerFarmId)
    local transferred = 0
    local failed = 0
    formerFarmId = math.floor(safeNumber(formerFarmId))
    for _, item in ipairs(fixtureAssessment ~= nil and fixtureAssessment.placeables or {}) do
        local placeable = item.placeable
        if placeable ~= nil and placeable.isDeleted ~= true then
            if self:getPlaceableOwnerFarmId(placeable) ~= formerFarmId then
                transferred = transferred + 1
            else
                failed = failed + 1
                if Logging ~= nil and Logging.warning ~= nil then
                    Logging.warning("[RealisticFarmFinance] Fixed placeable on recovered farmland %d still belongs to former farm %d after native farmland sale", item.farmlandId or 0, formerFarmId)
                end
            end
        end
    end
    return transferred, failed
end

function RFF_PropertyFinanceService:getApplicationSecurityFarmlandIds(application)
    if application == nil then return {} end
    local ids = parseIdList(application.securityFarmlandIds)
    if #ids == 0 and safeNumber(application.farmlandId) > 0 then
        table.insert(ids, math.floor(safeNumber(application.farmlandId)))
    end
    return ids
end

function RFF_PropertyFinanceService:getSecurityPackageCurrentValue(ids)
    local value = 0
    for _, farmlandId in ipairs(ids or {}) do
        local farmland = self:getFarmland(farmlandId)
        if farmland ~= nil then value = value + math.max(0, safeNumber(farmland.price)) end
    end
    return value
end

function RFF_PropertyFinanceService:getMortgageByFarmland(farmlandId, activeOnly)
    farmlandId = math.floor(safeNumber(farmlandId))
    for _, loan in ipairs(self.repository ~= nil and self.repository.loans or {}) do
        if loan.type == RFF_LoanService.TYPE_MORTGAGE and (not activeOnly or not loan.paidOff) then
            for _, securedId in ipairs(self:getMortgageSecurityFarmlandIds(loan)) do
                if securedId == farmlandId then return loan end
            end
        end
    end
    return nil
end

function RFF_PropertyFinanceService:getMortgageSummary(farmId)
    local count, balance, payment = 0, 0, 0
    for _, loan in ipairs(self.repository ~= nil and self.repository.loans or {}) do
        if loan.farmId == farmId and loan.type == RFF_LoanService.TYPE_MORTGAGE and not loan.paidOff then
            count = count + 1
            balance = balance + math.max(0, safeNumber(loan.principal))
            payment = payment + math.max(0, safeNumber(loan.monthlyPayment))
        end
    end
    return count, balance, payment
end

function RFF_PropertyFinanceService:getPropertyLtvLimit(grade)
    if grade == "A" then return 0.85 end
    if grade == "B" then return 0.80 end
    if grade == "C" then return 0.75 end
    return 0.70
end

function RFF_PropertyFinanceService:evaluateMortgagePrincipal(farmId, farmlandId, principal, months, lenderValuation, requireDepositFunds)
    local farmland = self:getFarmland(farmlandId)
    local result = {
        approved=false, reason="invalid", grade=nil, interestRate=0, monthlyPayment=0,
        ltv=math.huge, dscr=nil, propertyLtv=math.huge, propertyLtvLimit=0,
        lenderValuation=0, requiredDeposit=0, maxAdvance=0, underwritingRoute="STANDARD", securedRoute=false,
        marketRateApplied=false, marketState="SELECTIVE", dealFit="STANDARD"
    }
    if farmland == nil or farmId == nil or farmId <= 0 or self.repository == nil or self.loanService == nil then return result end
    if not self:isFarmlandAvailableForAcquisition(farmlandId) then
        result.reason = "farmland_not_for_sale"
        return result
    end

    local price = math.max(0, safeNumber(farmland.price))
    principal = math.max(0, math.min(price, safeNumber(principal)))
    months = math.max(12, math.floor(safeNumber(months)))
    lenderValuation = math.max(1, safeNumber(lenderValuation) > 0 and lenderValuation or price)
    local deposit = math.max(0, price - principal)
    result.price, result.deposit, result.principal, result.months = price, deposit, principal, months
    result.lenderValuation = lenderValuation

    if principal < 1000 then result.reason = "invalid"; return result end
    if requireDepositFunds == true and farmMoney(farmId) < deposit then result.reason = "funds"; return result end

    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(self.repository, farmId) or nil
    if conduct ~= nil and conduct.declineNewCredit then result.reason = "payment_conduct"; return result end
    local conductRate = conduct ~= nil and safeNumber(conduct.rateAdjustment) or 0
    local market = self.marketService ~= nil and self.marketService:getMarketAdjustment("PRIMARY_BANK")
        or {state="SELECTIVE", rateAdjustment=0, collateralFactor=1, incomeFactor=1, ltvAdjustment=0}
    local fit = self.marketService ~= nil and self.marketService:getDealAdjustment("PRIMARY_BANK", RFF_LoanService.TYPE_MORTGAGE, "LAND_PROPERTY", principal, nil)
        or {code="STANDARD", available=true, rateAdjustment=0, collateralFactor=1, incomeFactor=1, ltvAdjustment=0}
    result.marketState = market.state or "SELECTIVE"
    result.dealFit = fit.code or "STANDARD"
    if fit.available ~= true then result.reason = "lender_appetite"; return result end
    local relationshipBenefits = self.relationshipService ~= nil and self.relationshipService:getBenefits(farmId, "PRIMARY_BANK") or nil
    local relationshipLtvBonus = relationshipBenefits ~= nil and safeNumber(relationshipBenefits.ltvBonus) or 0
    local marketLtvAdjustment = safeNumber(market.ltvAdjustment) + safeNumber(fit.ltvAdjustment)
    local securedPropertyLtvMax = math.max(0.45, math.min(0.80, self.MORTGAGE_SECURED_MAX_PROPERTY_LTV + relationshipLtvBonus + marketLtvAdjustment))
    local securedOverallLtvMax = math.max(0.50, math.min(0.85, self.MORTGAGE_SECURED_MAX_OVERALL_LTV + relationshipLtvBonus + marketLtvAdjustment))

    -- The lender values the proposed security independently. The current farm cash collateral is
    -- reduced by the deposit being paid, then the lender's land valuation is added at the normal
    -- farmland collateral haircut. This keeps underwriting based on recoverable security rather
    -- than simply accepting the seller/map price as bank value.
    local marketCollateral = safeNumber(credit.collateral) * math.max(0.75, safeNumber(market.collateralFactor)) * math.max(0.75, safeNumber(fit.collateralFactor))
    local postCollateral = math.max(0, marketCollateral - deposit * 0.30 + lenderValuation * 0.70)
    if postCollateral <= 0 then result.reason = "no_collateral"; return result end

    local existingDebt = math.max(0, safeNumber(valuation.liabilities))
    result.ltv = (existingDebt + principal) / postCollateral
    result.propertyLtv = principal / lenderValuation

    local baseRate = self.loanService:getBaseRate() + self.loanService:getProductSpread(RFF_LoanService.TYPE_MORTGAGE)
    local provisionalRate = baseRate + self.loanService:getPricingSpread("B") + conductRate + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment)
    local candidatePayment = self.loanService:calculateAnnuityPayment(principal, provisionalRate, months)
    local existingCommitments = self.loanService:getMonthlyDebtService(farmId) + (self.repository:getMonthlyTenancyRent(farmId) or 0)
    local totalDebtService = existingCommitments + candidatePayment
    local monthlyIncome = math.max(0, safeNumber(credit.monthlyIncome)) * math.max(0.75, safeNumber(market.incomeFactor)) * math.max(0.75, safeNumber(fit.incomeFactor))
    local hasIncome = monthlyIncome > 0
    local dscr = totalDebtService > 0 and monthlyIncome / totalDebtService or math.huge
    result.dscr = dscr

    local tracked = safeNumber(credit.trackedPeriods)
    local grade
    if tracked < 3 then
        grade = self.loanService:scoreStartup(result.ltv)
        result.dscr = nil
    elseif tracked < 12 then
        grade = self.loanService:scoreDeveloping(dscr, result.ltv, hasIncome)
    else
        grade = self.loanService:scoreEstablished(dscr, result.ltv)
    end
    local securedRoute = false
    local securedEligible = tracked >= 3
        and result.propertyLtv <= securedPropertyLtvMax + 0.000001
        and result.ltv <= securedOverallLtvMax + 0.000001
        and (conduct == nil or conduct.declineNewCredit ~= true)
    if grade == nil then
        if securedEligible then
            securedRoute = true
            grade = (result.propertyLtv <= 0.50 and result.ltv <= 0.55) and "C" or "D"
        else
            result.reason = tracked < 3 and "startup_ltv" or "affordability"
            return result
        end
    end
    if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end

    local routeRateUplift = securedRoute and self.MORTGAGE_SECURED_RATE_UPLIFT or 0
    local finalRate = baseRate + self.loanService:getPricingSpread(grade) + conductRate + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment) + routeRateUplift
    local finalPayment = self.loanService:calculateAnnuityPayment(principal, finalRate, months)
    local finalTotalDebtService = existingCommitments + finalPayment
    local finalDscr = finalTotalDebtService > 0 and monthlyIncome / finalTotalDebtService or math.huge
    if tracked >= 3 and hasIncome and not securedRoute then
        local revised = tracked < 12 and self.loanService:scoreDeveloping(finalDscr, result.ltv, true) or self.loanService:scoreEstablished(finalDscr, result.ltv)
        if revised == nil then
            if securedEligible then
                securedRoute = true
                grade = (result.propertyLtv <= 0.50 and result.ltv <= 0.55) and "C" or "D"
                if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end
                finalRate = baseRate + self.loanService:getPricingSpread(grade) + conductRate + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment) + self.MORTGAGE_SECURED_RATE_UPLIFT
                finalPayment = self.loanService:calculateAnnuityPayment(principal, finalRate, months)
                finalTotalDebtService = existingCommitments + finalPayment
                finalDscr = finalTotalDebtService > 0 and monthlyIncome / finalTotalDebtService or math.huge
            else
                result.reason = "affordability_after_pricing"
                result.grade = grade
                result.interestRate = finalRate
                result.monthlyPayment = finalPayment
                result.dscr = finalDscr
                return result
            end
        elseif revised ~= grade then
            grade = revised
            if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end
            finalRate = baseRate + self.loanService:getPricingSpread(grade) + conductRate + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment)
            finalPayment = self.loanService:calculateAnnuityPayment(principal, finalRate, months)
            finalTotalDebtService = existingCommitments + finalPayment
            finalDscr = finalTotalDebtService > 0 and monthlyIncome / finalTotalDebtService or math.huge
        end
        result.dscr = finalDscr
    elseif securedRoute then
        result.dscr = finalDscr
    end

    result.grade = grade
    result.interestRate = finalRate
    result.monthlyPayment = finalPayment
    result.securedRoute = securedRoute
    result.underwritingRoute = securedRoute and "SECURED_AGRICULTURAL" or "STANDARD"
    result.propertyLtvLimit = securedRoute and securedPropertyLtvMax or math.max(0.50, math.min(0.95, self:getPropertyLtvLimit(grade) + relationshipLtvBonus + marketLtvAdjustment))
    result.maxAdvance = math.min(price, lenderValuation * result.propertyLtvLimit)
    result.requiredDeposit = math.max(0, price - result.maxAdvance)

    if result.propertyLtv > result.propertyLtvLimit + 0.000001 then
        result.reason = "property_ltv"
        return result
    end

    result.marketRateApplied = true
    result.approved = true
    result.reason = securedRoute and "secured_agricultural" or "approved"
    return result
end

function RFF_PropertyFinanceService:evaluateMortgage(farmId, farmlandId, downPaymentPercent, months)
    local farmland = self:getFarmland(farmlandId)
    if farmland == nil then return {approved=false, reason="invalid"} end
    local price = math.max(0, safeNumber(farmland.price))
    downPaymentPercent = math.max(10, math.min(90, safeNumber(downPaymentPercent)))
    local deposit = price * downPaymentPercent / 100
    local principal = math.max(0, price - deposit)
    local result = self:evaluateMortgagePrincipal(farmId, farmlandId, principal, months, price, true)
    result.selectedDepositPercent = downPaymentPercent
    return result
end

function RFF_PropertyFinanceService:getEquityReleaseFarmlands(farmId)
    local result = {}
    if g_farmlandManager == nil or farmId == nil or farmId <= 0 then return result end
    for _, farmland in pairs(g_farmlandManager:getFarmlands() or {}) do
        if g_farmlandManager:getFarmlandOwner(farmland.id) == farmId
            and self:getMortgageByFarmland(farmland.id, true) == nil
            and (self.repository == nil or self.repository:getTenancyByFarmland(farmland.id, true) == nil) then
            table.insert(result, farmland)
        end
    end
    table.sort(result, function(a, b) return safeNumber(a.id) < safeNumber(b.id) end)
    return result
end

function RFF_PropertyFinanceService:getPropertySecuritySummary(farmId)
    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local mortgageCount, mortgageBalance, mortgagePayment = self:getMortgageSummary(farmId)
    local unencumbered = self:getEquityReleaseFarmlands(farmId)
    local unencumberedValue = 0
    for _, farmland in ipairs(unencumbered) do unencumberedValue = unencumberedValue + math.max(0, safeNumber(farmland.price)) end
    local propertyValue = math.max(0, safeNumber(valuation.farmland)) + math.max(0, safeNumber(valuation.buildings))
    return {
        farmlandValue=math.max(0, safeNumber(valuation.farmland)),
        buildingValue=math.max(0, safeNumber(valuation.buildings)),
        propertyValue=propertyValue,
        mortgageCount=mortgageCount,
        mortgageBalance=mortgageBalance,
        mortgagePayment=mortgagePayment,
        propertyEquity=math.max(0, propertyValue - mortgageBalance),
        unencumberedCount=#unencumbered,
        unencumberedLandValue=unencumberedValue,
        indicativeSecurityHeadroom=unencumberedValue * self.EQUITY_RELEASE_BASE_MAX_LTV
    }
end

function RFF_PropertyFinanceService:evaluateEquityReleaseSecurityPrincipal(farmId, securityIds, currentValue, principal, months, lenderValuation)
    securityIds = securityIds or {}
    local result = {
        approved=false, reason="invalid", grade=nil, interestRate=0, monthlyPayment=0,
        ltv=math.huge, dscr=nil, propertyLtv=math.huge, propertyLtvLimit=0,
        lenderValuation=0, maxAdvance=0, underwritingRoute="STANDARD", securedRoute=false,
        marketState="SELECTIVE", dealFit="STANDARD", deposit=0, securityCount=#securityIds,
        securityFarmlandIds=joinIdList(securityIds)
    }
    if farmId == nil or farmId <= 0 or self.repository == nil or self.loanService == nil or g_farmlandManager == nil or #securityIds == 0 then return result end

    currentValue = math.max(0, safeNumber(currentValue))
    if currentValue <= 0 then currentValue = self:getSecurityPackageCurrentValue(securityIds) end
    for _, farmlandId in ipairs(securityIds) do
        local farmland = self:getFarmland(farmlandId)
        if farmland == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= farmId then result.reason="property_not_owned"; return result end
        if self:getMortgageByFarmland(farmlandId, true) ~= nil then result.reason="already_mortgaged"; return result end
        if self.repository ~= nil and self.repository:getTenancyByFarmland(farmlandId, true) ~= nil then result.reason="security_unavailable"; return result end
    end

    lenderValuation = math.max(1, safeNumber(lenderValuation) > 0 and lenderValuation or currentValue)
    principal = math.max(0, safeNumber(principal))
    months = math.max(60, math.floor(safeNumber(months)))
    result.price=currentValue
    result.principal=principal
    result.months=months
    result.lenderValuation=lenderValuation
    if principal < 1000 then return result end

    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(self.repository, farmId) or nil
    if conduct ~= nil and conduct.declineNewCredit then result.reason="payment_conduct"; return result end

    local market = self.marketService ~= nil and self.marketService:getMarketAdjustment("PRIMARY_BANK")
        or {state="SELECTIVE", rateAdjustment=0, collateralFactor=1, incomeFactor=1, ltvAdjustment=0}
    local fit = self.marketService ~= nil and self.marketService:getDealAdjustment("PRIMARY_BANK", RFF_LoanService.TYPE_MORTGAGE, "LAND_PROPERTY", principal, nil)
        or {code="STANDARD", available=true, rateAdjustment=0, collateralFactor=1, incomeFactor=1, ltvAdjustment=0}
    result.marketState=market.state or "SELECTIVE"
    result.dealFit=fit.code or "STANDARD"
    if fit.available ~= true then result.reason="lender_appetite"; return result end

    local benefits = self.relationshipService ~= nil and self.relationshipService:getBenefits(farmId, "PRIMARY_BANK") or nil
    local ltvBonus = benefits ~= nil and safeNumber(benefits.ltvBonus) or 0
    local dscrTolerance = benefits ~= nil and safeNumber(benefits.dscrTolerance) or 0
    local rateBenefit = benefits ~= nil and safeNumber(benefits.rateAdjustment) or 0
    local ltvAdjustment = safeNumber(market.ltvAdjustment) + safeNumber(fit.ltvAdjustment)
    local propertyLimit = math.max(0.45, math.min(0.72, self.EQUITY_RELEASE_BASE_MAX_LTV + ltvBonus + ltvAdjustment))
    local overallLimit = math.max(0.55, math.min(0.88, self.EQUITY_RELEASE_MAX_OVERALL_LTV + ltvBonus + ltvAdjustment))
    result.propertyLtvLimit=propertyLimit
    result.maxAdvance=lenderValuation * propertyLimit
    result.propertyLtv=principal / lenderValuation
    if result.propertyLtv > propertyLimit + 0.000001 then result.reason="property_ltv"; return result end

    local collateral = math.max(0, safeNumber(credit.collateral)) * math.max(0.75, safeNumber(market.collateralFactor)) * math.max(0.75, safeNumber(fit.collateralFactor))
    if collateral <= 0 then result.reason="no_collateral"; return result end
    local existingDebt = math.max(0, safeNumber(valuation.liabilities))
    result.ltv=(existingDebt + principal) / collateral
    if result.ltv > overallLimit + 0.000001 then result.reason="overall_ltv"; return result end

    local conductRate = conduct ~= nil and safeNumber(conduct.rateAdjustment) or 0
    local baseRate = self.loanService:getBaseRate() + self.loanService:getProductSpread(RFF_LoanService.TYPE_MORTGAGE) + self.EQUITY_RELEASE_RATE_UPLIFT
    local provisionalRate = baseRate + self.loanService:getPricingSpread("B") + conductRate + rateBenefit + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment)
    local candidatePayment = self.loanService:calculateAnnuityPayment(principal, provisionalRate, months)
    local existingCommitments = self.loanService:getMonthlyDebtService(farmId) + (self.repository:getMonthlyTenancyRent(farmId) or 0)
    local totalDebtService=existingCommitments + candidatePayment
    local monthlyIncome=math.max(0, safeNumber(credit.monthlyIncome)) * math.max(0.75, safeNumber(market.incomeFactor)) * math.max(0.75, safeNumber(fit.incomeFactor))
    local hasIncome=monthlyIncome > 0
    local dscr=totalDebtService > 0 and monthlyIncome / totalDebtService or math.huge
    result.dscr=dscr

    local tracked=safeNumber(credit.trackedPeriods)
    local grade
    if tracked < 3 then
        grade=self.loanService:scoreStartup(result.ltv)
        result.dscr=nil
    elseif tracked < 12 then
        grade=self.loanService:scoreDeveloping(dscr + dscrTolerance, result.ltv, hasIncome)
    else
        grade=self.loanService:scoreEstablished(dscr + dscrTolerance, result.ltv)
    end

    local securedRoute=false
    if grade == nil then
        local securedEligible = tracked >= 3 and hasIncome and dscr >= 0.50
            and result.propertyLtv <= math.min(propertyLimit, 0.50) + 0.000001
            and result.ltv <= math.min(overallLimit, 0.70) + 0.000001
        if securedEligible then
            securedRoute=true
            grade=(result.propertyLtv <= 0.40 and result.ltv <= 0.60) and "C" or "D"
        else
            result.reason=tracked < 3 and "startup_ltv" or "affordability"
            return result
        end
    end
    if conduct ~= nil and RFF_PaymentConduct ~= nil then grade=RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end

    local finalRate = baseRate + self.loanService:getPricingSpread(grade) + conductRate + rateBenefit + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment)
        + (securedRoute and self.EQUITY_RELEASE_SECURED_RATE_UPLIFT or 0)
    local finalPayment=self.loanService:calculateAnnuityPayment(principal, finalRate, months)
    local finalDscr=(existingCommitments + finalPayment) > 0 and monthlyIncome / (existingCommitments + finalPayment) or math.huge
    if tracked >= 3 and hasIncome and not securedRoute and finalDscr + dscrTolerance < 0.80 then
        result.reason="affordability_after_pricing"
        result.interestRate=finalRate
        result.monthlyPayment=finalPayment
        result.dscr=finalDscr
        return result
    end

    result.grade=grade
    result.interestRate=finalRate
    result.monthlyPayment=finalPayment
    result.dscr=tracked >= 3 and hasIncome and finalDscr or result.dscr
    result.securedRoute=securedRoute
    result.underwritingRoute=securedRoute and "ASSET_BACKED" or "STANDARD"
    result.approved=true
    result.reason=securedRoute and "secured_agricultural" or "approved"
    return result
end

function RFF_PropertyFinanceService:evaluateEquityReleasePrincipal(farmId, farmlandId, principal, months, lenderValuation)
    local farmland = self:getFarmland(farmlandId)
    if farmland == nil then return {approved=false, reason="invalid"} end
    return self:evaluateEquityReleaseSecurityPrincipal(farmId, {farmlandId}, math.max(0, safeNumber(farmland.price)), principal, months, lenderValuation)
end

function RFF_PropertyFinanceService:evaluateHoldingEquityReleasePrincipal(farmId, securityIds, principal, months, lenderValuation)
    securityIds = securityIds or {}
    local currentValue = self:getSecurityPackageCurrentValue(securityIds)
    return self:evaluateEquityReleaseSecurityPrincipal(farmId, securityIds, currentValue, principal, months, lenderValuation)
end

function RFF_PropertyFinanceService:evaluateEquityRelease(farmId, farmlandId, advancePercent, months)
    local farmland=self:getFarmland(farmlandId)
    if farmland == nil then return {approved=false, reason="invalid"} end
    advancePercent=math.max(5, math.min(70, safeNumber(advancePercent)))
    local value=math.max(0, safeNumber(farmland.price))
    local principal=value * advancePercent / 100
    local result=self:evaluateEquityReleasePrincipal(farmId, farmlandId, principal, months, value)
    result.selectedAdvancePercent=advancePercent
    return result
end

function RFF_PropertyFinanceService:getHoldingEquityReleaseFarmlands(farmId)
    return self:getEquityReleaseFarmlands(farmId)
end

function RFF_PropertyFinanceService:evaluateHoldingEquityRelease(farmId, advancePercent, months)
    local farmlands = self:getHoldingEquityReleaseFarmlands(farmId)
    if #farmlands < 2 then return {approved=false, reason="insufficient_security", securityCount=#farmlands} end
    local ids = {}
    local value = 0
    for _, farmland in ipairs(farmlands) do
        table.insert(ids, farmland.id)
        value = value + math.max(0, safeNumber(farmland.price))
    end
    advancePercent=math.max(5, math.min(70, safeNumber(advancePercent)))
    local principal=value * advancePercent / 100
    local result=self:evaluateHoldingEquityReleasePrincipal(farmId, ids, principal, months, value)
    result.selectedAdvancePercent=advancePercent
    result.securityCount=#ids
    result.securityFarmlandIds=joinIdList(ids)
    return result
end

function RFF_PropertyFinanceService:findEquityReleaseCounterOffer(application)
    if application == nil then return nil, nil end
    local requested=math.max(0, safeNumber(application.requestedAmount))
    if requested < 5000 then return nil, nil end
    local lenderValuation=self:performLenderValuation(application)
    if lenderValuation <= 0 then return nil, nil end
    local low, high=1000, requested
    local bestAmount, bestEvaluation=0, nil
    for _=1,20 do
        local candidate=math.floor(((low+high)*0.5)/1000)*1000
        candidate=math.max(1000,candidate)
        local evaluation=self:evaluateEquityReleasePrincipal(application.farmId, application.farmlandId, candidate, application.requestedMonths, lenderValuation)
        if evaluation.approved then bestAmount,bestEvaluation=candidate,evaluation; low=candidate+1000 else high=candidate-1000 end
        if high < low then break end
    end
    if bestAmount <= 0 or bestAmount < math.max(5000, requested*0.50) then return nil,nil end
    return bestAmount,bestEvaluation
end

function RFF_PropertyFinanceService:findHoldingEquityReleaseCounterOffer(application)
    if application == nil then return nil, nil end
    local requested=math.max(0, safeNumber(application.requestedAmount))
    if requested < 5000 then return nil, nil end
    local ids=self:getApplicationSecurityFarmlandIds(application)
    if #ids < 2 then return nil,nil end
    local lenderValuation=self:performLenderValuation(application)
    if lenderValuation <= 0 then return nil, nil end
    local low, high=1000, requested
    local bestAmount, bestEvaluation=0, nil
    for _=1,20 do
        local candidate=math.floor(((low+high)*0.5)/1000)*1000
        candidate=math.max(1000,candidate)
        local evaluation=self:evaluateHoldingEquityReleasePrincipal(application.farmId, ids, candidate, application.requestedMonths, lenderValuation)
        if evaluation.approved then bestAmount,bestEvaluation=candidate,evaluation; low=candidate+1000 else high=candidate-1000 end
        if high < low then break end
    end
    if bestAmount <= 0 or bestAmount < math.max(5000, requested*0.50) then return nil,nil end
    return bestAmount,bestEvaluation
end

function RFF_PropertyFinanceService:completeEquityReleaseFromApplication(application)
    if g_currentMission == nil or not g_currentMission:getIsServer() or application == nil then return nil,"server_only" end
    local farmland=self:getFarmland(application.farmlandId)
    if farmland == nil or g_farmlandManager == nil or g_farmlandManager:getFarmlandOwner(application.farmlandId) ~= application.farmId then return nil,"property_unavailable" end
    if self:getMortgageByFarmland(application.farmlandId, true) ~= nil then return nil,"already_mortgaged" end
    local principal=math.max(0,safeNumber(application.offeredAmount))
    if principal < 1000 then return nil,"invalid_offer" end
    local offer={
        approved=true, interestRate=safeNumber(application.offeredRate), monthlyPayment=safeNumber(application.offeredPayment),
        grade=application.offeredGrade or "C", lenderId=application.lenderId or "PRIMARY_BANK",
        lenderNameKey=application.lenderNameKey or "rff_lender_primary_bank", brokered=false, brokerCaseId=0,
        arrangementFee=0, brokerFee=0
    }
    local loan,reason=self.loanService:createLoanFromOffer(application.farmId,principal,application.offeredMonths or application.requestedMonths,
        RFF_LoanService.TYPE_MORTGAGE,"LAND_PROPERTY",offer,{disburse=true})
    if loan == nil then return nil,reason end
    loan.securityFarmlandId=application.farmlandId
    loan.securityFarmlandIds=tostring(application.farmlandId or 0)
    loan.securityFarmlandCount=1
    loan.purchasePrice=math.max(0,safeNumber(farmland.price))
    loan.depositPaid=0
    loan.lenderValuation=safeNumber(application.lenderValuation)
    loan.propertyLtv=safeNumber(application.offeredPropertyLtv)
    loan.propertyLtvLimit=safeNumber(application.propertyLtvLimit)
    loan.applicationId=application.id or 0
    loan.propertyFinanceMode="EQUITY_RELEASE"
    loan.equityRelease=true
    loan.equityReleasedAmount=principal
    return loan,nil
end

function RFF_PropertyFinanceService:completeHoldingEquityReleaseFromApplication(application)
    if g_currentMission == nil or not g_currentMission:getIsServer() or application == nil or g_farmlandManager == nil then return nil,"server_only" end
    local ids=self:getApplicationSecurityFarmlandIds(application)
    if #ids < 2 then return nil,"security_unavailable" end
    for _,farmlandId in ipairs(ids) do
        local farmland=self:getFarmland(farmlandId)
        if farmland == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= application.farmId then return nil,"property_unavailable" end
        if self:getMortgageByFarmland(farmlandId,true) ~= nil then return nil,"already_mortgaged" end
    end
    local principal=math.max(0,safeNumber(application.offeredAmount))
    if principal < 1000 then return nil,"invalid_offer" end
    local offer={
        approved=true, interestRate=safeNumber(application.offeredRate), monthlyPayment=safeNumber(application.offeredPayment),
        grade=application.offeredGrade or "C", lenderId=application.lenderId or "PRIMARY_BANK",
        lenderNameKey=application.lenderNameKey or "rff_lender_primary_bank", brokered=false, brokerCaseId=0,
        arrangementFee=0, brokerFee=0
    }
    local loan,reason=self.loanService:createLoanFromOffer(application.farmId,principal,application.offeredMonths or application.requestedMonths,
        RFF_LoanService.TYPE_MORTGAGE,"LAND_PROPERTY",offer,{disburse=true})
    if loan == nil then return nil,reason end
    loan.securityFarmlandId=ids[1] or 0
    loan.securityFarmlandIds=joinIdList(ids)
    loan.securityFarmlandCount=#ids
    loan.purchasePrice=self:getSecurityPackageCurrentValue(ids)
    loan.depositPaid=0
    loan.lenderValuation=safeNumber(application.lenderValuation)
    loan.propertyLtv=safeNumber(application.offeredPropertyLtv)
    loan.propertyLtvLimit=safeNumber(application.propertyLtvLimit)
    loan.applicationId=application.id or 0
    loan.propertyFinanceMode="HOLDING_EQUITY_RELEASE"
    loan.equityRelease=true
    loan.holdingEquityRelease=true
    loan.equityReleasedAmount=principal
    return loan,nil
end

function RFF_PropertyFinanceService:performLenderValuation(application)
    if application == nil then return 0 end
    if safeNumber(application.lenderValuation) > 0 then return application.lenderValuation end

    if application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then
        local ids = self:getApplicationSecurityFarmlandIds(application)
        if #ids < 2 then return 0 end
        local totalPrice = 0
        local totalValue = 0
        for _, farmlandId in ipairs(ids) do
            local farmland = self:getFarmland(farmlandId)
            if farmland == nil then return 0 end
            local price = math.max(0, safeNumber(farmland.price))
            totalPrice = totalPrice + price
            local seed = (math.max(1, math.floor(safeNumber(farmlandId))) * 37 + math.max(1, math.floor(safeNumber(application.id))) * 17) % 11
            local ratio = 0.92 + seed * 0.01
            totalValue = totalValue + math.floor((price * ratio) / 100 + 0.5) * 100
        end
        application.purchasePrice = totalPrice
        application.lenderValuation = totalValue
        application.lenderValuationRatio = totalPrice > 0 and totalValue / totalPrice or 0
        return totalValue
    end

    local farmland = self:getFarmland(application.farmlandId)
    local price = math.max(0, safeNumber(application.purchasePrice))
    if price <= 0 and farmland ~= nil then price = math.max(0, safeNumber(farmland.price)) end
    if price <= 0 then return 0 end

    -- Deterministic 92%-102% valuation band. It behaves like an independent professional
    -- valuation while remaining stable across save/reload and reproducible for testing.
    local seed = (math.max(1, math.floor(safeNumber(application.farmlandId))) * 37 + math.max(1, math.floor(safeNumber(application.id))) * 17) % 11
    local ratio = 0.92 + seed * 0.01
    local value = math.floor((price * ratio) / 100 + 0.5) * 100
    application.lenderValuation = value
    application.lenderValuationRatio = ratio
    return value
end

function RFF_PropertyFinanceService:findMortgageCounterOffer(application)
    if application == nil then return nil, nil end
    local requested = math.max(0, safeNumber(application.requestedAmount))
    if requested < 10000 then return nil, nil end
    local lenderValuation = self:performLenderValuation(application)
    if lenderValuation <= 0 then return nil, nil end

    local low, high = 1000, requested
    local bestAmount, bestEvaluation = 0, nil
    for _ = 1, 20 do
        local candidate = math.floor(((low + high) * 0.5) / 1000) * 1000
        candidate = math.max(1000, candidate)
        local evaluation = self:evaluateMortgagePrincipal(application.farmId, application.farmlandId, candidate, application.requestedMonths, lenderValuation, false)
        if evaluation.approved then
            bestAmount, bestEvaluation = candidate, evaluation
            low = candidate + 1000
        else
            high = candidate - 1000
        end
        if high < low then break end
    end

    if bestAmount <= 0 or bestAmount < math.max(10000, requested * 0.50) then return nil, nil end
    bestEvaluation = self:evaluateMortgagePrincipal(application.farmId, application.farmlandId, bestAmount, application.requestedMonths, lenderValuation, false)
    if bestEvaluation == nil or not bestEvaluation.approved then return nil, nil end
    return bestAmount, bestEvaluation
end

-- Retained for backward/internal compatibility. New player-initiated mortgages are submitted
-- through the underwriting application service and complete only when a formal offer is accepted.
function RFF_PropertyFinanceService:createMortgage(farmId, farmlandId, downPaymentPercent, months)
    if g_currentMission == nil or not g_currentMission:getIsServer() then return nil, {approved=false, reason="server_only"} end
    local farmland = self:getFarmland(farmlandId)
    if farmland == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID
        or not self:isFarmlandAvailableForAcquisition(farmlandId) then
        return nil, {approved=false, reason="unavailable"}
    end
    local evaluation = self:evaluateMortgage(farmId, farmlandId, downPaymentPercent, months)
    if not evaluation.approved then return nil, evaluation end

    local application = {
        farmId=farmId, farmlandId=farmlandId, purchasePrice=evaluation.price,
        offeredAmount=evaluation.principal, offeredMonths=evaluation.months,
        offeredRate=evaluation.interestRate, offeredPayment=evaluation.monthlyPayment,
        offeredGrade=evaluation.grade, lenderValuation=evaluation.price,
        offeredDeposit=evaluation.deposit, offeredPropertyLtv=evaluation.propertyLtv,
        propertyLtvLimit=evaluation.propertyLtvLimit, id=0
    }
    return self:completeMortgageFromApplication(application)
end

function RFF_PropertyFinanceService:completeMortgageFromApplication(application)
    if g_currentMission == nil or not g_currentMission:getIsServer() or application == nil then return nil, "server_only" end
    if application.propertyFinanceMode == "EQUITY_RELEASE" then return self:completeEquityReleaseFromApplication(application) end
    if application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then return self:completeHoldingEquityReleaseFromApplication(application) end
    local farmlandId = application.farmlandId
    local farmland = self:getFarmland(farmlandId)
    if farmland == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID then return nil, "property_unavailable" end
    if not self:isFarmlandAvailableForAcquisition(farmlandId) then return nil, "farmland_not_for_sale" end

    local price = math.max(0, safeNumber(application.purchasePrice))
    local currentPrice = math.max(0, safeNumber(farmland.price))
    if price <= 0 then price = currentPrice end
    if math.abs(currentPrice - price) > 1 then return nil, "price_changed" end

    local principal = math.max(0, math.min(price, safeNumber(application.offeredAmount)))
    local deposit = math.max(0, price - principal)
    if principal < 1000 then return nil, "invalid_offer" end
    local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(self.repository, application.farmId) or nil
    if conduct ~= nil and conduct.declineNewCredit then return nil, "payment_conduct" end
    if farmMoney(application.farmId) < deposit then return nil, "funds" end

    if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(application.farmId, string.format("Agricultural mortgage deposit - Land %d", farmlandId)) end
    g_currentMission:addMoney(-deposit, application.farmId, moneyTypeFallback(), true, true)
    g_farmlandManager:setLandOwnership(farmlandId, application.farmId)
    g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, application.farmId)

    local current = self.repository:getCurrentPeriodIndex()
    local loan = {
        id=self.repository:getNextLoanId(), farmId=application.farmId, type=RFF_LoanService.TYPE_MORTGAGE, purpose="LAND_PROPERTY",
        originalAmount=principal, creditLimit=0, principal=principal, drawnAmount=0,
        interestRate=safeNumber(application.offeredRate), termMonths=application.offeredMonths or application.requestedMonths or 0,
        remainingMonths=application.offeredMonths or application.requestedMonths or 0,
        monthlyPayment=safeNumber(application.offeredPayment), riskGrade=application.offeredGrade or "C",
        createdPeriod=current, lastPaymentPeriod=current, paymentsMade=0, missedPayments=0,
        arrearsPrincipal=0, arrearsInterest=0, arrearsRent=0, arrearsBalance=0,
        consecutiveMissedPayments=0, maxConsecutiveMissedPayments=0, lastMissedPeriod=0,
        lastSuccessfulPaymentPeriod=current, lastArrearsClearedPeriod=0, arrearsSchemaVersion=1,
        principalPaid=0, interestPaid=0, completedPeriod=0, paidOff=false,
        securityFarmlandId=farmlandId, securityFarmlandIds=tostring(farmlandId or 0), securityFarmlandCount=1, purchasePrice=price, depositPaid=deposit,
        lenderValuation=safeNumber(application.lenderValuation), propertyLtv=safeNumber(application.offeredPropertyLtv),
        propertyLtvLimit=safeNumber(application.propertyLtvLimit), applicationId=application.id or 0, propertyFinanceMode="PURCHASE",
        lenderId=application.lenderId or "PRIMARY_BANK", lenderNameKey=application.lenderNameKey or "rff_lender_primary_bank",
        brokered=application.brokered == true, brokerCaseId=application.brokerCaseId or 0,
        arrangementFee=safeNumber(application.arrangementFee), brokerFee=safeNumber(application.brokerFee)
    }
    self.repository:addLoan(loan)
    return loan, nil
end


function RFF_PropertyFinanceService:getMortgageSecurityValue(loan)
    if loan == nil or loan.type ~= RFF_LoanService.TYPE_MORTGAGE then return 0 end
    local ids = self:getMortgageSecurityFarmlandIds(loan)
    if #ids == 0 then return math.max(0, safeNumber(loan.lenderValuation), safeNumber(loan.purchasePrice)) end
    local value = 0
    local found = 0
    for _, farmlandId in ipairs(ids) do
        local farmland = self:getFarmland(farmlandId)
        if farmland ~= nil then
            value = value + math.max(0, safeNumber(farmland.price))
            found = found + 1
        end
    end
    if found == 0 then return math.max(0, safeNumber(loan.lenderValuation), safeNumber(loan.purchasePrice)) end
    return value
end

function RFF_PropertyFinanceService:evaluateSecurityRelease(loan, farmlandId)
    local result = {approved=false, reason="invalid", currentSecurityValue=0, releasedValue=0, remainingSecurityValue=0, debt=0, postReleaseLtv=math.huge, releaseLtvLimit=0}
    if loan == nil or loan.paidOff or loan.type ~= RFF_LoanService.TYPE_MORTGAGE then return result end
    local ids = self:getMortgageSecurityFarmlandIds(loan)
    if #ids < 2 then result.reason="single_security"; return result end
    if (loan.arrearsBalance or 0) > 0.01 or loan.currentDefault == true then result.reason="arrears"; return result end
    farmlandId = math.floor(safeNumber(farmlandId))
    local selected = false
    local remainingValue = 0
    local releasedValue = 0
    local currentValue = 0
    for _, id in ipairs(ids) do
        local farmland = self:getFarmland(id)
        if farmland == nil or g_farmlandManager == nil or g_farmlandManager:getFarmlandOwner(id) ~= loan.farmId then result.reason="security_unavailable"; return result end
        local value = math.max(0, safeNumber(farmland.price))
        currentValue = currentValue + value
        if id == farmlandId then selected=true; releasedValue=value else remainingValue=remainingValue+value end
    end
    if not selected or releasedValue <= 0 or remainingValue <= 0 then result.reason="invalid_security"; return result end
    local debt = math.max(0, safeNumber(loan.principal))
    local originalLimit = safeNumber(loan.propertyLtvLimit)
    if originalLimit <= 0 then originalLimit = self.EQUITY_RELEASE_BASE_MAX_LTV end
    local releaseLimit = math.max(0.40, math.min(0.70, originalLimit - 0.05))
    local postLtv = debt / remainingValue
    result.currentSecurityValue=currentValue
    result.releasedValue=releasedValue
    result.remainingSecurityValue=remainingValue
    result.debt=debt
    result.postReleaseLtv=postLtv
    result.releaseLtvLimit=releaseLimit
    result.farmlandId=farmlandId
    result.approved=postLtv <= releaseLimit + 0.000001
    result.reason=result.approved and "approved" or "insufficient_remaining_security"
    return result
end

function RFF_PropertyFinanceService:releaseSecurityParcel(loan, farmlandId)
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false,"server_only",nil end
    local evaluation=self:evaluateSecurityRelease(loan,farmlandId)
    if not evaluation.approved then return false,evaluation.reason,evaluation end
    local ids=self:getMortgageSecurityFarmlandIds(loan)
    local remaining={}
    for _,id in ipairs(ids) do if id ~= farmlandId then table.insert(remaining,id) end end
    if #remaining < 1 then return false,"single_security",evaluation end
    loan.securityFarmlandIds=joinIdList(remaining)
    loan.securityFarmlandCount=#remaining
    loan.securityFarmlandId=remaining[1] or 0
    loan.lenderValuation=evaluation.remainingSecurityValue
    loan.propertyLtv=evaluation.postReleaseLtv
    local released=parseIdList(loan.releasedSecurityFarmlandIds)
    table.insert(released,math.floor(safeNumber(farmlandId)))
    loan.releasedSecurityFarmlandIds=joinIdList(released)
    loan.releasedSecurityFarmlandCount=#released
    return true,nil,evaluation
end

function RFF_PropertyFinanceService:getMortgageRecoveryAssessment(loan, voluntary)
    if loan == nil or loan.type ~= RFF_LoanService.TYPE_MORTGAGE then return nil end
    local landMarketValue = self:getMortgageSecurityValue(loan)
    local fixtures = self:getMortgageRecoveryFixtures(loan, voluntary)
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(loan) or math.max(0, safeNumber(loan.arrearsBalance))
    local debt = math.max(0, safeNumber(loan.principal)) + arrears
    local factor = voluntary == true and self.MORTGAGE_VOLUNTARY_REALISATION_FACTOR or self.MORTGAGE_FORCED_REALISATION_FACTOR
    local costRate = voluntary == true and self.MORTGAGE_VOLUNTARY_COST_RATE or self.MORTGAGE_FORCED_COST_RATE
    local landGrossRealisation = math.max(0, landMarketValue * factor)
    local grossRealisation = landGrossRealisation + fixtures.fixtureRealisedValue
    local totalMarketValue = landMarketValue + fixtures.fixtureMarketValue
    local recoveryCosts = math.max(self.MORTGAGE_MIN_RECOVERY_COST, math.min(self.MORTGAGE_MAX_RECOVERY_COST, totalMarketValue * costRate))
    local realisedValue = math.max(0, grossRealisation - recoveryCosts)
    local shortfall = math.max(0, debt - realisedValue)
    local surplus = math.max(0, realisedValue - debt)
    local shortfallRate = math.max(safeNumber(loan.interestRate) + 3.00, (self.loanService ~= nil and self.loanService:getBaseRate() or 5.50) + 4.50)
    return {
        sourceType = "PROPERTY",
        method = voluntary == true and "VOLUNTARY_PROPERTY_SALE" or "MORTGAGE_POSSESSION",
        farmlandId = loan.securityFarmlandId or 0,
        farmlandIds = loan.securityFarmlandIds or tostring(loan.securityFarmlandId or 0),
        farmlandCount = #self:getMortgageSecurityFarmlandIds(loan),
        securityLabel = self:getMortgageSecurityLabel(loan),
        marketValue = landMarketValue,
        landMarketValue = landMarketValue,
        fixtureMarketValue = fixtures.fixtureMarketValue,
        totalMarketValue = totalMarketValue,
        placeableCount = fixtures.placeableCount,
        husbandryCount = fixtures.husbandryCount,
        animalCount = fixtures.animalCount,
        livestockMarketValue = fixtures.livestockMarketValue,
        livestockRealisedValue = fixtures.livestockRealisedValue,
        landGrossRealisation = landGrossRealisation,
        fixtureGrossRealisation = fixtures.fixtureRealisedValue,
        grossRealisation = grossRealisation,
        recoveryCosts = recoveryCosts,
        realisedValue = realisedValue,
        debt = debt,
        arrears = arrears,
        shortfall = shortfall,
        surplus = surplus,
        shortfallRate = shortfallRate,
        fixtureAssessment = fixtures
    }
end

function RFF_PropertyFinanceService:canRestructureMortgage(loan)
    if loan == nil or loan.paidOff or loan.type ~= RFF_LoanService.TYPE_MORTGAGE then return false, "invalid", nil end
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(loan) or math.max(0, safeNumber(loan.arrearsBalance))
    if arrears <= 0.01 then return false, "no_arrears", nil end
    local stage = loan.arrearsStage or "CURRENT"
    local inDefault = loan.currentDefault == true or stage == "DEFAULT_NOTICE" or stage == "FORMAL_DEMAND" or stage == "POSSESSION_WARNING" or stage == "RECOVERY"
    if not inDefault then return false, "too_early", nil end
    local relationshipCode = "NEW"
    if self.relationshipService ~= nil then
        local benefits = self.relationshipService:getBenefits(loan.farmId, loan.lenderId or "PRIMARY_BANK")
        relationshipCode = benefits ~= nil and benefits.code or "NEW"
    end
    local maxRestructures = relationshipCode == "TRUSTED" and 2 or 1
    if math.max(0, math.floor(safeNumber(loan.mortgageRestructureCount))) >= maxRestructures then return false, "already_restructured", nil end
    local security = self:getMortgageSecurityValue(loan)
    if security <= 0 then return false, "security_missing", nil end
    local restructuredPrincipal = math.max(0, safeNumber(loan.principal)) + arrears
    local ltv = restructuredPrincipal / security
    if ltv > self.MORTGAGE_RESTRUCTURE_MAX_LTV then return false, "equity", {securityValue=security, principal=restructuredPrincipal, ltv=ltv} end
    local extension = self.MORTGAGE_RESTRUCTURE_EXTENSION_MONTHS
    local rateUplift = self.MORTGAGE_RESTRUCTURE_RATE_UPLIFT
    if relationshipCode == "DEVELOPING" then
        rateUplift = 0.65
    elseif relationshipCode == "PROVEN" then
        extension = 18
        rateUplift = 0.50
    elseif relationshipCode == "TRUSTED" then
        extension = 24
        rateUplift = 0.35
    elseif relationshipCode == "STRAINED" then
        rateUplift = 1.00
    end
    local newRemaining = math.max(12, math.floor(safeNumber(loan.remainingMonths)) + extension)
    local newRate = math.max(0, safeNumber(loan.interestRate) + rateUplift)
    local newPayment = self.loanService ~= nil and self.loanService:calculateAnnuityPayment(restructuredPrincipal, newRate, newRemaining) or 0
    return true, nil, {
        securityValue=security, principal=restructuredPrincipal, capitalisedArrears=arrears,
        ltv=ltv, extensionMonths=extension, remainingMonths=newRemaining,
        interestRate=newRate, monthlyPayment=newPayment, relationshipCode=relationshipCode,
        maxRestructures=maxRestructures, restructureNumber=math.max(0, math.floor(safeNumber(loan.mortgageRestructureCount))) + 1
    }
end

function RFF_PropertyFinanceService:notifyMortgageEvent(loan, titleKey, fallbackTitle, textKey, ...)
    if loan == nil or g_currentMission == nil then return end
    local text = string.format(g_i18n:getText(textKey), ...)
    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(loan.lenderNameKey, "Primary Farm Bank")
        local title = RFF_NotificationService:getText(titleKey, fallbackTitle)
        if RFF_NotificationService:send(loan.farmId, sender, title, text, "property", text, true) then return end
    end
    if g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, text)
    end
end

function RFF_PropertyFinanceService:restructureMortgage(loan)
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "server_only", nil end
    local eligible, reason, terms = self:canRestructureMortgage(loan)
    if not eligible then return false, reason, terms end

    local oldRate = safeNumber(loan.interestRate)
    local oldPayment = safeNumber(loan.monthlyPayment)
    loan.principal = terms.principal
    loan.interestRate = terms.interestRate
    loan.remainingMonths = terms.remainingMonths
    loan.termMonths = math.max(math.floor(safeNumber(loan.termMonths)), terms.remainingMonths) + terms.extensionMonths
    loan.monthlyPayment = terms.monthlyPayment
    loan.riskGrade = "D"
    loan.mortgageRestructureCount = math.max(0, math.floor(safeNumber(loan.mortgageRestructureCount))) + 1
    loan.mortgageLastRestructurePeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    loan.mortgageCapitalisedArrears = safeNumber(loan.mortgageCapitalisedArrears) + terms.capitalisedArrears
    loan.mortgageRateBeforeRestructure = oldRate
    loan.mortgagePaymentBeforeRestructure = oldPayment
    loan.mortgageRecoveryPending = false
    loan.mortgageRecoveryEligiblePeriod = 0
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(loan, self.repository) end
    if self.relationshipService ~= nil then
        self.relationshipService:recordArrearsCleared(loan)
        self.relationshipService:recordMortgageRestructure(loan)
    end

    self:notifyMortgageEvent(loan, "rff_phone_title_mortgage", "Mortgage Update", "rff_mortgage_restructure_notification",
        self:getMortgageSecurityLabel(loan),
        g_i18n:formatMoney(terms.capitalisedArrears, 0, true, true),
        terms.extensionMonths,
        terms.interestRate,
        g_i18n:formatMoney(terms.monthlyPayment, 0, true, true))
    return true, nil, terms
end

function RFF_PropertyFinanceService:notifyMortgageRecoveryEligible(loan)
    local fixtures = self:getMortgageRecoveryFixtures(loan, false)
    self:notifyMortgageEvent(loan, "rff_phone_title_default", "Default Notice", "rff_mortgage_recovery_eligible_notification",
        self:getMortgageSecurityLabel(loan),
        g_i18n:formatMoney(math.max(0, safeNumber(loan.principal)) + math.max(0, safeNumber(loan.arrearsBalance)), 0, true, true),
        fixtures.placeableCount or 0, fixtures.animalCount or 0)
end

function RFF_PropertyFinanceService:recoverMortgageProperty(loan, voluntary)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or loan.paidOff or loan.type ~= RFF_LoanService.TYPE_MORTGAGE then
        return false, "invalid", nil
    end
    local stage = loan.arrearsStage or "CURRENT"
    if voluntary == true then
        if loan.currentDefault ~= true and stage ~= "DEFAULT_NOTICE" and stage ~= "FORMAL_DEMAND" and stage ~= "POSSESSION_WARNING" and stage ~= "RECOVERY" then
            return false, "not_default", nil
        end
    elseif loan.recoveryEligible ~= true then
        return false, "not_eligible", nil
    end

    local securityIds = self:getMortgageSecurityFarmlandIds(loan)
    if #securityIds == 0 then return false, "security_missing", nil end
    for _, farmlandId in ipairs(securityIds) do
        local farmland = self:getFarmland(farmlandId)
        if farmland == nil then return false, "security_missing", nil end
        if g_farmlandManager:getFarmlandOwner(farmlandId) ~= loan.farmId then return false, "security_not_owned", nil end
    end

    local assessment = self:getMortgageRecoveryAssessment(loan, voluntary)
    if assessment == nil then return false, "assessment", nil end
    if voluntary == true and (assessment.animalCount or 0) > 0 then
        return false, "livestock_present", assessment
    end

    local promotedPlaceables, promotionFailures, animalClusterFailures = self:prepareRecoveredPlaceablesForNativeSale(assessment.fixtureAssessment, voluntary)

    local farmlandTransferFailures = 0
    for _, farmlandId in ipairs(securityIds) do
        if not self:transferFarmlandByNativeSale(farmlandId) then
            farmlandTransferFailures = farmlandTransferFailures + 1
        end
    end
    if farmlandTransferFailures > 0 then
        return false, "farmland_transfer_failed", assessment
    end

    local transferredPlaceables, failedPlaceables = self:countRecoveredPlaceableOwnership(assessment.fixtureAssessment, loan.farmId)
    failedPlaceables = failedPlaceables + promotionFailures

    if voluntary ~= true and (assessment.livestockRealisedValue or 0) > 0.01 then
        if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
            self.repository:setNextTransactionDescription(loan.farmId, string.format("Forced livestock sale on mortgage possession - %s", self:getMortgageSecurityLabel(loan)))
        end
        g_currentMission:addMoney(assessment.livestockRealisedValue, loan.farmId, nonOperatingLiquidationMoneyType(), true, true)
    end

    if assessment.surplus > 0.01 then
        if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
            self.repository:setNextTransactionDescription(loan.farmId, string.format("Mortgage recovery surplus - %s", self:getMortgageSecurityLabel(loan)))
        end
        g_currentMission:addMoney(assessment.surplus, loan.farmId, moneyTypeFallback(), true, true)
    end

    local liability = nil
    if assessment.shortfall > 0.01 and self.loanService ~= nil and self.loanService.createRecoveryShortfall ~= nil then
        liability = self.loanService:createRecoveryShortfall(loan, assessment.shortfall, assessment.shortfallRate, assessment)
    end

    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(loan, self.repository) end
    loan.principal = 0
    loan.remainingMonths = 0
    loan.paidOff = true
    loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    loan.mortgageRecovered = true
    loan.mortgageRecoveredPeriod = loan.completedPeriod
    loan.mortgageRecoveryMethod = assessment.method
    loan.mortgageMarketValue = assessment.marketValue
    loan.mortgageRealisedValue = assessment.realisedValue
    loan.mortgageRecoveryCosts = assessment.recoveryCosts
    loan.mortgageDebtAtRecovery = assessment.debt
    loan.mortgageRecoveryShortfall = assessment.shortfall
    loan.mortgageRecoverySurplus = assessment.surplus
    loan.mortgageRecoveredFixtureCount = assessment.placeableCount or 0
    loan.mortgageRecoveredFixtureMarketValue = assessment.fixtureMarketValue or 0
    loan.mortgageRecoveredFixtureRealisedValue = assessment.fixtureGrossRealisation or 0
    loan.mortgageForcedLivestockCount = voluntary == true and 0 or (assessment.animalCount or 0)
    loan.mortgageForcedLivestockMarketValue = voluntary == true and 0 or (assessment.livestockMarketValue or 0)
    loan.mortgageForcedLivestockProceeds = voluntary == true and 0 or (assessment.livestockRealisedValue or 0)
    loan.mortgageRecoveryPlaceablesDeleted = 0 -- legacy v0.8.1.1 field retained for save compatibility
    loan.mortgageRecoveryPlaceablesTransferred = transferredPlaceables or 0
    loan.mortgageRecoveryPlaceablesPromotedToFarmland = promotedPlaceables or 0
    loan.mortgageRecoveryPlaceableFailures = failedPlaceables or 0
    loan.mortgageRecoveryAnimalClusterFailures = animalClusterFailures or 0
    loan.mortgageRecoveryLiabilityLoanId = liability ~= nil and (liability.id or 0) or 0
    loan.mortgageRecoveredFarmlandIds = joinIdList(securityIds)
    loan.mortgageRecoveredFarmlandCount = #securityIds
    loan.mortgageRecoveryPending = false
    loan.mortgageRecoveryEligiblePeriod = 0
    loan.recoveryEligible = false
    loan.currentDefault = false
    if self.relationshipService ~= nil then self.relationshipService:recordRecovery(loan, true, voluntary == true) end

    self:notifyMortgageEvent(loan, "rff_phone_title_mortgage", "Mortgage Update",
        voluntary == true and "rff_mortgage_voluntary_recovery_complete_notification" or "rff_mortgage_forced_recovery_complete_notification",
        self:getMortgageSecurityLabel(loan),
        g_i18n:formatMoney(assessment.realisedValue, 0, true, true),
        g_i18n:formatMoney(assessment.shortfall, 0, true, true),
        g_i18n:formatMoney(assessment.surplus, 0, true, true))
    if voluntary ~= true and (assessment.animalCount or 0) > 0 then
        self:notifyMortgageEvent(loan, "rff_phone_title_mortgage", "Mortgage Update", "rff_mortgage_forced_livestock_sale_notification",
            assessment.animalCount or 0, g_i18n:formatMoney(assessment.livestockRealisedValue or 0, 0, true, true))
    end
    return true, nil, assessment
end

function RFF_PropertyFinanceService:attemptForcedMortgageRecovery(loan)
    if loan == nil or loan.type ~= RFF_LoanService.TYPE_MORTGAGE or loan.recoveryEligible ~= true then return false, "not_eligible", nil end
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local eligiblePeriod = math.max(0, math.floor(safeNumber(loan.mortgageRecoveryEligiblePeriod)))
    if eligiblePeriod <= 0 then
        loan.mortgageRecoveryEligiblePeriod = current
        loan.mortgageRecoveryPending = true
        return false, "grace", nil
    end
    if current <= eligiblePeriod then
        loan.mortgageRecoveryPending = true
        return false, "grace", nil
    end
    return self:recoverMortgageProperty(loan, false)
end

function RFF_PropertyFinanceService:getTenancyAnnualRate(termMonths)
    if termMonths >= 60 then return 0.0375 end
    if termMonths >= 36 then return 0.0400 end
    if termMonths >= 24 then return 0.0425 end
    return 0.0450
end

local TENANCY_LANDLORD_PROFILES = {
    PRIVATE_LANDOWNER = {
        id="PRIVATE_LANDOWNER", nameKey="rff_landlord_private_landowner", approachKey="rff_landlord_approach_balanced",
        descriptionKey="rff_landlord_private_profile", prioritiesKey="rff_landlord_private_priorities",
        initialRentFactor=1.00, renewalRentFactor=1.025, negotiationMargin=0.040, considerationMargin=0.040, baseRounds=3
    },
    FAMILY_LANDHOLDING = {
        id="FAMILY_LANDHOLDING", nameKey="rff_landlord_family_landholding", approachKey="rff_landlord_approach_flexible",
        descriptionKey="rff_landlord_family_profile", prioritiesKey="rff_landlord_family_priorities",
        initialRentFactor=0.98, renewalRentFactor=1.020, negotiationMargin=0.050, considerationMargin=0.050, baseRounds=3
    },
    REGIONAL_LAND_PARTNERSHIP = {
        id="REGIONAL_LAND_PARTNERSHIP", nameKey="rff_landlord_regional_partnership", approachKey="rff_landlord_approach_balanced",
        descriptionKey="rff_landlord_regional_profile", prioritiesKey="rff_landlord_regional_priorities",
        initialRentFactor=1.00, renewalRentFactor=1.025, negotiationMargin=0.035, considerationMargin=0.035, baseRounds=3
    },
    AGRICULTURAL_LAND_TRUST = {
        id="AGRICULTURAL_LAND_TRUST", nameKey="rff_landlord_agricultural_trust", approachKey="rff_landlord_approach_structured",
        descriptionKey="rff_landlord_trust_profile", prioritiesKey="rff_landlord_trust_priorities",
        initialRentFactor=1.01, renewalRentFactor=1.030, negotiationMargin=0.025, considerationMargin=0.025, baseRounds=2
    },
    LAND_MANAGEMENT_COMPANY = {
        id="LAND_MANAGEMENT_COMPANY", nameKey="rff_landlord_management_company", approachKey="rff_landlord_approach_firm",
        descriptionKey="rff_landlord_company_profile", prioritiesKey="rff_landlord_company_priorities",
        initialRentFactor=1.03, renewalRentFactor=1.035, negotiationMargin=0.015, considerationMargin=0.015, baseRounds=2
    }
}

local TENANCY_LANDLORD_ORDER = {
    "PRIVATE_LANDOWNER", "FAMILY_LANDHOLDING", "REGIONAL_LAND_PARTNERSHIP",
    "AGRICULTURAL_LAND_TRUST", "LAND_MANAGEMENT_COMPANY"
}

local TENANCY_COVENANT_PACKAGE_VERSION = 2
local TENANCY_ENTERPRISES = {MIXED=true, ARABLE=true, LIVESTOCK=true}
local TENANCY_APPLICATION_STATES = {APPLICATION=true, APPLICATION_REVIEW=true, APPLICATION_HEADS=true}
local TENANCY_NARRATIVE_COMMENCED_STATES = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true, ENDED=true, ENDED_RENEWED=true, TERMINATED=true}
local TENANCY_REVIEW_INTERVALS = {[0]=true, [12]=true, [24]=true, [36]=true}
local TENANCY_BREAK_NOTICE_MONTHS = {[3]=true, [6]=true, [12]=true}
local TENANCY_LANDLORD_VARIATION_NOTICE_MONTHS = {[3]=true, [6]=true, [12]=true}
local TENANCY_LANDLORD_VARIATION_COOLDOWN_MONTHS = {[12]=true, [24]=true, [36]=true}
local TENANCY_COVENANT_WEIGHTS = {
    PRIVATE_LANDOWNER={enterprise=1.00, grass=1.00, boundary=1.00, improvements=1.00, maintenance=1.00, review=1.00, breakRight=1.00, variationNotice=1.00, variationCooldown=1.00, packageFlexibility=1},
    FAMILY_LANDHOLDING={enterprise=0.90, grass=1.05, boundary=0.90, improvements=0.90, maintenance=1.20, review=0.85, breakRight=0.85, variationNotice=0.90, variationCooldown=0.90, packageFlexibility=1},
    REGIONAL_LAND_PARTNERSHIP={enterprise=1.00, grass=1.00, boundary=1.05, improvements=1.00, maintenance=1.10, review=1.10, breakRight=1.05, variationNotice=1.05, variationCooldown=1.05, packageFlexibility=0},
    AGRICULTURAL_LAND_TRUST={enterprise=1.10, grass=1.45, boundary=1.35, improvements=1.20, maintenance=1.10, review=0.90, breakRight=1.05, variationNotice=1.10, variationCooldown=1.15, packageFlexibility=0},
    LAND_MANAGEMENT_COMPANY={enterprise=0.90, grass=0.90, boundary=1.00, improvements=1.00, maintenance=1.15, review=1.35, breakRight=1.30, variationNotice=1.25, variationCooldown=1.30, packageFlexibility=0}
}

local TENANCY_COVENANT_FIELDS = {
    {key="permittedEnterprise", suffix="PermittedEnterprise"},
    {key="permanentGrassRestriction", suffix="PermanentGrassRestriction"},
    {key="boundaryRemovalRequiresConsent", suffix="BoundaryRemovalRequiresConsent"},
    {key="improvementsRequireConsent", suffix="ImprovementsRequireConsent"},
    {key="tenantMaintenanceObligation", suffix="TenantMaintenanceObligation"},
    {key="rentReviewIntervalMonths", suffix="RentReviewIntervalMonths"},
    {key="breakEnabled", suffix="BreakEnabled"},
    {key="breakNoticeMonths", suffix="BreakNoticeMonths"},
    {key="landlordVariationNoticeMonths", suffix="LandlordVariationNoticeMonths"},
    {key="landlordVariationCooldownMonths", suffix="LandlordVariationCooldownMonths"}
}

local function copyTenancyCovenantTerms(terms)
    local copy = {}
    if terms ~= nil then
        for _, field in ipairs(TENANCY_COVENANT_FIELDS) do copy[field.key] = terms[field.key] end
    end
    return copy
end

local function joinTenancyTerms(parts)
    if #parts == 0 then return "the existing covenant package" end
    if #parts == 1 then return parts[1] end
    return table.concat(parts, "; ")
end

local function resolveTenancyBool(value, fallback)
    if value == nil then return fallback == true end
    return value == true
end

function RFF_PropertyFinanceService:getLandlordProfile(profileId, farmlandId)
    if profileId == "PRIVATE_LANDLORD" then profileId = "PRIVATE_LANDOWNER" end
    if TENANCY_LANDLORD_PROFILES[profileId] ~= nil then return TENANCY_LANDLORD_PROFILES[profileId] end
    local numericId = math.max(1, math.floor(safeNumber(farmlandId)))
    local selectedId = TENANCY_LANDLORD_ORDER[((numericId - 1) % #TENANCY_LANDLORD_ORDER) + 1]
    return TENANCY_LANDLORD_PROFILES[selectedId]
end

function RFF_PropertyFinanceService:getLandlordName(profileId, farmlandId)
    local profile = self:getLandlordProfile(profileId, farmlandId)
    return g_i18n ~= nil and g_i18n:getText(profile.nameKey) or profile.id:gsub("_", " ")
end

function RFF_PropertyFinanceService:getLandlordApproach(profileId, farmlandId)
    local profile = self:getLandlordProfile(profileId, farmlandId)
    return g_i18n ~= nil and g_i18n:getText(profile.approachKey) or "Balanced"
end

function RFF_PropertyFinanceService:normaliseTenancyRenewalTerms(tenancy, terms)
    terms = terms or {}
    local enterprise = tostring(terms.permittedEnterprise or tenancy.permittedEnterprise or "MIXED"):upper()
    if not TENANCY_ENTERPRISES[enterprise] then enterprise = "MIXED" end
    local review = math.max(0, math.floor(safeNumber(terms.rentReviewIntervalMonths ~= nil
        and terms.rentReviewIntervalMonths or tenancy.rentReviewIntervalMonths)))
    if not TENANCY_REVIEW_INTERVALS[review] then review = review > 0 and 36 or 0 end
    local breakEnabled = resolveTenancyBool(terms.breakEnabled, tenancy.breakEnabled == true)
    local breakNotice = math.max(0, math.floor(safeNumber(terms.breakNoticeMonths ~= nil and terms.breakNoticeMonths or tenancy.breakNoticeMonths)))
    if breakEnabled and not TENANCY_BREAK_NOTICE_MONTHS[breakNotice] then breakNotice = 6 end
    if not breakEnabled then breakNotice = 0 end
    local variationNotice = math.max(3, math.floor(safeNumber(terms.landlordVariationNoticeMonths ~= nil
        and terms.landlordVariationNoticeMonths or tenancy.landlordVariationNoticeMonths)))
    if not TENANCY_LANDLORD_VARIATION_NOTICE_MONTHS[variationNotice] then variationNotice = 3 end
    local variationCooldown = math.max(12, math.floor(safeNumber(terms.landlordVariationCooldownMonths ~= nil
        and terms.landlordVariationCooldownMonths or tenancy.landlordVariationCooldownMonths)))
    if not TENANCY_LANDLORD_VARIATION_COOLDOWN_MONTHS[variationCooldown] then variationCooldown = 12 end
    local permanentGrass = resolveTenancyBool(terms.permanentGrassRestriction, tenancy.permanentGrassRestriction == true)
    -- A grass-retention covenant can only attach to a parcel recorded as grass at
    -- commencement. Unknown legacy holdings keep their existing position until the
    -- first RFF condition survey establishes the actual baseline.
    if tenancyHasRecordedGrass(tenancy) == false then permanentGrass = false end
    return {
        permittedEnterprise=enterprise,
        permanentGrassRestriction=permanentGrass,
        boundaryRemovalRequiresConsent=resolveTenancyBool(terms.boundaryRemovalRequiresConsent, tenancy.boundaryRemovalRequiresConsent ~= false),
        improvementsRequireConsent=resolveTenancyBool(terms.improvementsRequireConsent, tenancy.improvementsRequireConsent ~= false),
        tenantMaintenanceObligation=resolveTenancyBool(terms.tenantMaintenanceObligation, tenancy.tenantMaintenanceObligation ~= false),
        rentReviewIntervalMonths=review,
        breakEnabled=breakEnabled,
        breakNoticeMonths=breakNotice,
        landlordVariationNoticeMonths=variationNotice,
        landlordVariationCooldownMonths=variationCooldown
    }
end

function RFF_PropertyFinanceService:setTenancyRenewalTerms(tenancy, prefix, terms)
    if tenancy == nil then return nil end
    terms = self:normaliseTenancyRenewalTerms(tenancy, terms)
    for _, field in ipairs(TENANCY_COVENANT_FIELDS) do tenancy[prefix .. field.suffix] = terms[field.key] end
    return terms
end

function RFF_PropertyFinanceService:ensureTenancyRenewalCovenants(tenancy)
    if tenancy == nil then return end
    local packageVersion = math.max(0, math.floor(safeNumber(tenancy.renewalCovenantPackageVersion)))
    if packageVersion >= TENANCY_COVENANT_PACKAGE_VERSION then return end
    local current = self:normaliseTenancyRenewalTerms(tenancy, nil)
    if packageVersion <= 0 then
        self:setTenancyRenewalTerms(tenancy, "renewalOriginal", current)
        self:setTenancyRenewalTerms(tenancy, "renewalOffer", current)
        self:setTenancyRenewalTerms(tenancy, "renewalTenant", current)
    else
        -- Package v1 already stores a live rent-and-covenant negotiation. Add
        -- only the new landlord-variation protections so that an upgrade does
        -- not replace the player's or landlord's existing heads of terms.
        for _, prefix in ipairs({"renewalOriginal", "renewalOffer", "renewalTenant"}) do
            local noticeKey = prefix .. "LandlordVariationNoticeMonths"
            local cooldownKey = prefix .. "LandlordVariationCooldownMonths"
            if not TENANCY_LANDLORD_VARIATION_NOTICE_MONTHS[math.floor(safeNumber(tenancy[noticeKey]))] then
                tenancy[noticeKey] = current.landlordVariationNoticeMonths
            end
            if not TENANCY_LANDLORD_VARIATION_COOLDOWN_MONTHS[math.floor(safeNumber(tenancy[cooldownKey]))] then
                tenancy[cooldownKey] = current.landlordVariationCooldownMonths
            end
        end
    end
    tenancy.renewalCovenantPackageVersion = TENANCY_COVENANT_PACKAGE_VERSION
end

function RFF_PropertyFinanceService:getTenancyRenewalTerms(tenancy, prefix)
    if tenancy == nil then return nil end
    self:ensureTenancyRenewalCovenants(tenancy)
    local terms = {}
    for _, field in ipairs(TENANCY_COVENANT_FIELDS) do terms[field.key] = tenancy[prefix .. field.suffix] end
    return self:normaliseTenancyRenewalTerms(tenancy, terms)
end

function RFF_PropertyFinanceService:getTenancyRenewalPackageSummary(terms)
    terms = terms or {}
    local enterprise = tostring(terms.permittedEnterprise or "MIXED")
    local parts = {
        enterprise == "ARABLE" and "arable use" or (enterprise == "LIVESTOCK" and "livestock use" or "mixed farming"),
        terms.permanentGrassRestriction == true and "recorded grass parcels retained" or "cropping permitted",
        terms.boundaryRemovalRequiresConsent ~= false and "boundary consent required" or "boundary consent not required",
        terms.improvementsRequireConsent ~= false and "improvement consent required" or "improvement consent not required",
        terms.tenantMaintenanceObligation ~= false and "tenant maintenance" or "shared maintenance"
    }
    local review = math.max(0, math.floor(safeNumber(terms.rentReviewIntervalMonths)))
    parts[#parts + 1] = review > 0 and string.format("rent review every %d months", review) or "no scheduled rent review"
    if terms.breakEnabled == true then
        parts[#parts + 1] = string.format("half-term tenant break with %d months' notice", math.max(3, math.floor(safeNumber(terms.breakNoticeMonths))))
    else
        parts[#parts + 1] = "no tenant break"
    end
    parts[#parts + 1] = string.format("landlord changes: %d months' notice and %d months between changes",
        math.max(3, math.floor(safeNumber(terms.landlordVariationNoticeMonths))),
        math.max(12, math.floor(safeNumber(terms.landlordVariationCooldownMonths))))
    return joinTenancyTerms(parts)
end

function RFF_PropertyFinanceService:encodeTenancyRenewalTerms(terms)
    terms = terms or {}
    return string.format("enterprise=%s;grass=%d;boundaryConsent=%d;improvementConsent=%d;tenantMaintenance=%d;reviewMonths=%d;break=%d;breakNotice=%d;landlordChangeNotice=%d;landlordChangeCooldown=%d",
        tostring(terms.permittedEnterprise or "MIXED"), terms.permanentGrassRestriction == true and 1 or 0,
        terms.boundaryRemovalRequiresConsent ~= false and 1 or 0, terms.improvementsRequireConsent ~= false and 1 or 0,
        terms.tenantMaintenanceObligation ~= false and 1 or 0, math.max(0, math.floor(safeNumber(terms.rentReviewIntervalMonths))),
        terms.breakEnabled == true and 1 or 0, math.max(0, math.floor(safeNumber(terms.breakNoticeMonths))),
        math.max(3, math.floor(safeNumber(terms.landlordVariationNoticeMonths))),
        math.max(12, math.floor(safeNumber(terms.landlordVariationCooldownMonths))))
end

function RFF_PropertyFinanceService:getTenancyCovenantCost(tenancy, terms)
    local profile = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
    local weights = TENANCY_COVENANT_WEIGHTS[profile.id] or TENANCY_COVENANT_WEIGHTS.PRIVATE_LANDOWNER
    local cost = 0
    cost = cost + (terms.permittedEnterprise == "MIXED" and 0.006 * weights.enterprise or 0)
    cost = cost + (terms.permanentGrassRestriction ~= true and 0.012 * weights.grass or 0)
    cost = cost + (terms.boundaryRemovalRequiresConsent == false and 0.012 * weights.boundary or 0)
    cost = cost + (terms.improvementsRequireConsent == false and 0.010 * weights.improvements or 0)
    cost = cost + (terms.tenantMaintenanceObligation == false and 0.018 * weights.maintenance or 0)
    local review = math.max(0, math.floor(safeNumber(terms.rentReviewIntervalMonths)))
    cost = cost + ((review == 0 and 0.012 or (review == 36 and 0.008 or (review == 24 and 0.004 or 0))) * weights.review)
    if terms.breakEnabled == true then
        local noticeCost = safeNumber(terms.breakNoticeMonths) <= 3 and 0.006 or (safeNumber(terms.breakNoticeMonths) <= 6 and 0.003 or 0)
        cost = cost + (0.014 + noticeCost) * weights.breakRight
    end
    local variationNotice = math.max(3, math.floor(safeNumber(terms.landlordVariationNoticeMonths)))
    cost = cost + ((variationNotice >= 12 and 0.008 or (variationNotice >= 6 and 0.004 or 0)) * weights.variationNotice)
    local variationCooldown = math.max(12, math.floor(safeNumber(terms.landlordVariationCooldownMonths)))
    cost = cost + ((variationCooldown >= 36 and 0.009 or (variationCooldown >= 24 and 0.005 or 0)) * weights.variationCooldown)
    return cost, weights
end

function RFF_PropertyFinanceService:getTenancyCovenantPackageAssessment(tenancy, proposedTerms)
    local original = self:getTenancyRenewalTerms(tenancy, "renewalOriginal")
    local proposed = self:normaliseTenancyRenewalTerms(tenancy, proposedTerms)
    local originalCost, weights = self:getTenancyCovenantCost(tenancy, original)
    local proposedCost = self:getTenancyCovenantCost(tenancy, proposed)
    local changes = {}
    local groups = {
        {key="ENTERPRISE", fields={"permittedEnterprise"}, proposalLabel="the proposed enterprise use"},
        {key="GRASS", fields={"permanentGrassRestriction"}, proposalLabel="the proposed permanent-grass position"},
        {key="BOUNDARY", fields={"boundaryRemovalRequiresConsent"}, proposalLabel="the proposed boundary-consent position"},
        {key="IMPROVEMENTS", fields={"improvementsRequireConsent"}, proposalLabel="the proposed improvement-consent position"},
        {key="MAINTENANCE", fields={"tenantMaintenanceObligation"}, proposalLabel="the proposed maintenance allocation"},
        {key="REVIEW", fields={"rentReviewIntervalMonths"}, proposalLabel="the proposed rent-review cycle"},
        {key="BREAK", fields={"breakEnabled", "breakNoticeMonths"}, proposalLabel="the proposed break right"},
        {key="LANDLORD_VARIATION", fields={"landlordVariationNoticeMonths", "landlordVariationCooldownMonths"}, proposalLabel="the proposed landlord-change notice and cooldown protections"}
    }
    for _, group in ipairs(groups) do
        local changed = false
        for _, field in ipairs(group.fields) do if original[field] ~= proposed[field] then changed = true break end end
        if changed then
            local isolated = copyTenancyCovenantTerms(original)
            for _, field in ipairs(group.fields) do isolated[field] = proposed[field] end
            local isolatedCost = self:getTenancyCovenantCost(tenancy, isolated)
            changes[#changes + 1] = {key=group.key, fields=group.fields, proposalLabel=group.proposalLabel,
                delta=isolatedCost-originalCost}
        end
    end
    return {
        original=original, proposed=proposed, originalCost=originalCost, proposedCost=proposedCost,
        adjustmentRate=proposedCost-originalCost, changes=changes, weights=weights,
        summary=self:getTenancyRenewalPackageSummary(proposed), encoded=self:encodeTenancyRenewalTerms(proposed)
    }
end

function RFF_PropertyFinanceService:buildTenancyLandlordCounterTerms(tenancy, packageAssessment)
    local counter = copyTenancyCovenantTerms(packageAssessment.original)
    local tenantRequests = {}
    local accepted, retained = {}, {}
    for _, change in ipairs(packageAssessment.changes or {}) do
        if change.delta <= 0 then
            for _, field in ipairs(change.fields) do counter[field] = packageAssessment.proposed[field] end
            accepted[#accepted + 1] = change.proposalLabel
        else
            tenantRequests[#tenantRequests + 1] = change
        end
    end
    table.sort(tenantRequests, function(a, b) return a.delta < b.delta end)
    local relationship = self:getTenancyLandlordRelationship(tenancy)
    local allowance = math.max(0, math.floor(safeNumber(tenancy.renewalNegotiationAttempts)) - 1
        + math.floor(safeNumber(packageAssessment.weights.packageFlexibility))
        + ((relationship.code == "STRONG" or relationship.code == "TRUSTED") and 1 or 0)
        - (relationship.code == "STRAINED" and 1 or 0))
    for index, change in ipairs(tenantRequests) do
        if index <= allowance then
            for _, field in ipairs(change.fields) do counter[field] = packageAssessment.proposed[field] end
            accepted[#accepted + 1] = change.proposalLabel
        else
            retained[#retained + 1] = change.proposalLabel
        end
    end
    counter = self:normaliseTenancyRenewalTerms(tenancy, counter)
    local response
    if #accepted > 0 and #retained > 0 then
        response = string.format("The revised package incorporates %s, while the landlord retains its position on %s.",
            joinTenancyTerms(accepted), joinTenancyTerms(retained))
    elseif #accepted > 0 then
        response = string.format("The revised package incorporates %s.", joinTenancyTerms(accepted))
    elseif #retained > 0 then
        response = string.format("The landlord retains its existing position on %s.", joinTenancyTerms(retained))
    else
        response = "The covenant package remains as originally offered."
    end
    return counter, response
end

function RFF_PropertyFinanceService:adjustTenancyLandlordRelationship(tenancy, amount, reason)
    if tenancy == nil then return 0 end
    self:getTenancyLandlordRelationship(tenancy)
    tenancy.landlordRelationshipPoints = math.max(-20, math.min(25,
        safeNumber(tenancy.landlordRelationshipPoints) + safeNumber(amount)))
    tenancy.landlordRelationshipLastReason = reason or tenancy.landlordRelationshipLastReason or ""
    return tenancy.landlordRelationshipPoints
end

function RFF_PropertyFinanceService:getTenancyLandlordRelationship(tenancy)
    if tenancy == nil then return {code="PROFESSIONAL", key="rff_landlord_relationship_professional", points=0, concessionBonus=0, roundBonus=0} end
    if tenancy.landlordRelationshipInitialized ~= true then
        local interval = math.max(1, math.floor(safeNumber(tenancy.paymentIntervalMonths or 1)))
        local positive = safeNumber(tenancy.paymentsMade) * 0.25 * interval
        local negative = safeNumber(tenancy.missedPayments) * (1.5 + 0.25 * interval)
        tenancy.landlordRelationshipPoints = math.max(-20, math.min(20, positive - negative))
        tenancy.landlordRelationshipInitialized = true
        tenancy.landlordRelationshipLastReason = "MIGRATED_CONDUCT"
    end
    local points = safeNumber(tenancy.landlordRelationshipPoints)
    if points < -2 then return {code="STRAINED", key="rff_landlord_relationship_strained", points=points, concessionBonus=-0.010, roundBonus=-1} end
    if points >= 12 then return {code="TRUSTED", key="rff_landlord_relationship_trusted", points=points, concessionBonus=0.040, roundBonus=1} end
    if points >= 6 then return {code="STRONG", key="rff_landlord_relationship_strong", points=points, concessionBonus=0.025, roundBonus=1} end
    if points >= 2 then return {code="ESTABLISHED", key="rff_landlord_relationship_established", points=points, concessionBonus=0.010, roundBonus=0} end
    return {code="PROFESSIONAL", key="rff_landlord_relationship_professional", points=points, concessionBonus=0, roundBonus=0}
end

function RFF_PropertyFinanceService:getTenancyNegotiationAssessment(tenancy, proposalRent, proposedTerms)
    if tenancy == nil then return nil end
    local profile = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
    local relationship = self:getTenancyLandlordRelationship(tenancy)
    local originalRent = math.max(0, safeNumber(tenancy.renewalOriginalAnnualRent))
    if originalRent <= 0 then originalRent = math.max(0, safeNumber(tenancy.renewalOfferAnnualRent)) end
    local cleanConduct = safeNumber(tenancy.missedPayments) <= 0 and safeNumber(tenancy.arrears or tenancy.rentDue) <= 0.001
    local conductBonus = cleanConduct and 0.005 or 0
    local concession = math.max(0, profile.negotiationMargin + relationship.concessionBonus + conductBonus)
    local consideration = math.max(0.01, profile.considerationMargin + math.max(0, relationship.concessionBonus * 0.5))
    local packageTerms = proposedTerms or self:getTenancyRenewalTerms(tenancy, "renewalOffer")
    local package = self:getTenancyCovenantPackageAssessment(tenancy, packageTerms)
    local packageAdjustment = originalRent * package.adjustmentRate
    local acceptableRent = math.max(0, math.floor(originalRent * (1 - concession) + packageAdjustment + 0.5))
    local considerationFloor = math.max(0, math.floor(originalRent * (1 - concession - consideration) + packageAdjustment + 0.5))
    local maxRounds = math.max(2, math.min(4, math.floor(safeNumber(profile.baseRounds) + relationship.roundBonus)))
    local proposed = math.max(0, safeNumber(proposalRent))
    local outcome = proposed < considerationFloor and "IMMEDIATE_REJECT"
        or (proposed >= acceptableRent and "ACCEPTABLE" or "REVIEW_COUNTER")
    local postureKey
    if concession >= 0.075 then postureKey = "rff_landlord_posture_very_open"
    elseif concession >= 0.050 then postureKey = "rff_landlord_posture_open"
    elseif concession >= 0.030 then postureKey = "rff_landlord_posture_measured"
    else postureKey = "rff_landlord_posture_limited" end
    return {
        profile=profile, relationship=relationship, originalRent=originalRent, proposalRent=proposed,
        acceptableRent=acceptableRent, considerationFloor=considerationFloor, outcome=outcome,
        concession=concession, maxRounds=maxRounds, cleanConduct=cleanConduct, postureKey=postureKey,
        covenantPackage=package, packageAdjustment=packageAdjustment
    }
end

function RFF_PropertyFinanceService:getTenancyLandlordBrief(tenancy)
    if tenancy == nil then return nil end
    local assessment = self:getTenancyNegotiationAssessment(tenancy, tenancy.renewalTenantProposalRent or 0)
    local profile = assessment.profile
    if self.narrativeService ~= nil then
        self.narrativeService:ensureTenancyVoice(tenancy, profile.id, tenancy.farmlandId)
        if #(tenancy.narrativeEvents or {}) == 0 and TENANCY_NARRATIVE_COMMENCED_STATES[tenancy.status or ""] then
            self:createTenancyNarrative(tenancy, "TENANCY_STARTED", {
                token=string.format("tenancyStarted:%d", safeNumber(tenancy.id)),
                period=tenancy.commencementPeriod or tenancy.createdPeriod or 0,
                landlordRent=tenancy.annualRent, termMonths=tenancy.termMonths,
                memoryCode="NEW", relationshipCode="PROFESSIONAL", relationshipPoints=0,
                documentStatus="EXECUTED_TENANCY", outcome="COMMENCED"
            })
        end
    end
    return {
        name=self:getLandlordName(profile.id, tenancy.farmlandId),
        approach=self:getLandlordApproach(profile.id, tenancy.farmlandId),
        description=g_i18n ~= nil and g_i18n:getText(profile.descriptionKey) or profile.id:gsub("_", " "),
        priorities=g_i18n ~= nil and g_i18n:getText(profile.prioritiesKey) or "Reliable rent and land stewardship",
        relationshipCode=assessment.relationship.code,
        relationshipText=g_i18n ~= nil and g_i18n:getText(assessment.relationship.key) or assessment.relationship.code,
        relationshipPoints=assessment.relationship.points,
        posture=g_i18n ~= nil and g_i18n:getText(assessment.postureKey) or "Measured flexibility",
        communicationStyle=tenancy.npcCommunicationStyle or "BALANCED",
        voiceDescription=self.narrativeService ~= nil and self.narrativeService:getVoiceDescription(tenancy) or "Measured and personal",
        maxRounds=assessment.maxRounds,
        remainingRounds=math.max(0, assessment.maxRounds - safeNumber(tenancy.renewalNegotiationAttempts))
    }
end

function RFF_PropertyFinanceService:getTenancyOffer(farmlandId, termMonths)
    local farmland = self:getFarmland(farmlandId)
    if farmland == nil or not self:isFarmlandAvailableForAcquisition(farmlandId) then return nil end
    local price = math.max(0, safeNumber(farmland.price))
    termMonths = math.max(1, math.floor(safeNumber(termMonths)))
    local landlord = self:getLandlordProfile(nil, farmlandId)
    local annualRate = self:getTenancyAnnualRate(termMonths) * landlord.initialRentFactor
    local monthlyRent = price * annualRate / 12
    local securityDeposit = monthlyRent * 2
    return {price=price, termMonths=termMonths, annualRate=annualRate, monthlyRent=monthlyRent, securityDeposit=securityDeposit,
        cashRequired=securityDeposit+monthlyRent, landlord=landlord.id, landlordName=self:getLandlordName(landlord.id, farmlandId),
        landlordApproach=self:getLandlordApproach(landlord.id, farmlandId)}
end

local TENANCY_PAYMENT_INTERVALS = {MONTHLY=1, QUARTERLY=3, HALF_YEARLY=6, ANNUALLY=12}
local TENANCY_POSSESSION_STATES = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true}
local TENANCY_RENEWAL_OFFER_MONTHS = 6
local TENANCY_CONDITION_SURVEY_VERSION = 2
local TENANCY_INSPECTION_SCHEMA_VERSION = 2
local TENANCY_INSPECTION_INTERVAL_MONTHS = 12
local TENANCY_HANDBACK_SCHEMA_VERSION = 1
local TENANCY_HANDBACK_INSPECTION_MONTHS = 3
local TENANCY_BOUNDARY_MIN_EXPANSION_SQM = 500
local TENANCY_BOUNDARY_MIN_EXPANSION_RATE = 0.05
local TENANCY_BREACH_CASE_SCHEMA_VERSION = 2
local TENANCY_BREACH_CASE_OPEN = {REMEDY_NOTICE=true, FINAL_WARNING=true, TERMINATION_NOTICE=true}
local TENANCY_BREACH_ENFORCEMENT = {
    PRIVATE_LANDOWNER={remedyMonths=3, reviewMonths=2, terminationMonths=1, firstFeeRate=0.08, terminationFeeRate=0.18},
    FAMILY_LANDHOLDING={remedyMonths=4, reviewMonths=2, terminationMonths=2, firstFeeRate=0.06, terminationFeeRate=0.14},
    REGIONAL_LAND_PARTNERSHIP={remedyMonths=3, reviewMonths=2, terminationMonths=1, firstFeeRate=0.10, terminationFeeRate=0.20},
    AGRICULTURAL_LAND_TRUST={remedyMonths=2, reviewMonths=1, terminationMonths=1, firstFeeRate=0.12, terminationFeeRate=0.24},
    LAND_MANAGEMENT_COMPANY={remedyMonths=1, reviewMonths=1, terminationMonths=1, firstFeeRate=0.15, terminationFeeRate=0.30}
}
local TENANCY_BREACH_RELATIONSHIP_EFFECT = {
    STRAINED={remedyMonths=-1, feeFactor=1.25},
    PROFESSIONAL={remedyMonths=0, feeFactor=1.00},
    ESTABLISHED={remedyMonths=1, feeFactor=0.90},
    STRONG={remedyMonths=1, feeFactor=0.80},
    TRUSTED={remedyMonths=2, feeFactor=0.70}
}

local function displayConditionName(value)
    value = tostring(value or ""):gsub("_", " "):lower()
    return value:gsub("(%a)([%w']*)", function(first, rest) return first:upper() .. rest end)
end

function RFF_PropertyFinanceService:getActiveTenancyForFarmland(farmlandId, farmId)
    farmlandId = math.floor(safeNumber(farmlandId))
    farmId = math.floor(safeNumber(farmId))
    if farmlandId <= 0 or self.repository == nil then return nil end
    for _, tenancy in ipairs(self.repository.tenancies or {}) do
        if TENANCY_POSSESSION_STATES[tenancy.status or ""] and (farmId <= 0 or math.floor(safeNumber(tenancy.farmId)) == farmId) then
            for _, id in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
                if math.floor(safeNumber(id)) == farmlandId then return tenancy end
            end
        end
    end
    return nil
end

function RFF_PropertyFinanceService:isInitialTenancyApplication(tenancy)
    return tenancy ~= nil and (TENANCY_APPLICATION_STATES[tenancy.status or ""] == true
        or tostring(tenancy.applicationReference or "") ~= "" and tostring(tenancy.applicationStage or "") ~= "EXECUTED")
end

function RFF_PropertyFinanceService:getOpenTenancyApplicationForFarmland(farmlandId, farmId)
    farmlandId = math.floor(safeNumber(farmlandId))
    farmId = math.floor(safeNumber(farmId))
    if farmlandId <= 0 or self.repository == nil then return nil end
    for _, tenancy in ipairs(self.repository.tenancies or {}) do
        if TENANCY_APPLICATION_STATES[tenancy.status or ""] and (farmId <= 0 or math.floor(safeNumber(tenancy.farmId)) == farmId) then
            for _, id in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
                if math.floor(safeNumber(id)) == farmlandId then return tenancy end
            end
        end
    end
    return nil
end

function RFF_PropertyFinanceService:getInitialTenancyDefaultTerms(tenancy)
    local profile = self:getLandlordProfile(tenancy ~= nil and tenancy.landlord or nil, tenancy ~= nil and tenancy.farmlandId or 0)
    local hasGrass = tenancyHasRecordedGrass(tenancy) == true
    local termMonths = math.max(12, math.floor(safeNumber(tenancy ~= nil and tenancy.applicationRequestedTermMonths or 12)))
    local grassLed = hasGrass and (profile.id == "FAMILY_LANDHOLDING" or profile.id == "AGRICULTURAL_LAND_TRUST")
    local variationNotice = profile.id == "LAND_MANAGEMENT_COMPANY" and 3
        or ((profile.id == "FAMILY_LANDHOLDING" or profile.id == "AGRICULTURAL_LAND_TRUST") and 12 or 6)
    local variationCooldown = profile.id == "LAND_MANAGEMENT_COMPANY" and 12
        or ((profile.id == "FAMILY_LANDHOLDING" or profile.id == "AGRICULTURAL_LAND_TRUST") and 36 or 24)
    return self:normaliseTenancyRenewalTerms(tenancy, {
        permittedEnterprise=grassLed and "LIVESTOCK" or "MIXED",
        permanentGrassRestriction=grassLed,
        boundaryRemovalRequiresConsent=true,
        improvementsRequireConsent=true,
        tenantMaintenanceObligation=true,
        rentReviewIntervalMonths=termMonths >= 36 and 36 or 0,
        breakEnabled=termMonths >= 24,
        breakNoticeMonths=termMonths >= 24 and 6 or 0,
        landlordVariationNoticeMonths=variationNotice,
        landlordVariationCooldownMonths=variationCooldown
    })
end

function RFF_PropertyFinanceService:assessInitialTenancyCredit(tenancy)
    if tenancy == nil or self.repository == nil then return nil end
    local farmId = math.floor(safeNumber(tenancy.farmId))
    local valuation = RFF_FarmValuation ~= nil and RFF_FarmValuation:calculate(farmId, self.repository) or {
        cash=farmMoney(farmId), totalAssets=0, liabilities=0, farmland=0, buildings=0, equipment=0, livestock=0, inventory=0
    }
    local credit = RFF_CreditProfile ~= nil and RFF_CreditProfile:calculate(farmId, valuation, self.repository) or {
        trackedPeriods=0, monthlyIncome=0, debtToAssets=0, conductCode="EXCELLENT", currentArrears=0,
        consecutiveMissedPayments=0, forcedPropertyRecoveryEvents=0
    }
    local termMonths = math.max(12, math.floor(safeNumber(tenancy.applicationRequestedTermMonths)))
    local landlord = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
    local indicativeAnnualRent = math.max(0, safeNumber(tenancy.purchasePrice)) * self:getTenancyAnnualRate(termMonths) * landlord.initialRentFactor
    local proposedMonthlyRent = indicativeAnnualRent / 12
    local existingCommitments = (self.loanService ~= nil and self.loanService:getMonthlyDebtService(farmId) or 0)
        + math.max(0, safeNumber(self.repository:getMonthlyTenancyRent(farmId)))
    local monthlyIncome = math.max(0, safeNumber(credit.monthlyIncome))
    local affordability = monthlyIncome > 0 and monthlyIncome / math.max(1, existingCommitments + proposedMonthlyRent) or 0
    local score = 650 + math.min(60, math.max(0, safeNumber(credit.trackedPeriods)) * 5)
    local conductCode = tostring(credit.conductCode or "EXCELLENT")
    local conductAdjustments = {
        EXCELLENT=70, GOOD=45, WATCH=-20, RECOVERING=5, ARREARS=-150, SEVERE_ARREARS=-220,
        DEFAULT_LIABILITY=-230, MORTGAGE_POSSESSION_SEVERE=-210, MORTGAGE_POSSESSION_POOR=-105,
        MORTGAGE_POSSESSION_RECOVERING=-45, MORTGAGE_POSSESSION_HISTORIC=-10
    }
    score = score + (conductAdjustments[conductCode] or 0)
    local debtToAssets = math.max(0, safeNumber(credit.debtToAssets))
    if debtToAssets <= 0.25 then score = score + 50
    elseif debtToAssets <= 0.50 then score = score + 20
    elseif debtToAssets <= 0.75 then score = score - 20
    else score = score - 80 end
    if monthlyIncome <= 0 then
        score = score - (safeNumber(credit.trackedPeriods) < 3 and 0 or 25)
    elseif affordability >= 2 then score = score + 60
    elseif affordability >= 1.25 then score = score + 30
    elseif affordability < 0.90 then score = score - 70 end
    local cash = math.max(0, safeNumber(valuation.cash or farmMoney(farmId)))
    if cash >= proposedMonthlyRent * 5 then score = score + 30
    elseif cash >= proposedMonthlyRent * 3 then score = score + 10
    else score = score - 25 end
    score = math.max(300, math.min(900, math.floor(score + 0.5)))

    local band = score >= 760 and "A" or (score >= 680 and "B" or (score >= 600 and "C" or "D"))
    local depositMonths = band == "A" and 1 or (band == "B" and 2 or (band == "C" and 3 or 4))
    local severeConduct = safeNumber(credit.currentArrears) > 0.01 or conductCode == "SEVERE_ARREARS"
        or conductCode == "DEFAULT_LIABILITY" or conductCode == "MORTGAGE_POSSESSION_SEVERE"
    local decision
    if severeConduct or score < 460 then decision = "DECLINED"
    elseif band == "A" or band == "B" then decision = "APPROVED"
    else decision = "CONDITIONAL" end
    local affordabilityText
    if monthlyIncome <= 0 and safeNumber(credit.trackedPeriods) < 3 then affordabilityText = "startup history; cash and asset position considered"
    elseif affordability >= 1.5 then affordabilityText = "comfortable"
    elseif affordability >= 1.0 then affordabilityText = "adequate"
    else affordabilityText = "tight" end
    local decisionReason = severeConduct and "unresolved adverse payment conduct"
        or (score < 460 and "the overall financial assessment is below the landlord's minimum standard"
        or (decision == "CONDITIONAL" and string.format("additional security of %d months' rent is required", depositMonths)
        or "the application meets the landlord's financial standard"))
    return {
        score=score, band=band, decision=decision, decisionReason=decisionReason, depositMonths=depositMonths,
        monthlyIncome=monthlyIncome, existingCommitments=existingCommitments, proposedMonthlyRent=proposedMonthlyRent,
        affordability=affordability, affordabilityText=affordabilityText, conductCode=conductCode,
        trackedPeriods=math.max(0, math.floor(safeNumber(credit.trackedPeriods))), cash=cash,
        debtToAssets=debtToAssets, indicativeAnnualRent=indicativeAnnualRent
    }
end

function RFF_PropertyFinanceService:submitTenancyApplication(farmId, farmlandId, termMonths)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return nil, "server_only" end
    farmId = math.floor(safeNumber(farmId))
    farmlandId = math.floor(safeNumber(farmlandId))
    termMonths = math.max(12, math.floor(safeNumber(termMonths)))
    local farmland = self:getFarmland(farmlandId)
    if farmId <= 0 or farmland == nil then return nil, "invalid_land" end
    if g_farmlandManager:getFarmlandOwner(farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID
        or not self:isFarmlandAvailableForAcquisition(farmlandId)
        or self.repository:getTenancyByFarmland(farmlandId, true) ~= nil then return nil, "unavailable" end
    if self:getOpenTenancyApplicationForFarmland(farmlandId) ~= nil then return nil, "existing_open_application" end

    local current = self.repository:getCurrentPeriodIndex()
    local currentDay = self:getCurrentDay()
    local id = self.repository:getNextTenancyId()
    local applicationReference = string.format("RFF-TA-%06d", id)
    local landlord = self:getLandlordProfile(nil, farmlandId)
    local observed = self:surveyTenancyParcel(farmlandId)
    local footprint = self:surveyTenancyFieldFootprint(farmlandId)
    local initialFieldAreaSqm = footprint.available and footprint.detectedAreaSqm or footprint.officialAreaSqm
    local tenancy = {
        id=id, agreementId=applicationReference, applicationReference=applicationReference,
        farmId=farmId, farmlandId=farmlandId, farmlandIds={farmlandId}, landlord=landlord.id,
        holdingName=string.format("Land %d", farmlandId), purchasePrice=math.max(0, safeNumber(farmland.price)),
        securityDeposit=0, depositOriginal=0, depositHeld=0, annualRent=0, monthlyRent=0,
        paymentFrequency="MONTHLY", paymentIntervalMonths=1, termMonths=termMonths, remainingMonths=0,
        createdPeriod=current, commencementPeriod=current, contractualEndPeriod=current+4, nextRentDuePeriod=0,
        lastPaymentPeriod=0, paymentsMade=0, missedPayments=0, rentCharged=0, rentPaid=0, rentDue=0, arrears=0,
        status="APPLICATION", depositForfeited=false, rentReviewIntervalMonths=0, nextRentReviewPeriod=0,
        breakEnabled=false, earliestBreakPeriod=0, breakNoticeMonths=0, permittedEnterprise="MIXED",
        agriculturalUsePermitted=true, permanentGrassRestriction=false, boundaryRemovalRequiresConsent=true,
        improvementsRequireConsent=true, tenantMaintenanceObligation=true,
        landlordVariationNoticeMonths=6, landlordVariationCooldownMonths=24,
        settlementCompleted=false, settlementDepositApplied=0, settlementDepositReturned=0, settlementFinalBalance=0,
        settlementDilapidationCosts=0, settlementDilapidationCostsApplied=0,
        forfeitureProcessed=false, forfeiturePeriod=0, forfeitedPlaceableCount=0, forfeitedPlaceableValue=0,
        settlementDepositTransferred=0, expiryWarning12Sent=false, expiryWarning3Sent=false, expiryWarning1Sent=false,
        expiryNotificationSent=false, lastArrearsNotificationPeriod=0, commencementNotificationSent=false,
        renewalOfferStatus="PENDING", renewalOfferCreatedPeriod=0, renewalOfferExpiryPeriod=0,
        renewalOfferAnnualRent=0, renewalOriginalAnnualRent=0, renewalOfferTermMonths=termMonths,
        renewalOfferPaymentFrequency="MONTHLY", successorAgreementId=0, predecessorAgreementId=0,
        noticeServedPeriod=0, noticeEffectivePeriod=0, noticeReason="", breakExercisedPeriod=0,
        lastRentReviewPeriod=0, previousAnnualRent=0, renewalNegotiationStatus="NOT_STARTED", renewalNegotiationPeriod=0,
        renewalNegotiationAttempts=0, renewalNegotiatedAnnualRent=0, renewalNegotiationNextDay=0,
        renewalNegotiationLastUpdateDay=0, renewalTenantProposalRent=0, renewalLandlordCounterRent=0,
        renewalLegalReference="", renewalDocumentStatus="APPLICATION_RECEIVED", renewalCovenantPackageVersion=0,
        landlordRelationshipPoints=0, landlordRelationshipInitialized=true, landlordRelationshipLastReason="NEW_APPLICATION",
        landlordNegotiationRejections=0, consentNextId=1, consentLatestId=0, covenantComplianceStatus="PENDING",
        consentRequests={}, landlordVariationCount=0, lastLandlordVariationPeriod=0, nextLandlordVariationPeriod=0,
        conditionSurveyVersion=TENANCY_CONDITION_SURVEY_VERSION, conditionSurveyPeriod=current,
        conditionLastObservedPeriod=current, parcelConditions={{
            farmlandId=farmlandId, initialUse=observed.use, initialFruitName=observed.fruitName,
            initialGroundName=observed.groundName, currentUse=observed.use, currentFruitName=observed.fruitName,
            currentGroundName=observed.groundName, surveyedPeriod=current, lastObservedPeriod=current,
            initialFieldAreaSqm=initialFieldAreaSqm, currentFieldAreaSqm=initialFieldAreaSqm,
            officialFieldAreaSqm=footprint.officialAreaSqm, boundaryExpansionSqm=0,
            boundaryExpansionThresholdSqm=math.max(TENANCY_BOUNDARY_MIN_EXPANSION_SQM,
                initialFieldAreaSqm * TENANCY_BOUNDARY_MIN_EXPANSION_RATE),
            boundarySurveyAvailable=footprint.available,
            boundaryBaselineSource=footprint.available and "LIVE_COMMENCEMENT" or "MAP_FALLBACK"
        }}, alterationNextId=1, alterationLatestId=0, alterations={},
        applicationStage="ENQUIRY_RECEIVED", applicationSubmittedDay=currentDay,
        applicationNextActionDay=currentDay+1, applicationRequestedTermMonths=termMonths,
        applicationCreditScore=0, applicationCreditBand="", applicationCreditConduct="",
        applicationCreditAffordability="", applicationMonthlyIncome=0, applicationExistingCommitments=0,
        applicationDepositMonths=0, applicationLegalFee=0, applicationUpfrontCashRequired=0,
        applicationDecision="PENDING", applicationDecisionReason="", applicationLandlordIntroduced=false,
        narrativeNextEventId=1, narrativeLatestEventId=0, narrativeEvents={},
        handbackSchemaVersion=TENANCY_HANDBACK_SCHEMA_VERSION, handbackStatus="NONE", handbackReference="",
        handbackInspectionPeriod=0, handbackRemedyDeadlinePeriod=0, handbackFinalInspectionPeriod=0,
        handbackReviewCount=0, handbackItemCount=0, handbackUnresolvedCount=0,
        handbackEstimatedCost=0, handbackProfessionalFee=0, handbackFinalCost=0,
        handbackLatestSummary="", handbackItems={}
    }
    self.repository:addTenancy(tenancy)
    local event = self:createTenancyNarrative(tenancy, "APPLICATION_RECEIVED", {
        token=string.format("application:%d:RECEIVED", id), outcome="RECEIVED", documentStatus="APPLICATION_RECEIVED",
        termMonths=termMonths, reference=applicationReference, memoryCode="NEW"
    })
    print(string.format("[RealisticFarmFinance] Tenancy application submitted reference=%s farm=%d land=%d preferredTerm=%d nextDay=%d event=%s",
        applicationReference, farmId, farmlandId, termMonths, tenancy.applicationNextActionDay, tostring(event ~= nil)))
    return tenancy, nil
end

function RFF_PropertyFinanceService:getInitialTenancyCompletionCosts(tenancy)
    if tenancy == nil then return nil end
    local annualRent = math.max(0, safeNumber(tenancy.renewalOfferAnnualRent))
    local interval = TENANCY_PAYMENT_INTERVALS[tenancy.renewalOfferPaymentFrequency] or 1
    local instalment = annualRent * interval / 12
    local depositMonths = math.max(1, math.floor(safeNumber(tenancy.applicationDepositMonths or 2)))
    local deposit = annualRent / 12 * depositMonths
    local legalFee = math.max(250, math.min(1500, safeNumber(tenancy.applicationLegalFee) > 0
        and safeNumber(tenancy.applicationLegalFee) or annualRent * 0.025))
    return {annualRent=annualRent, instalment=instalment, deposit=deposit, legalFee=legalFee,
        total=instalment+deposit+legalFee, depositMonths=depositMonths, interval=interval}
end

function RFF_PropertyFinanceService:issueInitialTenancyHeads(tenancy)
    if tenancy == nil or not TENANCY_APPLICATION_STATES[tenancy.status or ""] then return false, "not_application" end
    local farmland = self:getFarmland(tenancy.farmlandId)
    if farmland == nil or g_farmlandManager:getFarmlandOwner(tenancy.farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID
        or not self:isFarmlandAvailableForAcquisition(tenancy.farmlandId)
        or self.repository:getTenancyByFarmland(tenancy.farmlandId, true) ~= nil then
        tenancy.status = "APPLICATION_DECLINED"
        tenancy.applicationStage = "CLOSED"
        tenancy.applicationDecision = "DECLINED"
        tenancy.applicationDecisionReason = "the holding is no longer available"
        tenancy.applicationNextActionDay = 0
        tenancy.renewalOfferStatus = "DECLINED"
        local unavailableEvent = self:createTenancyNarrative(tenancy, "APPLICATION_DECLINED", {
            token=string.format("application:%d:UNAVAILABLE", safeNumber(tenancy.id)), outcome="DECLINED",
            documentStatus="APPLICATION_CLOSED", creditReason=tenancy.applicationDecisionReason,
            reference=tenancy.applicationReference
        })
        self:notifyTenancyNarrative(tenancy, unavailableEvent, "rff_phone_title_tenancy_application_declined", "Tenancy Application Closed", false)
        return false, "unavailable"
    end

    local termMonths = math.max(12, math.floor(safeNumber(tenancy.applicationRequestedTermMonths)))
    local landlord = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
    local riskFactor = tenancy.applicationCreditBand == "A" and 0.99 or (tenancy.applicationCreditBand == "B" and 1
        or (tenancy.applicationCreditBand == "C" and 1.015 or 1.03))
    local annualRent = math.floor(math.max(0, safeNumber(farmland.price)) * self:getTenancyAnnualRate(termMonths)
        * landlord.initialRentFactor * riskFactor + 0.5)
    local initialTerms = self:getInitialTenancyDefaultTerms(tenancy)
    tenancy.permittedEnterprise = initialTerms.permittedEnterprise
    tenancy.permanentGrassRestriction = initialTerms.permanentGrassRestriction
    tenancy.boundaryRemovalRequiresConsent = initialTerms.boundaryRemovalRequiresConsent
    tenancy.improvementsRequireConsent = initialTerms.improvementsRequireConsent
    tenancy.tenantMaintenanceObligation = initialTerms.tenantMaintenanceObligation
    tenancy.rentReviewIntervalMonths = initialTerms.rentReviewIntervalMonths
    tenancy.breakEnabled = initialTerms.breakEnabled
    tenancy.breakNoticeMonths = initialTerms.breakNoticeMonths
    tenancy.landlordVariationNoticeMonths = initialTerms.landlordVariationNoticeMonths
    tenancy.landlordVariationCooldownMonths = initialTerms.landlordVariationCooldownMonths
    tenancy.renewalCovenantPackageVersion = 0
    self:ensureTenancyRenewalCovenants(tenancy)

    local current = self.repository:getCurrentPeriodIndex()
    tenancy.status = "APPLICATION_HEADS"
    tenancy.applicationStage = "HEADS_OFFERED"
    tenancy.applicationNextActionDay = 0
    tenancy.renewalOfferStatus = "OFFERED"
    tenancy.renewalOfferCreatedPeriod = current
    tenancy.renewalOfferExpiryPeriod = current + 3
    tenancy.contractualEndPeriod = current + 4
    tenancy.renewalOfferAnnualRent = annualRent
    tenancy.renewalOriginalAnnualRent = annualRent
    tenancy.renewalOfferTermMonths = termMonths
    tenancy.renewalOfferPaymentFrequency = "MONTHLY"
    tenancy.renewalNegotiationStatus = "NOT_STARTED"
    tenancy.renewalNegotiationPeriod = 0
    tenancy.renewalNegotiationAttempts = 0
    tenancy.renewalNegotiatedAnnualRent = 0
    tenancy.renewalNegotiationNextDay = 0
    tenancy.renewalNegotiationLastUpdateDay = self:getCurrentDay()
    tenancy.renewalTenantProposalRent = 0
    tenancy.renewalLandlordCounterRent = 0
    tenancy.renewalLegalReference = tenancy.applicationReference
    tenancy.renewalDocumentStatus = "INITIAL_HEADS_OF_TERMS"
    tenancy.applicationLegalFee = math.max(250, math.min(1500, annualRent * 0.025))
    local costs = self:getInitialTenancyCompletionCosts(tenancy)
    tenancy.securityDeposit = costs.deposit
    tenancy.depositOriginal = costs.deposit
    tenancy.applicationUpfrontCashRequired = costs.total

    local offerTerms = self:getTenancyRenewalTerms(tenancy, "renewalOffer")
    local event = self:createTenancyNarrative(tenancy, "INITIAL_HEADS", {
        token=string.format("application:%d:HEADS", safeNumber(tenancy.id)), outcome="OFFERED",
        documentStatus="INITIAL_HEADS_OF_TERMS", landlordRent=annualRent, termMonths=termMonths,
        paymentFrequency="MONTHLY", replyMonths=3, reference=tenancy.applicationReference,
        depositAmount=costs.deposit,
        legalFee=costs.legalFee, upfrontCosts=costs.total,
        packageSummary=self:getTenancyRenewalPackageSummary(offerTerms),
        landlordPackage=self:encodeTenancyRenewalTerms(offerTerms)
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_initial_heads", "Draft Tenancy Terms", false)
    print(string.format("[RealisticFarmFinance] Initial tenancy heads offered reference=%s rent=%.2f term=%d depositMonths=%d upfront=%.2f",
        tenancy.applicationReference or "-", annualRent, termMonths, costs.depositMonths, costs.total))
    return true
end

function RFF_PropertyFinanceService:processInitialTenancyApplicationDay(tenancy, currentDay)
    if tenancy == nil or not TENANCY_APPLICATION_STATES[tenancy.status or ""] then return false end
    if safeNumber(tenancy.applicationNextActionDay) <= 0 or currentDay < safeNumber(tenancy.applicationNextActionDay) then return false end
    local stage = tostring(tenancy.applicationStage or "ENQUIRY_RECEIVED")
    if stage == "ENQUIRY_RECEIVED" then
        tenancy.status = "APPLICATION_REVIEW"
        tenancy.applicationStage = "LANDLORD_INTRODUCTION"
        tenancy.applicationLandlordIntroduced = true
        tenancy.applicationNextActionDay = currentDay + 1
        tenancy.renewalDocumentStatus = "LANDLORD_INTRODUCTION"
        local profile = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
        local event = self:createTenancyNarrative(tenancy, "LANDLORD_INTRODUCTION", {
            token=string.format("application:%d:INTRODUCTION", safeNumber(tenancy.id)), outcome="INTRODUCED",
            documentStatus="LANDLORD_INTRODUCTION", reference=tenancy.applicationReference,
            landlordDescription=g_i18n ~= nil and g_i18n:getText(profile.descriptionKey) or profile.id:gsub("_", " "),
            landlordPriorities=g_i18n ~= nil and g_i18n:getText(profile.prioritiesKey) or "reliable rent and land stewardship",
            memoryCode="NEW"
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_landlord_introduction", "Landlord Introduction", false)
        return true
    end
    if stage == "LANDLORD_INTRODUCTION" then
        local assessment = self:assessInitialTenancyCredit(tenancy)
        if assessment == nil then return false end
        tenancy.applicationStage = "CREDIT_ASSESSMENT"
        tenancy.applicationCreditScore = assessment.score
        tenancy.applicationCreditBand = assessment.band
        tenancy.applicationCreditConduct = assessment.conductCode
        tenancy.applicationCreditAffordability = assessment.affordabilityText
        tenancy.applicationMonthlyIncome = assessment.monthlyIncome
        tenancy.applicationExistingCommitments = assessment.existingCommitments
        tenancy.applicationDepositMonths = assessment.depositMonths
        tenancy.applicationDecision = assessment.decision
        tenancy.applicationDecisionReason = assessment.decisionReason
        tenancy.renewalDocumentStatus = "CREDIT_ASSESSMENT"
        local creditEvent = self:createTenancyNarrative(tenancy, "CREDIT_ASSESSMENT", {
            token=string.format("application:%d:CREDIT", safeNumber(tenancy.id)), outcome=assessment.decision,
            documentStatus="CREDIT_ASSESSMENT", reference=tenancy.applicationReference,
            creditScore=assessment.score, creditBand=assessment.band, creditConduct=assessment.conductCode:gsub("_", " "):lower(),
            creditAffordability=assessment.affordabilityText, creditReason=assessment.decisionReason,
            depositMonths=assessment.depositMonths, memoryCode="NEW"
        })
        if assessment.decision == "DECLINED" then
            tenancy.status = "APPLICATION_DECLINED"
            tenancy.applicationStage = "CLOSED"
            tenancy.applicationNextActionDay = 0
            tenancy.renewalOfferStatus = "DECLINED"
            tenancy.renewalDocumentStatus = "APPLICATION_DECLINED"
            local declinedEvent = self:createTenancyNarrative(tenancy, "APPLICATION_DECLINED", {
                token=string.format("application:%d:DECLINED", safeNumber(tenancy.id)), outcome="DECLINED",
                documentStatus="APPLICATION_DECLINED", reference=tenancy.applicationReference,
                creditScore=assessment.score, creditBand=assessment.band, creditConduct=assessment.conductCode:gsub("_", " "):lower(),
                creditReason=assessment.decisionReason, memoryCode="NEW"
            })
            self:notifyTenancyNarrative(tenancy, declinedEvent, "rff_phone_title_tenancy_application_declined", "Tenancy Application Decision", false,
                g_i18n ~= nil and g_i18n:getText("rff_tenancy_applications_team") or "Agricultural Lettings Team")
        else
            tenancy.applicationNextActionDay = currentDay + 1
            self:notifyTenancyNarrative(tenancy, creditEvent, "rff_phone_title_tenancy_credit_assessment", "Tenancy Financial Assessment", false,
                g_i18n ~= nil and g_i18n:getText("rff_tenancy_applications_team") or "Agricultural Lettings Team")
        end
        return true
    end
    if stage == "CREDIT_ASSESSMENT" and tenancy.applicationDecision ~= "DECLINED" then
        return self:issueInitialTenancyHeads(tenancy)
    end
    return false
end

function RFF_PropertyFinanceService:canInstantTenancyDecision(tenancy,farmId)
    if not RFF_NewSaveSetup or not RFF_NewSaveSetup.isOpen(self.repository) or not tenancy or tenancy.farmId~=farmId
        or (tenancy.status~="APPLICATION" and tenancy.status~="APPLICATION_REVIEW") then return false end
    local stage=tenancy.applicationStage or "ENQUIRY_RECEIVED"
    if stage~="ENQUIRY_RECEIVED" and stage~="LANDLORD_INTRODUCTION" and stage~="CREDIT_ASSESSMENT" then return false end
    for _,record in ipairs(self.repository.tenancies or {}) do if record==tenancy then return true end end
    return false
end
function RFF_PropertyFinanceService:instantTenancyDecision(tenancy,farmId)
    if not self:canInstantTenancyDecision(tenancy,farmId) then return false end
    local day=self:getCurrentDay()
    for step=1,3 do
        if not self:canInstantTenancyDecision(tenancy,farmId) then break end
        local due=tenancy.applicationNextActionDay
        tenancy.applicationNextActionDay=day
        local stage=tenancy.applicationStage
        self:processInitialTenancyApplicationDay(tenancy,day)
        if tenancy.applicationStage==stage then tenancy.applicationNextActionDay=due;return false end
    end
    return tenancy.status=="APPLICATION_HEADS" or tenancy.status=="APPLICATION_DECLINED"
end

function RFF_PropertyFinanceService:surveyTenancyParcel(farmlandId)
    farmlandId = math.floor(safeNumber(farmlandId))
    local result = {farmlandId=farmlandId, use="UNCLASSIFIED", fruitName="", groundName=""}
    if farmlandId <= 0 or g_fieldManager == nil or g_fieldManager.getFieldById == nil then return result end
    local field = g_fieldManager:getFieldById(farmlandId)
    if field == nil then return result end
    if field.updateState ~= nil then pcall(field.updateState, field) end
    local state = field.getFieldState ~= nil and field:getFieldState() or field.fieldState
    if state == nil then return result end

    local fruitName = ""
    if g_fruitTypeManager ~= nil and g_fruitTypeManager.getFruitTypeNameByIndex ~= nil then
        fruitName = g_fruitTypeManager:getFruitTypeNameByIndex(state.fruitTypeIndex) or ""
    end
    local groundName = ""
    if FieldGroundType ~= nil and FieldGroundType.getName ~= nil then
        groundName = FieldGroundType.getName(state.groundType) or ""
    end
    local fruitUpper = tostring(fruitName):upper()
    local groundUpper = tostring(groundName):upper()
    local isGrass = fruitUpper == "GRASS" or groundUpper:find("GRASS", 1, true) ~= nil
    local hasCrop = fruitUpper ~= "" and fruitUpper ~= "UNKNOWN" and fruitUpper ~= "NONE"
    local cultivatedGround = groundUpper ~= "" and groundUpper ~= "NONE" and groundUpper:find("GRASS", 1, true) == nil
    if isGrass then result.use = "GRASS"
    elseif hasCrop or cultivatedGround then result.use = "ARABLE" end
    result.fruitName = fruitName
    result.groundName = groundName
    return result
end

-- GIANTS' AI field-course generator starts with BoundaryDetectionTask and follows
-- every connected non-zero terrain-detail pixel. Measuring that same footprint
-- lets an inspection identify a ploughed bridge between fields without treating
-- normal cultivation inside the map-defined field polygon as boundary works.
function RFF_PropertyFinanceService:surveyTenancyFieldFootprint(farmlandId)
    farmlandId = math.floor(safeNumber(farmlandId))
    local result = {
        farmlandId=farmlandId, available=false, officialAreaSqm=0, detectedAreaSqm=0,
        boundaryPoints=0, reason="unavailable"
    }
    if farmlandId <= 0 or g_fieldManager == nil or g_fieldManager.getFieldById == nil then return result end
    local field = g_fieldManager:getFieldById(farmlandId)
    if field == nil then result.reason = "field_not_found" return result end
    if field.getAreaHa ~= nil then result.officialAreaSqm = math.max(0, safeNumber(field:getAreaHa()) * 10000) end
    if BoundaryDetectionTask == nil or BoundaryDetectionTask.new == nil or field.getCenterOfFieldWorldPosition == nil then
        result.reason = "detector_unavailable"
        return result
    end

    local centerX, centerZ = field:getCenterOfFieldWorldPosition()
    local created, task = pcall(BoundaryDetectionTask.new, centerX, centerZ)
    if not created or task == nil then result.reason = "field_not_detected" return result end
    local inProgress = true
    local iterations = 0
    local startedAt = getTimeSec()
    while inProgress and iterations < 512 and getTimeSec() - startedAt < 0.35 do
        iterations = iterations + 1
        local updated, keepGoing = pcall(task.update, task, 0, 0.002)
        if not updated then result.reason = "detector_error" return result end
        inProgress = keepGoing == true
    end
    if inProgress then result.reason = "detector_timeout" return result end

    local points = task.boundaryPositions or {}
    if #points < 4 then result.reason = "boundary_unavailable" return result end
    local signedArea = 0
    for index = 1, #points do
        local current = points[index]
        local following = points[index % #points + 1]
        signedArea = signedArea + safeNumber(current[1]) * safeNumber(following[2])
            - safeNumber(following[1]) * safeNumber(current[2])
    end
    result.detectedAreaSqm = math.abs(signedArea) * 0.5
    result.boundaryPoints = #points
    result.available = result.detectedAreaSqm > 0
    result.reason = result.available and "ok" or "zero_area"
    return result
end

function RFF_PropertyFinanceService:recordTenancyAlteration(tenancy, alterationType, data)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then return nil end
    data = data or {}
    tenancy.alterations = tenancy.alterations or {}
    tenancy.alterationNextId = math.max(1, math.floor(safeNumber(tenancy.alterationNextId or 1)))
    local currentPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local currentDay = self:getCurrentDay()
    local farmlandId = math.floor(safeNumber(data.farmlandId or tenancy.farmlandId))
    local latest = tenancy.alterations[#tenancy.alterations]
    if alterationType == "LANDSCAPING" and latest ~= nil and latest.alterationType == alterationType
        and latest.farmlandId == farmlandId and latest.day == currentDay then
        latest.quantity = math.max(1, math.floor(safeNumber(latest.quantity))) + 1
        latest.value = safeNumber(latest.value) + safeNumber(data.value)
        latest.details = data.details or latest.details
        return latest
    end

    local ownerFarmId = math.floor(safeNumber(data.ownerFarmId))
    local ownership = data.assetOwnership
    if ownership == nil or ownership == "" then
        ownership = ownerFarmId == math.floor(safeNumber(tenancy.farmId)) and "TENANT" or "LANDLORD"
    end
    local alteration = {
        id=tenancy.alterationNextId, alterationType=tostring(alterationType or "ALTERATION"),
        farmlandId=farmlandId, period=currentPeriod, day=currentDay, ownerFarmId=ownerFarmId,
        assetOwnership=ownership, assetName=tostring(data.assetName or ""), category=tostring(data.category or ""),
        worldX=safeNumber(data.worldX), worldZ=safeNumber(data.worldZ),
        value=math.max(0, safeNumber(data.value)), quantity=math.max(1, math.floor(safeNumber(data.quantity or 1))),
        status=tostring(data.status or "OBSERVED"), consentReference=tostring(data.consentReference or ""),
        details=tostring(data.details or "")
    }
    tenancy.alterationNextId = tenancy.alterationNextId + 1
    tenancy.alterationLatestId = alteration.id
    table.insert(tenancy.alterations, alteration)
    print(string.format("[RealisticFarmFinance] Tenancy alteration recorded agreement=%s id=%d type=%s land=%d ownership=%s asset=%s",
        tostring(tenancy.agreementId or tenancy.id), alteration.id, alteration.alterationType,
        alteration.farmlandId, alteration.assetOwnership, alteration.assetName))
    return alteration
end

function RFF_PropertyFinanceService:recordTenancyAlterationAtWorldPosition(farmId, x, z, alterationType, data)
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return nil end
    local farmlandId = g_farmlandManager:getFarmlandIdAtWorldPosition(x, z)
    local tenancy = self:getActiveTenancyForFarmland(farmlandId, farmId)
    if tenancy == nil then return nil end
    data = data or {}
    data.farmlandId = farmlandId
    return self:recordTenancyAlteration(tenancy, alterationType, data)
end

function RFF_PropertyFinanceService:updateTenancyBoundaryEvidence(tenancy, parcel, footprint, observeChanges, legacyUpgrade)
    if tenancy == nil or parcel == nil or footprint == nil then return false end
    parcel.officialFieldAreaSqm = math.max(0, safeNumber(footprint.officialAreaSqm or parcel.officialFieldAreaSqm))
    if footprint.available ~= true then
        parcel.boundarySurveyAvailable = false
        return false
    end

    local detectedAreaSqm = math.max(0, safeNumber(footprint.detectedAreaSqm))
    local initialAreaSqm = math.max(0, safeNumber(parcel.initialFieldAreaSqm))
    if initialAreaSqm <= 0 then
        if legacyUpgrade == true and parcel.officialFieldAreaSqm > 0 then
            initialAreaSqm = parcel.officialFieldAreaSqm
            parcel.boundaryBaselineSource = "MAP_LEGACY_UPGRADE"
        else
            initialAreaSqm = detectedAreaSqm
            parcel.boundaryBaselineSource = "LIVE_COMMENCEMENT"
        end
        parcel.initialFieldAreaSqm = initialAreaSqm
    end

    local expansionSqm = math.max(0, detectedAreaSqm - initialAreaSqm)
    local thresholdSqm = math.max(TENANCY_BOUNDARY_MIN_EXPANSION_SQM,
        initialAreaSqm * TENANCY_BOUNDARY_MIN_EXPANSION_RATE)
    parcel.currentFieldAreaSqm = detectedAreaSqm
    parcel.boundaryExpansionSqm = expansionSqm
    parcel.boundaryExpansionThresholdSqm = thresholdSqm
    parcel.boundarySurveyAvailable = true
    if observeChanges ~= true or expansionSqm < thresholdSqm then return false end

    local farmlandId = math.floor(safeNumber(parcel.farmlandId))
    local existing = nil
    for index = #(tenancy.alterations or {}), 1, -1 do
        local alteration = tenancy.alterations[index]
        if tostring(alteration.alterationType or ""):upper() == "FIELD_BOUNDARY_EXPANSION"
            and math.floor(safeNumber(alteration.farmlandId)) == farmlandId then
            existing = alteration
            break
        end
    end
    local details = string.format("Connected field footprint expanded by %.2f ha (%.2f ha to %.2f ha; material threshold %.2f ha)",
        expansionSqm / 10000, initialAreaSqm / 10000, detectedAreaSqm / 10000, thresholdSqm / 10000)
    if existing == nil then
        existing = self:recordTenancyAlteration(tenancy, "FIELD_BOUNDARY_EXPANSION", {
            farmlandId=farmlandId, ownerFarmId=0, assetOwnership="LANDLORD",
            assetName="Connected field footprint", category="FIELD_BOUNDARY",
            value=expansionSqm, quantity=1, details=details
        })
        print(string.format("[RealisticFarmFinance] Material field-boundary expansion detected agreement=%s land=%d baseline=%.2fha detected=%.2fha expansion=%.2fha threshold=%.2fha",
            tostring(tenancy.agreementId or tenancy.id), farmlandId, initialAreaSqm / 10000,
            detectedAreaSqm / 10000, expansionSqm / 10000, thresholdSqm / 10000))
        return existing ~= nil
    end
    existing.value = math.max(safeNumber(existing.value), expansionSqm)
    existing.details = details
    existing.status = "OBSERVED"
    existing.consentReference = ""
    return false
end

function RFF_PropertyFinanceService:ensureTenancyConditionSurvey(tenancy, observeChanges)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then return false end
    local currentPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local previousSurveyVersion = math.max(0, math.floor(safeNumber(tenancy.conditionSurveyVersion)))
    tenancy.parcelConditions = tenancy.parcelConditions or {}
    local existing = {}
    for _, parcel in ipairs(tenancy.parcelConditions) do existing[math.floor(safeNumber(parcel.farmlandId))] = parcel end
    local changed = false

    for _, farmlandId in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
        farmlandId = math.floor(safeNumber(farmlandId))
        if farmlandId > 0 then
            local observed = self:surveyTenancyParcel(farmlandId)
            local parcel = existing[farmlandId]
            local footprint = nil
            if parcel == nil or observeChanges == true or previousSurveyVersion < TENANCY_CONDITION_SURVEY_VERSION then
                footprint = self:surveyTenancyFieldFootprint(farmlandId)
            end
            if parcel == nil then
                parcel = {
                    farmlandId=farmlandId, initialUse=observed.use, initialFruitName=observed.fruitName,
                    initialGroundName=observed.groundName, currentUse=observed.use,
                    currentFruitName=observed.fruitName, currentGroundName=observed.groundName,
                    surveyedPeriod=currentPeriod, lastObservedPeriod=currentPeriod
                }
                table.insert(tenancy.parcelConditions, parcel)
                existing[farmlandId] = parcel
                self:updateTenancyBoundaryEvidence(tenancy, parcel, footprint, false, false)
                changed = true
            elseif observeChanges == true then
                local previousUse = tostring(parcel.currentUse or parcel.initialUse or "UNCLASSIFIED")
                local nextUse = tostring(observed.use or "UNCLASSIFIED")
                if previousUse ~= nextUse and (previousUse == "ARABLE" or previousUse == "GRASS")
                    and (nextUse == "ARABLE" or nextUse == "GRASS") then
                    self:recordTenancyAlteration(tenancy, "LAND_USE_CHANGE", {
                        farmlandId=farmlandId, ownerFarmId=tenancy.farmId, assetOwnership="TENANT",
                        assetName=string.format("Land %d", farmlandId), category="LAND_USE",
                        details=string.format("%s to %s", previousUse, nextUse)
                    })
                    changed = true
                end
                parcel.currentUse = observed.use
                parcel.currentFruitName = observed.fruitName
                parcel.currentGroundName = observed.groundName
                parcel.lastObservedPeriod = currentPeriod
                if self:updateTenancyBoundaryEvidence(tenancy, parcel, footprint, true,
                    previousSurveyVersion < TENANCY_CONDITION_SURVEY_VERSION) then changed = true end
            else
                if footprint ~= nil then
                    self:updateTenancyBoundaryEvidence(tenancy, parcel, footprint, false,
                        previousSurveyVersion < TENANCY_CONDITION_SURVEY_VERSION)
                end
            end
        end
    end

    tenancy.conditionSurveyVersion = TENANCY_CONDITION_SURVEY_VERSION
    tenancy.conditionSurveyPeriod = safeNumber(tenancy.conditionSurveyPeriod) > 0 and tenancy.conditionSurveyPeriod or currentPeriod
    tenancy.conditionLastObservedPeriod = observeChanges == true and currentPeriod or (tenancy.conditionLastObservedPeriod or currentPeriod)
    if tenancyHasRecordedGrass(tenancy) == false and tenancy.permanentGrassRestriction == true then
        tenancy.permanentGrassRestriction = false
        for _, prefix in ipairs({"renewalOriginal", "renewalOffer", "renewalTenant"}) do
            tenancy[prefix .. "PermanentGrassRestriction"] = false
        end
        print(string.format("[RealisticFarmFinance] Removed inapplicable permanent-grass covenant agreement=%s; commencement survey contains no grass parcel",
            tostring(tenancy.agreementId or tenancy.id)))
        changed = true
    end
    return changed
end

function RFF_PropertyFinanceService:onLoaded()
    if self.repository == nil then return end
    for _, tenancy in ipairs(self.repository.tenancies or {}) do
        if TENANCY_POSSESSION_STATES[tenancy.status or ""] then
            self:ensureTenancyConditionSurvey(tenancy, false)
            self:ensureTenancyInspectionState(tenancy)
            self:ensureTenancyBreachCaseState(tenancy)
            self:ensureTenancyHandbackState(tenancy)
        elseif tenancy.status == "TERMINATED_COVENANT" then
            if tenancy.forfeitureProcessed ~= true then self:forfeitTenantPlaceables(tenancy) end
            self:reconcileForfeitedPlaceableConveyance(tenancy)
        elseif tenancy.status == "ENDED" or tenancy.status == "TERMINATED_DEFAULT" then
            if tenancy.forfeitureProcessed ~= true then self:forfeitTenantPlaceables(tenancy, "HAND_BACK") end
            if safeNumber(tenancy.forfeitedPlaceableCount) > 0 then
                self:reconcileForfeitedPlaceableConveyance(tenancy)
            end
        end
    end
    if RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService.synchronizeTenancyFixturePossession ~= nil then
        RFF_TenancyAccessService:synchronizeTenancyFixturePossession()
    end
end

function RFF_PropertyFinanceService:getTenancyConditionSurveySummary(tenancy)
    if tenancy == nil then return "Commencement survey unavailable" end
    self:ensureTenancyConditionSurvey(tenancy, false)
    local parts = {}
    for _, parcel in ipairs(tenancy.parcelConditions or {}) do
        local initialUse = tostring(parcel.initialUse or "UNCLASSIFIED")
        local currentUse = tostring(parcel.currentUse or initialUse)
        local detail = parcel.initialFruitName ~= nil and parcel.initialFruitName ~= "" and displayConditionName(parcel.initialFruitName)
            or (parcel.initialGroundName ~= nil and parcel.initialGroundName ~= "" and displayConditionName(parcel.initialGroundName) or "not field-mapped")
        local summary = string.format("Land %d: %s (%s)", parcel.farmlandId or 0, initialUse:lower(), detail)
        if currentUse ~= initialUse then summary = summary .. string.format("; now %s", currentUse:lower()) end
        if safeNumber(parcel.boundaryExpansionSqm) >= math.max(1, safeNumber(parcel.boundaryExpansionThresholdSqm)) then
            summary = summary .. string.format("; connected footprint +%.2f ha", safeNumber(parcel.boundaryExpansionSqm) / 10000)
        end
        parts[#parts + 1] = summary
    end
    if #parts == 0 then return "Commencement survey unavailable" end
    return "Commencement survey: " .. table.concat(parts, " | ")
end

function RFF_PropertyFinanceService:getTenancyAlterationSummary(tenancy)
    local alterations = tenancy ~= nil and tenancy.alterations or nil
    if type(alterations) ~= "table" or #alterations == 0 then return "Alterations: none recorded since commencement" end
    local latest = alterations[#alterations]
    local labels = {
        PLACEABLE_BUILT="built", PLACEABLE_REMOVED="removed", FENCE_BUILT="fence added",
        FENCE_REMOVED="fence removed", LANDSCAPING="landscaping", LAND_USE_CHANGE="land use changed",
        FIELD_BOUNDARY_EXPANSION="field boundary changed", PLACEABLE_FORFEITED="forfeited to landlord"
    }
    local label = labels[latest.alterationType] or tostring(latest.alterationType or "alteration"):lower()
    local asset = latest.assetName ~= nil and latest.assetName ~= "" and latest.assetName or string.format("Land %d", latest.farmlandId or 0)
    local ownership = latest.assetOwnership == "TENANT" and "tenant asset" or (latest.assetOwnership == "LANDLORD" and "landlord asset" or "recorded asset")
    local countText = #alterations == 1 and "1 recorded" or string.format("%d recorded", #alterations)
    return string.format("Alterations: %s | Latest: %s - %s (%s)", countText, label, asset, ownership)
end

function RFF_PropertyFinanceService:getTenancyInspectionInterval(tenancy)
    local termMonths = math.max(1, math.floor(safeNumber(tenancy ~= nil and tenancy.termMonths or 12)))
    if termMonths <= 12 then return math.max(3, math.floor(termMonths / 2)) end
    return TENANCY_INSPECTION_INTERVAL_MONTHS
end

function RFF_PropertyFinanceService:ensureTenancyInspectionState(tenancy)
    if tenancy == nil then return end
    tenancy.inspectionSchemaVersion = TENANCY_INSPECTION_SCHEMA_VERSION
    tenancy.inspectionReports = tenancy.inspectionReports or {}
    tenancy.inspectionNextId = math.max(1, math.floor(safeNumber(tenancy.inspectionNextId)))
    local maxId = 0
    for _, report in ipairs(tenancy.inspectionReports) do
        report.id = math.max(1, math.floor(safeNumber(report.id)))
        report.breachCount = math.max(0, math.floor(safeNumber(report.breachCount)))
        report.authorisedCount = math.max(0, math.floor(safeNumber(report.authorisedCount)))
        report.advisoryCount = math.max(0, math.floor(safeNumber(report.advisoryCount)))
        report.relationshipChange = safeNumber(report.relationshipChange)
        maxId = math.max(maxId, report.id)
    end
    tenancy.inspectionNextId = math.max(tenancy.inspectionNextId, maxId + 1)
    tenancy.inspectionLatestId = math.max(0, math.floor(safeNumber(tenancy.inspectionLatestId)))
    tenancy.lastInspectionPeriod = math.max(0, math.floor(safeNumber(tenancy.lastInspectionPeriod)))
    tenancy.lastInspectionStatus = tenancy.lastInspectionStatus or "NOT_INSPECTED"
    tenancy.lastInspectionReference = tenancy.lastInspectionReference or ""
    tenancy.lastInspectionSummary = tenancy.lastInspectionSummary or ""

    if safeNumber(tenancy.nextInspectionPeriod) <= 0 and #tenancy.inspectionReports == 0
        and TENANCY_POSSESSION_STATES[tenancy.status or ""] then
        local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
        local interval = self:getTenancyInspectionInterval(tenancy)
        local commencement = math.floor(safeNumber(tenancy.commencementPeriod or tenancy.createdPeriod))
        local contractualEnd = math.floor(safeNumber(tenancy.contractualEndPeriod))
        local scheduled = commencement + interval
        if scheduled <= current then scheduled = current + math.min(3, interval) end
        tenancy.nextInspectionPeriod = contractualEnd > 0 and scheduled >= contractualEnd and 0 or scheduled
    else
        tenancy.nextInspectionPeriod = math.max(0, math.floor(safeNumber(tenancy.nextInspectionPeriod)))
    end
end

function RFF_PropertyFinanceService:getTenancyInspectionConsent(tenancy, requestType, target, observedDay, observedPeriod)
    requestType = tostring(requestType or ""):upper()
    target = tostring(target or "AUTHORITY"):upper()
    observedDay = math.max(0, math.floor(safeNumber(observedDay)))
    observedPeriod = math.max(0, math.floor(safeNumber(observedPeriod)))
    for index = #(tenancy ~= nil and tenancy.consentRequests or {}), 1, -1 do
        local request = tenancy.consentRequests[index]
        local status = tostring(request.status or "")
        local approved = status == "APPROVED" or status == "APPROVED_CONDITIONS"
        local targetMatches = requestType ~= "ENTERPRISE" or tostring(request.target or ""):upper() == target
        local decisionDay = math.max(0, math.floor(safeNumber(request.decisionDay)))
        local priorApproval = observedDay <= 0 or decisionDay <= 0 or decisionDay <= observedDay
        local stillValid = safeNumber(request.expiresPeriod) <= 0 or safeNumber(request.expiresPeriod) >= observedPeriod
        if approved and tostring(request.requestType or ""):upper() == requestType and targetMatches and priorApproval and stillValid then
            return request
        end
    end
    return nil
end

function RFF_PropertyFinanceService:isMaterialTenancyImprovementAlteration(tenancy, alteration)
    if alteration == nil then return false end
    local alterationType = tostring(alteration.alterationType or ""):upper()
    local category = tostring(alteration.category or ""):upper()
    if category:find("FENCE", 1, true) ~= nil or alterationType == "FENCE_BUILT" or alterationType == "FENCE_REMOVED" then return false end
    if category:find("DECOR", 1, true) ~= nil then return false end
    if alterationType == "PLACEABLE_REMOVED" and alteration.assetOwnership == "LANDLORD" then return true end
    if alterationType == "PLACEABLE_BUILT" or alterationType == "PLACEABLE_REMOVED" then
        if category:find("HUSBANDRY", 1, true) ~= nil then return true end
        local threshold = math.max(1000, math.max(0, safeNumber(tenancy ~= nil and tenancy.annualRent)) * 0.05)
        return safeNumber(alteration.value) >= threshold
    end
    if alterationType == "LANDSCAPING" then
        local details = tostring(alteration.details or ""):lower()
        return details:find("raise terrain", 1, true) ~= nil or details:find("lower terrain", 1, true) ~= nil
            or details:find("flatten terrain", 1, true) ~= nil or details:find("create slope", 1, true) ~= nil
    end
    return false
end

local function tenancyAlterationPositionsMatch(first, second)
    local firstX, firstZ = safeNumber(first ~= nil and first.worldX), safeNumber(first ~= nil and first.worldZ)
    local secondX, secondZ = safeNumber(second ~= nil and second.worldX), safeNumber(second ~= nil and second.worldZ)
    if (firstX ~= 0 or firstZ ~= 0) and (secondX ~= 0 or secondZ ~= 0) then
        local dx, dz = firstX - secondX, firstZ - secondZ
        return dx * dx + dz * dz <= 25
    end
    return tostring(first ~= nil and first.assetName or "") == tostring(second ~= nil and second.assetName or "")
end

function RFF_PropertyFinanceService:isTenancyAlterationRemedied(tenancy, alteration)
    if tenancy == nil or alteration == nil then return false end
    if tostring(alteration.status or ""):upper() == "REMEDIED" then return true end
    local alterationType = tostring(alteration.alterationType or ""):upper()
    local farmlandId = math.floor(safeNumber(alteration.farmlandId))
    if alterationType == "FIELD_BOUNDARY_EXPANSION" then
        for _, parcel in ipairs(tenancy.parcelConditions or {}) do
            if math.floor(safeNumber(parcel.farmlandId)) == farmlandId
                and safeNumber(parcel.boundaryExpansionSqm) < math.max(1, safeNumber(parcel.boundaryExpansionThresholdSqm)) then
                alteration.status = "REMEDIED"
                alteration.details = tostring(alteration.details or "") .. "; commencement boundary restored"
                return true
            end
        end
    end

    local tenantPlaceable = alteration.assetOwnership == "TENANT"
        and (alterationType == "PLACEABLE_BUILT" or alterationType == "PLACEABLE_REMOVED")
    if tenantPlaceable then
        local wantsType = alterationType == "PLACEABLE_BUILT" and "PLACEABLE_REMOVED" or "PLACEABLE_BUILT"
        for _, counterpart in ipairs(tenancy.alterations or {}) do
            local counterpartType = tostring(counterpart.alterationType or ""):upper()
            local correctOrder = alterationType == "PLACEABLE_BUILT"
                and safeNumber(counterpart.id) > safeNumber(alteration.id)
                or alterationType == "PLACEABLE_REMOVED" and safeNumber(counterpart.id) < safeNumber(alteration.id)
            if counterpartType == wantsType and counterpart.assetOwnership == "TENANT" and correctOrder
                and math.floor(safeNumber(counterpart.farmlandId)) == farmlandId
                and tenancyAlterationPositionsMatch(alteration, counterpart) then
                alteration.status = "REMEDIED"
                counterpart.status = "REMEDIED"
                return true
            end
        end
    end
    return false
end

function RFF_PropertyFinanceService:ensureTenancyBreachCaseState(tenancy)
    if tenancy == nil then return end
    tenancy.breachCaseSchemaVersion = TENANCY_BREACH_CASE_SCHEMA_VERSION
    tenancy.breachCases = tenancy.breachCases or {}
    tenancy.breachCaseNextId = math.max(1, math.floor(safeNumber(tenancy.breachCaseNextId)))
    local maxId = 0
    for _, case in ipairs(tenancy.breachCases) do
        case.id = math.max(1, math.floor(safeNumber(case.id)))
        case.openedPeriod = math.max(0, math.floor(safeNumber(case.openedPeriod)))
        case.remedyDeadlinePeriod = math.max(0, math.floor(safeNumber(case.remedyDeadlinePeriod)))
        case.nextReviewPeriod = math.max(0, math.floor(safeNumber(case.nextReviewPeriod)))
        case.closedPeriod = math.max(0, math.floor(safeNumber(case.closedPeriod)))
        case.breachCount = math.max(0, math.floor(safeNumber(case.breachCount)))
        case.unresolvedCount = math.max(0, math.floor(safeNumber(case.unresolvedCount)))
        case.reviewCount = math.max(0, math.floor(safeNumber(case.reviewCount)))
        case.professionalFee = math.max(0, safeNumber(case.professionalFee))
        case.feePaid = math.max(0, safeNumber(case.feePaid))
        case.feeOutstanding = math.max(0, safeNumber(case.feeOutstanding))
        case.remedyMonths = math.max(0, math.floor(safeNumber(case.remedyMonths)))
        case.reviewMonths = math.max(0, math.floor(safeNumber(case.reviewMonths)))
        case.terminationNoticeMonths = math.max(0, math.floor(safeNumber(case.terminationNoticeMonths)))
        case.terminationEffectivePeriod = math.max(0, math.floor(safeNumber(case.terminationEffectivePeriod)))
        case.preNoticeContractualEndPeriod = math.max(0, math.floor(safeNumber(case.preNoticeContractualEndPeriod)))
        case.lastChargeAmount = math.max(0, safeNumber(case.lastChargeAmount))
        case.lastChargePeriod = math.max(0, math.floor(safeNumber(case.lastChargePeriod)))
        maxId = math.max(maxId, case.id)
    end
    tenancy.breachCaseNextId = math.max(tenancy.breachCaseNextId, maxId + 1)
    tenancy.breachCaseLatestId = math.max(0, math.floor(safeNumber(tenancy.breachCaseLatestId)))
end

function RFF_PropertyFinanceService:getLatestTenancyBreachCase(tenancy)
    self:ensureTenancyBreachCaseState(tenancy)
    local cases = tenancy ~= nil and tenancy.breachCases or {}
    return cases[#cases]
end

function RFF_PropertyFinanceService:getOpenTenancyBreachCase(tenancy)
    self:ensureTenancyBreachCaseState(tenancy)
    for index = #(tenancy ~= nil and tenancy.breachCases or {}), 1, -1 do
        local case = tenancy.breachCases[index]
        if TENANCY_BREACH_CASE_OPEN[tostring(case.status or ""):upper()] then return case end
    end
    return nil
end

function RFF_PropertyFinanceService:getTenancyBreachCostsOutstanding(tenancy)
    local total = 0
    self:ensureTenancyBreachCaseState(tenancy)
    for _, case in ipairs(tenancy ~= nil and tenancy.breachCases or {}) do
        total = total + math.max(0, safeNumber(case.feeOutstanding))
    end
    return total
end

function RFF_PropertyFinanceService:getTenancyBreachEnforcementTerms(tenancy, breachCount)
    local profile = self:getLandlordProfile(tenancy ~= nil and tenancy.landlord or nil,
        tenancy ~= nil and tenancy.farmlandId or 0)
    local policy = TENANCY_BREACH_ENFORCEMENT[profile.id] or TENANCY_BREACH_ENFORCEMENT.PRIVATE_LANDOWNER
    local relationship = self:getTenancyLandlordRelationship(tenancy)
    local relationshipEffect = TENANCY_BREACH_RELATIONSHIP_EFFECT[relationship.code]
        or TENANCY_BREACH_RELATIONSHIP_EFFECT.PROFESSIONAL
    local remedyMonths = math.max(1, math.min(6,
        math.floor(safeNumber(policy.remedyMonths) + safeNumber(relationshipEffect.remedyMonths))))
    local reviewMonths = math.max(1, math.min(3, math.floor(safeNumber(policy.reviewMonths))))
    local terminationMonths = math.max(1, math.min(2, math.floor(safeNumber(policy.terminationMonths))))
    local severity = 1 + math.min(0.75, math.max(0, math.floor(safeNumber(breachCount)) - 1) * 0.15)
    local annualRent = math.max(0, safeNumber(tenancy ~= nil and tenancy.annualRent))
    local feeFactor = math.max(0.6, safeNumber(relationshipEffect.feeFactor))
    local firstFee = math.max(1500, math.min(25000,
        annualRent * safeNumber(policy.firstFeeRate) * severity * feeFactor))
    local terminationFee = math.max(5000, math.min(50000,
        annualRent * safeNumber(policy.terminationFeeRate) * severity * feeFactor))
    firstFee = math.floor((firstFee + 25) / 50) * 50
    terminationFee = math.floor((terminationFee + 25) / 50) * 50
    return {
        profile=profile, relationship=relationship, remedyMonths=remedyMonths,
        reviewMonths=reviewMonths, terminationMonths=terminationMonths,
        firstLegalFee=firstFee, terminationLegalFee=terminationFee
    }
end

function RFF_PropertyFinanceService:addTenancyBreachCaseCharge(case, amount, currentPeriod)
    if case == nil then return 0 end
    amount = math.max(0, safeNumber(amount))
    if amount <= 0.001 then return 0 end
    case.professionalFee = math.max(0, safeNumber(case.professionalFee)) + amount
    case.feeOutstanding = math.max(0, safeNumber(case.feeOutstanding)) + amount
    case.lastChargeAmount = amount
    case.lastChargePeriod = math.max(0, math.floor(safeNumber(currentPeriod)))
    case.feeSettlementNotified = false
    return amount
end

function RFF_PropertyFinanceService:restoreTenancyBeforeBreachNotice(tenancy, case, currentPeriod)
    if tenancy == nil or case == nil or safeNumber(case.preNoticeContractualEndPeriod) <= 0 then return end
    tenancy.contractualEndPeriod = case.preNoticeContractualEndPeriod
    tenancy.noticeServedPeriod = math.max(0, math.floor(safeNumber(case.preNoticeServedPeriod)))
    tenancy.noticeEffectivePeriod = math.max(0, math.floor(safeNumber(case.preNoticeEffectivePeriod)))
    tenancy.noticeReason = tostring(case.preNoticeReason or "")
    tenancy.remainingMonths = math.max(0, tenancy.contractualEndPeriod - math.floor(safeNumber(currentPeriod)))
    local previousStatus = tostring(case.preNoticeStatus or "")
    tenancy.status = TENANCY_POSSESSION_STATES[previousStatus] and previousStatus
        or (tenancy.remainingMonths <= 12 and "EXPIRING" or "ACTIVE")
    case.preNoticeContractualEndPeriod = 0
end

function RFF_PropertyFinanceService:trySettleTenancyBreachCaseFee(tenancy, case)
    if tenancy == nil or case == nil then return false end
    case.feeOutstanding = math.max(0, safeNumber(case.feeOutstanding))
    if case.feeOutstanding <= 0.001 then return true end
    local available = self.repository ~= nil and self.repository.getAvailableFunds ~= nil
        and self.repository:getAvailableFunds(tenancy.farmId) or farmMoney(tenancy.farmId)
    if available + 0.001 < case.feeOutstanding or g_currentMission == nil then return false end
    local amount = case.feeOutstanding
    if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(tenancy.farmId,
            "Tenancy covenant enforcement costs - " .. (tenancy.holdingName or tenancy.agreementId or "Agricultural holding"))
    end
    g_currentMission:addMoney(-amount, tenancy.farmId, moneyTypeFallback(), true, true)
    local manager = RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
    if manager ~= nil and manager.businessAdministration ~= nil
        and manager.businessAdministration.recordRedTapeDeductibleExpense ~= nil then
        manager.businessAdministration:recordRedTapeDeductibleExpense(tenancy.farmId, amount)
    end
    case.feePaid = math.max(0, safeNumber(case.feePaid)) + amount
    case.feeOutstanding = 0
    if case.feeSettlementNotified ~= true then
        case.feeSettlementNotified = true
        local caseStatus = tostring(case.status or ""):upper()
        local inspectionAction
        if caseStatus == "FINAL_WARNING" then
            inspectionAction = string.format("This records payment only: the covenant default remains unresolved and the final-warning review is still due in %s.",
                formatTenancyPeriod(case.nextReviewPeriod))
        elseif caseStatus == "TERMINATION_NOTICE" then
            inspectionAction = string.format("This records payment only: the termination notice remains in force and the tenancy will still end in %s unless every breach is remedied before the final inspection.",
                formatTenancyPeriod(case.terminationEffectivePeriod or case.nextReviewPeriod))
        elseif caseStatus == "TERMINATED" then
            inspectionAction = "This records payment only; the tenancy remains terminated."
        elseif caseStatus == "REMEDIED" then
            inspectionAction = "The covenant breach has been remedied separately; this receipt settles only the enforcement costs already incurred."
        else
            inspectionAction = "This records payment only and does not waive or remedy any outstanding covenant breach."
        end
        local event = self:createTenancyNarrative(tenancy, "COVENANT_COSTS_SETTLED", {
            token=string.format("breachCase:%d:%d:COSTS_SETTLED:%d", safeNumber(tenancy.id), safeNumber(case.id),
                math.max(0, math.floor(safeNumber(case.reviewCount)))),
            reference=case.reference, documentStatus="COSTS_SETTLED", outcome="PAID",
            legalCharge=amount, inspectionAction=inspectionAction
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_variation_costs", "Tenancy Professional Costs", false)
    end
    return true
end

function RFF_PropertyFinanceService:updateTenancyBreachCaseFromInspection(tenancy, report)
    self:ensureTenancyBreachCaseState(tenancy)
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local openCase = self:getOpenTenancyBreachCase(tenancy)
    local hasBreach = report ~= nil and safeNumber(report.breachCount) > 0
    local formalReview = report ~= nil and (report.trigger == "REMEDY_REVIEW" or report.trigger == "ROUTINE")
    if hasBreach and openCase == nil then
        local id = tenancy.breachCaseNextId
        tenancy.breachCaseNextId = id + 1
        tenancy.breachCaseLatestId = id
        local enforcement = self:getTenancyBreachEnforcementTerms(tenancy, report.breachCount)
        local contractualEnd = math.max(current + 1, math.floor(safeNumber(tenancy.contractualEndPeriod)))
        local deadline = math.min(contractualEnd, current + enforcement.remedyMonths)
        openCase = {
            id=id, reference=string.format("RFF-B-%06d-%02d", math.floor(safeNumber(tenancy.id)), id),
            status="REMEDY_NOTICE", openedPeriod=current, remedyDeadlinePeriod=deadline,
            nextReviewPeriod=deadline, closedPeriod=0, sourceInspectionReference=report.reference or "",
            latestInspectionReference=report.reference or "", breachCount=report.breachCount or 0,
            unresolvedCount=report.breachCount or 0, reviewCount=0, professionalFee=0,
            feePaid=0, feeOutstanding=0, feeSettlementNotified=false, summary=report.summary or "",
            remedyMonths=enforcement.remedyMonths, reviewMonths=enforcement.reviewMonths,
            terminationNoticeMonths=enforcement.terminationMonths,
            firstLegalFee=enforcement.firstLegalFee, terminationLegalFee=enforcement.terminationLegalFee,
            landlordApproach=self:getLandlordApproach(enforcement.profile.id, tenancy.farmlandId),
            relationshipCodeAtOpen=enforcement.relationship.code,
            relationshipPointsAtOpen=enforcement.relationship.points,
            terminationEffectivePeriod=0, preNoticeContractualEndPeriod=0,
            preNoticeServedPeriod=0, preNoticeEffectivePeriod=0, preNoticeReason="", preNoticeStatus="",
            lastChargeAmount=0, lastChargePeriod=0
        }
        table.insert(tenancy.breachCases, openCase)
        tenancy.covenantComplianceStatus = "REMEDY_NOTICE"
        print(string.format("[RealisticFarmFinance] Covenant remedy case opened agreement=%s case=%s approach=%s relationship=%s remedyMonths=%d deadline=%d breaches=%d",
            tostring(tenancy.agreementId or tenancy.id), openCase.reference, tostring(openCase.landlordApproach),
            tostring(openCase.relationshipCodeAtOpen), openCase.remedyMonths, openCase.remedyDeadlinePeriod,
            openCase.unresolvedCount))
        return openCase, "OPENED"
    end
    if openCase == nil or not formalReview then return openCase, nil end

    openCase.latestInspectionReference = report.reference or ""
    openCase.summary = report.summary or openCase.summary or ""
    openCase.reviewCount = math.max(0, math.floor(safeNumber(openCase.reviewCount))) + 1
    if not hasBreach then
        self:restoreTenancyBeforeBreachNotice(tenancy, openCase, current)
        openCase.status = "REMEDIED"
        openCase.unresolvedCount = 0
        openCase.closedPeriod = current
        openCase.nextReviewPeriod = 0
        tenancy.covenantComplianceStatus = "COMPLIANT"
        self:adjustTenancyLandlordRelationship(tenancy, openCase.reviewCount <= 1 and 0.5 or 0.25,
            "COVENANT_BREACH_REMEDIED")
        print(string.format("[RealisticFarmFinance] Covenant remedy confirmed agreement=%s case=%s review=%d costsPaid=%.2f costsOutstanding=%.2f",
            tostring(tenancy.agreementId or tenancy.id), tostring(openCase.reference), openCase.reviewCount,
            safeNumber(openCase.feePaid), safeNumber(openCase.feeOutstanding)))
        return openCase, "REMEDIED"
    end

    openCase.breachCount = math.max(safeNumber(openCase.breachCount), safeNumber(report.breachCount))
    openCase.unresolvedCount = math.max(0, math.floor(safeNumber(report.breachCount)))
    local enforcement = self:getTenancyBreachEnforcementTerms(tenancy, openCase.unresolvedCount)
    openCase.reviewMonths = math.max(1, safeNumber(openCase.reviewMonths) > 0 and openCase.reviewMonths or enforcement.reviewMonths)
    openCase.terminationNoticeMonths = math.max(1, safeNumber(openCase.terminationNoticeMonths) > 0
        and openCase.terminationNoticeMonths or enforcement.terminationMonths)
    openCase.firstLegalFee = math.max(0, safeNumber(openCase.firstLegalFee) > 0 and openCase.firstLegalFee or enforcement.firstLegalFee)
    openCase.terminationLegalFee = math.max(0, safeNumber(openCase.terminationLegalFee) > 0
        and openCase.terminationLegalFee or enforcement.terminationLegalFee)

    if openCase.reviewCount == 1 then
        openCase.status = "FINAL_WARNING"
        local contractualEnd = math.max(current + 1, math.floor(safeNumber(tenancy.contractualEndPeriod)))
        openCase.nextReviewPeriod = math.min(contractualEnd, current + openCase.reviewMonths)
        self:addTenancyBreachCaseCharge(openCase, openCase.firstLegalFee, current)
        tenancy.covenantComplianceStatus = "FINAL_WARNING"
        self:adjustTenancyLandlordRelationship(tenancy, -1.5, "COVENANT_BREACH_FINAL_WARNING")
        print(string.format("[RealisticFarmFinance] Covenant final warning agreement=%s case=%s review=%d charge=%.2f nextReview=%d unresolved=%d",
            tostring(tenancy.agreementId or tenancy.id), tostring(openCase.reference), openCase.reviewCount,
            safeNumber(openCase.lastChargeAmount), openCase.nextReviewPeriod, openCase.unresolvedCount))
        return openCase, "FINAL_WARNING"
    end

    if openCase.reviewCount == 2 then
        openCase.status = "TERMINATION_NOTICE"
        self:addTenancyBreachCaseCharge(openCase, openCase.terminationLegalFee, current)
        openCase.preNoticeContractualEndPeriod = math.max(current,
            math.floor(safeNumber(tenancy.contractualEndPeriod)))
        openCase.preNoticeServedPeriod = math.max(0, math.floor(safeNumber(tenancy.noticeServedPeriod)))
        openCase.preNoticeEffectivePeriod = math.max(0, math.floor(safeNumber(tenancy.noticeEffectivePeriod)))
        openCase.preNoticeReason = tostring(tenancy.noticeReason or "")
        openCase.preNoticeStatus = tostring(tenancy.status or "ACTIVE")
        local effective = math.min(openCase.preNoticeContractualEndPeriod,
            current + openCase.terminationNoticeMonths)
        openCase.terminationEffectivePeriod = effective
        openCase.nextReviewPeriod = effective
        tenancy.noticeServedPeriod = current
        tenancy.noticeEffectivePeriod = effective
        tenancy.noticeReason = "COVENANT_DEFAULT"
        tenancy.contractualEndPeriod = effective
        tenancy.remainingMonths = math.max(0, effective - current)
        tenancy.status = "NOTICE_SERVED"
        tenancy.covenantComplianceStatus = "TERMINATION_NOTICE"
        self:adjustTenancyLandlordRelationship(tenancy, -2.5, "COVENANT_TERMINATION_NOTICE")
        print(string.format("[RealisticFarmFinance] Covenant termination notice agreement=%s case=%s charge=%.2f effectivePeriod=%d unresolved=%d",
            tostring(tenancy.agreementId or tenancy.id), tostring(openCase.reference),
            safeNumber(openCase.lastChargeAmount), openCase.terminationEffectivePeriod, openCase.unresolvedCount))
        if effective > current then return openCase, "TERMINATION_NOTICE" end
    end

    openCase.status = "TERMINATED"
    openCase.closedPeriod = current
    openCase.nextReviewPeriod = 0
    tenancy.covenantComplianceStatus = "TERMINATED"
    self:adjustTenancyLandlordRelationship(tenancy, -4, "COVENANT_TENANCY_TERMINATED")
    self:releaseTenancy(tenancy, true, "TERMINATED_COVENANT")
    print(string.format("[RealisticFarmFinance] Tenancy terminated for covenant default agreement=%s case=%s depositApplied=%.2f depositReturned=%.2f finalBalance=%.2f fixturesForfeited=%d formerFixtureSellValue=%.2f",
        tostring(tenancy.agreementId or tenancy.id), tostring(openCase.reference),
        safeNumber(tenancy.settlementDepositApplied), safeNumber(tenancy.settlementDepositReturned),
        safeNumber(tenancy.settlementFinalBalance), math.floor(safeNumber(tenancy.forfeitedPlaceableCount)),
        safeNumber(tenancy.forfeitedPlaceableValue)))
    return openCase, "TERMINATED"
end

function RFF_PropertyFinanceService:processTenancyBreachCases(tenancy, currentPeriod)
    if tenancy == nil then return false end
    self:ensureTenancyBreachCaseState(tenancy)
    local changed = false
    for _, case in ipairs(tenancy.breachCases or {}) do
        if safeNumber(case.feeOutstanding) > 0.001 and self:trySettleTenancyBreachCaseFee(tenancy, case) then changed = true end
    end
    local openCase = self:getOpenTenancyBreachCase(tenancy)
    if openCase ~= nil and safeNumber(openCase.nextReviewPeriod) > 0
        and safeNumber(currentPeriod) >= safeNumber(openCase.nextReviewPeriod) then
        self:performTenancyInspection(tenancy, "REMEDY_REVIEW")
        changed = true
    end
    return changed
end

function RFF_PropertyFinanceService:getLatestTenancyInspectionReport(tenancy)
    self:ensureTenancyInspectionState(tenancy)
    local reports = tenancy ~= nil and tenancy.inspectionReports or {}
    return reports[#reports]
end

function RFF_PropertyFinanceService:getTenancyInspectionSummary(tenancy)
    if tenancy == nil then return "Inspection record unavailable" end
    self:ensureTenancyInspectionState(tenancy)
    self:ensureTenancyBreachCaseState(tenancy)
    local report = self:getLatestTenancyInspectionReport(tenancy)
    local nextText = safeNumber(tenancy.nextInspectionPeriod) > 0 and formatTenancyPeriod(tenancy.nextInspectionPeriod) or "no further routine inspection scheduled"
    if report == nil then return string.format("Inspections: none completed | Next: %s", nextText) end
    local status = report.status == "BREACH" and "BREACHES RECORDED" or "CLEAR"
    local latestCase = self:getLatestTenancyBreachCase(tenancy)
    if latestCase ~= nil and TENANCY_BREACH_CASE_OPEN[tostring(latestCase.status or ""):upper()] then
        local caseStatuses = {REMEDY_NOTICE="REMEDY NOTICE", FINAL_WARNING="FINAL WARNING",
            TERMINATION_NOTICE="TERMINATION NOTICE"}
        local caseStatus = caseStatuses[latestCase.status] or tostring(latestCase.status or "CASE"):gsub("_", " ")
        local costs = safeNumber(latestCase.feeOutstanding) > 0.001
            and string.format(" | %s due", g_i18n:formatMoney(latestCase.feeOutstanding, 0, true, true)) or ""
        return string.format("Inspection %s | %s | %d breach(es)\nCase %s | %s | Review: %s%s",
            report.reference or "-", status, report.breachCount or 0,
            latestCase.reference or "-", caseStatus,
            formatTenancyPeriod(latestCase.nextReviewPeriod or latestCase.remedyDeadlinePeriod or 0), costs)
    elseif latestCase ~= nil and latestCase.status == "REMEDIED" then
        return string.format("Inspection %s | %s | %d breach(es), %d authorised\nCase %s | REMEDIED | Routine: %s",
            report.reference or "-", status, report.breachCount or 0, report.authorisedCount or 0,
            latestCase.reference or "-", nextText)
    elseif latestCase ~= nil and latestCase.status == "TERMINATED" then
        return string.format("Inspection %s | %s | %d breach(es)\nCase %s | TENANCY TERMINATED | Balance %s",
            report.reference or "-", status, report.breachCount or 0, latestCase.reference or "-",
            g_i18n:formatMoney(tenancy.settlementFinalBalance or 0, 0, true, true))
    end
    return string.format("Inspection %s | %s | %d breach(es), %d authorised\nNext routine review: %s | Full findings: correspondence",
        report.reference or "-", status, report.breachCount or 0, report.authorisedCount or 0, nextText)
end

function RFF_PropertyFinanceService:ensureTenancyHandbackState(tenancy)
    if tenancy == nil then return end
    tenancy.handbackSchemaVersion = TENANCY_HANDBACK_SCHEMA_VERSION
    tenancy.handbackStatus = tostring(tenancy.handbackStatus or "NONE")
    tenancy.handbackReference = tostring(tenancy.handbackReference or "")
    tenancy.handbackInspectionPeriod = math.max(0, math.floor(safeNumber(tenancy.handbackInspectionPeriod)))
    tenancy.handbackRemedyDeadlinePeriod = math.max(0, math.floor(safeNumber(tenancy.handbackRemedyDeadlinePeriod)))
    tenancy.handbackFinalInspectionPeriod = math.max(0, math.floor(safeNumber(tenancy.handbackFinalInspectionPeriod)))
    tenancy.handbackReviewCount = math.max(0, math.floor(safeNumber(tenancy.handbackReviewCount)))
    tenancy.handbackItemCount = math.max(0, math.floor(safeNumber(tenancy.handbackItemCount)))
    tenancy.handbackUnresolvedCount = math.max(0, math.floor(safeNumber(tenancy.handbackUnresolvedCount)))
    tenancy.handbackEstimatedCost = math.max(0, safeNumber(tenancy.handbackEstimatedCost))
    tenancy.handbackProfessionalFee = math.max(0, safeNumber(tenancy.handbackProfessionalFee))
    tenancy.handbackFinalCost = math.max(0, safeNumber(tenancy.handbackFinalCost))
    tenancy.handbackLatestSummary = tostring(tenancy.handbackLatestSummary or "")
    tenancy.handbackItems = tenancy.handbackItems or {}
    for index, item in ipairs(tenancy.handbackItems) do
        item.id = math.max(1, math.floor(safeNumber(item.id or index)))
        item.farmlandId = math.max(0, math.floor(safeNumber(item.farmlandId)))
        item.alterationId = math.max(0, math.floor(safeNumber(item.alterationId)))
        item.estimatedCost = math.max(0, safeNumber(item.estimatedCost))
        item.status = tostring(item.status or "OUTSTANDING")
    end
end

function RFF_PropertyFinanceService:getTenancyHandbackProfessionalFee(tenancy, itemCount)
    itemCount = math.max(0, math.floor(safeNumber(itemCount)))
    if itemCount <= 0 then return 0 end
    local profile = self:getLandlordProfile(tenancy ~= nil and tenancy.landlord or nil,
        tenancy ~= nil and tenancy.farmlandId or 0)
    local profileRates = {
        PRIVATE_LANDOWNER=0.040, FAMILY_LANDHOLDING=0.030, REGIONAL_LAND_PARTNERSHIP=0.050,
        AGRICULTURAL_LAND_TRUST=0.060, LAND_MANAGEMENT_COMPANY=0.080
    }
    local relationship = self:getTenancyLandlordRelationship(tenancy)
    local relationshipEffect = TENANCY_BREACH_RELATIONSHIP_EFFECT[relationship.code]
        or TENANCY_BREACH_RELATIONSHIP_EFFECT.PROFESSIONAL
    local annualRent = math.max(0, safeNumber(tenancy ~= nil and tenancy.annualRent))
    local amount = annualRent * safeNumber(profileRates[profile.id] or 0.04)
        * math.max(0.65, safeNumber(relationshipEffect.feeFactor)) + itemCount * 100
    amount = math.max(500, math.min(7500, amount))
    return math.floor((amount + 25) / 50) * 50
end

function RFF_PropertyFinanceService:buildTenancyHandbackItems(tenancy)
    local items = {}
    if tenancy == nil then return items end
    self:ensureTenancyConditionSurvey(tenancy, true)
    self:ensureTenancyConsentState(tenancy)
    local currentPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local tenantFarmId = math.floor(safeNumber(tenancy.farmId))
    local retainedReplacementPlaceables = {}
    local nextId = 1
    local function addItem(code, farmlandId, description, remedy, cost, consentReference, alterationId, assetName)
        items[#items + 1] = {
            id=nextId, code=code, status="OUTSTANDING", farmlandId=math.floor(safeNumber(farmlandId)),
            description=tostring(description or "Handback matter"), remedy=tostring(remedy or "Reinstate before handback"),
            estimatedCost=math.max(0, safeNumber(cost)), consentReference=tostring(consentReference or ""),
            alterationId=math.max(0, math.floor(safeNumber(alterationId))), assetName=tostring(assetName or "")
        }
        nextId = nextId + 1
    end
    local function latestAlteration(alterationType, farmlandId)
        for index = #(tenancy.alterations or {}), 1, -1 do
            local alteration = tenancy.alterations[index]
            if tostring(alteration.alterationType or ""):upper() == alterationType
                and math.floor(safeNumber(alteration.farmlandId)) == math.floor(safeNumber(farmlandId)) then
                return alteration
            end
        end
        return nil
    end
    local function findTenantReplacement(alteration)
        if alteration == nil or g_currentMission == nil or g_currentMission.placeableSystem == nil then return nil end
        local recordedX, recordedZ = safeNumber(alteration.worldX), safeNumber(alteration.worldZ)
        if recordedX == 0 and recordedZ == 0 then return nil end
        local best, bestDistanceSq = nil, nil
        for _, placeable in pairs(g_currentMission.placeableSystem.placeables or {}) do
            if placeable ~= nil and placeable.isDeleted ~= true
                and self:getPlaceableOwnerFarmId(placeable) == tenantFarmId
                and self:getPlaceableFarmlandId(placeable) == math.floor(safeNumber(alteration.farmlandId)) then
                local node = placeable.rootNode or placeable.nodeId
                if node ~= nil and node ~= 0 then
                    local okPosition, x, _, z = pcall(getWorldTranslation, node)
                    if okPosition then
                        local dx, dz = safeNumber(x) - recordedX, safeNumber(z) - recordedZ
                        local distanceSq = dx * dx + dz * dz
                        if distanceSq <= 25 and (bestDistanceSq == nil or distanceSq < bestDistanceSq) then
                            best, bestDistanceSq = placeable, distanceSq
                        end
                    end
                end
            end
        end
        return best
    end

    for _, parcel in ipairs(tenancy.parcelConditions or {}) do
        local farmlandId = math.floor(safeNumber(parcel.farmlandId))
        local initialUse = tostring(parcel.initialUse or "UNCLASSIFIED"):upper()
        local currentUse = tostring(parcel.currentUse or initialUse):upper()
        if initialUse == "GRASS" and currentUse == "ARABLE" then
            local alteration = latestAlteration("LAND_USE_CHANGE", farmlandId)
            local consent = self:getTenancyInspectionConsent(tenancy, "GRASS_CULTIVATION", "AUTHORITY",
                alteration ~= nil and alteration.day or 0, alteration ~= nil and alteration.period or currentPeriod)
            if consent == nil then
                local hectares = math.max(0.25, safeNumber(parcel.initialFieldAreaSqm) / 10000)
                local cost = math.max(750, math.min(15000, hectares * 900))
                addItem("RESTORE_GRASS", farmlandId,
                    string.format("Land %d remains arable although the commencement survey recorded grass", farmlandId),
                    "Re-establish grass before possession ends", cost, "", alteration ~= nil and alteration.id or 0)
            end
        end
        if safeNumber(parcel.boundaryExpansionSqm) >= math.max(1, safeNumber(parcel.boundaryExpansionThresholdSqm)) then
            local alteration = latestAlteration("FIELD_BOUNDARY_EXPANSION", farmlandId)
            local consent = self:getTenancyInspectionConsent(tenancy, "BOUNDARY_WORKS", "AUTHORITY",
                alteration ~= nil and alteration.day or 0, alteration ~= nil and alteration.period or currentPeriod)
            if consent == nil then
                local expansionHa = math.max(0, safeNumber(parcel.boundaryExpansionSqm) / 10000)
                local cost = math.max(1500, math.min(20000, 1000 + expansionHa * 3500))
                addItem("RESTORE_BOUNDARY", farmlandId,
                    string.format("Land %d remains merged beyond its recorded commencement boundary", farmlandId),
                    "Restore the separate field footprint before possession ends", cost, "",
                    alteration ~= nil and alteration.id or 0)
            end
        end
    end

    for _, alteration in ipairs(tenancy.alterations or {}) do
        local alterationType = tostring(alteration.alterationType or ""):upper()
        if alterationType == "PLACEABLE_REMOVED" and alteration.assetOwnership == "LANDLORD"
            and not self:isTenancyAlterationRemedied(tenancy, alteration) then
            local consent = self:getTenancyInspectionConsent(tenancy, "CAPITAL_IMPROVEMENT", "AUTHORITY",
                alteration.day, alteration.period)
            if consent == nil then
                local replacement = findTenantReplacement(alteration)
                if replacement ~= nil then
                    retainedReplacementPlaceables[replacement] = true
                else
                    local cost = math.max(1000, math.min(50000, safeNumber(alteration.value) * 1.25 + 750))
                    addItem("REPLACE_LANDLORD_FIXTURE", alteration.farmlandId,
                        string.format("Landlord fixture removed from Land %d (%s)", alteration.farmlandId or 0,
                            alteration.assetName ~= nil and alteration.assetName ~= "" and alteration.assetName or "recorded fixture"),
                        "Replace the landlord fixture or leave the assessed reinstatement cost", cost, "",
                        alteration.id, alteration.assetName)
                end
            end
        end
    end

    local farmlandSet = {}
    for _, value in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
        local farmlandId = math.floor(safeNumber(value))
        if farmlandId > 0 then farmlandSet[farmlandId] = true end
    end
    if g_currentMission ~= nil and g_currentMission.placeableSystem ~= nil then
        for _, placeable in pairs(g_currentMission.placeableSystem.placeables or {}) do
            if placeable ~= nil and placeable.isDeleted ~= true
                and self:getPlaceableOwnerFarmId(placeable) == tenantFarmId
                and retainedReplacementPlaceables[placeable] ~= true then
                local farmlandId = self:getPlaceableFarmlandId(placeable)
                local category = self:getPlaceableCategory(placeable):upper()
                local sellValue = self:getPlaceableSellValue(placeable)
                local materialThreshold = math.max(500, math.max(0, safeNumber(tenancy.annualRent)) * 0.01)
                local material = category:find("HUSBANDRY", 1, true) ~= nil
                    or (category:find("FENCE", 1, true) == nil and category:find("DECOR", 1, true) == nil
                        and sellValue >= materialThreshold)
                if farmlandSet[farmlandId] and material then
                    local removalRate = category:find("HUSBANDRY", 1, true) ~= nil and 0.25 or 0.15
                    local minimum = category:find("HUSBANDRY", 1, true) ~= nil and 1000 or 500
                    local cost = math.max(minimum, math.min(30000, sellValue * removalRate + 250))
                    local name = self:getPlaceableDisplayName(placeable)
                    addItem("REMOVE_TENANT_FIXTURE", farmlandId,
                        string.format("Tenant fixture remains on Land %d (%s)", farmlandId, name),
                        "Sell or remove the tenant fixture before possession ends", cost, "", 0, name)
                end
            end
        end
    end
    return items
end

function RFF_PropertyFinanceService:getTenancyHandbackSummary(tenancy)
    if tenancy == nil then return "" end
    self:ensureTenancyHandbackState(tenancy)
    if tenancy.handbackStatus == "NONE" or tenancy.handbackStatus == "CANCELLED" then return "" end
    local labels = {
        REMEDY_REQUIRED="REMEDY REQUIRED", OUTSTANDING="WORK OUTSTANDING", CLEAR="CLEAR",
        REMEDIED="REMEDIED", FINAL_CLEAR="FINAL CLEAR", FINAL_CHARGES="FINAL CHARGES"
    }
    local label = labels[tenancy.handbackStatus] or tenancy.handbackStatus:gsub("_", " ")
    local amount = tenancy.handbackStatus == "FINAL_CHARGES" and tenancy.handbackFinalCost
        or tenancy.handbackEstimatedCost
    local lineOne = string.format("Handback %s | %s | %d item(s) | %s",
        tenancy.handbackReference ~= "" and tenancy.handbackReference or "pending", label,
        tenancy.handbackUnresolvedCount or 0, g_i18n:formatMoney(amount or 0, 0, true, true))
    local lineTwo
    if tenancy.handbackStatus == "REMEDY_REQUIRED" or tenancy.handbackStatus == "OUTSTANDING" then
        lineTwo = string.format("Remedy by %s | Final possession: %s",
            formatTenancyPeriod(tenancy.handbackRemedyDeadlinePeriod),
            formatTenancyPeriod(tenancy.handbackFinalInspectionPeriod or tenancy.contractualEndPeriod))
    else
        lineTwo = string.format("Final possession check: %s | Full schedule: correspondence",
            formatTenancyPeriod(tenancy.handbackFinalInspectionPeriod or tenancy.contractualEndPeriod))
    end
    return lineOne .. "\n" .. lineTwo
end

function RFF_PropertyFinanceService:performTenancyHandbackInspection(tenancy, trigger)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return nil, "server_only" end
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then return nil, "inactive" end
    self:ensureTenancyHandbackState(tenancy)
    trigger = tostring(trigger or "PRE_EXPIRY"):upper()
    local finalAssessment = trigger == "FINAL"
    local current = self.repository:getCurrentPeriodIndex()
    local previousStatus = tenancy.handbackStatus
    local items = self:buildTenancyHandbackItems(tenancy)
    local itemCost = 0
    for _, item in ipairs(items) do itemCost = itemCost + math.max(0, safeNumber(item.estimatedCost)) end
    local professionalFee = self:getTenancyHandbackProfessionalFee(tenancy, #items)
    local totalCost = itemCost + professionalFee
    tenancy.handbackReference = tenancy.handbackReference ~= "" and tenancy.handbackReference
        or string.format("RFF-D-%06d", math.floor(safeNumber(tenancy.id)))
    tenancy.handbackInspectionPeriod = tenancy.handbackInspectionPeriod > 0 and tenancy.handbackInspectionPeriod or current
    tenancy.handbackFinalInspectionPeriod = finalAssessment and current
        or math.max(current, math.floor(safeNumber(tenancy.contractualEndPeriod)))
    tenancy.handbackReviewCount = tenancy.handbackReviewCount + 1
    tenancy.handbackItems = items
    tenancy.handbackItemCount = #items
    tenancy.handbackUnresolvedCount = #items
    tenancy.handbackProfessionalFee = professionalFee
    tenancy.handbackEstimatedCost = totalCost

    if finalAssessment then
        tenancy.handbackStatus = #items > 0 and "FINAL_CHARGES" or "FINAL_CLEAR"
        tenancy.handbackFinalCost = #items > 0 and totalCost or 0
        tenancy.handbackRemedyDeadlinePeriod = 0
    elseif #items == 0 then
        tenancy.handbackStatus = (previousStatus == "REMEDY_REQUIRED" or previousStatus == "OUTSTANDING")
            and "REMEDIED" or "CLEAR"
        tenancy.handbackFinalCost = 0
        tenancy.handbackRemedyDeadlinePeriod = 0
    else
        local enforcement = self:getTenancyBreachEnforcementTerms(tenancy, #items)
        local contractualEnd = math.max(current + 1, math.floor(safeNumber(tenancy.contractualEndPeriod)))
        if previousStatus == "NONE" or previousStatus == "CLEAR" or previousStatus == "REMEDIED"
            or previousStatus == "CANCELLED" then
            tenancy.handbackStatus = "REMEDY_REQUIRED"
            tenancy.handbackRemedyDeadlinePeriod = math.min(contractualEnd, current + enforcement.remedyMonths)
        else
            tenancy.handbackStatus = "OUTSTANDING"
            tenancy.handbackRemedyDeadlinePeriod = contractualEnd
        end
    end

    local detailParts = {}
    for index, item in ipairs(items) do
        if index <= 12 then
            detailParts[#detailParts + 1] = string.format("%s. Required action: %s. Estimated cost: %s",
                item.description, item.remedy, g_i18n:formatMoney(item.estimatedCost or 0, 0, true, true))
        end
    end
    if #items > #detailParts then detailParts[#detailParts + 1] = string.format("and %d further matter(s)", #items - #detailParts) end
    local summary = #items == 0 and "The handback inspection records no outstanding reinstatement work"
        or string.format("%d handback item(s) are outstanding: %s", #items, table.concat(detailParts, "; "))
    tenancy.handbackLatestSummary = summary

    if not finalAssessment then
        if trigger == "PRE_EXPIRY" then tenancy.expiryWarning3Sent = true end
        local eventType = #items > 0 and "HANDBACK_SCHEDULE"
            or ((previousStatus == "REMEDY_REQUIRED" or previousStatus == "OUTSTANDING")
                and "HANDBACK_REMEDIED" or "HANDBACK_CLEAR")
        local action
        if #items > 0 then
            action = string.format("Complete the listed work by %s. The current estimated repair, surveyor and administration exposure is %s. A final inspection will still take place before possession ends in %s. Any tenant asset left at possession will pass to the landlord without compensation.",
                formatTenancyPeriod(tenancy.handbackRemedyDeadlinePeriod),
                g_i18n:formatMoney(totalCost, 0, true, true),
                formatTenancyPeriod(tenancy.handbackFinalInspectionPeriod))
        else
            action = string.format("No deduction is presently indicated. A final possession inspection will still take place in %s. Any tenant asset left at possession will pass to the landlord without compensation.",
                formatTenancyPeriod(tenancy.handbackFinalInspectionPeriod))
        end
        local event = self:createTenancyNarrative(tenancy, eventType, {
            token=string.format("handback:%d:%d:%s", safeNumber(tenancy.id), tenancy.handbackReviewCount, tenancy.handbackStatus),
            reference=tenancy.handbackReference, documentStatus=tenancy.handbackStatus,
            outcome=tenancy.handbackStatus, inspectionSummary=summary, inspectionAction=action,
            remedyMonths=math.max(0, tenancy.handbackRemedyDeadlinePeriod - current),
            remedyDeadlinePeriod=tenancy.handbackRemedyDeadlinePeriod,
            legalCharge=professionalFee
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_handback", "Tenancy Handback Inspection", #items > 0)
    end
    print(string.format("[RealisticFarmFinance] Tenancy handback inspection agreement=%s reference=%s trigger=%s status=%s items=%d itemCost=%.2f professionalFee=%.2f total=%.2f deadline=%d",
        tostring(tenancy.agreementId or tenancy.id), tenancy.handbackReference, trigger, tenancy.handbackStatus,
        #items, itemCost, professionalFee, totalCost, tenancy.handbackRemedyDeadlinePeriod))
    return {reference=tenancy.handbackReference, status=tenancy.handbackStatus, items=items,
        itemCount=#items, itemCost=itemCost, professionalFee=professionalFee, totalCost=totalCost}, nil
end

function RFF_PropertyFinanceService:processTenancyHandback(tenancy, currentPeriod)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then return false end
    self:ensureTenancyHandbackState(tenancy)
    if tenancy.renewalOfferStatus == "ACCEPTED" and safeNumber(tenancy.successorAgreementId) > 0 then
        if tenancy.handbackStatus ~= "NONE" and tenancy.handbackStatus ~= "CANCELLED" then
            tenancy.handbackStatus = "CANCELLED"
            tenancy.handbackItems = {}
            tenancy.handbackItemCount = 0
            tenancy.handbackUnresolvedCount = 0
            tenancy.handbackEstimatedCost = 0
            tenancy.handbackProfessionalFee = 0
            tenancy.handbackLatestSummary = "Handback inspection cancelled because a successor tenancy has been executed"
            return true
        end
        return false
    end
    local remaining = math.max(0, math.floor(safeNumber(tenancy.contractualEndPeriod)) - math.floor(safeNumber(currentPeriod)))
    if tenancy.handbackStatus == "NONE" and remaining > 0 and remaining <= TENANCY_HANDBACK_INSPECTION_MONTHS then
        return self:performTenancyHandbackInspection(tenancy, "PRE_EXPIRY") ~= nil
    end
    if (tenancy.handbackStatus == "REMEDY_REQUIRED" or tenancy.handbackStatus == "OUTSTANDING")
        and safeNumber(tenancy.handbackRemedyDeadlinePeriod) > 0
        and currentPeriod >= tenancy.handbackRemedyDeadlinePeriod and remaining > 0 then
        return self:performTenancyHandbackInspection(tenancy, "REINSPECTION") ~= nil
    end
    return false
end

function RFF_PropertyFinanceService:notifyTenancyHandbackSettlement(tenancy)
    if tenancy == nil then return end
    self:ensureTenancyHandbackState(tenancy)
    local action = string.format("Possession has returned to the landlord. Dilapidations assessed: %s; deposit applied across rent, covenant and handback liabilities: %s; deposit returned: %s; balance still due: %s.",
        g_i18n:formatMoney(tenancy.settlementDilapidationCosts or 0, 0, true, true),
        g_i18n:formatMoney(tenancy.settlementDepositApplied or 0, 0, true, true),
        g_i18n:formatMoney(tenancy.settlementDepositReturned or 0, 0, true, true),
        g_i18n:formatMoney(tenancy.settlementFinalBalance or 0, 0, true, true))
    if safeNumber(tenancy.forfeitedPlaceableCount) > 0 then
        action = action .. string.format(" %d tenant asset(s) left on the holding transferred to the landlord without compensation; their former sale value was %s.",
            math.floor(safeNumber(tenancy.forfeitedPlaceableCount)),
            g_i18n:formatMoney(tenancy.forfeitedPlaceableValue or 0, 0, true, true))
    end
    local event = self:createTenancyNarrative(tenancy, "HANDBACK_SETTLEMENT", {
        token=string.format("handback:%d:SETTLEMENT", safeNumber(tenancy.id)), reference=tenancy.handbackReference,
        documentStatus=tenancy.handbackStatus, outcome=tenancy.handbackStatus,
        inspectionSummary=tenancy.handbackLatestSummary, inspectionAction=action,
        legalCharge=tenancy.handbackProfessionalFee, depositApplied=tenancy.settlementDepositApplied,
        depositReturned=tenancy.settlementDepositReturned, finalBalance=tenancy.settlementFinalBalance
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_handback_settlement", "Tenancy Handback Settlement",
        safeNumber(tenancy.settlementFinalBalance) > 0.001)
    tenancy.expiryNotificationSent = true
end

function RFF_PropertyFinanceService:performTenancyInspection(tenancy, trigger)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return nil, "server_only" end
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then return nil, "inactive" end
    self:ensureTenancyConditionSurvey(tenancy, true)
    self:ensureTenancyConsentState(tenancy)
    self:ensureTenancyInspectionState(tenancy)

    local currentPeriod = self.repository:getCurrentPeriodIndex()
    local currentDay = self:getCurrentDay()
    local previousNextInspectionPeriod = math.max(0, math.floor(safeNumber(tenancy.nextInspectionPeriod)))
    trigger = tostring(trigger or "ROUTINE"):upper()
    for _, parcel in ipairs(tenancy.parcelConditions or {}) do
        print(string.format("[RealisticFarmFinance] Tenancy boundary evidence agreement=%s land=%d available=%s source=%s baseline=%.2fha current=%.2fha expansion=%.2fha threshold=%.2fha",
            tostring(tenancy.agreementId or tenancy.id), math.floor(safeNumber(parcel.farmlandId)),
            tostring(parcel.boundarySurveyAvailable == true), tostring(parcel.boundaryBaselineSource or ""),
            safeNumber(parcel.initialFieldAreaSqm) / 10000, safeNumber(parcel.currentFieldAreaSqm) / 10000,
            safeNumber(parcel.boundaryExpansionSqm) / 10000, safeNumber(parcel.boundaryExpansionThresholdSqm) / 10000))
    end
    local findings = {}
    local breachCount = 0
    local authorisedCount = 0
    local advisoryCount = 0
    local function addFinding(status, description, reference)
        findings[#findings + 1] = {status=status, description=description, reference=reference or ""}
        if status == "BREACH" then breachCount = breachCount + 1
        elseif status == "AUTHORISED" then authorisedCount = authorisedCount + 1
        else advisoryCount = advisoryCount + 1 end
    end

    for _, parcel in ipairs(tenancy.parcelConditions or {}) do
        local initialUse = tostring(parcel.initialUse or "UNCLASSIFIED"):upper()
        local currentUse = tostring(parcel.currentUse or initialUse):upper()
        if initialUse == "GRASS" and currentUse == "ARABLE" then
            local reasons = {}
            local consentReference = ""
            local observedDay = 0
            local observedPeriod = currentPeriod
            local landUseAlteration = nil
            for index = #(tenancy.alterations or {}), 1, -1 do
                local alteration = tenancy.alterations[index]
                local sameParcel = math.floor(safeNumber(alteration.farmlandId)) == math.floor(safeNumber(parcel.farmlandId))
                local grassConversion = tostring(alteration.details or ""):upper():find("GRASS TO ARABLE", 1, true) ~= nil
                if sameParcel and tostring(alteration.alterationType or ""):upper() == "LAND_USE_CHANGE" and grassConversion then
                    landUseAlteration = alteration
                    observedDay = math.max(0, math.floor(safeNumber(alteration.day)))
                    observedPeriod = math.max(0, math.floor(safeNumber(alteration.period)))
                    break
                end
            end
            if tenancy.permanentGrassRestriction == true then
                local consent = self:getTenancyInspectionConsent(tenancy, "GRASS_CULTIVATION", "AUTHORITY", observedDay, observedPeriod)
                if consent == nil then reasons[#reasons + 1] = "permanent-grass cultivation was not authorised"
                else consentReference = consent.reference or "" end
            end
            if tostring(tenancy.permittedEnterprise or "MIXED"):upper() == "LIVESTOCK" then
                reasons[#reasons + 1] = "the current enterprise covenant does not permit arable conversion"
            end
            local description = string.format("Land %d changed from recorded grass to arable use", parcel.farmlandId or 0)
            if #reasons > 0 then
                if landUseAlteration ~= nil then
                    landUseAlteration.status = "BREACH"
                    landUseAlteration.consentReference = ""
                end
                addFinding("BREACH", description .. ": " .. table.concat(reasons, "; "))
            elseif consentReference ~= "" then
                if landUseAlteration ~= nil then
                    landUseAlteration.status = "AUTHORISED"
                    landUseAlteration.consentReference = consentReference
                end
                addFinding("AUTHORISED", description, consentReference)
            end
        end
    end

    for _, alteration in ipairs(tenancy.alterations or {}) do
        local alterationType = tostring(alteration.alterationType or ""):upper()
        local category = tostring(alteration.category or ""):upper()
        local requestType = nil
        local description = nil
        local remedied = self:isTenancyAlterationRemedied(tenancy, alteration)
        local fieldBoundaryExpansion = alterationType == "FIELD_BOUNDARY_EXPANSION"
        local establishedBoundaryRemoval = (fieldBoundaryExpansion or alterationType == "FENCE_REMOVED"
            or (alterationType == "PLACEABLE_REMOVED" and category:find("FENCE", 1, true) ~= nil))
            and alteration.assetOwnership ~= "TENANT"
        if not remedied and establishedBoundaryRemoval and tenancy.boundaryRemovalRequiresConsent ~= false then
            requestType = "BOUNDARY_WORKS"
            if fieldBoundaryExpansion then
                description = string.format("Connected field footprint on Land %d expanded by %.2f ha beyond its commencement boundary",
                    alteration.farmlandId or 0, safeNumber(alteration.value) / 10000)
            else
                description = string.format("Established boundary removed on Land %d (%s)", alteration.farmlandId or 0,
                    alteration.assetName ~= nil and alteration.assetName ~= "" and alteration.assetName or "field boundary")
            end
        elseif not remedied and tenancy.improvementsRequireConsent ~= false and self:isMaterialTenancyImprovementAlteration(tenancy, alteration) then
            requestType = "CAPITAL_IMPROVEMENT"
            local action = alterationType == "PLACEABLE_BUILT" and "constructed" or (alterationType == "PLACEABLE_REMOVED" and "removed" or "altered")
            description = string.format("Material improvement %s on Land %d (%s)", action, alteration.farmlandId or 0,
                alteration.assetName ~= nil and alteration.assetName ~= "" and alteration.assetName or alteration.details or "recorded works")
        end
        if requestType ~= nil then
            local consent = self:getTenancyInspectionConsent(tenancy, requestType, "AUTHORITY", alteration.day, alteration.period)
            if consent ~= nil then
                alteration.status = "AUTHORISED"
                alteration.consentReference = consent.reference or ""
                addFinding("AUTHORISED", description, alteration.consentReference)
            else
                alteration.status = "BREACH"
                alteration.consentReference = ""
                addFinding("BREACH", description .. ": no prior written consent is recorded")
            end
        end
    end

    local detailParts = {}
    local summary
    if breachCount > 0 then
        for _, finding in ipairs(findings) do
            if finding.status == "BREACH" and #detailParts < 4 then
                detailParts[#detailParts + 1] = finding.description
            end
        end
        if breachCount > #detailParts then
            detailParts[#detailParts + 1] = string.format("and %d further breach(es)", breachCount - #detailParts)
        end
        summary = string.format("%d potential covenant breach(es) identified", breachCount)
        if #detailParts > 0 then summary = summary .. ": " .. table.concat(detailParts, "; ") end
    elseif authorisedCount > 0 then
        summary = string.format("No breach identified; %d recorded alteration(s) matched prior written consent", authorisedCount)
    else
        summary = "No recorded evidence of a covenant breach was identified"
    end

    local id = tenancy.inspectionNextId
    tenancy.inspectionNextId = id + 1
    tenancy.inspectionLatestId = id
    local relationshipChange = 0
    if trigger == "ROUTINE" then
        relationshipChange = breachCount > 0 and -math.min(2, 0.5 + breachCount * 0.25) or 0.25
        self:adjustTenancyLandlordRelationship(tenancy, relationshipChange,
            breachCount > 0 and "COVENANT_INSPECTION_BREACH" or "COVENANT_INSPECTION_CLEAR")
    end
    local report = {
        id=id, reference=string.format("RFF-I-%06d-%02d", math.floor(safeNumber(tenancy.id)), id),
        period=currentPeriod, day=currentDay, trigger=trigger,
        status=breachCount > 0 and "BREACH" or "CLEAR", summary=summary,
        breachCount=breachCount, authorisedCount=authorisedCount, advisoryCount=advisoryCount,
        relationshipChange=relationshipChange
    }
    table.insert(tenancy.inspectionReports, report)
    tenancy.lastInspectionPeriod = currentPeriod
    tenancy.lastInspectionStatus = report.status
    tenancy.lastInspectionReference = report.reference
    tenancy.lastInspectionSummary = report.summary
    tenancy.covenantComplianceStatus = breachCount > 0 and "BREACH_RECORDED" or "COMPLIANT"
    local nextPeriod = currentPeriod + self:getTenancyInspectionInterval(tenancy)
    if trigger == "ROUTINE" then
        tenancy.nextInspectionPeriod = safeNumber(tenancy.contractualEndPeriod) > 0 and nextPeriod >= safeNumber(tenancy.contractualEndPeriod) and 0 or nextPeriod
    else
        tenancy.nextInspectionPeriod = previousNextInspectionPeriod
    end

    local breachCase, caseTransition = self:updateTenancyBreachCaseFromInspection(tenancy, report)
    local eventType = breachCount > 0 and "COVENANT_INSPECTION_FINDINGS" or "COVENANT_INSPECTION_CLEAR"
    if caseTransition == "OPENED" then eventType = "COVENANT_REMEDY_NOTICE"
    elseif caseTransition == "REMEDIED" then eventType = "COVENANT_REMEDIED"
    elseif caseTransition == "FINAL_WARNING" then eventType = "COVENANT_FINAL_WARNING"
    elseif caseTransition == "TERMINATION_NOTICE" then eventType = "COVENANT_TERMINATION_NOTICE"
    elseif caseTransition == "TERMINATED" then eventType = "COVENANT_TERMINATED" end
    local inspectionAction = breachCount > 0 and "The holding should remain unchanged while any required remedy is considered." or "No action is required."
    if caseTransition == "OPENED" then
        local relationship = self:getTenancyLandlordRelationship(tenancy)
        local relationshipText = g_i18n ~= nil and g_i18n:getText(relationship.key) or relationship.code
        inspectionAction = string.format("The landlord's %s approach and the current %s relationship allow %d month(s), until %s. Rectify every finding by then. Failure will trigger substantial legal charges and can end the tenancy.",
            tostring(breachCase.landlordApproach or self:getLandlordApproach(tenancy.landlord, tenancy.farmlandId)):lower(),
            tostring(relationshipText or relationship.code):lower(), breachCase.remedyMonths or 1,
            formatTenancyPeriod(breachCase.remedyDeadlinePeriod))
    elseif caseTransition == "REMEDIED" then
        inspectionAction = "The required reinstatement has been recognised and the breach case is closed."
    elseif caseTransition == "FINAL_WARNING" then
        inspectionAction = string.format("This is the final warning. Legal and land-agent enforcement costs of %s are charged now. If every breach is not cured before the review in %s, formal notice to terminate the tenancy will be served.",
            g_i18n:formatMoney(breachCase.lastChargeAmount or 0, 0, true, true),
            formatTenancyPeriod(breachCase.nextReviewPeriod))
    elseif caseTransition == "TERMINATION_NOTICE" then
        inspectionAction = string.format("Formal notice to terminate has been served. A further legal enforcement charge of %s is added. The tenancy will end in %s unless every breach is remedied before the final inspection.",
            g_i18n:formatMoney(breachCase.lastChargeAmount or 0, 0, true, true),
            formatTenancyPeriod(breachCase.terminationEffectivePeriod or breachCase.nextReviewPeriod))
    elseif caseTransition == "TERMINATED" then
        inspectionAction = string.format("The tenancy is terminated for continuing covenant default. Agricultural and construction access has ended. Physical handback costs: %s; deposit applied: %s; deposit returned: %s; outstanding balance: %s.",
            g_i18n:formatMoney(tenancy.settlementDilapidationCosts or 0, 0, true, true),
            g_i18n:formatMoney(tenancy.settlementDepositApplied or 0, 0, true, true),
            g_i18n:formatMoney(tenancy.settlementDepositReturned or 0, 0, true, true),
            g_i18n:formatMoney(tenancy.settlementFinalBalance or 0, 0, true, true))
        if safeNumber(tenancy.forfeitedPlaceableCount) > 0 then
            inspectionAction = inspectionAction .. string.format(" %d tenant-owned fixture(s) left on the holding have transferred to the landlord without compensation. Their former sale value was %s.",
                math.floor(safeNumber(tenancy.forfeitedPlaceableCount)),
                g_i18n:formatMoney(tenancy.forfeitedPlaceableValue or 0, 0, true, true))
        end
    end
    local event = self:createTenancyNarrative(tenancy, eventType, {
        token=string.format("inspection:%d:%d:%s", safeNumber(tenancy.id), id, tostring(caseTransition or "REPORT")),
        reference=breachCase ~= nil and breachCase.reference or report.reference,
        documentStatus=caseTransition == "TERMINATED" and "TENANCY_TERMINATED" or report.status,
        outcome=caseTransition or report.status, inspectionSummary=report.summary,
        inspectionAction=inspectionAction, landlordApproach=breachCase ~= nil and breachCase.landlordApproach or "",
        remedyMonths=breachCase ~= nil and breachCase.remedyMonths or 0,
        remedyDeadlinePeriod=breachCase ~= nil and breachCase.remedyDeadlinePeriod or 0,
        nextReviewPeriod=breachCase ~= nil and breachCase.nextReviewPeriod or 0,
        terminationEffectivePeriod=breachCase ~= nil and breachCase.terminationEffectivePeriod or 0,
        legalCharge=breachCase ~= nil and breachCase.lastChargeAmount or 0,
        depositApplied=tenancy.settlementDepositApplied or 0,
        depositReturned=tenancy.settlementDepositReturned or 0,
        finalBalance=tenancy.settlementFinalBalance or 0
    })
    local titleKey = caseTransition == "TERMINATED" and "rff_phone_title_tenancy_default" or "rff_phone_title_tenancy_inspection"
    local fallbackTitle = caseTransition == "TERMINATED" and "Tenancy Terminated" or "Tenancy Covenant Enforcement"
    self:notifyTenancyNarrative(tenancy, event, titleKey, fallbackTitle, breachCount > 0)
    if (caseTransition == "FINAL_WARNING" or caseTransition == "TERMINATION_NOTICE") and breachCase ~= nil then
        self:trySettleTenancyBreachCaseFee(tenancy, breachCase)
    end
    print(string.format("[RealisticFarmFinance] Tenancy inspection agreement=%s reference=%s trigger=%s status=%s breaches=%d authorised=%d relationshipChange=%.2f",
        tostring(tenancy.agreementId or tenancy.id), report.reference, report.trigger, report.status,
        report.breachCount, report.authorisedCount, report.relationshipChange))
    return report, nil
end

function RFF_PropertyFinanceService:setRestrictiveTestCovenants(tenancy)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then return false, "inactive" end
    self:ensureTenancyConditionSurvey(tenancy, false)
    if tenancyHasRecordedGrass(tenancy) ~= true then return false, "no_grass" end

    tenancy.permittedEnterprise = "LIVESTOCK"
    tenancy.agriculturalUsePermitted = true
    tenancy.permanentGrassRestriction = true
    tenancy.boundaryRemovalRequiresConsent = true
    tenancy.improvementsRequireConsent = true
    tenancy.tenantMaintenanceObligation = true

    -- Keep any displayed renewal package aligned with the forced operative test
    -- terms. This is a test helper only; it does not create landlord correspondence.
    local restrictive = self:normaliseTenancyRenewalTerms(tenancy, {
        permittedEnterprise="LIVESTOCK", permanentGrassRestriction=true,
        boundaryRemovalRequiresConsent=true, improvementsRequireConsent=true,
        tenantMaintenanceObligation=true
    })
    for _, prefix in ipairs({"renewalOriginal", "renewalOffer", "renewalTenant"}) do
        self:setTenancyRenewalTerms(tenancy, prefix, restrictive)
    end
    tenancy.renewalCovenantPackageVersion = TENANCY_COVENANT_PACKAGE_VERSION

    -- Expire any old written authorities so the restrictive state is unambiguous.
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    for _, request in ipairs(tenancy.consentRequests or {}) do
        if request.status == "APPROVED" or request.status == "APPROVED_CONDITIONS" then
            request.expiresPeriod = math.max(1, current - 1)
        end
    end
    tenancy.covenantComplianceStatus = "COMPLIANT"
    print(string.format("[RealisticFarmFinance] Restrictive tenancy test covenants applied agreement=%s grassParcels=true enterprise=LIVESTOCK boundaryConsent=true improvementConsent=true",
        tostring(tenancy.agreementId or tenancy.id)))
    return true, nil
end
local TENANCY_RENEWAL_RESPONSE_MONTHS = 3
local TENANCY_REVIEW_RENT_FACTOR = 1.025
local TENANCY_CONSENT_TYPES = {
    ENTERPRISE=true,
    GRASS_CULTIVATION=true,
    BOUNDARY_WORKS=true,
    CAPITAL_IMPROVEMENT=true,
    MAINTENANCE=true
}
local TENANCY_CONSENT_PENDING = {RECEIVED=true, PROFESSIONAL_REVIEW=true, TENANT_DECISION=true}
local TENANCY_LANDLORD_NOTICE_PENDING = {LANDLORD_NOTICE=true, NOTICE_RUNNING=true}
local TENANCY_CONSENT_BASE_SUPPORT = {
    ENTERPRISE=0.68,
    GRASS_CULTIVATION=0.50,
    BOUNDARY_WORKS=0.57,
    CAPITAL_IMPROVEMENT=0.66
}
local TENANCY_VARIATION_FEE_BASE = {
    ENTERPRISE=450,
    GRASS_CULTIVATION=350,
    BOUNDARY_WORKS=400,
    CAPITAL_IMPROVEMENT=550,
    MAINTENANCE=300
}
local TENANCY_VARIATION_FEE_RENT_RATE = {
    ENTERPRISE=0.0075,
    GRASS_CULTIVATION=0.0040,
    BOUNDARY_WORKS=0.0050,
    CAPITAL_IMPROVEMENT=0.0080,
    MAINTENANCE=0.0030
}
local TENANCY_LANDLORD_REVIEW_INTERVAL = 12
local TENANCY_LANDLORD_PROPOSAL_MIN_REMAINING = 4

function RFF_PropertyFinanceService:notifyTenancy(tenancy, titleKey, fallbackTitle, messageKey, fallbackMessage, critical, ...)
    if tenancy == nil or RFF_NotificationService == nil then return false end
    local message = RFF_NotificationService:formatText(messageKey, fallbackMessage, ...)
    local sender = self:getLandlordName(tenancy.landlord, tenancy.farmlandId)
    local title = RFF_NotificationService:getText(titleKey, fallbackTitle)
    return RFF_NotificationService:send(tenancy.farmId, sender, title, message, "tenancy", message, critical == true)
end

function RFF_PropertyFinanceService:getTenancyPlayerName()
    local mission = g_currentMission
    if mission ~= nil then
        local nickname = tostring(mission.playerNickname or ""):match("^%s*(.-)%s*$")
        if nickname ~= "" then return nickname end

        if mission.player ~= nil and mission.player.getNickname ~= nil then
            local ok, playerNickname = pcall(mission.player.getNickname, mission.player)
            playerNickname = ok and tostring(playerNickname or ""):match("^%s*(.-)%s*$") or ""
            if playerNickname ~= "" and playerNickname ~= "Unknown" then return playerNickname end
        end

        if mission.userManager ~= nil and mission.userManager.getUserByUserId ~= nil and mission.playerUserId ~= nil then
            local ok, user = pcall(mission.userManager.getUserByUserId, mission.userManager, mission.playerUserId)
            if ok and user ~= nil and user.getNickname ~= nil then
                local nicknameOk, userNickname = pcall(user.getNickname, user)
                userNickname = nicknameOk and tostring(userNickname or ""):match("^%s*(.-)%s*$") or ""
                if userNickname ~= "" and userNickname ~= "Unknown" then return userNickname end
            end
        end
    end
    return "Farmer"
end

function RFF_PropertyFinanceService:getTenancyCorrespondenceHudText()
    if RFF_NotificationService ~= nil then
        return RFF_NotificationService:getText("rff_tenancy_hud_update_received", "Tenancy Updated Received")
    end
    return "Tenancy Updated Received"
end

function RFF_PropertyFinanceService:getTenancyNarrativeContext(tenancy, extra)
    if tenancy == nil then return nil end
    local relationship = self:getTenancyLandlordRelationship(tenancy)
    local profile = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
    local maxRounds = math.max(2, math.min(4, math.floor(safeNumber(profile.baseRounds) + safeNumber(relationship.roundBonus))))
    local currentPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local context = {
        profileId=profile.id,
        landlordName=self:getLandlordName(profile.id, tenancy.farmlandId),
        holdingName=tenancy.holdingName or tenancy.agreementId or "the holding",
        playerName=self:getTenancyPlayerName(),
        farmlandId=math.max(0, math.floor(safeNumber(tenancy.farmlandId))),
        relationshipCode=relationship.code,
        relationshipPoints=relationship.points,
        round=math.max(0, math.floor(safeNumber(tenancy.renewalNegotiationAttempts))),
        remainingRounds=math.max(0, maxRounds - math.floor(safeNumber(tenancy.renewalNegotiationAttempts))),
        day=self:getCurrentDay(), period=currentPeriod,
        replyMonths=math.max(0, math.floor(safeNumber(tenancy.renewalOfferExpiryPeriod)) - currentPeriod),
        reference=tenancy.renewalLegalReference or "",
        documentStatus=tenancy.renewalDocumentStatus or "",
        landlordRent=tenancy.renewalOfferAnnualRent or tenancy.annualRent or 0,
        tenantRent=tenancy.renewalTenantProposalRent or 0,
        counterRent=tenancy.renewalLandlordCounterRent or tenancy.renewalOfferAnnualRent or 0,
        agreedRent=tenancy.renewalNegotiatedAnnualRent or tenancy.renewalOfferAnnualRent or 0,
        termMonths=tenancy.renewalOfferTermMonths or tenancy.termMonths or 0,
        paymentFrequency=tenancy.renewalOfferPaymentFrequency or tenancy.paymentFrequency or "MONTHLY"
    }
    for key, value in pairs(extra or {}) do context[key] = value end
    return context
end

function RFF_PropertyFinanceService:createTenancyNarrative(tenancy, eventType, extra)
    if tenancy == nil or self.narrativeService == nil then return nil, false end
    self.narrativeService:ensureTenancyVoice(tenancy, tenancy.landlord, tenancy.farmlandId)
    if eventType ~= "TENANCY_STARTED" and #(tenancy.narrativeEvents or {}) == 0
        and TENANCY_NARRATIVE_COMMENCED_STATES[tenancy.status or ""] then
        self.narrativeService:createTenancyEvent(tenancy, "TENANCY_STARTED", self:getTenancyNarrativeContext(tenancy, {
            token=string.format("tenancyStarted:%d", safeNumber(tenancy.id)),
            period=tenancy.commencementPeriod or tenancy.createdPeriod or 0,
            landlordRent=tenancy.annualRent, termMonths=tenancy.termMonths,
            memoryCode="NEW", relationshipCode="PROFESSIONAL", relationshipPoints=0,
            documentStatus="EXECUTED_TENANCY", outcome="COMMENCED"
        }))
    end
    return self.narrativeService:createTenancyEvent(tenancy, eventType, self:getTenancyNarrativeContext(tenancy, extra))
end

function RFF_PropertyFinanceService:notifyTenancyNarrative(tenancy, event, titleKey, fallbackTitle, critical, senderOverride)
    if tenancy == nil or event == nil or RFF_NotificationService == nil then return false end
    local sender = senderOverride or self:getLandlordName(tenancy.landlord, tenancy.farmlandId)
    local title = RFF_NotificationService:getText(titleKey, fallbackTitle)
    return RFF_NotificationService:send(tenancy.farmId, sender, title, event.text or "", "tenancy",
        self:getTenancyCorrespondenceHudText(), critical == true)
end

function RFF_PropertyFinanceService:getCurrentDay()
    local environment = g_currentMission ~= nil and g_currentMission.environment or nil
    return math.max(0, math.floor(safeNumber(environment ~= nil and environment.currentMonotonicDay or 0)))
end

function RFF_PropertyFinanceService:ensureTenancyConsentState(tenancy)
    if tenancy == nil then return end
    tenancy.landlordVariationNoticeMonths = math.max(3, math.floor(safeNumber(tenancy.landlordVariationNoticeMonths)))
    if not TENANCY_LANDLORD_VARIATION_NOTICE_MONTHS[tenancy.landlordVariationNoticeMonths] then tenancy.landlordVariationNoticeMonths = 3 end
    tenancy.landlordVariationCooldownMonths = math.max(12, math.floor(safeNumber(tenancy.landlordVariationCooldownMonths)))
    if not TENANCY_LANDLORD_VARIATION_COOLDOWN_MONTHS[tenancy.landlordVariationCooldownMonths] then tenancy.landlordVariationCooldownMonths = 12 end
    tenancy.consentRequests = tenancy.consentRequests or {}
    tenancy.consentNextId = math.max(1, math.floor(safeNumber(tenancy.consentNextId)))
    local maxId = 0
    for _, request in ipairs(tenancy.consentRequests) do
        maxId = math.max(maxId, math.floor(safeNumber(request.id)))
        request.initiator = request.initiator ~= nil and request.initiator ~= "" and request.initiator or "TENANT"
        request.feePayer = request.feePayer ~= nil and request.feePayer ~= "" and request.feePayer or request.initiator
        request.professionalFee = math.max(0, safeNumber(request.professionalFee))
        request.feePaid = math.max(0, safeNumber(request.feePaid))
        request.feeOutstanding = math.max(0, safeNumber(request.feeOutstanding))
        request.proposedTermKey = request.proposedTermKey or ""
        request.proposedValue = request.proposedValue or ""
        request.noticeServedPeriod = math.max(0, math.floor(safeNumber(request.noticeServedPeriod)))
        request.effectivePeriod = math.max(0, math.floor(safeNumber(request.effectivePeriod)))
        request.cooldownUntilPeriod = math.max(0, math.floor(safeNumber(request.cooldownUntilPeriod)))
    end
    tenancy.consentNextId = math.max(tenancy.consentNextId, maxId + 1)
    tenancy.consentLatestId = math.max(0, math.floor(safeNumber(tenancy.consentLatestId)))
    tenancy.covenantComplianceStatus = tenancy.covenantComplianceStatus or "COMPLIANT"
    tenancy.landlordVariationCount = math.max(0, math.floor(safeNumber(tenancy.landlordVariationCount)))
    tenancy.lastLandlordVariationPeriod = math.max(0, math.floor(safeNumber(tenancy.lastLandlordVariationPeriod)))
    if safeNumber(tenancy.nextLandlordVariationPeriod) <= 0 and self.repository ~= nil then
        local current = self.repository:getCurrentPeriodIndex()
        local delay = math.max(3, math.min(TENANCY_LANDLORD_REVIEW_INTERVAL, math.floor(math.max(1, safeNumber(tenancy.termMonths)) / 2)))
        local scheduled = math.floor(safeNumber(tenancy.commencementPeriod)) + delay
        tenancy.nextLandlordVariationPeriod = scheduled > current and scheduled or (current + 1)
    end
end

function RFF_PropertyFinanceService:getTenancyConsentTypeLabel(requestType)
    local keys = {
        ENTERPRISE="rff_tenancy_consent_type_enterprise",
        GRASS_CULTIVATION="rff_tenancy_consent_type_grass",
        BOUNDARY_WORKS="rff_tenancy_consent_type_boundary",
        CAPITAL_IMPROVEMENT="rff_tenancy_consent_type_improvement",
        MAINTENANCE="rff_tenancy_consent_type_maintenance"
    }
    local key = keys[requestType]
    return key ~= nil and g_i18n ~= nil and g_i18n:getText(key) or tostring(requestType or "Consent"):gsub("_", " ")
end

function RFF_PropertyFinanceService:getTenancyConsentTargetLabel(requestType, target)
    local variationKeys = {
        RETAIN_PERMANENT_GRASS="rff_tenancy_variation_target_retain_grass",
        PRIOR_BOUNDARY_CONSENT="rff_tenancy_variation_target_boundary_consent",
        PRIOR_IMPROVEMENT_CONSENT="rff_tenancy_variation_target_improvement_consent",
        TENANT_MAINTENANCE="rff_tenancy_variation_target_tenant_maintenance",
        RESTRICT_ENTERPRISE_ARABLE="rff_tenancy_variation_target_enterprise_arable",
        RESTRICT_ENTERPRISE_LIVESTOCK="rff_tenancy_variation_target_enterprise_livestock"
    }
    local variationKey = variationKeys[tostring(target or ""):upper()]
    if variationKey ~= nil then
        return g_i18n ~= nil and g_i18n:getText(variationKey) or tostring(target):gsub("_", " ")
    end
    if requestType == "ENTERPRISE" then
        local keys = {
            MIXED="rff_tenancy_enterprise_mixed",
            ARABLE="rff_tenancy_enterprise_arable",
            LIVESTOCK="rff_tenancy_enterprise_livestock"
        }
        local key = keys[tostring(target or "MIXED"):upper()] or keys.MIXED
        return g_i18n ~= nil and g_i18n:getText(key) or tostring(target or "MIXED")
    end
    local keys = {
        GRASS_CULTIVATION="rff_tenancy_consent_target_grass",
        BOUNDARY_WORKS="rff_tenancy_consent_target_boundary",
        CAPITAL_IMPROVEMENT="rff_tenancy_consent_target_improvement",
        MAINTENANCE="rff_tenancy_variation_target_tenant_maintenance"
    }
    local key = keys[requestType]
    return key ~= nil and g_i18n ~= nil and g_i18n:getText(key) or tostring(target or requestType or "Authority"):gsub("_", " ")
end

function RFF_PropertyFinanceService:getLatestTenancyConsentRequest(tenancy)
    self:ensureTenancyConsentState(tenancy)
    local requests = tenancy ~= nil and tenancy.consentRequests or {}
    return requests[#requests]
end

function RFF_PropertyFinanceService:getPendingTenancyConsentRequest(tenancy)
    self:ensureTenancyConsentState(tenancy)
    for index = #(tenancy ~= nil and tenancy.consentRequests or {}), 1, -1 do
        local request = tenancy.consentRequests[index]
        if TENANCY_CONSENT_PENDING[request.status or ""] then return request end
    end
    return nil
end

function RFF_PropertyFinanceService:getPendingLandlordVariationNotice(tenancy)
    self:ensureTenancyConsentState(tenancy)
    for index = #(tenancy ~= nil and tenancy.consentRequests or {}), 1, -1 do
        local request = tenancy.consentRequests[index]
        if request.initiator == "LANDLORD" and TENANCY_LANDLORD_NOTICE_PENDING[request.status or ""] then return request end
    end
    return nil
end

function RFF_PropertyFinanceService:getTenancyConsentRequirement(tenancy, requestType, target)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then
        return {eligible=false, required=false, code="inactive"}
    end
    requestType = tostring(requestType or ""):upper()
    target = tostring(target or ""):upper()
    if not TENANCY_CONSENT_TYPES[requestType] then return {eligible=false, required=false, code="invalid_type"} end
    local pending = self:getPendingTenancyConsentRequest(tenancy)
    if pending ~= nil then return {eligible=false, required=true, code="pending", pending=pending} end

    if requestType == "ENTERPRISE" then
        if not TENANCY_ENTERPRISES[target] then return {eligible=false, required=false, code="invalid_target"} end
        if tostring(tenancy.permittedEnterprise or "MIXED"):upper() == target then
            return {eligible=false, required=false, code="already_permitted"}
        end
    elseif requestType == "GRASS_CULTIVATION" and tenancy.permanentGrassRestriction ~= true then
        return {eligible=false, required=false, code="not_required"}
    elseif requestType == "BOUNDARY_WORKS" and tenancy.boundaryRemovalRequiresConsent == false then
        return {eligible=false, required=false, code="not_required"}
    elseif requestType == "CAPITAL_IMPROVEMENT" and tenancy.improvementsRequireConsent == false then
        return {eligible=false, required=false, code="not_required"}
    end

    local currentPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    for index = #(tenancy.consentRequests or {}), 1, -1 do
        local request = tenancy.consentRequests[index]
        if request.requestType == requestType and request.target == target
            and (request.status == "APPROVED" or request.status == "APPROVED_CONDITIONS")
            and (safeNumber(request.expiresPeriod) <= 0 or safeNumber(request.expiresPeriod) >= currentPeriod) then
            return {eligible=false, required=false, code="already_approved", existing=request}
        end
    end
    return {eligible=true, required=true, code="required"}
end

function RFF_PropertyFinanceService:getTenancyConsentRequirementText(requirement)
    local keys = {
        inactive="rff_tenancy_consent_inactive",
        invalid_type="rff_tenancy_consent_invalid",
        invalid_target="rff_tenancy_consent_invalid",
        pending="rff_tenancy_consent_pending_existing",
        already_permitted="rff_tenancy_consent_already_permitted",
        not_required="rff_tenancy_consent_not_required_note",
        already_approved="rff_tenancy_consent_already_approved",
        required="rff_tenancy_consent_required_note"
    }
    local key = keys[requirement ~= nil and requirement.code or "invalid_type"] or "rff_tenancy_consent_invalid"
    return g_i18n ~= nil and g_i18n:getText(key) or tostring(requirement ~= nil and requirement.code or "Unavailable")
end

function RFF_PropertyFinanceService:getTenancyVariationProfessionalFee(tenancy, requestType)
    requestType = tostring(requestType or ""):upper()
    local base = safeNumber(TENANCY_VARIATION_FEE_BASE[requestType] or 350)
    local rentRate = safeNumber(TENANCY_VARIATION_FEE_RENT_RATE[requestType] or 0.004)
    local annualRent = math.max(0, safeNumber(tenancy ~= nil and tenancy.annualRent or 0))
    local amount = math.max(250, math.min(2500, base + annualRent * rentRate))
    return math.floor((amount + 5) / 10) * 10
end

function RFF_PropertyFinanceService:getTenancyVariationFeeText(tenancy, request)
    if request == nil then return g_i18n ~= nil and g_i18n:getText("rff_tenancy_variation_fee_none") or "No professional costs due" end
    local fee = math.max(0, safeNumber(request.professionalFee))
    if fee <= 0 and (request.status == "RECEIVED" or request.status == "PROFESSIONAL_REVIEW" or request.status == "TENANT_DECISION") then
        fee = self:getTenancyVariationProfessionalFee(tenancy, request.requestType)
    end
    if fee <= 0 then return g_i18n ~= nil and g_i18n:getText("rff_tenancy_variation_fee_none") or "No professional costs due" end
    local formatted = g_i18n ~= nil and g_i18n:formatMoney(fee, 0, true, true) or string.format("%.0f", fee)
    local key = "rff_tenancy_variation_fee_tenant_estimate"
    if request.status == "DECLINED" or request.status == "DECLINED_BY_TENANT" then
        return g_i18n ~= nil and g_i18n:getText("rff_tenancy_variation_fee_none") or "No professional costs due"
    elseif request.initiator == "LANDLORD" then
        if request.status == "ACCEPTED" or request.status == "IMPOSED" then
            key = "rff_tenancy_variation_fee_landlord_paid"
        elseif request.status == "LANDLORD_NOTICE" or request.status == "NOTICE_RUNNING" then
            key = "rff_tenancy_variation_fee_landlord_notice"
        else
            key = "rff_tenancy_variation_fee_landlord_estimate"
        end
    elseif request.status == "APPROVED" or request.status == "APPROVED_CONDITIONS" then
        key = safeNumber(request.feeOutstanding) > 0.001 and "rff_tenancy_variation_fee_tenant_outstanding" or "rff_tenancy_variation_fee_tenant_paid"
    end
    local template = g_i18n ~= nil and g_i18n:getText(key) or "%s"
    return string.format(template, formatted)
end

function RFF_PropertyFinanceService:getTenancyVariationFeeDisplayText(tenancy, request)
    if request == nil then return g_i18n ~= nil and g_i18n:getText("rff_tenancy_variation_fee_none") or "No professional costs due" end
    local fee = math.max(0, safeNumber(request.professionalFee))
    if fee <= 0 and (request.status == "RECEIVED" or request.status == "PROFESSIONAL_REVIEW" or request.status == "TENANT_DECISION") then
        fee = self:getTenancyVariationProfessionalFee(tenancy, request.requestType)
    end
    if fee <= 0 or request.status == "DECLINED" or request.status == "DECLINED_BY_TENANT" then
        return g_i18n ~= nil and g_i18n:getText("rff_tenancy_variation_fee_none") or "No professional costs due"
    end
    local formatted = g_i18n ~= nil and g_i18n:formatMoney(fee, 0, true, true) or string.format("%.0f", fee)
    local key
    if request.initiator == "LANDLORD" then
        if request.status == "ACCEPTED" or request.status == "IMPOSED" then
            key = "rff_tenancy_variation_fee_landlord_paid_short"
        elseif request.status == "LANDLORD_NOTICE" or request.status == "NOTICE_RUNNING" then
            key = "rff_tenancy_variation_fee_landlord_notice_short"
        else
            key = "rff_tenancy_variation_fee_landlord_estimate_short"
        end
    elseif request.status == "APPROVED" or request.status == "APPROVED_CONDITIONS" then
        key = safeNumber(request.feeOutstanding) > 0.001 and "rff_tenancy_variation_fee_tenant_outstanding_short" or "rff_tenancy_variation_fee_tenant_paid_short"
    else
        key = "rff_tenancy_variation_fee_tenant_estimate_short"
    end
    return string.format(g_i18n ~= nil and g_i18n:getText(key) or "%s", formatted)
end

function RFF_PropertyFinanceService:getTenancyConsentApplicationCostText(tenancy, requestType)
    local request = {requestType=requestType, initiator="TENANT", status="RECEIVED",
        professionalFee=self:getTenancyVariationProfessionalFee(tenancy, requestType)}
    return self:getTenancyVariationFeeText(tenancy, request)
end

function RFF_PropertyFinanceService:trySettleTenancyVariationFee(tenancy, request)
    if tenancy == nil or request == nil or request.initiator ~= "TENANT"
        or (request.status ~= "APPROVED" and request.status ~= "APPROVED_CONDITIONS") then return false end
    request.professionalFee = math.max(0, safeNumber(request.professionalFee))
    request.feePaid = math.max(0, safeNumber(request.feePaid))
    request.feeOutstanding = math.max(0, request.professionalFee - request.feePaid)
    if request.feeOutstanding <= 0.001 then return true end
    local available = self.repository ~= nil and self.repository.getAvailableFunds ~= nil
        and self.repository:getAvailableFunds(tenancy.farmId) or farmMoney(tenancy.farmId)
    if available + 0.001 < request.feeOutstanding or g_currentMission == nil then return false end
    local amount = request.feeOutstanding
    if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(tenancy.farmId,
            "Tenancy legal and administration costs - " .. (tenancy.holdingName or tenancy.agreementId or "Agricultural holding"))
    end
    g_currentMission:addMoney(-amount, tenancy.farmId, moneyTypeFallback(), true, true)
    local manager = RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
    if manager ~= nil and manager.businessAdministration ~= nil
        and manager.businessAdministration.recordRedTapeDeductibleExpense ~= nil then
        manager.businessAdministration:recordRedTapeDeductibleExpense(tenancy.farmId, amount)
    end
    request.feePaid = request.feePaid + amount
    request.feeOutstanding = 0
    return true
end

function RFF_PropertyFinanceService:processTenancyVariationFeeArrears(tenancy)
    if tenancy == nil then return false end
    self:ensureTenancyConsentState(tenancy)
    local settled = false
    for _, request in ipairs(tenancy.consentRequests or {}) do
        if request.initiator == "TENANT" and safeNumber(request.feeOutstanding) > 0.001
            and self:trySettleTenancyVariationFee(tenancy, request) then
            settled = true
            if request.feeSettlementNotified ~= true then
                request.feeSettlementNotified = true
                local feeText = self:getTenancyVariationFeeText(tenancy, request)
                local event = self:createTenancyNarrative(tenancy, "VARIATION_COSTS_SETTLED", {
                    token=string.format("consent:%d:%d:COSTS_SETTLED", safeNumber(tenancy.id), safeNumber(request.id)),
                    reference=request.reference, documentStatus="COSTS_SETTLED", outcome="PAID",
                    consentType=self:getTenancyConsentTypeLabel(request.requestType),
                    consentTarget=self:getTenancyConsentTargetLabel(request.requestType, request.target),
                    professionalFeeText=feeText
                })
                self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_variation_costs", "Tenancy Professional Costs", false)
            end
        end
    end
    return settled
end

function RFF_PropertyFinanceService:submitTenancyConsentRequest(tenancy, requestType, target)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return false, "server_only" end
    self:ensureTenancyConsentState(tenancy)
    requestType = tostring(requestType or ""):upper()
    target = requestType == "ENTERPRISE" and tostring(target or ""):upper() or "AUTHORITY"
    local requirement = self:getTenancyConsentRequirement(tenancy, requestType, target)
    if not requirement.eligible then return false, requirement.code end

    local id = tenancy.consentNextId
    tenancy.consentNextId = id + 1
    tenancy.consentLatestId = id
    local currentDay = self:getCurrentDay()
    local request = {
        id=id,
        requestType=requestType,
        target=target,
        status="RECEIVED",
        submittedDay=currentDay,
        reviewDay=0,
        decisionDay=0,
        nextActionDay=currentDay + 1,
        reference=string.format("RFF-C-%06d-%02d", math.floor(safeNumber(tenancy.id)), id),
        conditions="",
        decisionReason="",
        expiresPeriod=0,
        initiator="TENANT",
        feePayer="TENANT",
        professionalFee=self:getTenancyVariationProfessionalFee(tenancy, requestType),
        feePaid=0,
        feeOutstanding=0,
        feeSettlementNotified=false,
        proposedTermKey="",
        proposedValue="",
        relationshipPoints=self:getTenancyLandlordRelationship(tenancy).points,
        profileId=self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId).id
    }
    table.insert(tenancy.consentRequests, request)
    local event = self:createTenancyNarrative(tenancy, "CONSENT_REQUEST", {
        token=string.format("consent:%d:%d:REQUEST", safeNumber(tenancy.id), id),
        reference=request.reference, documentStatus="REQUEST_RECEIVED", outcome="RECEIVED",
        consentType=self:getTenancyConsentTypeLabel(requestType),
        consentTarget=self:getTenancyConsentTargetLabel(requestType, target),
        professionalFeeText=self:getTenancyVariationFeeText(tenancy, request)
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_consent", "Landlord Consent", false)
    print(string.format("[RealisticFarmFinance] Tenancy consent submitted agreement=%s reference=%s type=%s target=%s nextDay=%d",
        tostring(tenancy.agreementId or tenancy.id), request.reference, requestType, target, request.nextActionDay))
    return true, nil, request
end

function RFF_PropertyFinanceService:assessTenancyConsentRequest(tenancy, request)
    local profile = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
    local relationship = self:getTenancyLandlordRelationship(tenancy)
    local _, weights = self:getTenancyCovenantCost(tenancy, self:normaliseTenancyRenewalTerms(tenancy, nil))
    local weightKeys = {ENTERPRISE="enterprise", GRASS_CULTIVATION="grass", BOUNDARY_WORKS="boundary", CAPITAL_IMPROVEMENT="improvements"}
    local sensitivity = safeNumber(weights[weightKeys[request.requestType] or "enterprise"] or 1)
    local score = safeNumber(TENANCY_CONSENT_BASE_SUPPORT[request.requestType] or 0.55)
    score = score + math.max(-0.24, math.min(0.30, relationship.points * 0.012))
    score = score - math.max(0, sensitivity - 0.90) * 0.28
    if request.requestType == "ENTERPRISE" and request.target == "MIXED" then score = score - 0.05 end
    if safeNumber(tenancy.arrears or tenancy.rentDue) > 0.001 then score = score - 0.20 else score = score + 0.06 end
    score = score - math.min(0.12, safeNumber(tenancy.missedPayments) * 0.025)
    score = score + (deterministicUnit(request.reference .. ":decision") - 0.5) * 0.16
    local outcome = score >= 0.65 and "APPROVED" or (score >= 0.45 and "APPROVED_CONDITIONS" or "DECLINED")
    return {score=score, outcome=outcome, profile=profile, relationship=relationship, sensitivity=sensitivity}
end

function RFF_PropertyFinanceService:getTenancyConsentDecisionText(request, outcome)
    local key
    if outcome == "DECLINED" then
        key = "rff_tenancy_consent_decision_declined"
    elseif outcome == "APPROVED" then
        key = "rff_tenancy_consent_decision_approved"
    else
        local keys = {
            ENTERPRISE="rff_tenancy_consent_condition_enterprise",
            GRASS_CULTIVATION="rff_tenancy_consent_condition_grass",
            BOUNDARY_WORKS="rff_tenancy_consent_condition_boundary",
            CAPITAL_IMPROVEMENT="rff_tenancy_consent_condition_improvement"
        }
        key = keys[request.requestType] or "rff_tenancy_consent_decision_approved"
    end
    return g_i18n ~= nil and g_i18n:getText(key) or outcome
end

function RFF_PropertyFinanceService:processTenancyConsentDay(tenancy, currentDay)
    local processed = false
    local notice = self:getPendingLandlordVariationNotice(tenancy)
    if notice ~= nil and notice.status == "LANDLORD_NOTICE" and currentDay >= safeNumber(notice.nextActionDay) then
        notice.status = "NOTICE_RUNNING"
        notice.reviewDay = currentDay
        notice.nextActionDay = 0
        local adviser = RFF_NotificationService ~= nil
            and RFF_NotificationService:getText("rff_phone_sender_tenancy_legal", "Farm Legal Adviser") or "Farm Legal Adviser"
        local event = self:createTenancyNarrative(tenancy, "LANDLORD_VARIATION_LEGAL_REVIEW", {
            token=string.format("consent:%d:%d:LEGAL_RESPONSE", safeNumber(tenancy.id), safeNumber(notice.id)),
            landlordName=adviser, reference=notice.reference, documentStatus="NOTICE_RUNNING", outcome="REVIEWED",
            consentType=self:getTenancyConsentTypeLabel(notice.requestType),
            consentTarget=self:getTenancyConsentTargetLabel(notice.requestType, notice.target),
            consentConditions=notice.conditions,
            professionalFeeText=self:getTenancyVariationFeeText(tenancy, notice),
            variationNoticeMonths=tenancy.landlordVariationNoticeMonths,
            variationEffectivePeriod=notice.effectivePeriod,
            variationCooldownMonths=tenancy.landlordVariationCooldownMonths,
            variationCooldownUntilPeriod=notice.cooldownUntilPeriod
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_legal_response", "Legal Review of Landlord Notice", false, adviser)
        print(string.format("[RealisticFarmFinance] Landlord variation notice reviewed agreement=%s reference=%s effectivePeriod=%d cooldownUntil=%d",
            tostring(tenancy.agreementId or tenancy.id), tostring(notice.reference or "-"), notice.effectivePeriod or 0, notice.cooldownUntilPeriod or 0))
        processed = true
    end
    local request = self:getPendingTenancyConsentRequest(tenancy)
    if request == nil or currentDay < safeNumber(request.nextActionDay) then return processed end
    if request.status == "RECEIVED" then
        request.status = "PROFESSIONAL_REVIEW"
        request.reviewDay = currentDay
        request.nextActionDay = currentDay + 1
        local event = self:createTenancyNarrative(tenancy, "CONSENT_REVIEW", {
            token=string.format("consent:%d:%d:REVIEW", safeNumber(tenancy.id), safeNumber(request.id)),
            reference=request.reference, documentStatus="WITH_LAND_AGENT", outcome="REVIEW",
            consentType=self:getTenancyConsentTypeLabel(request.requestType),
            consentTarget=self:getTenancyConsentTargetLabel(request.requestType, request.target)
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_consent_review", "Consent Review", false)
        print(string.format("[RealisticFarmFinance] Tenancy consent referred agreement=%s reference=%s decisionDay=%d",
            tostring(tenancy.agreementId or tenancy.id), request.reference, request.nextActionDay))
        return true
    end

    if request.status ~= "PROFESSIONAL_REVIEW" then return false end
    local assessment = self:assessTenancyConsentRequest(tenancy, request)
    request.status = assessment.outcome
    request.decisionDay = currentDay
    request.nextActionDay = 0
    request.expiresPeriod = assessment.outcome ~= "DECLINED" and math.floor(safeNumber(tenancy.contractualEndPeriod)) or 0
    request.conditions = self:getTenancyConsentDecisionText(request, assessment.outcome)
    request.decisionReason = request.conditions
    request.relationshipPoints = assessment.relationship.points
    if assessment.outcome == "APPROVED" then
        self:adjustTenancyLandlordRelationship(tenancy, 0.25, "CONSENT_APPROVED")
    elseif assessment.outcome == "APPROVED_CONDITIONS" then
        self:adjustTenancyLandlordRelationship(tenancy, 0.10, "CONSENT_APPROVED_CONDITIONS")
    end
    if assessment.outcome ~= "DECLINED" and request.requestType == "ENTERPRISE" then
        tenancy.permittedEnterprise = request.target
    end
    if assessment.outcome ~= "DECLINED" then
        request.professionalFee = math.max(0, safeNumber(request.professionalFee))
        request.feePayer = "TENANT"
        request.feeOutstanding = math.max(0, request.professionalFee - safeNumber(request.feePaid))
        self:trySettleTenancyVariationFee(tenancy, request)
    else
        request.feePaid = 0
        request.feeOutstanding = 0
    end
    local eventType = assessment.outcome == "APPROVED" and "CONSENT_APPROVED"
        or (assessment.outcome == "APPROVED_CONDITIONS" and "CONSENT_CONDITIONAL" or "CONSENT_DECLINED")
    local event = self:createTenancyNarrative(tenancy, eventType, {
        token=string.format("consent:%d:%d:DECISION", safeNumber(tenancy.id), safeNumber(request.id)),
        reference=request.reference, documentStatus=assessment.outcome, outcome=assessment.outcome,
        consentType=self:getTenancyConsentTypeLabel(request.requestType),
        consentTarget=self:getTenancyConsentTargetLabel(request.requestType, request.target),
        consentConditions=request.conditions,
        professionalFeeText=self:getTenancyVariationFeeText(tenancy, request)
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_consent_decision", "Consent Decision", false)
    print(string.format("[RealisticFarmFinance] Tenancy consent decided agreement=%s reference=%s outcome=%s score=%.3f fee=%.2f paid=%.2f outstanding=%.2f payer=%s",
        tostring(tenancy.agreementId or tenancy.id), request.reference, assessment.outcome, assessment.score,
        request.professionalFee or 0, request.feePaid or 0, request.feeOutstanding or 0, tostring(request.feePayer or "TENANT")))
    return true
end

function RFF_PropertyFinanceService:getLandlordVariationCandidates(tenancy)
    local candidates = {}
    if tenancy == nil then return candidates end
    if tenancy.permanentGrassRestriction ~= true and tenancyHasRecordedGrass(tenancy) ~= false then
        candidates[#candidates + 1] = {requestType="GRASS_CULTIVATION", target="RETAIN_PERMANENT_GRASS",
            proposedTermKey="permanentGrassRestriction", proposedValue="true"}
    end
    if tenancy.boundaryRemovalRequiresConsent == false then
        candidates[#candidates + 1] = {requestType="BOUNDARY_WORKS", target="PRIOR_BOUNDARY_CONSENT",
            proposedTermKey="boundaryRemovalRequiresConsent", proposedValue="true"}
    end
    if tenancy.improvementsRequireConsent == false then
        candidates[#candidates + 1] = {requestType="CAPITAL_IMPROVEMENT", target="PRIOR_IMPROVEMENT_CONSENT",
            proposedTermKey="improvementsRequireConsent", proposedValue="true"}
    end
    if tenancy.tenantMaintenanceObligation == false then
        candidates[#candidates + 1] = {requestType="MAINTENANCE", target="TENANT_MAINTENANCE",
            proposedTermKey="tenantMaintenanceObligation", proposedValue="true"}
    end
    local enterprise = tostring(tenancy.permittedEnterprise or "MIXED"):upper()
    if enterprise == "MIXED" then
        local proposed = deterministicUnit(tostring(tenancy.agreementId or tenancy.id) .. ":landlordEnterprise") >= 0.5 and "ARABLE" or "LIVESTOCK"
        candidates[#candidates + 1] = {requestType="ENTERPRISE", target="RESTRICT_ENTERPRISE_" .. proposed,
            proposedTermKey="permittedEnterprise", proposedValue=proposed}
    end
    return candidates
end

function RFF_PropertyFinanceService:createLandlordVariationProposal(tenancy, force)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return false, "server_only" end
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or ""] then return false, "inactive" end
    self:ensureTenancyConsentState(tenancy)
    if self:getPendingTenancyConsentRequest(tenancy) ~= nil or self:getPendingLandlordVariationNotice(tenancy) ~= nil then return false, "pending" end
    local current = self.repository:getCurrentPeriodIndex()
    if current < safeNumber(tenancy.nextLandlordVariationPeriod)
        and (not force or safeNumber(tenancy.landlordVariationCount) > 0) then return false, "cooldown" end
    local noticeMonths = math.max(3, math.floor(safeNumber(tenancy.landlordVariationNoticeMonths)))
    local cooldownMonths = math.max(12, math.floor(safeNumber(tenancy.landlordVariationCooldownMonths)))
    if safeNumber(tenancy.remainingMonths) <= math.max(TENANCY_LANDLORD_PROPOSAL_MIN_REMAINING, noticeMonths) then
        tenancy.nextLandlordVariationPeriod = current + cooldownMonths
        return false, "short_term"
    end
    local candidates = self:getLandlordVariationCandidates(tenancy)
    tenancy.lastLandlordVariationPeriod = current
    tenancy.nextLandlordVariationPeriod = current + cooldownMonths
    if #candidates == 0 then return false, "no_change" end

    local sequence = math.max(0, math.floor(safeNumber(tenancy.landlordVariationCount)))
    local selection = math.floor(deterministicUnit(string.format("%s:%d:landlordVariation", tostring(tenancy.agreementId or tenancy.id), sequence)) * #candidates) + 1
    local candidate = candidates[math.max(1, math.min(#candidates, selection))]
    local id = tenancy.consentNextId
    tenancy.consentNextId = id + 1
    tenancy.consentLatestId = id
    tenancy.landlordVariationCount = sequence + 1
    local currentDay = self:getCurrentDay()
    local request = {
        id=id,
        requestType=candidate.requestType,
        target=candidate.target,
        status="LANDLORD_NOTICE",
        submittedDay=currentDay,
        reviewDay=0,
        decisionDay=0,
        nextActionDay=currentDay + 1,
        reference=string.format("RFF-V-%06d-%02d", math.floor(safeNumber(tenancy.id)), id),
        conditions="",
        decisionReason="",
        expiresPeriod=math.floor(safeNumber(tenancy.contractualEndPeriod)),
        initiator="LANDLORD",
        feePayer="LANDLORD",
        professionalFee=self:getTenancyVariationProfessionalFee(tenancy, candidate.requestType),
        feePaid=0,
        feeOutstanding=0,
        feeSettlementNotified=false,
        proposedTermKey=candidate.proposedTermKey,
        proposedValue=candidate.proposedValue,
        noticeServedPeriod=current,
        effectivePeriod=current + noticeMonths,
        cooldownUntilPeriod=current + noticeMonths + cooldownMonths,
        relationshipPoints=self:getTenancyLandlordRelationship(tenancy).points,
        profileId=self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId).id
    }
    local targetLabel = self:getTenancyConsentTargetLabel(request.requestType, request.target)
    tenancy.nextLandlordVariationPeriod = request.cooldownUntilPeriod
    local proposalTemplate = g_i18n ~= nil and g_i18n:getText("rff_tenancy_landlord_variation_notice_terms")
        or "Formal notice: %s. The change takes effect after %d months."
    request.conditions = string.format(proposalTemplate, targetLabel, noticeMonths, cooldownMonths)
    table.insert(tenancy.consentRequests, request)
    local event = self:createTenancyNarrative(tenancy, "LANDLORD_VARIATION_NOTICE", {
        token=string.format("consent:%d:%d:LANDLORD_NOTICE", safeNumber(tenancy.id), id),
        reference=request.reference, documentStatus="LANDLORD_NOTICE", outcome="NOTICE_SERVED",
        consentType=self:getTenancyConsentTypeLabel(request.requestType),
        consentTarget=targetLabel,
        consentConditions=request.conditions,
        professionalFeeText=self:getTenancyVariationFeeText(tenancy, request),
        variationNoticeMonths=noticeMonths,
        variationEffectivePeriod=request.effectivePeriod,
        variationCooldownMonths=cooldownMonths,
        variationCooldownUntilPeriod=request.cooldownUntilPeriod
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_landlord_notice", "Landlord Variation Notice", false)
    print(string.format("[RealisticFarmFinance] Landlord variation notice agreement=%s reference=%s type=%s target=%s notice=%d effectivePeriod=%d cooldown=%d fee=%.2f payer=LANDLORD",
        tostring(tenancy.agreementId or tenancy.id), request.reference, request.requestType, request.target,
        noticeMonths, request.effectivePeriod, cooldownMonths, request.professionalFee))
    return true, nil, request
end

function RFF_PropertyFinanceService:applyLandlordVariation(tenancy, request)
    if tenancy == nil or request == nil then return false end
    local key = tostring(request.proposedTermKey or "")
    local value = tostring(request.proposedValue or "")
    if key == "permittedEnterprise" and TENANCY_ENTERPRISES[value:upper()] then
        tenancy.permittedEnterprise = value:upper()
    elseif key == "permanentGrassRestriction" then
        tenancy.permanentGrassRestriction = value == "true" and tenancyHasRecordedGrass(tenancy) ~= false
    elseif key == "boundaryRemovalRequiresConsent" then
        tenancy.boundaryRemovalRequiresConsent = value == "true"
    elseif key == "improvementsRequireConsent" then
        tenancy.improvementsRequireConsent = value == "true"
    elseif key == "tenantMaintenanceObligation" then
        tenancy.tenantMaintenanceObligation = value == "true"
    else
        return false
    end
    return true
end

function RFF_PropertyFinanceService:processLandlordVariationNotices(tenancy, currentPeriod)
    if tenancy == nil then return false end
    self:ensureTenancyConsentState(tenancy)
    local changed = false
    for _, request in ipairs(tenancy.consentRequests or {}) do
        if request.initiator == "LANDLORD" and TENANCY_LANDLORD_NOTICE_PENDING[request.status or ""]
            and safeNumber(request.effectivePeriod) > 0 and currentPeriod >= safeNumber(request.effectivePeriod) then
            if self:applyLandlordVariation(tenancy, request) then
                request.status = "IMPOSED"
                request.decisionDay = self:getCurrentDay()
                request.nextActionDay = 0
                request.feePayer = "LANDLORD"
                request.feePaid = math.max(0, safeNumber(request.professionalFee))
                request.feeOutstanding = 0
                local targetLabel = self:getTenancyConsentTargetLabel(request.requestType, request.target)
                local template = g_i18n ~= nil and g_i18n:getText("rff_tenancy_landlord_variation_effective_terms")
                    or "The notified change is now effective: %s."
                request.conditions = string.format(template, targetLabel)
                request.decisionReason = request.conditions
                local event = self:createTenancyNarrative(tenancy, "LANDLORD_VARIATION_EFFECTIVE", {
                    token=string.format("consent:%d:%d:EFFECTIVE", safeNumber(tenancy.id), safeNumber(request.id)),
                    reference=request.reference, documentStatus="IMPOSED", outcome="EFFECTIVE",
                    consentType=self:getTenancyConsentTypeLabel(request.requestType),
                    consentTarget=targetLabel,
                    consentConditions=request.conditions,
                    professionalFeeText=self:getTenancyVariationFeeText(tenancy, request),
                    variationNoticeMonths=tenancy.landlordVariationNoticeMonths,
                    variationEffectivePeriod=request.effectivePeriod,
                    variationCooldownMonths=tenancy.landlordVariationCooldownMonths,
                    variationCooldownUntilPeriod=request.cooldownUntilPeriod
                })
                self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_landlord_variation_effective", "Landlord Variation Effective", false)
                print(string.format("[RealisticFarmFinance] Landlord variation effective agreement=%s reference=%s effectivePeriod=%d cooldownUntil=%d fee=%.2f payer=LANDLORD",
                    tostring(tenancy.agreementId or tenancy.id), tostring(request.reference or "-"),
                    request.effectivePeriod or 0, request.cooldownUntilPeriod or 0, request.professionalFee or 0))
                changed = true
            end
        end
    end
    return changed
end

function RFF_PropertyFinanceService:respondToLandlordVariation(tenancy, accepted)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return false, "server_only" end
    local request = self:getPendingTenancyConsentRequest(tenancy)
    if request == nil or request.status ~= "TENANT_DECISION" or request.initiator ~= "LANDLORD" then return false, "no_proposal" end
    local currentDay = self:getCurrentDay()
    local targetLabel = self:getTenancyConsentTargetLabel(request.requestType, request.target)
    request.decisionDay = currentDay
    request.nextActionDay = 0
    if accepted == true then
        if not self:applyLandlordVariation(tenancy, request) then return false, "invalid_change" end
        request.status = "ACCEPTED"
        request.expiresPeriod = math.floor(safeNumber(tenancy.contractualEndPeriod))
        request.feePayer = "LANDLORD"
        request.feePaid = math.max(0, safeNumber(request.professionalFee))
        request.feeOutstanding = 0
        local template = g_i18n ~= nil and g_i18n:getText("rff_tenancy_landlord_variation_accepted_terms") or "Accepted change: %s."
        request.conditions = string.format(template, targetLabel)
        request.decisionReason = request.conditions
        self:adjustTenancyLandlordRelationship(tenancy, 0.25, "LANDLORD_VARIATION_ACCEPTED")
    else
        request.status = "DECLINED_BY_TENANT"
        request.expiresPeriod = 0
        request.feePaid = 0
        request.feeOutstanding = 0
        request.conditions = g_i18n ~= nil and g_i18n:getText("rff_tenancy_landlord_variation_declined_terms") or "The current agreement remains unchanged."
        request.decisionReason = request.conditions
    end
    local eventType = accepted == true and "LANDLORD_VARIATION_ACCEPTED" or "LANDLORD_VARIATION_DECLINED"
    local event = self:createTenancyNarrative(tenancy, eventType, {
        token=string.format("consent:%d:%d:%s", safeNumber(tenancy.id), safeNumber(request.id), accepted == true and "ACCEPTED" or "DECLINED"),
        reference=request.reference, documentStatus=request.status, outcome=request.status,
        consentType=self:getTenancyConsentTypeLabel(request.requestType),
        consentTarget=targetLabel,
        consentConditions=request.conditions,
        professionalFeeText=self:getTenancyVariationFeeText(tenancy, request)
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_landlord_variation_decision", "Tenancy Variation Decision", false)
    print(string.format("[RealisticFarmFinance] Landlord variation decision agreement=%s reference=%s accepted=%s fee=%.2f payer=LANDLORD",
        tostring(tenancy.agreementId or tenancy.id), request.reference, tostring(accepted == true), request.professionalFee or 0))
    return true, nil, request
end

function RFF_PropertyFinanceService:extendTenancyNegotiationDeadline(tenancy)
    if tenancy == nil or self.repository == nil then return end
    local currentPeriod = self.repository:getCurrentPeriodIndex()
    local latestResponse = math.max(currentPeriod, math.floor(safeNumber(tenancy.contractualEndPeriod)) - 1)
    local protectedResponse = math.min(latestResponse, currentPeriod + 2)
    tenancy.renewalOfferExpiryPeriod = math.max(safeNumber(tenancy.renewalOfferExpiryPeriod), protectedResponse)
end

function RFF_PropertyFinanceService:createTenancyAgreement(farmId, farmlandIds, terms)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return nil, "server_only" end
    terms = terms or {}
    farmlandIds = farmlandIds or {}
    if #farmlandIds == 0 then return nil, "invalid_land" end
    local totalPrice = 0
    for _, farmlandId in ipairs(farmlandIds) do
        local farmland = self:getFarmland(farmlandId)
        if farmland == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID
            or not self:isFarmlandAvailableForAcquisition(farmlandId)
            or self.repository:getTenancyByFarmland(farmlandId, true) ~= nil then return nil, "unavailable" end
        totalPrice = totalPrice + math.max(0, safeNumber(farmland.price))
    end
    local termMonths = math.max(1, math.floor(safeNumber(terms.termMonths or 60)))
    local landlord = self:getLandlordProfile(terms.landlord, farmlandIds[1])
    local annualRent = math.max(0, safeNumber(terms.annualRent or (totalPrice * self:getTenancyAnnualRate(termMonths) * landlord.initialRentFactor)))
    local frequency = TENANCY_PAYMENT_INTERVALS[terms.paymentFrequency] ~= nil and terms.paymentFrequency or "MONTHLY"
    local interval = TENANCY_PAYMENT_INTERVALS[frequency]
    local instalment = annualRent * interval / 12
    local deposit = math.max(0, safeNumber(terms.deposit or instalment * 2))
    if farmMoney(farmId) < deposit + instalment then return nil, "funds" end

    if self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(farmId, "Tenancy security deposit - " .. (terms.holdingName or "Agricultural holding")) end
    g_currentMission:addMoney(-deposit, farmId, moneyTypeFallback(), true, true)
    if self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(farmId, "Tenancy rent - " .. (terms.holdingName or "Agricultural holding")) end
    g_currentMission:addMoney(-instalment, farmId, moneyTypeFallback(), true, true)
    if g_messageCenter ~= nil then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, farmId) end

    local current = self.repository:getCurrentPeriodIndex()
    local id = self.repository:getNextTenancyId()
    local reviewInterval = terms.rentReviewIntervalMonths
    if reviewInterval == nil then reviewInterval = termMonths >= 48 and 36 or 0 end
    local tenancy = {
        id=id, agreementId=string.format("RFF-T-%06d", id), farmId=farmId, farmlandId=farmlandIds[1], farmlandIds=farmlandIds,
        landlord=landlord.id, holdingName=terms.holdingName or string.format("Agricultural Holding %d", id), purchasePrice=totalPrice,
        securityDeposit=deposit, depositOriginal=deposit, depositHeld=deposit, annualRent=annualRent, monthlyRent=annualRent/12,
        paymentFrequency=frequency, paymentIntervalMonths=interval, termMonths=termMonths, remainingMonths=termMonths,
        createdPeriod=current, commencementPeriod=current, contractualEndPeriod=current+termMonths, nextRentDuePeriod=current+interval, lastPaymentPeriod=current,
        paymentsMade=1, missedPayments=0, rentCharged=instalment, rentPaid=instalment, rentDue=0, arrears=0,
        status="ACTIVE", depositForfeited=false, rentReviewIntervalMonths=math.max(0, math.floor(safeNumber(reviewInterval))),
        nextRentReviewPeriod=0, breakEnabled=terms.breakEnabled == true, earliestBreakPeriod=math.max(0, math.floor(safeNumber(terms.earliestBreakPeriod))),
        breakNoticeMonths=math.max(0, math.floor(safeNumber(terms.breakNoticeMonths))), permittedEnterprise=terms.permittedEnterprise or "MIXED",
        agriculturalUsePermitted=terms.agriculturalUsePermitted ~= false, permanentGrassRestriction=terms.permanentGrassRestriction == true,
        boundaryRemovalRequiresConsent=terms.boundaryRemovalRequiresConsent ~= false, improvementsRequireConsent=terms.improvementsRequireConsent ~= false,
        tenantMaintenanceObligation=terms.tenantMaintenanceObligation ~= false,
        landlordVariationNoticeMonths=3, landlordVariationCooldownMonths=12,
        settlementCompleted=false, settlementDepositApplied=0,
        settlementDepositReturned=0, settlementFinalBalance=0, settlementDilapidationCosts=0,
        settlementDilapidationCostsApplied=0, expiryWarning12Sent=false, expiryWarning3Sent=false,
        forfeitureProcessed=false, forfeiturePeriod=0, forfeitedPlaceableCount=0, forfeitedPlaceableValue=0,
        expiryWarning1Sent=false, expiryNotificationSent=false, lastArrearsNotificationPeriod=0,
        renewalOfferStatus="NONE", renewalOfferCreatedPeriod=0, renewalOfferExpiryPeriod=0, renewalOfferAnnualRent=0,
        renewalOfferTermMonths=0, renewalOfferPaymentFrequency="", successorAgreementId=0, predecessorAgreementId=0,
        noticeServedPeriod=0, noticeEffectivePeriod=0, noticeReason="", breakExercisedPeriod=0,
        lastRentReviewPeriod=0, previousAnnualRent=0, settlementDepositTransferred=0, commencementNotificationSent=true,
        renewalOriginalAnnualRent=0, renewalNegotiationStatus="NOT_STARTED", renewalNegotiationPeriod=0,
        renewalNegotiationAttempts=0, renewalNegotiatedAnnualRent=0, renewalNegotiationNextDay=0,
        renewalNegotiationLastUpdateDay=0, renewalTenantProposalRent=0, renewalLandlordCounterRent=0,
        renewalLegalReference="", renewalDocumentStatus="NONE", landlordRelationshipPoints=0.25*interval,
        landlordRelationshipInitialized=true, landlordRelationshipLastReason="TENANCY_COMMENCED", landlordNegotiationRejections=0,
        consentNextId=1, consentLatestId=0, covenantComplianceStatus="COMPLIANT", consentRequests={},
        landlordVariationCount=0, lastLandlordVariationPeriod=0, nextLandlordVariationPeriod=0,
        conditionSurveyVersion=0, conditionSurveyPeriod=0, conditionLastObservedPeriod=0, parcelConditions={},
        alterationNextId=1, alterationLatestId=0, alterations={},
        breachCaseSchemaVersion=TENANCY_BREACH_CASE_SCHEMA_VERSION, breachCaseNextId=1,
        breachCaseLatestId=0, breachCases={},
        handbackSchemaVersion=TENANCY_HANDBACK_SCHEMA_VERSION, handbackStatus="NONE", handbackReference="",
        handbackInspectionPeriod=0, handbackRemedyDeadlinePeriod=0, handbackFinalInspectionPeriod=0,
        handbackReviewCount=0, handbackItemCount=0, handbackUnresolvedCount=0,
        handbackEstimatedCost=0, handbackProfessionalFee=0, handbackFinalCost=0,
        handbackLatestSummary="", handbackItems={}
    }
    if tenancy.rentReviewIntervalMonths > 0 then tenancy.nextRentReviewPeriod = current + tenancy.rentReviewIntervalMonths end
    self.repository:addTenancy(tenancy)
    self:ensureTenancyConditionSurvey(tenancy, false)
    self:ensureTenancyInspectionState(tenancy)
    self:createTenancyNarrative(tenancy, "TENANCY_STARTED", {
        token=string.format("tenancyStarted:%d", safeNumber(tenancy.id)),
        period=current, landlordRent=annualRent, termMonths=termMonths,
        memoryCode="NEW", relationshipCode="PROFESSIONAL", relationshipPoints=0,
        documentStatus="EXECUTED_TENANCY", outcome="COMMENCED"
    })
    if RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService.grantTenancyFixturePossession ~= nil then
        RFF_TenancyAccessService:grantTenancyFixturePossession(tenancy)
    end
    print(string.format("[RealisticFarmFinance] Tenancy agreement created id=%s farm=%d parcels=%d landlord=%s annualRent=%.2f frequency=%s term=%d deposit=%.2f", tenancy.agreementId, farmId or 0, #farmlandIds, landlord.id, annualRent, frequency, termMonths, deposit))
    return tenancy, {price=totalPrice, termMonths=termMonths, annualRent=annualRent, monthlyRent=annualRent/12, securityDeposit=deposit, cashRequired=deposit+instalment}
end

function RFF_PropertyFinanceService:createTenancy(farmId, farmlandId, termMonths)
    return self:createTenancyAgreement(farmId, {farmlandId}, {termMonths=termMonths, paymentFrequency="MONTHLY", holdingName=string.format("Land %d", farmlandId)})
end

function RFF_PropertyFinanceService:releaseTenancy(tenancy, returnDeposit, status)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then return false end
    local finalStatus = status or "ENDED"
    self:performTenancyHandbackInspection(tenancy, "FINAL")
    -- Landlord fixtures only borrowed GIANTS' owner field to make their normal
    -- interactions available during possession. Restore those first so the
    -- forfeiture pass below considers only genuine tenant-owned improvements.
    if RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService.restoreTenancyFixturePossession ~= nil then
        RFF_TenancyAccessService:restoreTenancyFixturePossession(tenancy)
    end
    -- Any substantial tenant asset deliberately left after the final possession
    -- inspection is abandoned to the holding. The player had the notice/remedy
    -- period in which to remove it, and it now follows the farmland on resale.
    self:forfeitTenantPlaceables(tenancy, "HAND_BACK")
    local deposit = math.max(0, safeNumber(tenancy.depositHeld or tenancy.securityDeposit))
    local arrears = math.max(0, safeNumber(tenancy.arrears or tenancy.rentDue))
    local covenantCosts = self:getTenancyBreachCostsOutstanding(tenancy)
    local dilapidationCosts = math.max(0, safeNumber(tenancy.handbackFinalCost))
    local applied = returnDeposit and math.min(deposit, arrears + covenantCosts + dilapidationCosts) or deposit
    local refund = returnDeposit and math.max(0, deposit - applied) or 0
    if refund > 0 then
        if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(tenancy.farmId, "Tenancy end deposit settlement - " .. (tenancy.holdingName or "Agricultural holding")) end
        g_currentMission:addMoney(refund, tenancy.farmId, moneyTypeFallback(), true, true)
    end
    tenancy.depositForfeited = not returnDeposit
    tenancy.depositHeld = 0
    local rentApplied = math.min(arrears, applied)
    local covenantApplied = math.min(covenantCosts, math.max(0, applied - rentApplied))
    local dilapidationApplied = math.min(dilapidationCosts, math.max(0, applied - rentApplied - covenantApplied))
    tenancy.arrears = math.max(0, arrears - rentApplied)
    tenancy.rentDue = tenancy.arrears
    local covenantRemaining = covenantApplied
    for _, breachCase in ipairs(tenancy.breachCases or {}) do
        local caseApplied = math.min(math.max(0, safeNumber(breachCase.feeOutstanding)), covenantRemaining)
        if caseApplied > 0 then
            breachCase.feeOutstanding = math.max(0, safeNumber(breachCase.feeOutstanding) - caseApplied)
            breachCase.feePaid = math.max(0, safeNumber(breachCase.feePaid)) + caseApplied
            covenantRemaining = covenantRemaining - caseApplied
        end
    end
    tenancy.settlementDepositApplied = applied
    tenancy.settlementDepositReturned = refund
    tenancy.settlementCovenantCosts = covenantCosts
    tenancy.settlementCovenantCostsApplied = covenantApplied - covenantRemaining
    tenancy.settlementDilapidationCosts = dilapidationCosts
    tenancy.settlementDilapidationCostsApplied = dilapidationApplied
    tenancy.settlementFinalBalance = tenancy.arrears + self:getTenancyBreachCostsOutstanding(tenancy)
        + math.max(0, dilapidationCosts - dilapidationApplied)
    tenancy.settlementCompleted = true
    tenancy.remainingMonths = 0
    tenancy.status = finalStatus
    if safeNumber(tenancy.successorAgreementId) > 0 and tenancy.status ~= "ENDED_RENEWED" and self.repository ~= nil then
        local successor = self.repository:getTenancyById(tenancy.farmId, tenancy.successorAgreementId)
        if successor ~= nil and successor.status == "FUTURE" then successor.status = "CANCELLED" end
        if tenancy.renewalOfferStatus == "ACCEPTED" then tenancy.renewalOfferStatus = "CANCELLED" end
    end
    self:processTenancyVariationFeeArrears(tenancy)
    if g_messageCenter ~= nil then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, tenancy.farmId) end
    if finalStatus == "ENDED" then self:notifyTenancyHandbackSettlement(tenancy) end
    return true
end

function RFF_PropertyFinanceService:terminateTenancy(tenancy)
    return self:releaseTenancy(tenancy, true, "ENDED")
end

function RFF_PropertyFinanceService:getTenancyRenewalToken(tenancy)
    return string.format("tenancyRenewal:%d:%d", tenancy ~= nil and tenancy.id or 0, tenancy ~= nil and tenancy.renewalOfferCreatedPeriod or 0)
end

function RFF_PropertyFinanceService:serveTenancyNotice(tenancy, reason, effectivePeriod, messageOverride)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then return false, "inactive" end
    if tenancy.noticeReason ~= nil and tenancy.noticeReason ~= "" then return false, "notice_already_served" end
    local current = self.repository:getCurrentPeriodIndex()
    local contractualEnd = math.max(current + 1, math.floor(safeNumber(tenancy.contractualEndPeriod)))
    tenancy.noticeServedPeriod = current
    tenancy.noticeEffectivePeriod = math.min(contractualEnd, math.max(current + 1, math.floor(safeNumber(effectivePeriod or contractualEnd))))
    tenancy.noticeReason = reason or "LANDLORD_NOTICE"
    tenancy.contractualEndPeriod = tenancy.noticeEffectivePeriod
    tenancy.remainingMonths = math.max(0, tenancy.contractualEndPeriod - current)
    tenancy.status = "NOTICE_SERVED"
    if messageOverride ~= nil and messageOverride ~= "" and RFF_NotificationService ~= nil then
        local sender = self:getLandlordName(tenancy.landlord, tenancy.farmlandId)
        local title = RFF_NotificationService:getText("rff_phone_title_tenancy_notice", "Tenancy Notice")
        RFF_NotificationService:send(tenancy.farmId, sender, title, messageOverride, "tenancy", messageOverride, true)
    else
        self:notifyTenancy(tenancy, "rff_phone_title_tenancy_notice", "Tenancy Notice", "rff_phone_tenancy_notice",
            "%s: notice has been served and the tenancy will end in %d month(s). Agricultural access continues until that date.", true,
            tenancy.holdingName or tenancy.agreementId or "The tenancy", tenancy.remainingMonths)
    end
    return true
end

function RFF_PropertyFinanceService:createTenancyRenewalOffer(tenancy)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then return false, "inactive" end
    if tenancy.renewalOfferStatus ~= nil and tenancy.renewalOfferStatus ~= "NONE" then return false, "already_offered" end
    if safeNumber(tenancy.arrears or tenancy.rentDue) > 0.001 then
        tenancy.renewalOfferStatus = "NOT_OFFERED_ARREARS"
        return self:serveTenancyNotice(tenancy, "ARREARS_NON_RENEWAL", tenancy.contractualEndPeriod)
    end
    local current = self.repository:getCurrentPeriodIndex()
    tenancy.renewalOfferStatus = "OFFERED"
    tenancy.renewalOfferCreatedPeriod = current
    tenancy.renewalOfferExpiryPeriod = math.min(math.max(current, tenancy.contractualEndPeriod - 1), current + TENANCY_RENEWAL_RESPONSE_MONTHS)
    local landlord = self:getLandlordProfile(tenancy.landlord, tenancy.farmlandId)
    tenancy.renewalOfferAnnualRent = math.floor(math.max(0, safeNumber(tenancy.annualRent)) * landlord.renewalRentFactor + 0.5)
    tenancy.renewalOriginalAnnualRent = tenancy.renewalOfferAnnualRent
    tenancy.renewalOfferTermMonths = math.max(12, math.floor(safeNumber(tenancy.termMonths)))
    tenancy.renewalOfferPaymentFrequency = tenancy.paymentFrequency or "MONTHLY"
    tenancy.renewalNegotiationStatus = "NOT_STARTED"
    tenancy.renewalNegotiationPeriod = 0
    tenancy.renewalNegotiationAttempts = 0
    tenancy.renewalNegotiatedAnnualRent = 0
    tenancy.renewalNegotiationNextDay = 0
    tenancy.renewalNegotiationLastUpdateDay = 0
    tenancy.renewalTenantProposalRent = 0
    tenancy.renewalLandlordCounterRent = 0
    tenancy.renewalLegalReference = ""
    tenancy.renewalDocumentStatus = "NONE"
    tenancy.renewalCovenantPackageVersion = 0
    self:ensureTenancyRenewalCovenants(tenancy)
    tenancy.status = "RENEWAL_OFFERED"

    local offerTerms = self:getTenancyRenewalTerms(tenancy, "renewalOffer")
    local event = self:createTenancyNarrative(tenancy, "RENEWAL_OFFER", {
        token=string.format("renewalOffer:%d:%d", safeNumber(tenancy.id), current),
        outcome="OFFERED", documentStatus="RENEWAL_OFFER",
        landlordRent=tenancy.renewalOfferAnnualRent, termMonths=tenancy.renewalOfferTermMonths,
        paymentFrequency=tenancy.renewalOfferPaymentFrequency,
        replyMonths=math.max(0, tenancy.renewalOfferExpiryPeriod - current),
        packageSummary=self:getTenancyRenewalPackageSummary(offerTerms),
        landlordPackage=self:encodeTenancyRenewalTerms(offerTerms)
    })
    local sender = self:getLandlordName(tenancy.landlord, tenancy.farmlandId)
    local title = RFF_NotificationService ~= nil and RFF_NotificationService:getText("rff_phone_title_tenancy_renewal", "Tenancy Renewal Offer") or "Tenancy Renewal Offer"
    local message = event ~= nil and event.text or (RFF_NotificationService ~= nil and RFF_NotificationService:formatText("rff_phone_tenancy_renewal_offer",
        "%s: renewal offered for %d months at %s per year, payable %s. Respond within %d month(s).",
        tenancy.holdingName or tenancy.agreementId or "The tenancy", tenancy.renewalOfferTermMonths,
        g_i18n:formatMoney(tenancy.renewalOfferAnnualRent, 0, true, true), tostring(tenancy.renewalOfferPaymentFrequency):gsub("_", " "),
        math.max(0, tenancy.renewalOfferExpiryPeriod - current)) or "Tenancy renewal offer available.")
    local sent = RFF_NotificationService ~= nil and RFF_NotificationService:pushPhoneTenancyRenewalActionable(
        tenancy.farmId, sender, title, message, self:getTenancyRenewalToken(tenancy), self)
    if not sent and RFF_NotificationService ~= nil then
        RFF_NotificationService:send(tenancy.farmId, sender, title, message, "tenancy",
            self:getTenancyCorrespondenceHudText(), false)
    end
    print(string.format("[RealisticFarmFinance] Tenancy renewal offered agreement=%s annualRent=%.2f term=%d expiresPeriod=%d",
        tostring(tenancy.agreementId or tenancy.id), tenancy.renewalOfferAnnualRent, tenancy.renewalOfferTermMonths, tenancy.renewalOfferExpiryPeriod))
    return true
end

function RFF_PropertyFinanceService:negotiateTenancyRenewal(tenancy, requestedRent, proposedTerms)
    if tenancy == nil or tenancy.renewalOfferStatus ~= "OFFERED" then return false, "no_offer" end
    local currentPeriod = self.repository:getCurrentPeriodIndex()
    if currentPeriod > safeNumber(tenancy.renewalOfferExpiryPeriod) then return false, "expired" end
    local status = tenancy.renewalNegotiationStatus or "NOT_STARTED"
    local isInitial = status == "NOT_STARTED" or status == ""
    local isRevision = status == "COUNTER_OFFER" or status == "COUNTERED" or status == "DECLINED" or status == "IMMEDIATE_REJECTED"
    if not isInitial and not isRevision then return false, "negotiation_pending" end
    requestedRent = math.floor(math.max(0, safeNumber(requestedRent)) + 0.5)
    if requestedRent <= 0 then return false, "invalid_amount" end
    self:ensureTenancyRenewalCovenants(tenancy)
    local tenantTerms = self:normaliseTenancyRenewalTerms(tenancy,
        proposedTerms or self:getTenancyRenewalTerms(tenancy, "renewalOffer"))
    local assessment = self:getTenancyNegotiationAssessment(tenancy, requestedRent, tenantTerms)
    if assessment == nil then return false, "unavailable" end
    if requestedRent > math.max(1000000, assessment.originalRent * 5) then return false, "invalid_amount" end
    if safeNumber(tenancy.renewalNegotiationAttempts) >= assessment.maxRounds then return false, "final_terms" end

    tenancy.renewalNegotiationAttempts = safeNumber(tenancy.renewalNegotiationAttempts) + 1
    if isInitial then tenancy.renewalNegotiationPeriod = currentPeriod end

    local currentDay = self:getCurrentDay()
    tenancy.renewalTenantProposalRent = requestedRent
    self:setTenancyRenewalTerms(tenancy, "renewalTenant", tenantTerms)
    tenancy.renewalNegotiationLastUpdateDay = currentDay
    if tenancy.renewalLegalReference == nil or tenancy.renewalLegalReference == "" then
        tenancy.renewalLegalReference = string.format("RFF-HT-%06d-%d", safeNumber(tenancy.id), currentDay)
    end
    if assessment.outcome == "IMMEDIATE_REJECT" then
        tenancy.renewalNegotiationNextDay = 0
        tenancy.landlordNegotiationRejections = safeNumber(tenancy.landlordNegotiationRejections) + 1
        local isFinal = tenancy.renewalNegotiationAttempts >= assessment.maxRounds
        tenancy.renewalNegotiationStatus = isFinal and "FINAL_COUNTER" or "IMMEDIATE_REJECTED"
        tenancy.renewalDocumentStatus = isFinal and "FINAL_LANDLORD_TERMS" or "PROPOSAL_REJECTED"
        local relationshipPenalty = requestedRent < assessment.considerationFloor * 0.85 and -0.75 or -0.25
        self:adjustTenancyLandlordRelationship(tenancy, relationshipPenalty, "UNACCEPTABLE_RENT_PROPOSAL")
        local eventType = isFinal and "FINAL_REJECTED" or "IMMEDIATE_REJECTED"
        local event = self:createTenancyNarrative(tenancy, eventType, {
            token=string.format("negotiation:%d:%s:%d:%s", safeNumber(tenancy.id), tenancy.renewalLegalReference or "-",
                safeNumber(tenancy.renewalNegotiationAttempts), eventType),
            outcome=isFinal and "FINAL_REJECT" or "IMMEDIATE_REJECT",
            tenantRent=requestedRent, landlordRent=tenancy.renewalOfferAnnualRent or assessment.originalRent,
            documentStatus=tenancy.renewalDocumentStatus,
            packageSummary=self:getTenancyRenewalPackageSummary(tenantTerms),
            tenantPackage=self:encodeTenancyRenewalTerms(tenantTerms)
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_immediate_response", "Landlord Response", false)
        print(string.format("[RealisticFarmFinance] Tenancy proposal immediately rejected agreement=%s round=%d proposal=%.2f considerationFloor=%.2f acceptableRent=%.2f final=%s relationship=%.2f reference=%s",
            tostring(tenancy.agreementId or tenancy.id), tenancy.renewalNegotiationAttempts or 0, requestedRent,
            assessment.considerationFloor, assessment.acceptableRent, tostring(isFinal),
            safeNumber(tenancy.landlordRelationshipPoints), tenancy.renewalLegalReference))
        return true, isFinal and "FINAL_COUNTER" or "IMMEDIATE_REJECTED", requestedRent
    end

    tenancy.renewalNegotiationStatus = "LANDLORD_REVIEW"
    tenancy.renewalNegotiationNextDay = currentDay + 1
    tenancy.renewalDocumentStatus = isInitial and "PROPOSAL_RECEIVED" or "REVISED_PROPOSAL_RECEIVED"
    self:extendTenancyNegotiationDeadline(tenancy)
    local eventType = isInitial and "PROPOSAL_RECEIVED" or "REVISED_PROPOSAL_RECEIVED"
    local event = self:createTenancyNarrative(tenancy, eventType, {
        token=string.format("negotiation:%d:%s:%d:%s", safeNumber(tenancy.id), tenancy.renewalLegalReference or "-",
            safeNumber(tenancy.renewalNegotiationAttempts), eventType),
        outcome="REVIEW", tenantRent=requestedRent, documentStatus=tenancy.renewalDocumentStatus,
        packageSummary=self:getTenancyRenewalPackageSummary(tenantTerms),
        tenantPackage=self:encodeTenancyRenewalTerms(tenantTerms)
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_negotiation", "Renewal Negotiation", false)
    print(string.format("[RealisticFarmFinance] Tenancy negotiation submitted agreement=%s round=%d proposal=%.2f nextDay=%d reference=%s",
        tostring(tenancy.agreementId or tenancy.id), tenancy.renewalNegotiationAttempts or 0, requestedRent,
        tenancy.renewalNegotiationNextDay or 0, tenancy.renewalLegalReference))
    return true, "SUBMITTED", requestedRent
end

function RFF_PropertyFinanceService:processTenancyNegotiationDay(tenancy, currentDay)
    if tenancy == nil or tenancy.renewalOfferStatus ~= "OFFERED" then return false end
    if currentDay < safeNumber(tenancy.renewalNegotiationNextDay) then return false end
    local status = tenancy.renewalNegotiationStatus or "NOT_STARTED"
    if status == "LANDLORD_REVIEW" then
        tenancy.renewalNegotiationStatus = "SOLICITOR_REVIEW"
        tenancy.renewalNegotiationNextDay = currentDay + 1
        tenancy.renewalNegotiationLastUpdateDay = currentDay
        tenancy.renewalDocumentStatus = "WITH_LEGAL_ADVISER"
        self:extendTenancyNegotiationDeadline(tenancy)
        local tenantTerms = self:getTenancyRenewalTerms(tenancy, "renewalTenant")
        local event = self:createTenancyNarrative(tenancy, "LEGAL_REVIEW", {
            token=string.format("negotiation:%d:%s:%d:LEGAL_REVIEW", safeNumber(tenancy.id), tenancy.renewalLegalReference or "-",
                safeNumber(tenancy.renewalNegotiationAttempts)),
            outcome="LEGAL_REVIEW", day=currentDay, documentStatus=tenancy.renewalDocumentStatus,
            packageSummary=self:getTenancyRenewalPackageSummary(tenantTerms),
            tenantPackage=self:encodeTenancyRenewalTerms(tenantTerms)
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_legal_review", "Tenancy Documents", false)
        print(string.format("[RealisticFarmFinance] Tenancy negotiation legal review agreement=%s nextDay=%d reference=%s",
            tostring(tenancy.agreementId or tenancy.id), tenancy.renewalNegotiationNextDay or 0, tenancy.renewalLegalReference or ""))
        return true
    end

    if status ~= "SOLICITOR_REVIEW" then return false end
    local tenantProposal = math.max(0, safeNumber(tenancy.renewalTenantProposalRent))
    local tenantTerms = self:getTenancyRenewalTerms(tenancy, "renewalTenant")
    local assessment = self:getTenancyNegotiationAssessment(tenancy, tenantProposal, tenantTerms)
    if assessment == nil then return false end
    local originalRent = assessment.originalRent
    local minimumRent = assessment.acceptableRent
    tenancy.renewalNegotiationNextDay = 0
    tenancy.renewalNegotiationLastUpdateDay = currentDay

    if tenantProposal >= minimumRent then
        tenancy.renewalOfferAnnualRent = tenantProposal
        tenancy.renewalNegotiatedAnnualRent = tenantProposal
        self:setTenancyRenewalTerms(tenancy, "renewalOffer", tenantTerms)
        tenancy.renewalNegotiationStatus = "TERMS_AGREED"
        tenancy.renewalDocumentStatus = "AGREED_HEADS_OF_TERMS"
        local event = self:createTenancyNarrative(tenancy, "TERMS_AGREED", {
            token=string.format("negotiation:%d:%s:%d:TERMS_AGREED", safeNumber(tenancy.id), tenancy.renewalLegalReference or "-",
                safeNumber(tenancy.renewalNegotiationAttempts)),
            outcome="AGREED", agreedRent=tenantProposal, landlordRent=tenantProposal,
            day=currentDay, documentStatus=tenancy.renewalDocumentStatus,
            packageSummary=self:getTenancyRenewalPackageSummary(tenantTerms),
            tenantPackage=self:encodeTenancyRenewalTerms(tenantTerms),
            landlordPackage=self:encodeTenancyRenewalTerms(tenantTerms)
        })
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_heads_agreed", "Heads of Terms Agreed", false)
        print(string.format("[RealisticFarmFinance] Tenancy negotiation terms agreed agreement=%s round=%d rent=%.2f reference=%s",
            tostring(tenancy.agreementId or tenancy.id), tenancy.renewalNegotiationAttempts or 0, tenantProposal, tenancy.renewalLegalReference or ""))
        return true
    end

    local counterTerms, packageResponse = self:buildTenancyLandlordCounterTerms(tenancy, assessment.covenantPackage)
    self:setTenancyRenewalTerms(tenancy, "renewalOffer", counterTerms)
    local counterAssessment = self:getTenancyNegotiationAssessment(tenancy, tenantProposal, counterTerms)
    local counterMinimum = counterAssessment.acceptableRent
    local priorCounter = math.max(counterMinimum, safeNumber(tenancy.renewalLandlordCounterRent))
    if priorCounter <= counterMinimum then priorCounter = originalRent end
    local counterRent = math.floor((priorCounter + counterMinimum) / 2 + 0.5)
    tenancy.renewalLandlordCounterRent = counterRent
    tenancy.renewalOfferAnnualRent = counterRent
    tenancy.renewalNegotiatedAnnualRent = counterRent
    local isFinal = safeNumber(tenancy.renewalNegotiationAttempts) >= assessment.maxRounds
    tenancy.renewalNegotiationStatus = isFinal and "FINAL_COUNTER" or "COUNTER_OFFER"
    tenancy.renewalDocumentStatus = isFinal and "FINAL_HEADS_OF_TERMS" or "REVISED_HEADS_OF_TERMS"
    local eventType = isFinal and "FINAL_COUNTER" or "COUNTER_OFFER"
    local event = self:createTenancyNarrative(tenancy, eventType, {
        token=string.format("negotiation:%d:%s:%d:%s", safeNumber(tenancy.id), tenancy.renewalLegalReference or "-",
            safeNumber(tenancy.renewalNegotiationAttempts), eventType),
        outcome=eventType, tenantRent=tenantProposal, counterRent=counterRent, landlordRent=counterRent,
        day=currentDay, documentStatus=tenancy.renewalDocumentStatus,
        packageSummary=self:getTenancyRenewalPackageSummary(counterTerms), packageResponse=packageResponse,
        tenantPackage=self:encodeTenancyRenewalTerms(tenantTerms),
        landlordPackage=self:encodeTenancyRenewalTerms(counterTerms)
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_counter", "Revised Heads of Terms", false)
    print(string.format("[RealisticFarmFinance] Tenancy negotiation counter agreement=%s round=%d counter=%.2f minimum=%.2f covenantAdjustment=%.2f final=%s reference=%s",
        tostring(tenancy.agreementId or tenancy.id), tenancy.renewalNegotiationAttempts or 0, counterRent, counterMinimum,
        counterAssessment.packageAdjustment or 0,
        tostring(isFinal), tenancy.renewalLegalReference or ""))
    return true
end

function RFF_PropertyFinanceService:onDayChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local currentDay = self:getCurrentDay()
    for _, tenancy in ipairs(self.repository.tenancies or {}) do
        if TENANCY_APPLICATION_STATES[tenancy.status or ""] then self:processInitialTenancyApplicationDay(tenancy, currentDay) end
        if tenancy.renewalOfferStatus == "OFFERED" then self:processTenancyNegotiationDay(tenancy, currentDay) end
        if TENANCY_POSSESSION_STATES[tenancy.status or ""] then self:processTenancyConsentDay(tenancy, currentDay) end
    end
end

function RFF_PropertyFinanceService:acceptInitialTenancyApplication(tenancy)
    if tenancy == nil or not TENANCY_APPLICATION_STATES[tenancy.status or ""] or tenancy.renewalOfferStatus ~= "OFFERED" then
        return false, "no_offer"
    end
    local current = self.repository:getCurrentPeriodIndex()
    if current > safeNumber(tenancy.renewalOfferExpiryPeriod) then return false, "expired" end
    if tenancy.renewalNegotiationStatus == "LANDLORD_REVIEW" or tenancy.renewalNegotiationStatus == "SOLICITOR_REVIEW" then
        return false, "negotiation_pending"
    end
    for _, farmlandId in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
        local farmland = self:getFarmland(farmlandId)
        if farmland == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID
            or not self:isFarmlandAvailableForAcquisition(farmlandId)
            or self.repository:getTenancyByFarmland(farmlandId, true) ~= nil then return false, "unavailable" end
    end
    local costs = self:getInitialTenancyCompletionCosts(tenancy)
    if costs == nil or costs.annualRent <= 0 then return false, "invalid_terms" end
    if farmMoney(tenancy.farmId) < costs.total then return false, "funds" end

    if self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(tenancy.farmId, "Tenancy security deposit - " .. (tenancy.holdingName or "Agricultural holding"))
    end
    g_currentMission:addMoney(-costs.deposit, tenancy.farmId, moneyTypeFallback(), true, true)
    if self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(tenancy.farmId, "First tenancy rent - " .. (tenancy.holdingName or "Agricultural holding"))
    end
    g_currentMission:addMoney(-costs.instalment, tenancy.farmId, moneyTypeFallback(), true, true)
    if self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(tenancy.farmId, "Tenancy legal and administration costs - " .. (tenancy.holdingName or "Agricultural holding"))
    end
    g_currentMission:addMoney(-costs.legalFee, tenancy.farmId, moneyTypeFallback(), true, true)

    local terms = self:getTenancyRenewalTerms(tenancy, "renewalOffer")
    local termMonths = math.max(12, math.floor(safeNumber(tenancy.renewalOfferTermMonths)))
    local frequency = TENANCY_PAYMENT_INTERVALS[tenancy.renewalOfferPaymentFrequency] ~= nil
        and tenancy.renewalOfferPaymentFrequency or "MONTHLY"
    local interval = TENANCY_PAYMENT_INTERVALS[frequency]
    tenancy.agreementId = string.format("RFF-T-%06d", safeNumber(tenancy.id))
    tenancy.annualRent = costs.annualRent
    tenancy.monthlyRent = costs.annualRent / 12
    tenancy.securityDeposit = costs.deposit
    tenancy.depositOriginal = costs.deposit
    tenancy.depositHeld = costs.deposit
    tenancy.paymentFrequency = frequency
    tenancy.paymentIntervalMonths = interval
    tenancy.termMonths = termMonths
    tenancy.remainingMonths = termMonths
    tenancy.commencementPeriod = current
    tenancy.contractualEndPeriod = current + termMonths
    tenancy.nextRentDuePeriod = current + interval
    tenancy.lastPaymentPeriod = current
    tenancy.paymentsMade = 1
    tenancy.missedPayments = 0
    tenancy.rentCharged = costs.instalment
    tenancy.rentPaid = costs.instalment
    tenancy.rentDue = 0
    tenancy.arrears = 0
    tenancy.status = "ACTIVE"
    tenancy.depositForfeited = false
    tenancy.rentReviewIntervalMonths = terms.rentReviewIntervalMonths
    tenancy.nextRentReviewPeriod = terms.rentReviewIntervalMonths > 0 and current + terms.rentReviewIntervalMonths or 0
    tenancy.breakEnabled = terms.breakEnabled
    tenancy.breakNoticeMonths = terms.breakNoticeMonths
    tenancy.earliestBreakPeriod = terms.breakEnabled and current + math.max(1, math.floor(termMonths / 2)) or 0
    tenancy.permittedEnterprise = terms.permittedEnterprise
    tenancy.agriculturalUsePermitted = true
    tenancy.permanentGrassRestriction = terms.permanentGrassRestriction
    tenancy.boundaryRemovalRequiresConsent = terms.boundaryRemovalRequiresConsent
    tenancy.improvementsRequireConsent = terms.improvementsRequireConsent
    tenancy.tenantMaintenanceObligation = terms.tenantMaintenanceObligation
    tenancy.landlordVariationNoticeMonths = terms.landlordVariationNoticeMonths
    tenancy.landlordVariationCooldownMonths = terms.landlordVariationCooldownMonths
    tenancy.covenantComplianceStatus = "COMPLIANT"
    tenancy.applicationStage = "EXECUTED"
    tenancy.applicationNextActionDay = 0
    tenancy.applicationDecision = "ACCEPTED"
    tenancy.applicationDecisionReason = "the negotiated tenancy has been executed"
    tenancy.applicationUpfrontCashRequired = costs.total
    tenancy.renewalOfferStatus = "NONE"
    tenancy.renewalNegotiationStatus = "EXECUTED"
    tenancy.renewalNegotiationLastUpdateDay = self:getCurrentDay()
    tenancy.renewalDocumentStatus = "EXECUTED_TENANCY"
    tenancy.commencementNotificationSent = true
    self:adjustTenancyLandlordRelationship(tenancy, 0.25, "TENANCY_COMMENCED")
    self:ensureTenancyConditionSurvey(tenancy, false)
    self:ensureTenancyInspectionState(tenancy)
    if RFF_TenancyAccessService ~= nil and RFF_TenancyAccessService.grantTenancyFixturePossession ~= nil then
        RFF_TenancyAccessService:grantTenancyFixturePossession(tenancy)
    end

    local event = self:createTenancyNarrative(tenancy, "TENANCY_STARTED", {
        token=string.format("application:%d:EXECUTED", safeNumber(tenancy.id)), period=current,
        outcome="COMMENCED", documentStatus="EXECUTED_TENANCY", reference=tenancy.applicationReference,
        landlordRent=costs.annualRent, agreedRent=costs.annualRent, termMonths=termMonths,
        paymentFrequency=frequency, depositAmount=costs.deposit, legalFee=costs.legalFee,
        upfrontCosts=costs.total, packageSummary=self:getTenancyRenewalPackageSummary(terms),
        landlordPackage=self:encodeTenancyRenewalTerms(terms), memoryCode="NEW"
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_commenced", "Tenancy Commenced", false)
    if g_messageCenter ~= nil then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, tenancy.farmId) end
    print(string.format("[RealisticFarmFinance] Initial tenancy executed application=%s agreement=%s rent=%.2f deposit=%.2f legalFee=%.2f term=%d",
        tenancy.applicationReference or "-", tenancy.agreementId, costs.annualRent, costs.deposit, costs.legalFee, termMonths))
    return true, nil, tenancy
end

function RFF_PropertyFinanceService:acceptTenancyRenewal(tenancy)
    if tenancy == nil or tenancy.renewalOfferStatus ~= "OFFERED" then return false, "no_offer" end
    if TENANCY_APPLICATION_STATES[tenancy.status or ""] then return self:acceptInitialTenancyApplication(tenancy) end
    local current = self.repository:getCurrentPeriodIndex()
    if current > safeNumber(tenancy.renewalOfferExpiryPeriod) then return false, "expired" end
    if tenancy.renewalNegotiationStatus == "LANDLORD_REVIEW" or tenancy.renewalNegotiationStatus == "SOLICITOR_REVIEW" then return false, "negotiation_pending" end
    if safeNumber(tenancy.successorAgreementId) > 0 then return false, "already_accepted" end
    local interval = TENANCY_PAYMENT_INTERVALS[tenancy.renewalOfferPaymentFrequency] or math.max(1, math.floor(safeNumber(tenancy.paymentIntervalMonths or 1)))
    local startPeriod = math.max(current + 1, math.floor(safeNumber(tenancy.contractualEndPeriod)))
    local termMonths = math.max(12, math.floor(safeNumber(tenancy.renewalOfferTermMonths)))
    local annualRent = math.max(0, safeNumber(tenancy.renewalOfferAnnualRent))
    local renewalTerms = self:getTenancyRenewalTerms(tenancy, "renewalOffer")
    self:adjustTenancyLandlordRelationship(tenancy, 0.75, "RENEWAL_ACCEPTED")
    local id = self.repository:getNextTenancyId()
    local successor = {
        id=id, agreementId=string.format("RFF-T-%06d", id), farmId=tenancy.farmId, farmlandId=tenancy.farmlandId,
        farmlandIds=tenancy.farmlandIds, landlord=tenancy.landlord, holdingName=tenancy.holdingName, purchasePrice=tenancy.purchasePrice,
        securityDeposit=0, depositOriginal=0, depositHeld=0, annualRent=annualRent, monthlyRent=annualRent/12,
        paymentFrequency=tenancy.renewalOfferPaymentFrequency or tenancy.paymentFrequency or "MONTHLY", paymentIntervalMonths=interval,
        termMonths=termMonths, remainingMonths=termMonths, createdPeriod=current, commencementPeriod=startPeriod,
        contractualEndPeriod=startPeriod+termMonths, nextRentDuePeriod=startPeriod, lastPaymentPeriod=0,
        paymentsMade=0, missedPayments=0, rentCharged=0, rentPaid=0, rentDue=0, arrears=0, status="FUTURE",
        depositForfeited=false, rentReviewIntervalMonths=renewalTerms.rentReviewIntervalMonths,
        nextRentReviewPeriod=0, breakEnabled=renewalTerms.breakEnabled, earliestBreakPeriod=0,
        breakNoticeMonths=renewalTerms.breakNoticeMonths, permittedEnterprise=renewalTerms.permittedEnterprise,
        agriculturalUsePermitted=tenancy.agriculturalUsePermitted ~= false, permanentGrassRestriction=renewalTerms.permanentGrassRestriction,
        boundaryRemovalRequiresConsent=renewalTerms.boundaryRemovalRequiresConsent,
        improvementsRequireConsent=renewalTerms.improvementsRequireConsent,
        tenantMaintenanceObligation=renewalTerms.tenantMaintenanceObligation,
        landlordVariationNoticeMonths=renewalTerms.landlordVariationNoticeMonths,
        landlordVariationCooldownMonths=renewalTerms.landlordVariationCooldownMonths,
        settlementCompleted=false, settlementDepositApplied=0,
        settlementDepositReturned=0, settlementFinalBalance=0, settlementDepositTransferred=0,
        settlementDilapidationCosts=0, settlementDilapidationCostsApplied=0,
        forfeitureProcessed=false, forfeiturePeriod=0, forfeitedPlaceableCount=0, forfeitedPlaceableValue=0,
        expiryWarning12Sent=false, expiryWarning3Sent=false, expiryWarning1Sent=false, expiryNotificationSent=false,
        lastArrearsNotificationPeriod=0, renewalOfferStatus="NONE", renewalOfferCreatedPeriod=0, renewalOfferExpiryPeriod=0,
        renewalOfferAnnualRent=0, renewalOfferTermMonths=0, renewalOfferPaymentFrequency="", successorAgreementId=0,
        predecessorAgreementId=tenancy.id, noticeServedPeriod=0, noticeEffectivePeriod=0, noticeReason="",
        breakExercisedPeriod=0, lastRentReviewPeriod=0, previousAnnualRent=0, commencementNotificationSent=false,
        renewalOriginalAnnualRent=0, renewalNegotiationStatus="NOT_STARTED", renewalNegotiationPeriod=0,
        renewalNegotiationAttempts=0, renewalNegotiatedAnnualRent=0, renewalNegotiationNextDay=0,
        renewalNegotiationLastUpdateDay=0, renewalTenantProposalRent=0, renewalLandlordCounterRent=0,
        renewalLegalReference="", renewalDocumentStatus="NONE", renewalCovenantPackageVersion=0,
        landlordRelationshipPoints=safeNumber(tenancy.landlordRelationshipPoints),
        landlordRelationshipInitialized=true, landlordRelationshipLastReason="RENEWAL_ACCEPTED",
        landlordNegotiationRejections=0, consentNextId=1, consentLatestId=0,
        covenantComplianceStatus="COMPLIANT", consentRequests={}, landlordVariationCount=0,
        lastLandlordVariationPeriod=0, nextLandlordVariationPeriod=0,
        conditionSurveyVersion=0, conditionSurveyPeriod=0, conditionLastObservedPeriod=0, parcelConditions={},
        alterationNextId=1, alterationLatestId=0, alterations={},
        handbackSchemaVersion=TENANCY_HANDBACK_SCHEMA_VERSION, handbackStatus="NONE", handbackReference="",
        handbackInspectionPeriod=0, handbackRemedyDeadlinePeriod=0, handbackFinalInspectionPeriod=0,
        handbackReviewCount=0, handbackItemCount=0, handbackUnresolvedCount=0,
        handbackEstimatedCost=0, handbackProfessionalFee=0, handbackFinalCost=0,
        handbackLatestSummary="", handbackItems={}
    }
    if successor.rentReviewIntervalMonths > 0 then successor.nextRentReviewPeriod = startPeriod + successor.rentReviewIntervalMonths end
    if successor.breakEnabled then successor.earliestBreakPeriod = startPeriod + math.max(1, math.floor(termMonths / 2)) end
    if self.narrativeService ~= nil then
        self.narrativeService:ensureTenancyVoice(tenancy, tenancy.landlord, tenancy.farmlandId)
        self.narrativeService:inheritTenancyVoice(successor, tenancy)
    end
    self.repository:addTenancy(successor)
    tenancy.renewalOfferStatus = "ACCEPTED"
    tenancy.successorAgreementId = successor.id
    self:ensureTenancyHandbackState(tenancy)
    if tenancy.handbackStatus ~= "NONE" then
        tenancy.handbackStatus = "CANCELLED"
        tenancy.handbackItems = {}
        tenancy.handbackItemCount = 0
        tenancy.handbackUnresolvedCount = 0
        tenancy.handbackEstimatedCost = 0
        tenancy.handbackProfessionalFee = 0
        tenancy.handbackLatestSummary = "Handback inspection cancelled because a successor tenancy has been executed"
    end
    tenancy.renewalNegotiationLastUpdateDay = self:getCurrentDay()
    tenancy.renewalDocumentStatus = tenancy.renewalLegalReference ~= nil and tenancy.renewalLegalReference ~= ""
        and "EXECUTED_RENEWAL" or "RENEWAL_ACCEPTED"
    local acceptanceToken = string.format("renewalAccepted:%d:%d", safeNumber(tenancy.id), safeNumber(successor.id))
    local event = self:createTenancyNarrative(tenancy, "RENEWAL_ACCEPTED", {
        token=acceptanceToken, outcome="ACCEPTED", successorAgreement=successor.agreementId,
        landlordRent=annualRent, agreedRent=annualRent, termMonths=termMonths,
        documentStatus=tenancy.renewalDocumentStatus,
        packageSummary=self:getTenancyRenewalPackageSummary(renewalTerms),
        landlordPackage=self:encodeTenancyRenewalTerms(renewalTerms)
    })
    self:createTenancyNarrative(successor, "RENEWAL_ACCEPTED", {
        token=acceptanceToken .. ":successor", outcome="FUTURE_AGREEMENT", successorAgreement=successor.agreementId,
        landlordRent=annualRent, agreedRent=annualRent, termMonths=termMonths,
        reference=tenancy.renewalLegalReference or "", documentStatus="EXECUTED_RENEWAL",
        packageSummary=self:getTenancyRenewalPackageSummary(renewalTerms),
        landlordPackage=self:encodeTenancyRenewalTerms(renewalTerms)
    })
    self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_renewal", "Tenancy Renewal", false)
    print(string.format("[RealisticFarmFinance] Tenancy renewal accepted predecessor=%s successor=%s commencementPeriod=%d",
        tostring(tenancy.agreementId or tenancy.id), successor.agreementId, startPeriod))
    return true, nil, successor
end

function RFF_PropertyFinanceService:declineTenancyRenewal(tenancy)
    if tenancy == nil then return false, "no_offer" end
    if TENANCY_APPLICATION_STATES[tenancy.status or ""] then
        tenancy.renewalOfferStatus = "DECLINED"
        tenancy.renewalNegotiationLastUpdateDay = self:getCurrentDay()
        tenancy.renewalDocumentStatus = "APPLICATION_WITHDRAWN"
        tenancy.status = "APPLICATION_WITHDRAWN"
        tenancy.applicationStage = "CLOSED"
        tenancy.applicationNextActionDay = 0
        tenancy.applicationDecision = "WITHDRAWN"
        tenancy.applicationDecisionReason = "the applicant withdrew before execution"
        local event = self:createTenancyNarrative(tenancy, "APPLICATION_WITHDRAWN", {
            token=string.format("application:%d:WITHDRAWN:%d", safeNumber(tenancy.id), self:getCurrentDay()),
            outcome="WITHDRAWN", documentStatus="APPLICATION_WITHDRAWN", reference=tenancy.applicationReference,
            memoryCode="NEW"
        })
        local sender = nil
        if tenancy.applicationLandlordIntroduced ~= true then
            sender = g_i18n ~= nil and g_i18n:getText("rff_tenancy_applications_team") or "Agricultural Lettings Team"
        end
        self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_application_withdrawn", "Tenancy Application Withdrawn", false, sender)
        print(string.format("[RealisticFarmFinance] Initial tenancy application withdrawn reference=%s", tenancy.applicationReference or "-"))
        return true
    end
    if tenancy.renewalOfferStatus ~= "OFFERED" then return false, "no_offer" end
    tenancy.renewalOfferStatus = "DECLINED"
    tenancy.renewalNegotiationLastUpdateDay = self:getCurrentDay()
    if tenancy.renewalLegalReference ~= nil and tenancy.renewalLegalReference ~= "" then tenancy.renewalDocumentStatus = "NEGOTIATION_CLOSED" end
    local event = self:createTenancyNarrative(tenancy, "RENEWAL_DECLINED", {
        token=string.format("renewalDeclined:%d:%d", safeNumber(tenancy.id), self:getCurrentDay()),
        outcome="DECLINED", documentStatus=tenancy.renewalDocumentStatus
    })
    self:serveTenancyNotice(tenancy, "RENEWAL_DECLINED", tenancy.contractualEndPeriod, event ~= nil and event.text or nil)
    print(string.format("[RealisticFarmFinance] Tenancy renewal declined agreement=%s", tostring(tenancy.agreementId or tenancy.id)))
    return true
end

function RFF_PropertyFinanceService:handleTenancyPhoneDecision(context, decision)
    context = context or {}
    local tenancyId, createdPeriod = string.match(tostring(context.token or ""), "^tenancyRenewal:(%d+):(%d+)$")
    tenancyId, createdPeriod = tonumber(tenancyId), tonumber(createdPeriod)
    local farmId = tonumber(context.farmId)
    if tenancyId == nil or farmId == nil then return false, "invalid_context" end
    local tenancy = self.repository:getTenancyById(farmId, tenancyId)
    if tenancy == nil or tenancy.renewalOfferCreatedPeriod ~= createdPeriod then return false, "stale_offer" end
    if decision == "accept" then return self:acceptTenancyRenewal(tenancy) end
    if decision == "decline" then return self:declineTenancyRenewal(tenancy) end
    return false, "invalid_decision"
end

function RFF_PropertyFinanceService:exerciseTenancyBreak(tenancy)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then return false, "inactive" end
    if tenancy.breakEnabled ~= true then return false, "no_break_clause" end
    if tenancy.renewalOfferStatus == "ACCEPTED" then return false, "renewal_accepted" end
    if tenancy.noticeReason ~= nil and tenancy.noticeReason ~= "" then return false, "notice_already_served" end
    local current = self.repository:getCurrentPeriodIndex()
    if current < math.floor(safeNumber(tenancy.earliestBreakPeriod)) then return false, "too_early" end
    tenancy.breakExercisedPeriod = current
    return self:serveTenancyNotice(tenancy, "TENANT_BREAK", current + math.max(1, math.floor(safeNumber(tenancy.breakNoticeMonths or 3))))
end

function RFF_PropertyFinanceService:processTenancyRentReview(tenancy, reviewPeriod)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then return false end
    local oldRent = math.max(0, safeNumber(tenancy.annualRent))
    local newRent = math.floor(oldRent * TENANCY_REVIEW_RENT_FACTOR + 0.5)
    tenancy.previousAnnualRent = oldRent
    tenancy.annualRent = newRent
    tenancy.monthlyRent = newRent / 12
    tenancy.lastRentReviewPeriod = reviewPeriod
    tenancy.nextRentReviewPeriod = reviewPeriod + math.max(1, math.floor(safeNumber(tenancy.rentReviewIntervalMonths)))
    self:notifyTenancy(tenancy, "rff_phone_title_tenancy_review", "Tenancy Rent Review", "rff_phone_tenancy_rent_review",
        "%s: the scheduled rent review has changed annual rent from %s to %s. The next instalment will use the reviewed rent.", false,
        tenancy.holdingName or tenancy.agreementId or "The tenancy", g_i18n:formatMoney(oldRent, 0, true, true), g_i18n:formatMoney(newRent, 0, true, true))
    print(string.format("[RealisticFarmFinance] Tenancy rent reviewed agreement=%s old=%.2f new=%.2f period=%d",
        tostring(tenancy.agreementId or tenancy.id), oldRent, newRent, reviewPeriod))
    return true
end

function RFF_PropertyFinanceService:activateTenancySuccessor(predecessor, successor)
    if predecessor == nil or successor == nil or successor.status ~= "FUTURE" then return false end
    local current = self.repository:getCurrentPeriodIndex()
    local deposit = math.max(0, safeNumber(predecessor.depositHeld or predecessor.securityDeposit))
    local arrears = math.max(0, safeNumber(predecessor.arrears or predecessor.rentDue))
    local applied = math.min(deposit, arrears)
    local transferred = math.max(0, deposit - applied)
    predecessor.depositHeld = 0
    predecessor.arrears = math.max(0, arrears - applied)
    predecessor.rentDue = predecessor.arrears
    predecessor.settlementDepositApplied = applied
    predecessor.settlementDepositReturned = 0
    predecessor.settlementDepositTransferred = transferred
    predecessor.settlementFinalBalance = predecessor.arrears
    predecessor.settlementCompleted = true
    predecessor.remainingMonths = 0
    predecessor.status = "ENDED_RENEWED"

    successor.securityDeposit = transferred
    successor.depositOriginal = transferred
    successor.depositHeld = transferred
    successor.status = "ACTIVE"
    successor.commencementPeriod = current
    successor.contractualEndPeriod = current + math.max(12, math.floor(safeNumber(successor.termMonths)))
    successor.remainingMonths = successor.termMonths
    successor.nextRentDuePeriod = current
    successor.parcelConditions = {}
    successor.conditionSurveyVersion = 0
    successor.conditionSurveyPeriod = 0
    successor.conditionLastObservedPeriod = 0
    self:ensureTenancyConditionSurvey(successor, false)
    successor.nextInspectionPeriod = 0
    self:ensureTenancyInspectionState(successor)
    if RFF_TenancyAccessService ~= nil
        and RFF_TenancyAccessService.restoreTenancyFixturePossession ~= nil
        and RFF_TenancyAccessService.grantTenancyFixturePossession ~= nil then
        -- The same tenant remains in uninterrupted legal possession, but the
        -- runtime fixture ledger must move from the predecessor agreement to its
        -- successor. Restore and re-grant synchronously without running handback.
        RFF_TenancyAccessService:restoreTenancyFixturePossession(predecessor)
        RFF_TenancyAccessService:grantTenancyFixturePossession(successor)
    end
    if successor.rentReviewIntervalMonths > 0 then successor.nextRentReviewPeriod = current + successor.rentReviewIntervalMonths end
    if successor.breakEnabled then successor.earliestBreakPeriod = current + math.max(1, math.floor(successor.termMonths / 2)) end
    self:processTenancyPayment(successor, current)
    successor.commencementNotificationSent = true
    if g_messageCenter ~= nil then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, successor.farmId) end
    self:notifyTenancy(successor, "rff_phone_title_tenancy_commenced", "Renewed Tenancy Commenced", "rff_phone_tenancy_commenced",
        "%s: renewed agreement %s has commenced. Deposit transferred: %s. Agricultural access continues without interruption.", false,
        successor.holdingName or successor.agreementId or "The tenancy", successor.agreementId,
        g_i18n:formatMoney(transferred, 0, true, true))
    print(string.format("[RealisticFarmFinance] Tenancy successor commenced predecessor=%s successor=%s depositTransferred=%.2f",
        tostring(predecessor.agreementId or predecessor.id), tostring(successor.agreementId or successor.id), transferred))
    return true
end

function RFF_PropertyFinanceService:processTenancyPayment(tenancy, duePeriod)
    if tenancy == nil or not TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then return end
    local interval = math.max(1, math.floor(safeNumber(tenancy.paymentIntervalMonths or 1)))
    local due = math.max(0, safeNumber(tenancy.annualRent or (safeNumber(tenancy.monthlyRent) * 12))) * interval / 12
    tenancy.rentCharged = safeNumber(tenancy.rentCharged) + due
    tenancy.rentDue = safeNumber(tenancy.rentDue) + due
    tenancy.arrears = tenancy.rentDue
    tenancy.nextRentDuePeriod = duePeriod + interval
    local available = self.repository ~= nil and self.repository.getAvailableFunds ~= nil and self.repository:getAvailableFunds(tenancy.farmId) or farmMoney(tenancy.farmId)
    local payment = math.min(math.max(0, available), tenancy.rentDue)
    if payment > 0.001 then
        if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(tenancy.farmId, "Tenancy rent - " .. (tenancy.holdingName or "Agricultural holding")) end
        g_currentMission:addMoney(-payment, tenancy.farmId, moneyTypeFallback(), true, true)
        tenancy.rentPaid = safeNumber(tenancy.rentPaid) + payment
        tenancy.rentDue = math.max(0, tenancy.rentDue - payment)
        tenancy.arrears = tenancy.rentDue
        tenancy.lastPaymentPeriod = duePeriod
        if tenancy.rentDue <= 0.001 then
            tenancy.paymentsMade = safeNumber(tenancy.paymentsMade) + 1
            self:adjustTenancyLandlordRelationship(tenancy, 0.25 * interval, "RENT_PAID_ON_TIME")
        end
    end
    if tenancy.rentDue > 0.001 then
        tenancy.missedPayments = safeNumber(tenancy.missedPayments) + 1
        self:adjustTenancyLandlordRelationship(tenancy, -(1.5 + 0.25 * interval), "RENT_MISSED_OR_PARTIAL")
        tenancy.lastArrearsNotificationPeriod = duePeriod
        self:notifyTenancy(tenancy, "rff_phone_title_tenancy_arrears", "Tenancy Rent Arrears", "rff_phone_tenancy_arrears",
            "%s: rent of %s fell due. %s was collected and %s remains in arrears.", true,
            tenancy.holdingName or tenancy.agreementId or "Tenancy", g_i18n:formatMoney(due, 0, true, true), g_i18n:formatMoney(payment, 0, true, true), g_i18n:formatMoney(tenancy.rentDue, 0, true, true))
        print(string.format("[RealisticFarmFinance] Tenancy rent arrears agreement=%s duePeriod=%d instalment=%.2f collected=%.2f arrears=%.2f missed=%d",
            tostring(tenancy.agreementId or tenancy.id), duePeriod or 0, due, payment, tenancy.rentDue, tenancy.missedPayments or 0))
        if tenancy.missedPayments >= self.MAX_TENANCY_MISSED then
            self:releaseTenancy(tenancy, true, "TERMINATED_DEFAULT")
            self:notifyTenancy(tenancy, "rff_phone_title_tenancy_default", "Tenancy Terminated", "rff_phone_tenancy_default",
                "%s has been terminated following repeated missed rent. Agricultural access has ended. Physical handback costs were %s; deposit returned %s; final balance %s.", true,
                tenancy.holdingName or tenancy.agreementId or "The tenancy",
                g_i18n:formatMoney(tenancy.settlementDilapidationCosts or 0, 0, true, true),
                g_i18n:formatMoney(tenancy.settlementDepositReturned or 0, 0, true, true),
                g_i18n:formatMoney(tenancy.settlementFinalBalance or 0, 0, true, true))
            print(string.format("[RealisticFarmFinance] Tenancy terminated for default agreement=%s depositApplied=%.2f depositReturned=%.2f finalBalance=%.2f",
                tostring(tenancy.agreementId or tenancy.id), tenancy.settlementDepositApplied or 0, tenancy.settlementDepositReturned or 0, tenancy.settlementFinalBalance or 0))
        end
        return
    end
    tenancy.arrears = 0
    print(string.format("[RealisticFarmFinance] Tenancy rent paid agreement=%s duePeriod=%d instalment=%.2f collected=%.2f arrears=0",
        tostring(tenancy.agreementId or tenancy.id), duePeriod or 0, due, payment))
end

function RFF_PropertyFinanceService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for _, tenancy in ipairs(self.repository.tenancies or {}) do
        if TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then
            self:ensureTenancyConditionSurvey(tenancy, true)
            tenancy.commencementPeriod = safeNumber(tenancy.commencementPeriod or tenancy.createdPeriod)
            tenancy.contractualEndPeriod = safeNumber(tenancy.contractualEndPeriod) > 0 and tenancy.contractualEndPeriod or tenancy.commencementPeriod + safeNumber(tenancy.termMonths)
            tenancy.nextRentDuePeriod = safeNumber(tenancy.nextRentDuePeriod) > 0 and tenancy.nextRentDuePeriod or safeNumber(tenancy.lastPaymentPeriod) + math.max(1, safeNumber(tenancy.paymentIntervalMonths or 1))
            tenancy.renewalOfferStatus = tenancy.renewalOfferStatus or "NONE"
            if safeNumber(tenancy.nextRentReviewPeriod) > 0 then
                while tenancy.nextRentReviewPeriod <= current and tenancy.nextRentReviewPeriod < tenancy.contractualEndPeriod and TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] do
                    self:processTenancyRentReview(tenancy, tenancy.nextRentReviewPeriod)
                end
            end
            while tenancy.nextRentDuePeriod <= current and tenancy.nextRentDuePeriod < tenancy.contractualEndPeriod and TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] do
                self:processTenancyPayment(tenancy, tenancy.nextRentDuePeriod)
            end
            tenancy.remainingMonths = math.max(0, tenancy.contractualEndPeriod - current)
            self:ensureTenancyConsentState(tenancy)
            self:ensureTenancyInspectionState(tenancy)
            self:ensureTenancyBreachCaseState(tenancy)
            self:processTenancyVariationFeeArrears(tenancy)
            self:processTenancyBreachCases(tenancy, current)
            self:processLandlordVariationNotices(tenancy, current)
            if TENANCY_POSSESSION_STATES[tenancy.status or ""] then
                self:processTenancyHandback(tenancy, current)
            end
            if tenancy.remainingMonths > 0 and safeNumber(tenancy.nextInspectionPeriod) > 0
                and current >= safeNumber(tenancy.nextInspectionPeriod)
                and safeNumber(tenancy.lastInspectionPeriod) < current then
                self:performTenancyInspection(tenancy, "ROUTINE")
            end
            if tenancy.remainingMonths > 0 then self:createLandlordVariationProposal(tenancy, false) end
            if TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] then
                if tenancy.remainingMonths <= 0 then
                    local successor = safeNumber(tenancy.successorAgreementId) > 0 and self.repository:getTenancyById(tenancy.farmId, tenancy.successorAgreementId) or nil
                    if tenancy.renewalOfferStatus == "ACCEPTED" and successor ~= nil then
                        self:activateTenancySuccessor(tenancy, successor)
                    else
                        self:releaseTenancy(tenancy, true, "ENDED")
                    end
                if tenancy.expiryNotificationSent ~= true and tenancy.status ~= "ENDED_RENEWED" then
                    tenancy.expiryNotificationSent = true
                    self:notifyTenancy(tenancy, "rff_phone_title_tenancy_expired", "Tenancy Ended", "rff_phone_tenancy_expired",
                        "%s has reached its contractual expiry. Agricultural access has ended. Deposit applied: %s; deposit returned: %s; final balance: %s.", true,
                        tenancy.holdingName or tenancy.agreementId or "The tenancy", g_i18n:formatMoney(tenancy.settlementDepositApplied or 0, 0, true, true),
                        g_i18n:formatMoney(tenancy.settlementDepositReturned or 0, 0, true, true), g_i18n:formatMoney(tenancy.settlementFinalBalance or 0, 0, true, true))
                    print(string.format("[RealisticFarmFinance] Tenancy expired agreement=%s depositApplied=%.2f depositReturned=%.2f finalBalance=%.2f",
                        tostring(tenancy.agreementId or tenancy.id), tenancy.settlementDepositApplied or 0, tenancy.settlementDepositReturned or 0, tenancy.settlementFinalBalance or 0))
                    end
                else
                    if tenancy.status == "ACTIVE" and tenancy.remainingMonths <= 12 then tenancy.status = "EXPIRING" end
                    if tenancy.remainingMonths <= 12 and tenancy.expiryWarning12Sent ~= true then
                    tenancy.expiryWarning12Sent = true
                    self:notifyTenancy(tenancy, "rff_phone_title_tenancy_expiry", "Tenancy Expiry", "rff_phone_tenancy_expiry_12",
                        "%s has %d months remaining. Review the agreement and prepare for expiry or a future renewal process.", false,
                        tenancy.holdingName or tenancy.agreementId or "The tenancy", tenancy.remainingMonths)
                    end
                    if tenancy.remainingMonths <= 3 and tenancy.expiryWarning3Sent ~= true and tenancy.renewalOfferStatus ~= "ACCEPTED" then
                    tenancy.expiryWarning3Sent = true
                    self:notifyTenancy(tenancy, "rff_phone_title_tenancy_expiry", "Tenancy Expiry", "rff_phone_tenancy_expiry_3",
                        "%s has 3 months or less remaining. Agricultural access will end at contractual expiry.", true,
                        tenancy.holdingName or tenancy.agreementId or "The tenancy")
                    end
                    if tenancy.remainingMonths <= 1 and tenancy.expiryWarning1Sent ~= true and tenancy.renewalOfferStatus ~= "ACCEPTED" then
                    tenancy.expiryWarning1Sent = true
                    self:notifyTenancy(tenancy, "rff_phone_title_tenancy_expiry", "Tenancy Expiry", "rff_phone_tenancy_expiry_1",
                        "%s expires next month. Any rent arrears will be considered in the deposit settlement and access will then end.", true,
                        tenancy.holdingName or tenancy.agreementId or "The tenancy")
                    end
                    if tenancy.remainingMonths <= TENANCY_RENEWAL_OFFER_MONTHS and tenancy.remainingMonths > 1
                        and tenancy.renewalOfferStatus == "NONE" and (tenancy.noticeReason == nil or tenancy.noticeReason == "") then
                        self:createTenancyRenewalOffer(tenancy)
                    elseif tenancy.renewalOfferStatus == "OFFERED" and current > safeNumber(tenancy.renewalOfferExpiryPeriod) then
                        tenancy.renewalOfferStatus = "EXPIRED"
                        self:serveTenancyNotice(tenancy, "RENEWAL_OFFER_EXPIRED", tenancy.contractualEndPeriod)
                    end
                end
            end
        elseif TENANCY_APPLICATION_STATES[tenancy.status or ""] and tenancy.renewalOfferStatus == "OFFERED"
            and current > safeNumber(tenancy.renewalOfferExpiryPeriod) then
            tenancy.status = "APPLICATION_EXPIRED"
            tenancy.applicationStage = "CLOSED"
            tenancy.applicationNextActionDay = 0
            tenancy.applicationDecision = "EXPIRED"
            tenancy.applicationDecisionReason = "the heads of terms expired without acceptance"
            tenancy.renewalOfferStatus = "EXPIRED"
            tenancy.renewalDocumentStatus = "APPLICATION_EXPIRED"
            local event = self:createTenancyNarrative(tenancy, "APPLICATION_DECLINED", {
                token=string.format("application:%d:EXPIRED:%d", safeNumber(tenancy.id), current), outcome="EXPIRED",
                documentStatus="APPLICATION_EXPIRED", reference=tenancy.applicationReference,
                creditReason=tenancy.applicationDecisionReason, memoryCode="NEW"
            })
            self:notifyTenancyNarrative(tenancy, event, "rff_phone_title_tenancy_application_declined", "Tenancy Terms Expired", false)
        elseif tenancy.status == "FUTURE" and current >= safeNumber(tenancy.commencementPeriod) then
            local predecessor = self.repository:getTenancyById(tenancy.farmId, tenancy.predecessorAgreementId)
            if predecessor ~= nil and predecessor.renewalOfferStatus == "ACCEPTED" and TENANCY_POSSESSION_STATES[predecessor.status or ""] then
                self:activateTenancySuccessor(predecessor, tenancy)
            elseif predecessor ~= nil and predecessor.status == "ENDED_RENEWED" then
                tenancy.status = "ACTIVE"
                tenancy.commencementPeriod = current
                tenancy.contractualEndPeriod = current + math.max(12, math.floor(safeNumber(tenancy.termMonths)))
                tenancy.remainingMonths = tenancy.termMonths
                tenancy.nextRentDuePeriod = current
                tenancy.parcelConditions = {}
                tenancy.conditionSurveyVersion = 0
                tenancy.conditionSurveyPeriod = 0
                tenancy.conditionLastObservedPeriod = 0
                self:ensureTenancyConditionSurvey(tenancy, false)
                tenancy.nextInspectionPeriod = 0
                self:ensureTenancyInspectionState(tenancy)
                self:processTenancyPayment(tenancy, current)
                if g_messageCenter ~= nil then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, tenancy.farmId) end
            else
                tenancy.status = "CANCELLED"
            end
        end
        if not TENANCY_POSSESSION_STATES[tenancy.status or ""] then self:processTenancyVariationFeeArrears(tenancy) end
    end
end
