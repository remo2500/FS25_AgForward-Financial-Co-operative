-- One ordering gateway for native cash/hire and RFF finance, scoped to new shop machinery.
RFF_DealershipShop={}
local H=RFF_DealershipShop
local function service()
    local m=RFF_RealisticFarmFinance.manager;return m and m.dealership
end
local function eligible(screen)
    local d=service()
    return d and d:active() and screen.storeItem and screen.vehicle==nil and screen.saleItem==nil and d:eligible(screen.storeItem)
end
function H.offer(screen,lease)
    local d=service();local finance=RFF_AssetFinanceShopExtension.pendingPurchaseData
    RFF_AssetFinanceShopExtension.pendingPurchaseData=nil
    local q,reason=d:quote(screen.storeItem,screen.configurations,g_shopController.playerFarmId,lease,finance,screen.configurationData,screen.licensePlateData,screen.rffDealerStockId)
    if not q then InfoDialog.show(reason);return end
    local promotion=q.demoDiscount and "\nDEMO DAY: 5% brand discount included. Secured when this reservation is accepted.\n" or ""
    local text=string.format("%s\n%s\n\nAgreed machine price: %s\nReservation deposit now: %s\nPayment at handover: %s\nReady: %s\nCollect by: %s\n\n%s\n\nThis first draft allows cancellation for a full reservation refund. The deposit is credited once against the handover payment. Finance and hire start only at handover; existing quoted finance terms are held until the collection deadline.",
        q.name..promotion,q.route=="STOCK" and "IN STOCK - dealer preparation required" or "FACTORY ORDER - manufacture, transport and dealer preparation",
        g_i18n:formatMoney(q.price,0,true,true),g_i18n:formatMoney(q.deposit,0,true,true),g_i18n:formatMoney(q.payable-q.deposit,0,true,true),
        d:date(q.due),d:date(q.expires),q.lease and "Native hire: the handover payment covers the initial hire charge, not the machine purchase price. Normal daily/hourly hire charges then apply." or "New machine: zero hours, no damage or paint wear. ADS pre-delivery inspection and service are recorded at handover where supported.")
    local context={quote=q,service=d,used=false}
    YesNoDialog.show(function(c,yes)
        if c.used then return end;c.used=true
        if not yes then return end
        local _,message=c.service:place(c.quote);InfoDialog.show(message)
    end,context,text,"RFF dealership reservation")
end
function H.install()
    if H.installed or not ShopConfigScreen then return end
    H.installed=true
    if RFF_DealerShopMenu then RFF_DealerShopMenu.install() end
    ShopConfigScreen.setStoreItem=Utils.overwrittenFunction(ShopConfigScreen.setStoreItem,function(screen,superFunc,item,vehicle,saleItem,price,configs)
        local requested=H.pendingStock;H.pendingStock=nil
        screen.rffDealerStockId=nil;screen.rffDealerStockConfigurations=nil
        if requested and not vehicle and not saleItem and requested.xml==item.xmlFilename then
            screen.rffDealerStockId=requested.id
            screen.rffDealerStockConfigurations=RFF_DealershipService.copy(requested.configurations)
            configs=RFF_DealershipService.copy(requested.configurations)
        end
        return superFunc(screen,item,vehicle,saleItem,price,configs)
    end)
    ShopConfigScreen.processStoreItemConfigurations=Utils.overwrittenFunction(ShopConfigScreen.processStoreItemConfigurations,function(screen,superFunc,item,vehicle,saleItem)
        if not screen.rffDealerStockId then return superFunc(screen,item,vehicle,saleItem) end
        -- A stock preview is not a configurator. Bypass package/sub-option selectors
        -- entirely (including dynamic tyre groups), without altering the store item.
        screen.configurations=RFF_DealershipService.copy(screen.rffDealerStockConfigurations)
        screen.configSelection={title="Fixed dealer specification",texts={},prices={},options={{}}}
        screen.currentConfigSet=1;screen.colorPickers={};screen.displayableColorCount=0
    end)
    BuyVehicleData.onBought=Utils.overwrittenFunction(BuyVehicleData.onBought,function(data,superFunc,vehicles,state,args)
        if data.rffDealerOrderId then
            if data.rffDealerCallbackDone then return end
            data.rffDealerCallbackDone=true
        end
        return superFunc(data,vehicles,state,args)
    end)
    ShopConfigScreen.onClickBuy=Utils.overwrittenFunction(ShopConfigScreen.onClickBuy,function(screen,superFunc,...)
        if eligible(screen) then H.offer(screen,false);return end
        return superFunc(screen,...)
    end)
    ShopConfigScreen.onClickLease=Utils.overwrittenFunction(ShopConfigScreen.onClickLease,function(screen,superFunc,...)
        if eligible(screen) then H.offer(screen,true);return end
        return superFunc(screen,...)
    end)
    ShopConfigScreen.onCallback=Utils.overwrittenFunction(ShopConfigScreen.onCallback,function(screen,superFunc,lease,...)
        if eligible(screen) then H.offer(screen,lease);return end
        return superFunc(screen,lease,...)
    end)
    ShopConfigScreen.updateButtons=Utils.appendedFunction(ShopConfigScreen.updateButtons,function(screen)
        -- The native GUI may have captured callbacks before RFF installs hooks.
        -- Bind the gateway explicitly so cash checks use the reservation, not
        -- the full machine price. The gateway delegates unchanged when disabled.
        if screen.buyButton then screen.buyButton.onClickCallback=ShopConfigScreen.onClickBuy end
        if screen.leaseButton then screen.leaseButton.onClickCallback=ShopConfigScreen.onClickLease end
        if not eligible(screen) then return end
        screen.buyButton:setText(screen.rffDealerStockId and "RESERVE STOCK - 2 DAYS" or "RESERVE / ORDER")
        if screen.leaseButton then screen.leaseButton:setText("RESERVE FOR HIRE") end
    end)
end
