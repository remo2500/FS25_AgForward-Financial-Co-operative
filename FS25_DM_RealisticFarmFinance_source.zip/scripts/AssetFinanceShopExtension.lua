RFF_AssetFinanceShopExtension = {}
RFF_AssetFinanceShopExtension._installed = false
RFF_AssetFinanceShopExtension.pendingPurchaseData = nil
RFF_AssetFinanceShopExtension._vehicleMenuSellHooked = false
RFF_AssetFinanceShopExtension._vehicleMenuSellMethodHooks = {}
RFF_AssetFinanceShopExtension._shopControllerSellHooked = false
RFF_AssetFinanceShopExtension._sellEventHooked = false
RFF_AssetFinanceShopExtension._vehicleNameHooked = false

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function notifySaleBlocked(reason)
    if g_currentMission == nil or g_currentMission.addIngameNotification == nil then return end
    local key = reason == "lease" and "rff_asset_sale_blocked_lease" or "rff_asset_sale_blocked_finance"
    g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, g_i18n:getText(key))
end

function RFF_AssetFinanceShopExtension:getSelectedVehicleFromFrame(frame)
    if frame == nil then return nil end
    if frame.getSelectedVehicle ~= nil then
        local ok, vehicle = pcall(frame.getSelectedVehicle, frame)
        if ok and vehicle ~= nil then return vehicle end
    end
    if frame.selectedVehicle ~= nil then return frame.selectedVehicle end

    -- Native GIANTS Vehicles frame keeps the selection in vehicles[vehicleTable.selectedIndex].
    if frame.vehicles ~= nil and frame.vehicleTable ~= nil and frame.vehicleTable.selectedIndex ~= nil then
        local vehicle = frame.vehicles[frame.vehicleTable.selectedIndex]
        if vehicle ~= nil then return vehicle end
    end

    if frame.items ~= nil and frame.itemsList ~= nil and frame.itemsList.selectedIndex ~= nil then
        local item = frame.items[frame.itemsList.selectedIndex]
        if item ~= nil then return item.vehicle or item end
    end
    return nil
end

function RFF_AssetFinanceShopExtension:blockVehicleSaleIfNeeded(vehicle)
    local m = manager()
    if m == nil or m.assetFinance == nil or vehicle == nil then return false end
    local allowed, reason = m.assetFinance:canSellVehicle(vehicle)
    if allowed then return false end
    notifySaleBlocked(reason)
    return true
end

function RFF_AssetFinanceShopExtension:installVehicleMenuSellHook()
    if InGameMenuVehiclesFrame == nil then return end

    local function hookMethod(methodName)
        if RFF_AssetFinanceShopExtension._vehicleMenuSellMethodHooks[methodName] then return false end
        local original = InGameMenuVehiclesFrame[methodName]
        if original == nil then return false end

        InGameMenuVehiclesFrame[methodName] = Utils.overwrittenFunction(original, function(frame, superFunc, ...)
            local vehicle = RFF_AssetFinanceShopExtension:getSelectedVehicleFromFrame(frame)
            if RFF_AssetFinanceShopExtension:blockVehicleSaleIfNeeded(vehicle) then
                return
            end
            return superFunc(frame, ...)
        end)
        RFF_AssetFinanceShopExtension._vehicleMenuSellMethodHooks[methodName] = true
        return true
    end

    -- FS25/FS22 native garage flow uses onButtonSell; some UI variants/mods expose onClickSell.
    local hookedButton = hookMethod("onButtonSell")
    local hookedClick = hookMethod("onClickSell")
    self._vehicleMenuSellHooked = self._vehicleMenuSellHooked or hookedButton or hookedClick

    if self._vehicleMenuSellHooked then
        print(string.format("[RealisticFarmFinance] Vehicle-menu sale guard active (onButtonSell=%s, onClickSell=%s)",
            tostring(self._vehicleMenuSellMethodHooks.onButtonSell == true),
            tostring(self._vehicleMenuSellMethodHooks.onClickSell == true)))
    end
end

function RFF_AssetFinanceShopExtension:installShopControllerSellHook()
    if self._shopControllerSellHooked or ShopController == nil or ShopController.sell == nil then return end

    -- Central GIANTS sale entry point.  The Vehicles menu calls shopController:sell(...)
    -- before any asynchronous SellVehicleEvent is started, so blocking here avoids the spinner.
    ShopController.sell = Utils.overwrittenFunction(ShopController.sell, function(controller, superFunc, storeItem, item, ...)
        local vehicle = item
        if vehicle ~= nil and RFF_AssetFinanceShopExtension:blockVehicleSaleIfNeeded(vehicle) then
            return
        end
        return superFunc(controller, storeItem, item, ...)
    end)

    self._shopControllerSellHooked = true
    print("[RealisticFarmFinance] ShopController sale guard active")
end

function RFF_AssetFinanceShopExtension:respondToBlockedSellEvent(event, connection, reason)
    notifySaleBlocked(reason)

    local vehicle = event ~= nil and event.vehicle or nil
    local ownerFarmId = 0
    if vehicle ~= nil then
        if vehicle.getOwnerFarmId ~= nil then
            local ok, farmId = pcall(vehicle.getOwnerFarmId, vehicle)
            if ok and farmId ~= nil then ownerFarmId = farmId end
        elseif vehicle.ownerFarmId ~= nil then
            ownerFarmId = vehicle.ownerFarmId
        end
    end

    local ownedState = VehiclePropertyState ~= nil and VehiclePropertyState.OWNED or (Vehicle ~= nil and Vehicle.PROPERTY_STATE_OWNED or nil)
    local isOwned = vehicle ~= nil and ownedState ~= nil and vehicle.propertyState == ownedState
    local errorCode = SellVehicleEvent.SELL_NO_PERMISSION or SellVehicleEvent.SELL_VEHICLE_IN_USE or 2

    -- A SellVehicleEvent is asynchronous.  Never just return on the server: the client
    -- waits for a response and otherwise leaves the "vehicle is being sold" spinner open.
    if connection ~= nil and connection.getIsServer ~= nil and not connection:getIsServer()
            and connection.sendEvent ~= nil and SellVehicleEvent.newServerToClient ~= nil then
        connection:sendEvent(SellVehicleEvent.newServerToClient(
            errorCode, 0, event.isDirectSell or false, isOwned, ownerFarmId))
        return true
    end

    -- Single-player/local fallback if the event was executed without a network connection.
    if g_messageCenter ~= nil then
        g_messageCenter:publish(SellVehicleEvent, event ~= nil and event.isDirectSell or false, errorCode, 0, isOwned, ownerFarmId)
        return true
    end
    return false
end

function RFF_AssetFinanceShopExtension:installVehicleNameHook()
    if self._vehicleNameHooked or Vehicle == nil or Vehicle.getName == nil then return end

    Vehicle.getName = Utils.overwrittenFunction(Vehicle.getName, function(vehicle, superFunc, ...)
        local name = superFunc(vehicle, ...)
        local m = manager()
        if m ~= nil and m.repository ~= nil and vehicle ~= nil and vehicle.uniqueId ~= nil then
            local agreement = m.repository:getAssetFinanceByVehicle(vehicle.uniqueId, true)
            if agreement ~= nil and agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
                local suffix = g_i18n ~= nil and g_i18n:getText("rff_asset_lease_suffix") or "RFF LEASE"
                local marker = "(" .. suffix .. ")"
                if type(name) == "string" and string.find(name, marker, 1, true) == nil then
                    name = name .. " " .. marker
                end
            end
        end
        return name
    end)

    self._vehicleNameHooked = true
end

function RFF_AssetFinanceShopExtension.install()
    if RFF_AssetFinanceShopExtension._installed then return end
    if ShopConfigScreen == nil or BuyVehicleData == nil then return end

    RFF_AssetFinanceShopExtension:installVehicleMenuSellHook()
    RFF_AssetFinanceShopExtension:installShopControllerSellHook()
    RFF_AssetFinanceShopExtension:installVehicleNameHook()

    ShopConfigScreen.setStoreItem = Utils.appendedFunction(ShopConfigScreen.setStoreItem, function(screen, storeItem)
        RFF_AssetFinanceShopExtension:configureButton(screen, storeItem)
    end)
    ShopConfigScreen.updateButtons = Utils.appendedFunction(ShopConfigScreen.updateButtons, function(screen, storeItem, vehicle, saleItem)
        RFF_AssetFinanceShopExtension:updateButtonVisibility(screen, storeItem, vehicle, saleItem)
    end)

    local originalBuyVehicleDataNew = BuyVehicleData.new
    BuyVehicleData.new = function(...)
        local data = originalBuyVehicleDataNew(...)
        if RFF_AssetFinanceShopExtension.pendingPurchaseData ~= nil then
            data.rffAssetFinanceData = RFF_AssetFinanceShopExtension.pendingPurchaseData
            RFF_AssetFinanceShopExtension.pendingPurchaseData = nil
        end
        return data
    end

    function BuyVehicleData:setRFFAssetFinanceData(data)
        self.rffAssetFinanceData = data
    end

    BuyVehicleData.writeStream = Utils.appendedFunction(BuyVehicleData.writeStream, function(data, streamId, connection)
        local d = data.rffAssetFinanceData
        streamWriteBool(streamId, d ~= nil)
        if d ~= nil then
            streamWriteInt32(streamId, d.farmId or 0)
            streamWriteString(streamId, d.product or "")
            streamWriteFloat32(streamId, d.basePrice or 0)
            streamWriteFloat32(streamId, d.depositPercent or 0)
            streamWriteFloat32(streamId, d.deposit or 0)
            streamWriteInt32(streamId, d.months or 0)
            streamWriteFloat32(streamId, d.balloonPercent or 0)
            streamWriteFloat32(streamId, d.balloonAmount or 0)
            streamWriteFloat32(streamId, d.residualValue or 0)
            streamWriteFloat32(streamId, d.amountFinanced or 0)
            streamWriteFloat32(streamId, d.interestRate or 0)
            streamWriteFloat32(streamId, d.monthlyPayment or 0)
            streamWriteString(streamId, d.grade or "C")
            streamWriteString(streamId, d.lenderId or "PRIMARY_BANK")
            streamWriteString(streamId, d.lenderNameKey or "rff_lender_primary_bank")
            streamWriteString(streamId, d.vehicleName or "")
            streamWriteString(streamId, d.storeItemXml or "")
        end
    end)

    BuyVehicleData.readStream = Utils.appendedFunction(BuyVehicleData.readStream, function(data, streamId, connection)
        if streamReadBool(streamId) then
            data.rffAssetFinanceData = {
                farmId = streamReadInt32(streamId), product = streamReadString(streamId), basePrice = streamReadFloat32(streamId),
                depositPercent = streamReadFloat32(streamId), deposit = streamReadFloat32(streamId), months = streamReadInt32(streamId),
                balloonPercent = streamReadFloat32(streamId), balloonAmount = streamReadFloat32(streamId), residualValue = streamReadFloat32(streamId),
                amountFinanced = streamReadFloat32(streamId), interestRate = streamReadFloat32(streamId), monthlyPayment = streamReadFloat32(streamId),
                grade = streamReadString(streamId), lenderId = streamReadString(streamId), lenderNameKey = streamReadString(streamId),
                vehicleName = streamReadString(streamId), storeItemXml = streamReadString(streamId)
            }
        else
            data.rffAssetFinanceData = nil
        end
    end)

    BuyVehicleData.updatePrice = Utils.appendedFunction(BuyVehicleData.updatePrice, function(data)
        if data.rffAssetFinanceData ~= nil then data.price = data.rffAssetFinanceData.deposit or data.price end
    end)
    BuyVehicleData.buy = Utils.prependedFunction(BuyVehicleData.buy, function(data)
        if data.rffAssetFinanceData ~= nil then data.price = data.rffAssetFinanceData.deposit or data.price end
    end)
    BuyVehicleData.onBought = Utils.prependedFunction(BuyVehicleData.onBought, function(data, loadedVehicles, loadingState)
        if loadingState ~= VehicleLoadingState.OK then return end
        local m = manager()
        if m == nil then return end
        if data.rffDealerReservedDeposit ~= nil and m.dealership ~= nil then
            local deposit = data.rffDealerReservedDeposit
            data.rffDealerReservedDeposit = nil
            -- Release the reservation asset into the full native purchase debit.
            -- Net new cash paid is only the remaining balance; native accounting
            -- still records the full acquisition/initial hire payment exactly once.
            m.dealership:money(data.ownerFarmId, deposit, "Dealer deposit applied at handover")
        end
        if data.rffAssetFinanceData ~= nil and m.assetFinance ~= nil then
            for _, vehicle in pairs(loadedVehicles or {}) do
                if vehicle ~= nil then
                    m.assetFinance:createAgreementFromPurchase(data.rffAssetFinanceData, vehicle)
                    break
                end
            end
        end
        if m.fleetManagement ~= nil and data.leaseVehicle ~= true then
            local farmId = data.rffAssetFinanceData ~= nil and data.rffAssetFinanceData.farmId or data.ownerFarmId
            for _, vehicle in pairs(loadedVehicles or {}) do
                m.fleetManagement:grantDealershipCover(farmId or 0, vehicle)
            end
        end
    end)

    if Vehicle ~= nil and Vehicle.showInfo ~= nil then
        Vehicle.showInfo = Utils.appendedFunction(Vehicle.showInfo, function(vehicle, box)
            local m = manager()
            if m == nil or m.repository == nil or m.assetFinance == nil or vehicle == nil or box == nil then return end
            local agreement = m.repository:getAssetFinanceByVehicle(vehicle.uniqueId, true)
            if agreement == nil then return end
            local productKey = m.assetFinance:getProductTextKey(agreement.product)
            box:addLine(g_i18n:getText("rff_asset_info_finance"), g_i18n:getText(productKey))
            local providerName = agreement.lenderNameKey ~= nil and agreement.lenderNameKey ~= "" and g_i18n:getText(agreement.lenderNameKey) or g_i18n:getText("rff_lender_primary_bank")
            box:addLine(g_i18n:getText("rff_asset_provider"), providerName)
            box:addLine(g_i18n:getText("rff_asset_info_monthly"), g_i18n:formatMoney(agreement.monthlyPayment or 0, 0, true, true))
            box:addLine(g_i18n:getText("rff_asset_info_months_left"), tostring(agreement.remainingMonths or 0))
            if agreement.product ~= RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
                box:addLine(g_i18n:getText("rff_asset_info_settlement"), g_i18n:formatMoney(agreement.principal or 0, 0, true, true))
            end
        end)
    end

    if not RFF_AssetFinanceShopExtension._sellEventHooked and SellVehicleEvent ~= nil and SellVehicleEvent.run ~= nil then
        SellVehicleEvent.run = Utils.overwrittenFunction(SellVehicleEvent.run, function(event, superFunc, connection)
            local m = manager()
            local vehicle = event.vehicle
            if m ~= nil and m.assetFinance ~= nil and vehicle ~= nil then
                local allowed, reason = m.assetFinance:canSellVehicle(vehicle)
                if not allowed then
                    RFF_AssetFinanceShopExtension:respondToBlockedSellEvent(event, connection, reason)
                    return
                end
            end
            return superFunc(event, connection)
        end)
        RFF_AssetFinanceShopExtension._sellEventHooked = true
    end

    RFF_AssetFinanceShopExtension._installed = true
end

function RFF_AssetFinanceShopExtension:configureButton(screen, storeItem)
    if screen == nil or screen.buyButton == nil then return end
    local button = screen.rffFinanceButton
    if button == nil then
        button = screen.buyButton:clone(screen.buyButton.parent)
        button.name = "rffFinanceButton"
        button.inputActionName = "MENU_EXTRA_2"
        button:setText(g_i18n:getText("rff_asset_shop_button"))
        button.onClickCallback = function()
            RFF_AssetFinanceShopExtension:onClickFinance(screen)
        end
        screen.rffFinanceButton = button
    end
    self:updateButtonVisibility(screen, storeItem, screen.vehicle, screen.saleItem)
end

function RFF_AssetFinanceShopExtension:updateButtonVisibility(screen, storeItem, vehicle, saleItem)
    local button = screen ~= nil and screen.rffFinanceButton or nil
    if button == nil then return end
    storeItem = storeItem or screen.storeItem
    saleItem = saleItem or screen.saleItem
    vehicle = vehicle or screen.vehicle
    local eligiblePurchase = storeItem ~= nil and vehicle == nil and not storeItem.isInAppPurchase
    button:setText(g_i18n:getText(saleItem ~= nil and "rff_asset_shop_button_used" or "rff_asset_shop_button"))
    button:setVisible(eligiblePurchase)
    button:setDisabled(not eligiblePurchase)
    if screen.buttonsPanel ~= nil then screen.buttonsPanel:invalidateLayout() end
end

function RFF_AssetFinanceShopExtension:onClickFinance(screen)
    local m = manager()
    if m == nil or m.assetFinance == nil or screen == nil or screen.storeItem == nil
        or screen.vehicle ~= nil or screen.storeItem.isInAppPurchase then return end
    local dialog = g_gui:showDialog("RFFAssetFinanceDialog")
    if dialog ~= nil and dialog.target ~= nil then
        dialog.target:setData(screen.storeItem, screen.configurations, screen.licensePlateData, screen.totalPrice, screen.saleItem, screen.configurationData)
    end
end
