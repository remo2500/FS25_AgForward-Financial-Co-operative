RFF_LandFinanceDialog = {}
local RFF_LandFinanceDialog_mt = Class(RFF_LandFinanceDialog, MessageDialog)

RFF_LandFinanceDialog.MODE_MORTGAGE = "MORTGAGE"
RFF_LandFinanceDialog.MODE_TENANCY = "TENANCY"
RFF_LandFinanceDialog.MODE_RENEWAL = "RENEWAL"

local RENEWAL_ENTERPRISE_VALUES = {"MIXED", "ARABLE", "LIVESTOCK"}
local RENEWAL_REVIEW_VALUES = {0, 36, 24, 12}
local RENEWAL_BREAK_VALUES = {0, 12, 6, 3}
local RENEWAL_LANDLORD_NOTICE_VALUES = {3, 6, 12}
local RENEWAL_LANDLORD_COOLDOWN_VALUES = {12, 24, 36}

RFF_LandFinanceDialog.CONTROLS = {
    "titleText",
    "subtitleText",
    "mortgagePanel",
    "tenancyPanel",
    "renewalPanel",
    "mortgageDepositOption",
    "mortgageTermOption",
    "mortgagePriceValue",
    "mortgageDepositValue",
    "mortgagePrincipalValue",
    "mortgageRateValue",
    "mortgagePaymentValue",
    "mortgageLtvValue",
    "mortgageDscrValue",
    "mortgageGradeValue",
    "mortgageDecisionValue",
    "tenancyTermOption",
    "tenancyLandlordValue",
    "tenancyLandlordApproachValue",
    "tenancyPriceValue",
    "tenancyMonthlyRentValue",
    "tenancyAnnualRentValue",
    "tenancyDepositValue",
    "tenancyCashRequiredValue",
    "tenancyRateValue",
    "tenancyDecisionValue",
    "renewalRentValue",
    "renewalLandlordTermsValue",
    "renewalEnterpriseOption",
    "renewalGrassOption",
    "renewalBoundaryOption",
    "renewalImprovementsOption",
    "renewalMaintenanceOption",
    "renewalReviewOption",
    "renewalBreakOption",
    "renewalLandlordNoticeOption",
    "renewalLandlordCooldownOption",
    "renewalAssessmentValue",
    "confirmButton"
}

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function formatMoney(value)
    return g_i18n:formatMoney(value or 0, 0, true, true)
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then
        option:setState(state, false)
    else
        option.state = state
    end
end

local function getFarmMoney(farmId)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    return farm ~= nil and (farm.money or 0) or 0
end

local function stateForValue(values, value)
    for index, candidate in ipairs(values) do
        if candidate == value then return index end
    end
    return 1
end

local function countRenewalChanges(left, right)
    if left == nil or right == nil then return 0 end
    local count = 0
    for _, fields in ipairs({{"permittedEnterprise"}, {"permanentGrassRestriction"}, {"boundaryRemovalRequiresConsent"},
        {"improvementsRequireConsent"}, {"tenantMaintenanceObligation"}, {"rentReviewIntervalMonths"},
        {"breakEnabled", "breakNoticeMonths"}, {"landlordVariationNoticeMonths", "landlordVariationCooldownMonths"}}) do
        for _, key in ipairs(fields) do
            if left[key] ~= right[key] then count = count + 1 break end
        end
    end
    return count
end

local function wrapText(text, maxChars)
    if text == nil then return "" end
    maxChars = maxChars or 76
    local wrapped = {}
    for sourceLine in (tostring(text) .. "\n"):gmatch("(.-)\n") do
        if sourceLine == "" then
            table.insert(wrapped, "")
        else
            local line = ""
            for word in sourceLine:gmatch("%S+") do
                if line == "" then
                    line = word
                elseif #line + #word + 1 <= maxChars then
                    line = line .. " " .. word
                else
                    table.insert(wrapped, line)
                    line = word
                end
            end
            if line ~= "" then table.insert(wrapped, line) end
        end
    end
    return table.concat(wrapped, "\n")
end

function RFF_LandFinanceDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or RFF_LandFinanceDialog_mt)
    self.mode = nil
    self.farmlandId = nil
    self.callbackFrame = nil
    self.lastMortgageEvaluation = nil
    self.lastTenancyOffer = nil
    self.renewalTenancy = nil
    self.renewalRent = 0
    self.pendingConfirmation = false
    return self
end

function RFF_LandFinanceDialog:onLoad()
    RFF_LandFinanceDialog:superClass().onLoad(self)
    self:registerControls(RFF_LandFinanceDialog.CONTROLS)
end

function RFF_LandFinanceDialog:onOpen()
    RFF_LandFinanceDialog:superClass().onOpen(self)
    self:refresh()
    local focusElement = self.mode == self.MODE_RENEWAL and self.renewalRentValue or self.confirmButton
    if focusElement ~= nil then
        FocusManager:setFocus(focusElement)
    end
end

function RFF_LandFinanceDialog:onClose()
    self.pendingConfirmation = false
    RFF_LandFinanceDialog:superClass().onClose(self)
end

function RFF_LandFinanceDialog:configureMortgage(frame, farmlandId)
    local m = manager()
    if m == nil or m.propertyFinance == nil then return false end
    local land = m.propertyFinance:getFarmland(farmlandId)
    if land == nil or not m.propertyFinance:isFarmlandAvailableForAcquisition(farmlandId) then return false end

    self.mode = self.MODE_MORTGAGE
    self.farmlandId = farmlandId
    self.callbackFrame = frame

    local depositTexts = {}
    for _, pct in ipairs(m.propertyFinance.MORTGAGE_DOWN_PAYMENTS) do
        table.insert(depositTexts, string.format("%d%%   (%s)", pct, formatMoney((land.price or 0) * pct / 100)))
    end
    if self.mortgageDepositOption ~= nil then
        self.mortgageDepositOption:setTexts(depositTexts)
        setOptionState(self.mortgageDepositOption, RFF_FarmlandMapExtension.selectedDownPaymentIndex or 2)
    end

    local termTexts = {}
    for _, months in ipairs(m.propertyFinance.MORTGAGE_TERMS) do
        local years = math.floor(months / 12)
        table.insert(termTexts, string.format("%d year%s", years, years == 1 and "" or "s"))
    end
    if self.mortgageTermOption ~= nil then
        self.mortgageTermOption:setTexts(termTexts)
        setOptionState(self.mortgageTermOption, RFF_FarmlandMapExtension.selectedMortgageTermIndex or 4)
    end

    self:refresh()
    return true
end

function RFF_LandFinanceDialog:configureTenancy(frame, farmlandId)
    local m = manager()
    if m == nil or m.propertyFinance == nil then return false end
    local land = m.propertyFinance:getFarmland(farmlandId)
    if land == nil or not m.propertyFinance:isFarmlandAvailableForAcquisition(farmlandId) then return false end

    self.mode = self.MODE_TENANCY
    self.farmlandId = farmlandId
    self.callbackFrame = frame

    local termTexts = {}
    for _, months in ipairs(m.propertyFinance.TENANCY_TERMS) do
        if months >= 12 and months % 12 == 0 then
            local years = months / 12
            table.insert(termTexts, string.format("%d year%s (%d months)", years, years == 1 and "" or "s", months))
        else
            table.insert(termTexts, string.format("%d months", months))
        end
    end
    if self.tenancyTermOption ~= nil then
        self.tenancyTermOption:setTexts(termTexts)
        setOptionState(self.tenancyTermOption, RFF_FarmlandMapExtension.selectedTenancyTermIndex or 2)
    end

    self:refresh()
    return true
end

function RFF_LandFinanceDialog:configureRenewal(frame, tenancy, annualRent)
    local m = manager()
    if m == nil or m.propertyFinance == nil or tenancy == nil or tenancy.renewalOfferStatus ~= "OFFERED" then return false end

    self.mode = self.MODE_RENEWAL
    self.farmlandId = tenancy.farmlandId
    self.callbackFrame = frame
    self.renewalTenancy = tenancy
    self.renewalRent = math.max(1, math.floor(tonumber(annualRent) or 0))
    self.pendingRenewal = nil

    local termsPrefix = (tenancy.renewalNegotiationAttempts or 0) > 0 and "renewalTenant" or "renewalOffer"
    local terms = m.propertyFinance:getTenancyRenewalTerms(tenancy, termsPrefix)

    self.renewalEnterpriseOption:setTexts({
        g_i18n:getText("rff_tenancy_enterprise_mixed"), g_i18n:getText("rff_tenancy_enterprise_arable"),
        g_i18n:getText("rff_tenancy_enterprise_livestock")
    })
    self.renewalGrassOption:setTexts({g_i18n:getText("rff_tenancy_grass_retain"), g_i18n:getText("rff_tenancy_grass_cropping")})
    self.renewalBoundaryOption:setTexts({g_i18n:getText("rff_tenancy_consent_required"), g_i18n:getText("rff_tenancy_consent_not_required")})
    self.renewalImprovementsOption:setTexts({g_i18n:getText("rff_tenancy_consent_required"), g_i18n:getText("rff_tenancy_consent_not_required")})
    self.renewalMaintenanceOption:setTexts({g_i18n:getText("rff_tenancy_maintenance_tenant"), g_i18n:getText("rff_tenancy_maintenance_shared")})
    self.renewalReviewOption:setTexts({g_i18n:getText("rff_tenancy_review_none"), g_i18n:getText("rff_tenancy_review_36"),
        g_i18n:getText("rff_tenancy_review_24"), g_i18n:getText("rff_tenancy_review_12")})
    self.renewalBreakOption:setTexts({g_i18n:getText("rff_tenancy_break_none"), g_i18n:getText("rff_tenancy_break_12"),
        g_i18n:getText("rff_tenancy_break_6"), g_i18n:getText("rff_tenancy_break_3")})
    self.renewalLandlordNoticeOption:setTexts({g_i18n:getText("rff_tenancy_landlord_notice_3"),
        g_i18n:getText("rff_tenancy_landlord_notice_6"), g_i18n:getText("rff_tenancy_landlord_notice_12")})
    self.renewalLandlordCooldownOption:setTexts({g_i18n:getText("rff_tenancy_landlord_cooldown_12"),
        g_i18n:getText("rff_tenancy_landlord_cooldown_24"), g_i18n:getText("rff_tenancy_landlord_cooldown_36")})

    setOptionState(self.renewalEnterpriseOption, stateForValue(RENEWAL_ENTERPRISE_VALUES, terms.permittedEnterprise))
    setOptionState(self.renewalGrassOption, terms.permanentGrassRestriction and 1 or 2)
    setOptionState(self.renewalBoundaryOption, terms.boundaryRemovalRequiresConsent and 1 or 2)
    setOptionState(self.renewalImprovementsOption, terms.improvementsRequireConsent and 1 or 2)
    setOptionState(self.renewalMaintenanceOption, terms.tenantMaintenanceObligation and 1 or 2)
    setOptionState(self.renewalReviewOption, stateForValue(RENEWAL_REVIEW_VALUES, terms.rentReviewIntervalMonths))
    setOptionState(self.renewalBreakOption, terms.breakEnabled and stateForValue(RENEWAL_BREAK_VALUES, terms.breakNoticeMonths) or 1)
    setOptionState(self.renewalLandlordNoticeOption, stateForValue(RENEWAL_LANDLORD_NOTICE_VALUES, terms.landlordVariationNoticeMonths))
    setOptionState(self.renewalLandlordCooldownOption, stateForValue(RENEWAL_LANDLORD_COOLDOWN_VALUES, terms.landlordVariationCooldownMonths))

    self:refresh()
    return true
end

function RFF_LandFinanceDialog:getMortgageSelection()
    local m = manager()
    if m == nil or m.propertyFinance == nil then return nil, nil, nil, nil end
    local depositIndex = math.max(1, math.min(#m.propertyFinance.MORTGAGE_DOWN_PAYMENTS, self.mortgageDepositOption ~= nil and (self.mortgageDepositOption.state or 1) or 1))
    local termIndex = math.max(1, math.min(#m.propertyFinance.MORTGAGE_TERMS, self.mortgageTermOption ~= nil and (self.mortgageTermOption.state or 1) or 1))
    return m.propertyFinance.MORTGAGE_DOWN_PAYMENTS[depositIndex], m.propertyFinance.MORTGAGE_TERMS[termIndex], depositIndex, termIndex
end

function RFF_LandFinanceDialog:getTenancySelection()
    local m = manager()
    if m == nil or m.propertyFinance == nil then return nil, nil end
    local termIndex = math.max(1, math.min(#m.propertyFinance.TENANCY_TERMS, self.tenancyTermOption ~= nil and (self.tenancyTermOption.state or 1) or 1))
    return m.propertyFinance.TENANCY_TERMS[termIndex], termIndex
end

function RFF_LandFinanceDialog:getRenewalSelection()
    local enterpriseState = math.max(1, math.min(#RENEWAL_ENTERPRISE_VALUES, self.renewalEnterpriseOption.state or 1))
    local reviewState = math.max(1, math.min(#RENEWAL_REVIEW_VALUES, self.renewalReviewOption.state or 1))
    local breakState = math.max(1, math.min(#RENEWAL_BREAK_VALUES, self.renewalBreakOption.state or 1))
    local landlordNoticeState = math.max(1, math.min(#RENEWAL_LANDLORD_NOTICE_VALUES, self.renewalLandlordNoticeOption.state or 1))
    local landlordCooldownState = math.max(1, math.min(#RENEWAL_LANDLORD_COOLDOWN_VALUES, self.renewalLandlordCooldownOption.state or 1))
    return {
        permittedEnterprise=RENEWAL_ENTERPRISE_VALUES[enterpriseState],
        permanentGrassRestriction=(self.renewalGrassOption.state or 1) == 1,
        boundaryRemovalRequiresConsent=(self.renewalBoundaryOption.state or 1) == 1,
        improvementsRequireConsent=(self.renewalImprovementsOption.state or 1) == 1,
        tenantMaintenanceObligation=(self.renewalMaintenanceOption.state or 1) == 1,
        rentReviewIntervalMonths=RENEWAL_REVIEW_VALUES[reviewState],
        breakEnabled=RENEWAL_BREAK_VALUES[breakState] > 0,
        breakNoticeMonths=RENEWAL_BREAK_VALUES[breakState],
        landlordVariationNoticeMonths=RENEWAL_LANDLORD_NOTICE_VALUES[landlordNoticeState],
        landlordVariationCooldownMonths=RENEWAL_LANDLORD_COOLDOWN_VALUES[landlordCooldownState]
    }
end

function RFF_LandFinanceDialog:onMortgageOptionChanged()
    self:refreshMortgage()
end

function RFF_LandFinanceDialog:onTenancyOptionChanged()
    self:refreshTenancy()
end

function RFF_LandFinanceDialog:onRenewalOptionChanged()
    self:refreshRenewal()
end

function RFF_LandFinanceDialog:onClickRenewalRent()
    if self.mode ~= self.MODE_RENEWAL or self.renewalTenancy == nil then return end
    if TextInputDialog == nil or TextInputDialog.show == nil then
        InfoDialog.show(g_i18n:getText("rff_tenancy_amount_input_unavailable"))
        return
    end
    local landlordRent = formatMoney(self.renewalTenancy.renewalOfferAnnualRent or 0)
    local prompt = string.format(g_i18n:getText("rff_tenancy_package_rent_prompt"), landlordRent)
    TextInputDialog.show(self.onRenewalRentEntered, self, tostring(math.floor(self.renewalRent or 0)),
        wrapText(prompt, 60), nil, 12, g_i18n:getText("button_ok"))
end

function RFF_LandFinanceDialog:onRenewalRentEntered(text, confirmed)
    if not confirmed then return end
    local cleaned = tostring(text or ""):gsub("[^%d]", "")
    local amount = tonumber(cleaned)
    if amount == nil or amount <= 0 then
        InfoDialog.show(g_i18n:getText("rff_tenancy_invalid_offer_amount"))
        return
    end
    self.renewalRent = math.floor(amount + 0.5)
    self:refreshRenewal()
end

function RFF_LandFinanceDialog:refresh()
    if self.mortgagePanel ~= nil then self.mortgagePanel:setVisible(self.mode == self.MODE_MORTGAGE) end
    if self.tenancyPanel ~= nil then self.tenancyPanel:setVisible(self.mode == self.MODE_TENANCY) end
    if self.renewalPanel ~= nil then self.renewalPanel:setVisible(self.mode == self.MODE_RENEWAL) end

    if self.mode == self.MODE_MORTGAGE then
        if self.titleText ~= nil then self.titleText:setText(g_i18n:getText("rff_land_dialog_mortgage_title")) end
        if self.subtitleText ~= nil then self.subtitleText:setText(wrapText(g_i18n:getText("rff_land_dialog_mortgage_subtitle"), 76)) end
        if self.confirmButton ~= nil then self.confirmButton:setText(g_i18n:getText("rff_land_dialog_submit_application")) end
        self:refreshMortgage()
    elseif self.mode == self.MODE_TENANCY then
        if self.titleText ~= nil then self.titleText:setText(g_i18n:getText("rff_land_dialog_tenancy_title")) end
        if self.subtitleText ~= nil then self.subtitleText:setText(wrapText(g_i18n:getText("rff_land_dialog_tenancy_subtitle"), 76)) end
        if self.confirmButton ~= nil then self.confirmButton:setText(g_i18n:getText("rff_land_dialog_submit_tenancy_enquiry")) end
        self:refreshTenancy()
    elseif self.mode == self.MODE_RENEWAL then
        if self.titleText ~= nil then self.titleText:setText(g_i18n:getText("rff_tenancy_heads_title")) end
        if self.subtitleText ~= nil then self.subtitleText:setText(wrapText(g_i18n:getText("rff_tenancy_heads_subtitle"), 84)) end
        if self.confirmButton ~= nil then self.confirmButton:setText(g_i18n:getText("rff_tenancy_present_package")) end
        self:refreshRenewal()
    end
end

function RFF_LandFinanceDialog:refreshMortgage()
    if self.mode ~= self.MODE_MORTGAGE then return end
    local m = manager()
    if m == nil or m.propertyFinance == nil or self.farmlandId == nil then return end
    local pct, months = self:getMortgageSelection()
    if pct == nil or months == nil then return end

    local evaluation = m.propertyFinance:evaluateMortgage(g_currentMission:getFarmId(), self.farmlandId, pct, months)
    self.lastMortgageEvaluation = evaluation

    if self.mortgagePriceValue ~= nil then self.mortgagePriceValue:setText(formatMoney(evaluation.price or 0)) end
    if self.mortgageDepositValue ~= nil then self.mortgageDepositValue:setText(formatMoney(evaluation.deposit or 0)) end
    if self.mortgagePrincipalValue ~= nil then self.mortgagePrincipalValue:setText(formatMoney(evaluation.principal or 0)) end
    if self.mortgageRateValue ~= nil then self.mortgageRateValue:setText((evaluation.interestRate or 0) > 0 and string.format("%.2f%%", evaluation.interestRate or 0) or "-") end
    if self.mortgagePaymentValue ~= nil then self.mortgagePaymentValue:setText((evaluation.monthlyPayment or 0) > 0 and formatMoney(evaluation.monthlyPayment or 0) or "-") end
    if self.mortgageLtvValue ~= nil then self.mortgageLtvValue:setText(evaluation.ltv ~= nil and evaluation.ltv ~= math.huge and string.format("%.1f%%", evaluation.ltv * 100) or "-") end
    if self.mortgageDscrValue ~= nil then self.mortgageDscrValue:setText(evaluation.dscr ~= nil and evaluation.dscr ~= math.huge and string.format("%.2f", evaluation.dscr) or g_i18n:getText("rff_not_applicable")) end
    if self.mortgageGradeValue ~= nil then self.mortgageGradeValue:setText(evaluation.grade or "-") end

    local decision
    if evaluation.reason == "funds" then
        decision = g_i18n:getText("rff_mortgage_insufficient_deposit")
    elseif evaluation.approved then
        decision = g_i18n:getText("rff_land_dialog_indicative_supportable")
    elseif evaluation.reason == "property_ltv" then
        decision = g_i18n:getText("rff_land_dialog_indicative_revised_deposit")
    else
        decision = g_i18n:getText("rff_land_dialog_indicative_concerns")
    end
    if self.mortgageDecisionValue ~= nil then self.mortgageDecisionValue:setText(wrapText(decision, 76)) end
    local canSubmit = evaluation.reason ~= "funds" and evaluation.reason ~= "invalid" and evaluation.price ~= nil and evaluation.principal ~= nil
    if self.confirmButton ~= nil and self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(not canSubmit) end
end

function RFF_LandFinanceDialog:refreshTenancy()
    if self.mode ~= self.MODE_TENANCY then return end
    local m = manager()
    if m == nil or m.propertyFinance == nil or self.farmlandId == nil then return end
    local months = self:getTenancySelection()
    if months == nil then return end

    local offer = m.propertyFinance:getTenancyOffer(self.farmlandId, months)
    self.lastTenancyOffer = offer
    if offer == nil then
        if self.tenancyDecisionValue ~= nil then self.tenancyDecisionValue:setText(wrapText(g_i18n:getText("rff_farmland_not_for_sale"), 76)) end
        if self.confirmButton ~= nil and self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(true) end
        return
    end

    if self.tenancyPriceValue ~= nil then self.tenancyPriceValue:setText(formatMoney(offer.price or 0)) end
    if self.tenancyMonthlyRentValue ~= nil then self.tenancyMonthlyRentValue:setText(g_i18n:getText("rff_tenancy_quoted_in_heads")) end
    if self.tenancyAnnualRentValue ~= nil then self.tenancyAnnualRentValue:setText(g_i18n:getText("rff_tenancy_quoted_in_heads")) end
    if self.tenancyDepositValue ~= nil then self.tenancyDepositValue:setText(g_i18n:getText("rff_tenancy_set_after_checks")) end
    if self.tenancyCashRequiredValue ~= nil then self.tenancyCashRequiredValue:setText(g_i18n:getText("rff_tenancy_nothing_due_today")) end
    if self.tenancyRateValue ~= nil then self.tenancyRateValue:setText(g_i18n:getText("rff_tenancy_subject_to_negotiation")) end
    if self.tenancyLandlordValue ~= nil then self.tenancyLandlordValue:setText(g_i18n:getText("rff_tenancy_introduced_after_enquiry")) end
    if self.tenancyLandlordApproachValue ~= nil then self.tenancyLandlordApproachValue:setText(g_i18n:getText("rff_tenancy_explained_during_application")) end

    local existing = m.propertyFinance:getOpenTenancyApplicationForFarmland(self.farmlandId)
    if self.tenancyDecisionValue ~= nil then
        self.tenancyDecisionValue:setText(wrapText(existing ~= nil and g_i18n:getText("rff_tenancy_existing_enquiry")
            or g_i18n:getText("rff_land_dialog_tenancy_enquiry_available"), 76))
    end
    if self.confirmButton ~= nil and self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(existing ~= nil) end
end

function RFF_LandFinanceDialog:refreshRenewal()
    if self.mode ~= self.MODE_RENEWAL then return end
    local m = manager()
    local tenancy = self.renewalTenancy
    if m == nil or m.propertyFinance == nil or tenancy == nil then return end
    local proposedTerms = self:getRenewalSelection()
    local landlordTerms = m.propertyFinance:getTenancyRenewalTerms(tenancy, "renewalOffer")
    local brief = m.propertyFinance:getTenancyLandlordBrief(tenancy)
    local changed = countRenewalChanges(proposedTerms, landlordTerms)
    local rentDifference = self.renewalRent - (tenancy.renewalOfferAnnualRent or 0)
    local rentPosition
    if math.abs(rentDifference) < 0.5 then
        rentPosition = g_i18n:getText("rff_tenancy_rent_position_equal")
    elseif rentDifference > 0 then
        rentPosition = string.format(g_i18n:getText("rff_tenancy_rent_position_above"), formatMoney(rentDifference))
    else
        rentPosition = string.format(g_i18n:getText("rff_tenancy_rent_position_below"), formatMoney(math.abs(rentDifference)))
    end

    if self.renewalRentValue ~= nil then
        self.renewalRentValue:setText(string.format(g_i18n:getText("rff_tenancy_edit_rent_button"), formatMoney(self.renewalRent)))
    end
    if self.renewalLandlordTermsValue ~= nil then
        self.renewalLandlordTermsValue:setText(wrapText(m.propertyFinance:getTenancyRenewalPackageSummary(landlordTerms), 92))
    end
    if self.renewalAssessmentValue ~= nil then
        self.renewalAssessmentValue:setText(wrapText(string.format(g_i18n:getText("rff_tenancy_package_assessment"), rentPosition,
            changed, brief.name, brief.relationshipText, brief.posture), 90))
    end
    if self.confirmButton ~= nil and self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(false) end
end

function RFF_LandFinanceDialog:onClickConfirm()
    if self.pendingConfirmation then return end
    local m = manager()
    if m == nil or m.propertyFinance == nil then return end

    if self.mode == self.MODE_MORTGAGE then
        local pct, months, depositIndex, termIndex = self:getMortgageSelection()
        local evaluation = m.propertyFinance:evaluateMortgage(g_currentMission:getFarmId(), self.farmlandId, pct, months)
        if evaluation.reason == "farmland_not_for_sale" then
            InfoDialog.show(g_i18n:getText("rff_farmland_not_for_sale"))
            return
        end
        if evaluation.reason == "funds" then
            InfoDialog.show(g_i18n:getText("rff_mortgage_insufficient_deposit"))
            return
        end
        if evaluation.price == nil or evaluation.principal == nil then
            InfoDialog.show(g_i18n:getText("rff_application_changed"))
            return
        end
        self.pendingMortgage = {pct=pct, months=months, depositIndex=depositIndex, termIndex=termIndex, evaluation=evaluation}
        self.pendingConfirmation = true
        local indicativeRate = (evaluation.interestRate or 0) > 0 and string.format("%.2f%%", evaluation.interestRate) or "-"
        local indicativePayment = (evaluation.monthlyPayment or 0) > 0 and formatMoney(evaluation.monthlyPayment) or "-"
        local text = string.format(g_i18n:getText("rff_mortgage_application_confirm"),
            formatMoney(evaluation.price), formatMoney(evaluation.deposit), formatMoney(evaluation.principal), math.floor(months / 12), indicativeRate, indicativePayment)
        YesNoDialog.show(self.onMortgageConfirmed, self, text, g_i18n:getText("rff_mortgage_application_title"))
    elseif self.mode == self.MODE_TENANCY then
        local months, termIndex = self:getTenancySelection()
        local offer = m.propertyFinance:getTenancyOffer(self.farmlandId, months)
        if offer == nil then
            InfoDialog.show(g_i18n:getText("rff_farmland_not_for_sale"))
            return
        end
        if m.propertyFinance:getOpenTenancyApplicationForFarmland(self.farmlandId) ~= nil then
            InfoDialog.show(g_i18n:getText("rff_tenancy_existing_enquiry"))
            return
        end
        self.pendingTenancy = {months=months, termIndex=termIndex, offer=offer}
        self.pendingConfirmation = true
        local text = string.format(g_i18n:getText("rff_tenancy_enquiry_confirm"), self.farmlandId or 0, months)
        YesNoDialog.show(self.onTenancyConfirmed, self, text, g_i18n:getText("rff_tenancy_enquiry_title"))
    elseif self.mode == self.MODE_RENEWAL then
        local tenancy = self.renewalTenancy
        if tenancy == nil or tenancy.renewalOfferStatus ~= "OFFERED" then
            InfoDialog.show(g_i18n:getText("rff_application_changed"))
            return
        end
        local terms = self:getRenewalSelection()
        local proposalSummary = m.propertyFinance:getTenancyRenewalPackageSummary(terms)
        local landlordSummary = m.propertyFinance:getTenancyRenewalPackageSummary(
            m.propertyFinance:getTenancyRenewalTerms(tenancy, "renewalOffer"))
        self.pendingRenewal = {tenancy=tenancy, annualRent=self.renewalRent, terms=terms}
        self.pendingConfirmation = true
        local text = string.format(g_i18n:getText("rff_tenancy_package_confirm"), formatMoney(self.renewalRent),
            proposalSummary, formatMoney(tenancy.renewalOfferAnnualRent or 0), landlordSummary)
        YesNoDialog.show(self.onRenewalConfirmed, self, text, g_i18n:getText("rff_tenancy_negotiation_title"))
    end
end

function RFF_LandFinanceDialog:onMortgageConfirmed(accepted)
    self.pendingConfirmation = false
    if not accepted or self.pendingMortgage == nil then return end
    local pending = self.pendingMortgage
    self.pendingMortgage = nil
    local m = manager()
    if m == nil or m.applicationService == nil then return end

    local application, reason = m.applicationService:submitMortgageApplication(g_currentMission:getFarmId(), self.farmlandId, pending.pct, pending.months)
    if application == nil then
        if reason == "existing_open_application" then
            InfoDialog.show(g_i18n:getText("rff_application_existing_open"))
        elseif reason == "farmland_not_for_sale" then
            InfoDialog.show(g_i18n:getText("rff_farmland_not_for_sale"))
        elseif reason == "funds" then
            InfoDialog.show(g_i18n:getText("rff_mortgage_insufficient_deposit"))
        else
            InfoDialog.show(g_i18n:getText("rff_application_submit_failed"))
        end
        self:refreshMortgage()
        return
    end

    RFF_FarmlandMapExtension.selectedDownPaymentIndex = pending.depositIndex
    RFF_FarmlandMapExtension.selectedMortgageTermIndex = pending.termIndex
    self:close()
    local setupHint=RFF_NewSaveSetup and RFF_NewSaveSetup.isOpen(m.repository) and ("\n\n"..g_i18n:getText("rff_startup_mortgage_hint")) or ""
    InfoDialog.show(string.format(g_i18n:getText("rff_mortgage_application_submitted"), application.id or 0)..setupHint)
end

function RFF_LandFinanceDialog:onTenancyConfirmed(accepted)
    self.pendingConfirmation = false
    if not accepted or self.pendingTenancy == nil then return end
    local pending = self.pendingTenancy
    self.pendingTenancy = nil
    local m = manager()
    if m == nil then return end

    local farmId = g_currentMission:getFarmId()
    local tenancy, reason = m.propertyFinance:submitTenancyApplication(farmId, self.farmlandId, pending.months)
    if tenancy == nil then
        local existing = m.propertyFinance:getOpenTenancyApplicationForFarmland(self.farmlandId, farmId)
        if existing ~= nil and tonumber(existing.farmId) == tonumber(farmId) then
            RFF_FarmlandMapExtension.selectedTenancyTermIndex = pending.termIndex
            self:close()
            InfoDialog.show(string.format(g_i18n:getText("rff_tenancy_enquiry_submitted"), existing.applicationReference or existing.agreementId or "-"))
            print(string.format("[RealisticFarmFinance] Duplicate tenancy enquiry resolved as existing application farm=%d land=%d application=%d", farmId or 0, self.farmlandId or 0, existing.id or 0))
            return
        end

        if reason == "existing_open_application" then
            InfoDialog.show(g_i18n:getText("rff_tenancy_existing_enquiry"))
        elseif not m.propertyFinance:isFarmlandAvailableForAcquisition(self.farmlandId) then
            InfoDialog.show(g_i18n:getText("rff_farmland_not_for_sale"))
        else
            InfoDialog.show(g_i18n:getText("rff_application_changed"))
        end
        self:refreshTenancy()
        return
    end

    RFF_FarmlandMapExtension.selectedTenancyTermIndex = pending.termIndex
    self:close()
    local setupHint=RFF_NewSaveSetup and RFF_NewSaveSetup.isOpen(m.repository) and ("\n\n"..g_i18n:getText("rff_startup_tenancy_hint")) or ""
    InfoDialog.show(string.format(g_i18n:getText("rff_tenancy_enquiry_submitted"), tenancy.applicationReference or tenancy.agreementId or "-")..setupHint)
end

function RFF_LandFinanceDialog:onRenewalConfirmed(accepted)
    self.pendingConfirmation = false
    if not accepted then
        self.pendingRenewal = nil
        return
    end
    if self.pendingRenewal == nil then return end
    local pending = self.pendingRenewal
    self.pendingRenewal = nil
    local m = manager()
    if m == nil or m.propertyFinance == nil then return end

    local ok, reason, amount = m.propertyFinance:negotiateTenancyRenewal(pending.tenancy, pending.annualRent, pending.terms)
    if ok then
        local events = pending.tenancy.narrativeEvents or {}
        local latestEvent = events[#events]
        self:close()
        if self.callbackFrame ~= nil then
            self.callbackFrame.selectedTenancyNarrativeIndex = nil
            if self.callbackFrame.updatePropertyContent ~= nil then self.callbackFrame:updatePropertyContent() end
        end
        InfoDialog.show(latestEvent ~= nil and latestEvent.text or string.format(g_i18n:getText("rff_tenancy_negotiation_submitted_result"),
            formatMoney(amount or pending.annualRent), pending.tenancy.renewalLegalReference or "-"))
    else
        InfoDialog.show(string.format(g_i18n:getText("rff_tenancy_action_failed"), tostring(reason or "unavailable"):gsub("_", " ")))
        self:refreshRenewal()
    end
end

function RFF_LandFinanceDialog:onClickBack()
    self:close()
end

function RFF_LandFinanceDialog.showMortgage(frame, farmlandId)
    local gui = g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFLandFinanceDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configureMortgage(frame, farmlandId) then return false end
    g_gui:showDialog("RFFLandFinanceDialog")
    return true
end

function RFF_LandFinanceDialog.showTenancy(frame, farmlandId)
    local gui = g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFLandFinanceDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configureTenancy(frame, farmlandId) then return false end
    g_gui:showDialog("RFFLandFinanceDialog")
    return true
end

function RFF_LandFinanceDialog.showRenewal(frame, tenancy, annualRent)
    local gui = g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFLandFinanceDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configureRenewal(frame, tenancy, annualRent) then return false end
    g_gui:showDialog("RFFLandFinanceDialog")
    return true
end
