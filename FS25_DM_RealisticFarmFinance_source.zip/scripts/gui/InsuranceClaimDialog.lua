RFF_InsuranceClaimDialog = {}
local RFF_InsuranceClaimDialog_mt = Class(RFF_InsuranceClaimDialog, MessageDialog)

RFF_InsuranceClaimDialog.CONTROLS = {
    "paperBackground", "deathOption", "deathDisplayText", "deathLeftArrowText", "deathRightArrowText",
    "farmNameValue", "policyCoverValue", "policyStatusValue",
    "incidentDateValue", "animalValue", "breedValue", "ageValue",
    "causeValue", "recordedValueValue", "excessValue", "claimAmountValue",
    "declarationText", "signatureButton", "signatureAnchor", "submitButton", "formNote"
}

local MONTHS = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then option:setState(state, false) else option.state = state end
end

local function setDisabled(control, disabled)
    if control ~= nil and control.setDisabled ~= nil then control:setDisabled(disabled == true) end
end

local function formatMoney(value)
    if g_i18n ~= nil and g_i18n.formatMoney ~= nil then
        return g_i18n:formatMoney(value or 0, 0, true, true)
    end
    return string.format("£%.0f", value or 0)
end

local function humanize(value)
    local text = tostring(value or "")
    if text == "" then return "-" end
    text = text:gsub("_", " "):lower()
    return (text:gsub("(%a)([%w']*)", function(a, b) return string.upper(a) .. b end))
end

local function wrapText(text, maxChars)
    if text == nil then return "" end
    maxChars = maxChars or 76
    local wrapped = {}
    for sourceLine in (tostring(text) .. "\n"):gmatch("(.-)\n") do
        if sourceLine == "" then
            table.insert(wrapped, "")
        else
            local line = ""
            for word in sourceLine:gmatch("%S+") do
                if line == "" then line = word
                elseif #line + #word + 1 <= maxChars then line = line .. " " .. word
                else table.insert(wrapped, line); line = word end
            end
            if line ~= "" then table.insert(wrapped, line) end
        end
    end
    return table.concat(wrapped, "\n")
end

local function getCurrentPlayerName()
    local mission = g_currentMission
    local player = g_localPlayer or (mission ~= nil and mission.player or nil)
    if mission ~= nil and mission.userManager ~= nil and player ~= nil and player.userId ~= nil then
        local user = mission.userManager:getUserByUserId(player.userId)
        if user ~= nil and user.getNickname ~= nil then
            local nickname = user:getNickname()
            if type(nickname) == "string" and nickname:match("%S") ~= nil then return nickname end
        end
    end
    if player ~= nil and type(player.nickname) == "string" and player.nickname:match("%S") ~= nil then return player.nickname end
    return nil
end


local function incidentDateLabel(loss)
    if loss == nil then return "-" end
    local service = manager() ~= nil and manager().insuranceClaims or nil
    local daysPerPeriod = service ~= nil and service:getDaysPerPeriod() or 1
    local day = math.max(1, ((math.floor(tonumber(loss.incidentDay) or 1) - 1) % math.max(1, daysPerPeriod)) + 1)
    local periodIndex = math.max(0, math.floor(tonumber(loss.incidentPeriod) or 0))
    local year = math.floor(math.max(0, periodIndex - 1) / 12)
    local seasonPeriod = ((math.max(1, periodIndex) - 1) % 12) + 1
    local calendarMonth = ((seasonPeriod + 1) % 12) + 1
    local monthName = g_i18n ~= nil and g_i18n.formatPeriod ~= nil and g_i18n:formatPeriod(seasonPeriod, false) or MONTHS[calendarMonth]
    return string.format("Day %d, %s — Year %d", day, monthName, year)
end

local function drawHandwrittenControl(renderer, control, text, options)
    if renderer == nil or control == nil or text == nil or text == "" then return end
    local pos = control.absPosition or control.position
    local size = control.absSize or control.size
    if pos == nil or size == nil then return end
    renderer:draw(text, pos[1], pos[2], size[1], size[2], options)
end

function RFF_InsuranceClaimDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or RFF_InsuranceClaimDialog_mt)
    self.callbackFrame = target
    self.eligibleDeaths = {}
    self.selectedLossId = nil
    self.signed = false
    self.signedBy = nil
    self.pendingLossId = nil
    self.handwritingRenderer = nil
    return self
end

function RFF_InsuranceClaimDialog:onLoad()
    RFF_InsuranceClaimDialog:superClass().onLoad(self)
    self:registerControls(RFF_InsuranceClaimDialog.CONTROLS)
end

function RFF_InsuranceClaimDialog:configure(frame)
    local m = manager()
    if m == nil or m.insuranceClaims == nil or g_currentMission == nil then return false end
    self.callbackFrame = frame
    local farmId = g_currentMission:getFarmId()
    self.eligibleDeaths = m.insuranceClaims:getEligibleDeathRecords(farmId)
    self.selectedLossId = nil
    self.signed = false
    self.signedBy = nil
    self.pendingLossId = nil
    return #self.eligibleDeaths > 0
end

function RFF_InsuranceClaimDialog:onOpen()
    RFF_InsuranceClaimDialog:superClass().onOpen(self)
    if RFF_RealisticFarmFinance ~= nil then
        if self.paperBackground ~= nil and self.paperBackground.setImageFilename ~= nil then
            self.paperBackground:setImageFilename(RFF_RealisticFarmFinance.modDirectory .. "images/insuranceClaimForm.dds")
        end
        if RFF_DocumentFontRenderer ~= nil and self.handwritingRenderer == nil then
            self.handwritingRenderer = RFF_DocumentFontRenderer.new(
                RFF_RealisticFarmFinance.modDirectory .. "fonts/derwen_handwriting/font.xml",
                RFF_RealisticFarmFinance.modDirectory
            )
        end
    end
    self:rebuildDeathOption()
    self:refresh()
    if self.deathOption ~= nil then FocusManager:setFocus(self.deathOption) end
end

function RFF_InsuranceClaimDialog:onClose()
    self.pendingLossId = nil
    RFF_InsuranceClaimDialog:superClass().onClose(self)
end

function RFF_InsuranceClaimDialog:delete()
    if self.handwritingRenderer ~= nil then
        self.handwritingRenderer:delete()
        self.handwritingRenderer = nil
    end
    RFF_InsuranceClaimDialog:superClass().delete(self)
end

function RFF_InsuranceClaimDialog:getFarmId()
    return g_currentMission ~= nil and g_currentMission:getFarmId() or 0
end

function RFF_InsuranceClaimDialog:getSelectedLoss()
    if self.deathOption == nil then return nil end
    local index = math.floor(self.deathOption.state or 1) - 1
    if index < 1 or index > #self.eligibleDeaths then return nil end
    return self.eligibleDeaths[index]
end

function RFF_InsuranceClaimDialog:getAnimalLabel(loss)
    if loss == nil then return "-" end
    local name = tostring(loss.animalName or "")
    local breedRaw = tostring(loss.animalBreed or "")
    if breedRaw == "" then breedRaw = tostring(loss.animalSubType or "") end
    local breed = humanize(breedRaw)
    local animalType = humanize(loss.animalType)
    if name ~= "" and breed ~= "-" then return string.format("%s (%s)", name, breed) end
    if name ~= "" then return name end
    if breed ~= "-" then return breed end
    return animalType
end

function RFF_InsuranceClaimDialog:getCauseText(reason)
    local keys = {
        ACCIDENT = "rff_claim_cause_accident",
        HEALTH = "rff_claim_cause_health",
        OLD_AGE = "rff_claim_cause_old_age",
        UNKNOWN = "rff_claim_cause_unknown"
    }
    local key = keys[tostring(reason or "UNKNOWN")] or keys.UNKNOWN
    return g_i18n ~= nil and g_i18n:getText(key) or humanize(reason)
end

function RFF_InsuranceClaimDialog:getTierText(tierId)
    local m = manager()
    local tier = m ~= nil and m.businessAdministration ~= nil and m.businessAdministration:getTierConfig(tierId) or nil
    if tier ~= nil and g_i18n ~= nil then return g_i18n:getText(tier.key) end
    return humanize(tierId)
end

function RFF_InsuranceClaimDialog:getPolicyStatusText(status)
    local key = "rff_claim_form_policy_status_" .. string.lower(tostring(status or "unknown"))
    if g_i18n ~= nil then
        local text = g_i18n:getText(key)
        if text ~= nil and text ~= key then return text end
    end
    return humanize(status)
end

function RFF_InsuranceClaimDialog:rebuildDeathOption()
    if self.deathOption == nil then return end
    -- Keep the native MultiTextOption responsible only for state/navigation.
    -- Its text is intentionally blank because the document supplies its own
    -- precisely aligned display text and arrow overlays. This avoids the faint
    -- focused/selected GIANTS option text bleeding through the paper form.
    local texts = {" "}
    for _ in ipairs(self.eligibleDeaths or {}) do
        texts[#texts + 1] = " "
    end
    if self.deathOption.setTexts ~= nil then self.deathOption:setTexts(texts) else self.deathOption.texts = texts end
    setOptionState(self.deathOption, 1)
end

function RFF_InsuranceClaimDialog:onDeathChanged()
    local loss = self:getSelectedLoss()
    self.selectedLossId = loss ~= nil and loss.id or nil
    self.signed = false
    self.signedBy = nil
    self:refresh()
end

function RFF_InsuranceClaimDialog:refresh()
    local farmId = self:getFarmId()
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    local farmName = farm ~= nil and (farm.name or ("Farm " .. tostring(farmId))) or ("Farm " .. tostring(farmId))
    if self.farmNameValue ~= nil then self.farmNameValue:setText(farmName) end

    local loss = self:getSelectedLoss()
    if self.deathDisplayText ~= nil then
        self.deathDisplayText:setText(loss ~= nil and self:getAnimalLabel(loss) or g_i18n:getText("rff_claim_form_select_placeholder"))
    end

    local hasLoss = loss ~= nil
    if self.policyCoverValue ~= nil then self.policyCoverValue:setText(hasLoss and self:getTierText(loss.policyTier) or "-") end
    if self.policyStatusValue ~= nil then self.policyStatusValue:setText(hasLoss and self:getPolicyStatusText(loss.policyStatusAtIncident) or "-") end
    if self.incidentDateValue ~= nil then self.incidentDateValue:setText(hasLoss and incidentDateLabel(loss) or "-") end
    if self.animalValue ~= nil then self.animalValue:setText(hasLoss and humanize(loss.animalType) or "-") end
    if self.breedValue ~= nil then
        local breedRaw = hasLoss and tostring(loss.animalBreed or "") or ""
        if hasLoss and breedRaw == "" then breedRaw = tostring(loss.animalSubType or "") end
        self.breedValue:setText(hasLoss and humanize(breedRaw) or "-")
    end
    if self.ageValue ~= nil then self.ageValue:setText(hasLoss and string.format(g_i18n:getText("rff_claim_form_age_value"), loss.animalAge or 0) or "-") end
    if self.causeValue ~= nil then self.causeValue:setText(hasLoss and self:getCauseText(loss.deathReason) or "-") end
    if self.recordedValueValue ~= nil then self.recordedValueValue:setText(hasLoss and formatMoney(loss.incidentValue or 0) or "-") end

    local terms = hasLoss and manager().insuranceClaims:getTerms(loss.policyTier) or nil
    if self.excessValue ~= nil then self.excessValue:setText(hasLoss and formatMoney(terms ~= nil and terms.excess or 0) or "-") end
    if self.claimAmountValue ~= nil then self.claimAmountValue:setText(hasLoss and formatMoney(loss.incidentValue or 0) or "-") end

    if self.declarationText ~= nil then
        self.declarationText:setText(wrapText(g_i18n:getText("rff_claim_form_declaration"), 90))
    end
    if self.formNote ~= nil then
        local noteKey = hasLoss and "rff_claim_form_note_selected" or "rff_claim_form_note_select"
        self.formNote:setText(wrapText(g_i18n:getText(noteKey), 92))
    end

    if self.signatureButton ~= nil then
        self.signatureButton:setVisible(true)
        self.signatureButton:setText(self.signed and "" or g_i18n:getText("rff_claim_form_click_to_sign"))
        setDisabled(self.signatureButton, not hasLoss)
    end
    if self.submitButton ~= nil then
        setDisabled(self.submitButton, not hasLoss or not self.signed)
    end
end

function RFF_InsuranceClaimDialog:onDrawHandwriting(element)
    if self.handwritingRenderer == nil or not self.signed or self.signedBy == nil then return end
    drawHandwrittenControl(self.handwritingRenderer, self.signatureAnchor or self.signatureButton, self.signedBy, {
        lineHeightPx = 24, minLineHeightPx = 18, align = "center",
        color = {0.018, 0.018, 0.022, 1.0}, jitterPx = 0.22,
        fitToWidth = true, paddingPx = 8, offsetYPx = -2, clip = false
    })
end

function RFF_InsuranceClaimDialog:onClickSign()
    local loss = self:getSelectedLoss()
    if loss == nil then
        InfoDialog.show(g_i18n:getText("rff_claim_form_select_first"))
        return
    end
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(self:getFarmId()) or nil
    self.signedBy = getCurrentPlayerName() or (farm ~= nil and farm.name) or "Farm Manager"
    self.signed = true
    self:refresh()
end

function RFF_InsuranceClaimDialog:onClickSubmit()
    local loss = self:getSelectedLoss()
    if loss == nil then
        InfoDialog.show(g_i18n:getText("rff_claim_form_select_first"))
        return
    end
    if not self.signed then
        InfoDialog.show(g_i18n:getText("rff_claim_form_sign_first"))
        return
    end
    self.pendingLossId = loss.id
    local text = string.format(
        g_i18n:getText("rff_claim_form_submit_confirm"),
        self:getAnimalLabel(loss),
        formatMoney(loss.incidentValue or 0),
        self:getCauseText(loss.deathReason),
        self:getTierText(loss.policyTier)
    )
    YesNoDialog.show(self.onSubmitConfirmed, self, text, g_i18n:getText("rff_claim_form_title"))
end

function RFF_InsuranceClaimDialog:onSubmitConfirmed(confirmed)
    if not confirmed or self.pendingLossId == nil then self.pendingLossId = nil; return end
    local lossId = self.pendingLossId
    self.pendingLossId = nil
    local m = manager()
    if m == nil or m.insuranceClaims == nil then return end
    local ok, reason, claim = m.insuranceClaims:initiateClaim(self:getFarmId(), lossId, {signedBy = self.signedBy})
    if not ok then
        if reason == "expired" then InfoDialog.show(g_i18n:getText("rff_claim_window_expired"))
        elseif reason == "not_server" then InfoDialog.show(g_i18n:getText("rff_claim_server_only"))
        else InfoDialog.show(g_i18n:getText("rff_claim_submit_failed")) end
        return
    end

    if self.callbackFrame ~= nil and self.callbackFrame.updateInsuranceClaimsContent ~= nil then
        self.callbackFrame:updateInsuranceClaimsContent(true)
    end
    self:close()
    InfoDialog.show(string.format(g_i18n:getText("rff_claim_form_submitted_reference"), m.insuranceClaims:getClaimReference(claim)))
end

function RFF_InsuranceClaimDialog:onClickBack()
    self:close()
end

function RFF_InsuranceClaimDialog.show(frame)
    local gui = g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFInsuranceClaimDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configure(frame) then return false end
    g_gui:showDialog("RFFInsuranceClaimDialog")
    return true
end
