RFF_SecurityReleaseDialog = {}
local RFF_SecurityReleaseDialog_mt = Class(RFF_SecurityReleaseDialog, MessageDialog)

RFF_SecurityReleaseDialog.CONTROLS = {
    "securityOption", "debtValue", "currentSecurityValue", "releaseValue", "remainingValue",
    "postLtvValue", "limitValue", "decisionValue", "confirmButton"
}

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function formatMoney(value)
    return g_i18n:formatMoney(value or 0, 0, true, true)
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then option:setState(state, false) else option.state = state end
end

function RFF_SecurityReleaseDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or RFF_SecurityReleaseDialog_mt)
    self.callbackFrame = target
    self.loan = nil
    self.securityIds = {}
    self.lastEvaluation = nil
    return self
end

function RFF_SecurityReleaseDialog:onLoad()
    RFF_SecurityReleaseDialog:superClass().onLoad(self)
    self:registerControls(RFF_SecurityReleaseDialog.CONTROLS)
end

function RFF_SecurityReleaseDialog:configure(frame, loan)
    local m=manager()
    if m == nil or m.propertyFinance == nil or loan == nil then return false end
    self.callbackFrame=frame
    self.loan=loan
    self.securityIds=m.propertyFinance:getMortgageSecurityFarmlandIds(loan)
    return #self.securityIds >= 2
end

function RFF_SecurityReleaseDialog:onOpen()
    RFF_SecurityReleaseDialog:superClass().onOpen(self)
    self:rebuildOptions()
    self:refresh()
end

function RFF_SecurityReleaseDialog:onClose()
    self.loan=nil
    self.securityIds={}
    RFF_SecurityReleaseDialog:superClass().onClose(self)
end

function RFF_SecurityReleaseDialog:rebuildOptions()
    local m=manager()
    if m == nil or m.propertyFinance == nil or self.loan == nil then return end
    self.securityIds=m.propertyFinance:getMortgageSecurityFarmlandIds(self.loan)
    local texts={}
    for _,id in ipairs(self.securityIds) do
        local farmland=m.propertyFinance:getFarmland(id)
        table.insert(texts,string.format("Land %d   (%s)",id,formatMoney(farmland ~= nil and farmland.price or 0)))
    end
    if self.securityOption ~= nil then self.securityOption:setTexts(texts); setOptionState(self.securityOption,1) end
end

function RFF_SecurityReleaseDialog:getSelectedFarmlandId()
    if #self.securityIds == 0 then return 0 end
    local index=math.max(1,math.min(#self.securityIds,self.securityOption ~= nil and (self.securityOption.state or 1) or 1))
    return self.securityIds[index]
end

function RFF_SecurityReleaseDialog:onOptionChanged()
    self:refresh()
end

function RFF_SecurityReleaseDialog:refresh()
    local m=manager()
    if m == nil or m.propertyFinance == nil or self.loan == nil then return end
    local evaluation=m.propertyFinance:evaluateSecurityRelease(self.loan,self:getSelectedFarmlandId())
    self.lastEvaluation=evaluation
    if self.debtValue ~= nil then self.debtValue:setText(formatMoney(evaluation.debt or 0)) end
    if self.currentSecurityValue ~= nil then self.currentSecurityValue:setText(formatMoney(evaluation.currentSecurityValue or 0)) end
    if self.releaseValue ~= nil then self.releaseValue:setText(formatMoney(evaluation.releasedValue or 0)) end
    if self.remainingValue ~= nil then self.remainingValue:setText(formatMoney(evaluation.remainingSecurityValue or 0)) end
    if self.postLtvValue ~= nil then self.postLtvValue:setText(evaluation.postReleaseLtv ~= math.huge and string.format("%.1f%%",(evaluation.postReleaseLtv or 0)*100) or "-") end
    if self.limitValue ~= nil then self.limitValue:setText(string.format("%.1f%%",(evaluation.releaseLtvLimit or 0)*100)) end
    if self.decisionValue ~= nil then
        self.decisionValue:setText(g_i18n:getText(evaluation.approved and "rff_security_release_supportable" or "rff_security_release_not_supportable"))
    end
    if self.confirmButton ~= nil and self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(not evaluation.approved) end
end

function RFF_SecurityReleaseDialog:onClickConfirm()
    if self.loan == nil or self.lastEvaluation == nil or not self.lastEvaluation.approved then return end
    local farmlandId=self:getSelectedFarmlandId()
    self.pendingFarmlandId=farmlandId
    local text=string.format(g_i18n:getText("rff_security_release_confirm"),farmlandId,formatMoney(self.lastEvaluation.releasedValue or 0),formatMoney(self.lastEvaluation.remainingSecurityValue or 0),(self.lastEvaluation.postReleaseLtv or 0)*100)
    YesNoDialog.show(self.onConfirmed,self,text,g_i18n:getText("rff_security_release_title"))
end

function RFF_SecurityReleaseDialog:onConfirmed(accepted)
    local farmlandId=self.pendingFarmlandId or 0
    self.pendingFarmlandId=nil
    if not accepted or self.loan == nil then return end
    local m=manager()
    local ok,reason,evaluation=m.propertyFinance:releaseSecurityParcel(self.loan,farmlandId)
    if ok then
        self:close()
        InfoDialog.show(string.format(g_i18n:getText("rff_security_release_complete"),farmlandId,formatMoney(evaluation.remainingSecurityValue or 0)))
        if self.callbackFrame ~= nil and self.callbackFrame.updateContent ~= nil then self.callbackFrame:updateContent() end
    else
        InfoDialog.show(g_i18n:getText("rff_security_release_failed"))
        self:rebuildOptions(); self:refresh()
    end
end

function RFF_SecurityReleaseDialog:onClickBack()
    self:close()
end

function RFF_SecurityReleaseDialog.show(frame,loan)
    local gui=g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFSecurityReleaseDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configure(frame,loan) then return false end
    g_gui:showDialog("RFFSecurityReleaseDialog")
    return true
end
