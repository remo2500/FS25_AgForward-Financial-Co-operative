-- RFF-local bitmap document font renderer.
-- The font XML/metric model and Unicode/fallback handling are adapted from
-- Arrow's FS25 FontLibrary with permission, but this renderer is deliberately
-- scoped to Realistic Farm Finance and does not replace GIANTS global text APIs.

RFF_DocumentFontRenderer = {}
RFF_DocumentFontRenderer.__index = RFF_DocumentFontRenderer

local CLOSEST_CHARACTERS = {
    [192]=65,[193]=65,[194]=65,[195]=65,[196]=65,[197]=65,
    [199]=67,
    [200]=69,[201]=69,[202]=69,[203]=69,
    [204]=73,[205]=73,[206]=73,[207]=73,
    [209]=78,
    [210]=79,[211]=79,[212]=79,[213]=79,[214]=79,
    [217]=85,[218]=85,[219]=85,[220]=85,
    [224]=97,[225]=97,[226]=97,[227]=97,[228]=97,[229]=97,
    [231]=99,
    [232]=101,[233]=101,[234]=101,[235]=101,
    [236]=105,[237]=105,[238]=105,[239]=105,
    [241]=110,
    [242]=111,[243]=111,[244]=111,[245]=111,[246]=111,
    [249]=117,[250]=117,[251]=117,[252]=117,
    [8216]=39,[8217]=39,[8218]=39,
    [8220]=34,[8221]=34,[8222]=34,
    [8211]=45,[8212]=45,
    [8230]=46
}

local SPACE_CODEPOINTS = {
    [32]=true, [160]=true, [8192]=true, [8193]=true, [8194]=true,
    [8195]=true, [8196]=true, [8197]=true, [8198]=true, [8199]=true,
    [8200]=true, [8201]=true, [8202]=true, [8239]=true, [8287]=true
}

local function getNormPixels(px, py)
    if getNormalizedScreenValues ~= nil then
        return getNormalizedScreenValues(px or 0, py or 0)
    end
    local sw = g_screenWidth or 1920
    local sh = g_screenHeight or 1080
    return (px or 0) / sw, (py or 0) / sh
end

local function utf8Codepoints(text)
    text = tostring(text or "")
    local result = {}
    local i, n = 1, #text
    while i <= n do
        local b1 = text:byte(i)
        local code, size
        if b1 < 0x80 then
            code, size = b1, 1
        elseif b1 >= 0xC2 and b1 <= 0xDF and i + 1 <= n then
            local b2 = text:byte(i + 1)
            if b2 >= 0x80 and b2 <= 0xBF then
                code = (b1 - 0xC0) * 0x40 + (b2 - 0x80)
                size = 2
            end
        elseif b1 >= 0xE0 and b1 <= 0xEF and i + 2 <= n then
            local b2, b3 = text:byte(i + 1), text:byte(i + 2)
            if b2 >= 0x80 and b2 <= 0xBF and b3 >= 0x80 and b3 <= 0xBF then
                code = (b1 - 0xE0) * 0x1000 + (b2 - 0x80) * 0x40 + (b3 - 0x80)
                size = 3
            end
        elseif b1 >= 0xF0 and b1 <= 0xF4 and i + 3 <= n then
            local b2, b3, b4 = text:byte(i + 1), text:byte(i + 2), text:byte(i + 3)
            if b2 >= 0x80 and b2 <= 0xBF and b3 >= 0x80 and b3 <= 0xBF and b4 >= 0x80 and b4 <= 0xBF then
                code = (b1 - 0xF0) * 0x40000 + (b2 - 0x80) * 0x1000 + (b3 - 0x80) * 0x40 + (b4 - 0x80)
                size = 4
            end
        end
        if code ~= nil then
            result[#result + 1] = code
            i = i + size
        else
            -- Invalid byte: skip it rather than drawing a row of fallback marks.
            i = i + 1
        end
    end
    return result
end

local function lowerAsciiCode(code)
    if code >= 97 and code <= 122 then return code - 32 end
    return code
end

local function clipRect(x, y, w, h, minX, minY, maxX, maxY, uvs)
    if x >= maxX or y >= maxY or x + w <= minX or y + h <= minY then
        return nil
    end
    if x >= minX and y >= minY and x + w <= maxX and y + h <= maxY then
        return x, y, w, h, uvs
    end

    local leftCut = math.max(0, minX - x)
    local rightCut = math.max(0, (x + w) - maxX)
    local bottomCut = math.max(0, minY - y)
    local topCut = math.max(0, (y + h) - maxY)
    local newW = w - leftCut - rightCut
    local newH = h - bottomCut - topCut
    if newW <= 0 or newH <= 0 then return nil end

    local u0, v0, _, v1, u1 = uvs[1], uvs[2], uvs[3], uvs[4], uvs[5]
    local du = u1 - u0
    local dv = v1 - v0
    local leftRatio, rightRatio = leftCut / w, rightCut / w
    local bottomRatio, topRatio = bottomCut / h, topCut / h
    local nu0 = u0 + du * leftRatio
    local nu1 = u1 - du * rightRatio
    local nv0 = v0 + dv * bottomRatio
    local nv1 = v1 - dv * topRatio
    local clippedUVs = {nu0,nv0, nu0,nv1, nu1,nv0, nu1,nv1}

    return x + leftCut, y + bottomCut, newW, newH, clippedUVs
end

function RFF_DocumentFontRenderer.new(fontXmlFilename, baseDirectory)
    local self = setmetatable({}, RFF_DocumentFontRenderer)
    self.font = {
        characters = {},
        imageWidth = 1024,
        imageHeight = 1024,
        ascent = 53,
        descent = 15,
        lineHeight = 68,
        spaceAdvance = 19.312
    }
    self.overlay = nil
    self.valid = self:loadFont(fontXmlFilename, baseDirectory)
    return self
end

function RFF_DocumentFontRenderer:loadFont(fontXmlFilename, baseDirectory)
    local xmlFile = XMLFile.loadIfExists ~= nil and XMLFile.loadIfExists("rffDocumentFont", fontXmlFilename) or XMLFile.load("rffDocumentFont", fontXmlFilename)
    if xmlFile == nil then
        Logging.warning("[RealisticFarmFinance] Unable to load document font metrics '%s'", tostring(fontXmlFilename))
        return false
    end

    local font = self.font
    font.name = xmlFile:getString("font#name", "derwen_handwriting")
    font.imageWidth = xmlFile:getInt("font#imageWidth", 1024)
    font.imageHeight = xmlFile:getInt("font#imageHeight", 1024)
    font.ascent = xmlFile:getFloat("font#ascent", 53)
    font.descent = xmlFile:getFloat("font#descent", 15)
    font.lineHeight = xmlFile:getFloat("font#lineHeight", font.ascent + font.descent)
    font.spaceAdvance = xmlFile:getFloat("font#spaceAdvance", font.lineHeight * 0.28)

    local imageFilename = xmlFile:getString("font#image", "images/handwritingAtlas.dds")
    if Utils ~= nil and Utils.getFilename ~= nil then
        font.imageFilename = Utils.getFilename(imageFilename, baseDirectory or "")
    else
        font.imageFilename = (baseDirectory or "") .. imageFilename
    end

    xmlFile:iterate("font.character", function(_, key)
        local character = RFF_DocumentFontCharacter.new(font)
        if character:loadFromXMLFile(xmlFile, key) and character.code ~= nil then
            font.characters[character.code] = character
        end
    end)
    xmlFile:delete()

    self.overlay = Overlay.new(font.imageFilename, 0, 0, 0, 0)
    return self.overlay ~= nil and next(font.characters) ~= nil
end

function RFF_DocumentFontRenderer:delete()
    if self.overlay ~= nil then
        self.overlay:delete()
        self.overlay = nil
    end
end

function RFF_DocumentFontRenderer:getCharacter(code)
    if code == nil or SPACE_CODEPOINTS[code] then return nil, true end
    local character = self.font.characters[code]
    if character ~= nil then return character, false end
    local fallback = CLOSEST_CHARACTERS[code]
    if fallback ~= nil and self.font.characters[fallback] ~= nil then
        return self.font.characters[fallback], false
    end
    local upper = lowerAsciiCode(code)
    if self.font.characters[upper] ~= nil then return self.font.characters[upper], false end
    return self.font.characters[63], false -- '?' only for a genuinely unsupported printable glyph
end

function RFF_DocumentFontRenderer:measure(text, lineHeightPx, spacingPx)
    lineHeightPx = lineHeightPx or 24
    spacingPx = spacingPx or 0
    local scale = lineHeightPx / math.max(self.font.lineHeight, 1)
    local codepoints = utf8Codepoints(text)
    local widthPx = 0
    for i, code in ipairs(codepoints) do
        if SPACE_CODEPOINTS[code] then
            widthPx = widthPx + self.font.spaceAdvance * scale
        else
            local character = self:getCharacter(code)
            if character ~= nil then widthPx = widthPx + character.advance * scale end
        end
        if i < #codepoints then widthPx = widthPx + spacingPx end
    end
    local widthNorm = getNormPixels(widthPx, 0)
    return widthNorm, widthPx
end

function RFF_DocumentFontRenderer:draw(text, x, y, width, height, options)
    if not self.valid or self.overlay == nil or text == nil or text == "" then return end
    options = options or {}

    local lineHeightPx = options.lineHeightPx or 24
    local spacingPx = options.spacingPx or 0
    local paddingPx = options.paddingPx or 0
    local minLineHeightPx = options.minLineHeightPx or math.max(11, lineHeightPx * 0.70)
    local paddingNormX = getNormPixels(paddingPx, 0)
    local availableWidth = math.max(0, width - paddingNormX * 2)

    if options.fitToWidth == true and availableWidth > 0 then
        local measuredNorm = self:measure(text, lineHeightPx, spacingPx)
        if measuredNorm > availableWidth and measuredNorm > 0 then
            lineHeightPx = math.max(minLineHeightPx, lineHeightPx * availableWidth / measuredNorm)
        end
    end

    local font = self.font
    local scale = lineHeightPx / math.max(font.lineHeight, 1)
    local lineHeightNormY = select(2, getNormPixels(0, lineHeightPx))
    local descentNormY = select(2, getNormPixels(0, font.descent * scale))
    local offsetYNorm = select(2, getNormPixels(0, options.offsetYPx or 0))
    local baselineY = y + (height - lineHeightNormY) * 0.5 + descentNormY + offsetYNorm

    local totalNormX = self:measure(text, lineHeightPx, spacingPx)
    local penX = x + paddingNormX
    local align = options.align or "left"
    if align == "right" then
        penX = x + width - paddingNormX - totalNormX
    elseif align == "center" then
        penX = x + (width - totalNormX) * 0.5
    end
    penX = penX + getNormPixels(options.offsetXPx or 0, 0)

    local r,g,b,a = 0.06,0.12,0.18,1
    if options.color ~= nil then
        r = options.color[1] or r; g = options.color[2] or g; b = options.color[3] or b; a = options.color[4] or a
    end
    self.overlay:setColor(r,g,b,a)

    local codepoints = utf8Codepoints(text)
    local jitterPx = options.jitterPx or 0
    local minX, minY, maxX, maxY = x, y, x + width, y + height

    for i, code in ipairs(codepoints) do
        if SPACE_CODEPOINTS[code] then
            penX = penX + getNormPixels(font.spaceAdvance * scale + spacingPx, 0)
        else
            local character = self:getCharacter(code)
            if character ~= nil then
                if character.width > 0 and character.height > 0 then
                    local glyphWidthNorm, glyphHeightNorm = getNormPixels(character.width * scale, character.height * scale)
                    local leftNorm = getNormPixels(character.left * scale, 0)
                    local bottomNorm = select(2, getNormPixels(0, character.bottom * scale))
                    local jitterNorm = 0
                    if jitterPx > 0 then
                        local wave = math.sin((i * 12.9898) + (code or 0) * 0.31)
                        jitterNorm = select(2, getNormPixels(0, wave * jitterPx))
                    end
                    local gx = penX + leftNorm
                    local gy = baselineY - bottomNorm + jitterNorm
                    local guvs = character.uvs
                    if options.clip ~= false then
                        gx, gy, glyphWidthNorm, glyphHeightNorm, guvs = clipRect(gx, gy, glyphWidthNorm, glyphHeightNorm, minX, minY, maxX, maxY, guvs)
                    end
                    if gx ~= nil then
                        self.overlay:setUVs(guvs)
                        self.overlay:setPosition(gx, gy)
                        self.overlay:setDimension(glyphWidthNorm, glyphHeightNorm)
                        self.overlay:render()
                    end
                end
                penX = penX + getNormPixels(character.advance * scale + spacingPx, 0)
            end
        end
    end
end
