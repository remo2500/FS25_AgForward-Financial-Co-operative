RFF_AssetFinanceDialog = {}
local RFF_AssetFinanceDialog_mt = Class(RFF_AssetFinanceDialog, MessageDialog)

RFF_AssetFinanceDialog.CONTROLS = {
    "titleText", "subtitleText", "productOption", "depositOption", "termOption", "balloonOption", "balloonLabel",
    "providerValue", "priceValue", "depositValue", "financeValue", "rateValue", "monthlyValue", "balloonValue", "totalCostValue",
    "gradeValue", "assessmentText", "adviceText", "decisionValue", "confirmButton"
}

RFF_AssetFinanceDialog.PRODUCTS = {
    RFF_AssetFinanceService.TYPE_HIRE_PURCHASE,
    RFF_AssetFinanceService.TYPE_BALLOON,
    RFF_AssetFinanceService.TYPE_OPERATING_LEASE
}

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function formatMoney(value)
    return g_i18n:formatMoney(value or 0, 0, true, true)
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then option:setState(state, false) else option.state = state end
end

local function formatMonths(value)
    if value == nil or value == math.huge then return "Very strong" end
    return string.format("%.0f months", math.max(0, value))
end

local function getSecurityText(strength)
    local key = "rff_asset_security_unknown"
    if strength == "strong" then key = "rff_asset_security_strong"
    elseif strength == "moderate" then key = "rff_asset_security_moderate"
    elseif strength == "weak" then key = "rff_asset_security_weak" end
    return g_i18n:getText(key)
end

local function getBasisText(basis)
    if basis == "lease_liquidity_security" then return g_i18n:getText("rff_asset_basis_lease_liquidity") end
    if basis == "asset_security_liquidity" then return g_i18n:getText("rff_asset_basis_asset_liquidity") end
    return g_i18n:getText("rff_asset_basis_standard")
end

local function wrapText(text, maxChars)
    if text == nil then return "" end
    maxChars = maxChars or 88
    local wrapped = {}
    for sourceLine in (tostring(text) .. "\n"):gmatch("(.-)\n") do
        if sourceLine == "" then
            table.insert(wrapped, "")
        else
            local line = ""
            for word in sourceLine:gmatch("%S+") do
                if line == "" then
                    line = word
                elseif #line + #word + 1 <= maxChars then
                    line = line .. " " .. word
                else
                    table.insert(wrapped, line)
                    line = word
                end
            end
            if line ~= "" then table.insert(wrapped, line) end
        end
    end
    return table.concat(wrapped, "\n")
end

function RFF_AssetFinanceDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or RFF_AssetFinanceDialog_mt)
    self.storeItem = nil
    self.configurations = nil
    self.configurationData = nil
    self.licensePlateData = nil
    self.saleItem = nil
    self.purchaseContext = nil
    self.products = RFF_AssetFinanceDialog.PRODUCTS
    self.totalPrice = 0
    self.lastQuote = nil
    return self
end

function RFF_AssetFinanceDialog:onLoad()
    RFF_AssetFinanceDialog:superClass().onLoad(self)
    self:registerControls(RFF_AssetFinanceDialog.CONTROLS)
end

function RFF_AssetFinanceDialog:onOpen()
    RFF_AssetFinanceDialog:superClass().onOpen(self)
    self:refresh()
end

function RFF_AssetFinanceDialog:onClose()
    RFF_AssetFinanceDialog:superClass().onClose(self)
    self.purchaseContext = nil
    self.products = RFF_AssetFinanceDialog.PRODUCTS
end

function RFF_AssetFinanceDialog:setData(storeItem, configurations, licensePlateData, totalPrice, saleItem, configurationData, purchaseContext)
    self.storeItem = storeItem
    self.configurations = configurations or {}
    self.configurationData = configurationData or {}
    self.licensePlateData = licensePlateData
    self.saleItem = saleItem
    self.purchaseContext = purchaseContext
    self.products = (saleItem ~= nil or purchaseContext ~= nil)
        and {RFF_AssetFinanceService.TYPE_HIRE_PURCHASE}
        or RFF_AssetFinanceDialog.PRODUCTS
    self.totalPrice = math.max(0, totalPrice or 0)

    local m = manager()
    if m == nil or m.assetFinance == nil then return end

    local productTexts = {}
    for _, product in ipairs(self.products) do table.insert(productTexts, g_i18n:getText(m.assetFinance:getProductTextKey(product))) end
    self.productOption:setTexts(productTexts)
    setOptionState(self.productOption, 1)

    local depositTexts = {}
    for _, pct in ipairs(m.assetFinance.DEPOSIT_OPTIONS) do
        table.insert(depositTexts, string.format("%d%%   (%s)", pct, formatMoney(self.totalPrice * pct / 100)))
    end
    self.depositOption:setTexts(depositTexts)
    setOptionState(self.depositOption, 4)

    local termTexts = {}
    for _, months in ipairs(m.assetFinance.TERM_OPTIONS) do
        table.insert(termTexts, string.format("%d years (%d months)", math.floor(months / 12), months))
    end
    self.termOption:setTexts(termTexts)
    setOptionState(self.termOption, 4)

    local balloonTexts = {}
    for _, pct in ipairs(m.assetFinance.BALLOON_OPTIONS) do
        table.insert(balloonTexts, string.format("%d%%   (%s)", pct, formatMoney(self.totalPrice * pct / 100)))
    end
    self.balloonOption:setTexts(balloonTexts)
    setOptionState(self.balloonOption, 3)

    if self.titleText ~= nil then self.titleText:setText(g_i18n:getText("rff_asset_dialog_title")) end
    if self.subtitleText ~= nil then
        local subtitleKey = (saleItem ~= nil or purchaseContext ~= nil)
            and "rff_asset_dialog_subtitle_used"
            or "rff_asset_dialog_subtitle"
        self.subtitleText:setText(wrapText(g_i18n:getText(subtitleKey), 92))
    end
    self:refresh()
end

function RFF_AssetFinanceDialog:getSelection()
    local m = manager()
    if m == nil or m.assetFinance == nil then return nil end
    local products = self.products or self.PRODUCTS
    local pi = math.max(1, math.min(#products, self.productOption.state or 1))
    local di = math.max(1, math.min(#m.assetFinance.DEPOSIT_OPTIONS, self.depositOption.state or 1))
    local ti = math.max(1, math.min(#m.assetFinance.TERM_OPTIONS, self.termOption.state or 1))
    local bi = math.max(1, math.min(#m.assetFinance.BALLOON_OPTIONS, self.balloonOption.state or 1))
    return products[pi], m.assetFinance.DEPOSIT_OPTIONS[di], m.assetFinance.TERM_OPTIONS[ti], m.assetFinance.BALLOON_OPTIONS[bi]
end

function RFF_AssetFinanceDialog:onOptionChanged()
    self:refresh()
end

function RFF_AssetFinanceDialog:refresh()
    if self.storeItem == nil then return end
    local m = manager()
    if m == nil or m.assetFinance == nil or g_currentMission == nil then return end
    local product, depositPct, months, balloonPct = self:getSelection()
    if product == nil then return end
    local farmId = g_currentMission:getFarmId()
    local quote = m.assetFinance:evaluateQuote(farmId, self.totalPrice, depositPct, months, product, balloonPct)
    self.lastQuote = quote

    local isBalloon = product == RFF_AssetFinanceService.TYPE_BALLOON
    if self.balloonOption ~= nil then self.balloonOption:setVisible(isBalloon) end
    if self.balloonLabel ~= nil then self.balloonLabel:setVisible(isBalloon) end

    if self.providerValue ~= nil then
        if quote.lenderNameKey ~= nil and quote.lenderNameKey ~= "" then
            local providerName = g_i18n:getText(quote.lenderNameKey)
            local tierKey = "rff_relationship_" .. string.lower(quote.relationshipTier or "NEW")
            local providerTier = g_i18n:getText(tierKey)
            self.providerValue:setText(string.format("%s (%s)", providerName, providerTier))
        else
            self.providerValue:setText("-")
        end
    end
    self.priceValue:setText(formatMoney(quote.basePrice))
    self.depositValue:setText(formatMoney(quote.deposit))
    if product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
        self.financeValue:setText(g_i18n:getText("rff_asset_not_owned"))
        self.balloonValue:setText(formatMoney(quote.residualValue))
    else
        self.financeValue:setText(formatMoney(quote.amountFinanced))
        self.balloonValue:setText(isBalloon and formatMoney(quote.balloonAmount) or formatMoney(0))
    end
    self.rateValue:setText(quote.interestRate > 0 and string.format("%.2f%%", quote.interestRate) or "-")
    self.monthlyValue:setText(quote.monthlyPayment > 0 and formatMoney(quote.monthlyPayment) or "-")
    self.totalCostValue:setText(quote.totalCost > 0 and formatMoney(quote.totalCost) or "-")
    self.gradeValue:setText(quote.grade or "-")

    local stageText = quote.stageTextKey ~= nil and g_i18n:getText(quote.stageTextKey) or g_i18n:getText("rff_asset_assessment_unknown")
    local dscrText
    if quote.dscr == nil then
        dscrText = g_i18n:getText("rff_asset_assessment_dscr_startup")
    elseif quote.dscr == math.huge then
        dscrText = g_i18n:getText("rff_asset_assessment_dscr_no_commitments")
    else
        dscrText = string.format("%.2fx  (target %.2fx)", quote.dscr, quote.dscrTarget or 0.80)
    end

    local conductText = quote.paymentConduct ~= nil and g_i18n:getText(quote.paymentConduct.key or "rff_conduct_excellent") or g_i18n:getText("rff_conduct_excellent")
    local assessment = string.format(
        g_i18n:getText("rff_asset_assessment_summary"),
        stageText,
        quote.trackedPeriods or 0,
        conductText,
        formatMoney(quote.monthlyIncome),
        formatMoney(quote.existingMonthlyCommitments),
        dscrText,
        formatMoney(math.max(0, quote.cashAfterDeposit or 0)),
        formatMonths(quote.liquidityReserveMonths),
        getSecurityText(quote.securityStrength),
        getBasisText(quote.assessmentBasis)
    )
    if self.assessmentText ~= nil then self.assessmentText:setText(wrapText(assessment, 92)) end

    local adviceParts = {}
    if quote.approved then
        if quote.assessmentBasis == "lease_liquidity_security" then
            table.insert(adviceParts, g_i18n:getText("rff_asset_advice_approved_liquidity"))
        elseif quote.assessmentBasis == "asset_security_liquidity" then
            table.insert(adviceParts, g_i18n:getText("rff_asset_advice_approved_asset"))
        else
            table.insert(adviceParts, g_i18n:getText("rff_asset_advice_approved_standard"))
        end
    else
        if quote.reason == "payment_conduct" then
            table.insert(adviceParts, g_i18n:getText("rff_asset_advice_clear_arrears"))
        elseif (quote.additionalCashRequired or 0) > 0 then
            table.insert(adviceParts, string.format(g_i18n:getText("rff_asset_advice_more_cash"), formatMoney(quote.additionalCashRequired)))
        end
        if quote.reason ~= "payment_conduct" and quote.recommendedDepositPercent ~= nil and quote.recommendedDepositPercent > (quote.depositPercent or 0) then
            table.insert(adviceParts, string.format(g_i18n:getText("rff_asset_advice_deposit"), quote.recommendedDepositPercent, formatMoney(quote.recommendedDepositAmount)))
        end
        if quote.reason ~= "payment_conduct" and quote.recommendedTermMonths ~= nil then
            table.insert(adviceParts, string.format(g_i18n:getText("rff_asset_advice_term"), quote.recommendedTermMonths, formatMoney(quote.recommendedTermPayment)))
        end
        if quote.reason ~= "payment_conduct" and (quote.monthlyCommitmentReduction or 0) >= 1 then
            table.insert(adviceParts, string.format(g_i18n:getText("rff_asset_advice_commitments"), formatMoney(quote.monthlyCommitmentReduction)))
        end
        if quote.reason ~= "payment_conduct" and (quote.additionalLiquidityRequired or 0) >= 1 then
            table.insert(adviceParts, string.format(g_i18n:getText("rff_asset_advice_liquidity"), formatMoney(quote.additionalLiquidityRequired)))
        end
        if quote.reason ~= "payment_conduct" and (quote.trackedPeriods or 0) < 3 then
            table.insert(adviceParts, g_i18n:getText("rff_asset_advice_startup_history"))
        elseif (quote.trackedPeriods or 0) < 12 then
            table.insert(adviceParts, g_i18n:getText("rff_asset_advice_developing_history"))
        end
        if #adviceParts == 0 then
            table.insert(adviceParts, g_i18n:getText("rff_asset_advice_lower_asset"))
        end
    end
    if self.adviceText ~= nil then self.adviceText:setText(wrapText(table.concat(adviceParts, "\n"), 92)) end

    local decision
    if quote.approved then
        if product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
            if quote.assessmentBasis == "lease_liquidity_security" then
                decision = g_i18n:getText("rff_asset_quote_available_lease_liquidity")
            else
                decision = g_i18n:getText("rff_asset_quote_available_lease")
            end
        elseif quote.assessmentBasis == "asset_security_liquidity" then
            decision = g_i18n:getText("rff_asset_quote_available_liquidity")
        else
            decision = g_i18n:getText("rff_asset_quote_available")
        end
    elseif quote.reason == "funds" then
        decision = g_i18n:getText("rff_asset_quote_insufficient_deposit")
    elseif quote.reason == "deposit" then
        decision = string.format(g_i18n:getText("rff_asset_quote_more_deposit"), quote.minimumDepositPercent or 0)
    elseif quote.reason == "payment_conduct" then
        decision = g_i18n:getText("rff_asset_quote_declined_conduct")
    elseif quote.reason == "affordability" or quote.reason == "affordability_after_pricing" then
        decision = g_i18n:getText("rff_asset_quote_declined_affordability")
    else
        decision = g_i18n:getText("rff_asset_quote_declined")
    end
    self.decisionValue:setText(wrapText(decision, 94))
    if self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(not quote.approved) end
end

function RFF_AssetFinanceDialog:onClickConfirm()
    local quote = self.lastQuote
    if quote == nil or not quote.approved then return end
    local productName = g_i18n:getText(manager().assetFinance:getProductTextKey(quote.product))
    local extra = ""
    if quote.product == RFF_AssetFinanceService.TYPE_BALLOON then
        extra = string.format(g_i18n:getText("rff_asset_confirm_balloon_line"), formatMoney(quote.balloonAmount))
    elseif quote.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
        extra = string.format(g_i18n:getText("rff_asset_confirm_residual_line"), formatMoney(quote.residualValue))
    end
    local providerName = quote.lenderNameKey ~= nil and g_i18n:getText(quote.lenderNameKey) or g_i18n:getText("rff_lender_primary_bank")
    local text = string.format(g_i18n:getText("rff_asset_confirm_v601"), productName, providerName, formatMoney(quote.basePrice), formatMoney(quote.deposit), quote.months, quote.interestRate, formatMoney(quote.monthlyPayment), extra)
    YesNoDialog.show(self.onConfirmFinance, self, text, g_i18n:getText("rff_asset_dialog_title"))
end

function RFF_AssetFinanceDialog:createPurchaseData(quote, farmId)
    return {
        farmId = farmId,
        product = quote.product,
        basePrice = quote.basePrice,
        depositPercent = quote.depositPercent,
        deposit = quote.deposit,
        months = quote.months,
        balloonPercent = quote.balloonPercent,
        balloonAmount = quote.balloonAmount,
        residualValue = quote.residualValue,
        amountFinanced = quote.amountFinanced,
        interestRate = quote.interestRate,
        monthlyPayment = quote.monthlyPayment,
        grade = quote.grade,
        lenderId = quote.lenderId or "PRIMARY_BANK",
        lenderNameKey = quote.lenderNameKey or "rff_lender_primary_bank",
        marketState = quote.marketState or "SELECTIVE",
        dealFit = quote.dealFit or "STANDARD",
        vehicleName = self.storeItem ~= nil and (self.storeItem.name or "") or "",
        storeItemXml = self.storeItem ~= nil and (self.storeItem.xmlFilename or "") or ""
    }
end

function RFF_AssetFinanceDialog:onConfirmFinance(confirmed)
    if not confirmed or self.lastQuote == nil then return end
    local quote = self.lastQuote
    local farmId = self.purchaseContext ~= nil and self.purchaseContext.farmId
        or (g_shopController ~= nil and g_shopController.playerFarmId)
        or (g_currentMission ~= nil and g_currentMission:getFarmId())
    local purchaseData = self:createPurchaseData(quote, farmId)

    if self.purchaseContext ~= nil then
        local integration = RFF_UsedEquipmentYardsIntegration
        if integration == nil or integration.completeHirePurchase == nil then
            InfoDialog.show(g_i18n:getText("rff_asset_used_yard_unavailable"))
            return
        end
        local completed, reason, result = integration:completeHirePurchase(self.purchaseContext, purchaseData)
        if not completed then
            local key = "rff_asset_used_yard_error_" .. tostring(reason or "unknown")
            local message = g_i18n:getText(key)
            if message == nil or message == "" or message == key then
                message = g_i18n:getText("rff_asset_used_yard_error_unknown")
            end
            InfoDialog.show(message)
            return
        end
        self:close()
        InfoDialog.show(string.format(g_i18n:getText("rff_asset_used_yard_complete"),
            result.vehicleName or purchaseData.vehicleName,
            formatMoney(result.creditUsed or 0),
            formatMoney(result.deposit or purchaseData.deposit)))
        return
    end

    local screen = g_shopConfigScreen
    if screen == nil then return end

    local dealer = g_currentMission ~= nil and g_currentMission.dealerManager or nil
    if self.saleItem == nil and dealer ~= nil and self.storeItem ~= nil and dealer.isDealerStoreItem ~= nil and dealer:isDealerStoreItem(self.storeItem) then
        local stock = dealer.getStockLevel ~= nil and dealer:getStockLevel(self.storeItem.xmlFilename) or 1
        if stock <= 0 then
            InfoDialog.show(g_i18n:getText("rff_asset_dynamic_dealer_order_note"))
            return
        end
    end

    RFF_AssetFinanceShopExtension.pendingPurchaseData = purchaseData

    self:close()
    -- Use the normal shop callback rather than creating a parallel purchase path. This preserves dealer-stock hooks.
    screen:onCallback(false)
    if RFF_AssetFinanceShopExtension.pendingPurchaseData ~= nil then
        -- No BuyVehicleData was created (for example a factory/back order). Do not leak finance state into a later purchase.
        RFF_AssetFinanceShopExtension.pendingPurchaseData = nil
    end
end

function RFF_AssetFinanceDialog:onClickBack()
    self:close()
end
