RFF_TenancyManagementDialog = {}
local RFF_TenancyManagementDialog_mt = Class(RFF_TenancyManagementDialog, MessageDialog)

local REQUEST_TYPES = {"ENTERPRISE", "GRASS_CULTIVATION", "BOUNDARY_WORKS", "CAPITAL_IMPROVEMENT"}
local ENTERPRISE_TARGETS = {"MIXED", "ARABLE", "LIVESTOCK"}
local STATUS_KEYS = {
    RECEIVED="rff_tenancy_consent_status_received",
    PROFESSIONAL_REVIEW="rff_tenancy_consent_status_review",
    APPROVED="rff_tenancy_consent_status_approved",
    APPROVED_CONDITIONS="rff_tenancy_consent_status_conditional",
    DECLINED="rff_tenancy_consent_status_declined",
    TENANT_DECISION="rff_tenancy_variation_status_tenant_decision",
    ACCEPTED="rff_tenancy_variation_status_accepted",
    DECLINED_BY_TENANT="rff_tenancy_variation_status_declined",
    LANDLORD_NOTICE="rff_tenancy_variation_status_notice",
    NOTICE_RUNNING="rff_tenancy_variation_status_notice_running",
    IMPOSED="rff_tenancy_variation_status_imposed"
}

RFF_TenancyManagementDialog.CONTROLS = {
    "titleText", "subtitleText", "agreementValue", "covenantSummaryValue", "relationshipValue",
    "conditionSummaryValue", "alterationSummaryValue", "inspectionSummaryValue",
    "requestTypeOption", "requestTargetOption", "requirementValue", "latestReferenceValue",
    "latestStatusValue", "latestFeeValue", "latestDecisionValue", "confirmButton", "declineButton",
    "declineLeadingSeparator"
}

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then option:setState(state, false) else option.state = state end
end

local function setVisible(element, visible)
    if element == nil then return end
    if element.setVisible ~= nil then element:setVisible(visible) else element.visible = visible end
end

local function wrapText(text, maxChars)
    text = tostring(text or "")
    maxChars = maxChars or 76
    local lines = {}
    for sourceLine in (text .. "\n"):gmatch("(.-)\n") do
        local line = ""
        for word in sourceLine:gmatch("%S+") do
            if line == "" then line = word
            elseif #line + #word + 1 <= maxChars then line = line .. " " .. word
            else lines[#lines + 1] = line; line = word end
        end
        if line ~= "" then lines[#lines + 1] = line end
    end
    return table.concat(lines, "\n")
end

local function getCompactCovenantSummary(terms)
    terms = terms or {}
    local enterprise = tostring(terms.permittedEnterprise or "MIXED")
    local enterpriseText = enterprise == "ARABLE" and "Arable" or (enterprise == "LIVESTOCK" and "Livestock" or "Mixed farming")
    local grassText = terms.permanentGrassRestriction == true and "recorded grass retained" or "cropping permitted"
    local boundaryText = terms.boundaryRemovalRequiresConsent ~= false and "prior consent" or "no prior consent"
    local improvementText = terms.improvementsRequireConsent ~= false and "prior consent" or "no prior consent"
    local maintenanceText = terms.tenantMaintenanceObligation ~= false and "tenant" or "shared"
    local reviewMonths = math.max(0, math.floor(tonumber(terms.rentReviewIntervalMonths) or 0))
    local reviewText = reviewMonths > 0 and string.format("every %d months", reviewMonths) or "none"
    local breakText = "none"
    if terms.breakEnabled == true then
        breakText = string.format("half term / %d months' notice", math.max(3, math.floor(tonumber(terms.breakNoticeMonths) or 0)))
    end
    local noticeMonths = math.max(3, math.floor(tonumber(terms.landlordVariationNoticeMonths) or 0))
    local cooldownMonths = math.max(12, math.floor(tonumber(terms.landlordVariationCooldownMonths) or 0))
    return string.format("Use: %s | Grass: %s\nBoundaries: %s | Improvements: %s\nMaintenance: %s | Rent review: %s | Break: %s\nLandlord changes: %d months' notice | Cooldown: %d months",
        enterpriseText, grassText, boundaryText, improvementText, maintenanceText, reviewText,
        breakText, noticeMonths, cooldownMonths)
end

function RFF_TenancyManagementDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or RFF_TenancyManagementDialog_mt)
    self.callbackFrame = target
    self.tenancy = nil
    self.requestTargets = {"MIXED"}
    self.pendingSubmission = nil
    return self
end

function RFF_TenancyManagementDialog:onLoad()
    RFF_TenancyManagementDialog:superClass().onLoad(self)
    self:registerControls(RFF_TenancyManagementDialog.CONTROLS)
end

function RFF_TenancyManagementDialog:configure(frame, tenancy)
    local m = manager()
    if m == nil or m.propertyFinance == nil or tenancy == nil then return false end
    local active = tenancy.status == "ACTIVE" or tenancy.status == "EXPIRING"
        or tenancy.status == "RENEWAL_OFFERED" or tenancy.status == "NOTICE_SERVED"
    if not active then return false end
    self.callbackFrame = frame
    self.tenancy = tenancy
    return true
end

function RFF_TenancyManagementDialog:onOpen()
    RFF_TenancyManagementDialog:superClass().onOpen(self)
    local m = manager()
    if m == nil or m.propertyFinance == nil then return end
    local typeTexts = {}
    for _, requestType in ipairs(REQUEST_TYPES) do
        typeTexts[#typeTexts + 1] = m.propertyFinance:getTenancyConsentTypeLabel(requestType)
    end
    if self.requestTypeOption ~= nil then self.requestTypeOption:setTexts(typeTexts); setOptionState(self.requestTypeOption, 1) end
    self:rebuildTargetOptions()
    self:refresh()
    if self.requestTypeOption ~= nil then FocusManager:setFocus(self.requestTypeOption) end
end

function RFF_TenancyManagementDialog:onClose()
    self.pendingSubmission = nil
    self.tenancy = nil
    RFF_TenancyManagementDialog:superClass().onClose(self)
end

function RFF_TenancyManagementDialog:getSelectedRequestType()
    local state = self.requestTypeOption ~= nil and (self.requestTypeOption.state or 1) or 1
    return REQUEST_TYPES[math.max(1, math.min(#REQUEST_TYPES, state))]
end

function RFF_TenancyManagementDialog:getSelectedTarget()
    local state = self.requestTargetOption ~= nil and (self.requestTargetOption.state or 1) or 1
    return self.requestTargets[math.max(1, math.min(#self.requestTargets, state))] or "AUTHORITY"
end

function RFF_TenancyManagementDialog:rebuildTargetOptions()
    local m = manager()
    if m == nil or m.propertyFinance == nil or self.requestTargetOption == nil then return end
    local requestType = self:getSelectedRequestType()
    self.requestTargets = requestType == "ENTERPRISE" and ENTERPRISE_TARGETS or {"AUTHORITY"}
    local texts = {}
    for _, target in ipairs(self.requestTargets) do
        texts[#texts + 1] = m.propertyFinance:getTenancyConsentTargetLabel(requestType, target)
    end
    self.requestTargetOption:setTexts(texts)
    setOptionState(self.requestTargetOption, 1)
    if self.requestTargetOption.setDisabled ~= nil then self.requestTargetOption:setDisabled(#self.requestTargets <= 1) end
end

function RFF_TenancyManagementDialog:onRequestTypeChanged()
    self:rebuildTargetOptions()
    self:refresh()
end

function RFF_TenancyManagementDialog:onRequestTargetChanged()
    self:refresh()
end

function RFF_TenancyManagementDialog:refresh()
    local m = manager()
    local tenancy = self.tenancy
    if m == nil or m.propertyFinance == nil or tenancy == nil then return end
    local service = m.propertyFinance
    local brief = service:getTenancyLandlordBrief(tenancy)
    local requestType = self:getSelectedRequestType()
    local target = self:getSelectedTarget()
    local requirement = service:getTenancyConsentRequirement(tenancy, requestType, target)
    local latest = service:getLatestTenancyConsentRequest(tenancy)

    if self.titleText ~= nil then self.titleText:setText(g_i18n:getText("rff_tenancy_management_title")) end
    if self.subtitleText ~= nil then
        self.subtitleText:setText(string.format(g_i18n:getText("rff_tenancy_management_subtitle"),
            tenancy.holdingName or tenancy.agreementId or "-", brief ~= nil and brief.name or "-"))
    end
    if self.agreementValue ~= nil then
        self.agreementValue:setText(string.format("%s | %s", tenancy.agreementId or "-", tenancy.status or "ACTIVE"))
    end
    if self.covenantSummaryValue ~= nil then
        local terms = service:normaliseTenancyRenewalTerms(tenancy, nil)
        self.covenantSummaryValue:setText(wrapText(getCompactCovenantSummary(terms), 96))
    end
    if self.conditionSummaryValue ~= nil then
        local surveyText = service:getTenancyConditionSurveySummary(tenancy):gsub("^Commencement survey:", "Survey:")
        self.conditionSummaryValue:setText(wrapText(surveyText, 96))
    end
    if self.alterationSummaryValue ~= nil then
        local alterationText = service:getTenancyAlterationSummary(tenancy):gsub("^(Alterations: %d+) recorded", "%1")
        self.alterationSummaryValue:setText(wrapText(alterationText, 96))
    end
    if self.inspectionSummaryValue ~= nil then
        local handbackSummary = service:getTenancyHandbackSummary(tenancy)
        self.inspectionSummaryValue:setText(wrapText(handbackSummary ~= "" and handbackSummary
            or service:getTenancyInspectionSummary(tenancy), 96))
    end
    if self.relationshipValue ~= nil then
        self.relationshipValue:setText(string.format(g_i18n:getText("rff_tenancy_management_relationship"),
            brief ~= nil and brief.relationshipText or "-", brief ~= nil and brief.approach or "-"))
    end
    if self.requirementValue ~= nil then
        local requirementText = service:getTenancyConsentRequirementText(requirement)
        if requirement.eligible then
            requirementText = requirementText .. "\n" .. service:getTenancyConsentApplicationCostText(tenancy, requestType)
        end
        self.requirementValue:setText(wrapText(requirementText, 82))
    end

    if latest == nil then
        if self.latestReferenceValue ~= nil then self.latestReferenceValue:setText("-") end
        if self.latestStatusValue ~= nil then self.latestStatusValue:setText(g_i18n:getText("rff_tenancy_consent_no_requests")) end
        if self.latestFeeValue ~= nil then self.latestFeeValue:setText(g_i18n:getText("rff_tenancy_variation_fee_none")) end
        if self.latestDecisionValue ~= nil then self.latestDecisionValue:setText(g_i18n:getText("rff_tenancy_consent_no_decision")) end
    else
        local typeLabel = service:getTenancyConsentTypeLabel(latest.requestType)
        local initiatorKey = latest.initiator == "LANDLORD" and "rff_tenancy_variation_initiator_landlord" or "rff_tenancy_variation_initiator_tenant"
        local initiatorText = g_i18n:getText(initiatorKey)
        if self.latestReferenceValue ~= nil then
            self.latestReferenceValue:setText(string.format("%s | %s", latest.reference or "-", initiatorText))
        end
        local statusKey = STATUS_KEYS[latest.status] or "rff_tenancy_consent_status_received"
        local statusText = g_i18n:getText(statusKey)
        if latest.status == "RECEIVED" or latest.status == "PROFESSIONAL_REVIEW" or latest.status == "LANDLORD_NOTICE" then
            statusText = string.format(g_i18n:getText("rff_tenancy_consent_status_due"), statusText, math.max(0, latest.nextActionDay or 0))
        elseif latest.status == "NOTICE_RUNNING" then
            statusText = string.format(g_i18n:getText("rff_tenancy_variation_status_effective"), statusText,
                service:formatTenancyPeriod(latest.effectivePeriod))
        end
        if self.latestStatusValue ~= nil then self.latestStatusValue:setText(string.format("%s | %s", typeLabel, statusText)) end
        if self.latestFeeValue ~= nil then self.latestFeeValue:setText(service:getTenancyVariationFeeDisplayText(tenancy, latest)) end
        local decision = latest.conditions ~= nil and latest.conditions ~= "" and latest.conditions
            or g_i18n:getText("rff_tenancy_consent_awaiting_decision")
        if self.latestDecisionValue ~= nil then self.latestDecisionValue:setText(wrapText(decision, 82)) end
    end

    local pending = service:getPendingTenancyConsentRequest(tenancy)
    local landlordDecision = pending ~= nil and pending.status == "TENANT_DECISION" and pending.initiator == "LANDLORD"
    if self.requestTypeOption ~= nil and self.requestTypeOption.setDisabled ~= nil then self.requestTypeOption:setDisabled(pending ~= nil) end
    if self.requestTargetOption ~= nil and self.requestTargetOption.setDisabled ~= nil then
        self.requestTargetOption:setDisabled(pending ~= nil or #self.requestTargets <= 1)
    end
    if self.confirmButton ~= nil then
        self.confirmButton:setText(g_i18n:getText(landlordDecision and "rff_tenancy_variation_accept" or "rff_tenancy_consent_submit"))
        if self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(not landlordDecision and not requirement.eligible) end
    end
    setVisible(self.declineButton, landlordDecision)
    setVisible(self.declineLeadingSeparator, landlordDecision)
    if self.declineButton ~= nil and self.declineButton.setDisabled ~= nil then self.declineButton:setDisabled(not landlordDecision) end
end

function RFF_TenancyManagementDialog:onClickConfirm()
    local m = manager()
    if m == nil or m.propertyFinance == nil or self.tenancy == nil then return end
    local pendingVariation = m.propertyFinance:getPendingTenancyConsentRequest(self.tenancy)
    if pendingVariation ~= nil and pendingVariation.status == "TENANT_DECISION" and pendingVariation.initiator == "LANDLORD" then
        self.pendingSubmission = {action="acceptVariation"}
        YesNoDialog.show(self.onSubmissionConfirmed, self,
            string.format(g_i18n:getText("rff_tenancy_variation_accept_confirm"),
                m.propertyFinance:getTenancyConsentTargetLabel(pendingVariation.requestType, pendingVariation.target),
                m.propertyFinance:getTenancyVariationFeeText(self.tenancy, pendingVariation)),
            g_i18n:getText("rff_tenancy_management_title"))
        return
    end
    local requestType = self:getSelectedRequestType()
    local target = self:getSelectedTarget()
    local requirement = m.propertyFinance:getTenancyConsentRequirement(self.tenancy, requestType, target)
    if not requirement.eligible then return end
    local feeText = m.propertyFinance:getTenancyConsentApplicationCostText(self.tenancy, requestType)
    self.pendingSubmission = {action="submit", requestType=requestType, target=target}
    YesNoDialog.show(self.onSubmissionConfirmed, self,
        string.format(g_i18n:getText("rff_tenancy_consent_confirm"),
            m.propertyFinance:getTenancyConsentTargetLabel(requestType, target),
            self.tenancy.holdingName or self.tenancy.agreementId or "-", feeText),
        g_i18n:getText("rff_tenancy_management_title"))
end

function RFF_TenancyManagementDialog:onSubmissionConfirmed(accepted)
    local pending = self.pendingSubmission
    self.pendingSubmission = nil
    if not accepted or pending == nil or self.tenancy == nil then return end
    local m = manager()
    if m == nil or m.propertyFinance == nil then return end
    if pending.action == "acceptVariation" then
        local ok = m.propertyFinance:respondToLandlordVariation(self.tenancy, true)
        self:refresh()
        if self.callbackFrame ~= nil and self.callbackFrame.updateContent ~= nil then self.callbackFrame:updateContent() end
        InfoDialog.show(g_i18n:getText(ok and "rff_tenancy_variation_accepted_info" or "rff_tenancy_variation_response_failed"))
        return
    end
    local ok, reason, request = m.propertyFinance:submitTenancyConsentRequest(self.tenancy, pending.requestType, pending.target)
    if ok then
        self:refresh()
        if self.callbackFrame ~= nil and self.callbackFrame.updateContent ~= nil then self.callbackFrame:updateContent() end
        local reference = request ~= nil and request.reference or "-"
        InfoDialog.show(string.format(g_i18n:getText("rff_tenancy_consent_submitted"), reference))
    else
        local key = reason == "pending" and "rff_tenancy_consent_pending_existing" or "rff_tenancy_consent_submit_failed"
        InfoDialog.show(g_i18n:getText(key))
        self:refresh()
    end
end

function RFF_TenancyManagementDialog:onClickDecline()
    local m = manager()
    if m == nil or m.propertyFinance == nil or self.tenancy == nil then return end
    local pendingVariation = m.propertyFinance:getPendingTenancyConsentRequest(self.tenancy)
    if pendingVariation == nil or pendingVariation.status ~= "TENANT_DECISION" or pendingVariation.initiator ~= "LANDLORD" then return end
    YesNoDialog.show(self.onDeclineConfirmed, self,
        string.format(g_i18n:getText("rff_tenancy_variation_decline_confirm"),
            m.propertyFinance:getTenancyConsentTargetLabel(pendingVariation.requestType, pendingVariation.target)),
        g_i18n:getText("rff_tenancy_management_title"))
end

function RFF_TenancyManagementDialog:onDeclineConfirmed(accepted)
    if not accepted or self.tenancy == nil then return end
    local m = manager()
    if m == nil or m.propertyFinance == nil then return end
    local ok = m.propertyFinance:respondToLandlordVariation(self.tenancy, false)
    self:refresh()
    if self.callbackFrame ~= nil and self.callbackFrame.updateContent ~= nil then self.callbackFrame:updateContent() end
    InfoDialog.show(g_i18n:getText(ok and "rff_tenancy_variation_declined_info" or "rff_tenancy_variation_response_failed"))
end

function RFF_TenancyManagementDialog:onClickBack()
    self:close()
end

function RFF_TenancyManagementDialog.show(frame, tenancy)
    local gui = g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFTenancyManagementDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configure(frame, tenancy) then return false end
    g_gui:showDialog("RFFTenancyManagementDialog")
    return true
end
