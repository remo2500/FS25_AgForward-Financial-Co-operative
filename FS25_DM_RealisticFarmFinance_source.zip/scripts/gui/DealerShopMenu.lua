-- Dedicated shop sidebar page built with GIANTS' native machinery-card template.
RFF_DealerShopMenu={}
local M=RFF_DealerShopMenu
local function dealer()
    local m=RFF_RealisticFarmFinance.manager;return m and m.dealership
end
local function money(n) return g_i18n:formatMoney(n,0,true,true) end
RFF_DealerStockFrame={}
local StockFrame_mt=Class(RFF_DealerStockFrame,ShopItemsFrame)
function RFF_DealerStockFrame.new(target)
    return ShopItemsFrame.new(target,StockFrame_mt)
end
function RFF_DealerStockFrame:onFrameOpen()
    M.refresh(self)
    ShopItemsFrame.onFrameOpen(self)
end
function RFF_DealerStockFrame:populateCellForItemInSection(list,section,index,cell)
    ShopItemsFrame.populateCellForItemInSection(self,list,section,index,cell)
    local row=self.displayItems[index];local record=row and row.rffDealerStock
    if record then
        cell:getAttribute("value"):setText(money(record.price))
        cell:getAttribute("modDlc"):setText("S-"..record.id.." | NEW - 2 DAYS")
    end
end
function M.balance(frame)
    local farm=g_localPlayer and g_farmManager:getFarmById(g_localPlayer.farmId)
    if farm then frame:setCurrentBalance(farm.money,money(farm.money)) end
end
function M.refresh(frame)
    local d=dealer();local rows={}
    local selected=frame:getSelectedDisplayItem()
    local selectedId=selected and selected.rffDealerStock and selected.rffDealerStock.id
    if d and d:active() then
        d:repairLegacyStock();d:update(1000)
        for _,record in ipairs(d:state().stock) do
            local item=g_storeManager:getItemByXMLFilename(record.xml)
            if item then
                local ok,row=pcall(g_shopController.makeDisplayItem,g_shopController,item,nil,record.configurations)
                if ok and row then
                    row.rffDealerStock=record
                    row.configurations=RFF_DealershipService.copy(record.configurations)
                    row.functionText=string.format("S-%d | NEW | 0 hours | Fixed specification\nTwo game days for preparation. Ready if reserved now: %s\n%s",record.id,d:date(d:clock()+d:preparationMonths()),d:configurationText(item,record.configurations))
                    rows[#rows+1]=row
                else
                    Logging.warning("[RFF dealership] Stock display skipped for %s: %s",tostring(record.xml),tostring(row))
                end
            end
        end
    end
    frame:setCategory("RFF DEALERSHIP",g_i18n:getText("rff_dealer_shop_title"),ShopMenu.SLICE_ID.VEHICLES)
    frame.noItemsText:setText(g_i18n:getText(d and d:active() and "rff_dealer_shop_empty" or "rff_dealer_shop_disabled"))
    frame:setDisplayItems(rows)
    local index=1
    for i,row in ipairs(rows) do if row.rffDealerStock.id==selectedId then index=i;break end end
    if #rows>0 then frame.itemsList:setSelectedIndex(index) end
    M.balance(frame)
    frame.menu:updateButtonsPanel(frame)
end
function M.openStock(stock)
    local d=dealer();local live=d and d:findStock(stock.id)
    if not d or not d:active() or not live then InfoDialog.show("Enable dealer logistics and select an available stock unit.");return end
    local item=g_storeManager:getItemByXMLFilename(live.xml);if not item then return end
    RFF_DealershipShop.pendingStock=live
    local ok,err=pcall(g_shopController.buy,g_shopController,item,nil,false,RFF_DealershipService.copy(live.configurations))
    RFF_DealershipShop.pendingStock=nil
    if not ok then
        Logging.warning("[RFF dealership] Preview failed for %s: %s",live.xml,tostring(err))
        InfoDialog.show("This machine could not be previewed. No order or payment was made; please check the log.")
    end
end

function M.tryRegister()
    local menu=g_shopMenu
    if not menu or not menu.pagingElement or not menu.pageFrames or #menu.pageFrames==0
        or not g_currentMission or not g_currentMission.slotSystem or not dealer() then return false end
    if menu.rffDealerStockPage then return true end
    local frame=RFF_DealerStockFrame.new()
    local oldFocus=FocusManager.currentGui
    local loaded=g_gui:loadGui("dataS/gui/ShopItemsFrame.xml","RFFDealerStockFrame",frame,false)
    if oldFocus then FocusManager:setGui(oldFocus) end
    if not loaded then return false end
    frame:initialize();frame.menu=menu
    frame:setTitle(g_i18n:getText("rff_dealer_shop_title"))
    frame:setItemClickCallback(function(row) if row and row.rffDealerStock then M.openStock(row.rffDealerStock) end end)
    frame:setItemSelectCallback(function() menu:updateButtonsPanel(frame) end)
    menu.rffDealerStockPage=frame
    menu.pagingElement:addElement(frame)
    menu:registerPage(frame,nil,function() return dealer()~=nil end)
    menu:addPageTab(frame,Utils.getFilename("images/menuIcon.dds",RFF_RealisticFarmFinance.modDirectory),GuiUtils.getUVs({0,0,1024,1024}))
    menu.pagingElement:updateAbsolutePosition()
    menu.pagingElement:updatePageMapping()
    menu:updatePages()
    menu:setPageSelectorTitles()
    return true
end
function M.install()
    if M.installed or not ShopMenu then return end;M.installed=true
    ShopMenu.getPageButtonInfo=Utils.overwrittenFunction(ShopMenu.getPageButtonInfo,function(menu,superFunc,page)
        if not menu.rffDealerStockPage or page~=menu.rffDealerStockPage or menu:getIsDetailMode() then return superFunc(menu,page) end
        local buttons={menu.backButtonInfo}
        local row=page:getSelectedDisplayItem()
        if row and dealer() and dealer():active() then
            buttons[#buttons+1]={inputAction=InputAction.MENU_ACCEPT,text="VIEW FIXED SPECIFICATION",
                callback=function() M.openStock(row.rffDealerStock) end}
        end
        return buttons
    end)
    ShopMenu.updateCurrentDisplayItems=Utils.overwrittenFunction(ShopMenu.updateCurrentDisplayItems,function(menu,superFunc,...)
        if menu.rffDealerStockPage and menu.currentPage==menu.rffDealerStockPage and not menu:getIsDetailMode() then
            M.refresh(menu.rffDealerStockPage);return
        end
        return superFunc(menu,...)
    end)
    ShopMenu.onMoneyChange=Utils.appendedFunction(ShopMenu.onMoneyChange,function(menu)
        if menu.rffDealerStockPage then M.balance(menu.rffDealerStockPage) end
    end)
    ShopMenu.onSlotUsageChanged=Utils.appendedFunction(ShopMenu.onSlotUsageChanged,function(menu,used,maximum)
        if menu.rffDealerStockPage then menu.rffDealerStockPage:setSlotsUsage(used,maximum) end
    end)
end
