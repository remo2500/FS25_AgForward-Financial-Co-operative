-- RFF-local document font character metrics.
-- Adapted from the metric-driven approach used by Arrow's FS25 FontLibrary,
-- incorporated with permission. No global text-rendering functions are replaced.

RFF_DocumentFontCharacter = {}
RFF_DocumentFontCharacter.__index = RFF_DocumentFontCharacter

function RFF_DocumentFontCharacter.new(font)
    local self = setmetatable({}, RFF_DocumentFontCharacter)
    self.font = font
    return self
end

function RFF_DocumentFontCharacter:loadFromXMLFile(xmlFile, key)
    self.code = xmlFile:getInt(key .. "#code")
    self.character = xmlFile:getString(key .. "#character", "")
    self.x = xmlFile:getInt(key .. "#x", 0)
    self.y = xmlFile:getInt(key .. "#y", 0)
    self.width = xmlFile:getInt(key .. "#width", 0)
    self.height = xmlFile:getInt(key .. "#height", 0)
    self.left = xmlFile:getFloat(key .. "#left", 0)
    self.top = xmlFile:getFloat(key .. "#top", 0)
    self.bottom = xmlFile:getFloat(key .. "#bottom", 0)
    self.advance = xmlFile:getFloat(key .. "#advance", self.width)

    local imageWidth = math.max(self.font.imageWidth or 1, 1)
    local imageHeight = math.max(self.font.imageHeight or 1, 1)
    local u0 = self.x / imageWidth
    local u1 = (self.x + self.width) / imageWidth
    local vTop = 1 - self.y / imageHeight
    local vBottom = 1 - (self.y + self.height) / imageHeight
    self.uvs = {u0, vBottom, u0, vTop, u1, vBottom, u1, vTop}

    return self.code ~= nil
end
