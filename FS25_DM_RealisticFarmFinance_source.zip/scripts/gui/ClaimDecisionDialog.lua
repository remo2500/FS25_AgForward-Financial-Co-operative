RFF_ClaimDecisionDialog = {}
local mt = Class(RFF_ClaimDecisionDialog, MessageDialog)

function RFF_ClaimDecisionDialog.new()
    return MessageDialog.new(nil, mt)
end

function RFF_ClaimDecisionDialog:onLoad()
    RFF_ClaimDecisionDialog:superClass().onLoad(self)
    self:registerControls({"decisionText", "pageText", "previousButton", "nextButton"})
end

-- Fixed-size pages prevent long decision reasons from covering the controls.
function RFF_ClaimDecisionDialog:configure(text)
    local lines = {}
    for source in (tostring(text or "") .. "\n"):gmatch("(.-)\n") do
        local line = ""
        for word in source:gmatch("%S+") do
            if #line > 0 and #line + #word + 1 > 76 then
                lines[#lines + 1] = line
                line = ""
            end
            line = line == "" and word or line .. " " .. word
        end
        lines[#lines + 1] = line
    end
    self.pages = {}
    for first = 1, #lines, 10 do
        self.pages[#self.pages + 1] = table.concat(lines, "\n", first, math.min(first + 9, #lines))
    end
    self.page = 1
    self:refresh()
end

function RFF_ClaimDecisionDialog:refresh()
    self.decisionText:setText(self.pages[self.page] or "")
    self.pageText:setText(string.format("%d / %d", self.page, #self.pages))
    self.previousButton:setDisabled(self.page <= 1)
    self.nextButton:setDisabled(self.page >= #self.pages)
end

function RFF_ClaimDecisionDialog:onPrevious()
    self.page = math.max(1, self.page - 1)
    self:refresh()
end

function RFF_ClaimDecisionDialog:onNext()
    self.page = math.min(#self.pages, self.page + 1)
    self:refresh()
end

function RFF_ClaimDecisionDialog:onClickBack()
    self:close()
end

function RFF_ClaimDecisionDialog.show(text)
    local gui = g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis.RFFClaimDecisionDialog or nil
    if gui == nil or gui.target == nil then return false end
    gui.target:configure(text)
    g_gui:showDialog("RFFClaimDecisionDialog")
    return true
end
