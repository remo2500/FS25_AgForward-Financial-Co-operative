-- Uses the existing RFF frame's native controls and visual style.
function RFF_FinanceFrame:updateDemoContent(available)
    local s=self.manager and self.manager.demoDays
    if not s or not self.demoMode then return end
    local valid=available and s:validate();local state=s:state();local e=state.event
    if not valid then
        self.demoMode:setTexts({"DEMO DAYS UNAVAILABLE"});self.demoMode:setState(1)
        self.demoField:setTexts({"UNAVAILABLE"});self.demoField:setState(1)
        for _,name in ipairs({"demoMode","demoField","demoConfirmField","demoReturn","demoDetails"}) do self[name]:setDisabled(true) end
        self.demoSummary:setText("Demo days unavailable. Check dealership availability and saved event state.")
        return
    end
    self.demoMode:setTexts({"DEMO DAYS OFF","DEMO DAYS ENABLED"})
    self.demoMode:setState(state.enabled and 2 or 1);self.demoMode:setDisabled(not valid)
    if not s:canChooseField() then self.demoDraftField=nil end
    local fieldId=self.demoDraftField or state.farmlandId
    local labels={"CHOOSE AN NPC FIELD"};self.demoFields={0};local selected=1
    if valid then for _,f in ipairs(s:choices()) do
        labels[#labels+1]=string.format("Farmland %d | %.1f km",f.id,f.distance/1000)
        self.demoFields[#self.demoFields+1]=f.id
        if f.id==fieldId then selected=#labels end
    end end
    if fieldId>0 and selected==1 then
        labels[#labels+1]="Farmland "..fieldId.." (unavailable)"
        self.demoFields[#self.demoFields+1]=fieldId;selected=#labels
    end
    self.demoField:setTexts(labels);self.demoField:setState(selected)
    self.demoField:setDisabled(not valid or not s:canChooseField())
    self.demoConfirmField:setDisabled(not s:canChooseField() or fieldId==state.farmlandId or not s:eligibleField(fieldId))
    local text="Quarterly demos, 10:00-16:00: Case IH, John Deere, Fendt, Massey Ferguson, Deutz-Fahr. Cenio cultivator supplied. Confirm an NPC field; sale availability is ignored. Crop cleared at opening."
    if e then
        text=s:brandLabel(e.brand).." | "..s:date(e).." - 16:00\nFarmland "..e.farmlandId.." | "..e.status
        if e.status=="CLOSED" or e.status=="CANCELLED" or e.status=="MISSED" then
            text=text.."\nNext dealer event: "..s:nextEventDate()
            if not state.enabled then text=text.." (invitations off)"
            elseif not s:eligibleField(state.farmlandId) then text=text..". Select an available field." end
        else text=text.."\nCenio supplied; plough/cultivator work only. Return by 17:00. See Event Details." end
    end
    if not valid then text="Demo days unavailable. Check dealership availability and saved event state." end
    self.demoSummary:setText(text)
    local ready=false
    if valid and e then for _,r in ipairs(e.rows) do if r.status=="READY" then ready=true end end end
    self.demoReturn:setDisabled(not ready);self.demoDetails:setDisabled(not valid)
end
function RFF_FinanceFrame:onDemoMode(state)
    if self.updatingDealer then return end
    self.manager.demoDays:setEnabled((state or self.demoMode:getState())==2);self:updateDealerContent()
end
function RFF_FinanceFrame:onDemoField(state)
    if self.updatingDealer or self.pendingDemoField then return end
    local id=(self.demoFields or {})[state or self.demoField:getState()]
    if not id then return end
    -- Arrow callbacks run before GIANTS finishes its input/focus handling. Opening
    -- a modal here can steal the release and leave continuous scrolling latched.
    -- Browse locally only; never rebuild controls or open a dialog on an arrow.
    self.demoDraftField=id
    local s=self.manager.demoDays
    self.demoConfirmField:setDisabled(not s:canChooseField() or id==s:state().farmlandId or not s:eligibleField(id))
end
function RFF_FinanceFrame:onDemoConfirmField()
    if self.updatingDealer or self.pendingDemoField then return end
    local id=self.demoDraftField;local s=self.manager.demoDays
    if not id or id==0 or not s:canChooseField() or not s:eligibleField(id) then return end
    self.pendingDemoField=id
    YesNoDialog.show(self.onDemoFieldConfirmed,self,"Farmland "..id..": the field crop will be cleared when the demo opens. Temporary tillage access is provided for demo tractors only; the NPC remains the legal owner. Continue?","Demo farmland permission")
end
function RFF_FinanceFrame:onDemoFieldConfirmed(yes)
    local id=self.pendingDemoField;self.pendingDemoField=nil
    if yes and id then
        if self.manager.demoDays:chooseField(id) then self.demoDraftField=nil
        else InfoDialog.show("The field is no longer eligible or the announced venue is locked.") end
    end
    self:updateDealerContent()
end
function RFF_FinanceFrame:onDemoReturn()
    local count=self.manager.demoDays:returnAvailable()
    InfoDialog.show(count.." demo machines collected. Leave the cab and detach all implements first. Returned trials cannot be respawned.")
    self:updateDealerContent()
end
function RFF_FinanceFrame:onDemoDetails() InfoDialog.show(self.manager.demoDays:status()) end
function RFF_FinanceFrame:onDealerDetails() InfoDialog.show(self.dealerOrderDetails or "No order selected.") end
function RFF_FinanceFrame:updateDealerContent()
    local d=self.manager and self.manager.dealership
    if not d or not self.dealerMode or self.updatingDealer then return end
    self.updatingDealer=true;d:update(1000)
    self.dealerMode:setTexts({"INSTANT PURCHASING (DEFAULT)","DEALER STOCK AND FACTORY ORDERS"})
    self.dealerMode:setState(d:state().enabled and 2 or 1)
    local available,reason=d:available()
    self.dealerMode:setDisabled(not available)
    self.dealerHelp:setText(available and g_i18n:getText("rff_dealer_timing_help") or reason)
    self:updateDealerBrands(d,available)
    self.dealerBrowse:setDisabled(not available)
    if self.dealerRefresh then self.dealerRefresh:setDisabled(not d:canRefreshStock()) end
    if self.dealerRefreshDue then
        local due=d:state().nextManualRefresh
        self.dealerRefreshDue:setText(type(due)=="number" and due>d:clock()
            and string.format(g_i18n:getText("rff_dealer_refresh_due"),d:date(due)) or g_i18n:getText("rff_dealer_refresh_available"))
    end
    local records=d:orders(self:getCurrentFarmId());local labels={};local selected=1
    for i,o in ipairs(records) do labels[i]="D-"..o.id.." | "..o.name;if o.id==self.selectedDealerOrder then selected=i end end
    self.dealerOrders=records;self.dealerOrder:setTexts(#labels>0 and labels or {"No orders yet"});self.dealerOrder:setState(selected)
    local o=records[selected];self.selectedDealerOrder=o and o.id or nil
    local stage=o and o.status or "-"
    if o and o.status=="ORDERED" then stage=d:clock()<o.arrival and "Factory / transport" or "Dealer preparation" end
    self.dealerStatus:setText(stage)
    self.dealerDue:setText(o and d:date(o.due) or "-")
    self.dealerDeposit:setText(o and self:formatMoney(o.deposit) or "-")
    self.dealerBalance:setText(o and self:formatMoney(o.payable-o.deposit) or "-")
    self.dealerDeadline:setText(o and (o.useStartedHour and "Hourly charge until handover" or d:date(o.expires)) or "-")
    local note="Orders appear here. Ready machines are delivered to the dealership. Speak to the representative, or use this page as a fallback."
    if o then
        note=o.route.." | "..o.payment.."\n"
        if o.status=="DELIVERED" then note=note.."Handed over: "..d:date(o.closed).."\n"..o.ads
        elseif o.status=="CANCELLED" then note=note.."Reservation refunded; any incurred handover charges remain payable."
        elseif o.status=="REVIEW" then note=note..(o.ads or "Delivery requires save/log review. No automatic retry.")
        else note=note.."Complete handover with the representative or here. Moving over 10 m first starts "..self:formatMoney(25).." per game hour, including parked time. Payment may create unauthorised overdraft."
        end
        if o.useStartedHour then note=note.."\nHandover charges posted: "..self:formatMoney((o.handoverChargeCents or 0)/100) end
    end
    self.dealerOrderDetails=note
    -- Keep full ADS/review and charge information accessible without allowing long
    -- order histories to overlap the embedded demo-day panel.
    self.dealerOrderNote:setText(o and (o.status=="REVIEW" and "Delivery needs review: open Order Details. No automatic retry."
        or o.status=="DELIVERED" and "Handed over. Inspection and service information: Order Details."
        or o.status=="CANCELLED" and "Reservation refunded; incurred handover charges remain payable."
        or "Meet the representative or complete handover here. Moving first costs "..self:formatMoney(25).."/game hour; payment may create unauthorised overdraft. See Order Details.")
        or "Ready machines arrive at the dealer. Meet the representative, or complete handover here.")
    self.dealerCollect:setDisabled(not available or not o or o.status~="READY")
    self.dealerCancel:setDisabled(not available or not o or (o.status~="ORDERED" and o.status~="READY"))
    self:updateDemoContent(available)
    self.updatingDealer=false
end
function RFF_FinanceFrame:updateDealerBrands(d,available)
    local preferred=d:preferredBrands();local catalogue=d:brandChoices()
    self.dealerBrandOptions={}
    for slot=1,3 do
        local control=self["dealerBrand"..slot]
        if control then
            local names={""};local labels={g_i18n:getText("rff_dealer_brand_none")};local selected=1;local found=preferred[slot]==""
            for _,brand in ipairs(catalogue) do
                local used=false
                for i=1,3 do if i~=slot and preferred[i]==brand.name then used=true end end
                if not used then
                    names[#names+1]=brand.name;labels[#labels+1]=brand.title
                    if preferred[slot]==brand.name then selected=#names;found=true end
                end
            end
            if not found then
                names[#names+1]=preferred[slot];labels[#labels+1]=preferred[slot].." ("..g_i18n:getText("rff_dealer_brand_unavailable")..")";selected=#names
            end
            self.dealerBrandOptions[slot]=names
            control:setTexts(labels);control:setState(selected);control:setDisabled(not available)
        end
    end
end
function RFF_FinanceFrame:onDealerBrandChanged(slot,state)
    if self.updatingDealer then return end
    local control=self["dealerBrand"..slot]
    local name=(self.dealerBrandOptions[slot] or {})[state or control:getState()]
    local ok,message=self.manager.dealership:setPreferredBrand(slot,name)
    if not ok then InfoDialog.show(message) end
    self:updateDealerContent()
end
function RFF_FinanceFrame:onDealerBrandOne(state) self:onDealerBrandChanged(1,state) end
function RFF_FinanceFrame:onDealerBrandTwo(state) self:onDealerBrandChanged(2,state) end
function RFF_FinanceFrame:onDealerBrandThree(state) self:onDealerBrandChanged(3,state) end
function RFF_FinanceFrame:onDealerMode(state)
    if self.updatingDealer then return end
    local _,message=self.manager.dealership:setEnabled((state or self.dealerMode:getState())==2)
    InfoDialog.show(message);self:updateDealerContent()
end
function RFF_FinanceFrame:onDealerOrder(state)
    if self.updatingDealer then return end
    local o=(self.dealerOrders or {})[state or self.dealerOrder:getState()];self.selectedDealerOrder=o and o.id;self:updateDealerContent()
end
function RFF_FinanceFrame:onDealerBrowse()
    if not RFF_DealerShopMenu.tryRegister() then
        InfoDialog.show("The shop is not ready. Please open the shop and try again.");return
    end
    g_gui:changeScreen(nil,ShopMenu)
    g_shopMenu:goToPage(g_shopMenu.rffDealerStockPage)
end
function RFF_FinanceFrame:onDealerRefresh()
    if not self.manager.dealership:canRefreshStock() then return end
    YesNoDialog.show(self.onDealerRefreshConfirmed,self,g_i18n:getText("rff_dealer_refresh_confirm"),g_i18n:getText("rff_dealer_refresh"))
end
function RFF_FinanceFrame:onDealerRefreshConfirmed(yes)
    if not yes then return end
    local ok=self.manager.dealership:refreshStock()
    InfoDialog.show(g_i18n:getText(ok and "rff_dealer_refresh_done" or "rff_dealer_refresh_failed"))
    self:updateDealerContent()
end
function RFF_FinanceFrame:onDealerCollect()
    local o=self.manager.dealership:find(self.selectedDealerOrder,self:getCurrentFarmId());if not o then return end
    self.pendingDealerAction={id=o.id,farmId=o.farmId,action="COLLECT"}
    YesNoDialog.show(self.onDealerConfirmed,self,"Complete handover and pay "..self:formatMoney(o.payable-o.deposit).."?\n\nAccrued handover charges will also be settled. The delivered machine becomes yours under the agreed terms. Payment may exceed your overdraft limit: 39% annual interest plus "..self:formatMoney(10).." per game day applies to unauthorised borrowing.","Dealer handover")
end
function RFF_FinanceFrame:onDealerCancel()
    self.pendingDealerAction={id=self.selectedDealerOrder,farmId=self:getCurrentFarmId(),action="CANCEL"}
    YesNoDialog.show(self.onDealerConfirmed,self,"Cancel this reservation and refund its deposit? Any delivered machine will be removed; leave it empty and detach other equipment first. Incurred handover charges will still be taken. No finance agreement will be started.","Cancel order")
end
function RFF_FinanceFrame:onDealerConfirmed(yes)
    local q=self.pendingDealerAction;self.pendingDealerAction=nil;if not yes or not q then return end
    local d=self.manager.dealership;local _,message
    if q.action=="COLLECT" then _,message=d:collect(q.id,q.farmId) else _,message=d:cancel(q.id,q.farmId) end
    InfoDialog.show(message);self:updateDealerContent()
end
