RFF_TaxReturnDialog = {}
local RFF_TaxReturnDialog_mt = Class(RFF_TaxReturnDialog, MessageDialog)

RFF_TaxReturnDialog.CONTROLS = {
    "workingPaperBackground", "officialPaperBackground", "workingTitleText", "bookYearLabel", "bookYearValue", "farmNameLabel", "farmNameValue",
    "closedBooksLabel", "bookIncomeLabel", "bookIncomeValue", "bookTaxedIncomeLabel", "bookTaxedIncomeValue",
    "bookExpensesLabel", "bookExpensesValue", "bookLossesLabel", "bookLossesValue",
    "bookTaxableProfitLabel", "bookTaxableProfitValue", "bookTaxRateLabel", "bookTaxRateValue", "bookTaxLabel", "bookTaxValue", "workingNoteText",
    "statusValue", "methodOption", "methodDisplayText", "methodLeftArrowText", "methodRightArrowText",
    "declaredIncomeButton", "declaredExpensesButton", "declaredIncomeHandwritingAnchor", "declaredExpensesHandwritingAnchor", "declaredLossesValue",
    "declaredTaxableProfitValue", "declaredTaxRateValue", "filedTaxValue",
    "accountantFeeLabel", "accountantFeeValue", "declarationText", "signatureLabel", "signatureValue", "complianceNote", "confirmButton"
}

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function formatMoney(value)
    return g_i18n:formatMoney(value or 0, 0, true, true)
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then option:setState(state, false) else option.state = state end
end

local function setDisabled(control, disabled)
    if control ~= nil and control.setDisabled ~= nil then control:setDisabled(disabled == true) end
end

local function wrapText(text, maxChars)
    if text == nil then return "" end
    maxChars = maxChars or 62
    local wrapped = {}
    for sourceLine in (tostring(text) .. "\n"):gmatch("(.-)\n") do
        if sourceLine == "" then table.insert(wrapped, "") else
            local line = ""
            for word in sourceLine:gmatch("%S+") do
                if line == "" then line = word
                elseif #line + #word + 1 <= maxChars then line = line .. " " .. word
                else table.insert(wrapped, line); line = word end
            end
            if line ~= "" then table.insert(wrapped, line) end
        end
    end
    return table.concat(wrapped, "\n")
end

local function cleanAmount(text)
    local cleaned = tostring(text or ""):gsub("[^%d]", "")
    local value = tonumber(cleaned)
    if value == nil then return nil end
    return math.max(0, math.min(99999999, math.floor(value + 0.5)))
end

local function getCurrentPlayerName()
    local mission = g_currentMission
    local player = g_localPlayer or (mission ~= nil and mission.player or nil)
    if mission ~= nil and mission.userManager ~= nil and player ~= nil and player.userId ~= nil then
        local user = mission.userManager:getUserByUserId(player.userId)
        if user ~= nil and user.getNickname ~= nil then
            local nickname = user:getNickname()
            if type(nickname) == "string" and nickname:match("%S") ~= nil then
                return nickname
            end
        end
    end
    if player ~= nil and type(player.nickname) == "string" and player.nickname:match("%S") ~= nil then
        return player.nickname
    end
    return nil
end

function RFF_TaxReturnDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or RFF_TaxReturnDialog_mt)
    self.callbackFrame = target
    self.state = nil
    self.readOnly = false
    self.declaredIncome = 0
    self.declaredExpenses = 0
    self.notesRenderer = nil
    self.handwritingRenderer = nil
    self.handwritten = {}
    return self
end

function RFF_TaxReturnDialog:onLoad()
    RFF_TaxReturnDialog:superClass().onLoad(self)
    self:registerControls(RFF_TaxReturnDialog.CONTROLS)
end

function RFF_TaxReturnDialog:configure(frame)
    local m = manager()
    if m == nil or m.taxCompliance == nil or g_currentMission == nil then return false end
    self.callbackFrame = frame
    local farmId = g_currentMission:getFarmId()
    local summary = m.taxCompliance:getSummary(farmId)
    if not summary.available then return false end
    self.state = summary.state
    if self.state == nil or self.state.taxReturnStatus == "NONE" then return false end
    self.readOnly = self.state.taxReturnStatus ~= "OPEN"
    self.declaredIncome = self.readOnly and (self.state.taxReturnDeclaredIncome or 0) or (self.state.taxReturnDeclaredIncome or self.state.taxReturnBookIncome or 0)
    self.declaredExpenses = self.readOnly and (self.state.taxReturnDeclaredExpenses or 0) or (self.state.taxReturnDeclaredExpenses or self.state.taxReturnBookExpenses or 0)
    if not self.readOnly and self.declaredIncome <= 0 and (self.state.taxReturnBookIncome or 0) > 0 then self.declaredIncome = self.state.taxReturnBookIncome end
    if not self.readOnly and self.declaredExpenses <= 0 and (self.state.taxReturnBookExpenses or 0) > 0 then self.declaredExpenses = self.state.taxReturnBookExpenses end
    return true
end

function RFF_TaxReturnDialog:onOpen()
    RFF_TaxReturnDialog:superClass().onOpen(self)
    if RFF_RealisticFarmFinance ~= nil and RFF_DocumentFontRenderer ~= nil then
        if self.notesRenderer == nil then
            self.notesRenderer = RFF_DocumentFontRenderer.new(
                RFF_RealisticFarmFinance.modDirectory .. "fonts/derwen_notes/font.xml",
                RFF_RealisticFarmFinance.modDirectory
            )
        end
        if self.handwritingRenderer == nil then
            self.handwritingRenderer = RFF_DocumentFontRenderer.new(
                RFF_RealisticFarmFinance.modDirectory .. "fonts/derwen_handwriting/font.xml",
                RFF_RealisticFarmFinance.modDirectory
            )
        end
    end
    if RFF_RealisticFarmFinance ~= nil then
        if self.workingPaperBackground ~= nil and self.workingPaperBackground.setImageFilename ~= nil then
            self.workingPaperBackground:setImageFilename(RFF_RealisticFarmFinance.modDirectory .. "images/taxWorkingNotepad.dds")
        end
        if self.officialPaperBackground ~= nil and self.officialPaperBackground.setImageFilename ~= nil then
            self.officialPaperBackground:setImageFilename(RFF_RealisticFarmFinance.modDirectory .. "images/taxOfficialReturn.dds")
        end
    end
    self:rebuildMethodOption()
    self:refresh()
    if self.confirmButton ~= nil and not self.readOnly then FocusManager:setFocus(self.declaredIncomeButton or self.confirmButton) end
end

function RFF_TaxReturnDialog:onClose()
    self.pending = nil
    RFF_TaxReturnDialog:superClass().onClose(self)
end

function RFF_TaxReturnDialog:rebuildMethodOption()
    if self.methodOption == nil then return end
    local methods = {g_i18n:getText("rff_tax_method_self"), g_i18n:getText("rff_tax_method_accountant")}
    if self.readOnly and self.state ~= nil and self.state.taxReturnMethod == "AUTHORITY" then
        table.insert(methods, g_i18n:getText("rff_tax_method_authority"))
    end
    self.methodOption:setTexts(methods)
    local methodState = self.state ~= nil and self.state.taxReturnMethod == "ACCOUNTANT" and 2 or (self.state ~= nil and self.state.taxReturnMethod == "AUTHORITY" and 3 or 1)
    setOptionState(self.methodOption, methodState)
end

function RFF_TaxReturnDialog:getMethod()
    if self.readOnly then
        if self.state.taxReturnMethod == "ACCOUNTANT" then return "ACCOUNTANT" end
        if self.state.taxReturnMethod == "AUTHORITY" then return "AUTHORITY" end
        return "SELF"
    end
    return self.methodOption ~= nil and (self.methodOption.state or 1) == 2 and "ACCOUNTANT" or "SELF"
end

function RFF_TaxReturnDialog:onMethodChanged()
    if self.readOnly then return end
    local method = self:getMethod()
    if method == "ACCOUNTANT" then
        self.declaredIncome = self.state.taxReturnBookIncome or 0
        self.declaredExpenses = self.state.taxReturnBookExpenses or 0
    end
    self:refresh()
end

function RFF_TaxReturnDialog:getCalculation()
    local m = manager()
    if m == nil or m.taxCompliance == nil or self.state == nil then return nil end
    local method = self:getMethod()
    local income = self.declaredIncome
    local expenses = self.declaredExpenses
    if method == "ACCOUNTANT" or method == "AUTHORITY" then
        income = self.state.taxReturnBookIncome or 0
        expenses = self.state.taxReturnBookExpenses or 0
    end
    if self.readOnly then
        income = self.state.taxReturnDeclaredIncome or income
        expenses = self.state.taxReturnDeclaredExpenses or expenses
    end
    return m.taxCompliance:calculateDeclaredTaxValues(self.state, income, expenses)
end

local function setNativeText(control, value, useHandwriting)
    if control == nil then return end
    if useHandwriting then
        control:setText("")
    else
        control:setText(value or "")
    end
end

local function drawHandwrittenControl(renderer, control, text, options)
    if renderer == nil or control == nil or text == nil or text == "" then return end
    local pos = control.absPosition or control.position
    local size = control.absSize or control.size
    if pos == nil or size == nil then return end
    renderer:draw(text, pos[1], pos[2], size[1], size[2], options)
end

function RFF_TaxReturnDialog:refresh()
    local m = manager()
    if m == nil or m.taxCompliance == nil or self.state == nil then return end
    local method = self:getMethod()
    local calc = self:getCalculation()
    if calc == nil then return end

    local farmId = g_currentMission ~= nil and g_currentMission:getFarmId() or 0
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    self.handwritten.workingTitle = g_i18n:getText("rff_tax_paper_books_title")
    setNativeText(self.workingTitleText, self.handwritten.workingTitle, true)
    self.handwritten.bookYearLabel = g_i18n:getText("rff_tax_return_year") .. ":"
    setNativeText(self.bookYearLabel, self.handwritten.bookYearLabel, true)
    self.handwritten.bookYear = tostring(self.state.taxReturnYear or 0)
    setNativeText(self.bookYearValue, self.handwritten.bookYear, true)
    self.handwritten.farmNameLabel = g_i18n:getText("rff_tax_paper_farm") .. ":"
    setNativeText(self.farmNameLabel, self.handwritten.farmNameLabel, true)
    self.handwritten.farmName = farm ~= nil and (farm.name or ("Farm " .. tostring(farmId))) or ("Farm " .. tostring(farmId))
    setNativeText(self.farmNameValue, self.handwritten.farmName, true)
    -- Deliberately leave the old "Closed Books" ruled row blank; the figures below are self-explanatory.
    self.handwritten.closedBooksLabel = ""
    setNativeText(self.closedBooksLabel, "", true)
    self.handwritten.bookIncomeLabel = g_i18n:getText("rff_tax_paper_income_recorded")
    setNativeText(self.bookIncomeLabel, self.handwritten.bookIncomeLabel, true)
    self.handwritten.bookTaxedIncomeLabel = g_i18n:getText("rff_tax_paper_taxed_income")
    setNativeText(self.bookTaxedIncomeLabel, self.handwritten.bookTaxedIncomeLabel, true)
    self.handwritten.bookExpensesLabel = g_i18n:getText("rff_tax_paper_expenses")
    setNativeText(self.bookExpensesLabel, self.handwritten.bookExpensesLabel, true)
    self.handwritten.bookLossesLabel = g_i18n:getText("rff_tax_return_losses")
    setNativeText(self.bookLossesLabel, self.handwritten.bookLossesLabel, true)
    self.handwritten.bookTaxableProfitLabel = g_i18n:getText("rff_tax_paper_taxable_profit")
    setNativeText(self.bookTaxableProfitLabel, self.handwritten.bookTaxableProfitLabel, true)
    self.handwritten.bookTaxRateLabel = g_i18n:getText("rff_tax_paper_tax_rate")
    setNativeText(self.bookTaxRateLabel, self.handwritten.bookTaxRateLabel, true)
    self.handwritten.bookTaxLabel = g_i18n:getText("rff_tax_paper_tax_due_books")
    setNativeText(self.bookTaxLabel, self.handwritten.bookTaxLabel, true)
    self.handwritten.workingNote = g_i18n:getText("rff_tax_paper_books_note")
    setNativeText(self.workingNoteText, self.handwritten.workingNote, true)
    if self.statusValue ~= nil then self.statusValue:setText(g_i18n:getText("rff_tax_return_status_" .. string.lower(self.state.taxReturnStatus or "NONE"))) end
    if self.methodDisplayText ~= nil then
        local methodKey = method == "ACCOUNTANT" and "rff_tax_method_accountant" or (method == "AUTHORITY" and "rff_tax_method_authority" or "rff_tax_method_self")
        self.methodDisplayText:setText(g_i18n:getText(methodKey))
    end
    if self.methodLeftArrowText ~= nil then self.methodLeftArrowText:setVisible(not self.readOnly) end
    if self.methodRightArrowText ~= nil then self.methodRightArrowText:setVisible(not self.readOnly) end
    if self.signatureLabel ~= nil then self.signatureLabel:setText(g_i18n:getText("rff_tax_paper_signature")) end
    local signedBy = self.state.taxReturnSignedBy
    if type(signedBy) ~= "string" or signedBy:match("%S") == nil then signedBy = getCurrentPlayerName() end
    if signedBy == nil or signedBy == "" then signedBy = self.handwritten.farmName end
    self.handwritten.signature = self.readOnly and signedBy or ""
    setNativeText(self.signatureValue, self.handwritten.signature, true)

    local bookBase = math.max(0, (self.state.taxReturnBookTaxedIncome or 0) - (self.state.taxReturnBookExpenses or 0))
    local bookRollover = math.min(math.max(0, self.state.taxReturnLossRollover or 0), bookBase)
    local bookProfit = math.max(0, bookBase - bookRollover)
    self.handwritten.bookIncome = formatMoney(self.state.taxReturnBookIncome or 0)
    setNativeText(self.bookIncomeValue, self.handwritten.bookIncome, true)
    self.handwritten.bookTaxedIncome = formatMoney(self.state.taxReturnBookTaxedIncome or 0)
    setNativeText(self.bookTaxedIncomeValue, self.handwritten.bookTaxedIncome, true)
    self.handwritten.bookExpenses = formatMoney(self.state.taxReturnBookExpenses or 0)
    setNativeText(self.bookExpensesValue, self.handwritten.bookExpenses, true)
    self.handwritten.bookLosses = formatMoney(self.state.taxReturnLossRollover or 0)
    setNativeText(self.bookLossesValue, self.handwritten.bookLosses, true)
    self.handwritten.bookTaxableProfit = formatMoney(bookProfit)
    setNativeText(self.bookTaxableProfitValue, self.handwritten.bookTaxableProfit, true)
    self.handwritten.bookTaxRate = string.format("%.1f%%", (self.state.taxReturnTaxRate or 0) * 100)
    setNativeText(self.bookTaxRateValue, self.handwritten.bookTaxRate, true)
    self.handwritten.bookTax = formatMoney(self.state.taxReturnBookTax or 0)
    setNativeText(self.bookTaxValue, self.handwritten.bookTax, true)

    -- A self-filed return should look as though the player has physically filled in
    -- the declaration boxes. Accountant/authority-prepared figures remain clean
    -- printed text to give the two preparation methods an immediate visual identity.
    self.handwritten.useDeclarationHandwriting = method == "SELF"
    self.handwritten.declaredIncome = formatMoney(calc.declaredIncome or 0)
    setNativeText(self.declaredIncomeButton, self.handwritten.declaredIncome, self.handwritten.useDeclarationHandwriting)
    self.handwritten.declaredExpenses = formatMoney(calc.declaredExpenses or 0)
    setNativeText(self.declaredExpensesButton, self.handwritten.declaredExpenses, self.handwritten.useDeclarationHandwriting)
    self.handwritten.declaredLosses = formatMoney(self.state.taxReturnLossRollover or 0)
    -- Losses Brought Forward is carried from the books rather than entered by the
    -- player, so it always retains the official printed treatment.
    setNativeText(self.declaredLossesValue, self.handwritten.declaredLosses, false)
    if self.declaredTaxableProfitValue ~= nil then self.declaredTaxableProfitValue:setText(formatMoney(calc.taxableProfit or 0)) end
    if self.declaredTaxRateValue ~= nil then self.declaredTaxRateValue:setText(string.format("%.1f%%", (self.state.taxReturnTaxRate or 0) * 100)) end
    if self.filedTaxValue ~= nil then self.filedTaxValue:setText(formatMoney(self.readOnly and (self.state.taxReturnFiledTax or calc.tax or 0) or (calc.tax or 0))) end

    local accountant = method == "ACCOUNTANT"
    -- Keep the official form geometry consistent: the accountant-fee line is
    -- always present, showing £0 for a self-filed return rather than leaving an
    -- unexplained empty box on the printed form.
    if self.accountantFeeValue ~= nil then self.accountantFeeValue:setText(formatMoney(accountant and (self.state.taxReturnAccountantFee or 0) or 0)) end
    if self.accountantFeeLabel ~= nil then self.accountantFeeLabel:setVisible(true) end
    if self.accountantFeeValue ~= nil then self.accountantFeeValue:setVisible(true) end

    setDisabled(self.methodOption, self.readOnly)
    setDisabled(self.declaredIncomeButton, self.readOnly or accountant)
    setDisabled(self.declaredExpensesButton, self.readOnly or accountant)

    if self.confirmButton ~= nil then self.confirmButton:setVisible(not self.readOnly); setDisabled(self.confirmButton, self.readOnly) end
    if self.declarationText ~= nil then
        self.declarationText:setText(wrapText(g_i18n:getText(self.readOnly and "rff_tax_paper_declaration_filed" or "rff_tax_paper_declaration_text"), 65))
    end
    if self.complianceNote ~= nil then
        local key
        if self.readOnly then key = "rff_tax_paper_filed_note"
        elseif accountant then key = "rff_tax_paper_accountant_note"
        elseif (calc.baseDiscrepancy or 0) > 0.5 then key = "rff_tax_paper_discrepancy_note"
        else key = "rff_tax_paper_self_note" end
        self.complianceNote:setText(wrapText(g_i18n:getText(key), 72))
    end
end

function RFF_TaxReturnDialog:onDrawHandwriting(element)
    local notesRenderer = self.notesRenderer or self.handwritingRenderer
    local renderer = self.handwritingRenderer
    if renderer == nil or notesRenderer == nil or self.handwritten == nil then return end

    -- Working papers = blue biro. Figures entered on the official return =
    -- black biro. Keeping the two inks distinct makes the left page read as
    -- farm-office notes and the right page as the signed official declaration.
    local noteColor = {0.025, 0.18, 0.52, 0.98}
    local entryColor = {0.018, 0.018, 0.022, 1.0}

    local labelColor = {0.020, 0.16, 0.50, 0.98}
    local valueColor = {0.012, 0.12, 0.42, 1.0}

    drawHandwrittenControl(notesRenderer, self.workingTitleText, self.handwritten.workingTitle, {lineHeightPx=31, minLineHeightPx=23, align="left", color=valueColor, jitterPx=0.65, fitToWidth=true, paddingPx=2, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookYearLabel, self.handwritten.bookYearLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=labelColor, jitterPx=0.45, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookYearValue, self.handwritten.bookYear, {lineHeightPx=21, minLineHeightPx=16, align="left", color=valueColor, jitterPx=0.40, fitToWidth=true, paddingPx=2, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.farmNameLabel, self.handwritten.farmNameLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=labelColor, jitterPx=0.45, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.farmNameValue, self.handwritten.farmName, {lineHeightPx=21, minLineHeightPx=15, align="left", color=valueColor, jitterPx=0.55, fitToWidth=true, paddingPx=2, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.closedBooksLabel, self.handwritten.closedBooksLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=valueColor, jitterPx=0.60, fitToWidth=true, paddingPx=1, offsetYPx=-1})

    drawHandwrittenControl(notesRenderer, self.bookIncomeLabel, self.handwritten.bookIncomeLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=labelColor, jitterPx=0.50, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookIncomeValue, self.handwritten.bookIncome, {lineHeightPx=23, minLineHeightPx=17, align="right", color=valueColor, jitterPx=0.45, fitToWidth=true, paddingPx=10, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookTaxedIncomeLabel, self.handwritten.bookTaxedIncomeLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=labelColor, jitterPx=0.50, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookTaxedIncomeValue, self.handwritten.bookTaxedIncome, {lineHeightPx=23, minLineHeightPx=17, align="right", color=valueColor, jitterPx=0.45, fitToWidth=true, paddingPx=10, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookExpensesLabel, self.handwritten.bookExpensesLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=labelColor, jitterPx=0.50, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookExpensesValue, self.handwritten.bookExpenses, {lineHeightPx=23, minLineHeightPx=17, align="right", color=valueColor, jitterPx=0.45, fitToWidth=true, paddingPx=10, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookLossesLabel, self.handwritten.bookLossesLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=labelColor, jitterPx=0.50, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookLossesValue, self.handwritten.bookLosses, {lineHeightPx=23, minLineHeightPx=17, align="right", color=valueColor, jitterPx=0.45, fitToWidth=true, paddingPx=10, offsetYPx=-1})

    drawHandwrittenControl(notesRenderer, self.bookTaxableProfitLabel, self.handwritten.bookTaxableProfitLabel, {lineHeightPx=21, minLineHeightPx=16, align="left", color=valueColor, jitterPx=0.55, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookTaxableProfitValue, self.handwritten.bookTaxableProfit, {lineHeightPx=24, minLineHeightPx=18, align="right", color=valueColor, jitterPx=0.48, fitToWidth=true, paddingPx=10, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookTaxRateLabel, self.handwritten.bookTaxRateLabel, {lineHeightPx=20, minLineHeightPx=15, align="left", color=labelColor, jitterPx=0.48, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookTaxRateValue, self.handwritten.bookTaxRate, {lineHeightPx=23, minLineHeightPx=17, align="right", color=valueColor, jitterPx=0.40, fitToWidth=true, paddingPx=10, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookTaxLabel, self.handwritten.bookTaxLabel, {lineHeightPx=21, minLineHeightPx=16, align="left", color=valueColor, jitterPx=0.58, fitToWidth=true, paddingPx=1, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.bookTaxValue, self.handwritten.bookTax, {lineHeightPx=25, minLineHeightPx=19, align="right", color=valueColor, jitterPx=0.55, fitToWidth=true, paddingPx=10, offsetYPx=-1})
    drawHandwrittenControl(notesRenderer, self.workingNoteText, self.handwritten.workingNote, {lineHeightPx=15, minLineHeightPx=12, align="left", color=labelColor, jitterPx=0.45, fitToWidth=true, paddingPx=1, offsetYPx=-1})

    -- Only player-entered declaration figures are handwritten. The accountant
    -- path deliberately leaves the native printed controls visible instead.
    if self.handwritten.useDeclarationHandwriting then
        -- Keep the visual handwriting independent of the full-box interactive
        -- Button. This preserves the larger accessible hitbox without allowing the
        -- button geometry to rescale or reposition the handwritten amount.
        local incomeAnchor = self.declaredIncomeHandwritingAnchor or self.declaredIncomeButton
        local expensesAnchor = self.declaredExpensesHandwritingAnchor or self.declaredExpensesButton
        drawHandwrittenControl(renderer, incomeAnchor, self.handwritten.declaredIncome, {lineHeightPx=23, minLineHeightPx=20, align="center", color=entryColor, jitterPx=0.18, fitToWidth=true, paddingPx=12, offsetYPx=-3, clip=false})
        drawHandwrittenControl(renderer, expensesAnchor, self.handwritten.declaredExpenses, {lineHeightPx=23, minLineHeightPx=20, align="center", color=entryColor, jitterPx=0.18, fitToWidth=true, paddingPx=12, offsetYPx=-3, clip=false})
    end

    drawHandwrittenControl(renderer, self.signatureValue, self.handwritten.signature, {lineHeightPx=20, minLineHeightPx=15, align="center", color=entryColor, jitterPx=0.20, fitToWidth=true, paddingPx=4, offsetYPx=-1})
end

function RFF_TaxReturnDialog:delete()
    if self.notesRenderer ~= nil then
        self.notesRenderer:delete()
        self.notesRenderer = nil
    end
    if self.handwritingRenderer ~= nil then
        self.handwritingRenderer:delete()
        self.handwritingRenderer = nil
    end
    RFF_TaxReturnDialog:superClass().delete(self)
end

function RFF_TaxReturnDialog:openAmountInput(callback, current, promptKey)
    if self.readOnly or TextInputDialog == nil or TextInputDialog.show == nil then return end
    local prompt = wrapText(g_i18n:getText(promptKey), 58)
    TextInputDialog.show(callback, self, tostring(math.floor((current or 0) + 0.5)), prompt, nil, 12, g_i18n:getText("button_ok"))
end

function RFF_TaxReturnDialog:onClickEditIncome()
    if self:getMethod() == "ACCOUNTANT" then return end
    self:openAmountInput(self.onIncomeEntered, self.declaredIncome, "rff_tax_paper_income_prompt")
end

function RFF_TaxReturnDialog:onIncomeEntered(text, confirmed)
    if not confirmed then return end
    local value = cleanAmount(text)
    if value == nil then InfoDialog.show(g_i18n:getText("rff_tax_paper_invalid_amount")); return end
    self.declaredIncome = value
    self:refresh()
end

function RFF_TaxReturnDialog:onClickEditExpenses()
    if self:getMethod() == "ACCOUNTANT" then return end
    self:openAmountInput(self.onExpensesEntered, self.declaredExpenses, "rff_tax_paper_expenses_prompt")
end

function RFF_TaxReturnDialog:onExpensesEntered(text, confirmed)
    if not confirmed then return end
    local value = cleanAmount(text)
    if value == nil then InfoDialog.show(g_i18n:getText("rff_tax_paper_invalid_amount")); return end
    self.declaredExpenses = value
    self:refresh()
end

function RFF_TaxReturnDialog:onClickConfirm()
    if self.readOnly then return end
    local method = self:getMethod()
    local calc = self:getCalculation()
    if calc == nil then return end
    local methodText = g_i18n:getText(method == "ACCOUNTANT" and "rff_tax_method_accountant" or "rff_tax_method_self")
    local text = string.format(g_i18n:getText("rff_tax_paper_submit_confirm"), methodText, formatMoney(calc.declaredIncome), formatMoney(calc.declaredExpenses), formatMoney(calc.tax))
    self.pending = {method=method, income=calc.declaredIncome, expenses=calc.declaredExpenses, signedBy=getCurrentPlayerName()}
    YesNoDialog.show(self.onSubmitConfirmed, self, text, g_i18n:getText("rff_tax_return_title"))
end

function RFF_TaxReturnDialog:onSubmitConfirmed(confirmed)
    if not confirmed or self.pending == nil then self.pending=nil; return end
    local pending = self.pending; self.pending=nil
    local m = manager()
    local ok, reason = m.taxCompliance:submitReturnValues(g_currentMission:getFarmId(), pending.method, pending.income, pending.expenses, false, pending.signedBy)
    if not ok then
        if reason == "funds" then InfoDialog.show(g_i18n:getText("rff_tax_accountant_insufficient_funds"))
        else InfoDialog.show(g_i18n:getText("rff_tax_return_submit_failed")) end
        return
    end
    self.state = m.taxCompliance:getFarmState(g_currentMission:getFarmId(), true)
    self.readOnly = true
    self:rebuildMethodOption()
    self:refresh()
    InfoDialog.show(g_i18n:getText("rff_tax_return_submitted"))
    if self.callbackFrame ~= nil and self.callbackFrame.updateBusinessAdministrationContent ~= nil then self.callbackFrame:updateBusinessAdministrationContent() end
end

function RFF_TaxReturnDialog:onClickBack()
    self:close()
end

function RFF_TaxReturnDialog.show(frame)
    local gui = g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFTaxReturnDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configure(frame) then return false end
    g_gui:showDialog("RFFTaxReturnDialog")
    return true
end
