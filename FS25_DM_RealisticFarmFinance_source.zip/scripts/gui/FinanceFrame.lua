RFF_FinanceFrame = {}
local RFF_FinanceFrame_mt = Class(RFF_FinanceFrame, TabbedMenuFrameElement)

RFF_FinanceFrame.PAGE_OVERVIEW = 1
RFF_FinanceFrame.PAGE_BANKING = 2
RFF_FinanceFrame.PAGE_APPLICATIONS = 3
RFF_FinanceFrame.PAGE_AGREEMENTS = 4
RFF_FinanceFrame.PAGE_ASSET = 5
RFF_FinanceFrame.PAGE_PROPERTY = 6
RFF_FinanceFrame.PAGE_CASHFLOW = 7
RFF_FinanceFrame.PAGE_CREDIT = 8
RFF_FinanceFrame.PAGE_BROKER = 9
RFF_FinanceFrame.PAGE_RELATIONSHIPS = 10
RFF_FinanceFrame.PAGE_MARKET = 11
RFF_FinanceFrame.PAGE_APPLY = 12
RFF_FinanceFrame.PAGE_ADMIN = 13
RFF_FinanceFrame.PAGE_INSURANCE = 14
RFF_FinanceFrame.PAGE_FLEET = 15
RFF_FinanceFrame.PAGE_VEHICLE_INSURANCE = 16
RFF_FinanceFrame.PAGE_VEHICLE_COMPLIANCE = 17
RFF_FinanceFrame.PAGE_ROAD_COMPLIANCE = 18
RFF_FinanceFrame.PAGE_ROAD_SPEED_RULES = 19
RFF_FinanceFrame.PAGE_CROP_ADVANCES = 20
RFF_FinanceFrame.PAGE_ECONOMY = 21
RFF_FinanceFrame.PAGE_SAVINGS = 22
RFF_FinanceFrame.PAGE_ADVISER = 23
RFF_FinanceFrame.PAGE_INVESTMENTS = 24
RFF_FinanceFrame.PAGE_DEALERSHIP = 25
RFF_FinanceFrame.PAGE_MAX = 25

RFF_FinanceFrame.CATEGORY_OVERVIEW = 1
RFF_FinanceFrame.CATEGORY_BANKING = 2
RFF_FinanceFrame.CATEGORY_BORROWING = 3
RFF_FinanceFrame.CATEGORY_ASSETS_PROPERTY = 4
RFF_FinanceFrame.CATEGORY_VEHICLES = 5
RFF_FinanceFrame.CATEGORY_LENDERS = 6
RFF_FinanceFrame.CATEGORY_BUSINESS = 7

RFF_FinanceFrame.AMOUNTS = {}
for amount = 5000, 25000, 5000 do
    table.insert(RFF_FinanceFrame.AMOUNTS, amount)
end
for amount = 50000, 1000000, 25000 do
    table.insert(RFF_FinanceFrame.AMOUNTS, amount)
end
RFF_FinanceFrame.MIN_APPLICATION_AMOUNT = 1000
RFF_FinanceFrame.MAX_APPLICATION_AMOUNT = 50000000
RFF_FinanceFrame.TERMS = {12, 24, 36, 60, 84, 120, 180, 240}
RFF_FinanceFrame.MANAGEMENT_AMOUNTS = {1000, 5000, 10000, 25000, 50000, 100000}
RFF_FinanceFrame.PRODUCTS = {
    RFF_LoanService.TYPE_TERM,
    RFF_LoanService.TYPE_BULLET,
    RFF_LoanService.TYPE_REVOLVING,
    RFF_LoanService.TYPE_OVERDRAFT
}
RFF_FinanceFrame.PRODUCT_TEXT_KEYS = {
    [RFF_LoanService.TYPE_TERM] = "rff_product_term",
    [RFF_LoanService.TYPE_BULLET] = "rff_product_bullet",
    [RFF_LoanService.TYPE_REVOLVING] = "rff_product_revolving",
    [RFF_LoanService.TYPE_OVERDRAFT] = "rff_product_overdraft",
    [RFF_LoanService.TYPE_MORTGAGE] = "rff_product_mortgage",
    [RFF_LoanService.TYPE_RECOVERY_SHORTFALL] = "rff_product_recovery_shortfall"
}
RFF_FinanceFrame.PURPOSES = {
    {id = "GENERAL", key = "rff_purpose_general"},
    {id = "MACHINERY", key = "rff_purpose_machinery"},
    {id = "WORKING_CAPITAL", key = "rff_purpose_working_capital"},
    {id = "LAND_PROPERTY", key = "rff_purpose_land_property"}
}

local RFF_TENANCY_MONTH_KEYS = {
    "rff_month_january", "rff_month_february", "rff_month_march", "rff_month_april",
    "rff_month_may", "rff_month_june", "rff_month_july", "rff_month_august",
    "rff_month_september", "rff_month_october", "rff_month_november", "rff_month_december"
}

function RFF_FinanceFrame.new(i18n, manager)
    local self = RFF_FinanceFrame:superClass().new(nil, RFF_FinanceFrame_mt)
    self.i18n = i18n
    self.manager = manager
    self.pages = {}
    self.tabs = {}
    self.categoryTabs = {}
    self.categoryPages = {}
    self.secondaryLabels = {}
    self.currentCategory = self.CATEGORY_OVERVIEW
    self.currentSecondaryIndex = 1
    self.lastEvaluation = nil
    self.pendingApplication = nil
    self.pendingSubmission = nil
    self.creditApplications = {}
    self.agreements = {}
    self.pendingAgreementAction = nil
    self.pendingRefinanceQuote = nil
    self.assetAgreements = {}
    self.pendingAssetSettlement = nil
    self.brokerCases = {}
    self.brokerSourceApplications = {}
    self.brokerOffers = {}
    self.relationshipLenders = {}
    self.marketLenders = {}
    self.marketOffer = nil
    self.insuranceTierOptions = RFF_BusinessAdministrationService ~= nil and RFF_BusinessAdministrationService.INSURANCE_TIERS or {}
    self.insuranceClaims = {}
    self.insuranceTrafficIncidents = {}
    self.insuranceEntries = {}
    self.selectedInsuranceEntryKey = nil
    self.selectedInsuranceClaimId = nil
    self.pendingBrokerSource = nil
    self.pendingBrokerAcceptance = nil
    self.statementPeriodIndices = {}
    self.statementSelectedPeriod = nil
    self.statementTransactions = {}
    self.statementShowEveryEntry = false
    self.fleetVehicles = {}
    self.fleetSummary = nil
    self.vehicleInsuranceVehicles = {}
    self.selectedVehicleInsuranceUniqueId = nil
    self.vehicleInsuranceQuote = nil
    self.pendingVehicleInsuranceQuote = nil
    self.vehicleComplianceVehicles = {}
    self.selectedVehicleComplianceUniqueId = nil
    self.driverOffences = {}
    self.selectedDriverOffenceId = nil
    self.pendingMovementAuthorisation = nil
    self.licenceCategories = {"F", "H", "C", "ADR"}
    self.selectedLicenceCategory = "F"
    self.updatingLicenceModeOption = false
    self.tenancyAgreements = {}
    self.selectedTenancyAgreementId = nil
    self.selectedTenancyNarrativeIndex = nil
    self.pendingTenancyAction = nil
    self.applicationAmounts = {}
    for _, amount in ipairs(RFF_FinanceFrame.AMOUNTS) do
        table.insert(self.applicationAmounts, amount)
    end
    return self
end

function RFF_FinanceFrame:onGuiSetupFinished()
    RFF_FinanceFrame:superClass().onGuiSetupFinished(self)
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then
        option:setState(state)
    else
        option.state = state
    end
end

local function wrapText(text, maxChars)
    if text == nil then return "" end
    maxChars = maxChars or 34
    local wrapped = {}
    for sourceLine in (tostring(text) .. "\n"):gmatch("(.-)\n") do
        if sourceLine == "" then
            table.insert(wrapped, "")
        else
            local line = ""
            for word in sourceLine:gmatch("%S+") do
                if line == "" then
                    line = word
                elseif #line + #word + 1 <= maxChars then
                    line = line .. " " .. word
                else
                    table.insert(wrapped, line)
                    line = word
                end
            end
            if line ~= "" then table.insert(wrapped, line) end
        end
    end
    return table.concat(wrapped, "\n")
end

local function findClosestAmountIndex(amounts, target)
    if amounts == nil or #amounts == 0 then return 1 end
    local bestIndex = 1
    local bestDistance = math.huge
    for index, amount in ipairs(amounts) do
        local distance = math.abs((amount or 0) - (target or 0))
        if distance < bestDistance then
            bestDistance = distance
            bestIndex = index
        end
    end
    return bestIndex
end

function RFF_FinanceFrame:rebuildApplicationAmountOptions(selectedAmount)
    if self.amountOption == nil then return end
    local texts = {}
    for _, amount in ipairs(self.applicationAmounts or {}) do
        table.insert(texts, self:formatMoney(amount))
    end
    if self.amountOption.setTexts ~= nil then
        self.amountOption:setTexts(texts)
    else
        self.amountOption.texts = texts
    end
    setOptionState(self.amountOption, findClosestAmountIndex(self.applicationAmounts, selectedAmount or 100000))
end

function RFF_FinanceFrame:addExactApplicationAmount(amount)
    amount = math.floor(math.max(self.MIN_APPLICATION_AMOUNT, math.min(self.MAX_APPLICATION_AMOUNT, amount or 0)) + 0.5)
    local found = false
    for _, existing in ipairs(self.applicationAmounts) do
        if existing == amount then
            found = true
            break
        end
    end
    if not found then
        table.insert(self.applicationAmounts, amount)
        table.sort(self.applicationAmounts)
    end
    self:rebuildApplicationAmountOptions(amount)
end

function RFF_FinanceFrame:initialize()
    self.pages[self.PAGE_OVERVIEW] = self.overviewPage
    self.pages[self.PAGE_BANKING] = self.bankingPage
    self.pages[self.PAGE_APPLICATIONS] = self.applicationsPage
    self.pages[self.PAGE_AGREEMENTS] = self.agreementsPage
    self.pages[self.PAGE_ASSET] = self.assetPage
    self.pages[self.PAGE_PROPERTY] = self.propertyPage
    self.pages[self.PAGE_CASHFLOW] = self.cashflowPage
    self.pages[self.PAGE_CREDIT] = self.creditPage
    self.pages[self.PAGE_BROKER] = self.brokerPage
    self.pages[self.PAGE_RELATIONSHIPS] = self.relationshipsPage
    self.pages[self.PAGE_MARKET] = self.marketPage
    self.pages[self.PAGE_APPLY] = self.applyPage
    self.pages[self.PAGE_ADMIN] = self.adminPage
    self.pages[self.PAGE_INSURANCE] = self.insurancePage
    self.pages[self.PAGE_FLEET] = self.fleetPage
    self.pages[self.PAGE_VEHICLE_INSURANCE] = self.vehicleInsurancePage
    self.pages[self.PAGE_VEHICLE_COMPLIANCE] = self.vehicleCompliancePage
    self.pages[self.PAGE_ROAD_COMPLIANCE] = self.roadCompliancePage
    self.pages[self.PAGE_ROAD_SPEED_RULES] = self.roadSpeedRulesPage
    self.pages[self.PAGE_CROP_ADVANCES] = self.cropAdvancesPage
    self.pages[self.PAGE_ECONOMY] = self.economyPage
    self.pages[self.PAGE_SAVINGS] = self.savingsPage
    self.pages[self.PAGE_ADVISER] = self.adviserPage
    self.pages[self.PAGE_INVESTMENTS] = self.investmentsPage
    self.pages[self.PAGE_DEALERSHIP] = self.dealershipPage

    self.categoryTabs = {
        self.overviewCategoryTab,
        self.bankingCategoryTab,
        self.borrowingCategoryTab,
        self.assetsPropertyCategoryTab,
        self.vehiclesCategoryTab,
        self.lendersCategoryTab,
        self.businessCategoryTab
    }

    self.categoryPages = {
        [self.CATEGORY_OVERVIEW] = {self.PAGE_OVERVIEW, self.PAGE_ECONOMY},
        [self.CATEGORY_BANKING] = {self.PAGE_BANKING, self.PAGE_CASHFLOW, self.PAGE_SAVINGS, self.PAGE_ADVISER, self.PAGE_INVESTMENTS},
        [self.CATEGORY_BORROWING] = {self.PAGE_APPLY, self.PAGE_APPLICATIONS, self.PAGE_AGREEMENTS, self.PAGE_CROP_ADVANCES},
        [self.CATEGORY_ASSETS_PROPERTY] = {self.PAGE_ASSET, self.PAGE_PROPERTY},
        [self.CATEGORY_VEHICLES] = {self.PAGE_FLEET, self.PAGE_VEHICLE_INSURANCE, self.PAGE_ROAD_COMPLIANCE, self.PAGE_VEHICLE_COMPLIANCE, self.PAGE_ROAD_SPEED_RULES, self.PAGE_DEALERSHIP},
        [self.CATEGORY_LENDERS] = {self.PAGE_BROKER, self.PAGE_RELATIONSHIPS, self.PAGE_MARKET},
        [self.CATEGORY_BUSINESS] = {self.PAGE_CREDIT, self.PAGE_ADMIN, self.PAGE_INSURANCE}
    }

    self.secondaryLabels = {
        [self.CATEGORY_OVERVIEW] = {"rff_nav_dashboard", "rff_economy_tab"},
        [self.CATEGORY_BANKING] = {"rff_nav_account", "rff_tab_cashflow", "rff_savings_tab", "rff_adviser_tab", "rff_invest_tab"},
        [self.CATEGORY_BORROWING] = {"rff_nav_apply", "rff_tab_applications", "rff_tab_agreements", "rff_crop_tab"},
        [self.CATEGORY_ASSETS_PROPERTY] = {"rff_tab_asset_finance", "rff_tab_property"},
        [self.CATEGORY_VEHICLES] = {"rff_tab_fleet", "rff_tab_vehicle_insurance", "rff_tab_road_compliance", "rff_tab_vehicle_compliance", "rff_tab_road_speed_rules", "rff_dealer_tab"},
        [self.CATEGORY_LENDERS] = {"rff_tab_broker", "rff_tab_relationships", "rff_tab_market"},
        [self.CATEGORY_BUSINESS] = {"rff_nav_credit_profile", "rff_tab_tax_admin", "rff_tab_insurance"}
    }

    for category, tab in ipairs(self.categoryTabs) do
        if tab ~= nil then
            local background = tab:getDescendantByName("background")
            if background ~= nil then background:setSize(tab.size[1], tab.size[2]) end
            local categoryIndex = category
            tab.onClickCallback = function()
                self:setCategory(categoryIndex, 1)
            end
        end
    end

    self.secondaryTabs = {self.secondaryTab1, self.secondaryTab2, self.secondaryTab3, self.secondaryTab4, self.secondaryTab5, self.secondaryTab6}
    for index, tab in ipairs(self.secondaryTabs) do
        if tab ~= nil then
            local background = tab:getDescendantByName("background")
            if background ~= nil then background:setSize(tab.size[1], tab.size[2]) end
            local secondaryIndex = index
            tab.onClickCallback = function()
                self:onSecondaryNavigation(secondaryIndex)
            end
        end
    end

    if self.productOption ~= nil then
        for _, product in ipairs(self.PRODUCTS) do
            self.productOption:addText(self.i18n:getText(self.PRODUCT_TEXT_KEYS[product]))
        end
        setOptionState(self.productOption, 1)
    end

    if self.amountOption ~= nil then
        self:rebuildApplicationAmountOptions(100000)
    end

    if self.termOption ~= nil then
        for _, months in ipairs(self.TERMS) do
            self.termOption:addText(self:formatTerm(months))
        end
        setOptionState(self.termOption, 5)
    end

    if self.purposeOption ~= nil then
        for _, purpose in ipairs(self.PURPOSES) do
            self.purposeOption:addText(self.i18n:getText(purpose.key))
        end
        setOptionState(self.purposeOption, 1)
    end

    if self.managementAmountOption ~= nil then
        for _, amount in ipairs(self.MANAGEMENT_AMOUNTS) do
            self.managementAmountOption:addText(self:formatMoney(amount))
        end
        setOptionState(self.managementAmountOption, 3)
    end

    if self.statementEntryFilterOption ~= nil then
        self.statementEntryFilterOption:addText(self.i18n:getText("rff_statement_view_condensed"))
        self.statementEntryFilterOption:addText(self.i18n:getText("rff_statement_view_every_entry"))
        setOptionState(self.statementEntryFilterOption, self.statementShowEveryEntry and 2 or 1)
    end

    if self.speedingEnforcementOption ~= nil then
        self.speedingEnforcementOption:addText(self.i18n:getText("rff_speeding_off"))
        self.speedingEnforcementOption:addText(self.i18n:getText("rff_speeding_on"))
    end
    if self.roadsideChecksOption ~= nil then
        self.roadsideChecksOption:addText(self.i18n:getText("rff_speeding_off"))
        self.roadsideChecksOption:addText(self.i18n:getText("rff_speeding_on"))
    end
    if self.roadSpeedHudOption ~= nil then
        self.roadSpeedHudOption:addText(self.i18n:getText("rff_speed_hud_hidden"))
        self.roadSpeedHudOption:addText(self.i18n:getText("rff_speed_hud_shown"))
    end
    if self.insurancePointsOption ~= nil then
        self.insurancePointsOption:addText(self.i18n:getText("rff_insurance_points_off"))
        self.insurancePointsOption:addText(self.i18n:getText("rff_insurance_points_on"))
        setOptionState(self.insurancePointsOption, 1)
    end
    if self.drivingPenaltiesOption ~= nil then
        self.drivingPenaltiesOption:addText(self.i18n:getText("rff_driver_penalties_off"))
        self.drivingPenaltiesOption:addText(self.i18n:getText("rff_driver_penalties_on"))
        setOptionState(self.drivingPenaltiesOption, 1)
    end
    if self.licenceModeOption ~= nil then
        self.licenceModeOption:addText(self.i18n:getText("rff_licence_mode_full"))
        self.licenceModeOption:addText(self.i18n:getText("rff_licence_mode_required"))
        setOptionState(self.licenceModeOption, 1)
    end

    if self.statementList ~= nil then
        self.statementList:setDataSource(self)
        self.statementList:setDelegate(self)
    end
    if self.fleetVehicleList ~= nil then
        self.fleetVehicleList:setDataSource(self)
        self.fleetVehicleList:setDelegate(self)
    end
    if self.tenancyAgreementList ~= nil then
        self.tenancyAgreementList:setDataSource(self)
        self.tenancyAgreementList:setDelegate(self)
    end

    if self.relationshipLenderOption ~= nil and self.manager ~= nil and self.manager.relationshipService ~= nil then
        self.relationshipLenders = self.manager.relationshipService:getLenders() or {}
        for _, lender in ipairs(self.relationshipLenders) do
            self.relationshipLenderOption:addText(self.i18n:getText(lender.nameKey))
        end
        setOptionState(self.relationshipLenderOption, 1)
    end

    if self.marketLenderOption ~= nil and self.manager ~= nil and self.manager.lenderMarketService ~= nil then
        self.marketLenders = self.manager.lenderMarketService:getProfiles() or {}
        for _, lender in ipairs(self.marketLenders) do
            self.marketLenderOption:addText(self.i18n:getText(lender.nameKey))
        end
        setOptionState(self.marketLenderOption, 1)
    end

    if self.insuranceTierOption ~= nil then
        for _, tier in ipairs(self.insuranceTierOptions or {}) do
            self.insuranceTierOption:addText(self.i18n:getText(tier.key))
        end
        setOptionState(self.insuranceTierOption, 2)
    end
    if self.vehicleInsuranceAutoRenewOption ~= nil then
        self.vehicleInsuranceAutoRenewOption:addText(self.i18n:getText("rff_vehicle_auto_renew_off"))
        self.vehicleInsuranceAutoRenewOption:addText(self.i18n:getText("rff_vehicle_auto_renew_on"))
    end
    if self.vehicleInsuranceQuoteCoverOption ~= nil then
        self.vehicleInsuranceQuoteCoverOption:addText(self.i18n:getText("rff_vehicle_cover_third_party"))
        self.vehicleInsuranceQuoteCoverOption:addText(self.i18n:getText("rff_vehicle_cover_comprehensive"))
        setOptionState(self.vehicleInsuranceQuoteCoverOption, 2)
    end
    if self.vehicleInsuranceQuoteLegalOption ~= nil then
        self.vehicleInsuranceQuoteLegalOption:addText(self.i18n:getText("rff_vehicle_policy_not_included"))
        self.vehicleInsuranceQuoteLegalOption:addText(self.i18n:getText("rff_vehicle_policy_included"))
        setOptionState(self.vehicleInsuranceQuoteLegalOption, 1)
    end
    if self.vehicleInsuranceQuoteUseOption ~= nil then
        self.vehicleInsuranceQuoteUseOption:addText(self.i18n:getText("rff_vehicle_scope_farmland"))
        self.vehicleInsuranceQuoteUseOption:addText(self.i18n:getText("rff_vehicle_scope_agricultural_road"))
        setOptionState(self.vehicleInsuranceQuoteUseOption, 2)
    end
    if self.vehicleInsuranceQuoteWeightOption ~= nil then
        self.vehicleInsuranceQuoteWeightOption:addText(self.i18n:getText("rff_vehicle_weight_15"))
        self.vehicleInsuranceQuoteWeightOption:addText(self.i18n:getText("rff_vehicle_weight_30"))
        self.vehicleInsuranceQuoteWeightOption:addText(self.i18n:getText("rff_vehicle_weight_unrestricted"))
        setOptionState(self.vehicleInsuranceQuoteWeightOption, 3)
    end
    self:updateNavigation()
end

function RFF_FinanceFrame:onFrameOpen()
    RFF_FinanceFrame:superClass().onFrameOpen(self)
    self.statementSelectedPeriod = nil
    self:updateContent()
    self:setCategory(self.CATEGORY_OVERVIEW, 1)
end

function RFF_FinanceFrame:onFrameActivated()
    self:updateContent()
end

-- Retained for compatibility with older GUI/controller calls.
function RFF_FinanceFrame:onSubCategoryChanged(state)
    self:setPage(state or self.PAGE_OVERVIEW)
end

function RFF_FinanceFrame:getCategoryForPage(page)
    for category, pages in pairs(self.categoryPages or {}) do
        for index, candidate in ipairs(pages) do
            if candidate == page then return category, index end
        end
    end
    return nil, nil
end

function RFF_FinanceFrame:updateNavigation()
    for category, tab in ipairs(self.categoryTabs or {}) do
        if tab ~= nil then tab:setSelected(category == self.currentCategory) end
    end

    local labels = self.secondaryLabels[self.currentCategory] or {}
    for index, tab in ipairs(self.secondaryTabs or {}) do
        if tab ~= nil then
            local visible = index <= #labels and (self.categoryPages[self.currentCategory] or {})[index] ~= nil
            tab:setVisible(visible)
            if visible then
                local navWidth=GuiUtils.getNormalizedScreenValues((#labels>5 and "220px" or "260px").." 42px")
                tab:setSize(navWidth[1],tab.size[2])
                tab:setText(self.i18n:getText(labels[index]))
                tab:setSelected(index == self.currentSecondaryIndex)
                local background = tab:getDescendantByName("background")
                if background ~= nil then background:setSize(tab.size[1], tab.size[2]) end
            end
        end
    end

    if self.secondaryNavBox ~= nil and self.secondaryNavBox.invalidateLayout ~= nil then
        self.secondaryNavBox:invalidateLayout()
    end
end

function RFF_FinanceFrame:onSecondaryNavigation(index)
    self:setCategory(self.currentCategory, index)
end

function RFF_FinanceFrame:setCategory(category, secondaryIndex)
    category = math.max(self.CATEGORY_OVERVIEW, math.min(self.CATEGORY_BUSINESS, category or self.CATEGORY_OVERVIEW))
    local pages = self.categoryPages[category] or {self.PAGE_OVERVIEW}
    secondaryIndex = math.max(1, math.min(#pages, secondaryIndex or 1))
    self.currentCategory = category
    self.currentSecondaryIndex = secondaryIndex
    self:updateNavigation()
    self:showPage(pages[secondaryIndex])
end

function RFF_FinanceFrame:setPage(state)
    state = math.max(self.PAGE_OVERVIEW, math.min(self.PAGE_MAX, state or self.PAGE_OVERVIEW))
    local category, secondaryIndex = self:getCategoryForPage(state)
    if category ~= nil then
        self:setCategory(category, secondaryIndex)
    else
        self:showPage(state)
    end
end

function RFF_FinanceFrame:showPage(state)
    for index = self.PAGE_OVERVIEW, self.PAGE_MAX do
        local page = self.pages[index]
        if page ~= nil then page:setVisible(index == state) end
    end

    if state == self.PAGE_BANKING or state == self.PAGE_APPLY then
        self:updateBankingContent()
    elseif state == self.PAGE_APPLICATIONS then
        self:updateApplicationsContent(true)
    elseif state == self.PAGE_AGREEMENTS then
        self:updateAgreementsContent(true)
    elseif state == self.PAGE_ASSET then
        self:updateAssetFinanceContent(true)
    elseif state == self.PAGE_PROPERTY then
        self:updatePropertyContent()
    elseif state == self.PAGE_CASHFLOW then
        self:updateStatementContent(false)
    elseif state == self.PAGE_FLEET then
        self:updateFleetContent()
    elseif state == self.PAGE_VEHICLE_INSURANCE then
        self:updateVehicleInsuranceContent()
    elseif state == self.PAGE_ROAD_COMPLIANCE then
        self:updateRoadComplianceSettingsContent()
    elseif state == self.PAGE_VEHICLE_COMPLIANCE then
        self:updateVehicleComplianceContent()
    elseif state == self.PAGE_ROAD_SPEED_RULES then
        self:updateRoadSpeedRulesContent()
    elseif state == self.PAGE_ADVISER then
        self:updateAdviserContent()
    elseif state == self.PAGE_INVESTMENTS then
        self:updateInvestmentContent()
    elseif state == self.PAGE_DEALERSHIP then
        self:updateDealerContent()
    elseif state == self.PAGE_SAVINGS then
        self:updateSavingsContent()
    elseif state == self.PAGE_ECONOMY then
        self:updateEconomyContent()
    elseif state == self.PAGE_CROP_ADVANCES then
        self:updateCropAdvances(true)
    elseif state == self.PAGE_BROKER then
        self:updateBrokerContent(true)
    elseif state == self.PAGE_RELATIONSHIPS then
        self:updateRelationshipsContent()
    elseif state == self.PAGE_MARKET then
        self:updateMarketContent()
    elseif state == self.PAGE_ADMIN then
        self:updateBusinessAdministrationContent()
    elseif state == self.PAGE_INSURANCE then
        self:updateBusinessAdministrationContent()
        self:updateInsuranceClaimsContent(true)
    end
end

function RFF_FinanceFrame:formatMoney(value)
    return self.i18n:formatMoney(value or 0, 0, true, true)
end

function RFF_FinanceFrame:formatPercent(value)
    if value == math.huge then
        return "N/A"
    end
    return string.format("%.1f%%", (value or 0) * 100)
end

function RFF_FinanceFrame:formatTerm(months)
    months = math.max(0, math.floor(months or 0))
    if months >= 12 and months % 12 == 0 then
        local years = months / 12
        return string.format("%d year%s", years, years == 1 and "" or "s")
    end
    return string.format("%d months", months)
end

function RFF_FinanceFrame:formatDurationHours(hours)
    hours = math.max(0, math.floor((hours or 0) + 0.5))
    local days = math.floor(hours / 24)
    local remainder = hours % 24
    if days > 0 and remainder > 0 then
        return string.format(self.i18n:getText("rff_duration_days_hours"), days, remainder)
    elseif days > 0 then
        return string.format(self.i18n:getText("rff_duration_days"), days)
    end
    return string.format(self.i18n:getText("rff_duration_hours"), remainder)
end

function RFF_FinanceFrame:formatMovementAuthorisationRemaining(hours)
    local totalMinutes = math.max(0, math.ceil((hours or 0) * 60))
    return string.format(self.i18n:getText("rff_compliance_authorisation_time"),
        math.floor(totalMinutes / 60), totalMinutes % 60)
end

function RFF_FinanceFrame:formatDurationRange(minHours, maxHours)
    minHours = math.max(0, math.floor((minHours or 0) + 0.5))
    maxHours = math.max(minHours, math.floor((maxHours or 0) + 0.5))
    local first = self:formatDurationHours(minHours)
    local second = self:formatDurationHours(maxHours)
    if minHours == maxHours then return first end
    return string.format(self.i18n:getText("rff_duration_range"), first, second)
end

function RFF_FinanceFrame:formatApplicationTimestamp(hourStamp)
    hourStamp = math.max(0, math.floor(hourStamp or 0))
    local day = math.floor(hourStamp / 24)
    local hour = hourStamp % 24
    return string.format(self.i18n:getText("rff_application_timestamp"), day, hour)
end

function RFF_FinanceFrame:formatDscr(value)
    if value == nil or value == math.huge then
        return self.i18n:getText("rff_not_applicable")
    end
    return string.format("%.2f", value)
end

function RFF_FinanceFrame:getCurrentFarmId()
    if g_currentMission == nil then return 0 end
    return g_currentMission:getFarmId() or 0
end

function RFF_FinanceFrame:getSelectedApplication()
    local productIndex = math.max(1, math.min(#self.PRODUCTS, self.productOption ~= nil and (self.productOption.state or 1) or 1))
    local amounts = self.applicationAmounts or self.AMOUNTS
    local amountIndex = math.max(1, math.min(#amounts, self.amountOption ~= nil and (self.amountOption.state or 1) or 1))
    local termIndex = math.max(1, math.min(#self.TERMS, self.termOption ~= nil and (self.termOption.state or 1) or 1))
    local purposeIndex = math.max(1, math.min(#self.PURPOSES, self.purposeOption ~= nil and (self.purposeOption.state or 1) or 1))

    local product = self.PRODUCTS[productIndex]
    local months = product == RFF_LoanService.TYPE_OVERDRAFT and 12 or self.TERMS[termIndex]
    return {
        product = product,
        amount = amounts[amountIndex],
        months = months,
        purpose = self.PURPOSES[purposeIndex].id
    }
end

function RFF_FinanceFrame:getPurposeText(purposeId)
    if purposeId == "LEGACY_FINANCE" then return self.i18n:getText("rff_purpose_legacy_finance") end
    if purposeId == "ASSET_RECOVERY_SHORTFALL" then return self.i18n:getText("rff_purpose_recovery_shortfall") end
    if purposeId == "PROPERTY_RECOVERY_SHORTFALL" then return self.i18n:getText("rff_purpose_property_recovery_shortfall") end
    if purposeId == "REFINANCE" then return self.i18n:getText("rff_purpose_refinance") end
    if purposeId == "DEBT_CONSOLIDATION" then return self.i18n:getText("rff_purpose_debt_consolidation") end
    if purposeId == "RESCUE_FINANCE" then return self.i18n:getText("rff_purpose_rescue_finance") end
    for _, purpose in ipairs(self.PURPOSES) do
        if purpose.id == purposeId then
            return self.i18n:getText(purpose.key)
        end
    end
    return tostring(purposeId or "-")
end

function RFF_FinanceFrame:getArrearsStageText(stage)
    if stage == "REMINDER" then return self.i18n:getText("rff_status_payment_reminder") end
    if stage == "ARREARS_WARNING" then return self.i18n:getText("rff_status_arrears_warning") end
    if stage == "DEFAULT_NOTICE" then return self.i18n:getText("rff_status_default_notice") end
    if stage == "FORMAL_DEMAND" then return self.i18n:getText("rff_status_formal_demand") end
    if stage == "POSSESSION_WARNING" then return self.i18n:getText("rff_status_possession_warning") end
    if stage == "RECOVERY" then return self.i18n:getText("rff_status_recovery") end
    return self.i18n:getText("rff_status_arrears")
end

function RFF_FinanceFrame:getForbearanceTypeText(planType)
    if planType == RFF_ForbearanceService.TYPE_HOLIDAY then return self.i18n:getText("rff_forbearance_type_payment_holiday") end
    if planType == RFF_ForbearanceService.TYPE_INTEREST_ONLY then return self.i18n:getText("rff_forbearance_type_interest_only") end
    if planType == RFF_ForbearanceService.TYPE_RESTRUCTURE then return self.i18n:getText("rff_forbearance_type_restructure") end
    return tostring(planType or "-")
end

function RFF_FinanceFrame:getAgreementStatusText(loan)
    if loan == nil then
        return self.i18n:getText("rff_none")
    end
    if loan.mortgageRecovered == true then
        return self.i18n:getText(loan.mortgageRecoveryMethod == "VOLUNTARY_PROPERTY_SALE" and "rff_status_property_voluntary_sale" or "rff_status_property_recovered")
    end
    if loan.paidOff and loan.rescueRefinanced == true then return self.i18n:getText("rff_status_rescue_refinanced") end
    if loan.paidOff and loan.refinanced == true then return self.i18n:getText("rff_status_refinanced") end
    if loan.paidOff then return self.i18n:getText("rff_status_completed") end
    if loan.type == RFF_LoanService.TYPE_RECOVERY_SHORTFALL then return self.i18n:getText("rff_status_recovery_liability") end
    if (loan.arrearsBalance or 0) > 0.01 then return self:getArrearsStageText(loan.arrearsStage) end
    if loan.type == RFF_LoanService.TYPE_OVERDRAFT and loan.overdraftSuspended == true then return self.i18n:getText("rff_status_overdraft_suspended") end
    return self.i18n:getText("rff_status_active")
end

function RFF_FinanceFrame:getSelectedManagementAmount()
    local index = math.max(1, math.min(#self.MANAGEMENT_AMOUNTS, self.managementAmountOption ~= nil and (self.managementAmountOption.state or 1) or 1))
    return self.MANAGEMENT_AMOUNTS[index]
end

function RFF_FinanceFrame:getApplicationStatusText(application)
    if application == nil or self.manager == nil or self.manager.applicationService == nil then
        return self.i18n:getText("rff_none")
    end
    return self.i18n:getText(self.manager.applicationService:getStatusLabelKey(application.status, application))
end

function RFF_FinanceFrame:getApplicationRouteText(application)
    if application == nil or self.manager == nil or self.manager.applicationService == nil then return "-" end
    return self.i18n:getText(self.manager.applicationService:getRouteLabelKey(application.route))
end

function RFF_FinanceFrame:getApplicationOutcomeText(application)
    if application == nil then return "-" end
    if application.outcome == "APPROVED" then return self.i18n:getText("rff_outcome_approved") end
    if application.outcome == "COUNTEROFFER" then return self.i18n:getText("rff_outcome_counteroffer") end
    if application.outcome == "COUNTEROFFER_ACCEPTED" then return self.i18n:getText("rff_outcome_counteroffer_accepted") end
    if application.outcome == "APPROVED_ACCEPTED" then return self.i18n:getText("rff_outcome_accepted") end
    if application.outcome == "DECLINED" then return self.i18n:getText("rff_outcome_declined") end
    if application.outcome == "WITHDRAWN" then return self.i18n:getText("rff_outcome_withdrawn") end
    if application.outcome == "EXPIRED" then return self.i18n:getText("rff_outcome_expired") end
    return self.i18n:getText("rff_outcome_pending")
end

function RFF_FinanceFrame:getApplicationReasonText(application)
    if application == nil then return "-" end
    local reason = application.decisionReason
    if reason == "startup_ltv" or reason == "no_collateral" then return self.i18n:getText("rff_reason_security") end
    if reason == "affordability" or reason == "affordability_after_pricing" then return self.i18n:getText("rff_reason_affordability") end
    if reason == "payment_conduct" then return self.i18n:getText("rff_reason_payment_conduct") end
    if reason == "overdraft_exists" then return self.i18n:getText("rff_reason_overdraft_exists") end
    if reason == "lender_appetite" then return self.i18n:getText("rff_reason_lender_appetite") end
    if reason == "property_ltv" or reason == "overall_ltv" then return self.i18n:getText("rff_reason_property_ltv") end
    if reason == "security_unavailable" or reason == "already_mortgaged" or reason == "property_not_owned" then return self.i18n:getText("rff_equity_release_no_security") end
    if reason == "valuation_shortfall" then return self.i18n:getText("rff_reason_valuation_shortfall") end
    if reason == "secured_agricultural" then return self.i18n:getText("rff_reason_secured_agricultural") end
    if reason == "farmland_not_for_sale" then return self.i18n:getText("rff_farmland_not_for_sale") end
    if reason == "property_unavailable" or reason == "price_changed" then return self.i18n:getText("rff_reason_property_changed") end
    if reason == "approved" or reason == "formal_offer" or reason == "" then return self.i18n:getText("rff_reason_none") end
    return tostring(reason or "-")
end

function RFF_FinanceFrame:rebuildApplicationSelector(preserveApplicationId)
    if self.applicationOption == nil or self.manager == nil or self.manager.repository == nil then return end
    local farmId = self:getCurrentFarmId()
    self.creditApplications = self.manager.repository:getApplicationsByFarm(farmId)
    table.sort(self.creditApplications, function(a, b) return (a.id or 0) > (b.id or 0) end)

    local texts = {}
    local selected = 1
    for index, application in ipairs(self.creditApplications) do
        local productName
        if application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then productName = self.i18n:getText("rff_product_holding_equity_release")
        elseif application.propertyFinanceMode == "EQUITY_RELEASE" then productName = self.i18n:getText("rff_product_equity_release")
        else productName = self.i18n:getText(self.PRODUCT_TEXT_KEYS[application.product] or "rff_product_term") end
        table.insert(texts, string.format("#%d  %s  -  %s", application.id or index, productName, self:getApplicationStatusText(application)))
        if preserveApplicationId ~= nil and application.id == preserveApplicationId then selected = index end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_none")} end
    if self.applicationOption.setTexts ~= nil then self.applicationOption:setTexts(texts) else self.applicationOption.texts = texts end
    setOptionState(self.applicationOption, selected)
end

function RFF_FinanceFrame:getSelectedCreditApplication()
    if self.creditApplications == nil or #self.creditApplications == 0 then return nil end
    local index = math.max(1, math.min(#self.creditApplications, self.applicationOption ~= nil and (self.applicationOption.state or 1) or 1))
    return self.creditApplications[index]
end

function RFF_FinanceFrame:onCreditApplicationChanged()
    self:updateApplicationsContent(false)
end

function RFF_FinanceFrame:updateApplicationsContent(rebuild)
    if self.manager == nil or self.manager.repository == nil or self.manager.applicationService == nil then return end
    local current = self:getSelectedCreditApplication()
    local preserveId = current ~= nil and current.id or nil
    if rebuild or self.creditApplications == nil or #self.creditApplications == 0 then
        self:rebuildApplicationSelector(preserveId)
    end

    local application = self:getSelectedCreditApplication()
    local fields = {"applicationStatusValue","applicationRouteValue","applicationProductValue","applicationPurposeValue","applicationRequestedValue","applicationTermValue","applicationSubmittedValue","applicationDecisionDueValue","applicationSubmissionAssetsValue","applicationSubmissionCollateralValue","applicationSubmissionIncomeValue","applicationSubmissionLtvValue","applicationSubmissionDscrValue","applicationLenderValuationValue","applicationRequestedDepositValue","applicationOfferDepositValue","applicationPropertyLtvValue","applicationOutcomeValue","applicationOfferedValue","applicationOfferRateValue","applicationOfferPaymentValue","applicationOfferGradeValue","applicationOfferExpiryValue","applicationReasonValue"}
    if self.instantMortgageButton then self.instantMortgageButton:setVisible(self.manager.applicationService:canInstantDecision(application,self:getCurrentFarmId())) end
    if application == nil then
        for _, name in ipairs(fields) do if self[name] ~= nil then self[name]:setText("-") end end
        if self.acceptOfferButton ~= nil then self.acceptOfferButton:setVisible(false) end
        if self.withdrawApplicationButton ~= nil then self.withdrawApplicationButton:setVisible(false) end
        return
    end

    local service = self.manager.applicationService
    service:normaliseApplicationTiming(application)
    local nowHour = service:getCurrentHourStamp()
    local productName
    if application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then productName = self.i18n:getText("rff_product_holding_equity_release")
    elseif application.propertyFinanceMode == "EQUITY_RELEASE" then productName = self.i18n:getText("rff_product_equity_release")
    else productName = self.i18n:getText(self.PRODUCT_TEXT_KEYS[application.product] or "rff_product_term") end
    local decisionRemaining = math.max(0, (application.decisionHour or nowHour) - nowHour)
    local expiryRemaining = math.max(0, (application.offerExpiryHour or nowHour) - nowHour)

    if self.applicationStatusValue ~= nil then self.applicationStatusValue:setText(self:getApplicationStatusText(application)) end
    if self.applicationRouteValue ~= nil then self.applicationRouteValue:setText(self:getApplicationRouteText(application)) end
    if self.applicationProductValue ~= nil then self.applicationProductValue:setText(productName) end
    if self.applicationPurposeValue ~= nil then self.applicationPurposeValue:setText(self:getPurposeText(application.purpose)) end
    if self.applicationRequestedValue ~= nil then self.applicationRequestedValue:setText(self:formatMoney(application.requestedAmount or 0)) end
    if self.applicationTermValue ~= nil then
        local termText = application.product == RFF_LoanService.TYPE_REVOLVING and self.i18n:getText("rff_revolving_open_ended") or self:formatTerm(application.requestedMonths or 0)
        if application.product == RFF_LoanService.TYPE_OVERDRAFT then termText = self.i18n:getText("rff_overdraft_annual_review") end
        self.applicationTermValue:setText(termText)
    end
    if self.applicationSubmittedValue ~= nil then self.applicationSubmittedValue:setText(self:formatApplicationTimestamp(application.submittedHour or 0)) end
    if self.applicationDecisionDueValue ~= nil then
        local value = service:isPending(application) and string.format(self.i18n:getText("rff_approx_time_remaining"), self:formatDurationHours(decisionRemaining)) or "-"
        self.applicationDecisionDueValue:setText(value)
    end
    if self.applicationSubmissionAssetsValue ~= nil then self.applicationSubmissionAssetsValue:setText(self:formatMoney(application.submissionAssets or 0)) end
    if self.applicationSubmissionCollateralValue ~= nil then self.applicationSubmissionCollateralValue:setText(self:formatMoney(application.submissionCollateral or 0)) end
    if self.applicationSubmissionIncomeValue ~= nil then self.applicationSubmissionIncomeValue:setText(self:formatMoney(application.submissionIncome or 0)) end
    if self.applicationSubmissionLtvValue ~= nil then self.applicationSubmissionLtvValue:setText(self:formatPercent(application.submissionLtv or 0)) end
    if self.applicationSubmissionDscrValue ~= nil then self.applicationSubmissionDscrValue:setText(self:formatDscr(application.submissionDscr)) end
    local isMortgage = application.product == RFF_LoanService.TYPE_MORTGAGE
    if self.applicationLenderValuationValue ~= nil then self.applicationLenderValuationValue:setText(isMortgage and (application.lenderValuation or 0) > 0 and self:formatMoney(application.lenderValuation) or "-") end
    if self.applicationRequestedDepositValue ~= nil then self.applicationRequestedDepositValue:setText(isMortgage and self:formatMoney(application.requestedDepositAmount or 0) or "-") end
    if self.applicationOfferDepositValue ~= nil then self.applicationOfferDepositValue:setText(isMortgage and (application.offeredDeposit or 0) > 0 and self:formatMoney(application.offeredDeposit) or "-") end
    if self.applicationPropertyLtvValue ~= nil then
        local ltv = (application.offeredPropertyLtv or 0) > 0 and application.offeredPropertyLtv or application.submissionPropertyLtv
        local limit = application.propertyLtvLimit or 0
        if isMortgage and ltv ~= nil then
            self.applicationPropertyLtvValue:setText(limit > 0 and string.format("%.1f%% / %.0f%% max", ltv * 100, limit * 100) or string.format("%.1f%% / pending", ltv * 100))
        else
            self.applicationPropertyLtvValue:setText("-")
        end
    end

    if self.applicationOutcomeValue ~= nil then self.applicationOutcomeValue:setText(wrapText(self:getApplicationOutcomeText(application), 30)) end
    if self.applicationOfferedValue ~= nil then self.applicationOfferedValue:setText((application.offeredAmount or 0) > 0 and self:formatMoney(application.offeredAmount) or "-") end
    if self.applicationOfferRateValue ~= nil then self.applicationOfferRateValue:setText((application.offeredRate or 0) > 0 and string.format("%.2f%%", application.offeredRate) or "-") end
    if self.applicationOfferPaymentValue ~= nil then self.applicationOfferPaymentValue:setText((application.offeredPayment or 0) > 0 and self:formatMoney(application.offeredPayment) or "-") end
    if self.applicationOfferGradeValue ~= nil then self.applicationOfferGradeValue:setText(application.offeredGrade ~= "" and application.offeredGrade or "-") end
    if self.applicationOfferExpiryValue ~= nil then
        self.applicationOfferExpiryValue:setText(application.status == RFF_ApplicationService.STATUS_OFFERED and self:formatDurationHours(expiryRemaining) or "-")
    end
    if self.applicationReasonValue ~= nil then self.applicationReasonValue:setText(wrapText(self:getApplicationReasonText(application), 34)) end

    if self.acceptOfferButton ~= nil then self.acceptOfferButton:setVisible(application.status == RFF_ApplicationService.STATUS_OFFERED) end
    if self.withdrawApplicationButton ~= nil then self.withdrawApplicationButton:setVisible(service:isPending(application) or application.status == RFF_ApplicationService.STATUS_OFFERED) end
end

function RFF_FinanceFrame:onInstantMortgage()
    self.pendingInstantMortgage=self:getSelectedCreditApplication()
    if not self.manager.applicationService:canInstantDecision(self.pendingInstantMortgage,self:getCurrentFarmId()) then return end
    YesNoDialog.show(self.onInstantMortgageConfirmed,self,self.i18n:getText("rff_instant_decision_confirm"),self.i18n:getText("rff_instant_decision"))
end
function RFF_FinanceFrame:onInstantMortgageConfirmed(yes)
    local application=self.pendingInstantMortgage;self.pendingInstantMortgage=nil
    if not yes then return end
    local ok=self.manager.applicationService:instantDecision(application,self:getCurrentFarmId())
    InfoDialog.show(self.i18n:getText(ok and "rff_instant_decision_done" or "rff_instant_decision_unavailable"))
    self:updateApplicationsContent(true)
end
function RFF_FinanceFrame:onInstantTenancy()
    self.pendingInstantTenancy=self:getSelectedTenancyAgreement()
    if not self.manager.propertyFinance:canInstantTenancyDecision(self.pendingInstantTenancy,self:getCurrentFarmId()) then return end
    YesNoDialog.show(self.onInstantTenancyConfirmed,self,self.i18n:getText("rff_instant_decision_confirm"),self.i18n:getText("rff_instant_decision"))
end
function RFF_FinanceFrame:onInstantTenancyConfirmed(yes)
    local tenancy=self.pendingInstantTenancy;self.pendingInstantTenancy=nil
    if not yes then return end
    local ok=self.manager.propertyFinance:instantTenancyDecision(tenancy,self:getCurrentFarmId())
    InfoDialog.show(self.i18n:getText(ok and "rff_instant_decision_done" or "rff_instant_decision_unavailable"))
    self:updatePropertyContent()
end

function RFF_FinanceFrame:onClickAcceptOffer()
    local application = self:getSelectedCreditApplication()
    if application == nil or application.status ~= RFF_ApplicationService.STATUS_OFFERED then return end
    self.pendingApplication = application
    local text
    if application.product == RFF_LoanService.TYPE_MORTGAGE then
        if application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then
            text = string.format(self.i18n:getText("rff_accept_holding_equity_release_offer_confirm"), application.securityFarmlandCount or 0,
                tostring(application.securityFarmlandIds or ""), self:formatMoney(application.purchasePrice or 0), self:formatMoney(application.lenderValuation or 0),
                self:formatMoney(application.offeredAmount or 0), application.offeredRate or 0, self:formatMoney(application.offeredPayment or 0))
        elseif application.propertyFinanceMode == "EQUITY_RELEASE" then
            text = string.format(self.i18n:getText("rff_accept_equity_release_offer_confirm"), application.farmlandId or 0,
                self:formatMoney(application.purchasePrice or 0), self:formatMoney(application.lenderValuation or 0),
                self:formatMoney(application.offeredAmount or 0), application.offeredRate or 0, self:formatMoney(application.offeredPayment or 0))
        else
            text = string.format(self.i18n:getText("rff_accept_mortgage_offer_confirm"),
                self:formatMoney(application.purchasePrice or 0), self:formatMoney(application.lenderValuation or 0),
                self:formatMoney(application.offeredDeposit or 0), self:formatMoney(application.offeredAmount or 0),
                application.offeredRate or 0, self:formatMoney(application.offeredPayment or 0))
        end
    else
        text = string.format(self.i18n:getText("rff_accept_offer_confirm"), self:formatMoney(application.offeredAmount or 0), application.offeredRate or 0, self:formatMoney(application.offeredPayment or 0))
    end
    YesNoDialog.show(self.onAcceptOfferConfirmed, self, text, self.i18n:getText("rff_application_offer"))
end

function RFF_FinanceFrame:onAcceptOfferConfirmed(confirmed)
    local application = self.pendingApplication
    self.pendingApplication = nil
    if not confirmed or application == nil then return end
    local loan, reason = self.manager.applicationService:acceptOffer(application)
    if loan == nil then
        if reason == "expired" then
            InfoDialog.show(self.i18n:getText("rff_offer_expired_message"))
        elseif reason == "funds" and application.product == RFF_LoanService.TYPE_MORTGAGE then
            InfoDialog.show(self.i18n:getText("rff_mortgage_offer_extra_deposit_funds"))
        elseif (reason == "property_unavailable" or reason == "price_changed") and application.product == RFF_LoanService.TYPE_MORTGAGE then
            InfoDialog.show(self.i18n:getText("rff_mortgage_offer_property_changed"))
        elseif reason == "payment_conduct" then
            InfoDialog.show(self.i18n:getText("rff_clear_arrears_first"))
        else
            InfoDialog.show(self.i18n:getText("rff_offer_accept_failed"))
        end
    else
        if application.product == RFF_LoanService.TYPE_MORTGAGE then
            if application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then
                InfoDialog.show(string.format(self.i18n:getText("rff_holding_equity_release_offer_accepted_message"), application.securityFarmlandCount or 0, self:formatMoney(application.offeredAmount or 0)))
            elseif application.propertyFinanceMode == "EQUITY_RELEASE" then
                InfoDialog.show(string.format(self.i18n:getText("rff_equity_release_offer_accepted_message"), application.farmlandId or 0, self:formatMoney(application.offeredAmount or 0)))
            else
                InfoDialog.show(string.format(self.i18n:getText("rff_mortgage_offer_accepted_message"), self:formatMoney(application.purchasePrice or 0), self:formatMoney(application.offeredDeposit or 0), self:formatMoney(application.offeredAmount or 0)))
            end
        else
            InfoDialog.show(string.format(self.i18n:getText("rff_offer_accepted_message"), self:formatMoney(application.offeredAmount or 0)))
        end
    end
    self:updateContent()
    self:updateApplicationsContent(true)
end

function RFF_FinanceFrame:onClickWithdrawApplication()
    local application = self:getSelectedCreditApplication()
    if application == nil then return end
    self.pendingApplication = application
    YesNoDialog.show(self.onWithdrawApplicationConfirmed, self, self.i18n:getText("rff_withdraw_application_confirm"), self.i18n:getText("rff_application_history"))
end

function RFF_FinanceFrame:onWithdrawApplicationConfirmed(confirmed)
    local application = self.pendingApplication
    self.pendingApplication = nil
    if not confirmed or application == nil then return end
    if self.manager.applicationService:withdrawApplication(application) then
        InfoDialog.show(self.i18n:getText("rff_application_withdrawn_message"))
    end
    self:updateApplicationsContent(true)
end

function RFF_FinanceFrame:rebuildAgreementSelector(preserveLoanId)
    if self.agreementOption == nil or self.manager == nil or self.manager.repository == nil then
        return
    end

    local farmId = self:getCurrentFarmId()
    self.agreements = self.manager.repository:getLoansByFarm(farmId, false)
    table.sort(self.agreements, function(a, b)
        if (a.paidOff == true) ~= (b.paidOff == true) then
            return a.paidOff ~= true
        end
        return (a.id or 0) > (b.id or 0)
    end)

    local texts = {}
    local selected = 1
    for index, loan in ipairs(self.agreements) do
        local productName
        if loan.legacyImported == true then productName = self.i18n:getText("rff_product_legacy")
        elseif loan.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then productName = self.i18n:getText("rff_product_holding_equity_release")
        elseif loan.propertyFinanceMode == "EQUITY_RELEASE" then productName = self.i18n:getText("rff_product_equity_release")
        else productName = self.i18n:getText(self.PRODUCT_TEXT_KEYS[loan.type] or "rff_product_term") end
        local status = loan.paidOff and self.i18n:getText("rff_status_completed_short") or self.i18n:getText("rff_status_active_short")
        if loan.refinanced == true then status = self.i18n:getText("rff_status_refinanced_short") end
        if loan.mortgageRecovered == true then status = self.i18n:getText("rff_status_recovered_short") end
        if loan.type == RFF_LoanService.TYPE_RECOVERY_SHORTFALL and not loan.paidOff then status = self.i18n:getText("rff_status_default_short") end
        local lenderName = loan.lenderNameKey ~= nil and self.i18n:getText(loan.lenderNameKey) or self.i18n:getText("rff_lender_primary_bank")
        if loan.brokered then
            table.insert(texts, string.format("#%d  %s  -  %s  -  %s", loan.id or index, productName, lenderName, status))
        else
            table.insert(texts, string.format("#%d  %s  -  %s", loan.id or index, productName, status))
        end
        if preserveLoanId ~= nil and loan.id == preserveLoanId then
            selected = index
        end
    end

    if #texts == 0 then
        table.insert(texts, self.i18n:getText("rff_none"))
        selected = 1
    end
    if self.agreementOption.setTexts ~= nil then
        self.agreementOption:setTexts(texts)
    else
        self.agreementOption.texts = texts
    end
    setOptionState(self.agreementOption, selected)
end

function RFF_FinanceFrame:getSelectedAgreement()
    if self.agreements == nil or #self.agreements == 0 then
        return nil
    end
    local index = math.max(1, math.min(#self.agreements, self.agreementOption ~= nil and (self.agreementOption.state or 1) or 1))
    return self.agreements[index]
end

function RFF_FinanceFrame:onAgreementChanged()
    self:updateAgreementsContent(false)
end

function RFF_FinanceFrame:onManagementAmountChanged()
    self:updateAgreementsContent(false)
end

function RFF_FinanceFrame:updateSchedulePreview(loan)
    local schedule = self.manager.loanService:getProjectedSchedule(loan, 6)
    for i = 1, 6 do
        local monthField = self[string.format("scheduleMonth%d", i)]
        local paymentField = self[string.format("schedulePayment%d", i)]
        local principalField = self[string.format("schedulePrincipal%d", i)]
        local interestField = self[string.format("scheduleInterest%d", i)]
        local balanceField = self[string.format("scheduleBalance%d", i)]
        local row = schedule[i]
        if row ~= nil then
            if monthField ~= nil then monthField:setText(row.revolving and self.i18n:getText("rff_current") or tostring(row.month)) end
            if paymentField ~= nil then paymentField:setText(self:formatMoney(row.payment)) end
            if principalField ~= nil then principalField:setText(self:formatMoney(row.principal)) end
            if interestField ~= nil then interestField:setText(self:formatMoney(row.interest)) end
            if balanceField ~= nil then balanceField:setText(self:formatMoney(row.closingBalance)) end
        else
            if monthField ~= nil then monthField:setText("-") end
            if paymentField ~= nil then paymentField:setText("-") end
            if principalField ~= nil then principalField:setText("-") end
            if interestField ~= nil then interestField:setText("-") end
            if balanceField ~= nil then balanceField:setText("-") end
        end
    end
end

function RFF_FinanceFrame:updateAgreementsContent(rebuild)
    if self.manager == nil or self.manager.repository == nil or self.manager.loanService == nil then
        return
    end

    local current = self:getSelectedAgreement()
    local preserveId = current ~= nil and current.id or nil
    if rebuild or self.agreements == nil or #self.agreements == 0 then
        self:rebuildAgreementSelector(preserveId)
    end

    local loan = self:getSelectedAgreement()
    local service = self.manager.loanService
    if loan == nil then
        local emptyFields = {"agreementStatusValue", "agreementPurposeValue", "agreementLenderValue", "agreementOriginalValue", "agreementOutstandingValue", "agreementRateValue", "agreementGradeValue", "agreementRemainingValue", "agreementPaymentValue", "agreementPaymentsMadeValue", "agreementMissedValue", "agreementArrearsValue", "agreementConsecutiveMissedValue", "agreementPrincipalPaidValue", "agreementInterestPaidValue"}
        for _, fieldName in ipairs(emptyFields) do
            if self[fieldName] ~= nil then self[fieldName]:setText("-") end
        end
        self:updateSchedulePreview(nil)
        if self.extraRepayButton ~= nil then self.extraRepayButton:setVisible(false) end
        if self.agreementArrearsButton ~= nil then self.agreementArrearsButton:setVisible(false) end
        if self.settleButton ~= nil then self.settleButton:setVisible(false) end
        if self.agreementDrawButton ~= nil then self.agreementDrawButton:setVisible(false) end
        if self.agreementRepayButton ~= nil then self.agreementRepayButton:setVisible(false) end
        if self.mortgageRestructureButton ~= nil then self.mortgageRestructureButton:setVisible(false) end
        if self.mortgageSurrenderButton ~= nil then self.mortgageSurrenderButton:setVisible(false) end
        if self.refinanceButton ~= nil then self.refinanceButton:setVisible(false) end
        if self.consolidateButton ~= nil then self.consolidateButton:setVisible(false) end
        if self.paymentHelpButton ~= nil then self.paymentHelpButton:setVisible(false) end
        if self.rescueFinanceButton ~= nil then self.rescueFinanceButton:setVisible(false) end
        if self.agreementInterestLabel ~= nil then self.agreementInterestLabel:setText(self.i18n:getText("rff_interest_paid")) end
        if self.agreementManagementNote ~= nil then self.agreementManagementNote:setText(wrapText(self.i18n:getText("rff_management_note"), 62)) end
        return
    end

    local outstanding = service:getLoanOutstanding(loan)
    local isRevolving = loan.type == RFF_LoanService.TYPE_REVOLVING
    local isOverdraft = loan.type == RFF_LoanService.TYPE_OVERDRAFT
    local isShortfall = loan.type == RFF_LoanService.TYPE_RECOVERY_SHORTFALL
    local isMortgage = loan.type == RFF_LoanService.TYPE_MORTGAGE
    local original = (isRevolving or isOverdraft) and (loan.creditLimit or 0) or (loan.originalAmount or 0)
    local payment = (isRevolving or isOverdraft) and service:getCurrentInterestDue(loan) or (loan.monthlyPayment or 0)
    if isShortfall then payment = service:getCurrentInterestDue(loan) + (RFF_LoanService.RECOVERY_ADMIN_CHARGE or 0) end

    if self.agreementStatusValue ~= nil then self.agreementStatusValue:setText(self:getAgreementStatusText(loan)) end
    if self.agreementPurposeValue ~= nil then self.agreementPurposeValue:setText(self:getPurposeText(loan.purpose)) end
    if self.agreementLenderValue ~= nil then
        local lenderName = loan.lenderNameKey ~= nil and self.i18n:getText(loan.lenderNameKey) or self.i18n:getText("rff_lender_primary_bank")
        self.agreementLenderValue:setText(lenderName)
    end
    if self.agreementOriginalValue ~= nil then self.agreementOriginalValue:setText(self:formatMoney(original)) end
    if self.agreementOutstandingValue ~= nil then self.agreementOutstandingValue:setText(self:formatMoney(outstanding)) end
    if self.agreementRateValue ~= nil then self.agreementRateValue:setText(string.format("%.2f%%", loan.interestRate or 0)) end
    if self.agreementGradeValue ~= nil then self.agreementGradeValue:setText(loan.riskGrade or "-") end
    if self.agreementRemainingValue ~= nil then
        local remainingText = self:formatTerm(loan.remainingMonths or 0)
        if isRevolving then remainingText = self.i18n:getText("rff_revolving_open_ended") end
        if isOverdraft then remainingText = string.format(self.i18n:getText("rff_overdraft_review_remaining"), math.max(0, loan.remainingMonths or 0)) end
        if isShortfall then remainingText = self.i18n:getText("rff_recovery_until_repaid") end
        self.agreementRemainingValue:setText(remainingText)
    end
    if self.agreementPaymentValue ~= nil then self.agreementPaymentValue:setText(self:formatMoney(payment)) end
    if self.agreementPaymentsMadeValue ~= nil then self.agreementPaymentsMadeValue:setText(tostring(loan.paymentsMade or 0)) end
    if self.agreementMissedValue ~= nil then self.agreementMissedValue:setText(tostring(loan.missedPayments or 0)) end
    if self.agreementArrearsValue ~= nil then self.agreementArrearsValue:setText(self:formatMoney(loan.arrearsBalance or 0)) end
    if self.agreementConsecutiveMissedValue ~= nil then self.agreementConsecutiveMissedValue:setText(tostring(loan.consecutiveMissedPayments or 0)) end
    if self.agreementPrincipalPaidValue ~= nil then self.agreementPrincipalPaidValue:setText(self:formatMoney(loan.principalPaid or 0)) end
    if self.agreementInterestPaidValue ~= nil then
        local interestDisplay = isShortfall and (loan.capitalisedInterest or 0) or (loan.interestPaid or 0)
        self.agreementInterestPaidValue:setText(self:formatMoney(interestDisplay))
    end
    if self.agreementInterestLabel ~= nil then self.agreementInterestLabel:setText(self.i18n:getText(isShortfall and "rff_interest_capitalised" or "rff_interest_paid")) end
    if self.agreementManagementNote ~= nil then
        if loan.rescueRefinanced == true then
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_rescue_source_history_note"), loan.rescueRefinancedByLoanId or 0, self:formatMoney(loan.rescueSettlementAmount or 0), loan.rescueRefinancedPeriod or 0), 62))
        elseif loan.rescueFinance == true then
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_rescue_origin_note"), loan.rescueSourceLoanId or 0, self:formatMoney(loan.rescueSettlementAmount or loan.originalAmount or 0), self:formatMoney(loan.rescuePreviousPayment or 0)), 62))
        elseif (loan.forbearanceMode or "") ~= "" and (loan.forbearanceRemainingPeriods or 0) > 0 then
            local typeText = self:getForbearanceTypeText(loan.forbearanceMode)
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_forbearance_active_note"), typeText, loan.forbearanceRemainingPeriods or 0, self:formatMoney(loan.forbearanceCapitalisedArrears or 0)), 62))
        elseif (loan.forbearanceCount or 0) > 0 and (loan.forbearanceLastType or "") ~= "" then
            local typeText = self:getForbearanceTypeText(loan.forbearanceLastType)
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_forbearance_history_note"), typeText, loan.forbearanceCount or 0, self:formatMoney(loan.forbearanceCapitalisedArrears or 0)), 62))
        elseif loan.refinanced == true then
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_refinanced_history_note"), loan.refinancedByLoanId or 0, loan.refinancedPeriod or 0), 62))
        elseif loan.refinance == true then
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText(loan.consolidation == true and "rff_consolidation_origin_note" or "rff_refinance_origin_note"),
                loan.refinanceSourceCount or 0, self:formatMoney(loan.refinanceSettlementAmount or loan.originalAmount or 0), self:formatMoney(loan.refinancePreviousDebtService or 0)), 62))
        elseif isShortfall then
            local sourceLabel = loan.sourceRecoveryType == "PROPERTY" and self.i18n:getText("rff_property_recovery_source") or self.i18n:getText("rff_asset_recovery_source")
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_recovery_liability_note_with_source"), sourceLabel, self:formatMoney(loan.capitalisedAdminCharges or 0)), 62))
        elseif isMortgage and loan.mortgageRecovered == true then
            local securityLabel = self.manager.propertyFinance ~= nil and self.manager.propertyFinance:getMortgageSecurityLabel(loan) or string.format("Land %d", loan.securityFarmlandId or 0)
            if (loan.mortgageRecoveredFixtureCount or 0) > 0 or (loan.mortgageForcedLivestockCount or 0) > 0 then
                self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_mortgage_recovery_history_note_with_fixtures"),
                    securityLabel, self:formatMoney(loan.mortgageRealisedValue or 0),
                    loan.mortgageRecoveredFixtureCount or 0, self:formatMoney(loan.mortgageRecoveredFixtureRealisedValue or 0),
                    self:formatMoney(loan.mortgageRecoveryCosts or 0), self:formatMoney(loan.mortgageRecoveryShortfall or 0),
                    self:formatMoney(loan.mortgageRecoverySurplus or 0), loan.mortgageForcedLivestockCount or 0,
                    self:formatMoney(loan.mortgageForcedLivestockProceeds or 0)), 62))
            else
                self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_mortgage_recovery_history_note"),
                    securityLabel, self:formatMoney(loan.mortgageRealisedValue or 0),
                    self:formatMoney(loan.mortgageRecoveryCosts or 0), self:formatMoney(loan.mortgageRecoveryShortfall or 0),
                    self:formatMoney(loan.mortgageRecoverySurplus or 0)), 62))
            end
        elseif isMortgage and (loan.arrearsBalance or 0) > 0.01 and self.manager.propertyFinance ~= nil then
            local assessment = self.manager.propertyFinance:getMortgageRecoveryAssessment(loan, true)
            if assessment ~= nil then
                local result = assessment.shortfall > 0.01
                    and string.format(self.i18n:getText("rff_mortgage_estimated_shortfall"), self:formatMoney(assessment.shortfall))
                    or string.format(self.i18n:getText("rff_mortgage_estimated_surplus"), self:formatMoney(assessment.surplus))
                local securityLabel = self.manager.propertyFinance:getMortgageSecurityLabel(loan)
                self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_mortgage_default_management_note"),
                    securityLabel, self:formatMoney(assessment.marketValue), result), 58))
            end
        elseif isMortgage and loan.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" and self.manager.propertyFinance ~= nil then
            self.agreementManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_holding_security_agreement_note"), self.manager.propertyFinance:getMortgageSecurityLabel(loan)), 62))
        else
            self.agreementManagementNote:setText(wrapText(self.i18n:getText("rff_management_note"), 62))
        end
    end

    local active = not loan.paidOff
    local hasArrears = (loan.arrearsBalance or 0) > 0.01
    if self.extraRepayButton ~= nil then self.extraRepayButton:setVisible(active and not isRevolving and not isOverdraft and outstanding > 0 and not hasArrears) end
    if self.agreementArrearsButton ~= nil then self.agreementArrearsButton:setVisible(active and hasArrears) end
    if self.settleButton ~= nil then self.settleButton:setVisible(active and (not isOverdraft or outstanding <= 0.01)) end
    if self.agreementDrawButton ~= nil then self.agreementDrawButton:setVisible(active and isRevolving and (loan.drawnAmount or 0) < (loan.creditLimit or 0)) end
    if self.agreementRepayButton ~= nil then self.agreementRepayButton:setVisible(active and isRevolving and outstanding > 0) end
    local mortgageDefault = isMortgage and active and (loan.currentDefault == true or loan.arrearsStage == "DEFAULT_NOTICE" or loan.arrearsStage == "FORMAL_DEMAND" or loan.arrearsStage == "POSSESSION_WARNING" or loan.arrearsStage == "RECOVERY")
    local showRestructure = mortgageDefault and math.max(0, loan.mortgageRestructureCount or 0) < 1
    if self.mortgageRestructureButton ~= nil then self.mortgageRestructureButton:setVisible(showRestructure) end
    if self.mortgageSurrenderButton ~= nil then self.mortgageSurrenderButton:setVisible(mortgageDefault) end
    local securityReleaseEligible = false
    if isMortgage and active and not mortgageDefault and not hasArrears and self.manager.propertyFinance ~= nil then
        securityReleaseEligible = #self.manager.propertyFinance:getMortgageSecurityFarmlandIds(loan) >= 2
    end
    if self.securityReleaseButton ~= nil then self.securityReleaseButton:setVisible(securityReleaseEligible) end
    local refinanceEligible = false
    local consolidationEligible = false
    if self.manager.refinanceService ~= nil and active and not mortgageDefault then
        refinanceEligible = self.manager.refinanceService:isEligibleLoan(loan) == true
        if refinanceEligible then
            consolidationEligible = #self.manager.refinanceService:getEligibleLoans(self:getCurrentFarmId()) >= 2
        end
    end
    if self.refinanceButton ~= nil then self.refinanceButton:setVisible(refinanceEligible) end
    if self.consolidateButton ~= nil then self.consolidateButton:setVisible(consolidationEligible) end
    local paymentHelpEligible = false
    local rescueEligible = false
    if self.manager.forbearanceService ~= nil and active and hasArrears and not isMortgage and not isOverdraft and not isShortfall then
        paymentHelpEligible = self.manager.forbearanceService:canRequestHelp(loan) == true
        rescueEligible = self.manager.forbearanceService:isRescueEligible(loan) == true
    end
    if self.paymentHelpButton ~= nil then self.paymentHelpButton:setVisible(paymentHelpEligible) end
    if self.rescueFinanceButton ~= nil then self.rescueFinanceButton:setVisible(rescueEligible) end
    if self.managementAmountOption ~= nil and self.managementAmountOption.setDisabled ~= nil then self.managementAmountOption:setDisabled(not active or isOverdraft) end

    if isShortfall then self:updateSchedulePreview(nil) else self:updateSchedulePreview(loan) end
end

function RFF_FinanceFrame:onClickExtraRepayment()
    local loan = self:getSelectedAgreement()
    if loan == nil then return end
    local requested = self:getSelectedManagementAmount()
    local amount = math.min(requested, self.manager.loanService:getLoanOutstanding(loan))
    if amount <= 0 then return end
    self.pendingAgreementAction = {kind="EXTRA", loan=loan, amount=amount}
    YesNoDialog.show(self.onAgreementActionConfirmed, self,
        string.format(self.i18n:getText("rff_confirm_extra_repayment"), self:formatMoney(amount), loan.id or 0),
        self.i18n:getText("rff_manage_agreement"))
end

function RFF_FinanceFrame:onClickPayAgreementArrears()
    local loan = self:getSelectedAgreement()
    if loan == nil or self.manager == nil or self.manager.loanService == nil then return end
    local amount = math.max(0, loan.arrearsBalance or 0)
    if amount <= 0.01 then return end
    self.pendingAgreementArrears = loan
    YesNoDialog.show(self.onAgreementArrearsConfirmed, self,
        string.format(self.i18n:getText("rff_confirm_pay_arrears"), self:formatMoney(amount)),
        self.i18n:getText("rff_pay_arrears"))
end

function RFF_FinanceFrame:onAgreementArrearsConfirmed(confirmed)
    local loan = self.pendingAgreementArrears
    self.pendingAgreementArrears = nil
    if not confirmed or loan == nil then return end
    local ok, reason, amount = self.manager.loanService:payArrears(loan)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_arrears_paid"), self:formatMoney(amount or 0)))
        self:updateContent()
        self:updateAgreementsContent(true)
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_insufficient_funds"))
    end
end


function RFF_FinanceFrame:getPaymentHelpFailureText(reason)
    if reason == "relationship" or reason == "history" then return self.i18n:getText("rff_forbearance_unavailable_relationship") end
    if reason == "used" then return self.i18n:getText("rff_forbearance_unavailable_used") end
    if reason == "recovery" then return self.i18n:getText("rff_forbearance_unavailable_recovery") end
    if reason == "product" then return self.i18n:getText("rff_forbearance_unavailable_product") end
    return self.i18n:getText("rff_forbearance_unavailable")
end

function RFF_FinanceFrame:onClickPaymentHelp()
    if self.manager == nil or self.manager.forbearanceService == nil then return end
    local loan = self:getSelectedAgreement()
    if loan == nil then return end
    local plan, reason = self.manager.forbearanceService:buildPlan(loan)
    if plan == nil then
        InfoDialog.show(self:getPaymentHelpFailureText(reason))
        return
    end
    self.pendingForbearancePlan = {loan=loan, plan=plan}
    local relationshipText = self.i18n:getText("rff_relationship_" .. string.lower(tostring(plan.relationshipCode or "NEW")))
    local typeText = self:getForbearanceTypeText(plan.type)
    local temporaryText
    if plan.type == RFF_ForbearanceService.TYPE_HOLIDAY then
        temporaryText = string.format(self.i18n:getText("rff_forbearance_holiday_terms"), plan.durationPeriods or 0)
    elseif plan.type == RFF_ForbearanceService.TYPE_INTEREST_ONLY then
        temporaryText = string.format(self.i18n:getText("rff_forbearance_interest_only_terms"), plan.durationPeriods or 0)
    else
        temporaryText = string.format(self.i18n:getText("rff_forbearance_restructure_terms"), plan.extensionMonths or 0)
    end
    local text = string.format(self.i18n:getText("rff_forbearance_confirm"), typeText, relationshipText, self:formatMoney(plan.capitalisedArrears or 0), temporaryText, plan.interestRate or 0, self:formatMoney(plan.monthlyPayment or 0))
    YesNoDialog.show(self.onPaymentHelpConfirmed, self, text, self.i18n:getText("rff_payment_help"))
end

function RFF_FinanceFrame:onPaymentHelpConfirmed(confirmed)
    local pending = self.pendingForbearancePlan
    self.pendingForbearancePlan = nil
    if not confirmed or pending == nil or self.manager == nil or self.manager.forbearanceService == nil then return end
    local ok, reason, plan = self.manager.forbearanceService:applyPlan(pending.loan, pending.plan, "GUI")
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_forbearance_complete"), self:getForbearanceTypeText(plan.type), self:formatMoney(plan.capitalisedArrears or 0), plan.interestRate or 0, self:formatMoney(pending.loan.monthlyPayment or 0)))
        self:updateContent()
        self:updateAgreementsContent(true)
    else
        InfoDialog.show(self:getPaymentHelpFailureText(reason))
    end
end

function RFF_FinanceFrame:getRescueFailureText(reason)
    if reason == "too_early" then return self.i18n:getText("rff_rescue_too_early") end
    if reason == "recovery" then return self.i18n:getText("rff_rescue_recovery_stage") end
    if reason == "no_offers" then return self.i18n:getText("rff_rescue_no_offers") end
    if reason == "funds" then return self.i18n:getText("rff_rescue_fee_funds") end
    if reason == "quote_expired" or reason == "changed" then return self.i18n:getText("rff_rescue_quote_changed") end
    return self.i18n:getText("rff_rescue_unavailable")
end

function RFF_FinanceFrame:onClickRescueFinance()
    if self.manager == nil or self.manager.forbearanceService == nil then return end
    local loan = self:getSelectedAgreement()
    if loan == nil then return end
    local quote, reason = self.manager.forbearanceService:buildRescueQuote(loan)
    if quote == nil then
        InfoDialog.show(self:getRescueFailureText(reason))
        return
    end
    self.pendingRescueQuote = quote
    local lenderName = quote.lenderNameKey ~= nil and self.i18n:getText(quote.lenderNameKey) or tostring(quote.lenderId)
    local oldLender = quote.previousLenderNameKey ~= nil and self.i18n:getText(quote.previousLenderNameKey) or tostring(quote.previousLenderId)
    local marketText = self.manager.lenderMarketService ~= nil and self.manager.lenderMarketService.APPETITE[quote.marketState] ~= nil and self.i18n:getText(self.manager.lenderMarketService.APPETITE[quote.marketState].key) or tostring(quote.marketState or "-")
    local fitText = self:getDealFitText(quote.dealFit or "STANDARD")
    local monthlyLine
    if (quote.monthlyDifference or 0) >= 0 then monthlyLine = string.format(self.i18n:getText("rff_rescue_monthly_reduction"), self:formatMoney(math.abs(quote.monthlyDifference or 0)))
    else monthlyLine = string.format(self.i18n:getText("rff_rescue_monthly_increase"), self:formatMoney(math.abs(quote.monthlyDifference or 0))) end
    local text = string.format(self.i18n:getText("rff_rescue_confirm"), oldLender, self:formatMoney(quote.settlement or 0), lenderName, marketText, fitText, quote.termMonths or 0, quote.interestRate or 0, self:formatMoney(quote.previousPayment or 0), self:formatMoney(quote.monthlyPayment or 0), monthlyLine, self:formatMoney(quote.arrangementFee or 0))
    YesNoDialog.show(self.onRescueFinanceConfirmed, self, text, self.i18n:getText("rff_rescue_finance"))
end

function RFF_FinanceFrame:onRescueFinanceConfirmed(confirmed)
    local quote = self.pendingRescueQuote
    self.pendingRescueQuote = nil
    if not confirmed or quote == nil or self.manager == nil or self.manager.forbearanceService == nil then return end
    local loan, reason = self.manager.forbearanceService:completeRescueQuote(quote)
    if loan ~= nil then
        InfoDialog.show(string.format(self.i18n:getText("rff_rescue_complete"), loan.id or 0, self:formatMoney(loan.originalAmount or 0), loan.interestRate or 0, self:formatMoney(loan.monthlyPayment or 0)))
        self:updateContent()
        self:updateAgreementsContent(true)
    else
        InfoDialog.show(self:getRescueFailureText(reason))
    end
end

function RFF_FinanceFrame:getRefinanceFailureText(reason)
    if reason == "arrears" or reason == "payment_conduct" then return self.i18n:getText("rff_refinance_unavailable_arrears") end
    if reason == "product" then return self.i18n:getText("rff_refinance_unavailable_product") end
    if reason == "not_enough_loans" then return self.i18n:getText("rff_consolidation_not_enough") end
    if reason == "funds" then return self.i18n:getText("rff_refinance_fee_funds") end
    if reason == "quote_expired" or reason == "changed" then return self.i18n:getText("rff_refinance_quote_changed") end
    if reason == "no_offers" or reason == "affordability" or reason == "affordability_after_pricing" then return self.i18n:getText("rff_refinance_no_offers") end
    return self.i18n:getText("rff_refinance_unavailable")
end

function RFF_FinanceFrame:showRefinanceQuote(quote)
    if quote == nil then return end
    self.pendingRefinanceQuote = quote
    local lenderName = quote.lenderNameKey ~= nil and self.i18n:getText(quote.lenderNameKey) or self.i18n:getText("rff_lender_primary_bank")
    local marketText = self.manager.lenderMarketService ~= nil and self.manager.lenderMarketService.APPETITE[quote.marketState] ~= nil
        and self.i18n:getText(self.manager.lenderMarketService.APPETITE[quote.marketState].key) or tostring(quote.marketState or "-")
    local relationshipText = self.i18n:getText("rff_relationship_" .. string.lower(tostring(quote.relationshipTier or "NEW")))
    local fitText = self:getDealFitText(quote.dealFit or "STANDARD")
    local monthlyChange
    if (quote.monthlyDifference or 0) >= 0 then
        monthlyChange = string.format(self.i18n:getText("rff_refinance_monthly_saving"), self:formatMoney(math.abs(quote.monthlyDifference or 0)))
    else
        monthlyChange = string.format(self.i18n:getText("rff_refinance_monthly_increase"), self:formatMoney(math.abs(quote.monthlyDifference or 0)))
    end
    local projectedChange
    if (quote.projectedInterestDifference or 0) >= 0 then
        projectedChange = string.format(self.i18n:getText("rff_refinance_projected_saving"), self:formatMoney(math.abs(quote.projectedInterestDifference or 0)))
    else
        projectedChange = string.format(self.i18n:getText("rff_refinance_projected_increase"), self:formatMoney(math.abs(quote.projectedInterestDifference or 0)))
    end
    local modeText = self.i18n:getText(quote.mode == RFF_RefinanceService.MODE_CONSOLIDATE and "rff_debt_consolidation" or "rff_refinance")
    local text = string.format(self.i18n:getText("rff_refinance_confirm"),
        modeText, quote.targetLoanCount or 0, self:formatMoney(quote.amount or 0), lenderName, marketText, relationshipText, fitText,
        quote.termMonths or 0, quote.interestRate or 0, self:formatMoney(quote.existingDebtService or 0),
        self:formatMoney(quote.monthlyPayment or 0), monthlyChange, self:formatMoney(quote.arrangementFee or 0), projectedChange)
    YesNoDialog.show(self.onRefinanceConfirmed, self, text, modeText)
end

function RFF_FinanceFrame:onClickRefinanceAgreement()
    if self.manager == nil or self.manager.refinanceService == nil then return end
    local loan = self:getSelectedAgreement()
    if loan == nil then return end
    local quote, reason = self.manager.refinanceService:getBestRefinanceQuote(self:getCurrentFarmId(), loan)
    if quote == nil then
        InfoDialog.show(self:getRefinanceFailureText(reason))
        return
    end
    self:showRefinanceQuote(quote)
end

function RFF_FinanceFrame:onClickConsolidateAgreements()
    if self.manager == nil or self.manager.refinanceService == nil then return end
    local quote, reason = self.manager.refinanceService:getBestConsolidationQuote(self:getCurrentFarmId())
    if quote == nil then
        InfoDialog.show(self:getRefinanceFailureText(reason))
        return
    end
    self:showRefinanceQuote(quote)
end

function RFF_FinanceFrame:onRefinanceConfirmed(confirmed)
    local quote = self.pendingRefinanceQuote
    self.pendingRefinanceQuote = nil
    if not confirmed or quote == nil or self.manager == nil or self.manager.refinanceService == nil then return end
    local loan, reason = self.manager.refinanceService:completeQuote(quote)
    if loan ~= nil then
        InfoDialog.show(string.format(self.i18n:getText("rff_refinance_complete"), loan.id or 0, self:formatMoney(loan.originalAmount or 0), loan.interestRate or 0, self:formatMoney(loan.monthlyPayment or 0)))
        self:updateContent()
        self:updateAgreementsContent(true)
    else
        InfoDialog.show(self:getRefinanceFailureText(reason))
    end
end

function RFF_FinanceFrame:onClickMortgageRestructure()
    local loan = self:getSelectedAgreement()
    if loan == nil or self.manager == nil or self.manager.propertyFinance == nil then return end
    local eligible, reason, terms = self.manager.propertyFinance:canRestructureMortgage(loan)
    if not eligible or terms == nil then
        if reason == "equity" then
            InfoDialog.show(self.i18n:getText("rff_mortgage_restructure_equity_failed"))
        elseif reason == "already_restructured" then
            InfoDialog.show(self.i18n:getText("rff_mortgage_restructure_already_used"))
        else
            InfoDialog.show(self.i18n:getText("rff_mortgage_restructure_unavailable"))
        end
        return
    end
    self.pendingMortgageRestructure = loan
    local text = string.format(self.i18n:getText("rff_mortgage_restructure_confirm"),
        self:formatMoney(terms.capitalisedArrears), terms.extensionMonths,
        terms.interestRate, self:formatMoney(terms.monthlyPayment),
        string.format("%.1f%%", (terms.ltv or 0) * 100))
    YesNoDialog.show(self.onMortgageRestructureConfirmed, self, text, self.i18n:getText("rff_mortgage_restructure"))
end

function RFF_FinanceFrame:onMortgageRestructureConfirmed(confirmed)
    local loan = self.pendingMortgageRestructure
    self.pendingMortgageRestructure = nil
    if not confirmed or loan == nil then return end
    local ok, reason, terms = self.manager.propertyFinance:restructureMortgage(loan)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_mortgage_restructure_complete"),
            self:formatMoney(terms.principal), terms.interestRate, self:formatMoney(terms.monthlyPayment), terms.remainingMonths))
        self:updateContent()
        self:updateAgreementsContent(true)
    elseif reason == "equity" then
        InfoDialog.show(self.i18n:getText("rff_mortgage_restructure_equity_failed"))
    else
        InfoDialog.show(self.i18n:getText("rff_mortgage_restructure_unavailable"))
    end
end

function RFF_FinanceFrame:onClickSecurityRelease()
    local loan = self:getSelectedAgreement()
    if loan == nil or RFF_SecurityReleaseDialog == nil or not RFF_SecurityReleaseDialog.show(self, loan) then
        InfoDialog.show(self.i18n:getText("rff_security_release_unavailable"))
    end
end

function RFF_FinanceFrame:onClickMortgageVoluntarySale()
    local loan = self:getSelectedAgreement()
    if loan == nil or self.manager == nil or self.manager.propertyFinance == nil then return end
    local assessment = self.manager.propertyFinance:getMortgageRecoveryAssessment(loan, true)
    if assessment == nil then return end
    if (assessment.animalCount or 0) > 0 then
        InfoDialog.show(string.format(self.i18n:getText("rff_mortgage_voluntary_sale_livestock_present"), assessment.animalCount or 0))
        return
    end
    self.pendingMortgageRecovery = loan
    local result = assessment.shortfall > 0.01
        and string.format(self.i18n:getText("rff_mortgage_sale_shortfall_line"), self:formatMoney(assessment.shortfall))
        or string.format(self.i18n:getText("rff_mortgage_sale_surplus_line"), self:formatMoney(assessment.surplus))
    local securityLabel = self.manager.propertyFinance:getMortgageSecurityLabel(loan)
    local text = string.format(self.i18n:getText("rff_mortgage_voluntary_sale_confirm"),
        securityLabel,
        self:formatMoney(assessment.landMarketValue or assessment.marketValue),
        assessment.placeableCount or 0,
        self:formatMoney(assessment.fixtureMarketValue or 0),
        self:formatMoney(assessment.realisedValue),
        self:formatMoney(assessment.recoveryCosts),
        self:formatMoney(assessment.debt),
        result)
    YesNoDialog.show(self.onMortgageVoluntarySaleConfirmed, self, text, self.i18n:getText("rff_mortgage_voluntary_sale"))
end

function RFF_FinanceFrame:onMortgageVoluntarySaleConfirmed(confirmed)
    local loan = self.pendingMortgageRecovery
    self.pendingMortgageRecovery = nil
    if not confirmed or loan == nil then return end
    local ok, reason, assessment = self.manager.propertyFinance:recoverMortgageProperty(loan, true)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_mortgage_recovery_complete"),
            self:formatMoney(assessment.realisedValue), self:formatMoney(assessment.shortfall), self:formatMoney(assessment.surplus)))
        self:updateContent()
        self:updateAgreementsContent(true)
    elseif reason == "security_not_owned" or reason == "security_missing" then
        InfoDialog.show(self.i18n:getText("rff_mortgage_security_unavailable"))
    elseif reason == "livestock_present" then
        InfoDialog.show(string.format(self.i18n:getText("rff_mortgage_voluntary_sale_livestock_present"), assessment ~= nil and (assessment.animalCount or 0) or 0))
    else
        InfoDialog.show(self.i18n:getText("rff_mortgage_recovery_failed"))
    end
end

function RFF_FinanceFrame:onClickAgreementDraw()
    local loan = self:getSelectedAgreement()
    if loan == nil then return end
    local available = math.max(0, (loan.creditLimit or 0) - (loan.drawnAmount or 0))
    local amount = math.min(self:getSelectedManagementAmount(), available)
    if amount <= 0 then InfoDialog.show(self.i18n:getText("rff_revolving_no_available")); return end
    local ok = self.manager.loanService:drawRevolving(loan, amount)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_revolving_drawn"), self:formatMoney(amount)))
        self:updateContent()
        self:updateAgreementsContent(true)
    elseif self.manager.loanService:getPaymentConduct(loan.farmId) ~= nil and (loan.arrearsBalance or 0) > 0.01 then
        InfoDialog.show(self.i18n:getText("rff_clear_arrears_first"))
    end
end

function RFF_FinanceFrame:onClickAgreementRepay()
    local loan = self:getSelectedAgreement()
    if loan == nil then return end
    local amount = math.min(self:getSelectedManagementAmount(), self.manager.loanService:getLoanOutstanding(loan))
    local ok, reason = self.manager.loanService:repayRevolving(loan, amount)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_revolving_repaid"), self:formatMoney(amount)))
        self:updateContent()
        self:updateAgreementsContent(true)
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_insufficient_funds"))
    elseif reason == "arrears" then
        InfoDialog.show(self.i18n:getText("rff_clear_arrears_first"))
    elseif reason == "overdraft_in_use" then
        InfoDialog.show(self.i18n:getText("rff_overdraft_close_in_use"))
    end
end

function RFF_FinanceFrame:onClickSettleAgreement()
    local loan = self:getSelectedAgreement()
    if loan == nil or loan.paidOff then return end
    local amount = self.manager.loanService:getLoanOutstanding(loan)
    self.pendingAgreementAction = {kind="SETTLE", loan=loan, amount=amount}
    YesNoDialog.show(self.onAgreementActionConfirmed, self,
        string.format(self.i18n:getText("rff_confirm_settlement"), loan.id or 0, self:formatMoney(amount)),
        self.i18n:getText("rff_manage_agreement"))
end

function RFF_FinanceFrame:onAgreementActionConfirmed(confirmed)
    local action = self.pendingAgreementAction
    self.pendingAgreementAction = nil
    self.pendingRefinanceQuote = nil
    if not confirmed or action == nil or action.loan == nil then return end

    local ok, reason, amount
    if action.kind == "EXTRA" then
        ok, reason, amount = self.manager.loanService:makeExtraRepayment(action.loan, action.amount)
    else
        ok, reason, amount = self.manager.loanService:settleLoan(action.loan)
    end

    if ok then
        local key = action.kind == "EXTRA" and "rff_extra_repayment_made" or "rff_agreement_settled"
        InfoDialog.show(string.format(self.i18n:getText(key), self:formatMoney(amount or action.amount or 0)))
        self:updateContent()
        self:updateAgreementsContent(true)
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_insufficient_funds"))
    elseif reason == "arrears" then
        InfoDialog.show(self.i18n:getText("rff_clear_arrears_first"))
    end
end

function RFF_FinanceFrame:onApplicationOptionChanged()
    self:updateBankingContent()
end

function RFF_FinanceFrame:onClickEnterExactAmount()
    local current = self:getSelectedApplication()
    local defaultAmount = current ~= nil and math.floor(current.amount or 100000) or 100000
    if TextInputDialog == nil or TextInputDialog.show == nil then
        InfoDialog.show(self.i18n:getText("rff_exact_amount_unavailable"))
        return
    end
    TextInputDialog.show(
        self.onExactLoanAmountEntered, self, tostring(defaultAmount),
        self.i18n:getText("rff_exact_amount_prompt"), nil, 10, self.i18n:getText("button_ok"))
end

function RFF_FinanceFrame:onExactLoanAmountEntered(text, confirmed)
    if not confirmed then return end
    local cleaned = tostring(text or ""):gsub("[^%d]", "")
    local amount = tonumber(cleaned)
    if amount == nil or amount < self.MIN_APPLICATION_AMOUNT then
        InfoDialog.show(string.format(self.i18n:getText("rff_exact_amount_invalid"), self:formatMoney(self.MIN_APPLICATION_AMOUNT)))
        return
    end
    amount = math.min(self.MAX_APPLICATION_AMOUNT, math.floor(amount + 0.5))
    self:addExactApplicationAmount(amount)
    self:updateBankingContent()
end

function RFF_FinanceFrame:getEvaluation()
    local farmId = self:getCurrentFarmId()
    if farmId <= 0 or self.manager == nil or self.manager.repository == nil or self.manager.loanService == nil then
        return nil, nil, nil, nil
    end

    local application = self:getSelectedApplication()
    local valuation = RFF_FarmValuation:calculate(farmId, self.manager.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.manager.repository)
    local evaluation = self.manager.loanService:evaluateApplication(
        farmId, application.amount, application.months, application.product, valuation, credit)

    return evaluation, application, valuation, credit
end

function RFF_FinanceFrame:getDecisionText(evaluation)
    if evaluation == nil then
        return self.i18n:getText("rff_decision_unavailable")
    end
    if evaluation.approved then
        return self.i18n:getText("rff_decision_approved")
    end
    if evaluation.reason == "startup_ltv" or evaluation.reason == "no_collateral" then
        return self.i18n:getText("rff_decision_security")
    end
    if evaluation.reason == "payment_conduct" then return self.i18n:getText("rff_decision_conduct") end
    if evaluation.reason == "overdraft_exists" then return self.i18n:getText("rff_decision_overdraft_exists") end
    return self.i18n:getText("rff_decision_declined")
end

function RFF_FinanceFrame:updateBankingContent()
    if g_currentMission == nil or self.manager == nil or self.manager.repository == nil or self.manager.loanService == nil then
        return
    end

    local farmId = self:getCurrentFarmId()
    if farmId <= 0 then return end

    local repository = self.manager.repository
    local loanService = self.manager.loanService
    local bankingService = self.manager.bankingService
    local evaluation, application = self:getEvaluation()
    self.lastEvaluation = evaluation

    local position = bankingService ~= nil and bankingService:getAccountPosition(farmId) or {balance=RFF_FarmValuation:getBankBalance(farmId), limit=0, used=0, available=0, overLimit=0, suspended=false}
    if self.bankAccountBalanceValue ~= nil then self.bankAccountBalanceValue:setText(self:formatMoney(position.balance or 0)) end
    if self.bankCreditInterestValue ~= nil then self.bankCreditInterestValue:setText(string.format("%.2f%%", bankingService ~= nil and bankingService:getCreditInterestRate() or 0)) end
    if self.bankLastInterestValue ~= nil then self.bankLastInterestValue:setText(self:formatMoney(bankingService ~= nil and bankingService:getLastInterestCredit(farmId) or 0)) end
    if self.bankBaseRateValue ~= nil then self.bankBaseRateValue:setText(string.format("%.2f%%", loanService:getBaseRate())) end
    if self.bankUnauthorisedNote ~= nil then
        self.bankUnauthorisedNote:setText(string.format(self.i18n:getText("rff_bank_unauthorised_help"),self:formatMoney(10)))
    end
    if self.overdraftLimitValue ~= nil then
        local limitText = position.facility ~= nil and self:formatMoney(position.limit or 0) or self.i18n:getText("rff_none")
        if position.suspended then limitText = limitText .. " - " .. self.i18n:getText("rff_overdraft_suspended_short") end
        self.overdraftLimitValue:setText(limitText)
    end
    if self.overdraftUsedValue ~= nil then self.overdraftUsedValue:setText(self:formatMoney(position.used or 0)) end
    if self.overdraftAvailableValue ~= nil then
        local availableText = self:formatMoney(position.available or 0)
        if (position.overLimit or 0) > 0.01 then
            availableText = string.format(self.i18n:getText("rff_overdraft_over_limit_value"), self:formatMoney(position.overLimit or 0))
        end
        self.overdraftAvailableValue:setText(availableText)
    end

    if self.bankOutstandingValue ~= nil then self.bankOutstandingValue:setText(self:formatMoney(loanService:getOutstandingBalance(farmId) + (repository.getBankAccountLiability ~= nil and repository:getBankAccountLiability(farmId) or 0))) end
    if self.bankDebtServiceValue ~= nil then self.bankDebtServiceValue:setText(self:formatMoney(loanService:getMonthlyDebtService(farmId))) end
    if self.bankFacilitiesValue ~= nil then self.bankFacilitiesValue:setText(tostring(loanService:getActiveFacilityCount(farmId))) end

    if evaluation ~= nil then
        if self.offerRateValue ~= nil then
            self.offerRateValue:setText(evaluation.interestRate > 0 and string.format("%.2f%%", evaluation.interestRate) or "-")
        end
        if self.offerPaymentValue ~= nil then
            local paymentText = self:formatMoney(evaluation.monthlyPayment or 0)
            if application ~= nil and (application.product == RFF_LoanService.TYPE_REVOLVING or application.product == RFF_LoanService.TYPE_OVERDRAFT) then
                paymentText = paymentText .. "*"
            end
            self.offerPaymentValue:setText(paymentText)
        end
        if self.offerLtvValue ~= nil then self.offerLtvValue:setText(self:formatPercent(evaluation.ltv)) end
        if self.offerDscrValue ~= nil then self.offerDscrValue:setText(self:formatDscr(evaluation.dscr)) end
        if self.offerGradeValue ~= nil then self.offerGradeValue:setText(evaluation.grade or "-") end
        if self.offerDecisionValue ~= nil then self.offerDecisionValue:setText(self:getDecisionText(evaluation)) end
    end

    local isRevolvingApplication = application ~= nil and application.product == RFF_LoanService.TYPE_REVOLVING
    local isOverdraftApplication = application ~= nil and application.product == RFF_LoanService.TYPE_OVERDRAFT
    if self.termOption ~= nil and self.termOption.setDisabled ~= nil then
        self.termOption:setDisabled(isRevolvingApplication or isOverdraftApplication)
    end
    if isOverdraftApplication and self.termOption ~= nil then setOptionState(self.termOption, 1) end
    if self.termHintValue ~= nil then
        if isRevolvingApplication then
            self.termHintValue:setText(self.i18n:getText("rff_revolving_open_ended"))
        elseif isOverdraftApplication then
            self.termHintValue:setText(self.i18n:getText("rff_overdraft_review_note"))
        else
            self.termHintValue:setText("")
        end
    end

    local latest = loanService:getMostRecentActiveLoan(farmId)
    if latest ~= nil then
        if self.latestTypeValue ~= nil then
            local latestKey = latest.legacyImported == true and "rff_product_legacy" or (self.PRODUCT_TEXT_KEYS[latest.type] or "rff_product_term")
            self.latestTypeValue:setText(self.i18n:getText(latestKey))
        end
        if self.latestBalanceValue ~= nil then self.latestBalanceValue:setText(self:formatMoney(loanService:getLoanOutstanding(latest))) end
    else
        if self.latestTypeValue ~= nil then self.latestTypeValue:setText(self.i18n:getText("rff_none")) end
        if self.latestBalanceValue ~= nil then self.latestBalanceValue:setText(self:formatMoney(0)) end
    end

    local revolving = loanService:getMostRecentRevolving(farmId)
    local hasRevolving = revolving ~= nil
    if self.revolvingStatusValue ~= nil then
        if hasRevolving then
            self.revolvingStatusValue:setText(string.format("%s / %s", self:formatMoney(revolving.drawnAmount or 0), self:formatMoney(revolving.creditLimit or 0)))
        else
            self.revolvingStatusValue:setText(self.i18n:getText("rff_none"))
        end
    end
    if self.drawButton ~= nil then self.drawButton:setVisible(hasRevolving) end
    if self.repayButton ~= nil then self.repayButton:setVisible(hasRevolving) end
end

function RFF_FinanceFrame:onClickApply()
    local evaluation, application, valuation, credit = self:getEvaluation()
    if evaluation == nil or application == nil or valuation == nil or credit == nil or self.manager.applicationService == nil then return end
    local farmId = self:getCurrentFarmId()

    local route, minHours, maxHours = self.manager.applicationService:estimateRoute(application.amount, application.product, valuation, credit, evaluation, farmId)
    self.pendingSubmission = {application = application, valuation = valuation, credit = credit}
    local routeText = self.i18n:getText(self.manager.applicationService:getRouteLabelKey(route))
    local text = string.format(self.i18n:getText("rff_application_submit_confirm"),
        self.i18n:getText(self.PRODUCT_TEXT_KEYS[application.product]),
        self:formatMoney(application.amount),
        routeText,
        self:formatDurationRange(minHours, maxHours))
    YesNoDialog.show(self.onApplicationSubmitConfirmed, self, text, self.i18n:getText("rff_banking_application"))
end

function RFF_FinanceFrame:onApplicationSubmitConfirmed(confirmed)
    local pending = self.pendingSubmission
    self.pendingSubmission = nil
    if not confirmed or pending == nil then return end

    local application = pending.application
    local farmId = self:getCurrentFarmId()
    local submitted, reason = self.manager.applicationService:submitApplication(
        farmId, application.amount, application.months, application.product, application.purpose, pending.valuation, pending.credit)
    if submitted == nil then
        if reason == "existing_open_application" then
            InfoDialog.show(self.i18n:getText("rff_application_existing_open"))
        else
            InfoDialog.show(self.i18n:getText("rff_application_submit_failed"))
        end
        return
    end

    local setupHint=self.manager.applicationService:canInstantDecision(submitted,self:getCurrentFarmId())
        and ("\n\n"..self.i18n:getText("rff_startup_credit_hint")) or ""
    InfoDialog.show(string.format(self.i18n:getText("rff_application_submitted_message"), submitted.id or 0, self:formatDurationRange(submitted.expectedMinHours or 0, submitted.expectedMaxHours or 0))..setupHint)
    self:updateContent()
end

function RFF_FinanceFrame:onClickDraw()
    local farmId = self:getCurrentFarmId()
    local loan = self.manager.loanService:getMostRecentRevolving(farmId)
    if loan == nil then return end
    local available = math.max(0, (loan.creditLimit or 0) - (loan.drawnAmount or 0))
    local amount = math.min(10000, available)
    if amount <= 0 then
        InfoDialog.show(self.i18n:getText("rff_revolving_no_available"))
        return
    end
    local ok = self.manager.loanService:drawRevolving(loan, amount)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_revolving_drawn"), self:formatMoney(amount)))
        self:updateContent()
    end
end

function RFF_FinanceFrame:onClickRepay()
    local farmId = self:getCurrentFarmId()
    local loan = self.manager.loanService:getMostRecentRevolving(farmId)
    if loan == nil then return end
    local amount = math.min(10000, loan.drawnAmount or 0)
    if amount <= 0 then
        InfoDialog.show(self.i18n:getText("rff_revolving_nothing_drawn"))
        return
    end
    local ok, reason = self.manager.loanService:repayRevolving(loan, amount)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_revolving_repaid"), self:formatMoney(amount)))
        self:updateContent()
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_insufficient_funds"))
    end
end


function RFF_FinanceFrame:rebuildBrokerCaseSelector(preserveCaseId)
    if self.brokerCaseOption == nil or self.manager == nil or self.manager.brokerService == nil then return end
    local farmId = self:getCurrentFarmId()
    self.brokerCases = self.manager.brokerService:getCasesByFarm(farmId)
    table.sort(self.brokerCases, function(a, b) return (a.id or 0) > (b.id or 0) end)
    local texts = {}
    local selected = 1
    for index, case in ipairs(self.brokerCases) do
        local status = self.i18n:getText(self.manager.brokerService:getStatusTextKey(case.status))
        local product = self.i18n:getText(self.PRODUCT_TEXT_KEYS[case.product] or "rff_product_term")
        table.insert(texts, string.format("#%d  %s  -  %s", case.id or index, product, status))
        if preserveCaseId ~= nil and case.id == preserveCaseId then selected = index end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_none")} end
    if self.brokerCaseOption.setTexts ~= nil then self.brokerCaseOption:setTexts(texts) else self.brokerCaseOption.texts = texts end
    setOptionState(self.brokerCaseOption, selected)
end

function RFF_FinanceFrame:getSelectedBrokerCase()
    if self.brokerCases == nil or #self.brokerCases == 0 then return nil end
    local state = self.brokerCaseOption ~= nil and (self.brokerCaseOption.state or 1) or 1
    return self.brokerCases[math.max(1, math.min(#self.brokerCases, state))]
end

function RFF_FinanceFrame:rebuildBrokerSourceSelector()
    if self.brokerSourceOption == nil or self.manager == nil or self.manager.repository == nil or self.manager.brokerService == nil then return end
    local farmId = self:getCurrentFarmId()
    local used = {}
    for _, case in ipairs(self.manager.brokerService:getCasesByFarm(farmId)) do used[case.sourceApplicationId or 0] = true end
    self.brokerSourceApplications = {}
    local texts = {}
    for _, app in ipairs(self.manager.repository:getApplicationsByFarm(farmId) or {}) do
        if self.manager.brokerService:canBrokerApplication(app) and not used[app.id or 0] then
            table.insert(self.brokerSourceApplications, app)
            local product = self.i18n:getText(self.PRODUCT_TEXT_KEYS[app.product] or "rff_product_term")
            table.insert(texts, string.format("#%d  %s  -  %s", app.id or 0, product, self:formatMoney(app.requestedAmount or 0)))
        end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_broker_no_eligible_application")} end
    if self.brokerSourceOption.setTexts ~= nil then self.brokerSourceOption:setTexts(texts) else self.brokerSourceOption.texts = texts end
    setOptionState(self.brokerSourceOption, 1)
end

function RFF_FinanceFrame:getSelectedBrokerSourceApplication()
    if self.brokerSourceApplications == nil or #self.brokerSourceApplications == 0 then return nil end
    local state = self.brokerSourceOption ~= nil and (self.brokerSourceOption.state or 1) or 1
    return self.brokerSourceApplications[math.max(1, math.min(#self.brokerSourceApplications, state))]
end

function RFF_FinanceFrame:rebuildBrokerOfferSelector(case, preserveIndex)
    if self.brokerOfferOption == nil then return end
    self.brokerOffers = case ~= nil and case.offers or {}
    local texts = {}
    for index, offer in ipairs(self.brokerOffers or {}) do
        local lender = self.manager.brokerService:getLenderById(offer.lenderId)
        local lenderName = lender ~= nil and self.i18n:getText(lender.nameKey) or tostring(offer.lenderId)
        local fitText = self:getDealFitText(offer.dealFit or "STANDARD")
        table.insert(texts, string.format("%d. %s - %s - %s", index, lenderName, self:formatMoney(offer.amount or 0), fitText))
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_broker_no_offers_yet")} end
    if self.brokerOfferOption.setTexts ~= nil then self.brokerOfferOption:setTexts(texts) else self.brokerOfferOption.texts = texts end
    local selected = #self.brokerOffers > 0 and math.max(1, math.min(#self.brokerOffers, preserveIndex or 1)) or 1
    setOptionState(self.brokerOfferOption, selected)
end

function RFF_FinanceFrame:getSelectedBrokerOffer()
    if self.brokerOffers == nil or #self.brokerOffers == 0 then return nil, 0 end
    local state = self.brokerOfferOption ~= nil and (self.brokerOfferOption.state or 1) or 1
    local index = math.max(1, math.min(#self.brokerOffers, state))
    return self.brokerOffers[index], index
end

function RFF_FinanceFrame:onBrokerCaseChanged()
    self:updateBrokerContent(false)
    self:updateRelationshipsContent()
end

function RFF_FinanceFrame:onBrokerSourceChanged()
    self:updateBrokerContent(false)
end

function RFF_FinanceFrame:onBrokerOfferChanged()
    self:updateBrokerContent(false)
end

function RFF_FinanceFrame:updateBrokerContent(rebuild)
    if self.manager == nil or self.manager.brokerService == nil or self.manager.repository == nil then return end
    local service = self.manager.brokerService
    local farmId = self:getCurrentFarmId()
    local current = self:getSelectedBrokerCase()
    local preserveId = current ~= nil and current.id or nil
    if rebuild then
        self:rebuildBrokerCaseSelector(preserveId)
        self:rebuildBrokerSourceSelector()
    end
    local case = self:getSelectedBrokerCase()
    local offerState = self.brokerOfferOption ~= nil and (self.brokerOfferOption.state or 1) or 1
    self:rebuildBrokerOfferSelector(case, offerState)

    local relationship = service:getBrokerRelationship(farmId, false) or {casesInstructed=0, acceptedDeals=0, successfulIntroductions=0, feesPaid=0, relationshipPoints=0}
    local _, tierKey = service:getRelationshipTier(relationship.relationshipPoints or 0)
    if self.brokerRelationshipValue ~= nil then self.brokerRelationshipValue:setText(self.i18n:getText(tierKey)) end
    if self.brokerCasesValue ~= nil then self.brokerCasesValue:setText(tostring(relationship.casesInstructed or 0)) end
    if self.brokerDealsValue ~= nil then self.brokerDealsValue:setText(tostring(relationship.acceptedDeals or 0)) end
    if self.brokerFeesPaidValue ~= nil then self.brokerFeesPaidValue:setText(self:formatMoney(relationship.feesPaid or 0)) end

    local activeCase = service:getActiveCase(farmId)
    local source = self:getSelectedBrokerSourceApplication()
    if self.instructBrokerButton ~= nil then self.instructBrokerButton:setVisible(source ~= nil and activeCase == nil) end

    if case ~= nil then
        if self.brokerCaseStatusValue ~= nil then self.brokerCaseStatusValue:setText(self.i18n:getText(service:getStatusTextKey(case.status))) end
        if self.brokerCaseSourceValue ~= nil then self.brokerCaseSourceValue:setText(string.format("#%d", case.sourceApplicationId or 0)) end
        if self.brokerCaseRequestedValue ~= nil then self.brokerCaseRequestedValue:setText(self:formatMoney(case.requestedAmount or 0)) end
        if self.brokerCaseProductValue ~= nil then self.brokerCaseProductValue:setText(self.i18n:getText(self.PRODUCT_TEXT_KEYS[case.product] or "rff_product_term")) end
        if self.brokerCaseProgressValue ~= nil then
            if service:isPending(case) then
                self.brokerCaseProgressValue:setText(string.format(self.i18n:getText("rff_approx_time_remaining"), self:formatDurationHours(math.max(0, (case.offersReadyHour or 0) - service:getCurrentHourStamp()))))
            elseif case.status == service.STATUS_OFFERS_READY then
                self.brokerCaseProgressValue:setText(string.format(self.i18n:getText("rff_broker_offers_valid_for"), self:formatDurationHours(math.max(0, (case.offerExpiryHour or 0)-service:getCurrentHourStamp()))))
            else
                self.brokerCaseProgressValue:setText("-")
            end
        end
    else
        for _, name in ipairs({"brokerCaseStatusValue","brokerCaseSourceValue","brokerCaseRequestedValue","brokerCaseProductValue","brokerCaseProgressValue"}) do
            if self[name] ~= nil then self[name]:setText("-") end
        end
    end

    if self.withdrawBrokerButton ~= nil then self.withdrawBrokerButton:setVisible(case ~= nil and service:isOpen(case)) end

    local offer, offerIndex = self:getSelectedBrokerOffer()
    if offer ~= nil then
        local lender = service:getLenderById(offer.lenderId)
        local lenderName = lender ~= nil and self.i18n:getText(lender.nameKey) or tostring(offer.lenderId)
        local lenderStyle = lender ~= nil and self.i18n:getText(lender.styleKey) or "-"
        local lenderRel = service:getLenderRelationship(farmId, offer.lenderId, false) or {acceptedDeals=0, totalVolume=0, relationshipPoints=0}
        local _, lenderTierKey = service:getRelationshipTier(lenderRel.relationshipPoints or 0)
        if self.brokerOfferLenderValue ~= nil then self.brokerOfferLenderValue:setText(lenderName) end
        if self.brokerOfferStyleValue ~= nil then self.brokerOfferStyleValue:setText(lenderStyle) end
        if self.brokerOfferRelationshipValue ~= nil then self.brokerOfferRelationshipValue:setText(self.i18n:getText(lenderTierKey)) end
        if self.brokerOfferAmountValue ~= nil then self.brokerOfferAmountValue:setText(self:formatMoney(offer.amount or 0)) end
        if self.brokerOfferTermValue ~= nil then self.brokerOfferTermValue:setText(self:formatTerm(offer.months or 0)) end
        if self.brokerOfferRateValue ~= nil then self.brokerOfferRateValue:setText(string.format("%.2f%%", offer.interestRate or 0)) end
        if self.brokerOfferPaymentValue ~= nil then self.brokerOfferPaymentValue:setText(self:formatMoney(offer.monthlyPayment or 0)) end
        if self.brokerOfferArrangementFeeValue ~= nil then self.brokerOfferArrangementFeeValue:setText(self:formatMoney(offer.arrangementFee or 0)) end
        if self.brokerOfferBrokerFeeValue ~= nil then self.brokerOfferBrokerFeeValue:setText(self:formatMoney(offer.brokerFee or 0)) end
        if self.brokerOfferDepositValue ~= nil then self.brokerOfferDepositValue:setText(case ~= nil and case.product == RFF_LoanService.TYPE_MORTGAGE and self:formatMoney(offer.deposit or 0) or "-") end
        if self.brokerOfferValuationValue ~= nil then self.brokerOfferValuationValue:setText(case ~= nil and case.product == RFF_LoanService.TYPE_MORTGAGE and self:formatMoney(offer.lenderValuation or 0) or "-") end
        if self.acceptBrokerOfferButton ~= nil then self.acceptBrokerOfferButton:setVisible(case ~= nil and case.status == service.STATUS_OFFERS_READY) end
    else
        for _, name in ipairs({"brokerOfferLenderValue","brokerOfferStyleValue","brokerOfferRelationshipValue","brokerOfferAmountValue","brokerOfferTermValue","brokerOfferRateValue","brokerOfferPaymentValue","brokerOfferArrangementFeeValue","brokerOfferBrokerFeeValue","brokerOfferDepositValue","brokerOfferValuationValue"}) do
            if self[name] ~= nil then self[name]:setText("-") end
        end
        if self.acceptBrokerOfferButton ~= nil then self.acceptBrokerOfferButton:setVisible(false) end
    end
end

function RFF_FinanceFrame:onClickInstructBroker()
    local app = self:getSelectedBrokerSourceApplication()
    if app == nil or self.manager == nil or self.manager.brokerService == nil then return end
    local minHours, maxHours = self.manager.brokerService:estimateTiming(app, self:getCurrentFarmId())
    self.pendingBrokerSource = app
    local text = string.format(self.i18n:getText("rff_broker_instruct_confirm"), app.id or 0, self:formatMoney(app.requestedAmount or 0), self:formatDurationRange(minHours, maxHours))
    YesNoDialog.show(self.onBrokerInstructConfirmed, self, text, self.i18n:getText("rff_broker_title"))
end

function RFF_FinanceFrame:onBrokerInstructConfirmed(confirmed)
    local app = self.pendingBrokerSource
    self.pendingBrokerSource = nil
    if not confirmed or app == nil then return end
    local case, reason = self.manager.brokerService:instructBroker(self:getCurrentFarmId(), app)
    if case == nil then
        InfoDialog.show(reason == "existing_case" and self.i18n:getText("rff_broker_existing_case") or self.i18n:getText("rff_broker_instruct_failed"))
        return
    end
    InfoDialog.show(string.format(self.i18n:getText("rff_broker_instructed_message"), case.id or 0, self:formatDurationRange(case.expectedMinHours or 0, case.expectedMaxHours or 0)))
    self:updateBrokerContent(true)
end

function RFF_FinanceFrame:onClickAcceptBrokerOffer()
    local case = self:getSelectedBrokerCase()
    local offer, offerIndex = self:getSelectedBrokerOffer()
    if case == nil or offer == nil then return end
    local lender = self.manager.brokerService:getLenderById(offer.lenderId)
    local lenderName = lender ~= nil and self.i18n:getText(lender.nameKey) or tostring(offer.lenderId)
    self.pendingBrokerAcceptance = {case=case, offerIndex=offerIndex}
    local text = string.format(self.i18n:getText("rff_broker_accept_confirm"), lenderName, self:formatMoney(offer.amount or 0), offer.interestRate or 0, self:formatMoney(offer.monthlyPayment or 0), self:formatMoney((offer.arrangementFee or 0)+(offer.brokerFee or 0)), case.product == RFF_LoanService.TYPE_MORTGAGE and self:formatMoney(offer.deposit or 0) or self.i18n:getText("rff_not_applicable"))
    YesNoDialog.show(self.onBrokerAcceptConfirmed, self, text, self.i18n:getText("rff_broker_formal_offer"))
end

function RFF_FinanceFrame:onBrokerAcceptConfirmed(confirmed)
    local pending = self.pendingBrokerAcceptance
    self.pendingBrokerAcceptance = nil
    if not confirmed or pending == nil then return end
    local loan, reason = self.manager.brokerService:acceptOffer(pending.case, pending.offerIndex)
    if loan == nil then
        if reason == "funds" then InfoDialog.show(self.i18n:getText("rff_broker_insufficient_cash"))
        elseif reason == "expired" then InfoDialog.show(self.i18n:getText("rff_offer_expired_message"))
        elseif reason == "payment_conduct" then InfoDialog.show(self.i18n:getText("rff_clear_arrears_first"))
        else InfoDialog.show(self.i18n:getText("rff_broker_accept_failed")) end
        return
    end
    local lenderName = loan.lenderNameKey ~= nil and self.i18n:getText(loan.lenderNameKey) or self.i18n:getText("rff_lender_primary_bank")
    InfoDialog.show(string.format(self.i18n:getText("rff_broker_offer_accepted"), lenderName, self:formatMoney(loan.originalAmount or loan.creditLimit or 0)))
    self:updateContent()
    self:updateBrokerContent(true)
end

function RFF_FinanceFrame:onClickWithdrawBrokerCase()
    local case = self:getSelectedBrokerCase()
    if case == nil then return end
    self.pendingBrokerWithdraw = case
    YesNoDialog.show(self.onBrokerWithdrawConfirmed, self, self.i18n:getText("rff_broker_withdraw_confirm"), self.i18n:getText("rff_broker_title"))
end

function RFF_FinanceFrame:onBrokerWithdrawConfirmed(confirmed)
    local case = self.pendingBrokerWithdraw
    self.pendingBrokerWithdraw = nil
    if confirmed and case ~= nil and self.manager.brokerService:withdrawCase(case) then
        InfoDialog.show(self.i18n:getText("rff_broker_withdrawn_message"))
        self:updateBrokerContent(true)
    end
end

function RFF_FinanceFrame:rebuildAssetFinanceSelector(preserveId)
    if self.assetAgreementOption == nil or self.manager == nil or self.manager.repository == nil then return end
    local farmId = self:getCurrentFarmId()
    self.assetAgreements = self.manager.repository:getAssetFinanceByFarm(farmId, false)
    table.sort(self.assetAgreements, function(a, b) return (a.id or 0) > (b.id or 0) end)
    local texts = {}
    local selected = 1
    for index, agreement in ipairs(self.assetAgreements) do
        local productKey = self.manager.assetFinance:getProductTextKey(agreement.product)
        local lenderName = agreement.lenderNameKey ~= nil and agreement.lenderNameKey ~= "" and self.i18n:getText(agreement.lenderNameKey) or self.i18n:getText("rff_lender_primary_bank")
        table.insert(texts, string.format("#%d  %s  -  %s  -  %s", agreement.id or index, agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self.i18n:getText(productKey), lenderName))
        if preserveId ~= nil and agreement.id == preserveId then selected = index end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_none")} end
    if self.assetAgreementOption.setTexts ~= nil then self.assetAgreementOption:setTexts(texts) else self.assetAgreementOption.texts = texts end
    setOptionState(self.assetAgreementOption, selected)
end

function RFF_FinanceFrame:getSelectedAssetFinance()
    if self.assetAgreements == nil or #self.assetAgreements == 0 then return nil end
    local index = math.max(1, math.min(#self.assetAgreements, self.assetAgreementOption ~= nil and (self.assetAgreementOption.state or 1) or 1))
    return self.assetAgreements[index]
end

function RFF_FinanceFrame:onAssetAgreementChanged()
    self:updateAssetFinanceContent(false)
end

function RFF_FinanceFrame:getAssetStatusText(agreement)
    if agreement == nil then return self.i18n:getText("rff_none") end
    if (agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE") and (agreement.arrearsBalance or 0) > 0.01 then return self:getArrearsStageText(agreement.arrearsStage) end
    if agreement.status == "ACTIVE" then return self.i18n:getText("rff_status_active") end
    if agreement.status == "RETURN_DUE" then return self.i18n:getText("rff_asset_status_return_due") end
    if agreement.status == "RETURNED" then
        if agreement.returnEarlyTerminated == true then return self.i18n:getText("rff_asset_status_returned_early") end
        return self.i18n:getText("rff_asset_status_returned")
    end
    if agreement.status == "RECOVERED" then return self.i18n:getText("rff_asset_status_recovered") end
    if agreement.status == "SURRENDERED" then return self.i18n:getText("rff_asset_status_surrendered") end
    return self.i18n:getText("rff_status_completed")
end

function RFF_FinanceFrame:updateAssetFinanceContent(rebuild)
    if self.manager == nil or self.manager.repository == nil or self.manager.assetFinance == nil then return end
    local current = self:getSelectedAssetFinance()
    local preserveId = current ~= nil and current.id or nil
    if rebuild or self.assetAgreements == nil or #self.assetAgreements == 0 then self:rebuildAssetFinanceSelector(preserveId) end
    local agreement = self:getSelectedAssetFinance()
    local fields = {"assetStatusValue","assetProductValue","assetProviderValue","assetVehicleValue","assetPriceValue","assetDepositValue","assetBalanceValue","assetRateValue","assetPaymentValue","assetTermValue","assetBalloonValue","assetPaymentsValue","assetMissedValue","assetArrearsValue","assetConsecutiveMissedValue","assetInterestValue","assetSettlementValue","assetReturnRepairValue","assetReturnMaintenanceValue","assetReturnCleaningValue","assetEarlyTerminationValue","assetReturnRefundValue","assetReturnExtraValue"}
    local returnControls = {"assetReturnHeader","assetReturnRepairLabel","assetReturnRepairValue","assetReturnMaintenanceLabel","assetReturnMaintenanceValue","assetReturnCleaningLabel","assetReturnCleaningValue","assetEarlyTerminationLabel","assetEarlyTerminationValue","assetReturnRefundLabel","assetReturnRefundValue","assetReturnExtraLabel","assetReturnExtraValue"}

    for _, name in ipairs(returnControls) do
        if self[name] ~= nil then self[name]:setVisible(false) end
    end
    if self.assetReturnLeaseButton ~= nil then self.assetReturnLeaseButton:setVisible(false) end
    if self.assetPayArrearsButton ~= nil then self.assetPayArrearsButton:setVisible(false) end
    if self.assetRecoveryButton ~= nil then self.assetRecoveryButton:setVisible(false) end

    if agreement == nil then
        for _, name in ipairs(fields) do if self[name] ~= nil then self[name]:setText("-") end end
        if self.assetSettleButton ~= nil then self.assetSettleButton:setVisible(false) end
        if self.assetPayArrearsButton ~= nil then self.assetPayArrearsButton:setVisible(false) end
        if self.assetRecoveryButton ~= nil then self.assetRecoveryButton:setVisible(false) end
        if self.assetManagementNote ~= nil then self.assetManagementNote:setText(self.i18n:getText("rff_asset_management_note_v414")) end
    else
        local productKey = self.manager.assetFinance:getProductTextKey(agreement.product)
        if self.assetStatusValue ~= nil then self.assetStatusValue:setText(self:getAssetStatusText(agreement)) end
        if self.assetProductValue ~= nil then self.assetProductValue:setText(self.i18n:getText(productKey)) end
        if self.assetProviderValue ~= nil then
            local lenderName = agreement.lenderNameKey ~= nil and agreement.lenderNameKey ~= "" and self.i18n:getText(agreement.lenderNameKey) or self.i18n:getText("rff_lender_primary_bank")
            if agreement.lenderAssignmentLegacy == true then
                lenderName = lenderName .. " " .. self.i18n:getText("rff_asset_provider_legacy_suffix")
            elseif agreement.lenderDealFit ~= nil and agreement.lenderDealFit ~= "" then
                lenderName = string.format("%s - %s", lenderName, self:getDealFitText(agreement.lenderDealFit))
            end
            self.assetProviderValue:setText(lenderName)
        end
        if self.assetVehicleValue ~= nil then self.assetVehicleValue:setText(agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle")) end
        if self.assetPriceValue ~= nil then self.assetPriceValue:setText(self:formatMoney(agreement.basePrice or 0)) end
        if self.assetDepositValue ~= nil then self.assetDepositValue:setText(self:formatMoney(agreement.depositPaid or 0)) end
        if self.assetBalanceValue ~= nil then self.assetBalanceValue:setText(agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE and self.i18n:getText("rff_asset_not_owned") or self:formatMoney(agreement.principal or 0)) end
        if self.assetRateValue ~= nil then self.assetRateValue:setText(string.format("%.2f%%", agreement.interestRate or 0)) end
        if self.assetPaymentValue ~= nil then self.assetPaymentValue:setText(self:formatMoney(agreement.monthlyPayment or 0)) end
        if self.assetTermValue ~= nil then self.assetTermValue:setText(self:formatTerm(agreement.remainingMonths or 0)) end
        local terminal = agreement.product == RFF_AssetFinanceService.TYPE_BALLOON and (agreement.balloonAmount or 0) or (agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE and (agreement.residualValue or 0) or 0)
        if self.assetBalloonValue ~= nil then self.assetBalloonValue:setText(self:formatMoney(terminal)) end
        if self.assetPaymentsValue ~= nil then self.assetPaymentsValue:setText(tostring(agreement.paymentsMade or 0)) end
        if self.assetMissedValue ~= nil then self.assetMissedValue:setText(tostring(agreement.missedPayments or 0)) end
        if self.assetArrearsValue ~= nil then self.assetArrearsValue:setText(self:formatMoney(agreement.arrearsBalance or 0)) end
        if self.assetConsecutiveMissedValue ~= nil then self.assetConsecutiveMissedValue:setText(tostring(agreement.consecutiveMissedPayments or 0)) end
        if self.assetInterestValue ~= nil then self.assetInterestValue:setText(self:formatMoney((agreement.interestPaid or 0) + (agreement.leaseRentPaid or 0))) end
        local settlement = self.manager.assetFinance:getSettlementAmount(agreement)
        if self.assetSettlementValue ~= nil then self.assetSettlementValue:setText(agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE and self.i18n:getText("rff_not_applicable") or self:formatMoney(settlement)) end
        local openAgreement = agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE"
        local inDefault = agreement.currentDefault == true or agreement.arrearsStage == "DEFAULT_NOTICE" or agreement.arrearsStage == "RECOVERY"
        if self.assetSettleButton ~= nil then self.assetSettleButton:setVisible(agreement.status == "ACTIVE" and agreement.product ~= RFF_AssetFinanceService.TYPE_OPERATING_LEASE and not inDefault) end
        if self.assetPayArrearsButton ~= nil then self.assetPayArrearsButton:setVisible(openAgreement and (agreement.arrearsBalance or 0) > 0.01) end
        if self.assetRecoveryButton ~= nil then self.assetRecoveryButton:setVisible(openAgreement and inDefault) end
        if self.assetManagementNote ~= nil then
            if agreement.status == "RECOVERED" or agreement.status == "SURRENDERED" then
                local recovery = self.manager.assetFinance:getRecoveryAssessment(agreement, agreement.status == "SURRENDERED")
                local linked = (recovery ~= nil and (recovery.liabilityLoanId or 0) > 0) and string.format(" #%d", recovery.liabilityLoanId) or ""
                if recovery ~= nil and recovery.adsApplied == true then
                    self.assetManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_asset_recovery_history_note_ads"), self:formatMoney(recovery.realisedValue or 0), self:formatMoney(recovery.technicalAdjustment or 0), self:formatMoney(recovery.recoveryCosts or 0), self:formatMoney(recovery.shortfall or 0), linked), 66))
                else
                    self.assetManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_asset_recovery_history_note"), self:formatMoney(recovery ~= nil and recovery.realisedValue or 0), self:formatMoney(recovery ~= nil and recovery.recoveryCosts or 0), self:formatMoney(recovery ~= nil and recovery.shortfall or 0), linked), 66))
                end
            elseif inDefault then
                local recovery = self.manager.assetFinance:getRecoveryAssessment(agreement, true)
                if agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
                    if recovery ~= nil and recovery.adsApplied == true then
                        self.assetManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_asset_recovery_lease_note_ads"), self:formatMoney(recovery.depositApplied or 0), self:formatMoney(recovery.repairCost or 0), self:formatMoney(recovery.maintenancePenalty or 0), self:formatMoney(recovery.recoveryCosts or 0), self:formatMoney(recovery.shortfall or 0)), 66))
                    else
                        self.assetManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_asset_recovery_lease_note"), self:formatMoney(recovery ~= nil and recovery.depositApplied or 0), self:formatMoney(recovery ~= nil and recovery.recoveryCosts or 0), self:formatMoney(recovery ~= nil and recovery.shortfall or 0)), 66))
                    end
                else
                    if recovery ~= nil and recovery.adsApplied == true then
                        self.assetManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_asset_recovery_owned_note_ads"), self:formatMoney(recovery.marketValue or 0), self:formatMoney(recovery.technicalAdjustment or 0), self:formatMoney(recovery.adjustedMarketValue or 0), self:formatMoney(recovery.realisedValue or 0), self:formatMoney(recovery.recoveryCosts or 0), self:formatMoney(recovery.shortfall or 0)), 66))
                    else
                        self.assetManagementNote:setText(wrapText(string.format(self.i18n:getText("rff_asset_recovery_owned_note"), self:formatMoney(recovery ~= nil and recovery.marketValue or 0), self:formatMoney(recovery ~= nil and recovery.realisedValue or 0), self:formatMoney(recovery ~= nil and recovery.recoveryCosts or 0), self:formatMoney(recovery ~= nil and recovery.shortfall or 0)), 66))
                    end
                end
            else
                self.assetManagementNote:setText(self.i18n:getText("rff_asset_management_note_v414"))
            end
        end

        if agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
            for _, name in ipairs(returnControls) do
                if self[name] ~= nil then self[name]:setVisible(true) end
            end
            local assessment = self.manager.assetFinance:getLeaseReturnAssessment(agreement)
            if assessment ~= nil then
                if self.assetReturnRepairValue ~= nil then self.assetReturnRepairValue:setText(self:formatMoney(assessment.repairCost or 0)) end
                if self.assetReturnMaintenanceValue ~= nil then self.assetReturnMaintenanceValue:setText(self:formatMoney(assessment.maintenancePenalty or 0)) end
                if self.assetReturnCleaningValue ~= nil then self.assetReturnCleaningValue:setText(self:formatMoney(assessment.washingCost or 0)) end
                if self.assetEarlyTerminationValue ~= nil then self.assetEarlyTerminationValue:setText(self:formatMoney(assessment.earlyTerminationCharge or 0)) end
                if self.assetReturnRefundValue ~= nil then self.assetReturnRefundValue:setText(self:formatMoney(assessment.depositRefund or 0)) end
                if self.assetReturnExtraValue ~= nil then self.assetReturnExtraValue:setText(self:formatMoney(assessment.additionalCharge or 0)) end
            end
            if self.assetReturnLeaseButton ~= nil then
                local canReturn = (agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE") and not inDefault
                self.assetReturnLeaseButton:setVisible(canReturn)
                if agreement.status == "ACTIVE" then
                    self.assetReturnLeaseButton:setText(self.i18n:getText("rff_asset_end_lease_early"))
                else
                    self.assetReturnLeaseButton:setText(self.i18n:getText("rff_asset_return_lease"))
                end
            end
        end
    end

    local farmId = self:getCurrentFarmId()
    local active = self.manager.repository:getAssetFinanceByFarm(farmId, true)
    local hp, balloon, leases, balance, monthly = 0,0,0,0,0
    for _, item in ipairs(active) do
        if item.product == RFF_AssetFinanceService.TYPE_HIRE_PURCHASE then hp = hp + 1
        elseif item.product == RFF_AssetFinanceService.TYPE_BALLOON then balloon = balloon + 1
        elseif item.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then leases = leases + 1 end
        if item.status == "ACTIVE" or item.status == "RETURN_DUE" then
            if item.product ~= RFF_AssetFinanceService.TYPE_OPERATING_LEASE then balance = balance + math.max(0, item.principal or 0) end
            balance = balance + math.max(0, item.arrearsBalance or 0)
        end
        if item.status == "ACTIVE" and (item.remainingMonths or 0) > 0 then monthly = monthly + math.max(0, item.monthlyPayment or 0) end
    end
    if self.assetHpCountValue ~= nil then self.assetHpCountValue:setText(tostring(hp)) end
    if self.assetBalloonCountValue ~= nil then self.assetBalloonCountValue:setText(tostring(balloon)) end
    if self.assetLeaseCountValue ~= nil then self.assetLeaseCountValue:setText(tostring(leases)) end
    if self.assetOutstandingValue ~= nil then self.assetOutstandingValue:setText(self:formatMoney(balance)) end
    if self.assetMonthlyCommitmentValue ~= nil then self.assetMonthlyCommitmentValue:setText(self:formatMoney(monthly)) end
    if self.assetRefundableDepositsValue ~= nil then self.assetRefundableDepositsValue:setText(self:formatMoney(self.manager.repository:getRefundableAssetFinanceDeposits(farmId))) end
end

function RFF_FinanceFrame:onClickPayAssetArrears()
    local agreement = self:getSelectedAssetFinance()
    if agreement == nil or self.manager == nil or self.manager.assetFinance == nil then return end
    local amount = math.max(0, agreement.arrearsBalance or 0)
    if amount <= 0.01 then return end
    self.pendingAssetArrears = agreement
    YesNoDialog.show(self.onAssetArrearsConfirmed, self,
        string.format(self.i18n:getText("rff_confirm_pay_arrears"), self:formatMoney(amount)),
        self.i18n:getText("rff_pay_arrears"))
end

function RFF_FinanceFrame:onAssetArrearsConfirmed(confirmed)
    local agreement = self.pendingAssetArrears
    self.pendingAssetArrears = nil
    if not confirmed or agreement == nil then return end
    local ok, reason, amount = self.manager.assetFinance:payArrears(agreement)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_arrears_paid"), self:formatMoney(amount or 0)))
        self:updateAssetFinanceContent(true)
        self:updateContent()
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_insufficient_funds"))
    end
end

function RFF_FinanceFrame:onClickSettleAssetFinance()
    local agreement = self:getSelectedAssetFinance()
    if agreement == nil or agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then return end
    local amount = self.manager.assetFinance:getSettlementAmount(agreement)
    self.pendingAssetSettlement = agreement
    YesNoDialog.show(self.onAssetSettlementConfirmed, self, string.format(self.i18n:getText("rff_asset_settle_confirm"), agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self:formatMoney(amount)), self.i18n:getText("rff_tab_asset_finance"))
end

function RFF_FinanceFrame:onAssetSettlementConfirmed(confirmed)
    local agreement = self.pendingAssetSettlement
    self.pendingAssetSettlement = nil
    if not confirmed or agreement == nil then return end
    local ok, reason, amount = self.manager.assetFinance:settleAgreement(agreement)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_asset_settled_message"), agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self:formatMoney(amount)))
        self:updateAssetFinanceContent(true)
        self:updateContent()
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_asset_settle_insufficient"))
    end
end

function RFF_FinanceFrame:onClickSurrenderAsset()
    local agreement = self:getSelectedAssetFinance()
    if agreement == nil or self.manager == nil or self.manager.assetFinance == nil then return end
    local assessment = self.manager.assetFinance:getRecoveryAssessment(agreement, true)
    if assessment == nil then return end
    self.pendingAssetRecovery = agreement
    local text
    if agreement.product == RFF_AssetFinanceService.TYPE_OPERATING_LEASE then
        if assessment.adsApplied == true then
            text = string.format(self.i18n:getText("rff_asset_surrender_confirm_lease_ads"), agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self:formatMoney(assessment.depositApplied or 0), self:formatMoney(assessment.repairCost or 0), self:formatMoney(assessment.maintenancePenalty or 0), self:formatMoney(assessment.recoveryCosts or 0), self:formatMoney(assessment.shortfall or 0))
        else
            text = string.format(self.i18n:getText("rff_asset_surrender_confirm_lease"), agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self:formatMoney(assessment.depositApplied or 0), self:formatMoney(assessment.recoveryCosts or 0), self:formatMoney(assessment.shortfall or 0))
        end
    else
        if assessment.adsApplied == true then
            text = string.format(self.i18n:getText("rff_asset_surrender_confirm_owned_ads"), agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self:formatMoney(assessment.marketValue or 0), self:formatMoney(assessment.technicalAdjustment or 0), self:formatMoney(assessment.adjustedMarketValue or 0), self:formatMoney(assessment.realisedValue or 0), self:formatMoney(assessment.recoveryCosts or 0), self:formatMoney(assessment.shortfall or 0))
        else
            text = string.format(self.i18n:getText("rff_asset_surrender_confirm_owned"), agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self:formatMoney(assessment.marketValue or 0), self:formatMoney(assessment.realisedValue or 0), self:formatMoney(assessment.recoveryCosts or 0), self:formatMoney(assessment.shortfall or 0))
        end
    end
    YesNoDialog.show(self.onAssetSurrenderConfirmed, self, text, self.i18n:getText("rff_asset_surrender"))
end

function RFF_FinanceFrame:onAssetSurrenderConfirmed(confirmed)
    local agreement = self.pendingAssetRecovery
    self.pendingAssetRecovery = nil
    if not confirmed or agreement == nil then return end
    local ok, reason, assessment = self.manager.assetFinance:recoverAsset(agreement, true)
    if ok then
        local liability = assessment ~= nil and (assessment.liabilityLoanId or 0) or 0
        InfoDialog.show(string.format(self.i18n:getText("rff_asset_surrender_complete"), agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"), self:formatMoney(assessment ~= nil and assessment.shortfall or 0), liability > 0 and string.format(" #%d", liability) or ""))
        self:updateAssetFinanceContent(true)
        self:updateAgreementsContent(true)
        self:updateContent()
        return
    end
    local key = "rff_asset_recovery_error_generic"
    if reason == "vehicle_missing" then key = "rff_asset_return_error_missing"
    elseif reason == "in_use" then key = "rff_asset_return_error_in_use"
    elseif reason == "attached" or reason == "attachments" then key = "rff_asset_return_error_attached"
    elseif reason == "remove_failed" then key = "rff_asset_return_error_remove"
    elseif reason == "not_default" then key = "rff_asset_recovery_not_default" end
    InfoDialog.show(self.i18n:getText(key))
end

function RFF_FinanceFrame:onClickReturnOperatingLease()
    local agreement = self:getSelectedAssetFinance()
    if agreement == nil or agreement.product ~= RFF_AssetFinanceService.TYPE_OPERATING_LEASE or (agreement.status ~= "ACTIVE" and agreement.status ~= "RETURN_DUE") then return end
    local assessment = self.manager.assetFinance:getLeaseReturnAssessment(agreement)
    if assessment == nil then return end
    self.pendingLeaseReturn = agreement
    local text
    if agreement.status == "ACTIVE" then
        text = string.format(self.i18n:getText("rff_asset_early_return_confirm"),
            agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"),
            math.max(0, math.floor(assessment.remainingMonthsAtReturn or 0)),
            self:formatMoney(assessment.futureRentAtReturn or 0),
            self:formatMoney(assessment.earlyTerminationCharge or 0),
            self:formatMoney(assessment.deposit or 0),
            self:formatMoney(assessment.arrears or 0),
            self:formatMoney(assessment.repairCost or 0),
            self:formatMoney(assessment.maintenancePenalty or 0),
            self:formatMoney(assessment.washingCost or 0),
            self:formatMoney(assessment.depositRefund or 0),
            self:formatMoney(assessment.additionalCharge or 0))
    else
        text = string.format(self.i18n:getText("rff_asset_return_confirm"),
            agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"),
            self:formatMoney(assessment.deposit or 0),
            self:formatMoney(assessment.arrears or 0),
            self:formatMoney(assessment.repairCost or 0),
            self:formatMoney(assessment.maintenancePenalty or 0),
            self:formatMoney(assessment.washingCost or 0),
            self:formatMoney(assessment.depositRefund or 0),
            self:formatMoney(assessment.additionalCharge or 0))
    end
    YesNoDialog.show(self.onOperatingLeaseReturnConfirmed, self, text, self.i18n:getText("rff_tab_asset_finance"))
end

function RFF_FinanceFrame:onOperatingLeaseReturnConfirmed(confirmed)
    local agreement = self.pendingLeaseReturn
    self.pendingLeaseReturn = nil
    if not confirmed or agreement == nil then return end
    local ok, reason, assessment = self.manager.assetFinance:returnOperatingLease(agreement)
    if ok then
        local key = assessment.earlyTerminated == true and "rff_asset_early_return_complete" or "rff_asset_return_complete"
        InfoDialog.show(string.format(self.i18n:getText(key),
            agreement.vehicleName or self.i18n:getText("rff_asset_unknown_vehicle"),
            self:formatMoney(assessment.depositRefund or 0),
            self:formatMoney(assessment.additionalCharge or 0)))
        self:updateAssetFinanceContent(true)
        self:updateContent()
        return
    end

    local key = "rff_asset_return_error_generic"
    if reason == "funds" then key = "rff_asset_return_error_funds"
    elseif reason == "default" then key = "rff_asset_early_return_error_default"
    elseif reason == "vehicle_missing" then key = "rff_asset_return_error_missing"
    elseif reason == "in_use" then key = "rff_asset_return_error_in_use"
    elseif reason == "attached" or reason == "attachments" then key = "rff_asset_return_error_attached"
    elseif reason == "remove_failed" then key = "rff_asset_return_error_remove" end
    InfoDialog.show(self.i18n:getText(key))
end

function RFF_FinanceFrame:updatePropertyContent()
    if self.manager == nil or self.manager.repository == nil or self.manager.propertyFinance == nil then return end
    local farmId = self:getCurrentFarmId()
    local valuation = RFF_FarmValuation:calculate(farmId, self.manager.repository)
    local security = self.manager.propertyFinance:getPropertySecuritySummary(farmId)
    local mortgageCount, mortgageBalance, mortgagePayment = security.mortgageCount, security.mortgageBalance, security.mortgagePayment
    local tenancies = self.manager.repository:getTenanciesByFarm(farmId, true)
    self.tenancyAgreements = self.manager.repository:getTenanciesByFarm(farmId, false)
    table.sort(self.tenancyAgreements, function(a, b)
        local aPeriod, bPeriod = a.commencementPeriod or a.createdPeriod or 0, b.commencementPeriod or b.createdPeriod or 0
        if aPeriod == bPeriod then return (a.id or 0) > (b.id or 0) end
        return aPeriod > bPeriod
    end)
    if self.propertyOwnedLandValue ~= nil then self.propertyOwnedLandValue:setText(self:formatMoney(valuation.farmland)) end
    if self.propertyMortgageCountValue ~= nil then self.propertyMortgageCountValue:setText(tostring(mortgageCount)) end
    if self.propertyMortgageBalanceValue ~= nil then self.propertyMortgageBalanceValue:setText(self:formatMoney(mortgageBalance)) end
    if self.propertyMortgagePaymentValue ~= nil then self.propertyMortgagePaymentValue:setText(self:formatMoney(mortgagePayment)) end
    if self.propertyBuildingValue ~= nil then self.propertyBuildingValue:setText(self:formatMoney(security.buildingValue)) end
    if self.propertyTotalValue ~= nil then self.propertyTotalValue:setText(self:formatMoney(security.propertyValue)) end
    if self.propertyEquityValue ~= nil then self.propertyEquityValue:setText(self:formatMoney(security.propertyEquity)) end
    if self.propertyUnencumberedCountValue ~= nil then self.propertyUnencumberedCountValue:setText(tostring(security.unencumberedCount)) end
    if self.propertyUnencumberedValue ~= nil then self.propertyUnencumberedValue:setText(self:formatMoney(security.unencumberedLandValue)) end
    if self.propertySecurityHeadroomValue ~= nil then self.propertySecurityHeadroomValue:setText(self:formatMoney(security.indicativeSecurityHeadroom)) end
    if self.propertyEquityReleaseButton ~= nil then self.propertyEquityReleaseButton:setVisible(security.unencumberedCount > 0) end
    if self.propertyTenancyCountValue ~= nil then self.propertyTenancyCountValue:setText(tostring(#tenancies)) end
    if self.propertyRentValue ~= nil then self.propertyRentValue:setText(self:formatMoney(self.manager.repository:getMonthlyTenancyRent(farmId))) end
    if self.propertyTenancyArrearsValue ~= nil then self.propertyTenancyArrearsValue:setText(self:formatMoney(self.manager.repository:getTenancyArrears(farmId))) end
    if self.propertyDepositValue ~= nil then self.propertyDepositValue:setText(self:formatMoney(self.manager.repository:getRefundableTenancyDeposits(farmId))) end
    if self.tenancyAgreementList ~= nil then
        self.tenancyAgreementList:reloadData()
        local selectedIndex = 1
        for index, tenancy in ipairs(self.tenancyAgreements) do
            if tenancy.id == self.selectedTenancyAgreementId then selectedIndex = index break end
        end
        if self.tenancyAgreementList.setSelectedItem ~= nil and #self.tenancyAgreements > 0 then
            pcall(self.tenancyAgreementList.setSelectedItem, self.tenancyAgreementList, 1, selectedIndex)
            self.selectedTenancyAgreementId = self.tenancyAgreements[selectedIndex].id
        elseif #self.tenancyAgreements == 0 then
            self.selectedTenancyAgreementId = nil
        end
    end
    self:updateTenancyActionControls()
end

function RFF_FinanceFrame:onClickPropertyEquityRelease()
    if RFF_EquityReleaseDialog == nil or not RFF_EquityReleaseDialog.show(self) then
        InfoDialog.show(self.i18n:getText("rff_equity_release_no_security"))
    end
end

local function truncateStatementText(text, maxChars)
    text = tostring(text or "")
    maxChars = maxChars or 58
    if #text <= maxChars then return text end
    return text:sub(1, math.max(1, maxChars - 3)) .. "..."
end

local STATEMENT_ZERO_VALUE_THRESHOLD = 0.5

-- Statements retain every original transaction for audit, balance and persistence.
-- The default view combines matching entries and suppresses rounded zero-value rows;
-- the full view returns each original ledger entry without either transformation.
local function buildStatementDisplayRows(transactions, showEveryEntry)
    if showEveryEntry then
        local displayRows = {}
        for sourceIndex = #(transactions or {}), 1, -1 do
            table.insert(displayRows, transactions[sourceIndex])
        end
        return displayRows, #displayRows, 0
    end

    local groupedByKey = {}
    local groupedRows = {}

    for sourceIndex, transaction in ipairs(transactions or {}) do
        local amount = tonumber(transaction.amount) or 0
        local direction = amount < 0 and "OUT" or "IN"
        local key = table.concat({
            tostring(math.floor(tonumber(transaction.year) or 0)),
            tostring(math.floor(tonumber(transaction.periodNumber) or 0)),
            tostring(math.floor(tonumber(transaction.day) or 1)),
            tostring(transaction.statistic or ""),
            tostring(transaction.description or ""),
            direction
        }, "\31")
        local row = groupedByKey[key]
        if row == nil then
            row = {
                day = transaction.day,
                year = transaction.year,
                periodNumber = transaction.periodNumber,
                amount = 0,
                balance = transaction.balance,
                description = transaction.description,
                statistic = transaction.statistic,
                sourceIndex = sourceIndex,
                transactionCount = 0
            }
            groupedByKey[key] = row
            table.insert(groupedRows, row)
        end
        row.amount = row.amount + amount
        row.balance = transaction.balance
        row.sourceIndex = sourceIndex
        row.transactionCount = row.transactionCount + 1
    end

    table.sort(groupedRows, function(a, b) return a.sourceIndex > b.sourceIndex end)

    local displayRows = {}
    local hiddenCount = 0
    for _, row in ipairs(groupedRows) do
        if math.abs(row.amount) < STATEMENT_ZERO_VALUE_THRESHOLD then
            hiddenCount = hiddenCount + 1
        else
            table.insert(displayRows, row)
        end
    end
    return displayRows, #groupedRows, hiddenCount
end

function RFF_FinanceFrame:formatTenancyPeriod(period)
    period = math.max(0, math.floor(tonumber(period) or 0))
    local year = math.floor(math.max(0, period - 1) / 12)
    local seasonPeriod = ((math.max(1, period) - 1) % 12) + 1
    local calendarMonth = ((seasonPeriod + 1) % 12) + 1
    local monthName = self.i18n.formatPeriod ~= nil and self.i18n:formatPeriod(seasonPeriod, false)
        or self.i18n:getText(RFF_TENANCY_MONTH_KEYS[calendarMonth])
    return string.format("%s Y%d", monthName, year)
end

function RFF_FinanceFrame:formatFleetDate(date)
    if type(date) ~= "table" then return "-" end
    local month = math.max(1, math.min(12, math.floor(tonumber(date.month) or 1)))
    local day = math.max(1, math.floor(tonumber(date.day) or 1))
    local year = math.max(0, math.floor(tonumber(date.year) or 0))
    return string.format(self.i18n:getText("rff_fleet_date_format"), day, self.i18n:getText(RFF_TENANCY_MONTH_KEYS[month]), year)
end

function RFF_FinanceFrame:getFleetOwnershipText(ownership)
    local keys = {
        OWNED = "rff_fleet_owned",
        HIRE_PURCHASE = "rff_fleet_hire_purchase",
        BALLOON_FINANCE = "rff_fleet_balloon_finance",
        OPERATING_LEASE = "rff_fleet_operating_lease",
        NATIVE_LEASE = "rff_fleet_native_lease"
    }
    return self.i18n:getText(keys[ownership] or "rff_fleet_owned")
end

function RFF_FinanceFrame:getFleetInsuranceText(row)
    if row == nil then return "-" end
    if row.insuranceStatus == "LEASED" then return self.i18n:getText("rff_fleet_insurance_leased") end
    if row.insurancePolicy == nil then return self.i18n:getText("rff_insurance_status_uninsured") end
    local coverKey = row.insuranceCoverType == "THIRD_PARTY" and "rff_vehicle_cover_third_party" or "rff_vehicle_cover_comprehensive"
    local tierText = self.i18n:getText(coverKey)
    local statusText = self.i18n:getText("rff_insurance_status_" .. string.lower(tostring(row.insuranceStatus or "LAPSED")))
    return string.format(self.i18n:getText("rff_fleet_insurance_format"), tierText, statusText)
end

function RFF_FinanceFrame:getFleetServiceDueText(row)
    if row == nil or row.adsApplied ~= true then return "-" end
    if row.serviceRemainingHours == nil then return self.i18n:getText("rff_fleet_not_available") end
    if row.serviceRemainingHours <= 0 then
        return string.format(self.i18n:getText("rff_fleet_service_overdue"), math.abs(row.serviceRemainingHours))
    end
    return string.format(self.i18n:getText("rff_fleet_service_remaining"), row.serviceRemainingHours)
end

function RFF_FinanceFrame:updateFleetContent()
    local service = self.manager ~= nil and self.manager.fleetManagement or nil
    local farmId = self:getCurrentFarmId()
    if service == nil or farmId <= 0 then return end

    local summary = service:getFleet(farmId)
    self.fleetSummary = summary
    self.fleetVehicles = summary.vehicles or {}

    if self.fleetVehicleCountValue ~= nil then self.fleetVehicleCountValue:setText(tostring(summary.vehicleCount or 0)) end
    if self.fleetAdsStatusValue ~= nil then
        if summary.adsAvailable then
            self.fleetAdsStatusValue:setText(string.format(self.i18n:getText("rff_fleet_ads_active"), summary.adsTrackedCount or 0, summary.vehicleCount or 0))
        else
            self.fleetAdsStatusValue:setText(self.i18n:getText("rff_fleet_ads_not_installed"))
        end
    end
    if self.fleetInspectionDueValue ~= nil then self.fleetInspectionDueValue:setText(tostring(summary.inspectionDueCount or 0)) end
    if self.fleetServiceDueValue ~= nil then self.fleetServiceDueValue:setText(tostring(summary.serviceDueCount or 0)) end
    if self.fleetInsuranceStatusValue ~= nil then
        self.fleetInsuranceStatusValue:setText(string.format(self.i18n:getText("rff_fleet_insurance_summary"),
            summary.insuredCount or 0, summary.uninsuredCount or 0, summary.expiredCount or 0, summary.leasedCount or 0))
    end
    if self.fleetNote ~= nil then
        local key = summary.adsAvailable and "rff_fleet_note_ads" or "rff_fleet_note_no_ads"
        self.fleetNote:setText(self.i18n:getText(key))
    end
    if self.fleetVehicleList ~= nil then
        self.fleetVehicleList:reloadData()
        if self.fleetVehicleList.setSelectedItem ~= nil and #self.fleetVehicles > 0 then
            pcall(self.fleetVehicleList.setSelectedItem, self.fleetVehicleList, 1, 1)
        end
    end
end

function RFF_FinanceFrame:getSelectedTenancyAgreement()
    for _, tenancy in ipairs(self.tenancyAgreements or {}) do
        if tenancy.id == self.selectedTenancyAgreementId then return tenancy end
    end
    return nil
end

function RFF_FinanceFrame:getSelectedTenancyNarrativeEvent()
    local tenancy = self:getSelectedTenancyAgreement()
    local events = tenancy ~= nil and (tenancy.narrativeEvents or {}) or {}
    local count = #events
    if count == 0 then
        self.selectedTenancyNarrativeIndex = nil
        return nil, 0, 0
    end
    local index = math.floor(tonumber(self.selectedTenancyNarrativeIndex) or count)
    index = math.max(1, math.min(count, index))
    self.selectedTenancyNarrativeIndex = index
    return events[index], index, count
end

function RFF_FinanceFrame:onClickPreviousTenancyNarrative()
    local _, index, count = self:getSelectedTenancyNarrativeEvent()
    if count <= 1 then return end
    self.selectedTenancyNarrativeIndex = math.max(1, index - 1)
    self:updateTenancyActionControls()
end

function RFF_FinanceFrame:onClickNextTenancyNarrative()
    local _, index, count = self:getSelectedTenancyNarrativeEvent()
    if count <= 1 then return end
    self.selectedTenancyNarrativeIndex = math.min(count, index + 1)
    self:updateTenancyActionControls()
end

function RFF_FinanceFrame:onListSelectionChanged(list, section, index)
    if list ~= self.tenancyAgreementList then return end
    local tenancy = self.tenancyAgreements ~= nil and self.tenancyAgreements[index] or nil
    local selectedId = tenancy ~= nil and tenancy.id or nil
    if selectedId ~= self.selectedTenancyAgreementId then self.selectedTenancyNarrativeIndex = nil end
    self.selectedTenancyAgreementId = selectedId
    self:updateTenancyActionControls()
end

function RFF_FinanceFrame:updateTenancyActionControls()
    local tenancy = self:getSelectedTenancyAgreement()
    local isApplication = tenancy ~= nil and self.manager.propertyFinance:isInitialTenancyApplication(tenancy)
    if self.instantTenancyButton then self.instantTenancyButton:setVisible(self.manager.propertyFinance:canInstantTenancyDecision(tenancy,self:getCurrentFarmId())) end
    local current = self.manager ~= nil and self.manager.repository ~= nil and self.manager.repository:getCurrentPeriodIndex() or 0
    local canRespond = tenancy ~= nil and tenancy.renewalOfferStatus == "OFFERED" and current <= (tenancy.renewalOfferExpiryPeriod or 0)
    local negotiationStatus = tenancy ~= nil and (tenancy.renewalNegotiationStatus or "NOT_STARTED") or "NOT_STARTED"
    local reviewPending = negotiationStatus == "LANDLORD_REVIEW" or negotiationStatus == "SOLICITOR_REVIEW"
    local immediateRejected = negotiationStatus == "IMMEDIATE_REJECTED"
    local counterAvailable = negotiationStatus == "COUNTER_OFFER" or negotiationStatus == "COUNTERED" or negotiationStatus == "DECLINED"
    local termsAgreed = negotiationStatus == "TERMS_AGREED" or negotiationStatus == "AGREED"
    local finalCounter = negotiationStatus == "FINAL_COUNTER"
    local landlordVisible = tenancy ~= nil and (not isApplication or tenancy.applicationLandlordIntroduced == true)
    local landlordBrief = landlordVisible and self.manager.propertyFinance:getTenancyLandlordBrief(tenancy) or nil
    local maxRounds = landlordBrief ~= nil and landlordBrief.maxRounds or 2
    local canNegotiate = canRespond and ((negotiationStatus == "NOT_STARTED" or negotiationStatus == "")
        or ((counterAvailable or immediateRejected) and (tenancy.renewalNegotiationAttempts or 0) < maxRounds))
    local canDecide = canRespond and not reviewPending
    local openApplication = isApplication and (tenancy.status == "APPLICATION" or tenancy.status == "APPLICATION_REVIEW" or tenancy.status == "APPLICATION_HEADS")
    local canWithdrawApplication = openApplication
    local possession = tenancy ~= nil and (tenancy.status == "ACTIVE" or tenancy.status == "EXPIRING" or tenancy.status == "RENEWAL_OFFERED" or tenancy.status == "NOTICE_SERVED")
    local canBreak = possession and tenancy.breakEnabled == true and tenancy.renewalOfferStatus ~= "ACCEPTED" and tenancy.renewalOfferStatus ~= "OFFERED"
        and (tenancy.noticeReason == nil or tenancy.noticeReason == "") and current >= (tenancy.earliestBreakPeriod or 0)
    local canManageCovenants = possession
    if self.tenancyAcceptRenewalButton ~= nil then
        self.tenancyAcceptRenewalButton:setVisible(canDecide)
        if isApplication then self.tenancyAcceptRenewalButton:setText(self.i18n:getText("rff_tenancy_sign_initial"))
        elseif termsAgreed then self.tenancyAcceptRenewalButton:setText(self.i18n:getText("rff_tenancy_sign_renewal"))
        elseif immediateRejected then self.tenancyAcceptRenewalButton:setText(self.i18n:getText("rff_tenancy_accept_landlord_terms"))
        elseif counterAvailable or finalCounter then self.tenancyAcceptRenewalButton:setText(self.i18n:getText("rff_tenancy_accept_counter"))
        else self.tenancyAcceptRenewalButton:setText(self.i18n:getText("rff_tenancy_accept_renewal")) end
    end
    if self.tenancyNegotiateRenewalButton ~= nil then
        self.tenancyNegotiateRenewalButton:setVisible(canNegotiate)
        local buttonKey = immediateRejected and "rff_tenancy_submit_new_figure"
            or (counterAvailable and "rff_tenancy_revise_proposal" or "rff_tenancy_open_negotiation")
        self.tenancyNegotiateRenewalButton:setText(self.i18n:getText(buttonKey))
    end
    if self.tenancyDeclineRenewalButton ~= nil then
        self.tenancyDeclineRenewalButton:setVisible(canDecide or canWithdrawApplication)
        self.tenancyDeclineRenewalButton:setText(self.i18n:getText(isApplication and "rff_tenancy_withdraw_application" or "rff_tenancy_decline_renewal"))
    end
    if self.tenancyManageCovenantsButton ~= nil then self.tenancyManageCovenantsButton:setVisible(canManageCovenants) end
    if self.tenancyBreakButton ~= nil then self.tenancyBreakButton:setVisible(canBreak) end
    if self.tenancyActionNote == nil then return end
    local note = self.i18n:getText("rff_tenancy_select_agreement")
    if tenancy ~= nil then
        if canRespond then
            local landlordName = self.manager.propertyFinance:getLandlordName(tenancy.landlord, tenancy.farmlandId)
            local currentDay = self.manager.propertyFinance:getCurrentDay()
            local daysUntilUpdate = math.max(0, (tenancy.renewalNegotiationNextDay or currentDay) - currentDay)
            if negotiationStatus == "LANDLORD_REVIEW" then
                note = string.format(self.i18n:getText("rff_tenancy_landlord_review_note"), landlordName,
                    self:formatMoney(tenancy.renewalTenantProposalRent or 0), math.max(1, daysUntilUpdate), tenancy.renewalLegalReference or "-")
            elseif negotiationStatus == "SOLICITOR_REVIEW" then
                note = string.format(self.i18n:getText("rff_tenancy_legal_review_note"),
                    math.max(1, daysUntilUpdate), tenancy.renewalLegalReference or "-")
            elseif negotiationStatus == "TERMS_AGREED" or negotiationStatus == "AGREED" then
                note = string.format(self.i18n:getText("rff_tenancy_heads_agreed_note"), landlordName,
                    self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalLegalReference or "-")
            elseif negotiationStatus == "COUNTER_OFFER" or negotiationStatus == "COUNTERED" then
                note = string.format(self.i18n:getText("rff_tenancy_counter_offer_note"), landlordName,
                    self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalLegalReference or "-")
            elseif negotiationStatus == "IMMEDIATE_REJECTED" then
                note = string.format(self.i18n:getText("rff_tenancy_immediate_reject_note"), landlordName,
                    self:formatMoney(tenancy.renewalTenantProposalRent or 0),
                    math.max(0, maxRounds - (tenancy.renewalNegotiationAttempts or 0)), tenancy.renewalLegalReference or "-")
            elseif negotiationStatus == "FINAL_COUNTER" then
                note = string.format(self.i18n:getText("rff_tenancy_final_counter_note"), landlordName,
                    self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalLegalReference or "-")
            elseif negotiationStatus == "DECLINED" then
                note = string.format(self.i18n:getText("rff_tenancy_counter_offer_note"), landlordName,
                    self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalLegalReference or "-")
            elseif isApplication then
                local costs = self.manager.propertyFinance:getInitialTenancyCompletionCosts(tenancy)
                note = string.format(self.i18n:getText("rff_tenancy_initial_heads_note"), landlordName,
                    self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalOfferTermMonths or 0,
                    self:formatMoney(costs ~= nil and costs.total or 0))
            else
                note = string.format(self.i18n:getText("rff_tenancy_renewal_action_note"),
                    self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalOfferTermMonths or 0,
                    self:formatTenancyPeriod(tenancy.renewalOfferExpiryPeriod or 0))
            end
        elseif isApplication and tenancy.applicationStage == "ENQUIRY_RECEIVED" then
            note = string.format(self.i18n:getText("rff_tenancy_application_received_note"),
                tenancy.applicationReference or tenancy.agreementId or "-", math.max(1, (tenancy.applicationNextActionDay or 0) - self.manager.propertyFinance:getCurrentDay()))
        elseif isApplication and tenancy.applicationStage == "LANDLORD_INTRODUCTION" then
            note = string.format(self.i18n:getText("rff_tenancy_application_financial_checks_note"),
                landlordBrief ~= nil and landlordBrief.name or self.i18n:getText("rff_tenancy_landlord_pending"))
        elseif isApplication and tenancy.applicationStage == "CREDIT_ASSESSMENT" then
            note = string.format(self.i18n:getText("rff_tenancy_application_credit_complete_note"),
                tenancy.applicationCreditScore or 0, tenancy.applicationCreditBand or "-", tenancy.applicationDepositMonths or 0)
        elseif isApplication and tenancy.status == "APPLICATION_DECLINED" then
            note = string.format(self.i18n:getText("rff_tenancy_application_declined_note"), tenancy.applicationDecisionReason or "-")
        elseif isApplication and tenancy.status == "APPLICATION_WITHDRAWN" then
            note = self.i18n:getText("rff_tenancy_application_withdrawn_note")
        elseif isApplication and tenancy.status == "APPLICATION_EXPIRED" then
            note = self.i18n:getText("rff_tenancy_application_expired_note")
        elseif tenancy.renewalOfferStatus == "ACCEPTED" then
            local successor = self.manager.repository:getTenancyById(tenancy.farmId, tenancy.successorAgreementId)
            note = string.format(self.i18n:getText("rff_tenancy_renewal_accepted_note"),
                successor ~= nil and successor.agreementId or "-", self:formatTenancyPeriod(tenancy.contractualEndPeriod or 0))
        elseif tenancy.status == "FUTURE" then
            note = string.format(self.i18n:getText("rff_tenancy_future_note"), self:formatTenancyPeriod(tenancy.commencementPeriod or 0))
        elseif tenancy.status == "NOTICE_SERVED" then
            note = string.format(self.i18n:getText("rff_tenancy_notice_note"), self:formatTenancyPeriod(tenancy.noticeEffectivePeriod or tenancy.contractualEndPeriod or 0))
        elseif canBreak then
            note = string.format(self.i18n:getText("rff_tenancy_break_available_note"), math.max(1, tenancy.breakNoticeMonths or 0))
        elseif tenancy.breakEnabled == true and possession then
            note = string.format(self.i18n:getText("rff_tenancy_break_future_note"), self:formatTenancyPeriod(tenancy.earliestBreakPeriod or 0))
        else
            note = self.i18n:getText("rff_tenancy_no_action_note")
        end
    end
    local narrativeEvent, narrativeIndex, narrativeCount = self:getSelectedTenancyNarrativeEvent()
    local correspondenceMeta = ""
    if self.tenancyNarrativePreviousButton ~= nil then
        self.tenancyNarrativePreviousButton:setVisible(narrativeCount > 1)
        if self.tenancyNarrativePreviousButton.setDisabled ~= nil then
            self.tenancyNarrativePreviousButton:setDisabled(narrativeCount <= 1 or narrativeIndex <= 1)
        end
    end
    if self.tenancyNarrativeNextButton ~= nil then
        self.tenancyNarrativeNextButton:setVisible(narrativeCount > 1)
        if self.tenancyNarrativeNextButton.setDisabled ~= nil then
            self.tenancyNarrativeNextButton:setDisabled(narrativeCount <= 1 or narrativeIndex >= narrativeCount)
        end
    end
    if tenancy ~= nil and landlordBrief ~= nil and narrativeEvent ~= nil then
        correspondenceMeta = string.format(self.i18n:getText("rff_tenancy_correspondence_meta"), landlordBrief.name,
            narrativeEvent.label or tostring(narrativeEvent.eventType or "Correspondence"):gsub("_", " "),
            narrativeEvent.day or 0, narrativeIndex, narrativeCount)
        note = narrativeEvent.text or note
    elseif tenancy ~= nil and landlordBrief ~= nil then
        correspondenceMeta = string.format(self.i18n:getText("rff_tenancy_correspondence_landlord_meta"),
            landlordBrief.name, landlordBrief.relationshipText, landlordBrief.voiceDescription or landlordBrief.approach)
    elseif tenancy ~= nil and isApplication then
        correspondenceMeta = self.i18n:getText("rff_tenancy_application_team_meta")
    end
    if self.tenancyCorrespondenceMeta ~= nil then self.tenancyCorrespondenceMeta:setText(correspondenceMeta) end
    self.tenancyActionNote:setText(note)
end

function RFF_FinanceFrame:onClickAcceptTenancyRenewal()
    local tenancy = self:getSelectedTenancyAgreement()
    if tenancy == nil or tenancy.renewalOfferStatus ~= "OFFERED" then return end
    local terms = self.manager.propertyFinance:getTenancyRenewalTerms(tenancy, "renewalOffer")
    local packageSummary = self.manager.propertyFinance:getTenancyRenewalPackageSummary(terms)
    self.pendingTenancyAction = {action="ACCEPT_RENEWAL", tenancy=tenancy}
    if self.manager.propertyFinance:isInitialTenancyApplication(tenancy) then
        local costs = self.manager.propertyFinance:getInitialTenancyCompletionCosts(tenancy)
        YesNoDialog.show(self.onTenancyActionConfirmed, self,
            string.format(self.i18n:getText("rff_tenancy_sign_initial_confirm"), tenancy.holdingName or tenancy.agreementId,
                self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalOfferTermMonths or 0, packageSummary,
                self:formatMoney(costs ~= nil and costs.deposit or 0), self:formatMoney(costs ~= nil and costs.instalment or 0),
                self:formatMoney(costs ~= nil and costs.legalFee or 0), self:formatMoney(costs ~= nil and costs.total or 0)),
            self.i18n:getText("rff_tenancy_signing_title"))
    else
        YesNoDialog.show(self.onTenancyActionConfirmed, self,
            string.format(self.i18n:getText("rff_tenancy_accept_package_confirm"), tenancy.holdingName or tenancy.agreementId,
                self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalOfferTermMonths or 0, packageSummary),
            self.i18n:getText("rff_tenancy_renewal_title"))
    end
end

function RFF_FinanceFrame:onClickDeclineTenancyRenewal()
    local tenancy = self:getSelectedTenancyAgreement()
    local isOpenApplication = tenancy ~= nil and self.manager.propertyFinance:isInitialTenancyApplication(tenancy)
        and (tenancy.status == "APPLICATION" or tenancy.status == "APPLICATION_REVIEW" or tenancy.status == "APPLICATION_HEADS")
    if tenancy == nil or (tenancy.renewalOfferStatus ~= "OFFERED" and not isOpenApplication) then return end
    self.pendingTenancyAction = {action="DECLINE_RENEWAL", tenancy=tenancy}
    if self.manager.propertyFinance:isInitialTenancyApplication(tenancy) then
        YesNoDialog.show(self.onTenancyActionConfirmed, self,
            string.format(self.i18n:getText("rff_tenancy_withdraw_confirm"), tenancy.holdingName or tenancy.agreementId),
            self.i18n:getText("rff_tenancy_enquiry_title"))
    else
        YesNoDialog.show(self.onTenancyActionConfirmed, self,
            string.format(self.i18n:getText("rff_tenancy_decline_confirm"), tenancy.holdingName or tenancy.agreementId,
                self:formatTenancyPeriod(tenancy.contractualEndPeriod or 0)), self.i18n:getText("rff_tenancy_renewal_title"))
    end
end

function RFF_FinanceFrame:onClickNegotiateTenancyRenewal()
    local tenancy = self:getSelectedTenancyAgreement()
    if tenancy == nil or tenancy.renewalOfferStatus ~= "OFFERED" then return end
    local status = tenancy.renewalNegotiationStatus or "NOT_STARTED"
    local isRevision = status == "COUNTER_OFFER" or status == "COUNTERED" or status == "DECLINED" or status == "IMMEDIATE_REJECTED"
    local brief = self.manager.propertyFinance:getTenancyLandlordBrief(tenancy)
    if isRevision and (tenancy.renewalNegotiationAttempts or 0) >= (brief ~= nil and brief.maxRounds or 2) then return end
    if status ~= "NOT_STARTED" and status ~= "" and not isRevision then return end
    local originalRent = (tenancy.renewalOriginalAnnualRent or 0) > 0 and tenancy.renewalOriginalAnnualRent or (tenancy.renewalOfferAnnualRent or 0)
    local defaultRent = isRevision and ((tenancy.renewalTenantProposalRent or 0) > 0 and tenancy.renewalTenantProposalRent or tenancy.renewalOfferAnnualRent)
        or tenancy.renewalOfferAnnualRent
    if RFF_LandFinanceDialog == nil or not RFF_LandFinanceDialog.showRenewal(self, tenancy, defaultRent or originalRent) then
        InfoDialog.show(self.i18n:getText("rff_tenancy_amount_input_unavailable"))
    end
end

function RFF_FinanceFrame:onClickExerciseTenancyBreak()
    local tenancy = self:getSelectedTenancyAgreement()
    if tenancy == nil then return end
    self.pendingTenancyAction = {action="BREAK", tenancy=tenancy}
    YesNoDialog.show(self.onTenancyActionConfirmed, self,
        string.format(self.i18n:getText("rff_tenancy_break_confirm"), tenancy.holdingName or tenancy.agreementId,
            math.max(1, tenancy.breakNoticeMonths or 0)), self.i18n:getText("rff_tenancy_break_title"))
end

function RFF_FinanceFrame:onClickManageTenancyCovenants()
    local tenancy = self:getSelectedTenancyAgreement()
    if tenancy == nil or RFF_TenancyManagementDialog == nil
        or not RFF_TenancyManagementDialog.show(self, tenancy) then
        InfoDialog.show(self.i18n:getText("rff_tenancy_management_unavailable"))
    end
end

function RFF_FinanceFrame:onTenancyActionConfirmed(confirmed)
    local pending = self.pendingTenancyAction
    self.pendingTenancyAction = nil
    if not confirmed or pending == nil or pending.tenancy == nil then return end
    local ok, reason, amount
    if pending.action == "ACCEPT_RENEWAL" then
        ok, reason = self.manager.propertyFinance:acceptTenancyRenewal(pending.tenancy)
    elseif pending.action == "DECLINE_RENEWAL" then
        ok, reason = self.manager.propertyFinance:declineTenancyRenewal(pending.tenancy)
    elseif pending.action == "NEGOTIATE_RENEWAL" then
        ok, reason, amount = self.manager.propertyFinance:negotiateTenancyRenewal(pending.tenancy, pending.amount)
    elseif pending.action == "BREAK" then
        ok, reason = self.manager.propertyFinance:exerciseTenancyBreak(pending.tenancy)
    end
    if ok and pending.action == "NEGOTIATE_RENEWAL" then
        local events = pending.tenancy.narrativeEvents or {}
        local latestEvent = events[#events]
        InfoDialog.show(latestEvent ~= nil and latestEvent.text or string.format(self.i18n:getText("rff_tenancy_negotiation_submitted_result"),
            self:formatMoney(amount or 0), pending.tenancy.renewalLegalReference or "-"))
    elseif ok then
        local events = pending.tenancy.narrativeEvents or {}
        local latestEvent = events[#events]
        local hasNarrativeResult = pending.action == "ACCEPT_RENEWAL" or pending.action == "DECLINE_RENEWAL"
        InfoDialog.show(hasNarrativeResult and latestEvent ~= nil and latestEvent.text or self.i18n:getText("rff_tenancy_action_complete"))
    elseif reason == "funds" and self.manager.propertyFinance:isInitialTenancyApplication(pending.tenancy) then
        local costs = self.manager.propertyFinance:getInitialTenancyCompletionCosts(pending.tenancy)
        InfoDialog.show(string.format(self.i18n:getText("rff_tenancy_signing_insufficient_funds"),
            self:formatMoney(costs ~= nil and costs.total or 0)))
    elseif reason == "unavailable" and self.manager.propertyFinance:isInitialTenancyApplication(pending.tenancy) then
        InfoDialog.show(self.i18n:getText("rff_tenancy_signing_land_unavailable"))
    else
        InfoDialog.show(string.format(self.i18n:getText("rff_tenancy_action_failed"), tostring(reason or "unavailable"):gsub("_", " ")))
    end
    self.selectedTenancyNarrativeIndex = nil
    self:updatePropertyContent()
end

function RFF_FinanceFrame:getNumberOfItemsInSection(list, section)
    if list == self.statementList then
        return #(self.statementTransactions or {})
    elseif list == self.fleetVehicleList then
        return #(self.fleetVehicles or {})
    elseif list == self.tenancyAgreementList then
        return #(self.tenancyAgreements or {})
    end
    return 0
end

function RFF_FinanceFrame:populateCellForItemInSection(list, section, index, cell)
    if cell == nil then return end
    if list == self.fleetVehicleList then
        local row = self.fleetVehicles ~= nil and self.fleetVehicles[index] or nil
        local nameField = cell:getAttribute("fleetRowName")
        local ownershipField = cell:getAttribute("fleetRowOwnership")
        local hoursField = cell:getAttribute("fleetRowHours")
        local inspectionField = cell:getAttribute("fleetRowInspection")
        local inspectionDueField = cell:getAttribute("fleetRowInspectionDue")
        local serviceField = cell:getAttribute("fleetRowService")
        local serviceDueField = cell:getAttribute("fleetRowServiceDue")
        local insuranceField = cell:getAttribute("fleetRowInsurance")
        if row == nil then
            for _, field in ipairs({nameField, ownershipField, hoursField, inspectionField, inspectionDueField, serviceField, serviceDueField, insuranceField}) do
                if field ~= nil then field:setText("") end
            end
            return
        end
        if nameField ~= nil then nameField:setText(row.name or "-") end
        if ownershipField ~= nil then ownershipField:setText(self:getFleetOwnershipText(row.ownership)) end
        if hoursField ~= nil then hoursField:setText(string.format(self.i18n:getText("rff_fleet_hours_format"), row.operatingHours or 0)) end
        if inspectionField ~= nil then inspectionField:setText(self:formatFleetDate(row.lastInspectionDate)) end
        if inspectionDueField ~= nil then
            local dueText = "-"
            if row.adsApplied then
                dueText = row.inspectionDuePeriod ~= nil and self:formatTenancyPeriod(row.inspectionDuePeriod) or self.i18n:getText("rff_due_now")
            end
            inspectionDueField:setText(dueText)
        end
        if serviceField ~= nil then serviceField:setText(self:formatFleetDate(row.lastServiceDate)) end
        if serviceDueField ~= nil then serviceDueField:setText(self:getFleetServiceDueText(row)) end
        if insuranceField ~= nil then insuranceField:setText(self:getFleetInsuranceText(row)) end
        return
    end
    if list == self.tenancyAgreementList then
        local tenancy = self.tenancyAgreements ~= nil and self.tenancyAgreements[index] or nil
        local primary = cell:getAttribute("tenancyRowPrimary")
        local term = cell:getAttribute("tenancyRowTerm")
        local financial = cell:getAttribute("tenancyRowFinancial")
        local covenants = cell:getAttribute("tenancyRowCovenants")
        if tenancy == nil then
            if primary ~= nil then primary:setText("") end
            if term ~= nil then term:setText("") end
            if financial ~= nil then financial:setText("") end
            if covenants ~= nil then covenants:setText("") end
            return
        end
        local farmlandParts = {}
        for _, farmlandId in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do table.insert(farmlandParts, tostring(farmlandId or 0)) end
        local isApplication = self.manager.propertyFinance:isInitialTenancyApplication(tenancy)
        if isApplication then
            local landlordVisible = tenancy.applicationLandlordIntroduced == true
            local landlordBrief = landlordVisible and self.manager.propertyFinance:getTenancyLandlordBrief(tenancy) or nil
            local landlordName = landlordBrief ~= nil and landlordBrief.name or self.i18n:getText("rff_tenancy_landlord_pending")
            local stage = tostring(tenancy.applicationStage or tenancy.status or "APPLICATION"):gsub("_", " ")
            if primary ~= nil then
                primary:setText(string.format("%s | %s | %s", tenancy.applicationReference or tenancy.agreementId or "-",
                    landlordName, stage))
            end
            if term ~= nil then
                term:setText(string.format("%s | Land %s | Preferred term %d months | Submitted Day %d",
                    tostring(tenancy.holdingName or "Agricultural Holding"), table.concat(farmlandParts, ","),
                    tenancy.applicationRequestedTermMonths or tenancy.termMonths or 0, tenancy.applicationSubmittedDay or 0))
            end
            if financial ~= nil then
                if (tenancy.renewalOfferAnnualRent or 0) > 0 then
                    local costs = self.manager.propertyFinance:getInitialTenancyCompletionCosts(tenancy)
                    financial:setText(string.format("Heads: %s/year | Deposit %s | Fees %s | Signing total %s",
                        self:formatMoney(tenancy.renewalOfferAnnualRent or 0), self:formatMoney(costs ~= nil and costs.deposit or 0),
                        self:formatMoney(costs ~= nil and costs.legalFee or 0), self:formatMoney(costs ~= nil and costs.total or 0)))
                elseif (tenancy.applicationCreditScore or 0) > 0 then
                    financial:setText(string.format("Financial assessment: %d / band %s | %s | Deposit condition %d month(s)",
                        tenancy.applicationCreditScore or 0, tenancy.applicationCreditBand or "-",
                        tostring(tenancy.applicationCreditConduct or "pending"):gsub("_", " "), tenancy.applicationDepositMonths or 0))
                else
                    financial:setText(self.i18n:getText("rff_tenancy_application_assessment_pending"))
                end
            end
            if covenants ~= nil then
                if (tenancy.renewalOfferAnnualRent or 0) > 0 then
                    covenants:setText(self.manager.propertyFinance:getTenancyRenewalPackageSummary(
                        self.manager.propertyFinance:getTenancyRenewalTerms(tenancy, "renewalOffer")))
                else
                    covenants:setText(self.i18n:getText("rff_tenancy_application_terms_pending"))
                end
            end
            return
        end
        local frequency = tostring(tenancy.paymentFrequency or "MONTHLY"):gsub("_", " ")
        local covenantParts = {tostring(tenancy.permittedEnterprise or "MIXED")}
        if tenancy.agriculturalUsePermitted ~= false then table.insert(covenantParts, self.i18n:getText("rff_tenancy_cov_agricultural")) end
        if tenancy.permanentGrassRestriction == true then table.insert(covenantParts, self.i18n:getText("rff_tenancy_cov_grass")) end
        if tenancy.boundaryRemovalRequiresConsent ~= false then table.insert(covenantParts, self.i18n:getText("rff_tenancy_cov_boundaries")) end
        if tenancy.improvementsRequireConsent ~= false then table.insert(covenantParts, self.i18n:getText("rff_tenancy_cov_improvements")) end
        if tenancy.tenantMaintenanceObligation ~= false then table.insert(covenantParts, self.i18n:getText("rff_tenancy_cov_maintenance")) end
        if tenancy.rentReviewIntervalMonths ~= nil and tenancy.rentReviewIntervalMonths > 0 then table.insert(covenantParts, string.format("Rent review every %d months", tenancy.rentReviewIntervalMonths)) end
        if tenancy.breakEnabled == true then table.insert(covenantParts, string.format("Break clause: %d months notice", math.max(1, tenancy.breakNoticeMonths or 0))) end
        local landlordBrief = self.manager.propertyFinance:getTenancyLandlordBrief(tenancy)
        local landlordName = landlordBrief ~= nil and landlordBrief.name or self.manager.propertyFinance:getLandlordName(tenancy.landlord, tenancy.farmlandId)
        if primary ~= nil then primary:setText(string.format("%s | %s | %s relationship | %s", tostring(tenancy.agreementId or tenancy.id), landlordName,
            landlordBrief ~= nil and landlordBrief.relationshipText or "Professional", tostring(tenancy.status or "ACTIVE"):gsub("_", " "))) end
        if term ~= nil then term:setText(string.format("%s | Land %s | %s to %s | %d months | %s/year (%s)", tostring(tenancy.holdingName or "Agricultural Holding"), table.concat(farmlandParts, ","), self:formatTenancyPeriod(tenancy.commencementPeriod or tenancy.createdPeriod or 0), self:formatTenancyPeriod(tenancy.contractualEndPeriod or 0), tenancy.remainingMonths or 0, self:formatMoney(tenancy.annualRent or ((tenancy.monthlyRent or 0) * 12)), frequency)) end
        if financial ~= nil then
            if tenancy.settlementCompleted == true then
                if (tenancy.settlementDilapidationCosts or 0) > 0 then
                    financial:setText(string.format("Settlement: deposit applied %s | dilapidations %s | returned %s | balance %s",
                        self:formatMoney(tenancy.settlementDepositApplied or 0),
                        self:formatMoney(tenancy.settlementDilapidationCosts or 0),
                        self:formatMoney(tenancy.settlementDepositReturned or 0),
                        self:formatMoney(tenancy.settlementFinalBalance or 0)))
                else
                    financial:setText(string.format("Settlement: applied %s | returned %s | transferred %s | balance %s", self:formatMoney(tenancy.settlementDepositApplied or 0), self:formatMoney(tenancy.settlementDepositReturned or 0), self:formatMoney(tenancy.settlementDepositTransferred or 0), self:formatMoney(tenancy.settlementFinalBalance or 0)))
                end
            elseif tenancy.handbackStatus ~= nil and tenancy.handbackStatus ~= "NONE" and tenancy.handbackStatus ~= "CANCELLED" then
                local handbackDue = (tenancy.handbackRemedyDeadlinePeriod or 0) > 0
                    and tenancy.handbackRemedyDeadlinePeriod or tenancy.handbackFinalInspectionPeriod
                financial:setText(string.format("Handback %s | %d item(s) | exposure %s | remedy %s",
                    tostring(tenancy.handbackStatus):gsub("_", " "), tenancy.handbackUnresolvedCount or 0,
                    self:formatMoney(tenancy.handbackEstimatedCost or 0),
                    self:formatTenancyPeriod(handbackDue or tenancy.contractualEndPeriod or 0)))
            elseif tenancy.renewalOfferStatus == "OFFERED" then
                local negotiationStatus = tenancy.renewalNegotiationStatus or "NOT_STARTED"
                if negotiationStatus ~= "NOT_STARTED" and negotiationStatus ~= "" then
                    local documentStatus = tenancy.renewalDocumentStatus
                    if documentStatus == nil or documentStatus == "" or documentStatus == "NONE" then documentStatus = negotiationStatus end
                    local documentRent = (negotiationStatus == "LANDLORD_REVIEW" or negotiationStatus == "SOLICITOR_REVIEW")
                        and (tenancy.renewalTenantProposalRent or 0) or (tenancy.renewalOfferAnnualRent or 0)
                    financial:setText(string.format("Documents: %s | %s/year | Ref %s", tostring(documentStatus):gsub("_", " "), self:formatMoney(documentRent), tenancy.renewalLegalReference or "-"))
                else
                    financial:setText(string.format("Renewal: %s/year for %d months | Reply by %s", self:formatMoney(tenancy.renewalOfferAnnualRent or 0), tenancy.renewalOfferTermMonths or 0, self:formatTenancyPeriod(tenancy.renewalOfferExpiryPeriod or 0)))
                end
            else
                financial:setText(string.format("Due %s | Arrears %s | Deposit %s | Missed %d", self:formatMoney(tenancy.rentDue or 0), self:formatMoney(tenancy.arrears or 0), self:formatMoney(tenancy.depositHeld or 0), tenancy.missedPayments or 0))
            end
        end
        if covenants ~= nil then covenants:setText(table.concat(covenantParts, " | ")) end
        return
    end
    if list ~= self.statementList then return end
    local transaction = self.statementTransactions ~= nil and self.statementTransactions[index] or nil
    local dateField = cell:getAttribute("statementRowDate")
    local descField = cell:getAttribute("statementRowDescription")
    local inField = cell:getAttribute("statementRowIn")
    local outField = cell:getAttribute("statementRowOut")
    local balanceField = cell:getAttribute("statementRowBalance")

    if transaction == nil then
        if dateField ~= nil then dateField:setText("") end
        if descField ~= nil then descField:setText("") end
        if inField ~= nil then inField:setText("") end
        if outField ~= nil then outField:setText("") end
        if balanceField ~= nil then balanceField:setText("") end
        return
    end

    if dateField ~= nil then dateField:setText(string.format(self.i18n:getText("rff_statement_day_format"), transaction.day or 1)) end
    if descField ~= nil then descField:setText(truncateStatementText(transaction.description, 66)) end
    if inField ~= nil then inField:setText((transaction.amount or 0) > 0 and self:formatMoney(transaction.amount) or "") end
    if outField ~= nil then outField:setText((transaction.amount or 0) < 0 and self:formatMoney(math.abs(transaction.amount)) or "") end
    if balanceField ~= nil then balanceField:setText(self:formatMoney(transaction.balance or 0)) end
end

function RFF_FinanceFrame:rebuildStatementPeriods(preserveSelection)
    local farmId = self:getCurrentFarmId()
    local repository = self.manager ~= nil and self.manager.repository or nil
    if farmId <= 0 or repository == nil or self.statementPeriodOption == nil then return end

    local previous = preserveSelection and self.statementSelectedPeriod or nil
    self.statementPeriodIndices = repository:getStatementPeriods(farmId)
    if #self.statementPeriodIndices == 0 then table.insert(self.statementPeriodIndices, repository:getCurrentPeriodIndex()) end

    local labels = {}
    local current = repository:getCurrentPeriodIndex()
    local selectedState = 1
    for state, periodIndex in ipairs(self.statementPeriodIndices) do
        local period = repository:getStatementPeriod(farmId, periodIndex)
        local label
        if period ~= nil and period.year ~= nil and period.periodNumber ~= nil then
            local periodNumber = math.max(1, math.min(12, math.floor(tonumber(period.periodNumber) or 1)))
            local monthName = self.i18n:formatPeriod(periodNumber, false)
            label = string.format(self.i18n:getText("rff_statement_month_year_format"), monthName, period.year)
        else
            local offset = math.max(0, current - periodIndex)
            if offset == 0 then label = self.i18n:getText("rff_statement_current_period")
            elseif offset == 1 then label = self.i18n:getText("rff_statement_previous_period")
            else label = string.format(self.i18n:getText("rff_statement_periods_ago"), offset) end
        end
        table.insert(labels, label)
        if previous ~= nil and previous == periodIndex then selectedState = state end
    end
    if self.statementPeriodOption.setTexts ~= nil then self.statementPeriodOption:setTexts(labels) else self.statementPeriodOption.texts = labels end
    setOptionState(self.statementPeriodOption, selectedState)
    self.statementSelectedPeriod = self.statementPeriodIndices[selectedState]
end

function RFF_FinanceFrame:onStatementPeriodChanged(state)
    local selected = state or (self.statementPeriodOption ~= nil and self.statementPeriodOption.state) or 1
    selected = math.max(1, math.min(#(self.statementPeriodIndices or {}), selected))
    self.statementSelectedPeriod = self.statementPeriodIndices[selected]
    self:updateStatementContent(true)
end

function RFF_FinanceFrame:onStatementEntryFilterChanged(state)
    local selected = state or (self.statementEntryFilterOption ~= nil and self.statementEntryFilterOption.state) or 1
    self.statementShowEveryEntry = selected == 2
    self:updateStatementContent(true)
end


function RFF_FinanceFrame:updateStatementContent(keepPeriodOptions)
    if g_currentMission == nil or self.manager == nil or self.manager.repository == nil then return end
    local farmId = self:getCurrentFarmId()
    if farmId <= 0 then return end
    local repository = self.manager.repository
    if not keepPeriodOptions or self.statementSelectedPeriod == nil then self:rebuildStatementPeriods(true) end

    local periodIndex = self.statementSelectedPeriod or repository:getCurrentPeriodIndex()
    local period = repository:getStatementPeriod(farmId, periodIndex) or repository:getPeriod(farmId, periodIndex, true)
    if period == nil then return end
    local transactions = period.transactions or {}
    local currentIndex = repository:getCurrentPeriodIndex()
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil

    local opening = period.openingBalance
    if opening == nil and #transactions > 0 then opening = (transactions[1].balance or 0) - (transactions[1].amount or 0) end
    if opening == nil and periodIndex == currentIndex and farm ~= nil then
        opening = (farm.money or 0) - (period.inflows or 0) + (period.outflows or 0)
    end
    local closing = period.closingBalance
    if periodIndex == currentIndex and farm ~= nil then closing = farm.money or 0 end
    if closing == nil and #transactions > 0 then closing = transactions[#transactions].balance or 0 end

    if self.statementOpeningValue ~= nil then self.statementOpeningValue:setText(opening ~= nil and self:formatMoney(opening) or self.i18n:getText("rff_not_available_short")) end
    if self.statementClosingValue ~= nil then self.statementClosingValue:setText(closing ~= nil and self:formatMoney(closing) or self.i18n:getText("rff_not_available_short")) end
    if self.statementMoneyInValue ~= nil then self.statementMoneyInValue:setText(self:formatMoney(period.inflows or 0)) end
    if self.statementMoneyOutValue ~= nil then self.statementMoneyOutValue:setText(self:formatMoney(period.outflows or 0)) end
    if self.statementNetValue ~= nil then self.statementNetValue:setText(self:formatMoney((period.inflows or 0) - (period.outflows or 0))) end
    if self.statementOperatingIncomeValue ~= nil then self.statementOperatingIncomeValue:setText(self:formatMoney(period.operatingIncome or 0)) end
    local valuation = RFF_FarmValuation:calculate(farmId, repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, repository)
    if self.statementTrailingIncomeValue ~= nil then self.statementTrailingIncomeValue:setText(self:formatMoney(credit.monthlyIncome or 0)) end

    local groupedCount, hiddenCount
    self.statementTransactions, groupedCount, hiddenCount = buildStatementDisplayRows(
        transactions, self.statementShowEveryEntry)

    if self.statementList ~= nil then
        self.statementList:reloadData()
        -- SmoothList uses setSelectedItem(section, index); selecting the first row also
        -- brings the newest transaction back into view after switching statement month.
        if self.statementList.setSelectedItem ~= nil and #self.statementTransactions > 0 then
            pcall(self.statementList.setSelectedItem, self.statementList, 1, 1)
        end
    end

    if self.statementNoteValue ~= nil then
        local note = ""
        if #transactions == 0 and ((period.inflows or 0) > 0.01 or (period.outflows or 0) > 0.01) then
            note = self.i18n:getText("rff_statement_legacy_note")
        elseif #transactions == 0 then
            note = self.i18n:getText("rff_statement_no_transactions")
        elseif period.statementTruncated == true then
            note = self.i18n:getText("rff_statement_truncated")
        elseif hiddenCount > 0 then
            note = string.format(self.i18n:getText("rff_statement_filtered_count"),
                #self.statementTransactions, #transactions, hiddenCount)
        elseif groupedCount < #transactions then
            note = string.format(self.i18n:getText("rff_statement_aggregated_count"),
                #self.statementTransactions, #transactions)
        else
            note = string.format(self.i18n:getText("rff_statement_transaction_count"), #transactions)
        end
        self.statementNoteValue:setText(note)
    end
end

function RFF_FinanceFrame:onRelationshipLenderChanged()
    self:updateRelationshipsContent()
end

function RFF_FinanceFrame:getSelectedRelationshipLender()
    local lenders = self.relationshipLenders or {}
    if #lenders == 0 and self.manager ~= nil and self.manager.relationshipService ~= nil then
        lenders = self.manager.relationshipService:getLenders() or {}
        self.relationshipLenders = lenders
    end
    if #lenders == 0 then return nil end
    local state = self.relationshipLenderOption ~= nil and (self.relationshipLenderOption.state or 1) or 1
    state = math.max(1, math.min(#lenders, state))
    return lenders[state]
end

function RFF_FinanceFrame:formatRelationshipRate(value)
    value = value or 0
    if math.abs(value) < 0.001 then return self.i18n:getText("rff_relationship_no_adjustment") end
    return string.format("%+.2f%%", value)
end

function RFF_FinanceFrame:formatRelationshipFactor(factor, reductionKey, increaseKey)
    factor = factor or 1
    local delta = math.abs(1 - factor) * 100
    if delta < 0.1 then return self.i18n:getText("rff_relationship_no_adjustment") end
    if factor < 1 then return string.format(self.i18n:getText(reductionKey), delta) end
    return string.format(self.i18n:getText(increaseKey), delta)
end

function RFF_FinanceFrame:getDealFitText(code)
    local service = self.manager ~= nil and self.manager.lenderMarketService or nil
    local entry = service ~= nil and service.DEAL_FIT ~= nil and service.DEAL_FIT[code or "STANDARD"] or nil
    return entry ~= nil and self.i18n:getText(entry.key) or self.i18n:getText("rff_market_fit_standard")
end

function RFF_FinanceFrame:updateRelationshipsContent()
    if self.manager == nil or self.manager.relationshipService == nil then return end
    local farmId = self:getCurrentFarmId()
    local service = self.manager.relationshipService
    local brokerService = self.manager.brokerService

    local brokerRel = brokerService ~= nil and brokerService:getBrokerRelationship(farmId, false) or nil
    brokerRel = brokerRel or {relationshipPoints=0, casesInstructed=0, acceptedDeals=0, successfulIntroductions=0, feesPaid=0}
    local brokerCode, brokerKey = "NEW", "rff_relationship_new"
    if brokerService ~= nil then brokerCode, brokerKey = brokerService:getRelationshipTier(brokerRel.relationshipPoints or 0) end
    local brokerBenefits = brokerService ~= nil and brokerService:getBrokerBenefits(farmId) or {timingFactor=1, feeFactor=1}
    if self.relationshipBrokerStatusValue ~= nil then self.relationshipBrokerStatusValue:setText(self.i18n:getText(brokerKey)) end
    if self.relationshipBrokerScoreValue ~= nil then self.relationshipBrokerScoreValue:setText(string.format("%.1f", brokerRel.relationshipPoints or 0)) end
    if self.relationshipBrokerCasesValue ~= nil then self.relationshipBrokerCasesValue:setText(tostring(brokerRel.casesInstructed or 0)) end
    if self.relationshipBrokerDealsValue ~= nil then self.relationshipBrokerDealsValue:setText(tostring(brokerRel.acceptedDeals or 0)) end
    if self.relationshipBrokerIntroductionsValue ~= nil then self.relationshipBrokerIntroductionsValue:setText(tostring(brokerRel.successfulIntroductions or 0)) end
    if self.relationshipBrokerFeesValue ~= nil then self.relationshipBrokerFeesValue:setText(self:formatMoney(brokerRel.feesPaid or 0)) end
    if self.relationshipBrokerFeeBenefitValue ~= nil then self.relationshipBrokerFeeBenefitValue:setText(self:formatRelationshipFactor(brokerBenefits.feeFactor, "rff_relationship_percent_reduction", "rff_relationship_percent_increase")) end
    if self.relationshipBrokerSpeedValue ~= nil then self.relationshipBrokerSpeedValue:setText(self:formatRelationshipFactor(brokerBenefits.timingFactor, "rff_relationship_percent_faster", "rff_relationship_percent_slower")) end
    if self.relationshipBrokerNote ~= nil then self.relationshipBrokerNote:setText(wrapText(self.i18n:getText("rff_broker_relationship_note"), 72)) end

    local lender = self:getSelectedRelationshipLender()
    if lender == nil then return end
    local rel, benefits = service:getSummary(farmId, lender.id)
    if self.relationshipLenderStyleValue ~= nil then self.relationshipLenderStyleValue:setText(self.i18n:getText(lender.styleKey)) end
    if self.relationshipLenderStatusValue ~= nil then self.relationshipLenderStatusValue:setText(self.i18n:getText(benefits.key)) end
    if self.relationshipLenderScoreValue ~= nil then self.relationshipLenderScoreValue:setText(string.format("%.1f", rel.relationshipPoints or 0)) end
    if self.relationshipApplicationsValue ~= nil then self.relationshipApplicationsValue:setText(tostring(rel.applications or 0)) end
    if self.relationshipDealsValue ~= nil then self.relationshipDealsValue:setText(tostring(rel.acceptedDeals or 0)) end
    if self.relationshipVolumeValue ~= nil then self.relationshipVolumeValue:setText(self:formatMoney(rel.totalVolume or 0)) end
    if self.relationshipSuccessfulPaymentsValue ~= nil then self.relationshipSuccessfulPaymentsValue:setText(tostring(rel.successfulPayments or 0)) end
    if self.relationshipMissedPaymentsValue ~= nil then self.relationshipMissedPaymentsValue:setText(tostring(rel.missedPayments or 0)) end
    if self.relationshipCompletedValue ~= nil then self.relationshipCompletedValue:setText(tostring(rel.completedAgreements or 0)) end
    if self.relationshipRecoveriesValue ~= nil then self.relationshipRecoveriesValue:setText(tostring((rel.forcedRecoveries or 0) + (rel.voluntarySurrenders or 0))) end
    if self.relationshipPossessionsValue ~= nil then self.relationshipPossessionsValue:setText(tostring((rel.mortgagePossessions or 0) + (rel.voluntaryPropertySales or 0))) end
    if self.relationshipRateBenefitValue ~= nil then self.relationshipRateBenefitValue:setText(self:formatRelationshipRate(benefits.rateAdjustment or 0)) end
    if self.relationshipFeeBenefitValue ~= nil then
        if lender.id == "PRIMARY_BANK" then
            self.relationshipFeeBenefitValue:setText(self.i18n:getText("rff_relationship_no_direct_fee"))
        else
            self.relationshipFeeBenefitValue:setText(self:formatRelationshipFactor(benefits.arrangementFeeFactor, "rff_relationship_percent_reduction", "rff_relationship_percent_increase"))
        end
    end
    if self.relationshipSpeedBenefitValue ~= nil then self.relationshipSpeedBenefitValue:setText(self:formatRelationshipFactor(benefits.timingFactor, "rff_relationship_percent_faster", "rff_relationship_percent_slower")) end
    if self.relationshipLtvBenefitValue ~= nil then
        local bonus = (benefits.ltvBonus or 0) * 100
        if math.abs(bonus) < 0.01 then self.relationshipLtvBenefitValue:setText(self.i18n:getText("rff_relationship_no_adjustment"))
        else self.relationshipLtvBenefitValue:setText(string.format("%+.1f pp", bonus)) end
    end
end

function RFF_FinanceFrame:onMarketLenderChanged()
    self:updateMarketContent()
end

function RFF_FinanceFrame:getSelectedMarketLender()
    local lenders = self.marketLenders or {}
    if #lenders == 0 and self.manager ~= nil and self.manager.lenderMarketService ~= nil then
        lenders = self.manager.lenderMarketService:getProfiles() or {}
        self.marketLenders = lenders
    end
    if #lenders == 0 then return nil end
    local state = self.marketLenderOption ~= nil and (self.marketLenderOption.state or 1) or 1
    return lenders[math.max(1, math.min(#lenders, state))]
end

function RFF_FinanceFrame:getMarketOfferStatusText(status)
    if status == RFF_LenderMarketService.STATUS_OFFERED then return self.i18n:getText("rff_market_offer_open") end
    if status == RFF_LenderMarketService.STATUS_ACCEPTED then return self.i18n:getText("rff_market_offer_accepted") end
    if status == RFF_LenderMarketService.STATUS_DECLINED then return self.i18n:getText("rff_market_offer_declined") end
    if status == RFF_LenderMarketService.STATUS_EXPIRED then return self.i18n:getText("rff_market_offer_expired") end
    return self.i18n:getText("rff_none")
end

function RFF_FinanceFrame:updateMarketContent()
    if self.manager == nil or self.manager.lenderMarketService == nil or self.manager.relationshipService == nil then return end
    local farmId = self:getCurrentFarmId()
    local service = self.manager.lenderMarketService
    local lender = self:getSelectedMarketLender()
    if lender ~= nil then
        local market = service:getMarketAdjustment(lender.id)
        local rel, benefits = self.manager.relationshipService:getSummary(farmId, lender.id)
        if self.marketLenderStyleValue ~= nil then self.marketLenderStyleValue:setText(self.i18n:getText(lender.styleKey)) end
        if self.marketAppetiteValue ~= nil then self.marketAppetiteValue:setText(self.i18n:getText(market.key)) end
        if self.marketRelationshipValue ~= nil then self.marketRelationshipValue:setText(self.i18n:getText(benefits.key)) end
        if self.marketSpecialismValue ~= nil then self.marketSpecialismValue:setText(wrapText(self.i18n:getText(lender.specialismKey), 34)) end
        if self.marketFocusValue ~= nil then
            local focusParts = {}
            for _, item in ipairs(service:getFocusSummary(lender.id) or {}) do
                table.insert(focusParts, string.format("%s: %s", self.i18n:getText(item.key), self:getDealFitText(item.fit)))
            end
            self.marketFocusValue:setText(wrapText(table.concat(focusParts, "  |  "), 42))
        end
        if self.marketPricingValue ~= nil then self.marketPricingValue:setText(self:formatRelationshipRate(market.rateAdjustment or 0)) end
        if self.marketOfferHistoryValue ~= nil then
            self.marketOfferHistoryValue:setText(string.format(self.i18n:getText("rff_market_offer_history_format"), rel.proactiveOffersMade or 0, rel.proactiveOffersAccepted or 0, rel.proactiveOffersDeclined or 0))
        end
    end

    local offer = service:getActiveOffer(farmId) or service:getLatestOffer(farmId)
    self.marketOffer = offer
    if offer == nil then
        for _, name in ipairs({"marketOfferStatusValue","marketOfferLenderValue","marketOfferAmountValue","marketOfferTermValue","marketOfferRateValue","marketOfferPaymentValue","marketOfferFeeValue","marketOfferExpiryValue","marketOfferTierValue"}) do
            if self[name] ~= nil then self[name]:setText("-") end
        end
        if self.marketOfferNote ~= nil then self.marketOfferNote:setText(self.i18n:getText("rff_market_no_offer_note")) end
        if self.acceptPreApprovedButton ~= nil then self.acceptPreApprovedButton:setVisible(false) end
        if self.declinePreApprovedButton ~= nil then self.declinePreApprovedButton:setVisible(false) end
        return
    end

    local profile = service:getProfile(offer.lenderId)
    if self.marketOfferStatusValue ~= nil then self.marketOfferStatusValue:setText(self:getMarketOfferStatusText(offer.status)) end
    if self.marketOfferLenderValue ~= nil then self.marketOfferLenderValue:setText(self.i18n:getText(offer.lenderNameKey or profile.nameKey)) end
    if self.marketOfferAmountValue ~= nil then self.marketOfferAmountValue:setText(self:formatMoney(offer.amount or 0)) end
    if self.marketOfferTermValue ~= nil then self.marketOfferTermValue:setText(self:formatTerm(offer.months or 0)) end
    if self.marketOfferRateValue ~= nil then self.marketOfferRateValue:setText(string.format("%.2f%%", offer.interestRate or 0)) end
    if self.marketOfferPaymentValue ~= nil then self.marketOfferPaymentValue:setText(self:formatMoney(offer.monthlyPayment or 0)) end
    if self.marketOfferFeeValue ~= nil then self.marketOfferFeeValue:setText(self:formatMoney(offer.arrangementFee or 0)) end
    if self.marketOfferTierValue ~= nil then
        local key = (self.manager.relationshipService.TIERS[offer.relationshipTier or "NEW"] or {}).key or "rff_relationship_new"
        self.marketOfferTierValue:setText(self.i18n:getText(key))
    end
    if self.marketOfferExpiryValue ~= nil then
        if offer.status == service.STATUS_OFFERED then
            local remaining = math.max(0, (offer.expiryPeriod or 0) - service:getCurrentPeriod())
            self.marketOfferExpiryValue:setText(string.format(self.i18n:getText("rff_market_expiry_periods"), remaining))
        else
            self.marketOfferExpiryValue:setText("-")
        end
    end
    if self.marketOfferNote ~= nil then
        self.marketOfferNote:setText(offer.status == service.STATUS_OFFERED and self.i18n:getText("rff_market_offer_note") or self.i18n:getText("rff_market_historic_offer_note"))
    end
    local open = offer.status == service.STATUS_OFFERED
    if self.acceptPreApprovedButton ~= nil then self.acceptPreApprovedButton:setVisible(open) end
    if self.declinePreApprovedButton ~= nil then self.declinePreApprovedButton:setVisible(open) end
end

function RFF_FinanceFrame:onClickAcceptPreApprovedOffer()
    local offer = self.marketOffer
    if offer == nil or self.manager == nil or self.manager.lenderMarketService == nil then return end
    self.pendingPreApprovedOffer = offer
    local lenderName = self.i18n:getText(offer.lenderNameKey or "rff_lender_primary_bank")
    local text = string.format(self.i18n:getText("rff_market_accept_confirm"), lenderName, self:formatMoney(offer.amount or 0), offer.interestRate or 0, self:formatTerm(offer.months or 0), self:formatMoney(offer.monthlyPayment or 0), self:formatMoney(offer.arrangementFee or 0))
    YesNoDialog.show(self.onAcceptPreApprovedConfirmed, self, text, self.i18n:getText("rff_market_preapproved_offer"))
end

function RFF_FinanceFrame:onAcceptPreApprovedConfirmed(confirmed)
    local offer = self.pendingPreApprovedOffer
    self.pendingPreApprovedOffer = nil
    if not confirmed or offer == nil then return end
    local loan, reason = self.manager.lenderMarketService:acceptOffer(offer)
    if loan == nil then
        if reason == "expired" then InfoDialog.show(self.i18n:getText("rff_offer_expired_message"))
        elseif reason == "payment_conduct" then InfoDialog.show(self.i18n:getText("rff_clear_arrears_first"))
        else InfoDialog.show(self.i18n:getText("rff_market_accept_failed")) end
        self:updateMarketContent()
        return
    end
    InfoDialog.show(string.format(self.i18n:getText("rff_market_accept_complete"), self:formatMoney(offer.amount or 0)))
    self:updateContent()
    self:updateMarketContent()
end

function RFF_FinanceFrame:onClickDeclinePreApprovedOffer()
    local offer = self.marketOffer
    if offer == nil then return end
    self.pendingPreApprovedDecline = offer
    YesNoDialog.show(self.onDeclinePreApprovedConfirmed, self, self.i18n:getText("rff_market_decline_confirm"), self.i18n:getText("rff_market_preapproved_offer"))
end

function RFF_FinanceFrame:onDeclinePreApprovedConfirmed(confirmed)
    local offer = self.pendingPreApprovedDecline
    self.pendingPreApprovedDecline = nil
    if confirmed and offer ~= nil then
        local ok = self.manager.lenderMarketService:declineOffer(offer)
        if ok then InfoDialog.show(self.i18n:getText("rff_market_decline_complete")) end
        self:updateMarketContent()
    end
end

function RFF_FinanceFrame:getInsuranceClaimStatusText(status)
    local keys = {
        AWAITING_SUBMISSION = "rff_claim_status_awaiting_submission",
        UNDER_REVIEW = "rff_claim_status_under_review",
        APPROVED = "rff_claim_status_approved",
        DECLINED = "rff_claim_status_declined",
        PAID = "rff_claim_status_paid",
        AWAITING_RESPONSE = "rff_claim_status_awaiting_response",
        AWAITING_ADS_INSPECTION = "rff_claim_status_awaiting_ads_inspection",
        AWAITING_OEM_REPAIR = "rff_claim_status_awaiting_oem_repair",
        DEFAULTED = "rff_claim_status_defaulted",
        SETTLED = "rff_claim_status_settled"
    }
    return self.i18n:getText(keys[status] or "rff_claim_status_unknown")
end

function RFF_FinanceFrame:getInsuranceLossStatusText(loss)
    if loss == nil then return self.i18n:getText("rff_claim_status_unknown") end
    if loss.status == RFF_InsuranceClaimService.LOSS_EXPIRED then
        return self.i18n:getText("rff_loss_status_expired")
    end
    if loss.status == RFF_InsuranceClaimService.LOSS_CLAIMED then
        return self.i18n:getText("rff_loss_status_claimed")
    end
    local months = self.manager.insuranceClaims:getLossMonthsRemaining(loss)
    if months <= 0 then return self.i18n:getText("rff_loss_status_expired") end
    return string.format(self.i18n:getText("rff_loss_status_claimable"), months)
end

function RFF_FinanceFrame:getInsuranceClaimCauseText(reason)
    local keys = {
        ACCIDENT = "rff_claim_cause_accident",
        HEALTH = "rff_claim_cause_health",
        OLD_AGE = "rff_claim_cause_old_age",
        VETERINARY = "rff_claim_cause_veterinary",
        VEHICLE_INCIDENT = "rff_claim_cause_vehicle_incident",
        UNKNOWN = "rff_claim_cause_unknown"
    }
    return self.i18n:getText(keys[reason] or "rff_claim_cause_unknown")
end

function RFF_FinanceFrame:getInsuranceLicenceSnapshotText(record)
    if record == nil or (record.licenceSnapshotVersion or 0) < 1 then return "" end
    if record.licenceRulesApplied ~= true then
        return self.i18n:getText("rff_claim_licence_private")
    end
    local category = tostring(record.licenceRequiredCategory or "")
    if category == "" then category = "-" end
    local entitlement = self.i18n:getText(record.licenceEntitlementHeld == true
        and "rff_compliance_held" or "rff_compliance_not_held")
    local adrText = ""
    if record.licenceAdrRequired == true then
        local loadName = tostring(record.licenceHazardousLoadName or "")
        if loadName == "" then loadName = self.i18n:getText("rff_claim_hazardous_load") end
        adrText = string.format(self.i18n:getText(record.licenceAdrHeld == true
            and "rff_claim_licence_adr_held" or "rff_claim_licence_adr_missing"),
            loadName)
    end
    if record.licenceCategoryBreach == true or record.licenceAdrBreach == true then
        return string.format(self.i18n:getText("rff_claim_licence_breach"), category, entitlement, adrText)
    end
    return string.format(self.i18n:getText("rff_claim_licence_compliant"), category, adrText)
end

function RFF_FinanceFrame:getInsuranceClaimOutcomeText(claim)
    if claim == nil then return self.i18n:getText("rff_claim_none_note") end
    local incidentText = ""
    if claim.claimType == "VEHICLE" and claim.source == "TRAFFIC_COURTESY" then
        local speedKph = (claim.incidentClosingSpeedMps or 0) * 3.6
        local speedText = string.format("%.0f %s", self.i18n:getSpeed(speedKph), self.i18n:getSpeedMeasuringUnit())
        incidentText = string.format(self.i18n:getText("rff_traffic_claim_detail"), claim.externalIncidentId or "Traffic Courtesy",
            self:getTrafficIncidentSeverityText(claim.incidentSeverity), speedText,
            claim.incidentPartName ~= "" and claim.incidentPartName or claim.vehicleName or "Vehicle",
            claim.incidentTargetName ~= "" and claim.incidentTargetName or self.i18n:getText("rff_traffic_target_other"),
            (claim.incidentImpactZone ~= "" and claim.incidentImpactZone or "UNKNOWN"):gsub("_", " "),
            (claim.incidentTargetImpactZone ~= "" and claim.incidentTargetImpactZone or "UNKNOWN"):gsub("_", " "))
    end
    local licenceText = claim.claimType == "VEHICLE" and self:getInsuranceLicenceSnapshotText(claim) or ""
    local function withIncident(text)
        local sections = {}
        if incidentText ~= "" then sections[#sections + 1] = incidentText end
        if licenceText ~= "" then sections[#sections + 1] = licenceText end
        if text ~= "" then sections[#sections + 1] = text end
        return table.concat(sections, "\n")
    end
    if self.manager ~= nil and self.manager.insuranceClaims ~= nil
            and self.manager.insuranceClaims:isTrafficWorkflowClaim(claim) then
        if claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_RESPONSE then
            return withIncident(string.format(self.i18n:getText("rff_traffic_claim_awaiting_response_note"),
                self.manager.insuranceClaims:getTrafficClaimResponseDaysRemaining(claim),
                self:formatMoney(claim.thirdPartyLiability or 0), self:formatMoney(claim.legalCosts or 0)))
        elseif claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_ADS_INSPECTION then
            return withIncident(self.i18n:getText("rff_traffic_claim_ads_inspection_note"))
        elseif claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_OEM_REPAIR then
            return withIncident(string.format(self.i18n:getText("rff_traffic_claim_oem_repair_note"),
                claim.adsInspectionIssueCount or 0, self:formatMoney(claim.adsInspectionCost or 0)))
        elseif claim.status == RFF_InsuranceClaimService.STATUS_DEFAULTED then
            return withIncident(string.format(self.i18n:getText("rff_traffic_claim_defaulted_note"),
                self:formatMoney(claim.defaultCharge or 0)))
        elseif claim.status == RFF_InsuranceClaimService.STATUS_SETTLED then
            local warrantyText = claim.adsWarrantyRepair == true and self.i18n:getText("rff_traffic_claim_warranty_suffix") or ""
            if (claim.liabilityInsurerRecovery or 0) > 0 then
                return withIncident(string.format(self.i18n:getText("rff_traffic_claim_settled_recovery_note"),
                    self:formatMoney(claim.liabilityInsurerPaid or 0), self:formatMoney(claim.liabilityPolicyShortfall or 0),
                    self:formatMoney(claim.liabilityInsurerRecovery or 0), self:formatMoney(claim.liabilityFarmCharge or 0),
                    self:formatMoney(claim.ownPaidAmount or 0), self:formatMoney(claim.actualOwnDamageCost or 0), warrantyText))
            end
            return withIncident(string.format(self.i18n:getText("rff_traffic_claim_settled_note"),
                self:formatMoney(claim.liabilityInsurerPaid or 0), self:formatMoney(claim.liabilityFarmCharge or 0),
                self:formatMoney(claim.ownPaidAmount or 0), self:formatMoney(claim.actualOwnDamageCost or 0), warrantyText))
        end
    end
    if claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_SUBMISSION then
        return withIncident(self.i18n:getText("rff_claim_awaiting_note"))
    elseif claim.status == RFF_InsuranceClaimService.STATUS_UNDER_REVIEW then
        if claim.claimType == "VEHICLE" and claim.coverageSummary ~= nil and claim.coverageSummary ~= "" then
            return withIncident(string.format(self.i18n:getText("rff_vehicle_claim_review_note"), claim.coverageSummary))
        end
        return withIncident(self.i18n:getText("rff_claim_review_note"))
    elseif claim.status == RFF_InsuranceClaimService.STATUS_APPROVED then
        local text = string.format(self.i18n:getText("rff_claim_approved_note"), self:formatMoney(claim.approvedAmount or 0))
        if claim.claimType == "VEHICLE" and claim.coverageSummary ~= nil and claim.coverageSummary ~= "" then text = text .. " " .. claim.coverageSummary end
        return withIncident(text)
    elseif claim.status == RFF_InsuranceClaimService.STATUS_PAID then
        local text = string.format(self.i18n:getText("rff_claim_paid_note"), self:formatMoney(claim.paidAmount or 0))
        if claim.claimType == "VEHICLE" and claim.coverageSummary ~= nil and claim.coverageSummary ~= "" then text = text .. " " .. claim.coverageSummary end
        return withIncident(text)
    elseif claim.status == RFF_InsuranceClaimService.STATUS_DECLINED then
        local reason = self.manager ~= nil and self.manager.insuranceClaims ~= nil and self.manager.insuranceClaims:getOutcomeText(claim.outcomeReason) or tostring(claim.outcomeReason or "")
        return withIncident(string.format(self.i18n:getText("rff_claim_declined_note"), reason))
    end
    return withIncident(self.i18n:getText("rff_claim_none_note"))
end

function RFF_FinanceFrame:getInsuranceLossNote(loss)
    if loss == nil then return self.i18n:getText("rff_claim_none_note") end
    if loss.status == RFF_InsuranceClaimService.LOSS_EXPIRED or self.manager.insuranceClaims:isLossExpired(loss) then
        return self.i18n:getText("rff_loss_expired_note")
    end
    if loss.status == RFF_InsuranceClaimService.LOSS_CLAIMED then
        return self.i18n:getText("rff_loss_claimed_note")
    end
    local months = self.manager.insuranceClaims:getLossMonthsRemaining(loss)
    return string.format(self.i18n:getText("rff_loss_claimable_note"), months)
end

function RFF_FinanceFrame:getInsuranceEntryKey(entry)
    if entry == nil or entry.data == nil then return nil end
    if entry.kind == "TRAFFIC_INCIDENT" then return "TRAFFIC:" .. tostring(entry.data.id or 0) end
    return "CLAIM:" .. tostring(entry.data.id or 0)
end

function RFF_FinanceFrame:getTrafficIncidentStatusText(incident)
    if incident == nil then return self.i18n:getText("rff_claim_status_unknown") end
    if incident.status == RFF_InsuranceClaimService.TRAFFIC_INCIDENT_EXPIRED
        or self.manager.insuranceClaims:isTrafficCourtesyIncidentExpired(incident) then
        return self.i18n:getText("rff_traffic_incident_status_expired")
    end
    if incident.status == RFF_InsuranceClaimService.TRAFFIC_INCIDENT_CLAIMED then
        return self.i18n:getText("rff_traffic_incident_status_claimed")
    end
    return string.format(self.i18n:getText("rff_traffic_incident_status_recorded"),
        self.manager.insuranceClaims:getTrafficCourtesyIncidentMonthsRemaining(incident))
end

function RFF_FinanceFrame:getTrafficIncidentSeverityText(severity)
    local key = {
        MINOR="rff_traffic_severity_minor", MODERATE="rff_traffic_severity_moderate",
        SERIOUS="rff_traffic_severity_serious", SEVERE="rff_traffic_severity_severe",
        UNKNOWN="rff_traffic_severity_unknown"
    }
    return self.i18n:getText(key[tostring(severity or "UNKNOWN")] or key.UNKNOWN)
end

function RFF_FinanceFrame:getTrafficIncidentTargetTypeText(targetType)
    local key = {
        AI_VEHICLE="rff_traffic_target_ai_vehicle", VEHICLE="rff_traffic_target_vehicle",
        PEDESTRIAN="rff_traffic_target_pedestrian", BUILDING="rff_traffic_target_building",
        FENCE="rff_traffic_target_fence", GATE="rff_traffic_target_gate", WALL="rff_traffic_target_wall",
        TREE="rff_traffic_target_tree", STREET_FURNITURE="rff_traffic_target_street_furniture",
        OTHER_STATIC="rff_traffic_target_other", UNKNOWN="rff_traffic_target_other"
    }
    return self.i18n:getText(key[tostring(targetType or "UNKNOWN")] or key.UNKNOWN)
end

function RFF_FinanceFrame:getTrafficIncidentNote(incident)
    if incident == nil then return self.i18n:getText("rff_traffic_incident_none") end
    local impactZone = tostring(incident.impactZone or "UNKNOWN"):gsub("_", " ")
    local targetZone = tostring(incident.targetImpactZone or "UNKNOWN"):gsub("_", " ")
    local faultKeys = {
        UNKNOWN="rff_traffic_fault_unknown", PRESUMED_PLAYER="rff_traffic_fault_presumed_player",
        OWN_PROPERTY="rff_traffic_fault_own_property"
    }
    local fault = self.i18n:getText(faultKeys[tostring(incident.faultAssessment or "UNKNOWN")] or "rff_traffic_fault_unknown")
    local ads = incident.adsSourceSystems ~= nil and incident.adsSourceSystems ~= "" and incident.adsSourceSystems or self.i18n:getText("rff_traffic_ads_none")
    if incident.adsSourceBreakdowns ~= nil and incident.adsSourceBreakdowns ~= "" then ads = ads .. "; " .. incident.adsSourceBreakdowns end
    if #ads > 82 then ads = ads:sub(1, 79) .. "..." end
    local speedKph = (incident.closingSpeedMps or 0) * 3.6
    local speedText = string.format("%.0f %s", self.i18n:getSpeed(speedKph), self.i18n:getSpeedMeasuringUnit())
    local detail = string.format(self.i18n:getText("rff_traffic_incident_detail"),
        incident.externalIncidentId or "Traffic Courtesy", self:getTrafficIncidentSeverityText(incident.severityClass),
        speedText, incident.partName or incident.vehicleName or "Vehicle",
        incident.targetName or "Unknown object", self:getVehicleUseLocationText(incident.locationType),
        self.i18n:formatMass((incident.combinationMassKg or 0) / 1000), fault, impactZone, targetZone,
        self:formatMoney(incident.ownDamageEstimate or 0), self:formatMoney(incident.thirdPartyEstimate or 0),
        self:formatMoney(incident.legalCostEstimate or 0), ads)
    if (incident.groupedIncidentCount or 1) > 1 then
        detail = detail .. "\n" .. string.format(self.i18n:getText("rff_traffic_incident_grouped_note"), incident.groupedIncidentCount)
    end
    local licenceText = self:getInsuranceLicenceSnapshotText(incident)
    if licenceText ~= "" then detail = detail .. "\n" .. licenceText end
    return detail
end

function RFF_FinanceFrame:rebuildInsuranceClaimSelector(preserveKey)
    if self.insuranceClaimOption == nil or self.manager == nil or self.manager.repository == nil then return end
    local farmId = self:getCurrentFarmId()
    self.insuranceEntries = {}

    -- Only actual claims belong in claim history. Recorded livestock deaths remain
    -- internal claim candidates until the player deliberately starts a new claim.
    self.insuranceClaims = self.manager.repository:getInsuranceClaimsByFarm(farmId) or {}
    for _, claim in ipairs(self.insuranceClaims) do
        table.insert(self.insuranceEntries, {kind = "CLAIM", data = claim, sortDay = claim.incidentDay or claim.submittedDay or 0, sortId = claim.id or 0})
    end
    self.insuranceTrafficIncidents = self.manager.repository.getTrafficCourtesyIncidentsByFarm ~= nil
        and self.manager.repository:getTrafficCourtesyIncidentsByFarm(farmId) or {}
    for _, incident in ipairs(self.insuranceTrafficIncidents) do
        if incident.status ~= RFF_InsuranceClaimService.TRAFFIC_INCIDENT_CLAIMED then
            table.insert(self.insuranceEntries, {kind = "TRAFFIC_INCIDENT", data = incident, sortDay = incident.incidentDay or 0, sortId = 1000000 + (incident.id or 0)})
        end
    end

    table.sort(self.insuranceEntries, function(a, b)
        if (a.sortDay or 0) == (b.sortDay or 0) then return (a.sortId or 0) > (b.sortId or 0) end
        return (a.sortDay or 0) > (b.sortDay or 0)
    end)

    local texts = {}
    local selected = 1
    for index, entry in ipairs(self.insuranceEntries) do
        if entry.kind == "TRAFFIC_INCIDENT" then
            local incident = entry.data
            local reference = self.manager.insuranceClaims:getTrafficCourtesyIncidentReference(incident)
            local status = self:getTrafficIncidentStatusText(incident)
            table.insert(texts, string.format("%s  -  %s  -  %s", reference, incident.vehicleName or self.i18n:getText("rff_fleet_vehicle"), status))
        else
            local claim = entry.data
            local reference = self.manager.insuranceClaims:getClaimReference(claim)
            local status = self:getInsuranceClaimStatusText(claim.status)
            local animal
            if claim.claimType == "VETERINARY" then
                animal = self.i18n:getText("rff_vet_claim_history_label")
            elseif claim.claimType == "VEHICLE" then
                animal = claim.vehicleName ~= nil and claim.vehicleName ~= "" and claim.vehicleName or self.i18n:getText("rff_vehicle_claim_history_label")
            else
                animal = claim.animalName ~= nil and claim.animalName ~= "" and claim.animalName or (claim.animalBreed ~= nil and claim.animalBreed ~= "" and claim.animalBreed or claim.animalType or "Livestock")
            end
            table.insert(texts, string.format("%s  -  %s  -  %s", reference, animal, status))
        end
        local key = self:getInsuranceEntryKey(entry)
        if preserveKey ~= nil and key == preserveKey then selected = index end
    end

    if #texts == 0 then texts = {self.i18n:getText("rff_claim_none")} end
    if self.insuranceClaimOption.setTexts ~= nil then self.insuranceClaimOption:setTexts(texts) else self.insuranceClaimOption.texts = texts end
    setOptionState(self.insuranceClaimOption, selected)
end

function RFF_FinanceFrame:getSelectedInsuranceEntry()
    if self.insuranceEntries == nil or #self.insuranceEntries == 0 then return nil end
    local index = math.max(1, math.min(#self.insuranceEntries, self.insuranceClaimOption ~= nil and (self.insuranceClaimOption.state or 1) or 1))
    return self.insuranceEntries[index]
end

function RFF_FinanceFrame:getSelectedInsuranceClaim()
    local entry = self:getSelectedInsuranceEntry()
    return entry ~= nil and entry.kind == "CLAIM" and entry.data or nil
end

function RFF_FinanceFrame:onInsuranceClaimChanged()
    self:updateInsuranceClaimsContent(false)
end

function RFF_FinanceFrame:updateInsuranceClaimsContent(rebuild)
    if self.manager == nil or self.manager.repository == nil or self.manager.insuranceClaims == nil then return end
    local current = self:getSelectedInsuranceEntry()
    local preserveKey = current ~= nil and self:getInsuranceEntryKey(current) or self.selectedInsuranceEntryKey
    if rebuild or self.insuranceEntries == nil then self:rebuildInsuranceClaimSelector(preserveKey) end

    local entry = self:getSelectedInsuranceEntry()
    self.selectedInsuranceEntryKey = self:getInsuranceEntryKey(entry)
    local trafficContribution = entry ~= nil and (entry.kind == "TRAFFIC_INCIDENT"
        or (entry.kind == "CLAIM" and self.manager.insuranceClaims:isTrafficWorkflowClaim(entry.data)))
    local licenceRecovery = entry ~= nil and entry.kind == "CLAIM"
        and (entry.data.liabilityInsurerRecovery or 0) > 0
    if self.insuranceClaimSettlementLabel ~= nil then
        self.insuranceClaimSettlementLabel:setText(self.i18n:getText(licenceRecovery
            and "rff_claim_insurer_payment_recovery"
            or (trafficContribution and "rff_claim_insurer_contribution" or "rff_claim_settlement")))
    end
    local fields = {"insuranceClaimStatusValue", "insuranceClaimAnimalValue", "insuranceClaimCauseValue", "insuranceClaimValueValue", "insuranceClaimCoverValue", "insuranceClaimExcessValue", "insuranceClaimSettlementValue"}
    if entry == nil then
        for _, name in ipairs(fields) do if self[name] ~= nil then self[name]:setText("-") end end
        if self.insuranceClaimNote ~= nil then self.insuranceClaimNote:setText(wrapText(self.i18n:getText("rff_claim_none_note"), 62)) end
    elseif entry.kind == "TRAFFIC_INCIDENT" then
        local incident = entry.data
        local vehicleText = incident.vehicleName or self.i18n:getText("rff_fleet_vehicle")
        if incident.partName ~= nil and incident.partName ~= "" and incident.partName ~= vehicleText then
            vehicleText = string.format("%s (%s)", vehicleText, incident.partName)
        end
        local coverText = incident.policyCoverType == "THIRD_PARTY" and self.i18n:getText("rff_vehicle_cover_third_party")
            or (incident.policyCoverType == "COMPREHENSIVE" and self.i18n:getText("rff_vehicle_cover_comprehensive") or self.i18n:getText("rff_vehicle_cover_none"))
        local licenceBreach = self.manager.insuranceClaims:hasLicenceClaimBreach(incident)
        if licenceBreach then coverText = string.format(self.i18n:getText("rff_claim_cover_licence_breach"), coverText) end
        if self.insuranceClaimStatusValue ~= nil then self.insuranceClaimStatusValue:setText(self:getTrafficIncidentStatusText(incident)) end
        if self.insuranceClaimAnimalValue ~= nil then self.insuranceClaimAnimalValue:setText(vehicleText) end
        if self.insuranceClaimCauseValue ~= nil then
            self.insuranceClaimCauseValue:setText(string.format(self.i18n:getText("rff_traffic_incident_cause"),
                self:getTrafficIncidentSeverityText(incident.severityClass), self:getTrafficIncidentTargetTypeText(incident.targetType)))
        end
        if self.insuranceClaimValueValue ~= nil then self.insuranceClaimValueValue:setText(self:formatMoney(incident.estimatedClaimTotal or 0)) end
        if self.insuranceClaimCoverValue ~= nil then self.insuranceClaimCoverValue:setText(coverText) end
        if self.insuranceClaimExcessValue ~= nil then self.insuranceClaimExcessValue:setText(self:formatMoney(self.manager.insuranceClaims:getTrafficCourtesyIncidentExcess(incident))) end
        if self.insuranceClaimSettlementValue ~= nil then
            self.insuranceClaimSettlementValue:setText(self.i18n:getText("rff_claim_not_yet_assessed"))
        end
        if self.insuranceClaimNote ~= nil then self.insuranceClaimNote:setText(wrapText(self:getTrafficIncidentNote(incident), 62)) end
    else
        local claim = entry.data
        local animal
        if claim.claimType == "VETERINARY" then
            animal = claim.animalName ~= nil and claim.animalName ~= "" and claim.animalName or self.i18n:getText("rff_vet_claim_history_label")
            if claim.animalBreed ~= nil and claim.animalBreed ~= "" and claim.animalUniqueId ~= nil and claim.animalUniqueId ~= "" then
                animal = string.format("%s (%s)", animal, claim.animalBreed)
            end
        elseif claim.claimType == "VEHICLE" then
            animal = claim.vehicleName ~= nil and claim.vehicleName ~= "" and claim.vehicleName or self.i18n:getText("rff_vehicle_claim_history_label")
        else
            animal = claim.animalName ~= nil and claim.animalName ~= "" and claim.animalName or (claim.animalBreed ~= nil and claim.animalBreed ~= "" and claim.animalBreed or claim.animalType or "-")
            if claim.animalBreed ~= nil and claim.animalBreed ~= "" and claim.animalName ~= nil and claim.animalName ~= "" then
                animal = string.format("%s (%s)", claim.animalName, claim.animalBreed)
            end
        end
        if self.insuranceClaimStatusValue ~= nil then self.insuranceClaimStatusValue:setText(self:getInsuranceClaimStatusText(claim.status)) end
        if self.insuranceClaimAnimalValue ~= nil then self.insuranceClaimAnimalValue:setText(animal) end
        if self.insuranceClaimCauseValue ~= nil then self.insuranceClaimCauseValue:setText(self:getInsuranceClaimCauseText(claim.deathReason)) end
        if self.insuranceClaimValueValue ~= nil then self.insuranceClaimValueValue:setText(self:formatMoney(claim.incidentValue or 0)) end
        if self.insuranceClaimCoverValue ~= nil then
            if claim.claimType == "VEHICLE" then
                local coverText = claim.policyCoverType == "THIRD_PARTY" and self.i18n:getText("rff_vehicle_cover_third_party") or (claim.policyCoverType == "COMPREHENSIVE" and self.i18n:getText("rff_vehicle_cover_comprehensive") or self.i18n:getText("rff_vehicle_cover_none"))
                local licenceBreach = self.manager.insuranceClaims:hasLicenceClaimBreach(claim)
                if licenceBreach then coverText = string.format(self.i18n:getText("rff_claim_cover_licence_breach"), coverText) end
                self.insuranceClaimCoverValue:setText(coverText)
            else
                local tier = self.manager.businessAdministration ~= nil and self.manager.businessAdministration:getTierConfig(claim.policyTier) or nil
                self.insuranceClaimCoverValue:setText(tier ~= nil and self.i18n:getText(tier.key) or tostring(claim.policyTier or "-"))
            end
        end
        if self.insuranceClaimExcessValue ~= nil then self.insuranceClaimExcessValue:setText(self:formatMoney(claim.excess or 0)) end
        if self.insuranceClaimSettlementValue ~= nil then
            local claimValue = math.max(0, claim.incidentValue or 0)
            local amount = math.min(claimValue, claim.status == RFF_InsuranceClaimService.STATUS_PAID and (claim.paidAmount or 0) or (claim.approvedAmount or 0))
            if claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_SUBMISSION
                    or claim.status == RFF_InsuranceClaimService.STATUS_UNDER_REVIEW
                    or claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_RESPONSE
                    or claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_ADS_INSPECTION
                    or claim.status == RFF_InsuranceClaimService.STATUS_AWAITING_OEM_REPAIR then
                self.insuranceClaimSettlementValue:setText(self.i18n:getText("rff_claim_not_yet_assessed"))
            elseif claim.status == RFF_InsuranceClaimService.STATUS_DECLINED then
                self.insuranceClaimSettlementValue:setText(self:formatMoney(0))
            else
                self.insuranceClaimSettlementValue:setText(self:formatMoney(amount))
            end
        end
        if self.insuranceClaimNote ~= nil then self.insuranceClaimNote:setText(wrapText(self:getInsuranceClaimOutcomeText(claim), 62)) end
    end

    local selectedTrafficIncident = entry ~= nil and entry.kind == "TRAFFIC_INCIDENT" and entry.data or nil
    local selectedTrafficClaim = entry ~= nil and entry.kind == "CLAIM" and entry.data or nil
    local trafficResponseRequired = selectedTrafficClaim ~= nil
        and self.manager.insuranceClaims:isTrafficWorkflowClaim(selectedTrafficClaim)
        and selectedTrafficClaim.liabilityStatus == "AWAITING_RESPONSE"
    local finalVehicleClaim = self.manager.insuranceClaims:isDecisionFinal(selectedTrafficClaim)
    if self.insuranceDecisionButton ~= nil then self.insuranceDecisionButton:setVisible(finalVehicleClaim) end
    if self.insuranceReviewButton ~= nil then
        self.insuranceReviewButton:setVisible(finalVehicleClaim)
        self.insuranceReviewButton:setDisabled(not finalVehicleClaim or (selectedTrafficClaim.reviewStatus ~= nil and selectedTrafficClaim.reviewStatus ~= ""))
        self.insuranceReviewButton:setText(self.i18n:getText(finalVehicleClaim and selectedTrafficClaim.reviewStatus == "PENDING"
            and "rff_claim_review_pending" or finalVehicleClaim and (selectedTrafficClaim.reviewStatus == "UPHELD" or selectedTrafficClaim.reviewStatus == "ADJUSTED")
            and "rff_claim_review_done" or "rff_claim_review_request"))
    end
    local trafficClaimable = selectedTrafficIncident ~= nil
        and selectedTrafficIncident.status == RFF_InsuranceClaimService.TRAFFIC_INCIDENT_RECORDED
        and selectedTrafficIncident.policyCoverType == "COMPREHENSIVE"
        and self.manager.insuranceClaims:isPolicyInForce(selectedTrafficIncident.policyStatusAtIncident)
        and not self.manager.insuranceClaims:isTrafficCourtesyIncidentExpired(selectedTrafficIncident)
    if self.insuranceVehicleClaimButton ~= nil then
        self.insuranceVehicleClaimButton:setVisible(trafficClaimable or trafficResponseRequired)
        if self.insuranceVehicleClaimButton.setText ~= nil then
            self.insuranceVehicleClaimButton:setText(self.i18n:getText(trafficResponseRequired
                and "rff_traffic_claim_respond" or "rff_traffic_incident_claim_start"))
        end
    end

    -- A new claim remains an explicit player action. When a Traffic Courtesy
    -- incident is selected, the single incident action replaces the two general
    -- livestock actions so the controls remain clear and do not overlap.
    if self.insuranceSubmitClaimButton ~= nil then
        local eligible = self.manager.insuranceClaims:getEligibleDeathCount(self:getCurrentFarmId())
        self.insuranceSubmitClaimButton:setVisible(not finalVehicleClaim and selectedTrafficIncident == nil and not trafficResponseRequired and eligible > 0)
        if eligible > 0 and self.insuranceSubmitClaimButton.setText ~= nil then
            self.insuranceSubmitClaimButton:setText(self.i18n:getText("rff_claim_start"))
        end
    end
    if self.insuranceVetClaimButton ~= nil then
        local total, count = self.manager.insuranceClaims:getEligibleVeterinaryExpenseTotal(self:getCurrentFarmId())
        self.insuranceVetClaimButton:setVisible(not finalVehicleClaim and selectedTrafficIncident == nil and not trafficResponseRequired and count > 0 and total > 0)
    end
end

function RFF_FinanceFrame:onClickInsuranceDecision()
    local claim = self:getSelectedInsuranceClaim()
    if self.manager.insuranceClaims:isDecisionFinal(claim) then
        RFF_ClaimDecisionDialog.show(self.manager.insuranceClaims:getDecisionText(claim))
    end
end

function RFF_FinanceFrame:onClickInsuranceReview()
    local claim = self:getSelectedInsuranceClaim()
    if not self.manager.insuranceClaims:isDecisionFinal(claim) then return end
    self.pendingClaimReviewId = claim.id
    YesNoDialog.show(self.onInsuranceReviewConfirmed, self, self.i18n:getText("rff_claim_review_confirm"), self.i18n:getText("rff_claim_review_request"))
end

function RFF_FinanceFrame:onInsuranceReviewConfirmed(confirmed)
    local id = self.pendingClaimReviewId
    self.pendingClaimReviewId = nil
    if not confirmed or id == nil then return end
    local ok, reason = self.manager.insuranceClaims:requestDecisionReview(self:getCurrentFarmId(), id)
    InfoDialog.show(self.i18n:getText(ok and "rff_claim_review_recorded" or reason == "not_server" and "rff_claim_server_only" or "rff_claim_review_unavailable"))
    self:updateInsuranceClaimsContent(true)
end

function RFF_FinanceFrame:onClickSubmitVehicleIncidentClaim()
    if self.manager == nil or self.manager.insuranceClaims == nil then return end
    local entry = self:getSelectedInsuranceEntry()
    local claim = entry ~= nil and entry.kind == "CLAIM" and entry.data or nil
    if claim ~= nil and self.manager.insuranceClaims:isTrafficWorkflowClaim(claim)
            and claim.liabilityStatus == "AWAITING_RESPONSE" then
        local text = string.format(self.i18n:getText("rff_traffic_claim_response_confirm"),
            self.manager.insuranceClaims:getClaimReference(claim), claim.incidentTargetName or self.i18n:getText("rff_traffic_target_other"),
            self:formatMoney(claim.thirdPartyLiability or 0), self:formatMoney(claim.legalCosts or 0),
            self:getInsuranceLicenceSnapshotText(claim), self.manager.insuranceClaims:getTrafficClaimResponseDaysRemaining(claim))
        self.pendingTrafficCourtesyClaimId = claim.id
        YesNoDialog.show(self.onTrafficClaimResponseConfirmed, self, text, self.i18n:getText("rff_traffic_claim_response_title"))
        return
    end
    local incident = entry ~= nil and entry.kind == "TRAFFIC_INCIDENT" and entry.data or nil
    if incident == nil then return end
    if self.manager.insuranceClaims:isTrafficCourtesyIncidentExpired(incident) then
        InfoDialog.show(self.i18n:getText("rff_traffic_incident_expired_note"))
        self:updateInsuranceClaimsContent(true)
        return
    end
    local text = string.format(self.i18n:getText("rff_traffic_incident_claim_confirm"),
        self.manager.insuranceClaims:getTrafficCourtesyIncidentReference(incident), incident.externalIncidentId or "Traffic Courtesy",
        incident.vehicleName or self.i18n:getText("rff_fleet_vehicle"), incident.targetName or self.i18n:getText("rff_traffic_target_other"),
        self:getTrafficIncidentSeverityText(incident.severityClass), self:formatMoney(incident.ownDamageEstimate or 0),
        self:formatMoney(incident.thirdPartyEstimate or 0), self:formatMoney(incident.legalCostEstimate or 0),
        self:formatMoney(incident.estimatedClaimTotal or 0), self:formatMoney(incident.estimatedPayout or 0),
        self:getInsuranceLicenceSnapshotText(incident))
    self.pendingTrafficCourtesyIncidentId = incident.id
    YesNoDialog.show(self.onVehicleIncidentClaimConfirmed, self, text, self.i18n:getText("rff_traffic_incident_claim_title"))
end

function RFF_FinanceFrame:onTrafficClaimResponseConfirmed(confirmed)
    local claimId = self.pendingTrafficCourtesyClaimId
    self.pendingTrafficCourtesyClaimId = nil
    if not confirmed or claimId == nil or self.manager == nil or self.manager.insuranceClaims == nil then return end
    local ok, reason, claim = self.manager.insuranceClaims:acknowledgeTrafficCourtesyClaim(self:getCurrentFarmId(), claimId)
    if not ok or claim == nil then
        InfoDialog.show(reason == "not_server" and self.i18n:getText("rff_claim_server_only") or self.i18n:getText("rff_traffic_claim_response_failed"))
        self:updateInsuranceClaimsContent(true)
        return
    end
    self.selectedInsuranceEntryKey = "CLAIM:" .. tostring(claim.id or 0)
    self.insuranceEntries = nil
    InfoDialog.show(string.format(self.i18n:getText("rff_traffic_claim_response_recorded"), self.manager.insuranceClaims:getClaimReference(claim)))
    self:updateInsuranceClaimsContent(true)
    self:updateBusinessAdministrationContent()
end

function RFF_FinanceFrame:onVehicleIncidentClaimConfirmed(confirmed)
    local incidentId = self.pendingTrafficCourtesyIncidentId
    self.pendingTrafficCourtesyIncidentId = nil
    if not confirmed or incidentId == nil or self.manager == nil or self.manager.insuranceClaims == nil then return end
    local ok, reason, claim = self.manager.insuranceClaims:initiateTrafficCourtesyClaim(self:getCurrentFarmId(), incidentId)
    if not ok or claim == nil then
        if reason == "expired" then InfoDialog.show(self.i18n:getText("rff_traffic_incident_expired_note"))
        elseif reason == "not_server" then InfoDialog.show(self.i18n:getText("rff_claim_server_only"))
        else InfoDialog.show(self.i18n:getText("rff_traffic_incident_claim_failed")) end
        self:updateInsuranceClaimsContent(true)
        return
    end
    self.selectedInsuranceEntryKey = "CLAIM:" .. tostring(claim.id or 0)
    self.insuranceEntries = nil
    InfoDialog.show(string.format(self.i18n:getText("rff_traffic_incident_claim_submitted"), self.manager.insuranceClaims:getClaimReference(claim)))
    self:updateInsuranceClaimsContent(true)
    self:updateBusinessAdministrationContent()
end

function RFF_FinanceFrame:onClickSubmitInsuranceClaim()
    if self.manager == nil or self.manager.insuranceClaims == nil then return end
    local eligible = self.manager.insuranceClaims:getEligibleDeathRecords(self:getCurrentFarmId())
    if #eligible == 0 then
        InfoDialog.show(self.i18n:getText("rff_claim_no_eligible_deaths"))
        return
    end

    -- Opening the document is still only an administrative action. The insurer
    -- claim record is created by the document controller only after the player
    -- selects a recorded death, signs the declaration and confirms submission.
    if RFF_InsuranceClaimDialog == nil or not RFF_InsuranceClaimDialog.show(self) then
        InfoDialog.show(self.i18n:getText("rff_claim_form_unavailable"))
    end
end

function RFF_FinanceFrame:onClickSubmitVeterinaryClaim()
    if self.manager == nil or self.manager.insuranceClaims == nil then return end
    local total, count = self.manager.insuranceClaims:getEligibleVeterinaryExpenseTotal(self:getCurrentFarmId())
    if count <= 0 or total <= 0 then
        InfoDialog.show(self.i18n:getText("rff_vet_claim_no_eligible"))
        return
    end
    local terms = self.manager.insuranceClaims:getTerms("COMPREHENSIVE")
    local estimate = math.max(0, total * (terms.veterinaryIndemnity or 0) - (terms.veterinaryExcess or 0))
    local text = string.format(self.i18n:getText("rff_vet_claim_confirm"),
        count, self:formatMoney(total), math.floor((terms.veterinaryIndemnity or 0) * 100 + 0.5),
        self:formatMoney(terms.veterinaryExcess or 0), self:formatMoney(estimate))
    YesNoDialog.show(self.onVeterinaryClaimConfirmed, self, text, self.i18n:getText("rff_vet_claim_title"))
end

function RFF_FinanceFrame:onVeterinaryClaimConfirmed(confirmed)
    if not confirmed or self.manager == nil or self.manager.insuranceClaims == nil then return end
    local ok, reason, claim = self.manager.insuranceClaims:initiateVeterinaryClaim(self:getCurrentFarmId())
    if not ok then
        if reason == "not_server" then InfoDialog.show(self.i18n:getText("rff_claim_server_only"))
        else InfoDialog.show(self.i18n:getText("rff_vet_claim_no_eligible")) end
        return
    end
    InfoDialog.show(string.format(self.i18n:getText("rff_vet_claim_submitted"), self.manager.insuranceClaims:getClaimReference(claim)))
    self:updateInsuranceClaimsContent(true)
    self:updateBusinessAdministrationContent()
end

function RFF_FinanceFrame:getInsuranceTierIndex(tierId)
    for index, tier in ipairs(self.insuranceTierOptions or {}) do
        if tier.id == tierId then return index end
    end
    return 2
end

function RFF_FinanceFrame:getInsuranceCoverSummaryText(tierId)
    if self.manager == nil or self.manager.insuranceClaims == nil then return "" end
    local terms = self.manager.insuranceClaims:getTerms(tierId)
    local covered = self.i18n:getText("rff_insurance_covered")
    local notCovered = self.i18n:getText("rff_insurance_not_covered")
    local lines = {}
    lines[#lines + 1] = string.format("%s: %s    |    %s: %s",
        self.i18n:getText("rff_insurance_accidental_death"), terms.accidentalCovered == true and covered or notCovered,
        self.i18n:getText("rff_insurance_health_death"), terms.healthCovered == true and covered or notCovered)
    if terms.veterinaryCovered == true then
        lines[#lines + 1] = string.format(self.i18n:getText("rff_insurance_veterinary_benefit"),
            math.floor((terms.veterinaryIndemnity or 0) * 100 + 0.5), self:formatMoney(terms.veterinaryExcess or 0))
    else
        lines[#lines + 1] = string.format("%s: %s", self.i18n:getText("rff_insurance_veterinary_treatment"), notCovered)
    end
    if terms.missingCovered == true then
        lines[#lines + 1] = string.format(self.i18n:getText("rff_insurance_missing_benefit"),
            math.floor((terms.missingIndemnity or 0) * 100 + 0.5), self:formatMoney(terms.missingExcess or 0))
    else
        lines[#lines + 1] = string.format("%s: %s", self.i18n:getText("rff_insurance_missing_livestock"), notCovered)
    end
    lines[#lines + 1] = string.format(self.i18n:getText("rff_insurance_mortality_terms"),
        math.floor((terms.indemnity or 0) * 100 + 0.5), self:formatMoney(terms.excess or 0))
    lines[#lines + 1] = self.i18n:getText("rff_insurance_old_age_neglect_excluded")
    return table.concat(lines, "\n")
end

function RFF_FinanceFrame:updateBusinessAdministrationContent()
    if self.manager == nil or self.manager.businessAdministration == nil or g_currentMission == nil then return end
    local farmId = self:getCurrentFarmId()
    if farmId <= 0 then return end
    local summary = self.manager.businessAdministration:getSummary(farmId)
    local state = summary.state or {}
    local tax = summary.tax or {}
    local compliance = self.manager.taxCompliance ~= nil and self.manager.taxCompliance:getSummary(farmId) or {available=false,state={}}
    local taxState = compliance.state or {}

    if self.taxAuthorityValue ~= nil then
        if tax.available and tax.enabled then self.taxAuthorityValue:setText(self.i18n:getText("rff_tax_authority_redtape") .. " - " .. self.i18n:getText("rff_status_active"))
        elseif tax.available then self.taxAuthorityValue:setText(self.i18n:getText("rff_tax_authority_redtape") .. " - " .. self.i18n:getText("rff_status_disabled"))
        else self.taxAuthorityValue:setText(self.i18n:getText("rff_tax_authority_unavailable")) end
    end
    if self.taxRateValue ~= nil then self.taxRateValue:setText(tax.enabled and string.format("%.1f%%", (tax.taxRate or 0) * 100) or "-") end
    if self.taxIncomeValue ~= nil then self.taxIncomeValue:setText(tax.enabled and self:formatMoney(tax.currentTaxableIncome or 0) or "-") end
    if self.taxExpensesValue ~= nil then self.taxExpensesValue:setText(tax.enabled and self:formatMoney(tax.currentExpenses or 0) or "-") end
    if self.taxEstimateValue ~= nil then self.taxEstimateValue:setText(tax.enabled and self:formatMoney(tax.currentTax or 0) or "-") end
    if self.taxLossRolloverValue ~= nil then self.taxLossRolloverValue:setText(tax.enabled and self:formatMoney(tax.lossRollover or 0) or "-") end
    if self.taxAnnualAssessmentValue ~= nil then
        self.taxAnnualAssessmentValue:setText(tax.enabled and tax.lastAssessmentExists and self:formatMoney(tax.lastTax or 0) or self.i18n:getText("rff_tax_no_annual_assessment"))
    end
    if self.taxAnnualPaymentTimingValue ~= nil then
        self.taxAnnualPaymentTimingValue:setText(tax.enabled and string.format(self.i18n:getText("rff_tax_collection_timing_value"), tostring(tax.paymentMonth or "September")) or "-")
    end
    if self.taxAnnualPaymentStatusValue ~= nil then
        local paymentText = self.i18n:getText("rff_tax_no_annual_assessment")
        if tax.enabled and tax.lastAssessmentExists then
            paymentText = self.i18n:getText(tax.lastPaid and "rff_tax_payment_status_paid_redtape" or "rff_tax_payment_status_awaiting_redtape")
        end
        self.taxAnnualPaymentStatusValue:setText(paymentText)
    end

    if self.taxReturnStatusValue ~= nil then
        local status = taxState.taxReturnStatus or "NONE"
        if status == "NONE" then
            self.taxReturnStatusValue:setText(self.i18n:getText(tax.enabled and "rff_tax_return_not_due_short" or "rff_not_available"))
        else
            local key = "rff_tax_return_status_" .. string.lower(status)
            self.taxReturnStatusValue:setText(string.format("%s %d - %s", self.i18n:getText("rff_tax_return_year_short"), taxState.taxReturnYear or 0, self.i18n:getText(key)))
        end
    end

    if self.taxComplianceRecordValue ~= nil then
        local key = "rff_tax_compliance_clear"
        if taxState.taxInvestigationStatus == "OPEN" then key = "rff_tax_compliance_under_review"
        elseif (taxState.taxComplianceFlags or 0) >= 2 then key = "rff_tax_compliance_heightened"
        elseif (taxState.taxComplianceFlags or 0) == 1 then key = "rff_tax_compliance_previous_adjustment" end
        self.taxComplianceRecordValue:setText(self.i18n:getText(key))
    end
    if self.taxComplianceLiabilityValue ~= nil then self.taxComplianceLiabilityValue:setText(self:formatMoney(taxState.taxComplianceLiability or 0)) end
    if self.taxReturnButton ~= nil then
        local status = taxState.taxReturnStatus or "NONE"
        -- Red Tape itself is authoritative for whether the annual assessment remains
        -- outstanding. If it has an unpaid assessment, always expose the filing action.
        -- The click handler reconciles/adopts that statement before opening the dialog.
        local show = tax.enabled and (status ~= "NONE" or (tax.lastAssessmentExists and not tax.lastPaid))
        self.taxReturnButton:setVisible(show)
        if show and self.taxReturnButton.setText ~= nil then
            local buttonKey = (status == "OPEN" or status == "NONE") and "rff_tax_return_prepare" or "rff_tax_return_view"
            self.taxReturnButton:setText(self.i18n:getText(buttonKey))
        end
    end
    if self.taxCompliancePayButton ~= nil then self.taxCompliancePayButton:setVisible((taxState.taxComplianceLiability or 0) > 0.01) end

    if self.taxIntegrationNote ~= nil then
        if tax.available and tax.enabled then
            local noteKey = taxState.taxReturnWasForcedTest == true and "rff_tax_redtape_note_test_v0911" or "rff_tax_redtape_note_v0911"
            self.taxIntegrationNote:setText(wrapText(string.format(self.i18n:getText(noteKey), tostring(tax.calculationMonth or "April"), tostring(tax.paymentMonth or "September")), 66))
        else
            self.taxIntegrationNote:setText(wrapText(self.i18n:getText("rff_tax_missing_note"), 64))
        end
    end

    if self.adminMonthlyValue ~= nil then self.adminMonthlyValue:setText(self:formatMoney(summary.monthlyAdminCost or 0)) end
    if self.adminArrearsValue ~= nil then self.adminArrearsValue:setText(self:formatMoney(summary.adminArrears or 0)) end
    if self.adminFilingEstimateValue ~= nil then self.adminFilingEstimateValue:setText(self:formatMoney(summary.annualFilingEstimate or 0)) end
    if self.adminLastFilingValue ~= nil then self.adminLastFilingValue:setText(self:formatMoney(state.adminLastAnnualFilingCharge or 0)) end
    if self.adminTotalPaidValue ~= nil then self.adminTotalPaidValue:setText(self:formatMoney(state.adminTotalPaid or 0)) end
    if self.adminMissedValue ~= nil then self.adminMissedValue:setText(tostring(state.adminMissedPayments or 0)) end
    if self.businessLiabilityValue ~= nil then self.businessLiabilityValue:setText(self:formatMoney(summary.outstandingLiabilities or 0)) end
    do
        local c = summary.counts or {}
        local financeCount = (c.loans or 0) + (c.tenancies or 0) + (c.assetFinance or 0)
        if self.adminComplexityValueLine1 ~= nil then
            self.adminComplexityValueLine1:setText(string.format(self.i18n:getText("rff_admin_complexity_line1"), c.farmland or 0, c.placeables or 0))
        end
        if self.adminComplexityValueLine2 ~= nil then
            self.adminComplexityValueLine2:setText(string.format(self.i18n:getText("rff_admin_complexity_line2"), c.vehicles or 0, financeCount))
        end
    end
    if self.adminNote ~= nil then
        self.adminNote:setText(wrapText(self.i18n:getText("rff_admin_note"), 62))
    end

    local tier = self.manager.businessAdministration:getTierConfig(summary.insuranceTier)
    local nextTier = self.manager.businessAdministration:getTierConfig(summary.insuranceNextTier)
    if self.insuranceStatusValue ~= nil then self.insuranceStatusValue:setText(self.i18n:getText("rff_insurance_status_" .. string.lower(summary.insuranceStatus or "ACTIVE"))) end
    if self.insuranceCurrentTierValue ~= nil then self.insuranceCurrentTierValue:setText(self.i18n:getText(tier.key)) end
    if self.insuranceTierOption ~= nil then setOptionState(self.insuranceTierOption, self:getInsuranceTierIndex(nextTier.id)) end
    if self.insuranceInsurableValue ~= nil then self.insuranceInsurableValue:setText(self:formatMoney(summary.insuranceInsurableValue or 0)) end
    if self.insurancePremiumEstimateValue ~= nil then self.insurancePremiumEstimateValue:setText(self:formatMoney(summary.insurancePremiumEstimate or 0)) end
    if self.insurancePremiumDueValue ~= nil then self.insurancePremiumDueValue:setText(self:formatMoney(summary.insurancePremiumDue or 0)) end
    if self.insuranceLastPremiumValue ~= nil then self.insuranceLastPremiumValue:setText(self:formatMoney(state.insuranceLastPremium or 0)) end
    if self.insuranceTotalPaidValue ~= nil then self.insuranceTotalPaidValue:setText(self:formatMoney(state.insuranceTotalPaid or 0)) end
    if self.insuranceRenewalValue ~= nil then
        local months = summary.insuranceMonthsToRenewal or 0
        if summary.insurancePremiumDue > 0.01 then self.insuranceRenewalValue:setText(self.i18n:getText("rff_due_now"))
        elseif months <= 0 then self.insuranceRenewalValue:setText(self.i18n:getText("rff_due_now"))
        else self.insuranceRenewalValue:setText(string.format(self.i18n:getText("rff_periods_remaining"), months)) end
    end
    if self.insurancePayButton ~= nil then self.insurancePayButton:setVisible((summary.insurancePremiumDue or 0) > 0.01) end
    if self.insuranceNote ~= nil then self.insuranceNote:setText(self:getInsuranceCoverSummaryText(nextTier.id)) end
end

function RFF_FinanceFrame:getVehicleComplianceCategoryText(category)
    return string.format(self.i18n:getText("rff_compliance_category_value"), tostring(category or "-"))
end

function RFF_FinanceFrame:getVehicleComplianceBasisText(basis)
    local key = {
        TRACKED = "rff_compliance_basis_tracked",
        LIGHT_VEHICLE = "rff_compliance_basis_light",
        WHEELED_TRACTOR = "rff_compliance_basis_tractor",
        LARGE_TRACTOR = "rff_compliance_basis_large_tractor",
        ROAD_TRUCK = "rff_compliance_basis_truck",
        SELF_PROPELLED_HARVESTER = "rff_compliance_basis_harvester",
        LARGE_SELF_PROPELLED = "rff_compliance_basis_self_propelled",
        UNCLASSIFIED_DRIVEABLE = "rff_compliance_basis_unclassified"
    }
    return self.i18n:getText(key[tostring(basis or "")] or "rff_compliance_basis_unclassified")
end

function RFF_FinanceFrame:updateRoadSpeedRulesContent()
    local fleet = self.manager ~= nil and self.manager.fleetManagement or nil
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if fleet == nil or service == nil then return end
    local previousIndex = self.roadSpeedVehicleOption ~= nil and self.roadSpeedVehicleOption.state or 1
    local previous = (self.roadSpeedVehicles or {})[previousIndex]
    local preserve = previous ~= nil and previous.uniqueId or nil
    self.roadSpeedVehicles = fleet:getFleet(self:getCurrentFarmId()).vehicles or {}
    local texts, selected = {}, 1
    for index, row in ipairs(self.roadSpeedVehicles) do
        texts[#texts + 1] = tostring(row.name or self.i18n:getText("rff_vehicle_insurance_vehicle"))
        if preserve ~= nil and row.uniqueId == preserve then selected = index end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_vehicle_insurance_no_vehicles")} end
    if self.roadSpeedVehicleOption ~= nil then
        self.roadSpeedVehicleOption:setTexts(texts)
        setOptionState(self.roadSpeedVehicleOption, selected)
    end
    local row = self.roadSpeedVehicles[selected]
    local assessment = row ~= nil and service:getAssessment(self:getCurrentFarmId(), row.vehicle or row.uniqueId) or nil
    local rules = assessment ~= nil and assessment.speedRules or {}
    local function set(element, text) if element ~= nil then element:setText(text) end end
    local function speed(value) return RFF_RoadSpeedRules.formatSpeed(value, self.i18n) end
    local unused = self.i18n:getText("rff_speed_not_applicable")
    local missing = self.i18n:getText("rff_speed_not_supplied")
    set(self.roadSpeedRoadValue, rules.roadLimitKmh ~= nil and speed(rules.roadLimitKmh) or missing)
    set(self.roadSpeedVehicleValue, rules.vehicleLimitKmh ~= nil and speed(rules.vehicleLimitKmh) or missing)
    set(self.roadSpeedWidthValue, rules.widthLimitKmh ~= nil and speed(rules.widthLimitKmh) or unused)
    set(self.roadSpeedWeightValue, rules.weightLimitKmh ~= nil and speed(rules.weightLimitKmh) or unused)
    set(self.roadSpeedPenaltyValue, rules.penaltyLimitKmh ~= nil and speed(rules.penaltyLimitKmh) or unused)
    set(self.roadSpeedFallbackValue, rules.fallbackLimitKmh ~= nil and speed(rules.fallbackLimitKmh) or unused)
    set(self.roadSpeedEffectiveValue, speed(rules.limitKmh))
    set(self.roadSpeedReasonValue, rules.reason ~= nil and self.i18n:getText("rff_speed_reason_" .. string.lower(rules.reason)) or "-")
    set(self.roadSpeedSizeValue, assessment ~= nil and string.format("%.2f m / %.2f t", assessment.widthMetres, assessment.grossMassTonnes) or "-")
    set(self.roadSpeedContextNote, wrapText(self.i18n:getText(assessment == nil and "rff_compliance_no_vehicle_note"
        or (assessment.locationType == "ROAD" and "rff_speed_on_road" or "rff_speed_off_road")), 62))
    set(self.roadSpeedDimensionHelp, wrapText(string.format(self.i18n:getText("rff_speed_dimensions_help"), speed(RFF_RoadSpeedRules.DIMENSION_CAP_KMH)), 66))
end

function RFF_FinanceFrame:onRoadSpeedVehicleChanged()
    self:updateRoadSpeedRulesContent()
end

function RFF_FinanceFrame:rebuildVehicleComplianceSelector(vehicles, preserveUniqueId)
    self.vehicleComplianceVehicles = vehicles or {}
    local texts = {}
    local selected = 1
    for index, row in ipairs(self.vehicleComplianceVehicles) do
        texts[#texts + 1] = tostring(row.name or self.i18n:getText("rff_vehicle_insurance_vehicle"))
        if preserveUniqueId ~= nil and tostring(row.uniqueId or "") == tostring(preserveUniqueId) then selected = index end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_vehicle_insurance_no_vehicles")} end
    if self.vehicleComplianceVehicleOption ~= nil then
        if self.vehicleComplianceVehicleOption.setTexts ~= nil then self.vehicleComplianceVehicleOption:setTexts(texts) else self.vehicleComplianceVehicleOption.texts = texts end
        setOptionState(self.vehicleComplianceVehicleOption, selected)
    end
end

function RFF_FinanceFrame:getSelectedVehicleComplianceRow()
    if self.vehicleComplianceVehicles == nil or #self.vehicleComplianceVehicles == 0 then return nil end
    local index = math.max(1, math.min(#self.vehicleComplianceVehicles, self.vehicleComplianceVehicleOption ~= nil and (self.vehicleComplianceVehicleOption.state or 1) or 1))
    return self.vehicleComplianceVehicles[index]
end

function RFF_FinanceFrame:rebuildLicenceCategorySelector()
    local labels = {
        self.i18n:getText("rff_licence_category_f"),
        self.i18n:getText("rff_licence_category_h"),
        self.i18n:getText("rff_licence_category_c"),
        self.i18n:getText("rff_licence_category_adr")
    }
    local selected = 1
    for index, category in ipairs(self.licenceCategories or {}) do
        if category == self.selectedLicenceCategory then selected = index end
    end
    if self.licenceCategoryOption ~= nil then
        if self.licenceCategoryOption.setTexts ~= nil then self.licenceCategoryOption:setTexts(labels) else self.licenceCategoryOption.texts = labels end
        setOptionState(self.licenceCategoryOption, selected)
    end
end

function RFF_FinanceFrame:getSelectedLicenceCategory()
    local index = self.licenceCategoryOption ~= nil and (self.licenceCategoryOption.state or 1) or 1
    index = math.max(1, math.min(#self.licenceCategories, index))
    return self.licenceCategories[index]
end

function RFF_FinanceFrame:getLicenceFailureText(reason)
    local keys = {
        COLLISION="rff_licence_failure_collision",
        SPEED="rff_licence_failure_speed",
        TIME="rff_licence_failure_time",
        THEORY="rff_licence_failure_theory",
        VEHICLE_MISSING="rff_licence_failure_vehicle",
        INTERRUPTED="rff_licence_failure_interrupted",
        SPAWN_FAILED="rff_licence_failure_spawn"
    }
    return self.i18n:getText(keys[tostring(reason or "")] or "rff_licence_failure_general")
end

function RFF_FinanceFrame:updateLicenceProcessContent(farmId, service)
    self:rebuildLicenceCategorySelector()
    local category = self:getSelectedLicenceCategory()
    self.selectedLicenceCategory = category
    local process = service:getLicenceProcess(farmId, category)
    if process == nil then return end
    if self.licenceModeOption ~= nil then
        self.updatingLicenceModeOption = true
        setOptionState(self.licenceModeOption, process.licenceMode == "REQUIRED" and 2 or 1)
        self.updatingLicenceModeOption = false
        if self.licenceModeOption.setDisabled ~= nil then self.licenceModeOption:setDisabled(process.canChangeLicenceMode ~= true) end
    end
    if self.licenceCategoryOption ~= nil and self.licenceCategoryOption.setDisabled ~= nil then
        self.licenceCategoryOption:setDisabled(process.licenceMode == "FULL")
    end
    local statusKey = "rff_licence_status_" .. string.lower(tostring(process.status or "NONE"))
    if self.licenceAssessmentStatusValue ~= nil then self.licenceAssessmentStatusValue:setText(self.i18n:getText(statusKey)) end

    local progress = ""
    local actionKey = "rff_licence_apply"
    local disabled = false
    if process.status == "FULL" then
        progress = self.i18n:getText("rff_licence_progress_full")
        actionKey = "rff_licence_full_button"
        disabled = true
    elseif process.status == "HELD" then
        progress = string.format(self.i18n:getText("rff_licence_progress_held"), category)
        actionKey = "rff_licence_held_button"
        disabled = true
    elseif process.status == "OTHER_ACTIVE" then
        progress = string.format(self.i18n:getText("rff_licence_progress_other_active"), tostring(process.activeCategory or "-"))
        actionKey = "rff_licence_active_button"
        disabled = true
    elseif process.status == "BOOKED" then
        if process.ready then
            progress = string.format(self.i18n:getText(process.theoryRetake
                and "rff_licence_progress_theory_retake_ready" or "rff_licence_progress_ready"), category)
            actionKey = (process.theoryOnly or process.theoryRetake) and "rff_licence_start_theory" or "rff_licence_start_practical"
        else
            progress = string.format(self.i18n:getText(process.theoryRetake
                and "rff_licence_progress_theory_retake_booked" or "rff_licence_progress_booked"), category)
            actionKey = "rff_licence_waiting_button"
            disabled = true
        end
    elseif process.status == "SPAWNING" then
        progress = self.i18n:getText("rff_licence_progress_spawning")
        actionKey = "rff_licence_spawning_button"
        disabled = true
    elseif process.status == "PRACTICAL" then
        local r = process.requirements or {}
        progress = string.format(self.i18n:getText("rff_licence_progress_practical"),
            process.distance / 1000, (r.distance or 0) / 1000,
            process.roadDistance / 1000, (r.roadDistance or 0) / 1000,
            process.reverseDistance, r.reverseDistance or 0,
            process.movingSeconds, r.movingSeconds or 0,
            process.leftTurnDegrees, r.turnDegrees or 0,
            process.rightTurnDegrees, r.turnDegrees or 0,
            process.trafficCourtesyConnected and self.i18n:getText("rff_licence_collision_monitored") or self.i18n:getText("rff_licence_collision_unmonitored"))
        actionKey = "rff_licence_active_button"
        disabled = true
    elseif process.status == "RETURNING_FAILED" then
        progress = string.format(self.i18n:getText("rff_licence_progress_returning_failed"),
            self:getLicenceFailureText(process.failureReason), process.returnMinutes or 0)
        actionKey = "rff_licence_returning_button"
        disabled = true
    elseif process.status == "RETURNING" then
        progress = string.format(self.i18n:getText("rff_licence_progress_returning"), process.returnMinutes or 0)
        actionKey = "rff_licence_returning_button"
        disabled = true
    elseif process.status == "THEORY" then
        progress = string.format(self.i18n:getText("rff_licence_progress_theory"), process.theoryIndex or 1, process.theoryTotal or 5)
        actionKey = "rff_licence_answer_theory"
    elseif process.status == "FAILED" then
        if process.theoryRetake then
            progress = string.format(self.i18n:getText("rff_licence_progress_theory_retake"), self:formatMoney(process.fee or 0))
            actionKey = "rff_licence_rebook_theory"
        else
            progress = string.format(self.i18n:getText("rff_licence_progress_failed"), self:getLicenceFailureText(process.failureReason), self:formatMoney(process.fee or 0))
            actionKey = "rff_licence_rebook"
        end
    else
        progress = string.format(self.i18n:getText(process.theoryOnly and "rff_licence_progress_new_theory" or "rff_licence_progress_new_practical"), self:formatMoney(process.fee or 0))
    end
    if self.licenceAssessmentProgress ~= nil then self.licenceAssessmentProgress:setText(wrapText(progress, 64)) end
    if self.licenceAssessmentActionButton ~= nil then
        self.licenceAssessmentActionButton:setText(self.i18n:getText(actionKey))
        if self.licenceAssessmentActionButton.setDisabled ~= nil then self.licenceAssessmentActionButton:setDisabled(disabled) end
    end
end

function RFF_FinanceFrame:updateRoadComplianceSettingsContent()
    if self.roadsideChecksOption ~= nil and self.manager ~= nil then
        local state=self.manager.repository:getFarmState(self:getCurrentFarmId(),false)
        self.updatingRoadsideOption=true
        setOptionState(self.roadsideChecksOption,state ~= nil and state.roadsideChecksEnabled==true and 2 or 1)
        self.roadsideChecksOption:setDisabled(g_currentMission==nil or not g_currentMission:getIsServer())
        self.updatingRoadsideOption=false
    end
    if self.speedingEnforcementOption ~= nil and self.manager ~= nil then
        local state=self.manager.repository:getFarmState(self:getCurrentFarmId(),false)
        self.updatingSpeedingOption=true
        setOptionState(self.speedingEnforcementOption,state ~= nil and state.speedingEnforcementEnabled == true and 2 or 1)
        self.speedingEnforcementOption:setDisabled(g_currentMission == nil or not g_currentMission:getIsServer())
        self.updatingSpeedingOption=false
    end
    if self.roadSpeedHudOption ~= nil and self.manager ~= nil and self.manager.roadSpeedHud ~= nil then
        self.updatingRoadSpeedHudOption = true
        setOptionState(self.roadSpeedHudOption,self.manager.roadSpeedHud:isEnabled(self:getCurrentFarmId()) and 2 or 1)
        self.updatingRoadSpeedHudOption = false
    end
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    local farmId = self:getCurrentFarmId()
    if service == nil or farmId <= 0 then return end
    local settings = service:getRoadComplianceSettings(farmId)
    if settings == nil then return end
    if self.insurancePointsOption ~= nil then
        local state = self.manager.repository:getFarmState(farmId, true)
        self.updatingInsurancePointsOption = true
        setOptionState(self.insurancePointsOption, state.vehicleInsurancePointsEnabled == true and 2 or 1)
        self.updatingInsurancePointsOption = false
        self.insurancePointsOption:setDisabled(g_currentMission == nil or not g_currentMission:getIsServer())
    end
    if self.drivingPenaltiesOption ~= nil then
        self.updatingDrivingPenaltiesOption = true
        setOptionState(self.drivingPenaltiesOption, settings.drivingPenaltiesEnabled and 2 or 1)
        self.updatingDrivingPenaltiesOption = false
    end
    if self.licenceModeOption ~= nil then
        self.updatingLicenceModeOption = true
        setOptionState(self.licenceModeOption, settings.licenceMode == "REQUIRED" and 2 or 1)
        self.updatingLicenceModeOption = false
        if self.licenceModeOption.setDisabled ~= nil then
            self.licenceModeOption:setDisabled(settings.canChangeLicenceMode ~= true)
        end
    end
    local modeKey = settings.licenceMode == "REQUIRED" and "rff_road_rules_mode_required_summary" or "rff_road_rules_mode_full_summary"
    if self.roadRulesModeSummary ~= nil then
        self.roadRulesModeSummary:setText(wrapText(self.i18n:getText(modeKey), 72))
    end
    if self.roadRulesTrafficCourtesyValue ~= nil then
        self.roadRulesTrafficCourtesyValue:setText(self.i18n:getText(settings.trafficCourtesyConnected
            and "rff_road_rules_detected" or "rff_road_rules_not_detected"))
    end
    if self.roadRulesCollisionValue ~= nil then
        self.roadRulesCollisionValue:setText(self.i18n:getText(settings.trafficCourtesyConnected
            and "rff_road_rules_collision_external" or "rff_road_rules_collision_unavailable"))
    end
    if self.roadRulesStopsValue ~= nil then
        self.roadRulesStopsValue:setText(self.i18n:getText("rff_road_rules_not_active"))
    end
    if self.roadRulesPointsValue ~= nil then
        local farmState = self.manager.repository:getFarmState(farmId,false)
        self.roadRulesPointsValue:setText(string.format(self.i18n:getText((settings.automaticPenaltyPointsActive
            or (farmState ~= nil and (farmState.speedingEnforcementEnabled == true or farmState.roadsideChecksEnabled == true)))
            and "rff_road_rules_points_active" or "rff_road_rules_points_unavailable"), settings.penaltyPoints or 0))
    end
    if self.roadRulesClaimsValue ~= nil then
        self.roadRulesClaimsValue:setText(self.i18n:getText(settings.trafficCourtesyConnected
            and "rff_road_rules_claims_connected" or "rff_road_rules_claims_unavailable"))
    end
    self:rebuildDriverOffenceSelector(service:getDriverOffences(farmId), self.selectedDriverOffenceId)
    self:updateDriverOffenceDetails(settings.penaltyPoints or 0)
    if self.roadRulesFinanceOnlyText ~= nil then
        self.roadRulesFinanceOnlyText:setText(wrapText(service:getRestrictionSummary(farmId), 67))
    end
    if self.roadRulesDevelopmentText ~= nil then
        self.roadRulesDevelopmentText:setText(wrapText(self.i18n:getText("rff_road_rules_development"), 69))
    end
end

function RFF_FinanceFrame:rebuildDriverOffenceSelector(offences, preserveId)
    self.driverOffences = offences or {}
    local texts = {}
    local selected = 1
    for index, offence in ipairs(self.driverOffences) do
        local severityKey = "rff_driver_offence_severity_" .. string.lower(tostring(offence.severityClass or "MINOR"))
        texts[#texts + 1] = string.format(self.i18n:getText("rff_driver_offence_selector"),
            offence.id or 0, self.i18n:getText(severityKey), offence.points or 0)
        if offence.offenceCode=="ROADSIDE" then
            texts[#texts]=string.format(self.i18n:getText("rff_roadside_selector"),offence.externalIncidentId or "-",offence.points or 0)
        end
        if preserveId ~= nil and (offence.id or 0) == preserveId then selected = index end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_driver_offence_none")} end
    if self.driverOffenceOption ~= nil then
        if self.driverOffenceOption.setTexts ~= nil then self.driverOffenceOption:setTexts(texts) else self.driverOffenceOption.texts = texts end
        setOptionState(self.driverOffenceOption, selected)
    end
    local selectedOffence = self:getSelectedDriverOffence()
    self.selectedDriverOffenceId = selectedOffence ~= nil and selectedOffence.id or nil
end

function RFF_FinanceFrame:getSelectedDriverOffence()
    if self.driverOffences == nil or #self.driverOffences == 0 then return nil end
    local index = self.driverOffenceOption ~= nil and (self.driverOffenceOption.state or 1) or 1
    index = math.max(1, math.min(#self.driverOffences, index))
    return self.driverOffences[index]
end

function RFF_FinanceFrame:updateDriverOffenceDetails(currentPoints)
    local selected=self:getSelectedDriverOffence()
    if self.speedingNoticeButton ~= nil then self.speedingNoticeButton:setVisible(selected ~= nil and (selected.offenceCode == "SPEEDING" or selected.offenceCode == "ROADSIDE")) end
    if self.driverOffencePointsValue ~= nil then
        self.driverOffencePointsValue:setText(string.format(self.i18n:getText("rff_compliance_points_value"), currentPoints or 0))
    end
    if self.driverOffenceDetails == nil then return end
    local offence = self:getSelectedDriverOffence()
    if offence == nil then
        self.driverOffenceDetails:setText(wrapText(self.i18n:getText("rff_driver_offence_empty_details"), 67))
        return
    end
    local periodText = (offence.incidentPeriod or 0) > 0 and self:formatTenancyPeriod(offence.incidentPeriod) or "-"
    local severityKey = "rff_driver_offence_severity_" .. string.lower(tostring(offence.severityClass or "MINOR"))
    local details = string.format(self.i18n:getText("rff_driver_offence_details"),
        offence.externalIncidentId or "-", offence.incidentDay or 0, periodText,
        offence.vehicleName or "Vehicle", offence.targetName or "another road user",
        self.i18n:getText(severityKey), offence.closingSpeedKph or 0,
        offence.points or 0)
    if offence.offenceCode == "LEGACY_POINTS" then
        details = string.format(self.i18n:getText("rff_driver_points_legacy"), offence.points or 0)
    end
    if offence.offenceCode == "SPEEDING" and self.manager.speedingEnforcement ~= nil then
        local notice=self.manager.speedingEnforcement:findNotice(offence.externalIncidentId)
        if notice ~= nil then
            details=string.format(self.i18n:getText("rff_speeding_record_details"),offence.externalIncidentId,
                offence.incidentDay or 0,periodText,offence.vehicleName,
                RFF_RoadSpeedRules.formatSpeed(notice.speedKph,self.i18n),RFF_RoadSpeedRules.formatSpeed(notice.limitKph,self.i18n),
                self:formatMoney(notice.fine or 0),notice.points or 0)
        end
    end
    if offence.offenceCode == "ROADSIDE" and self.manager.roadsideChecks ~= nil then
        local report=self.manager.roadsideChecks:findReport(offence.externalIncidentId)
        if report ~= nil then
            details=string.format(self.i18n:getText("rff_roadside_record"),offence.externalIncidentId,
                offence.incidentDay or 0,periodText,offence.vehicleName,report.findingCount,self:formatMoney(report.fine),report.points)
        end
    end
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    local status = tostring(offence.status or "ACTIVE")
    local statusText = self.i18n:getText("rff_driver_points_status_" .. string.lower(status))
    if service ~= nil and offence.pointsExpireAt ~= nil and status ~= "SERVED" then
        statusText = string.format(self.i18n:getText(status == "ACTIVE" and "rff_driver_points_expiry" or "rff_driver_points_expired"),
            service:formatRestrictionEnd(offence.pointsExpireAt))
    end
    details = details .. "\n" .. statusText
    self.driverOffenceDetails:setText(wrapText(details, 67))
end

function RFF_FinanceFrame:updateVehicleComplianceContent()
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    local fleetService = self.manager ~= nil and self.manager.fleetManagement or nil
    local farmId = self:getCurrentFarmId()
    if service == nil or fleetService == nil or farmId <= 0 then return end
    local record = service:getQualificationRecord(farmId)
    local held = self.i18n:getText("rff_compliance_held")
    local notHeld = self.i18n:getText("rff_compliance_not_held")
    local specialistRevoked = record ~= nil and record.specialistRevoked == true
    if self.complianceLicenceModeValue ~= nil then
        self.complianceLicenceModeValue:setText(self.i18n:getText(record ~= nil and record.licenceMode == "REQUIRED"
            and "rff_licence_mode_required" or "rff_licence_mode_full"))
    end
    if self.complianceCategoryBValue ~= nil then self.complianceCategoryBValue:setText(held) end
    if self.complianceCategoryFValue ~= nil then self.complianceCategoryFValue:setText(record ~= nil and record.categoryF and not specialistRevoked and held or notHeld) end
    if self.complianceCategoryHValue ~= nil then self.complianceCategoryHValue:setText(record ~= nil and record.categoryH and not specialistRevoked and held or notHeld) end
    if self.complianceCategoryCValue ~= nil then self.complianceCategoryCValue:setText(record ~= nil and record.categoryC and not specialistRevoked and held or notHeld) end
    if self.complianceAdrValue ~= nil then self.complianceAdrValue:setText(record ~= nil and record.adr and not specialistRevoked and held or notHeld) end
    if self.compliancePointsValue ~= nil then self.compliancePointsValue:setText(string.format(self.i18n:getText("rff_compliance_points_value"), record ~= nil and (record.penaltyPoints or 0) or 0)) end
    local fullLicence = record ~= nil and record.licenceMode == "FULL"
    if self.complianceSpecialistStatusValue ~= nil then
        local key = fullLicence and "rff_compliance_specialist_full"
            or specialistRevoked and "rff_compliance_specialist_revoked"
            or "rff_compliance_specialist_available"
        self.complianceSpecialistStatusValue:setText(self.i18n:getText(key))
    end
    if self.complianceQualificationNote ~= nil then
        local key = fullLicence and "rff_compliance_qualification_full_note" or "rff_compliance_qualification_foundation_note"
        self.complianceQualificationNote:setText(wrapText(self.i18n:getText(key), 62))
    end
    self:updateLicenceProcessContent(farmId, service)

    local preserveUniqueId = self.selectedVehicleComplianceUniqueId
    local fleet = fleetService:getFleet(farmId)
    self:rebuildVehicleComplianceSelector(fleet.vehicles, preserveUniqueId)
    local row = self:getSelectedVehicleComplianceRow()
    self.selectedVehicleComplianceUniqueId = row ~= nil and row.uniqueId or nil
    local assessment = row ~= nil and service:getAssessment(farmId, row.vehicle or row.uniqueId) or nil
    local empty = "-"
    if self.complianceRequiredCategoryValue ~= nil then self.complianceRequiredCategoryValue:setText(assessment ~= nil and self:getVehicleComplianceCategoryText(assessment.requiredCategory) or empty) end
    if self.complianceClassificationValue ~= nil then self.complianceClassificationValue:setText(assessment ~= nil and self:getVehicleComplianceBasisText(assessment.classificationBasis) or empty) end
    if self.complianceLocationValue ~= nil then self.complianceLocationValue:setText(assessment ~= nil and self:getVehicleUseLocationText(assessment.locationType) or empty) end
    if self.complianceEntitlementValue ~= nil then self.complianceEntitlementValue:setText(assessment ~= nil and (assessment.entitlementHeld and held or notHeld) or empty) end
    if self.complianceSpeedValue ~= nil then
        self.complianceSpeedValue:setText(assessment ~= nil and
            (RFF_RoadSpeedRules.formatSpeed(assessment.speedKmh, self.i18n) .. " / " .. RFF_RoadSpeedRules.formatSpeed(assessment.speedLimitKmh, self.i18n)) or empty)
    end
    if self.complianceWidthValue ~= nil then self.complianceWidthValue:setText(assessment ~= nil and string.format(self.i18n:getText("rff_compliance_width_value"), assessment.widthMetres or 0) or empty) end
    if self.complianceMassValue ~= nil then self.complianceMassValue:setText(assessment ~= nil and self.i18n:formatMass(assessment.grossMassTonnes or 0) or empty) end
    if self.complianceTrailerMassValue ~= nil then
        self.complianceTrailerMassValue:setText(assessment ~= nil and (assessment.hasTrailer and self.i18n:formatMass(assessment.trailerMassTonnes or 0) or self.i18n:getText("rff_compliance_no_trailer")) or empty)
    end
    if self.complianceLoadValue ~= nil then
        local loadText = self.i18n:getText("rff_compliance_no_hazardous_load")
        if assessment ~= nil and assessment.hazardousLoad then
            loadText = string.format(self.i18n:getText("rff_compliance_hazardous_load_value"), tostring(assessment.hazardousLoadName), assessment.adrHeld and held or notHeld)
        end
        self.complianceLoadValue:setText(assessment ~= nil and loadText or empty)
    end
    if self.complianceAdsValue ~= nil then
        local adsText = empty
        if assessment ~= nil then
            if assessment.adsRoadworthy == nil then adsText = self.i18n:getText("rff_compliance_ads_not_assessed")
            elseif assessment.adsRoadworthy then adsText = self.i18n:getText("rff_compliance_ads_clear")
            else adsText = string.format(self.i18n:getText("rff_compliance_ads_attention"), assessment.adsTechnical ~= nil and (assessment.adsTechnical.breakdownCount or 0) or 0) end
        end
        self.complianceAdsValue:setText(adsText)
    end
    if self.complianceInsuranceValue ~= nil then self.complianceInsuranceValue:setText(row ~= nil and self:getFleetInsuranceText(row) or empty) end
    if self.complianceOverallValue ~= nil then
        local overallKey = assessment ~= nil and "rff_compliance_overall_" .. string.lower(tostring(assessment.overallStatus or "PRIVATE_USE")) or nil
        self.complianceOverallValue:setText(overallKey ~= nil and self.i18n:getText(overallKey) or empty)
    end
    if self.complianceMovementAuthorisationButton ~= nil then
        local showAuthorisation = assessment ~= nil and assessment.widthAuthorisationRequired == true
        local activeAuthorisation = showAuthorisation and assessment.movementAuthorisationActive == true
        self.complianceMovementAuthorisationButton:setVisible(showAuthorisation)
        self.complianceMovementAuthorisationButton:setText(self.i18n:getText(activeAuthorisation
            and "rff_compliance_authorisation_active_button" or "rff_compliance_request_authorisation"))
        if self.complianceMovementAuthorisationButton.setDisabled ~= nil then
            self.complianceMovementAuthorisationButton:setDisabled(activeAuthorisation)
        end
    end
    if self.complianceAssessmentNote ~= nil then
        local note = self.i18n:getText("rff_compliance_no_vehicle_note")
        if assessment ~= nil and assessment.locationType == "ROAD" and #assessment.violations > 0 then
            local labels = {}
            for _, violation in ipairs(assessment.violations) do labels[#labels + 1] = self.i18n:getText("rff_compliance_violation_" .. string.lower(violation)) end
            note = string.format(self.i18n:getText("rff_compliance_failure_note"), table.concat(labels, ", "))
        elseif assessment ~= nil and assessment.movementAuthorisationActive then
            local remaining = self:formatMovementAuthorisationRemaining(assessment.movementAuthorisationRemainingHours or 0)
            if assessment.massAuthorisationRequired then
                note = string.format(self.i18n:getText("rff_compliance_authorisation_active_mass_note"),
                    assessment.vehicleName or "Vehicle", assessment.movementAuthorisation.authorisedWidth or assessment.widthMetres or 0, remaining)
            elseif assessment.locationType == "ROAD" then
                note = string.format(self.i18n:getText("rff_compliance_authorisation_active_note"),
                    assessment.vehicleName or "Vehicle", assessment.movementAuthorisation.authorisedWidth or assessment.widthMetres or 0, remaining)
            else
                note = string.format(self.i18n:getText("rff_compliance_authorisation_active_private_note"),
                    assessment.vehicleName or "Vehicle", assessment.movementAuthorisation.authorisedWidth or assessment.widthMetres or 0, remaining)
            end
        elseif assessment ~= nil and assessment.movementAuthorisationRequired then
            if assessment.widthAuthorisationRequired and assessment.massAuthorisationRequired then
                note = string.format(self.i18n:getText("rff_compliance_authorisation_width_mass_note"), assessment.widthMetres or 0)
            elseif assessment.widthAuthorisationRequired then
                note = string.format(self.i18n:getText("rff_compliance_authorisation_request_note"), assessment.widthMetres or 0)
            else
                note = self.i18n:getText("rff_compliance_authorisation_mass_note")
            end
        elseif assessment ~= nil and assessment.locationType ~= "ROAD" then
            note = self.i18n:getText("rff_compliance_private_use_note")
        elseif assessment ~= nil then
            note = self.i18n:getText("rff_compliance_clear_note")
        end
        self.complianceAssessmentNote:setText(wrapText(note, 62))
    end
end

function RFF_FinanceFrame:onVehicleComplianceVehicleChanged()
    local row = self:getSelectedVehicleComplianceRow()
    self.selectedVehicleComplianceUniqueId = row ~= nil and row.uniqueId or nil
    self:updateVehicleComplianceContent()
end

function RFF_FinanceFrame:onClickMovementAuthorisation()
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    local row = self:getSelectedVehicleComplianceRow()
    if service == nil or row == nil then return end
    local assessment = service:getAssessment(self:getCurrentFarmId(), row.vehicle or row.uniqueId)
    if assessment == nil or assessment.widthAuthorisationRequired ~= true or assessment.movementAuthorisationActive == true then return end
    self.pendingMovementAuthorisation = {
        uniqueId=assessment.vehicleUniqueId,
        vehicleName=assessment.vehicleName,
        width=assessment.widthMetres
    }
    YesNoDialog.show(self.onMovementAuthorisationConfirmed, self,
        string.format(self.i18n:getText("rff_compliance_authorisation_confirm"),
            assessment.vehicleName or "Vehicle", assessment.widthMetres or 0),
        self.i18n:getText("rff_compliance_authorisation_title"))
end

function RFF_FinanceFrame:onMovementAuthorisationConfirmed(confirmed)
    local pending = self.pendingMovementAuthorisation
    self.pendingMovementAuthorisation = nil
    if not confirmed or pending == nil then return end
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil then return end
    local ok, reason, authorisation = service:requestOversizeMovement(self:getCurrentFarmId(), pending.uniqueId)
    if ok then
        InfoDialog.show(string.format(self.i18n:getText("rff_compliance_authorisation_granted_popup"),
            authorisation.vehicleName or pending.vehicleName or "Vehicle"))
    elseif reason == "active" then
        InfoDialog.show(self.i18n:getText("rff_compliance_authorisation_already_active"))
    elseif reason == "width" then
        InfoDialog.show(self.i18n:getText("rff_compliance_authorisation_not_required"))
    else
        InfoDialog.show(self.i18n:getText("rff_compliance_authorisation_failed"))
    end
    self:updateVehicleComplianceContent()
end

function RFF_FinanceFrame:onLicenceCategoryChanged()
    self.selectedLicenceCategory = self:getSelectedLicenceCategory()
    self:updateVehicleComplianceContent()
end

function RFF_FinanceFrame:onLicenceModeChanged()
    if self.updatingLicenceModeOption then return end
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil then return end
    local farmId = self:getCurrentFarmId()
    local mode = self.licenceModeOption ~= nil and (self.licenceModeOption.state or 1) == 2 and "REQUIRED" or "FULL"
    local ok, reason = service:setLicenceMode(farmId, mode)
    if not ok then
        if reason == "active" then InfoDialog.show(self.i18n:getText("rff_licence_mode_active_assessment"))
        else InfoDialog.show(self.i18n:getText("rff_licence_mode_failed")) end
    elseif reason == "updated" then
        InfoDialog.show(self.i18n:getText(mode == "FULL" and "rff_licence_mode_full_confirmed" or "rff_licence_mode_required_confirmed"))
    end
    self:updateRoadComplianceSettingsContent()
    self:updateVehicleComplianceContent()
end

function RFF_FinanceFrame:onSpeedingEnforcementChanged()
    if self.updatingSpeedingOption then return end
    local service=self.manager ~= nil and self.manager.speedingEnforcement or nil
    if service == nil or self.speedingEnforcementOption == nil then return end
    local enabled=self.speedingEnforcementOption.state==2
    if service:setEnabled(self:getCurrentFarmId(),enabled) then
        InfoDialog.show(self.i18n:getText(enabled and "rff_speeding_help" or "rff_speeding_disabled_help"))
    end
    self:updateRoadComplianceSettingsContent()
end

function RFF_FinanceFrame:onRoadsideChecksChanged()
    if self.updatingRoadsideOption then return end
    local service=self.manager ~= nil and self.manager.roadsideChecks or nil
    if service==nil or self.roadsideChecksOption==nil then return end
    local enabled=self.roadsideChecksOption.state==2
    if service:setEnabled(self:getCurrentFarmId(),enabled) then
        InfoDialog.show(self.i18n:getText(enabled and "rff_roadside_help" or "rff_roadside_disabled_help"))
    end
    self:updateRoadComplianceSettingsContent()
end

function RFF_FinanceFrame:onClickSpeedingNotice()
    local offence=self:getSelectedDriverOffence()
    if offence ~= nil and offence.offenceCode=="ROADSIDE" and self.manager ~= nil and self.manager.roadsideChecks ~= nil then
        local report=self.manager.roadsideChecks:findReport(offence.externalIncidentId)
        if report ~= nil then InfoDialog.show(self.manager.roadsideChecks:getReportMessage(report)) end
        return
    end
    local service=self.manager ~= nil and self.manager.speedingEnforcement or nil
    local notice=offence ~= nil and service ~= nil and service:findNotice(offence.externalIncidentId) or nil
    if notice ~= nil then InfoDialog.show(service:getNoticeMessage(notice)) end
end

function RFF_FinanceFrame:onRoadSpeedHudChanged()
    if self.updatingRoadSpeedHudOption then return end
    local hud = self.manager ~= nil and self.manager.roadSpeedHud or nil
    if hud == nil or self.roadSpeedHudOption == nil then return end
    hud:setEnabled(self:getCurrentFarmId(),self.roadSpeedHudOption.state == 2)
    self:updateRoadComplianceSettingsContent()
end

function RFF_FinanceFrame:onInsurancePointsChanged()
    if self.updatingInsurancePointsOption then return end
    local fleet = self.manager ~= nil and self.manager.fleetManagement or nil
    if fleet == nil then return end
    fleet:setPointsInsurancePricing(self:getCurrentFarmId(), self.insurancePointsOption ~= nil and self.insurancePointsOption.state == 2)
    self:updateRoadComplianceSettingsContent()
    self:updateVehicleInsuranceQuote(self:getSelectedVehicleInsuranceRow())
end

function RFF_FinanceFrame:onDrivingPenaltiesChanged()
    if self.updatingDrivingPenaltiesOption then return end
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil then return end
    service:setDrivingPenalties(self:getCurrentFarmId(), self.drivingPenaltiesOption ~= nil and self.drivingPenaltiesOption.state == 2)
    self:updateRoadComplianceSettingsContent()
end

function RFF_FinanceFrame:onDriverOffenceChanged()
    local offence = self:getSelectedDriverOffence()
    self.selectedDriverOffenceId = offence ~= nil and offence.id or nil
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    local record = service ~= nil and service:getQualificationRecord(self:getCurrentFarmId()) or nil
    self:updateDriverOffenceDetails(record ~= nil and record.penaltyPoints or 0)
end

function RFF_FinanceFrame:onClickLicenceAssessmentAction()
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil then return end
    local farmId = self:getCurrentFarmId()
    local category = self:getSelectedLicenceCategory()
    local process = service:getLicenceProcess(farmId, category)
    if process == nil then return end
    if process.status == "NONE" or process.status == "FAILED" then
        self.pendingLicenceCategory = category
        YesNoDialog.show(self.onLicenceAssessmentBookConfirmed, self,
            string.format(self.i18n:getText(process.theoryRetake
                and "rff_licence_confirm_theory_retake" or "rff_licence_confirm_booking"), category, self:formatMoney(process.fee or 0)),
            self.i18n:getText("rff_licence_process_title"))
    elseif process.status == "BOOKED" and process.ready then
        local ok, reason = service:startAssessment(farmId, category)
        if ok then
            self:updateVehicleComplianceContent()
            if reason == "theory" then self:showLicenceTheoryQuestion()
            else InfoDialog.show(self.i18n:getText("rff_licence_vehicle_loading")) end
        elseif reason == "dealer_space" then InfoDialog.show(self.i18n:getText("rff_licence_dealer_space"))
        else InfoDialog.show(self.i18n:getText("rff_licence_start_failed")) end
    elseif process.status == "THEORY" then
        self:showLicenceTheoryQuestion()
    end
end

function RFF_FinanceFrame:onLicenceAssessmentBookConfirmed(confirmed)
    local category = self.pendingLicenceCategory
    self.pendingLicenceCategory = nil
    if not confirmed or category == nil then return end
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil then return end
    local ok, reason = service:bookAssessment(self:getCurrentFarmId(), category)
    if not ok then
        if reason == "funds" then InfoDialog.show(self.i18n:getText("rff_insufficient_funds"))
        elseif reason == "active" then InfoDialog.show(self.i18n:getText("rff_licence_other_active"))
        else InfoDialog.show(self.i18n:getText("rff_licence_booking_failed")) end
    else
        InfoDialog.show(string.format(self.i18n:getText(reason == "theory_retake_booked"
            and "rff_licence_theory_retake_booking_complete" or "rff_licence_booking_complete"), category))
    end
    self:updateVehicleComplianceContent()
end

function RFF_FinanceFrame:showLicenceTheoryQuestion()
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil then return end
    local farmId = self:getCurrentFarmId()
    local category = self:getSelectedLicenceCategory()
    local question, _, index, total = service:getTheoryQuestion(farmId, category)
    if question == nil then return end
    self.pendingLicenceTheoryCategory = category
    YesNoDialog.show(self.onLicenceTheoryAnswered, self, self.i18n:getText(question.key),
        string.format(self.i18n:getText("rff_licence_theory_title"), category, index, total))
end

function RFF_FinanceFrame:onLicenceTheoryAnswered(answer)
    local category = self.pendingLicenceTheoryCategory
    if category == nil then return end
    local service = self.manager ~= nil and self.manager.vehicleCompliance or nil
    if service == nil then return end
    local ok, _, result = service:answerTheory(self:getCurrentFarmId(), category, answer == true)
    if not ok or result == nil then
        self.pendingLicenceTheoryCategory = nil
        InfoDialog.show(self.i18n:getText("rff_licence_theory_failed_to_record"))
        return
    end
    self:updateVehicleComplianceContent()
    if result.complete then
        self.pendingLicenceTheoryCategory = nil
    else
        self:showLicenceTheoryQuestion()
    end
end

function RFF_FinanceFrame:rebuildVehicleInsuranceSelector(vehicles, preserveUniqueId)
    self.vehicleInsuranceVehicles = vehicles or {}
    local texts = {}
    local selected = 1
    for index, row in ipairs(self.vehicleInsuranceVehicles) do
        table.insert(texts, string.format("%s  -  %s", tostring(row.name or self.i18n:getText("rff_fleet_vehicle")), self:getFleetOwnershipText(row.ownership)))
        if preserveUniqueId ~= nil and tostring(row.uniqueId or "") == tostring(preserveUniqueId) then selected = index end
    end
    if #texts == 0 then texts = {self.i18n:getText("rff_vehicle_insurance_no_vehicles")} end
    if self.vehicleInsuranceVehicleOption ~= nil then
        if self.vehicleInsuranceVehicleOption.setTexts ~= nil then self.vehicleInsuranceVehicleOption:setTexts(texts) else self.vehicleInsuranceVehicleOption.texts = texts end
        setOptionState(self.vehicleInsuranceVehicleOption, selected)
    end
end

function RFF_FinanceFrame:getSelectedVehicleInsuranceRow()
    if self.vehicleInsuranceVehicles == nil or #self.vehicleInsuranceVehicles == 0 then return nil end
    local index = math.max(1, math.min(#self.vehicleInsuranceVehicles, self.vehicleInsuranceVehicleOption ~= nil and (self.vehicleInsuranceVehicleOption.state or 1) or 1))
    return self.vehicleInsuranceVehicles[index]
end

function RFF_FinanceFrame:getVehicleInsuranceCoverText(policy)
    if policy == nil then return self.i18n:getText("rff_vehicle_cover_none") end
    if policy.coverType == "THIRD_PARTY" then return self.i18n:getText("rff_vehicle_cover_third_party") end
    return self.i18n:getText("rff_vehicle_cover_comprehensive")
end

function RFF_FinanceFrame:getVehicleWeightLimitText(limit)
    limit = tonumber(limit) or 0
    if limit <= 0 then return self.i18n:getText("rff_vehicle_weight_unrestricted") end
    return string.format(self.i18n:getText("rff_vehicle_weight_limit_value"), self.i18n:formatMass(limit))
end

function RFF_FinanceFrame:getVehicleUseLocationText(locationType)
    local key = {
        ROAD = "rff_vehicle_location_road",
        FARMLAND = "rff_vehicle_location_farmland",
        OTHER = "rff_vehicle_location_other",
        UNKNOWN = "rff_vehicle_location_unknown"
    }
    return self.i18n:getText(key[tostring(locationType or "UNKNOWN")] or key.UNKNOWN)
end

function RFF_FinanceFrame:setVehicleInsuranceQuoteOptionsFromPolicy(policy, row)
    local operatingLease = row ~= nil and row.ownership == "OPERATING_LEASE"
    setOptionState(self.vehicleInsuranceQuoteCoverOption, operatingLease and 2 or (policy ~= nil and policy.coverType == "THIRD_PARTY" and 1 or 2))
    if self.vehicleInsuranceQuoteCoverOption ~= nil and self.vehicleInsuranceQuoteCoverOption.setDisabled ~= nil then
        self.vehicleInsuranceQuoteCoverOption:setDisabled(operatingLease)
    end
    setOptionState(self.vehicleInsuranceQuoteLegalOption, policy ~= nil and policy.legalCover == true and 2 or 1)
    setOptionState(self.vehicleInsuranceQuoteUseOption, policy ~= nil and policy.useScope == "FARMLAND_ONLY" and 1 or 2)
    local limit = policy ~= nil and (tonumber(policy.maxGrossWeight) or 0) or 0
    setOptionState(self.vehicleInsuranceQuoteWeightOption, limit > 0 and limit <= 15 and 1 or (limit > 15 and limit <= 30 and 2 or 3))
end

function RFF_FinanceFrame:getVehicleInsuranceQuoteSelections()
    local coverType = self.vehicleInsuranceQuoteCoverOption ~= nil and (self.vehicleInsuranceQuoteCoverOption.state or 2) == 1 and "THIRD_PARTY" or "COMPREHENSIVE"
    local legalCover = self.vehicleInsuranceQuoteLegalOption ~= nil and (self.vehicleInsuranceQuoteLegalOption.state or 1) == 2
    local useScope = self.vehicleInsuranceQuoteUseOption ~= nil and (self.vehicleInsuranceQuoteUseOption.state or 2) == 1 and "FARMLAND_ONLY" or "AGRICULTURAL_ROAD"
    local weightState = self.vehicleInsuranceQuoteWeightOption ~= nil and (self.vehicleInsuranceQuoteWeightOption.state or 3) or 3
    local maxGrossWeight = weightState == 1 and 15 or (weightState == 2 and 30 or 0)
    return coverType, legalCover, useScope, maxGrossWeight
end

function RFF_FinanceFrame:updateVehicleInsuranceQuote(row)
    local quote = nil
    local reason = "vehicle"
    if row ~= nil and self.manager ~= nil and self.manager.fleetManagement ~= nil then
        local coverType, legalCover, useScope, maxGrossWeight = self:getVehicleInsuranceQuoteSelections()
        quote, reason = self.manager.fleetManagement:getPolicyQuote(self:getCurrentFarmId(), row.uniqueId, coverType, legalCover, useScope, maxGrossWeight)
    end
    self.vehicleInsuranceQuote = quote
    local empty = "-"
    if self.vehicleInsuranceQuoteValue ~= nil then self.vehicleInsuranceQuoteValue:setText(quote ~= nil and self:formatMoney(quote.insuredValue or 0) or empty) end
    if self.vehicleInsuranceQuoteAnnualValue ~= nil then self.vehicleInsuranceQuoteAnnualValue:setText(quote ~= nil and self:formatMoney(quote.annualPremium or 0) or empty) end
    if self.vehicleInsuranceQuoteBaseValue ~= nil then self.vehicleInsuranceQuoteBaseValue:setText(quote ~= nil and self:formatMoney(quote.basePremium) or empty) end
    if self.vehicleInsuranceQuoteDiscountValue ~= nil then
        self.vehicleInsuranceQuoteDiscountValue:setText(quote ~= nil and string.format("- %s (%.0f%%)", self:formatMoney(quote.discountAmount), quote.discountRate * 100) or empty)
    end
    if self.vehicleInsuranceQuoteLoadingValue ~= nil then
        self.vehicleInsuranceQuoteLoadingValue:setText(quote ~= nil and string.format("+ %s (%.0f%%)", self:formatMoney(quote.claimsLoadingAmount), quote.claimsLoadingRate * 100) or empty)
    end
    if self.vehicleInsuranceQuotePointsValue ~= nil then
        local pointsText = empty
        if quote ~= nil then
            pointsText = quote.pointsPricingEnabled and string.format("+ %s (%.0f%%)", self:formatMoney(quote.pointsLoadingAmount), quote.pointsLoadingRate * 100)
                or self.i18n:getText("rff_insurance_points_off")
        end
        self.vehicleInsuranceQuotePointsValue:setText(pointsText)
    end
    if self.vehicleInsuranceQuotePreviousValue ~= nil then
        self.vehicleInsuranceQuotePreviousValue:setText(quote ~= nil and quote.previousAnnualPremium > 0 and self:formatMoney(quote.previousAnnualPremium) or empty)
    end
    if self.vehicleInsuranceBreakdownButton ~= nil then self.vehicleInsuranceBreakdownButton:setDisabled(quote == nil) end
    if self.vehicleInsuranceQuoteCreditValue ~= nil then self.vehicleInsuranceQuoteCreditValue:setText(quote ~= nil and self:formatMoney(quote.currentPolicyCredit or 0) or empty) end
    if self.vehicleInsuranceQuoteOutstandingValue ~= nil then self.vehicleInsuranceQuoteOutstandingValue:setText(quote ~= nil and self:formatMoney(quote.outstandingPremium or 0) or empty) end
    if self.vehicleInsuranceQuotePayableValue ~= nil then self.vehicleInsuranceQuotePayableValue:setText(quote ~= nil and self:formatMoney(quote.payableToday or 0) or empty) end
    if self.vehicleInsurancePurchaseButton ~= nil then
        self.vehicleInsurancePurchaseButton:setVisible(row ~= nil)
        if self.vehicleInsurancePurchaseButton.setDisabled ~= nil then self.vehicleInsurancePurchaseButton:setDisabled(quote == nil) end
    end
    if self.vehicleInsuranceQuoteNote ~= nil then
        local key = reason == "lease" and "rff_vehicle_quote_lease_note" or (quote == nil and "rff_vehicle_quote_unavailable_note" or (quote.lessorInterested and "rff_vehicle_quote_operating_lease_note" or "rff_vehicle_quote_note"))
        local note = self.i18n:getText(key)
        if quote ~= nil and quote.lessorInterested then
            local lessorName = quote.lessorNameKey ~= "" and self.i18n:getText(quote.lessorNameKey) or self.i18n:getText("rff_vehicle_lease_provider")
            note = string.format(note, lessorName, self.i18n:formatMass(quote.currentGrossWeight or 0))
        elseif quote ~= nil then note = string.format(note, self.i18n:formatMass(quote.currentGrossWeight or 0)) end
        self.vehicleInsuranceQuoteNote:setText(wrapText(note, 62))
    end
end

function RFF_FinanceFrame:updateVehicleInsuranceContent()
    if self.manager == nil or self.manager.fleetManagement == nil or g_currentMission == nil then return end
    local farmId = self:getCurrentFarmId()
    if farmId <= 0 then return end
    local preserveUniqueId = self.selectedVehicleInsuranceUniqueId
    local fleet = self.manager.fleetManagement:getFleet(farmId)
    self:rebuildVehicleInsuranceSelector(fleet.vehicles, preserveUniqueId)
    local row = self:getSelectedVehicleInsuranceRow()
    self.selectedVehicleInsuranceUniqueId = row ~= nil and row.uniqueId or nil
    local policy = row ~= nil and row.insurancePolicy or nil
    if preserveUniqueId == nil then self:setVehicleInsuranceQuoteOptionsFromPolicy(policy, row) end
    local empty = "-"

    local statusText = empty
    if row ~= nil then
        if row.insuranceStatus == "LEASED" then
            statusText = self.i18n:getText("rff_vehicle_policy_outside")
        else
            statusText = self.i18n:getText("rff_insurance_status_" .. string.lower(tostring(row.insuranceStatus or "UNINSURED")))
        end
    end
    if self.vehicleInsuranceStatusValue ~= nil then self.vehicleInsuranceStatusValue:setText(statusText) end
    if self.vehicleInsuranceCoverValue ~= nil then self.vehicleInsuranceCoverValue:setText(row ~= nil and self:getVehicleInsuranceCoverText(policy) or empty) end
    if self.vehicleInsuranceReferenceValue ~= nil then
        self.vehicleInsuranceReferenceValue:setText(policy ~= nil and string.format("RFF-VI-%06d", policy.id or 0) or self.i18n:getText("rff_vehicle_policy_none"))
    end
    if self.vehicleInsuranceSourceValue ~= nil then
        local sourceKey = "rff_vehicle_policy_source_rff"
        if policy ~= nil and policy.source == "MIGRATED_FARM_POLICY" then sourceKey = "rff_vehicle_policy_source_migrated"
        elseif policy ~= nil and policy.source == "DEALERSHIP_TEMPORARY" then sourceKey = "rff_vehicle_policy_source_dealership" end
        self.vehicleInsuranceSourceValue:setText(policy ~= nil and self.i18n:getText(sourceKey) or empty)
    end
    if self.vehicleInsuranceStartValue ~= nil then self.vehicleInsuranceStartValue:setText(policy ~= nil and self:formatTenancyPeriod(policy.startPeriod or 0) or empty) end
    if self.vehicleInsuranceExpiryValue ~= nil then
        local expiryText = empty
        if policy ~= nil and policy.status == "TEMPORARY" then
            expiryText = string.format(self.i18n:getText("rff_vehicle_temporary_hours_remaining"), self.manager.fleetManagement:getTemporaryCoverHoursRemaining(policy))
        elseif policy ~= nil then
            expiryText = self:formatTenancyPeriod(policy.endPeriod or 0)
        end
        self.vehicleInsuranceExpiryValue:setText(expiryText)
    end
    if self.vehicleInsuranceInsuredValue ~= nil then self.vehicleInsuranceInsuredValue:setText(policy ~= nil and self:formatMoney(policy.insuredValue or 0) or empty) end
    if self.vehicleInsurancePremiumDueValue ~= nil then self.vehicleInsurancePremiumDueValue:setText(policy ~= nil and self:formatMoney(policy.premiumDue or 0) or empty) end
    if self.vehicleInsuranceLegalCoverValue ~= nil then
        self.vehicleInsuranceLegalCoverValue:setText(policy ~= nil and self.i18n:getText(policy.legalCover == true and "rff_vehicle_policy_included" or "rff_vehicle_policy_not_included") or empty)
    end
    if self.vehicleInsuranceUseScopeValue ~= nil then
        local scopeKey = policy ~= nil and policy.useScope == "FARMLAND_ONLY" and "rff_vehicle_scope_farmland" or "rff_vehicle_scope_agricultural_road"
        self.vehicleInsuranceUseScopeValue:setText(policy ~= nil and self.i18n:getText(scopeKey) or empty)
    end
    if self.vehicleInsuranceWeightLimitValue ~= nil then self.vehicleInsuranceWeightLimitValue:setText(policy ~= nil and self:getVehicleWeightLimitText(policy.maxGrossWeight) or empty) end
    if self.vehicleInsuranceComplianceNote ~= nil then
        local compliance = row ~= nil and self.manager.fleetManagement:getPolicyCompliance(farmId, row.uniqueId) or nil
        local note = empty
        if compliance ~= nil then
            if policy == nil or compliance.inForce ~= true then
                note = self.i18n:getText("rff_vehicle_compliance_no_cover")
            elseif compliance.compliant then
                note = string.format(self.i18n:getText("rff_vehicle_compliance_ok"), self:getVehicleUseLocationText(compliance.locationType), self.i18n:formatMass(compliance.grossWeight or 0))
            else
                local reason = compliance.violations ~= nil and compliance.violations[1] or "NO_COVER"
                local reasonKey = reason == "WEIGHT_LIMIT_EXCEEDED" and "rff_vehicle_compliance_weight" or "rff_vehicle_compliance_use"
                note = string.format(self.i18n:getText(reasonKey), self:getVehicleUseLocationText(compliance.locationType), self.i18n:formatMass(compliance.grossWeight or 0), self:getVehicleWeightLimitText(compliance.weightLimit or 0))
            end
            if row ~= nil and row.ownership == "OPERATING_LEASE" then
                local lessorNameKey = policy ~= nil and policy.lessorNameKey or (row.assetAgreement ~= nil and row.assetAgreement.lenderNameKey or "")
                local lessorName = lessorNameKey ~= nil and lessorNameKey ~= "" and self.i18n:getText(lessorNameKey) or self.i18n:getText("rff_vehicle_lease_provider")
                note = string.format(self.i18n:getText("rff_vehicle_lease_policy_position"), lessorName, note)
            end
        end
        self.vehicleInsuranceComplianceNote:setText(wrapText(note, 62))
    end
    if self.vehicleInsurancePayButton ~= nil then self.vehicleInsurancePayButton:setVisible(policy ~= nil and (policy.premiumDue or 0) > 0.01) end
    if self.vehicleInsuranceAutoRenewOption ~= nil then
        self.updatingVehicleAutoRenew = true
        setOptionState(self.vehicleInsuranceAutoRenewOption, policy ~= nil and policy.autoRenew == true and 2 or 1)
        local canChange = row ~= nil and self.manager.fleetManagement:canSetAutoRenew(farmId, row.uniqueId)
        self.vehicleInsuranceAutoRenewOption:setDisabled(not canChange or (policy.autoRenew ~= true
            and (policy.status ~= "ACTIVE" or (policy.endPeriod or 0) <= self.manager.repository:getCurrentPeriodIndex())))
        self.updatingVehicleAutoRenew = false
    end

    self:updateVehicleInsuranceQuote(row)
end

function RFF_FinanceFrame:onVehicleInsuranceAutoRenewChanged()
    if self.updatingVehicleAutoRenew then return end
    local row = self:getSelectedVehicleInsuranceRow()
    local fleet = self.manager ~= nil and self.manager.fleetManagement or nil
    if row == nil or fleet == nil or self.vehicleInsuranceAutoRenewOption == nil then return end
    local enabled = self.vehicleInsuranceAutoRenewOption.state == 2
    if fleet:setAutoRenew(self:getCurrentFarmId(), row.uniqueId, enabled) and enabled then
        InfoDialog.show(self.i18n:getText("rff_vehicle_auto_renew_help"))
    end
    self:updateVehicleInsuranceContent()
end

function RFF_FinanceFrame:onClickTaxReturn()
    if self.manager == nil or self.manager.taxCompliance == nil then return end
    if g_currentMission ~= nil and g_currentMission:getIsServer() and self.manager.taxCompliance.ensureReturnForCurrentStatement ~= nil then
        self.manager.taxCompliance:ensureReturnForCurrentStatement(self:getCurrentFarmId())
    end
    self:updateBusinessAdministrationContent()
    if not RFF_TaxReturnDialog.show(self) then InfoDialog.show(self.i18n:getText("rff_tax_return_not_available")) end
end

function RFF_FinanceFrame:onClickPayTaxCompliance()
    if self.manager == nil or self.manager.taxCompliance == nil then return end
    local ok, reason = self.manager.taxCompliance:payComplianceLiability(self:getCurrentFarmId())
    if ok then InfoDialog.show(self.i18n:getText("rff_tax_compliance_payment_complete"))
    elseif reason == "funds" then InfoDialog.show(self.i18n:getText("rff_tax_compliance_insufficient_funds"))
    else InfoDialog.show(self.i18n:getText("rff_tax_compliance_nothing_due")) end
    self:updateContent()
    self:updateBusinessAdministrationContent()
end

function RFF_FinanceFrame:onInsuranceTierChanged()
    if self.manager == nil or self.manager.businessAdministration == nil then return end
    local index = self.insuranceTierOption ~= nil and (self.insuranceTierOption.state or 2) or 2
    local tier = self.insuranceTierOptions[index] or self.insuranceTierOptions[2]
    if tier ~= nil and self.insurancePremiumEstimateValue ~= nil then
        local premium = self.manager.businessAdministration:calculateInsurancePremium(self:getCurrentFarmId(), tier.id)
        self.insurancePremiumEstimateValue:setText(self:formatMoney(premium))
    end
    if tier ~= nil and self.insuranceNote ~= nil then
        self.insuranceNote:setText(self:getInsuranceCoverSummaryText(tier.id))
    end
end

function RFF_FinanceFrame:onClickSetInsuranceTier()
    if self.manager == nil or self.manager.businessAdministration == nil then return end
    local index = self.insuranceTierOption ~= nil and (self.insuranceTierOption.state or 2) or 2
    local tier = self.insuranceTierOptions[index] or self.insuranceTierOptions[2]
    if tier == nil then return end
    self.manager.businessAdministration:setInsuranceNextTier(self:getCurrentFarmId(), tier.id)
    InfoDialog.show(string.format(self.i18n:getText("rff_insurance_cover_updated"), self.i18n:getText(tier.key)))
    self:updateBusinessAdministrationContent()
end

function RFF_FinanceFrame:onClickPayInsurancePremium()
    if self.manager == nil or self.manager.businessAdministration == nil then return end
    local ok, reason = self.manager.businessAdministration:payInsurancePremium(self:getCurrentFarmId())
    if ok then
        InfoDialog.show(self.i18n:getText("rff_insurance_payment_complete"))
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_insurance_insufficient_funds"))
    else
        InfoDialog.show(self.i18n:getText("rff_insurance_nothing_due"))
    end
    self:updateContent()
    self:updateBusinessAdministrationContent()
end

function RFF_FinanceFrame:onVehicleInsuranceVehicleChanged()
    local row = self:getSelectedVehicleInsuranceRow()
    self.selectedVehicleInsuranceUniqueId = row ~= nil and row.uniqueId or nil
    self:setVehicleInsuranceQuoteOptionsFromPolicy(row ~= nil and row.insurancePolicy or nil, row)
    self:updateVehicleInsuranceContent()
end

function RFF_FinanceFrame:onVehicleInsuranceQuoteChanged()
    self:updateVehicleInsuranceQuote(self:getSelectedVehicleInsuranceRow())
end

function RFF_FinanceFrame:onClickPurchaseVehicleInsurance()
    local quote = self.vehicleInsuranceQuote
    if quote == nil then return end
    self.pendingVehicleInsuranceQuote = quote
    local coverText = quote.coverType == "THIRD_PARTY" and self.i18n:getText("rff_vehicle_cover_third_party") or self.i18n:getText("rff_vehicle_cover_comprehensive")
    local legalText = self.i18n:getText(quote.legalCover == true and "rff_vehicle_policy_included" or "rff_vehicle_policy_not_included")
    local useText = self.i18n:getText(quote.useScope == "FARMLAND_ONLY" and "rff_vehicle_scope_farmland" or "rff_vehicle_scope_agricultural_road")
    local weightText = self:getVehicleWeightLimitText(quote.maxGrossWeight)
    local text = string.format(self.i18n:getText("rff_vehicle_quote_confirm"), quote.vehicleName, coverText, legalText, useText, weightText,
        self:formatMoney(quote.annualPremium), self:formatMoney(quote.currentPolicyCredit), self:formatMoney(quote.outstandingPremium), self:formatMoney(quote.payableToday), self:formatTenancyPeriod(quote.endPeriod))
    YesNoDialog.show(self.onVehicleInsurancePurchaseConfirmed, self, text, self.i18n:getText("rff_vehicle_quote_title"))
end

function RFF_FinanceFrame:onClickVehicleInsuranceBreakdown()
    local quote = self.vehicleInsuranceQuote
    if quote == nil then return end
    local change = quote.annualPremiumChange ~= nil and
        ((quote.annualPremiumChange >= 0 and "+ " or "- ") .. self:formatMoney(math.abs(quote.annualPremiumChange))) or "-"
    local text = string.format(self.i18n:getText("rff_vehicle_pricing_breakdown_points"),
        self:formatMoney(quote.basePremium), quote.claimFreeMonths, quote.discountRate * 100, self:formatMoney(quote.discountAmount),
        quote.recentClaims, quote.claimsLoadingRate * 100, self:formatMoney(quote.claimsLoadingAmount),
        self.i18n:getText(quote.pointsPricingEnabled and "rff_insurance_points_on" or "rff_insurance_points_off"),
        quote.activePenaltyPoints, quote.pointsLoadingRate * 100, self:formatMoney(quote.pointsLoadingAmount),
        self:formatMoney(quote.annualPremium), change)
    InfoDialog.show(text)
end

function RFF_FinanceFrame:onVehicleInsurancePurchaseConfirmed(confirmed)
    local quote = self.pendingVehicleInsuranceQuote
    self.pendingVehicleInsuranceQuote = nil
    if not confirmed or quote == nil or self.manager == nil or self.manager.fleetManagement == nil then return end
    local policy, reason, finalQuote = self.manager.fleetManagement:purchasePolicy(quote.farmId, quote.vehicleUniqueId, quote.coverType, quote.legalCover, quote.useScope, quote.maxGrossWeight, quote)
    if policy == nil then
        if reason == "quote_changed" then InfoDialog.show(self.i18n:getText("rff_vehicle_pricing_quote_changed"))
        elseif reason == "funds" then InfoDialog.show(self.i18n:getText("rff_vehicle_insurance_insufficient_funds"))
        elseif reason == "lease" then InfoDialog.show(self.i18n:getText("rff_vehicle_quote_lease_note"))
        else InfoDialog.show(self.i18n:getText("rff_vehicle_quote_purchase_failed")) end
        self:updateVehicleInsuranceContent()
        return
    end
    self.selectedVehicleInsuranceUniqueId = quote.vehicleUniqueId
    self:setVehicleInsuranceQuoteOptionsFromPolicy(policy, self:getSelectedVehicleInsuranceRow())
    InfoDialog.show(string.format(self.i18n:getText("rff_vehicle_quote_purchase_complete"), finalQuote.vehicleName, self:formatMoney(finalQuote.payableToday)))
    self:updateContent()
    self:updateVehicleInsuranceContent()
    self:updateFleetContent()
end

function RFF_FinanceFrame:onClickPayVehicleInsurancePremium()
    if self.manager == nil or self.manager.fleetManagement == nil then return end
    local row = self:getSelectedVehicleInsuranceRow()
    if row == nil then return end
    local ok, reason = self.manager.fleetManagement:payPolicyPremium(self:getCurrentFarmId(), row.uniqueId)
    if ok then
        InfoDialog.show(self.i18n:getText("rff_vehicle_insurance_payment_complete"))
    elseif reason == "funds" then
        InfoDialog.show(self.i18n:getText("rff_vehicle_insurance_insufficient_funds"))
    else
        InfoDialog.show(self.i18n:getText("rff_vehicle_insurance_nothing_due"))
    end
    self:updateContent()
    self:updateVehicleInsuranceContent()
    self:updateFleetContent()
end

function RFF_FinanceFrame:onClickOpenBusinessClaims()
    self:setCategory(self.CATEGORY_BUSINESS, 3)
end

function RFF_FinanceFrame:updateAdviserContent()
    local service=self.manager and self.manager.adviser
    if service==nil or self.adviserReport==nil or self.updatingAdviser then return end
    self.updatingAdviser=true
    local farmId=self:getCurrentFarmId()
    self.adviserRecords=service:records(farmId)
    local labels,selected={},#self.adviserRecords
    for i,r in ipairs(self.adviserRecords) do
        labels[i]=string.format("FA-%d | %s | %s",r.id,RFF_EconomyService.date(r.period),r.status=="PENDING" and "In preparation" or "Delivered")
        if r.id==self.selectedAdviserId then selected=i end
    end
    self.adviserReport:setTexts(#labels>0 and labels or {"No paid reviews yet"});setOptionState(self.adviserReport,math.max(1,selected))
    local r=self.adviserRecords[selected];self.selectedAdviserId=r and r.id or nil
    local preparing=r and r.status=="PENDING"
    self.adviserSectionIndex=self.adviserSectionIndex or 1
    self.adviserSection:setTexts({"Recommendations","Cash pressure and actions","Cash and commitments","Savings and borrowing","Economic outlook","Scope and cautions","Tax books and outlook","Grant opportunities","Investments and risk"});setOptionState(self.adviserSection,self.adviserSectionIndex)
    local sections={"recommendations","actionPlan","cashAdvice","savingsAdvice","outlook","cautions","taxAdvice","grantAdvice","investmentAdvice"}
    self.adviserPriority:setText(r and r.priority or "Your farm, explained in plain language")
    self.adviserBody:setText(r and r[sections[self.adviserSectionIndex]] or "A paid review combines your recorded farm finances with the RFF economic outlook. The adviser considers working cash, bills and locked savings before discussing higher returns.\n\nThe adviser does not move savings or change agreements. Forecasts remain conditional. Select Book review to see the fee confirmation first.")
    if r and (r[sections[self.adviserSectionIndex]] or "")=="" then
        self.adviserBody:setText("This saved review predates this report section. Its original advice is still available in the other sections.\n\nA new paid review is optional if you would like updated coverage based on your current finances; the old report has not been recalculated.")
    end
    for _,key in ipairs({"cash","easy","locked","commitments","billed","reserve"}) do
        self["adviser_"..key]:setText(r and not preparing and self:formatMoney(r[key]) or "-")
    end
    self.adviserStamp:setText(r and ("Saved snapshot: "..RFF_EconomyService.date(r.period).." | Fee paid "..self:formatMoney(r.fee)) or "The figures below will show the selected paid report, not live balances.")
    self.adviserBookingNote:setText(wrapText("One-off fee: "..self:formatMoney(service.FEE).." paid on commission. Delivery takes two in-game days. Only one review can be in preparation per farm. Reading delivered reports is free.",78))
    if preparing then
        local now=service:clock()
        local remaining=now and math.max(0,(r.dueDay-now)*24) or nil
        self.adviserPriority:setText("Your review is in preparation")
        self.adviserBody:setText("Thank you for commissioning my review. I'm examining your recorded cash, commitments and the economic outlook, with Red Tape tax and grant records where available.\n\n"..(remaining and string.format("Delivery in approximately %.0f in-game hours.",math.ceil(remaining)) or "Delivery is scheduled two in-game days after commission.").." You'll receive a notification when it is ready.\n\nThe review uses your position at commission, after the fee. No further payment is due on delivery, and no savings or loans are changed automatically.")
        self.adviserStamp:setText("In preparation | Commissioned "..RFF_EconomyService.date(r.period).." | Fee paid "..self:formatMoney(r.fee))
    end
    local f=g_farmManager and g_farmManager:getFarmById(farmId)
    self.adviserBook:setDisabled(g_currentMission==nil or not g_currentMission:getIsServer() or service:quote(farmId)==nil or f==nil or f.money<service.FEE)
    self.updatingAdviser=false
end
function RFF_FinanceFrame:onAdviserReportChanged(state)
    if self.updatingAdviser then return end
    local r=(self.adviserRecords or {})[state or self.adviserReport:getState()]
    self.selectedAdviserId=r and r.id or nil;self:updateAdviserContent()
end
function RFF_FinanceFrame:onAdviserSectionChanged(state)
    if self.updatingAdviser then return end
    self.adviserSectionIndex=state or self.adviserSection:getState();self:updateAdviserContent()
end
function RFF_FinanceFrame:onAdviserBook()
    local service=self.manager.adviser
    self.pendingAdviserQuote=service:quote(self:getCurrentFarmId())
    if self.pendingAdviserQuote==nil then return end
    YesNoDialog.show(self.onAdviserConfirmed,self,"Commission a new financial review for "..self:formatMoney(self.pendingAdviserQuote.fee).."?\n\nThe fee is charged once, now. Delivery takes two in-game days and uses your position at commission. You will be notified when the report is ready, with free rereading thereafter. It is guidance, not a guarantee of future rates or income. The adviser will not move savings or change loans.","Financial adviser")
end
function RFF_FinanceFrame:onAdviserConfirmed(yes)
    local q=self.pendingAdviserQuote;self.pendingAdviserQuote=nil
    if not yes or q==nil then return end
    local r,reason=self.manager.adviser:buy(q.farmId,q)
    if r then self.selectedAdviserId=r.id;self.adviserSectionIndex=1 end
    InfoDialog.show(r and "Your review has been commissioned. Allow two in-game days for delivery; you will be notified when it is ready. The fee has been paid in full." or tostring(reason))
    self:updateAdviserContent()
end

function RFF_FinanceFrame:updateSavingsContent()
    local service=self.manager and self.manager.savings
    if service==nil or self.savingsProduct==nil or self.updatingSavings then return end
    self.updatingSavings=true
    service:process()
    self.savingsProductIndex=self.savingsProductIndex or 1
    self.savingsAmountIndex=self.savingsAmountIndex or 4
    self.savingsAmounts={100,500,1000,5000,10000,25000,50000,100000,250000,500000,1000000}
    local labels={};for _,p in ipairs(RFF_SavingsService.PRODUCTS) do labels[#labels+1]=p.name end
    self.savingsProduct:setTexts(labels);setOptionState(self.savingsProduct,self.savingsProductIndex)
    labels={};for _,v in ipairs(self.savingsAmounts) do labels[#labels+1]=self:formatMoney(v) end
    self.savingsAmount:setTexts(labels);setOptionState(self.savingsAmount,self.savingsAmountIndex)
    local p=RFF_SavingsService.PRODUCTS[self.savingsProductIndex]
    local amount=self.savingsAmounts[self.savingsAmountIndex]
    local rate=service:rate(p.id)
    self.savingsQuote={product=p.id,amount=amount,rate=rate,farmId=self:getCurrentFarmId()}
    self.savingsRate:setText(string.format("%.2f%% p.a. (%s)",rate,p.months>0 and "fixed" or "variable"))
    self.savingsAccess:setText(p.months>0 and service:date(service:clock()+p.months) or p.id=="NOTICE" and "One game month after notice" or "Withdraw at any time")
    self.savingsEstimate:setText(self:formatMoney(amount*rate/100*(p.months>0 and p.months/12 or 1))..(p.months>0 and " over full term" or " over 12 months*"))
    local f=g_farmManager and g_farmManager:getFarmById(self:getCurrentFarmId())
    self.savingsCash:setText(self:formatMoney(f and f.money or 0))
    self.savingsTotal:setText(self:formatMoney(service:total(self:getCurrentFarmId())))
    local ready=g_currentMission~=nil and g_currentMission:getIsServer() and service.repository.loaded
    self.savingsOpen:setDisabled(not ready or f==nil or f.money<amount)
    self.savingsRecords=service:records(self:getCurrentFarmId())
    labels={};local selected=1
    for i,a in ipairs(self.savingsRecords) do
        labels[i]=string.format("S-%d | %s | %s",a.id,RFF_SavingsService.product(a.product).name,a.status)
        if a.id==self.selectedSavingsId then selected=i end
    end
    self.savingsRecord:setTexts(#labels>0 and labels or {self.i18n:getText("rff_none")});setOptionState(self.savingsRecord,selected)
    local a=self.savingsRecords[selected];self.selectedSavingsId=a and a.id or nil
    self.savingsPrincipal:setText(a and self:formatMoney(a.principal) or "-")
    self.savingsInterest:setText(a and self:formatMoney(a.status=="CLOSED" and a.paidInterest or a.interest) or "-")
    self.savingsRecordRate:setText(a and string.format("%.2f%% p.a. (%s)",RFF_SavingsService.product(a.product).months>0 and a.rate or service:rate(a.product),RFF_SavingsService.product(a.product).months>0 and "fixed" or "variable") or "-")
    self.savingsOpened:setText(a and service:date(a.opened) or "-")
    self.savingsDue:setText(a and (a.status=="CLOSED" and "Returned: "..service:date(a.closed) or a.due>0 and service:date(a.due) or a.product=="NOTICE" and "Notice not yet requested" or "Available now") or "-")
    self.savingsRecordNote:setText(wrapText(a and (a.status=="CLOSED" and "This deposit has been returned. Principal and interest appear separately in the bank statement. The record is retained for your history." or a.product=="EASY" and "Withdraw closes this deposit and returns its full principal and accrued interest immediately. To save more, open another deposit." or a.product=="NOTICE" and "Request notice to return this entire deposit after one full game month. Interest continues during notice. The return is automatic; there is no early release." or "This deposit is locked at the agreed rate until maturity. Principal and interest return automatically. There is no early withdrawal or automatic reinvestment.") or "No savings deposits yet. Choose a product and amount on the left.",78))
    self.savingsWithdraw:setText(a and a.product=="NOTICE" and a.status=="ACTIVE" and "Request withdrawal notice" or "Withdraw full deposit")
    self.savingsWithdraw:setDisabled(not ready or a==nil or a.status=="CLOSED" or a.due>service:clock())
    self.updatingSavings=false
end
function RFF_FinanceFrame:onSavingsProductChanged(state)
    if self.updatingSavings then return end
    self.savingsProductIndex=state or self.savingsProduct:getState();self:updateSavingsContent()
end
function RFF_FinanceFrame:onSavingsAmountChanged(state)
    if self.updatingSavings then return end
    self.savingsAmountIndex=state or self.savingsAmount:getState();self:updateSavingsContent()
end
function RFF_FinanceFrame:onSavingsRecordChanged(state)
    if self.updatingSavings then return end
    local a=(self.savingsRecords or {})[state or self.savingsRecord:getState()]
    self.selectedSavingsId=a and a.id or nil;self:updateSavingsContent()
end
function RFF_FinanceFrame:onSavingsOpen()
    self:updateSavingsContent()
    local q=self.savingsQuote;if q==nil then return end
    self.pendingSavings=q
    local p=RFF_SavingsService.product(q.product)
    local access=p.months>0 and ("Locked until "..self.manager.savings:date(self.manager.savings:clock()+p.months)..". No early withdrawal.") or q.product=="NOTICE" and "One full game month's notice is required to withdraw." or "Withdraw the full deposit whenever needed."
    YesNoDialog.show(self.onSavingsOpenConfirmed,self,string.format("Deposit %s into %s at %.2f%% p.a. (%s)?\n\n%s\nInterest accrues on principal for actual game time and is paid on return; it does not compound. Your bank account will be debited now.",self:formatMoney(q.amount),p.name,q.rate,p.months>0 and "fixed" or "variable",access),"Savings")
    -- Include the access restriction in the confirmation, not just on the underlying page.
end
function RFF_FinanceFrame:onSavingsOpenConfirmed(yes)
    local q=self.pendingSavings;self.pendingSavings=nil
    if not yes or q==nil then return end
    local a,reason=self.manager.savings:open(q.farmId,q.product,q.amount,q.rate)
    if a then self.selectedSavingsId=a.id end
    InfoDialog.show(a and "Savings deposit opened." or tostring(reason));self:updateSavingsContent()
end
function RFF_FinanceFrame:onSavingsWithdraw()
    if self.selectedSavingsId==nil then return end
    self.pendingSavingsWithdrawal={farmId=self:getCurrentFarmId(),id=self.selectedSavingsId}
    YesNoDialog.show(self.onSavingsWithdrawConfirmed,self,"Request the return of this entire deposit under its displayed withdrawal terms? Notice savings will remain locked for one full game month.","Savings")
end
function RFF_FinanceFrame:onSavingsWithdrawConfirmed(yes)
    local q=self.pendingSavingsWithdrawal;self.pendingSavingsWithdrawal=nil
    if not yes or q==nil then return end
    local _,reason=self.manager.savings:withdraw(q.farmId,q.id)
    InfoDialog.show(reason);self:updateSavingsContent()
end

function RFF_FinanceFrame:updateInvestmentContent()
    local service=self.manager and self.manager.investments
    if not service or not self.investProduct or self.updatingInvestments then return end
    self.updatingInvestments=true;service:process()
    self.investProductIndex=self.investProductIndex or 1;self.investAmountIndex=self.investAmountIndex or 3
    self.investAmounts={100,1000,5000,10000,25000,50000,100000,250000,1000000}
    local names={};for _,p in ipairs(RFF_InvestmentService.PRODUCTS) do names[#names+1]=p.name end
    self.investProduct:setTexts(names);setOptionState(self.investProduct,self.investProductIndex)
    names={};for _,n in ipairs(self.investAmounts) do names[#names+1]=self:formatMoney(n) end
    self.investAmount:setTexts(names);setOptionState(self.investAmount,self.investAmountIndex)
    local p=RFF_InvestmentService.PRODUCTS[self.investProductIndex];local farmId=self:getCurrentFarmId()
    self.investQuote=service:quote(farmId,p.id,self.investAmounts[self.investAmountIndex])
    self.investTerms:setText(string.format("%d months + 1 month's notice",p.months))
    self.investFee:setText(string.format("%.2f%% p.a., included in value",p.fee))
    local f=g_farmManager and g_farmManager:getFarmById(farmId)
    self.investCash:setText(self:formatMoney(f and f.money or 0));self.investTotal:setText(self:formatMoney(service:total(farmId)))
    self.investRisk:setText(p.id=="CONSERVATIVE" and "Lower-risk does not mean guaranteed. This fund responds to base rates, economic activity, inflation pressure and credit conditions. Weak conditions can reduce your capital."
        or "Higher risk. Agricultural business growth responds strongly to economic activity, with inflation and tight credit weighing on returns. Prolonged downturns can cause substantial losses.")
    self.investBuy:setDisabled(self.investQuote==nil or f==nil or f.money<self.investAmounts[self.investAmountIndex])
    self.investRecords=service:records(farmId);names={};local selected=1
    for i,a in ipairs(self.investRecords) do
        names[i]=string.format("I-%d | %s | %s",a.id,RFF_InvestmentService.product(a.product).name,a.status)
        if a.id==self.selectedInvestmentId then selected=i end
    end
    self.investRecord:setTexts(#names>0 and names or {"No investments yet"});setOptionState(self.investRecord,selected)
    local a=self.investRecords[selected];self.selectedInvestmentId=a and a.id or nil
    self.investCost:setText(a and self:formatMoney(a.principal) or "-")
    self.investValue:setText(a and self:formatMoney(a.status=="CLOSED" and a.proceeds or a.value) or "-")
    self.investGain:setText(a and (self:formatMoney(a.status=="CLOSED" and a.realised or a.value-a.principal)..(a.status=="CLOSED" and " realised" or " unrealised")) or "-")
    self.investOpened:setText(a and service:date(a.opened) or "-")
    self.investUnlock:setText(a and service:date(a.unlock) or "-")
    self.investDue:setText(a and (a.status=="CLOSED" and "Sold: "..service:date(a.closed) or a.status=="NOTICE" and service:date(a.due) or "Sale not requested") or "-")
    self.investNote:setText(a and (a.status=="CLOSED" and "This holding is closed. Proceeds and realised gain/loss are retained here. Only recovered capital and any gain were paid to your bank; a loss is not a second cash debit." or a.status=="NOTICE" and "The sale is pending. Capital remains at risk until the notice ends. The final sale value, not today's value, will return automatically to the farm account." or "No automatic sale at the end of the minimum term. Request a full sale when eligible; one month's irrevocable notice then applies. The value can rise or fall during notice. No early or partial withdrawals.") or "Choose a fund and amount to begin. A risk confirmation appears before any money moves.")
    self.investSell:setDisabled(g_currentMission==nil or not g_currentMission:getIsServer() or not a or a.status~="ACTIVE" or service:clock()<a.unlock)
    self.updatingInvestments=false
end
function RFF_FinanceFrame:onInvestmentProductChanged(state)
    if self.updatingInvestments then return end
    self.investProductIndex=state or self.investProduct:getState();self:updateInvestmentContent()
end
function RFF_FinanceFrame:onInvestmentAmountChanged(state)
    if self.updatingInvestments then return end
    self.investAmountIndex=state or self.investAmount:getState();self:updateInvestmentContent()
end
function RFF_FinanceFrame:onInvestmentRecordChanged(state)
    if self.updatingInvestments then return end
    local a=(self.investRecords or {})[state or self.investRecord:getState()];self.selectedInvestmentId=a and a.id or nil;self:updateInvestmentContent()
end
function RFF_FinanceFrame:onInvestmentBuy()
    self:updateInvestmentContent();self.pendingInvestment=self.investQuote
    local q=self.pendingInvestment;if not q then return end
    local p=RFF_InvestmentService.product(q.product)
    YesNoDialog.show(self.onInvestmentBuyConfirmed,self,string.format("Invest %s in the %s?\n\nCAPITAL AT RISK: you may receive less than you invest. No guaranteed rate. Minimum holding: %d game months, then one month's notice at the final sale value. No early or partial withdrawal. Management fee %.2f%% p.a. is included in value. Your current account is debited now.",self:formatMoney(q.amount),p.name,p.months,p.fee),"Investment risk confirmation")
end
function RFF_FinanceFrame:onInvestmentBuyConfirmed(yes)
    local q=self.pendingInvestment;self.pendingInvestment=nil;if not yes or not q then return end
    local a,reason=self.manager.investments:buy(q);if a then self.selectedInvestmentId=a.id end
    InfoDialog.show(a and "Investment opened. View the holding here to track its value." or tostring(reason));self:updateInvestmentContent()
end
function RFF_FinanceFrame:onInvestmentSell()
    if not self.selectedInvestmentId then return end
    self.pendingInvestmentSale={farmId=self:getCurrentFarmId(),id=self.selectedInvestmentId}
    YesNoDialog.show(self.onInvestmentSellConfirmed,self,"Sell this entire holding after one game month's irrevocable notice?\n\nThe value remains at risk during notice. The eventual proceeds may be lower than today's value or your original investment.","Investment sale")
end
function RFF_FinanceFrame:onInvestmentSellConfirmed(yes)
    local q=self.pendingInvestmentSale;self.pendingInvestmentSale=nil;if not yes or not q then return end
    local _,reason=self.manager.investments:sell(q.farmId,q.id);InfoDialog.show(reason);self:updateInvestmentContent()
end

function RFF_FinanceFrame:updateEconomyContent()
    local service = self.manager ~= nil and self.manager.economy or nil
    local report = service ~= nil and service:report() or {}
    for _,key in ipairs({"date","activity","inflation","baseRate","credit","bankRate","review"}) do
        local element = self["economy_"..key]
        if element ~= nil then element:setText(report[key] or "-") end
    end
    for _,key in ipairs({"summary","history","outlook","borrowing","planning","scope"}) do
        local element = self["economy_"..key]
        if element ~= nil then element:setText(wrapText(report[key] or "",78)) end
    end
end

function RFF_FinanceFrame:updateCropAdvances(rebuild)
    if self.cropFieldOption == nil or self.manager.cropAdvances == nil or self.updatingCrop then return end
    self.updatingCrop=true
    local service,farm=self.manager.cropAdvances,self:getCurrentFarmId()
    service:install()
    service:processDue()
    if rebuild or self.cropFields==nil then
        self.cropFields=service:fields(farm)
        local texts={}
        for _,field in ipairs(self.cropFields) do texts[#texts+1]=tostring(field:getName()).." / Land "..tostring(field:getId()) end
        self.cropFieldOption:setTexts(#texts>0 and texts or {self.i18n:getText("rff_none")})
        self.cropFieldIndex=math.max(1,math.min(self.cropFieldIndex or 1,#self.cropFields))
        setOptionState(self.cropFieldOption,self.cropFieldIndex)
    end
    self.cropPercentIndex=self.cropPercentIndex or 2
    self.cropPercentOption:setTexts({"25%","50%","65%","80%","90%"})
    setOptionState(self.cropPercentOption,self.cropPercentIndex)
    self.cropQuote,self.cropQuoteError=service:quote(farm,self.cropFields[self.cropFieldIndex],RFF_CropAdvanceService.PERCENTAGES[self.cropPercentIndex])
    local q=self.cropQuote
    local values={"cropOfferCrop","cropOfferYield","cropOfferVolume","cropOfferReference","cropOfferPrice","cropOfferAdvance","cropOfferHarvest","cropOfferDue"}
    local texts={}
    if q~=nil then
        texts={string.format("%s / %.2f ha",q.cropTitle,q.areaHa),
            string.format("%.0f L",q.expectedLitres),string.format("%.0f L",q.committedLitres),
            self:formatMoney(q.referencePrice*1000).." / 1,000 L",
            string.format("%s / 1,000 L (%.0f%%)",self:formatMoney(q.referencePrice*q.advanceFactor*1000),q.advanceFactor*100),
            self:formatMoney(q.advance),service:date(q.harvestStart).." - "..service:date(q.harvestEnd),
            "End of "..service:date(q.duePeriod)}
    end
    for i,key in ipairs(values) do self[key]:setText(texts[i] or "-") end
    self.cropOfferNote:setText(wrapText(q~=nil and self.i18n:getText("rff_crop_offer_help") or self.cropQuoteError or "",72))
    self.cropAcceptButton:setDisabled(q==nil or g_currentMission==nil or not g_currentMission:getIsServer())
    local records=service:records(farm);self.cropRecords=records
    local labels={};local selection
    for i,a in ipairs(records) do
        labels[i]=string.format("CA-%d | %s | %s",a.id,a.cropTitle,a.status)
        if a.id==self.selectedCropAgreementId then selection=i end
    end
    selection=selection or math.max(1,#records)
    self.cropAgreementOption:setTexts(#labels>0 and labels or {self.i18n:getText("rff_none")})
    setOptionState(self.cropAgreementOption,selection)
    self.selectedCropAgreementId=records[selection] and records[selection].id or nil
    local h=service:getHistory(farm)
    self.cropHistoryNote:setText(wrapText(string.format(
        "Last five completed commitments: %d fulfilled, %d shortfalls.\nDelivery shortfall: %.0f%% | Offer price: %.0f%% of reference\nMaximum commitment: %d%%%s",
        h.successes,h.converted,h.shortfall*100,h.rate*100,h.maxPercent,h.blocked and " | New advances suspended" or ""),74))
    self.updatingCrop=false
    self:updateCropAgreement()
end

function RFF_FinanceFrame:updateCropAgreement()
    if self.cropAgreementOption==nil then return end
    local a
    for _,r in ipairs(self.cropRecords or {}) do if r.id==self.selectedCropAgreementId then a=r end end
    local names={"cropRecordStatus","cropRecordCommitted","cropRecordDelivered","cropRecordRemaining","cropRecordCleared","cropRecordExposure","cropRecordLoan","cropRecordStation"}
    local values={}
    if a~=nil then
        local remaining=math.max(0,a.committedLitres-a.deliveredLitres)
        local closed=a.status~="ACTIVE"
        values={a.status,string.format("%.0f L",a.committedLitres),string.format("%.1f L",a.deliveredLitres),
            closed and (a.status=="CONVERTED" and "Closed - converted to loan" or "0 L") or string.format("%.1f L",remaining),
            self:formatMoney(a.advance*a.deliveredLitres/a.committedLitres),
            a.status=="ACTIVE" and self:formatMoney(remaining*a.referencePrice) or self:formatMoney(0),
            (a.loanId or 0)>0 and string.format("#%d | %.1f%% fixed / %d months",a.loanId,a.interestRate,a.loanMonths) or "-",
            a.lastStation~=nil and a.lastStation~="" and a.lastStation or "-"}
    end
    for i,name in ipairs(names) do self[name]:setText(values[i] or "-") end
    local note=a and ("Due: end of "..self.manager.cropAdvances:date(a.duePeriod)..". "
        ..(a.lastMessage or "")) or self.i18n:getText("rff_crop_register_help")
    self.cropRecordNote:setText(wrapText(note,72))
end

function RFF_FinanceFrame:onCropFieldChanged(state)
    if self.updatingCrop then return end
    self.cropFieldIndex=state or self.cropFieldOption:getState()
    self:updateCropAdvances(false)
end
function RFF_FinanceFrame:onCropPercentChanged(state)
    if self.updatingCrop then return end
    self.cropPercentIndex=state or self.cropPercentOption:getState()
    self:updateCropAdvances(false)
end
function RFF_FinanceFrame:onCropAgreementChanged(state)
    if self.updatingCrop then return end
    local a=(self.cropRecords or {})[state or self.cropAgreementOption:getState()]
    self.selectedCropAgreementId=a and a.id or nil
    self:updateCropAgreement()
end
function RFF_FinanceFrame:onCropRefresh()
    self:updateCropAdvances(true)
end
function RFF_FinanceFrame:onCropAccept()
    local q=self.cropQuote
    if q==nil then return end
    self.pendingCropQuote=q
    self.pendingCropField=self.cropFields[self.cropFieldIndex]
    local text=string.format("Receive %s now for %.0f L of %s.\nDeliver by the end of %s.\nCommitted litres receive no second payment.\nShortfall price: %s per 1,000 L.\nMaximum shortfall loan: %s at 8%% fixed over 12 months.\nAccept this crop advance?",
        self:formatMoney(q.advance),q.committedLitres,q.cropTitle,self.manager.cropAdvances:date(q.duePeriod),
        self:formatMoney(q.referencePrice*1000),self:formatMoney(q.committedLitres*q.referencePrice))
    YesNoDialog.show(self.onCropAcceptConfirmed,self,text,self.i18n:getText("rff_crop_tab"))
end
function RFF_FinanceFrame:onCropAcceptConfirmed(confirmed)
    local q,field=self.pendingCropQuote,self.pendingCropField
    self.pendingCropQuote,self.pendingCropField=nil,nil
    if not confirmed or q==nil then return end
    local agreement,reason=self.manager.cropAdvances:accept(self:getCurrentFarmId(),field,q)
    if agreement~=nil then self.selectedCropAgreementId=agreement.id end
    InfoDialog.show(agreement and self.i18n:getText("rff_crop_accepted") or tostring(reason))
    self:updateCropAdvances(true)
end

function RFF_FinanceFrame:updateContent()
    if g_currentMission == nil or self.manager == nil then
        return
    end

    local farmId = self:getCurrentFarmId()
    if farmId <= 0 then
        return
    end

    local repository = self.manager.repository
    local valuation = RFF_FarmValuation:calculate(farmId, repository)
    local currentPeriodIndex = repository:getCurrentPeriodIndex()
    local currentPeriod = repository:getPeriod(farmId, currentPeriodIndex, true)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, repository)
    local snapshot, snapshotPeriod = repository:getLatestSnapshot(farmId)

    self.cashValue:setText(self:formatMoney(valuation.bankBalance ~= nil and valuation.bankBalance or valuation.cash))
    self.farmlandValue:setText(self:formatMoney(valuation.farmland))
    self.buildingsValue:setText(self:formatMoney(valuation.buildings))
    self.equipmentValue:setText(self:formatMoney(valuation.equipment))
    self.livestockValue:setText(self:formatMoney(valuation.livestock))
    self.inventoryValue:setText(self:formatMoney(valuation.inventory))
    if self.refundableDepositsValue ~= nil then self.refundableDepositsValue:setText(self:formatMoney(valuation.refundableDeposits or 0)) end
    self.totalAssetsValue:setText(self:formatMoney(valuation.totalAssets))
    self.liabilitiesValue:setText(self:formatMoney(valuation.liabilities))
    self.netWorthValue:setText(self:formatMoney(valuation.netWorth))

    local bankingService = self.manager.bankingService
    local accountPosition = bankingService ~= nil and bankingService:getAccountPosition(farmId) or nil
    if self.overviewOverdraftLimitValue ~= nil then
        local limitText = accountPosition ~= nil and accountPosition.facility ~= nil and self:formatMoney(accountPosition.limit or 0) or self.i18n:getText("rff_none")
        if accountPosition ~= nil and accountPosition.suspended then
            limitText = limitText .. " - " .. self.i18n:getText("rff_overdraft_suspended_short")
        end
        self.overviewOverdraftLimitValue:setText(limitText)
    end
    if self.overviewOverdraftUsedValue ~= nil then
        local used = accountPosition ~= nil and (accountPosition.used or 0) or 0
        local limit = accountPosition ~= nil and (accountPosition.limit or 0) or 0
        local usedText = self:formatMoney(used)
        if limit > 0.01 then
            usedText = string.format("%s  (%.0f%%)", usedText, math.min(999, used / limit * 100))
        end
        self.overviewOverdraftUsedValue:setText(usedText)
    end
    if self.overviewOverdraftAvailableValue ~= nil then
        local availableText = self:formatMoney(accountPosition ~= nil and (accountPosition.available or 0) or 0)
        if accountPosition ~= nil and (accountPosition.overLimit or 0) > 0.01 then
            availableText = string.format(self.i18n:getText("rff_overdraft_over_limit_value"), self:formatMoney(accountPosition.overLimit or 0))
        end
        self.overviewOverdraftAvailableValue:setText(availableText)
    end

    if snapshot ~= nil and snapshotPeriod ~= nil then
        self.snapshotValue:setText(self:formatMoney(snapshot.netWorth))
    else
        self.snapshotValue:setText(self.i18n:getText("rff_none"))
    end

    self:updateStatementContent(false)

    self.creditStageValue:setText(self.i18n:getText(credit.stageTextKey))
    self.collateralValue:setText(self:formatMoney(credit.collateral))
    self.debtAssetsValue:setText(self:formatPercent(credit.debtToAssets))
    self.collateralLtvValue:setText(self:formatPercent(credit.collateralLtv))
    self.securedHeadroomValue:setText(self:formatMoney(credit.securedHeadroom))
    self.incomeBasisValue:setText(self:formatMoney(credit.monthlyIncome))

    local repayment = repository:getRepaymentRecord(farmId)
    if self.creditConductValue ~= nil then self.creditConductValue:setText(self.i18n:getText(credit.conductTextKey or "rff_conduct_excellent")) end
    if self.creditArrearsValue ~= nil then self.creditArrearsValue:setText(self:formatMoney(credit.currentArrears or 0)) end
    if self.creditConsecutiveMissedValue ~= nil then self.creditConsecutiveMissedValue:setText(tostring(credit.consecutiveMissedPayments or 0)) end
    if self.creditLastMissValue ~= nil then
        if credit.monthsSinceLastMiss == nil then self.creditLastMissValue:setText(self.i18n:getText("rff_none"))
        elseif credit.monthsSinceLastMiss <= 0 then self.creditLastMissValue:setText(self.i18n:getText("rff_this_period"))
        else self.creditLastMissValue:setText(string.format(self.i18n:getText("rff_periods_ago"), credit.monthsSinceLastMiss)) end
    end
    if self.creditPaymentsValue ~= nil then self.creditPaymentsValue:setText(tostring(repayment.paymentsMade or 0)) end
    if self.creditMissedValue ~= nil then self.creditMissedValue:setText(tostring(repayment.missedPayments or 0)) end
    if self.creditCompletedValue ~= nil then self.creditCompletedValue:setText(tostring(repayment.completedAgreements or 0)) end
    if self.creditInterestPaidValue ~= nil then self.creditInterestPaidValue:setText(self:formatMoney(repayment.interestPaid or 0)) end
    if self.creditRecoveryLiabilityValue ~= nil then
        local recoveryBalance = repository.getRecoveryShortfallBalance ~= nil and repository:getRecoveryShortfallBalance(farmId) or 0
        self.creditRecoveryLiabilityValue:setText(self:formatMoney(recoveryBalance))
    end
    if self.creditMortgagePossessionsValue ~= nil then
        self.creditMortgagePossessionsValue:setText(tostring(repayment.forcedPropertyRecoveryEvents or 0))
    end
    if self.creditLastMortgagePossessionValue ~= nil then
        local months = credit.monthsSincePropertyRecovery
        if months == nil then self.creditLastMortgagePossessionValue:setText(self.i18n:getText("rff_none"))
        elseif months <= 0 then self.creditLastMortgagePossessionValue:setText(self.i18n:getText("rff_this_period"))
        else self.creditLastMortgagePossessionValue:setText(string.format(self.i18n:getText("rff_periods_ago"), months)) end
    end
    if self.creditAssessmentNote ~= nil then
        self.creditAssessmentNote:setText(wrapText(self.i18n:getText("rff_credit_note_v5"), 58))
    end

    self:updateBankingContent()
    self:updateApplicationsContent(false)
    self:updatePropertyContent()
    self:updateBrokerContent(false)
    self:updateRelationshipsContent()
    self:updateBusinessAdministrationContent()
end
