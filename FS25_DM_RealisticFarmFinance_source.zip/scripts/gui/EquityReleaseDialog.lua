RFF_EquityReleaseDialog = {}
local RFF_EquityReleaseDialog_mt = Class(RFF_EquityReleaseDialog, MessageDialog)

RFF_EquityReleaseDialog.CONTROLS = {
    "titleText", "subtitleText", "farmlandOption", "advanceOption", "termOption",
    "landValueValue", "amountValue", "rateValue", "paymentValue", "propertyLtvValue",
    "overallLtvValue", "dscrValue", "gradeValue", "decisionValue", "confirmButton"
}

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function formatMoney(value)
    return g_i18n:formatMoney(value or 0, 0, true, true)
end

local function setOptionState(option, state)
    if option == nil then return end
    if option.setState ~= nil then option:setState(state, false) else option.state = state end
end

local function wrapText(text, maxChars)
    if text == nil then return "" end
    maxChars = maxChars or 76
    local wrapped = {}
    for sourceLine in (tostring(text) .. "\n"):gmatch("(.-)\n") do
        if sourceLine == "" then
            table.insert(wrapped, "")
        else
            local line = ""
            for word in sourceLine:gmatch("%S+") do
                if line == "" then line = word
                elseif #line + #word + 1 <= maxChars then line = line .. " " .. word
                else table.insert(wrapped, line); line = word end
            end
            if line ~= "" then table.insert(wrapped, line) end
        end
    end
    return table.concat(wrapped, "\n")
end

function RFF_EquityReleaseDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or RFF_EquityReleaseDialog_mt)
    self.callbackFrame = target
    self.farmlands = {}
    self.securityOptions = {}
    self.lastEvaluation = nil
    self.pendingConfirmation = false
    return self
end

function RFF_EquityReleaseDialog:onLoad()
    RFF_EquityReleaseDialog:superClass().onLoad(self)
    self:registerControls(RFF_EquityReleaseDialog.CONTROLS)
end

function RFF_EquityReleaseDialog:onOpen()
    RFF_EquityReleaseDialog:superClass().onOpen(self)
    self:rebuildOptions()
    self:refresh()
    if self.confirmButton ~= nil then FocusManager:setFocus(self.confirmButton) end
end

function RFF_EquityReleaseDialog:onClose()
    self.pendingConfirmation = false
    RFF_EquityReleaseDialog:superClass().onClose(self)
end

function RFF_EquityReleaseDialog:configure(frame)
    local m = manager()
    if m == nil or m.propertyFinance == nil or g_currentMission == nil then return false end
    self.callbackFrame = frame
    self.farmlands = m.propertyFinance:getEquityReleaseFarmlands(g_currentMission:getFarmId())
    return #self.farmlands > 0
end

function RFF_EquityReleaseDialog:rebuildOptions()
    local m = manager()
    if m == nil or m.propertyFinance == nil or g_currentMission == nil then return end
    self.farmlands = m.propertyFinance:getEquityReleaseFarmlands(g_currentMission:getFarmId())
    self.securityOptions = {}

    local landTexts = {}
    for _, farmland in ipairs(self.farmlands) do
        local option = {mode="SINGLE", farmland=farmland, value=farmland.price or 0}
        table.insert(self.securityOptions, option)
        table.insert(landTexts, string.format("Land %d   (%s)", farmland.id or 0, formatMoney(farmland.price or 0)))
    end
    if #self.farmlands >= 2 then
        local value = 0
        for _, farmland in ipairs(self.farmlands) do value = value + math.max(0, farmland.price or 0) end
        table.insert(self.securityOptions, {mode="HOLDING", farmlands=self.farmlands, value=value, count=#self.farmlands})
        table.insert(landTexts, string.format("Whole holding land - %d parcels   (%s)", #self.farmlands, formatMoney(value)))
    end
    if self.farmlandOption ~= nil then
        self.farmlandOption:setTexts(landTexts)
        setOptionState(self.farmlandOption, 1)
    end

    local advanceTexts = {}
    for _, pct in ipairs(m.propertyFinance.EQUITY_RELEASE_ADVANCE_PCTS or {}) do table.insert(advanceTexts, string.format("%d%% of security value", pct)) end
    if self.advanceOption ~= nil then self.advanceOption:setTexts(advanceTexts); setOptionState(self.advanceOption, 3) end

    local termTexts = {}
    for _, months in ipairs(m.propertyFinance.EQUITY_RELEASE_TERMS or {}) do
        local years = math.floor(months / 12)
        table.insert(termTexts, string.format("%d year%s", years, years == 1 and "" or "s"))
    end
    if self.termOption ~= nil then self.termOption:setTexts(termTexts); setOptionState(self.termOption, 4) end
end

function RFF_EquityReleaseDialog:getSelection()
    local m = manager()
    if m == nil or m.propertyFinance == nil or #self.securityOptions == 0 then return nil,nil,nil end
    local securityIndex = math.max(1, math.min(#self.securityOptions, self.farmlandOption ~= nil and (self.farmlandOption.state or 1) or 1))
    local advanceIndex = math.max(1, math.min(#m.propertyFinance.EQUITY_RELEASE_ADVANCE_PCTS, self.advanceOption ~= nil and (self.advanceOption.state or 1) or 1))
    local termIndex = math.max(1, math.min(#m.propertyFinance.EQUITY_RELEASE_TERMS, self.termOption ~= nil and (self.termOption.state or 1) or 1))
    return self.securityOptions[securityIndex], m.propertyFinance.EQUITY_RELEASE_ADVANCE_PCTS[advanceIndex], m.propertyFinance.EQUITY_RELEASE_TERMS[termIndex]
end

function RFF_EquityReleaseDialog:onOptionChanged()
    self:refresh()
end

function RFF_EquityReleaseDialog:refresh()
    local m = manager()
    if m == nil or m.propertyFinance == nil or g_currentMission == nil then return end
    local security, pct, months = self:getSelection()
    if security == nil then
        if self.confirmButton ~= nil and self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(true) end
        return
    end
    local evaluation
    if security.mode == "HOLDING" then
        evaluation = m.propertyFinance:evaluateHoldingEquityRelease(g_currentMission:getFarmId(), pct, months)
    else
        evaluation = m.propertyFinance:evaluateEquityRelease(g_currentMission:getFarmId(), security.farmland.id, pct, months)
    end
    self.lastEvaluation = evaluation
    if self.landValueValue ~= nil then self.landValueValue:setText(formatMoney(evaluation.price or security.value or 0)) end
    if self.amountValue ~= nil then self.amountValue:setText(formatMoney(evaluation.principal or 0)) end
    if self.rateValue ~= nil then self.rateValue:setText((evaluation.interestRate or 0) > 0 and string.format("%.2f%%", evaluation.interestRate) or "-") end
    if self.paymentValue ~= nil then self.paymentValue:setText((evaluation.monthlyPayment or 0) > 0 and formatMoney(evaluation.monthlyPayment) or "-") end
    if self.propertyLtvValue ~= nil then
        self.propertyLtvValue:setText(evaluation.propertyLtv ~= nil and evaluation.propertyLtv ~= math.huge and string.format("%.1f%% / %.0f%% max", evaluation.propertyLtv * 100, (evaluation.propertyLtvLimit or 0) * 100) or "-")
    end
    if self.overallLtvValue ~= nil then self.overallLtvValue:setText(evaluation.ltv ~= nil and evaluation.ltv ~= math.huge and string.format("%.1f%%", evaluation.ltv * 100) or "-") end
    if self.dscrValue ~= nil then self.dscrValue:setText(evaluation.dscr ~= nil and evaluation.dscr ~= math.huge and string.format("%.2f", evaluation.dscr) or g_i18n:getText("rff_not_applicable")) end
    if self.gradeValue ~= nil then self.gradeValue:setText(evaluation.grade or "-") end
    if self.decisionValue ~= nil then
        local key = evaluation.approved and "rff_equity_dialog_supportable" or "rff_equity_dialog_revise"
        self.decisionValue:setText(wrapText(g_i18n:getText(key), 76))
    end
    if self.confirmButton ~= nil and self.confirmButton.setDisabled ~= nil then self.confirmButton:setDisabled(false) end
end

function RFF_EquityReleaseDialog:onClickConfirm()
    if self.pendingConfirmation then return end
    local security, pct, months = self:getSelection()
    if security == nil then return end
    local m = manager()
    local evaluation
    if security.mode == "HOLDING" then evaluation = m.propertyFinance:evaluateHoldingEquityRelease(g_currentMission:getFarmId(), pct, months)
    else evaluation = m.propertyFinance:evaluateEquityRelease(g_currentMission:getFarmId(), security.farmland.id, pct, months) end
    self.pending = {security=security,pct=pct,months=months,evaluation=evaluation}
    self.pendingConfirmation = true
    local rateText = (evaluation.interestRate or 0) > 0 and string.format("%.2f%%", evaluation.interestRate) or "-"
    local paymentText = (evaluation.monthlyPayment or 0) > 0 and formatMoney(evaluation.monthlyPayment) or "-"
    local text
    if security.mode == "HOLDING" then
        text = string.format(g_i18n:getText("rff_holding_equity_release_application_confirm"), security.count or 0, formatMoney(evaluation.price or 0), formatMoney(evaluation.principal or 0), math.floor(months / 12), rateText, paymentText)
    else
        text = string.format(g_i18n:getText("rff_equity_release_application_confirm"), security.farmland.id or 0, formatMoney(security.farmland.price or 0), formatMoney(evaluation.principal or 0), math.floor(months / 12), rateText, paymentText)
    end
    YesNoDialog.show(self.onConfirmed, self, text, g_i18n:getText("rff_equity_dialog_title"))
end

function RFF_EquityReleaseDialog:onConfirmed(accepted)
    self.pendingConfirmation = false
    if not accepted or self.pending == nil then self.pending=nil; return end
    local pending=self.pending; self.pending=nil
    local m=manager()
    if m == nil or m.applicationService == nil then return end
    local application,reason
    if pending.security.mode == "HOLDING" then
        application,reason=m.applicationService:submitHoldingEquityReleaseApplication(g_currentMission:getFarmId(), pending.pct, pending.months)
    else
        application,reason=m.applicationService:submitEquityReleaseApplication(g_currentMission:getFarmId(), pending.security.farmland.id, pending.pct, pending.months)
    end
    if application == nil then
        if reason == "existing_open_application" then InfoDialog.show(g_i18n:getText("rff_application_existing_open"))
        elseif reason == "already_mortgaged" or reason == "property_unavailable" or reason == "insufficient_security" then InfoDialog.show(g_i18n:getText("rff_equity_release_no_security"))
        else InfoDialog.show(g_i18n:getText("rff_application_submit_failed")) end
        self:rebuildOptions(); self:refresh(); return
    end
    self:close()
    local key = application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" and "rff_holding_equity_release_application_submitted" or "rff_equity_release_application_submitted"
    InfoDialog.show(string.format(g_i18n:getText(key), application.id or 0))
    if self.callbackFrame ~= nil and self.callbackFrame.updateContent ~= nil then self.callbackFrame:updateContent() end
end

function RFF_EquityReleaseDialog:onClickBack()
    self:close()
end

function RFF_EquityReleaseDialog.show(frame)
    local gui=g_gui ~= nil and g_gui.guis ~= nil and g_gui.guis["RFFEquityReleaseDialog"] or nil
    if gui == nil or gui.target == nil then return false end
    if not gui.target:configure(frame) then return false end
    g_gui:showDialog("RFFEquityReleaseDialog")
    return true
end
