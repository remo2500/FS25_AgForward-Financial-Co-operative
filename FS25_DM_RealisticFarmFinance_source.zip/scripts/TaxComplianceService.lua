RFF_TaxComplianceService = {}
RFF_TaxComplianceService.__index = RFF_TaxComplianceService

-- Red Tape closes the preceding tax year and creates its annual statement in April.
-- RFF turns that closed set of books into a player-filed return. If the return is
-- still open when May begins, the recorded books stand and a late-filing penalty is raised.
RFF_TaxComplianceService.RETURN_MONTH = 4
RFF_TaxComplianceService.LATE_MONTH = 5
RFF_TaxComplianceService.PAYMENT_MONTH = 9
RFF_TaxComplianceService.INCOME_FACTORS = {1.00, 0.98, 0.95, 0.90, 0.80}
RFF_TaxComplianceService.EXPENSE_FACTORS = {1.00, 1.02, 1.05, 1.10, 1.20}
RFF_TaxComplianceService.COMPLIANCE_LATE_INTEREST = 0.005

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local function clamp(value, minValue, maxValue)
    return math.max(minValue, math.min(maxValue, value))
end

local function isPlayableFarm(farmId)
    if farmId == nil or farmId <= 0 then return false end
    if FarmManager ~= nil and FarmManager.SPECTATOR_FARM_ID ~= nil and farmId == FarmManager.SPECTATOR_FARM_ID then return false end
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    if farm == nil or farm.isSpectator == true then return false end
    return true
end

local function copyNotes(notes)
    local result = {}
    for _, note in ipairs(notes or {}) do table.insert(result, note) end
    return result
end

function RFF_TaxComplianceService.new(repository, businessAdministration)
    local self = setmetatable({}, RFF_TaxComplianceService)
    self.repository = repository
    self.businessAdministration = businessAdministration
    self.redTapeHookInstalled = false
    self._originalStoreTaxStatement = nil
    return self
end

function RFF_TaxComplianceService:getFarmState(farmId, create)
    local state = self.repository ~= nil and self.repository:getFarmState(farmId, create) or nil
    if state == nil then return nil end
    state.taxReturnYear = math.floor(safeNumber(state.taxReturnYear))
    state.taxReturnStatus = state.taxReturnStatus or "NONE"
    state.taxReturnOpenPeriod = math.floor(safeNumber(state.taxReturnOpenPeriod))
    state.taxReturnFiledPeriod = math.floor(safeNumber(state.taxReturnFiledPeriod))
    state.taxReturnMethod = state.taxReturnMethod or "NONE"
    state.taxReturnSignedBy = type(state.taxReturnSignedBy) == "string" and state.taxReturnSignedBy or ""
    state.taxReturnBookIncome = math.max(0, safeNumber(state.taxReturnBookIncome))
    state.taxReturnBookTaxedIncome = math.max(0, safeNumber(state.taxReturnBookTaxedIncome))
    state.taxReturnBookExpenses = math.max(0, safeNumber(state.taxReturnBookExpenses))
    state.taxReturnBookTax = math.max(0, safeNumber(state.taxReturnBookTax))
    state.taxReturnLossRollover = math.max(0, safeNumber(state.taxReturnLossRollover)) -- rollover entering the filed year
    state.taxReturnTaxRate = math.max(0, safeNumber(state.taxReturnTaxRate))
    state.taxReturnIncomeFactor = clamp(safeNumber(state.taxReturnIncomeFactor) > 0 and state.taxReturnIncomeFactor or 1, 0.1, 2)
    state.taxReturnExpenseFactor = clamp(safeNumber(state.taxReturnExpenseFactor) > 0 and state.taxReturnExpenseFactor or 1, 0.1, 3)
    state.taxReturnDeclaredIncome = math.max(0, safeNumber(state.taxReturnDeclaredIncome))
    state.taxReturnDeclaredTaxedIncome = math.max(0, safeNumber(state.taxReturnDeclaredTaxedIncome))
    state.taxReturnDeclaredExpenses = math.max(0, safeNumber(state.taxReturnDeclaredExpenses))
    state.taxReturnFiledTax = math.max(0, safeNumber(state.taxReturnFiledTax))
    state.taxReturnTaxSaving = safeNumber(state.taxReturnTaxSaving)
    state.taxReturnAdjustment = safeNumber(state.taxReturnAdjustment)
    state.taxReturnAdjustmentApplied = state.taxReturnAdjustmentApplied == true
    state.taxReturnAccountantFee = math.max(0, safeNumber(state.taxReturnAccountantFee))
    state.taxReturnWasForcedTest = state.taxReturnWasForcedTest == true
    state.taxComplianceFlags = math.max(0, math.floor(safeNumber(state.taxComplianceFlags)))
    state.taxComplianceCleanFilings = math.max(0, math.floor(safeNumber(state.taxComplianceCleanFilings)))
    state.taxComplianceAggressiveFilings = math.max(0, math.floor(safeNumber(state.taxComplianceAggressiveFilings)))
    state.taxComplianceLiability = math.max(0, safeNumber(state.taxComplianceLiability))
    state.taxComplianceLastInterestPeriod = math.floor(safeNumber(state.taxComplianceLastInterestPeriod))
    state.taxInvestigationStatus = state.taxInvestigationStatus or "NONE"
    state.taxInvestigationStartPeriod = math.floor(safeNumber(state.taxInvestigationStartPeriod))
    state.taxInvestigationOutcomePeriod = math.floor(safeNumber(state.taxInvestigationOutcomePeriod))
    state.taxInvestigationLastOutcome = state.taxInvestigationLastOutcome or "NONE"
    state.taxInvestigationAdjustment = math.max(0, safeNumber(state.taxInvestigationAdjustment))
    state.taxInvestigationPenalty = math.max(0, safeNumber(state.taxInvestigationPenalty))
    state.taxInvestigationInterest = math.max(0, safeNumber(state.taxInvestigationInterest))
    return state
end

function RFF_TaxComplianceService:getRedTapeTaxSystem()
    local rt = g_currentMission ~= nil and g_currentMission.RedTape or nil
    if rt == nil or rt.TaxSystem == nil or rt.settings == nil or rt.settings.taxEnabled ~= true then return nil end
    return rt.TaxSystem
end

function RFF_TaxComplianceService:getCurrentMonth()
    if RedTape ~= nil and RedTape.periodToMonth ~= nil and g_currentMission ~= nil and g_currentMission.environment ~= nil then
        return RedTape.periodToMonth(g_currentMission.environment.currentPeriod)
    end
    return nil
end

function RFF_TaxComplianceService:getTaxYear()
    if RedTape ~= nil and RedTape.getActualYear ~= nil then return RedTape.getActualYear() end
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return env ~= nil and (env.currentYear or 0) or 0
end

function RFF_TaxComplianceService:getCurrentPeriod()
    return self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
end

function RFF_TaxComplianceService:getLatestTaxStatement(farmId)
    local taxSystem = self:getRedTapeTaxSystem()
    if taxSystem == nil then return nil end
    local latest = nil
    local latestMonth = -math.huge
    local latestIndex = -1
    for index, statement in ipairs(taxSystem.taxStatements or {}) do
        if statement ~= nil and statement.farmId == farmId then
            local month = type(statement.month) == "number" and statement.month or nil
            if latest == nil or (month ~= nil and month > latestMonth) or (month == nil and latestMonth == -math.huge and index > latestIndex) then
                latest = statement
                latestMonth = month or -math.huge
                latestIndex = index
            end
        end
    end
    return latest
end

function RFF_TaxComplianceService:getCurrentBookEstimate(farmId)
    local taxSystem = self:getRedTapeTaxSystem()
    if taxSystem == nil or taxSystem.getCurrentYearTaxToDate == nil then return nil end
    local ok, statement = pcall(taxSystem.getCurrentYearTaxToDate, taxSystem, farmId)
    return ok and statement or nil
end

function RFF_TaxComplianceService:calculateAccountantFee(farmId)
    local counts = self.businessAdministration ~= nil and self.businessAdministration:getOwnedCounts(farmId) or {}
    local financeCount = (counts.loans or 0) + (counts.tenancies or 0) + (counts.assetFinance or 0)
    local fee = 500 + (counts.farmland or 0) * 20 + (counts.placeables or 0) * 8 + (counts.vehicles or 0) * 6 + financeCount * 25
    return math.floor(clamp(fee, 500, 3000) + 0.5)
end

function RFF_TaxComplianceService:calculateDeclaredTaxValues(state, declaredIncome, declaredExpenses)
    declaredIncome = math.max(0, safeNumber(declaredIncome))
    declaredExpenses = math.max(0, safeNumber(declaredExpenses))

    -- Red Tape's closed statement exposes total taxable receipts and the amount actually
    -- subject to tax after its own allowances/rates. Preserve that same effective ratio
    -- when the player manually enters a different income figure on the paper return.
    local bookIncome = math.max(0, safeNumber(state.taxReturnBookIncome))
    local bookTaxedIncome = math.max(0, safeNumber(state.taxReturnBookTaxedIncome))
    local taxedRatio = bookIncome > 0.001 and (bookTaxedIncome / bookIncome) or 1
    taxedRatio = clamp(taxedRatio, 0, 2)
    local declaredTaxedIncome = declaredIncome * taxedRatio

    local base = declaredTaxedIncome - declaredExpenses
    local rollover = math.min(math.max(0, state.taxReturnLossRollover or 0), math.max(0, base))
    local taxable = math.max(0, base - rollover)
    local tax = math.floor(taxable * math.max(0, state.taxReturnTaxRate or 0) + 0.0001)
    return {
        declaredIncome = declaredIncome,
        declaredTaxedIncome = declaredTaxedIncome,
        declaredExpenses = declaredExpenses,
        taxableProfit = taxable,
        tax = tax,
        saving = math.max(0, (state.taxReturnBookTax or 0) - tax),
        baseDiscrepancy = math.max(0, (state.taxReturnBookTaxedIncome - declaredTaxedIncome) + (declaredExpenses - state.taxReturnBookExpenses))
    }
end

function RFF_TaxComplianceService:calculateDeclaredTax(state, incomeFactor, expenseFactor)
    incomeFactor = incomeFactor or 1
    expenseFactor = expenseFactor or 1
    return self:calculateDeclaredTaxValues(
        state,
        math.max(0, state.taxReturnBookIncome * incomeFactor),
        math.max(0, state.taxReturnBookExpenses * expenseFactor)
    )
end

function RFF_TaxComplianceService:getStartingRolloverFromStatement(farmId, statement)
    local taxSystem = self:getRedTapeTaxSystem()
    local ending = taxSystem ~= nil and taxSystem.lossRollover ~= nil and math.max(0, safeNumber(taxSystem.lossRollover[farmId])) or 0
    local generated = math.max(0, safeNumber(statement ~= nil and statement.lossRolloverGenerated or 0))
    local used = math.max(0, safeNumber(statement ~= nil and statement.lossRolloverUsed or 0))
    if generated > 0 then return math.max(0, ending - generated) end
    if used > 0 then return ending + used end
    return ending
end

function RFF_TaxComplianceService:isCurrentAnnualStatement(statement)
    -- Red Tape keeps an annual assessment unpaid until its own September collection.
    -- That unpaid flag is the authoritative signal RFF needs: if an annual assessment
    -- exists and is not paid, the return must remain available for filing/viewing.
    return statement ~= nil and statement.paid ~= true
end

function RFF_TaxComplianceService:ensureReturnForCurrentStatement(farmId)
    if not isPlayableFarm(farmId) then return nil, "farm" end
    local state = self:getFarmState(farmId, true)
    if state == nil then return nil, "state" end
    if state.taxReturnStatus ~= nil and state.taxReturnStatus ~= "NONE" and state.taxReturnWasForcedTest ~= true then
        return state, "existing"
    end
    local statement = self:getLatestTaxStatement(farmId)
    if not self:isCurrentAnnualStatement(statement) then return nil, "no_current_statement" end
    return self:createReturnTaskFromStatement(farmId, statement, false)
end

function RFF_TaxComplianceService:createReturnTaskFromStatement(farmId, statement, forceTest)
    if statement == nil or not isPlayableFarm(farmId) then return nil, "statement" end
    if not forceTest and not self:isCurrentAnnualStatement(statement) then
        return nil, "stale_statement"
    end
    local state = self:getFarmState(farmId, true)
    local year = self:getTaxYear()
    if not forceTest and state.taxReturnYear == year and state.taxReturnStatus ~= "NONE" and state.taxReturnWasForcedTest ~= true then
        return state, "existing"
    end

    state.taxReturnYear = year
    state.taxReturnStatus = "OPEN"
    state.taxReturnOpenPeriod = self:getCurrentPeriod()
    state.taxReturnFiledPeriod = 0
    state.taxReturnMethod = "NONE"
    state.taxReturnSignedBy = ""
    state.taxReturnBookIncome = math.max(0, safeNumber(statement.totalTaxableIncome))
    state.taxReturnBookTaxedIncome = math.max(0, safeNumber(statement.totalTaxedIncome))
    state.taxReturnBookExpenses = math.max(0, safeNumber(statement.totalExpenses))
    state.taxReturnBookTax = math.max(0, safeNumber(statement.totalTax))
    state.taxReturnLossRollover = self:getStartingRolloverFromStatement(farmId, statement)
    state.taxReturnTaxRate = math.max(0, safeNumber(statement.taxRate))
    state.taxReturnIncomeFactor = 1
    state.taxReturnExpenseFactor = 1
    state.taxReturnDeclaredIncome = state.taxReturnBookIncome
    state.taxReturnDeclaredTaxedIncome = state.taxReturnBookTaxedIncome
    state.taxReturnDeclaredExpenses = state.taxReturnBookExpenses
    state.taxReturnFiledTax = state.taxReturnBookTax
    state.taxReturnTaxSaving = 0
    state.taxReturnAdjustment = 0
    state.taxReturnAdjustmentApplied = false
    state.taxReturnAccountantFee = self:calculateAccountantFee(farmId)
    state.taxReturnWasForcedTest = forceTest == true
    state.taxInvestigationStatus = "NONE"
    state.taxInvestigationStartPeriod = 0
    state.taxInvestigationOutcomePeriod = 0

    self:notifyBusiness(farmId, "rff_phone_title_tax_return", "Annual Tax Return", "rff_tax_return_ready_phone",
        "The annual farm accounts have been closed. Review and submit the Farm Business Tax Return before the filing deadline.")
    return state, "created"
end

function RFF_TaxComplianceService:onRedTapeStatementStored(statement)
    if statement == nil or not isPlayableFarm(statement.farmId) then return end
    -- Only create a natural return when Red Tape is producing the annual April statement.
    if self:getCurrentMonth() == self.RETURN_MONTH then
        self:createReturnTaskFromStatement(statement.farmId, statement, false)
    end
end

function RFF_TaxComplianceService:updateRedTapeStatement(farmId, calc, restoreBooks)
    local taxSystem = self:getRedTapeTaxSystem()
    local statement = self:getLatestTaxStatement(farmId)
    local state = self:getFarmState(farmId, true)
    if taxSystem == nil or statement == nil or state == nil then return false end

    local income = restoreBooks and state.taxReturnBookIncome or calc.declaredIncome
    local taxedIncome = restoreBooks and state.taxReturnBookTaxedIncome or calc.declaredTaxedIncome
    local expenses = restoreBooks and state.taxReturnBookExpenses or calc.declaredExpenses
    local tax = restoreBooks and state.taxReturnBookTax or calc.tax
    local base = taxedIncome - expenses
    local startingRollover = math.max(0, state.taxReturnLossRollover or 0)
    local endingRollover = startingRollover
    local used, generated = 0, 0
    if base < 0 then
        generated = math.abs(base)
        endingRollover = math.min(5000000, startingRollover + generated)
    else
        used = math.min(startingRollover, base)
        endingRollover = math.max(0, startingRollover - used)
    end

    statement.totalTaxableIncome = math.floor(income + 0.5)
    statement.totalTaxedIncome = math.floor(taxedIncome + 0.5)
    statement.totalExpenses = math.floor(expenses + 0.5)
    statement.totalTax = math.floor(tax + 0.5)
    statement.lossRolloverUsed = math.floor(used + 0.5)
    statement.lossRolloverGenerated = math.floor(generated + 0.5)
    taxSystem.lossRollover[farmId] = endingRollover

    if RTNewTaxStatementEvent ~= nil and g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(RTNewTaxStatementEvent.new(statement))
    elseif g_currentMission ~= nil and g_currentMission:getIsServer() then
        taxSystem:storeTaxStatement(statement)
        if g_server ~= nil and RTNewTaxStatementEvent ~= nil then g_server:broadcastEvent(RTNewTaxStatementEvent.new(statement), false) end
    end
    return true
end

function RFF_TaxComplianceService:calculateAuditRisk(state)
    if state.taxReturnMethod == "ACCOUNTANT" then return 0.005 end
    local bookScale = math.max(25000, state.taxReturnBookTaxedIncome + state.taxReturnBookExpenses)
    local discrepancy = math.max(0, -safeNumber(state.taxReturnAdjustment))
    local ratio = discrepancy / bookScale
    local risk = 0.015 + (state.taxComplianceFlags or 0) * 0.035 + math.min(0.12, (state.taxComplianceAggressiveFilings or 0) * 0.02)
    if discrepancy > 0.5 then
        risk = risk + 0.05 + math.min(0.60, ratio * 1.8)
        if discrepancy > 50000 then risk = risk + 0.08 end
        if discrepancy > 100000 then risk = risk + 0.10 end
    end
    return clamp(risk, 0, 0.85)
end

function RFF_TaxComplianceService:scheduleInvestigation(state)
    local risk = self:calculateAuditRisk(state)
    if math.random() < risk then
        state.taxInvestigationStatus = "SCHEDULED"
        state.taxInvestigationStartPeriod = self:getCurrentPeriod() + math.random(2, 6)
        state.taxInvestigationOutcomePeriod = 0
        return true
    end
    return false
end

function RFF_TaxComplianceService:submitReturnValues(farmId, method, declaredIncome, declaredExpenses, autoLate, signedBy)
    local state = self:getFarmState(farmId, true)
    if state == nil or state.taxReturnStatus ~= "OPEN" then return false, "not_open" end
    if self:getRedTapeTaxSystem() == nil then return false, "tax_unavailable" end

    method = method == "ACCOUNTANT" and "ACCOUNTANT" or "SELF"
    if method == "ACCOUNTANT" and not autoLate then
        local fee = math.max(0, state.taxReturnAccountantFee or self:calculateAccountantFee(farmId))
        if fee > 0 and (self.businessAdministration == nil or not self.businessAdministration:charge(farmId, fee, "Accountant preparation of annual tax return")) then
            return false, "funds"
        end
        declaredIncome = state.taxReturnBookIncome
        declaredExpenses = state.taxReturnBookExpenses
    elseif autoLate then
        declaredIncome = state.taxReturnBookIncome
        declaredExpenses = state.taxReturnBookExpenses
    end

    declaredIncome = clamp(safeNumber(declaredIncome), 0, 99999999)
    declaredExpenses = clamp(safeNumber(declaredExpenses), 0, 99999999)
    local calc = self:calculateDeclaredTaxValues(state, declaredIncome, declaredExpenses)
    local desiredBase = calc.declaredTaxedIncome - calc.declaredExpenses
    local bookBase = state.taxReturnBookTaxedIncome - state.taxReturnBookExpenses
    local adjustment = desiredBase - bookBase

    if not state.taxReturnWasForcedTest then
        if not self:updateRedTapeStatement(farmId, calc, false) then return false, "statement" end
        state.taxReturnAdjustmentApplied = true
    end

    local bookIncome = math.max(0, safeNumber(state.taxReturnBookIncome))
    local bookExpenses = math.max(0, safeNumber(state.taxReturnBookExpenses))
    local incomeFactor = bookIncome > 0.001 and calc.declaredIncome / bookIncome or 1
    local expenseFactor = bookExpenses > 0.001 and calc.declaredExpenses / bookExpenses or 1

    state.taxReturnStatus = autoLate and "LATE_FILED" or "FILED"
    state.taxReturnFiledPeriod = self:getCurrentPeriod()
    state.taxReturnMethod = autoLate and "AUTHORITY" or method
    state.taxReturnSignedBy = autoLate and "" or (type(signedBy) == "string" and signedBy or "")
    state.taxReturnIncomeFactor = incomeFactor
    state.taxReturnExpenseFactor = expenseFactor
    state.taxReturnDeclaredIncome = calc.declaredIncome
    state.taxReturnDeclaredTaxedIncome = calc.declaredTaxedIncome
    state.taxReturnDeclaredExpenses = calc.declaredExpenses
    state.taxReturnFiledTax = calc.tax
    state.taxReturnTaxSaving = calc.saving
    state.taxReturnAdjustment = adjustment

    local dishonest = adjustment < -0.5
    if not dishonest then
        state.taxComplianceCleanFilings = (state.taxComplianceCleanFilings or 0) + 1
        state.taxComplianceAggressiveFilings = math.max(0, (state.taxComplianceAggressiveFilings or 0) - 1)
        if state.taxComplianceCleanFilings >= 2 and (state.taxComplianceFlags or 0) > 0 then
            state.taxComplianceFlags = math.max(0, state.taxComplianceFlags - 1)
            state.taxComplianceCleanFilings = 0
        end
    else
        state.taxComplianceCleanFilings = 0
        state.taxComplianceAggressiveFilings = (state.taxComplianceAggressiveFilings or 0) + 1
    end

    if not autoLate then self:scheduleInvestigation(state) end
    return true, "filed"
end

function RFF_TaxComplianceService:submitReturn(farmId, method, incomeFactor, expenseFactor, autoLate)
    local state = self:getFarmState(farmId, true)
    if state == nil then return false, "state" end
    incomeFactor = incomeFactor or 1
    expenseFactor = expenseFactor or 1
    return self:submitReturnValues(
        farmId, method,
        math.max(0, state.taxReturnBookIncome * incomeFactor),
        math.max(0, state.taxReturnBookExpenses * expenseFactor),
        autoLate
    )
end

function RFF_TaxComplianceService:addComplianceLiability(farmId, amount)
    local state = self:getFarmState(farmId, true)
    if state == nil then return end
    state.taxComplianceLiability = math.max(0, state.taxComplianceLiability or 0) + math.max(0, amount or 0)
    state.taxComplianceLastInterestPeriod = self:getCurrentPeriod()
end

function RFF_TaxComplianceService:chargeNonDeductible(farmId, amount, description)
    amount = math.max(0, amount or 0)
    if amount <= 0 then return true end
    if self.businessAdministration == nil or self.businessAdministration:getAvailableFunds(farmId) + 0.001 < amount then return false end
    if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(farmId, description) end
    g_currentMission:addMoney(-amount, farmId, MoneyType ~= nil and MoneyType.OTHER or nil, true, true)
    return true
end

function RFF_TaxComplianceService:payComplianceLiability(farmId)
    local state = self:getFarmState(farmId, true)
    if state == nil or state.taxComplianceLiability <= 0.01 then return false, "nothing_due" end
    local amount = state.taxComplianceLiability
    if not self:chargeNonDeductible(farmId, amount, "Tax investigation settlement and penalties") then return false, "funds" end
    state.taxComplianceLiability = 0
    state.taxComplianceLastInterestPeriod = self:getCurrentPeriod()
    self:notifyRevenue(farmId, "rff_phone_title_tax_compliance", "Revenue Compliance", "rff_tax_compliance_paid_phone",
        "The outstanding tax compliance balance of %s has been paid in full.", g_i18n:formatMoney(amount, 0, true, true))
    return true, "paid"
end

function RFF_TaxComplianceService:applyLateFiling(farmId)
    local state = self:getFarmState(farmId, true)
    if state == nil or state.taxReturnStatus ~= "OPEN" then return end
    local penalty = math.floor(250 + math.min(750, (state.taxReturnBookIncome + state.taxReturnBookExpenses) * 0.001) + 0.5)
    self:addComplianceLiability(farmId, penalty)
    self:submitReturn(farmId, "SELF", 1, 1, true)
    self:notifyRevenue(farmId, "rff_phone_title_tax_compliance", "Revenue Compliance", "rff_tax_return_late_phone",
        "The annual return was not submitted by the filing deadline. The recorded books remain as filed and a late-filing penalty of %s has been added to the farm account.", g_i18n:formatMoney(penalty, 0, true, true))
end

function RFF_TaxComplianceService:installRedTapeHook()
    if self.redTapeHookInstalled or RTTaxSystem == nil or RTTaxSystem.storeTaxStatement == nil then return false end
    local service = self
    local original = RTTaxSystem.storeTaxStatement
    self._originalStoreTaxStatement = original
    RTTaxSystem.storeTaxStatement = function(taxSystem, statement, ...)
        local result = original(taxSystem, statement, ...)
        if service ~= nil then service:onRedTapeStatementStored(statement) end
        return result
    end
    self.redTapeHookInstalled = true
    return true
end

function RFF_TaxComplianceService:restoreRedTapeHook()
    if self.redTapeHookInstalled and self._originalStoreTaxStatement ~= nil and RTTaxSystem ~= nil then
        RTTaxSystem.storeTaxStatement = self._originalStoreTaxStatement
    end
    self.redTapeHookInstalled = false
    self._originalStoreTaxStatement = nil
end

function RFF_TaxComplianceService:notifyBusiness(farmId, titleKey, fallbackTitle, textKey, fallbackText, ...)
    if RFF_NotificationService == nil then return false end
    local message = RFF_NotificationService:formatText(textKey, fallbackText, ...)
    local sender = RFF_NotificationService:getText("rff_phone_sender_business", "Farm Business Office")
    local title = RFF_NotificationService:getText(titleKey, fallbackTitle)
    return RFF_NotificationService:send(farmId, sender, title, message, "tax", message, true)
end

function RFF_TaxComplianceService:notifyRevenue(farmId, titleKey, fallbackTitle, textKey, fallbackText, ...)
    if RFF_NotificationService == nil then return false end
    local message = RFF_NotificationService:formatText(textKey, fallbackText, ...)
    local sender = RFF_NotificationService:getText("rff_phone_sender_revenue", "Revenue Compliance Office")
    local title = RFF_NotificationService:getText(titleKey, fallbackTitle)
    return RFF_NotificationService:send(farmId, sender, title, message, "taxCompliance", message, true)
end

function RFF_TaxComplianceService:processInvestigation(farmId, current)
    local state = self:getFarmState(farmId, true)
    if state == nil then return end
    if state.taxInvestigationStatus == "SCHEDULED" and current >= (state.taxInvestigationStartPeriod or 0) then
        state.taxInvestigationStatus = "OPEN"
        state.taxInvestigationOutcomePeriod = current + math.random(1, 2)
        self:notifyRevenue(farmId, "rff_phone_title_tax_investigation", "Tax Return Review", "rff_tax_investigation_open_phone",
            "Your Year %d Farm Business Tax Return has been selected for a compliance review. Keep sufficient funds available pending the outcome.", state.taxReturnYear or 0)
    elseif state.taxInvestigationStatus == "OPEN" and current >= (state.taxInvestigationOutcomePeriod or 0) then
        self:resolveInvestigation(farmId)
    end
end

function RFF_TaxComplianceService:resolveInvestigation(farmId)
    local state = self:getFarmState(farmId, true)
    if state == nil then return false end
    local discrepancy = math.max(0, -(state.taxReturnAdjustment or 0))
    local bookScale = math.max(25000, state.taxReturnBookTaxedIncome + state.taxReturnBookExpenses)
    local ratio = discrepancy / bookScale
    local detected = false
    if discrepancy > 0.5 then
        local detectionChance = clamp(0.55 + ratio * 2 + (state.taxComplianceFlags or 0) * 0.05, 0.55, 0.98)
        detected = math.random() < detectionChance
    end

    if not detected then
        state.taxInvestigationStatus = "CLOSED"
        state.taxInvestigationLastOutcome = "NO_ACTION"
        state.taxInvestigationAdjustment = 0
        state.taxInvestigationPenalty = 0
        state.taxInvestigationInterest = 0
        self:notifyRevenue(farmId, "rff_phone_title_tax_investigation", "Tax Return Review", "rff_tax_investigation_clear_phone",
            "The review of your Year %d Farm Business Tax Return is complete. No further action is required.", state.taxReturnYear or 0)
        return true
    end

    local underpaidTax = math.max(0, (state.taxReturnBookTax or 0) - (state.taxReturnFiledTax or 0))
    local elapsed = math.max(1, self:getCurrentPeriod() - (state.taxReturnFiledPeriod or self:getCurrentPeriod()))
    local interest = math.floor(underpaidTax * 0.005 * elapsed + 0.5)
    local penaltyRate = ratio < 0.05 and 0.10 or (ratio < 0.15 and 0.25 or 0.50)
    penaltyRate = math.min(0.75, penaltyRate + (state.taxComplianceFlags or 0) * 0.10)
    local penalty = math.floor(underpaidTax * penaltyRate + 0.5)

    -- If Red Tape has not yet collected the annual statement, correcting that statement
    -- to the recorded books will cause the full tax to be collected in its normal payment
    -- month. Do not also add the tax difference to RFF's compliance balance or it would be
    -- charged twice. If the statement has already been paid, the extra tax must be collected
    -- here because Red Tape correctly considers the annual statement settled.
    local annualStatement = self:getLatestTaxStatement(farmId)
    local statementAlreadyPaid = annualStatement ~= nil and annualStatement.paid == true
    local backTaxCashDue = (state.taxReturnWasForcedTest or statementAlreadyPaid) and underpaidTax or 0
    local total = backTaxCashDue + interest + penalty

    if not state.taxReturnWasForcedTest then
        self:updateRedTapeStatement(farmId, self:calculateDeclaredTax(state, 1, 1), true)
    end

    state.taxComplianceFlags = (state.taxComplianceFlags or 0) + 1
    state.taxComplianceCleanFilings = 0
    state.taxInvestigationStatus = "CLOSED"
    state.taxInvestigationLastOutcome = "ADJUSTED"
    state.taxInvestigationAdjustment = underpaidTax
    state.taxInvestigationPenalty = penalty
    state.taxInvestigationInterest = interest
    self:addComplianceLiability(farmId, total)
    if backTaxCashDue > 0.01 then
        self:notifyRevenue(farmId, "rff_phone_title_tax_investigation", "Tax Return Review", "rff_tax_investigation_adjusted_phone",
            "The review of your Year %d return identified an underpayment of %s. Interest of %s and a penalty of %s have been added. Total compliance balance: %s.",
            state.taxReturnYear or 0, g_i18n:formatMoney(underpaidTax, 0, true, true), g_i18n:formatMoney(interest, 0, true, true),
            g_i18n:formatMoney(penalty, 0, true, true), g_i18n:formatMoney(total, 0, true, true))
    else
        self:notifyRevenue(farmId, "rff_phone_title_tax_investigation", "Tax Return Review", "rff_tax_investigation_adjusted_prepaid_phone",
            "The review of your Year %d return identified an understatement of %s. The annual Red Tape assessment has been corrected before payment. Interest of %s and a penalty of %s are due separately: %s.",
            state.taxReturnYear or 0, g_i18n:formatMoney(underpaidTax, 0, true, true), g_i18n:formatMoney(interest, 0, true, true),
            g_i18n:formatMoney(penalty, 0, true, true), g_i18n:formatMoney(total, 0, true, true))
    end
    return true
end

function RFF_TaxComplianceService:processComplianceLiability(farmId, current)
    local state = self:getFarmState(farmId, true)
    if state == nil or state.taxComplianceLiability <= 0.01 then return end
    if current > (state.taxComplianceLastInterestPeriod or current) then
        local months = current - (state.taxComplianceLastInterestPeriod or current)
        local interest = math.floor(state.taxComplianceLiability * self.COMPLIANCE_LATE_INTEREST * months + 0.5)
        if interest > 0 then state.taxComplianceLiability = state.taxComplianceLiability + interest end
        state.taxComplianceLastInterestPeriod = current
    end
end

function RFF_TaxComplianceService:onLoaded()
    self:installRedTapeHook()
    -- Also adopt an already-created, still-unpaid annual statement. This repairs saves
    -- where Red Tape created the April assessment before RFF's hook was active and
    -- keeps the manual return available throughout the pre-September filing window.
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if isPlayableFarm(farmId) then
            self:ensureReturnForCurrentStatement(farmId)
        end
    end
end

function RFF_TaxComplianceService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() then return end
    self:installRedTapeHook()
    local current = self:getCurrentPeriod()
    local month = self:getCurrentMonth()
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if isPlayableFarm(farmId) then
            local state = self:getFarmState(farmId, true)

            -- Red Tape and RFF can receive PERIOD_CHANGED in either order. If Red Tape
            -- has already created April's annual statement before our storeTaxStatement
            -- hook was installed/called, adopt that current statement here. If RFF runs
            -- first, the stale-statement guard rejects last year's statement and the hook
            -- will create the return when Red Tape stores the new one later in the event.
            local adoptedState, adoptedReason = self:ensureReturnForCurrentStatement(farmId)
            if adoptedState ~= nil and adoptedReason == "created" then
                Logging.info("[RealisticFarmFinance] Adopted Red Tape annual tax statement for farm=%d year=%d tax=%.2f", farmId, adoptedState.taxReturnYear or 0, adoptedState.taxReturnBookTax or 0)
            end
            state = self:getFarmState(farmId, true)

            if month == self.LATE_MONTH and state.taxReturnStatus == "OPEN" and state.taxReturnWasForcedTest ~= true then self:applyLateFiling(farmId) end
            self:processInvestigation(farmId, current)
            self:processComplianceLiability(farmId, current)
        end
    end
end

function RFF_TaxComplianceService:getSummary(farmId)
    -- In single-player/hosted games the Business page can be the first RFF code to run
    -- after Red Tape has loaded its April statement. Reconcile lazily here as a final
    -- safety net so a valid unpaid Red Tape assessment can never be visible without
    -- its corresponding RFF filing task.
    if g_currentMission ~= nil and g_currentMission:getIsServer() then
        self:ensureReturnForCurrentStatement(farmId)
    end
    local state = self:getFarmState(farmId, true)
    local available = self:getRedTapeTaxSystem() ~= nil
    return {
        available = available,
        state = state,
        returnOpen = state ~= nil and state.taxReturnStatus == "OPEN",
        returnStatus = state ~= nil and state.taxReturnStatus or "NONE",
        returnYear = state ~= nil and state.taxReturnYear or 0,
        complianceLiability = state ~= nil and state.taxComplianceLiability or 0,
        complianceFlags = state ~= nil and state.taxComplianceFlags or 0,
        investigationStatus = state ~= nil and state.taxInvestigationStatus or "NONE",
        lastOutcome = state ~= nil and state.taxInvestigationLastOutcome or "NONE"
    }
end

function RFF_TaxComplianceService:forceReturnForTest(farmId)
    local state = self:getFarmState(farmId, true)
    if state ~= nil and state.taxReturnStatus == "OPEN" then return nil, "already_open" end
    if state ~= nil and (state.taxReturnStatus == "FILED" or state.taxReturnStatus == "LATE_FILED") then return nil, "already_filed" end
    local statement = self:getCurrentBookEstimate(farmId)
    if statement == nil then return nil, "statement" end
    return self:createReturnTaskFromStatement(farmId, statement, true)
end

function RFF_TaxComplianceService:forceAuditForTest(farmId)
    local state = self:getFarmState(farmId, true)
    if state == nil or (state.taxReturnStatus ~= "FILED" and state.taxReturnStatus ~= "LATE_FILED") then return false, "not_filed" end
    state.taxInvestigationStatus = "OPEN"
    state.taxInvestigationStartPeriod = self:getCurrentPeriod()
    state.taxInvestigationOutcomePeriod = self:getCurrentPeriod() + 1
    self:notifyRevenue(farmId, "rff_phone_title_tax_investigation", "Tax Return Review", "rff_tax_investigation_open_phone",
        "Your Year %d Farm Business Tax Return has been selected for a compliance review. Keep sufficient funds available pending the outcome.", state.taxReturnYear or 0)
    return true, "opened"
end
