RFF_NpcNarrativeService = {}
RFF_NpcNarrativeService.__index = RFF_NpcNarrativeService

RFF_NpcNarrativeService.SCHEMA_VERSION = 1

-- These are communication profiles, not negotiating concessions. A warm
-- landlord can still be commercially firm, while a terse landlord may be
-- willing to move. The economic decision remains in PropertyFinanceService.
local BASE_VOICES = {
    PRIVATE_LANDOWNER = {
        voiceId="BALANCED_PERSONAL", style="BALANCED", formality=0.55, warmth=0.55,
        verbosity=0.55, patience=0.55, directness=0.50, conservatism=0.55, relationshipWeight=0.70
    },
    FAMILY_LANDHOLDING = {
        voiceId="WARM_CONTINUITY", style="WARM", formality=0.35, warmth=0.78,
        verbosity=0.66, patience=0.72, directness=0.38, conservatism=0.48, relationshipWeight=0.90
    },
    REGIONAL_LAND_PARTNERSHIP = {
        voiceId="PRACTICAL_PARTNERSHIP", style="BALANCED", formality=0.56, warmth=0.48,
        verbosity=0.48, patience=0.56, directness=0.66, conservatism=0.60, relationshipWeight=0.58
    },
    AGRICULTURAL_LAND_TRUST = {
        voiceId="FORMAL_STEWARDSHIP", style="FORMAL", formality=0.86, warmth=0.32,
        verbosity=0.68, patience=0.64, directness=0.54, conservatism=0.84, relationshipWeight=0.50
    },
    LAND_MANAGEMENT_COMPANY = {
        voiceId="COMMERCIAL_DIRECT", style="DIRECT", formality=0.78, warmth=0.22,
        verbosity=0.34, patience=0.34, directness=0.90, conservatism=0.88, relationshipWeight=0.30
    }
}

local VOICE_DESCRIPTIONS = {
    BALANCED = "Measured and personal",
    WARM = "Warm and continuity-minded",
    FORMAL = "Formal and stewardship-led",
    DIRECT = "Direct and commercially focused"
}

local EVENT_LABELS = {
    APPLICATION_RECEIVED="Tenancy enquiry received",
    LANDLORD_INTRODUCTION="Landlord introduction",
    CREDIT_ASSESSMENT="Financial assessment",
    INITIAL_HEADS="Initial heads of terms",
    APPLICATION_DECLINED="Application declined",
    APPLICATION_WITHDRAWN="Application withdrawn",
    TENANCY_STARTED="Agreement commenced",
    RENEWAL_OFFER="Renewal offer",
    PROPOSAL_RECEIVED="Proposal received",
    REVISED_PROPOSAL_RECEIVED="Revised proposal received",
    IMMEDIATE_REJECTED="Immediate response",
    FINAL_REJECTED="Final landlord position",
    LEGAL_REVIEW="Legal review",
    TERMS_AGREED="Heads of terms agreed",
    COUNTER_OFFER="Counter-offer",
    FINAL_COUNTER="Final heads of terms",
    RENEWAL_ACCEPTED="Renewal executed",
    RENEWAL_DECLINED="Renewal declined",
    CONSENT_REQUEST="Consent application received",
    CONSENT_REVIEW="Land agent review",
    CONSENT_APPROVED="Written consent granted",
    CONSENT_CONDITIONAL="Conditional consent granted",
    CONSENT_DECLINED="Consent declined",
    COVENANT_INSPECTION_CLEAR="Covenant inspection clear",
    COVENANT_INSPECTION_FINDINGS="Covenant inspection findings",
    COVENANT_REMEDY_NOTICE="Covenant remedy notice",
    COVENANT_REMEDIED="Covenant remedy confirmed",
    COVENANT_FINAL_WARNING="Covenant final warning",
    COVENANT_TERMINATION_NOTICE="Covenant termination notice",
    COVENANT_TERMINATED="Tenancy terminated for covenant default",
    COVENANT_COSTS_SETTLED="Covenant costs settled",
    HANDBACK_SCHEDULE="Schedule of dilapidations",
    HANDBACK_CLEAR="Handback inspection clear",
    HANDBACK_REMEDIED="Handback inspection update",
    HANDBACK_SETTLEMENT="Final handback settlement",
    LANDLORD_VARIATION_PROPOSED="Landlord variation proposed",
    LANDLORD_VARIATION_ACCEPTED="Landlord variation accepted",
    LANDLORD_VARIATION_DECLINED="Landlord variation declined",
    LANDLORD_VARIATION_NOTICE="Formal landlord notice",
    LANDLORD_VARIATION_LEGAL_REVIEW="Legal adviser response",
    LANDLORD_VARIATION_EFFECTIVE="Landlord variation effective",
    VARIATION_COSTS_SETTLED="Professional costs settled"
}

local EVENT_ACTIONS = {
    APPLICATION_RECEIVED="WAIT",
    LANDLORD_INTRODUCTION="WAIT",
    CREDIT_ASSESSMENT="WAIT",
    INITIAL_HEADS="REPLY",
    APPLICATION_DECLINED="CLOSED",
    APPLICATION_WITHDRAWN="CLOSED",
    TENANCY_STARTED="RECORD_ONLY",
    RENEWAL_OFFER="REPLY",
    PROPOSAL_RECEIVED="WAIT",
    REVISED_PROPOSAL_RECEIVED="WAIT",
    IMMEDIATE_REJECTED="REVISE",
    FINAL_REJECTED="DECIDE",
    LEGAL_REVIEW="WAIT",
    TERMS_AGREED="DECIDE",
    COUNTER_OFFER="REVISE",
    FINAL_COUNTER="DECIDE",
    RENEWAL_ACCEPTED="CLOSED",
    RENEWAL_DECLINED="CLOSED",
    CONSENT_REQUEST="WAIT",
    CONSENT_REVIEW="WAIT",
    CONSENT_APPROVED="CLOSED",
    CONSENT_CONDITIONAL="CLOSED",
    CONSENT_DECLINED="CLOSED",
    COVENANT_INSPECTION_CLEAR="RECORD_ONLY",
    COVENANT_INSPECTION_FINDINGS="WAIT",
    COVENANT_REMEDY_NOTICE="REMEDY",
    COVENANT_REMEDIED="CLOSED",
    COVENANT_FINAL_WARNING="FINAL_REMEDY",
    COVENANT_TERMINATION_NOTICE="FINAL_REMEDY",
    COVENANT_TERMINATED="CLOSED",
    COVENANT_COSTS_SETTLED="CLOSED",
    HANDBACK_SCHEDULE="REMEDY",
    HANDBACK_CLEAR="RECORD_ONLY",
    HANDBACK_REMEDIED="RECORD_ONLY",
    HANDBACK_SETTLEMENT="CLOSED",
    LANDLORD_VARIATION_PROPOSED="REPLY",
    LANDLORD_VARIATION_ACCEPTED="CLOSED",
    LANDLORD_VARIATION_DECLINED="CLOSED",
    LANDLORD_VARIATION_NOTICE="WAIT",
    LANDLORD_VARIATION_LEGAL_REVIEW="RECORD_ONLY",
    LANDLORD_VARIATION_EFFECTIVE="CLOSED",
    VARIATION_COSTS_SETTLED="CLOSED"
}

local OPENINGS = {
    FORMAL = {
        "We have reviewed the position concerning {HOLDING}.",
        "I write regarding the current position on {HOLDING}.",
        "The tenancy position for {HOLDING} has now been considered."
    },
    WARM = {
        "I've had another proper look at {HOLDING}.",
        "I've taken some time to consider where we are with {HOLDING}.",
        "Thank you for keeping the conversation moving on {HOLDING}."
    },
    DIRECT = {
        "On {HOLDING}, this is the position.",
        "I've reviewed {HOLDING}.",
        "The position on {HOLDING} is straightforward."
    },
    BALANCED = {
        "I've considered the position on {HOLDING}.",
        "We've looked again at the arrangements for {HOLDING}.",
        "I wanted to come back to you about {HOLDING}."
    }
}

local MEMORY_LINES = {
    TRUSTED = {
        FORMAL={"Your established record as occupier carries considerable weight.", "The history of reliable performance under the agreement is recognised."},
        WARM={"You've always dealt fairly with the holding, and that matters to me.", "We've built up a good working relationship over the tenancy."},
        DIRECT={"Your record is strong.", "Your past performance is in your favour."},
        BALANCED={"Your reliable record under the existing tenancy works in your favour.", "The way you have handled the tenancy gives useful reassurance."}
    },
    RELIABLE = {
        FORMAL={"The rent record and general conduct of the tenancy have been satisfactory.", "Your performance of the existing obligations has been noted."},
        WARM={"You've kept the rent straight and looked after the arrangement well.", "There has been no trouble over the rent, which helps your case."},
        DIRECT={"The payment record is clean.", "The existing agreement has been handled properly."},
        BALANCED={"Your clean payment record is a positive part of the discussion.", "The existing tenancy has been conducted reliably."}
    },
    ESTABLISHED = {
        FORMAL={"There is now a useful record of performance under the agreement.", "The existing course of dealings provides some reassurance."},
        WARM={"We've had enough time working together to know where we stand.", "The relationship is beginning to speak for itself."},
        DIRECT={"There is an established record now.", "Your recent conduct is satisfactory."},
        BALANCED={"The relationship is established and that is being taken into account.", "Your record so far provides a reasonable basis for discussion."}
    },
    NEW = {
        FORMAL={"The relationship remains relatively new, so the written terms retain particular importance.", "There is limited historic performance on which to rely at present."},
        WARM={"We're still getting to know how the arrangement works in practice.", "There isn't a long history between us yet, but the start has been useful."},
        DIRECT={"There is not much history to rely on yet.", "The relationship is still new."},
        BALANCED={"There is still only a limited tenancy history to assess.", "The relationship remains at an early stage."}
    },
    STRAINED = {
        FORMAL={"The previous payment difficulties materially limit the flexibility available.", "The recent conduct of the agreement requires a cautious approach."},
        WARM={"I cannot overlook the difficulties we've already had over the rent.", "I'd like to find a way forward, but the earlier problems still matter."},
        DIRECT={"The previous payment problems count against the proposal.", "The tenancy record requires caution."},
        BALANCED={"The earlier payment difficulties reduce the room for compromise.", "Recent conduct means the proposal has to be considered cautiously."}
    },
    PREVIOUS_POSITIONS = {
        FORMAL={"The earlier proposals and responses also form part of the present assessment.", "The movement already made during these discussions has been taken into account."},
        WARM={"We've already covered some ground in this discussion, and I have kept that in mind.", "I have not forgotten the figures we've each put forward already."},
        DIRECT={"Previous positions have already been considered.", "There has already been movement in these talks."},
        BALANCED={"The proposals already exchanged are being taken into account.", "Both sides have already shown their position during these discussions."}
    }
}

local EVENT_LINES = {
    APPLICATION_RECEIVED = {
        FORMAL={"Your expression of interest for {HOLDING} has been logged under {REFERENCE}. No tenancy or right of occupation arises at this stage.", "The application for {HOLDING} has been received under reference {REFERENCE}; landlord review will follow."},
        WARM={"Your enquiry about {HOLDING} is safely in under {REFERENCE}. I will come back to you once the landlord has considered it.", "We've logged your interest in {HOLDING} as {REFERENCE}; this starts the conversation but does not yet grant occupation."},
        DIRECT={"Application {REFERENCE} received for {HOLDING}. No occupation is granted yet.", "Enquiry logged: {REFERENCE}. Landlord review follows."},
        BALANCED={"Your tenancy enquiry for {HOLDING} has been recorded under {REFERENCE}. The holding remains unlet while the application is considered.", "Application {REFERENCE} has been received for {HOLDING}; landlord review and financial checks will follow."}
    },
    LANDLORD_INTRODUCTION = {
        FORMAL={"Hello {PLAYER_NAME}. Thank you for your interest in the tenancy of farmland {FARMLAND_ID}. Let me introduce myself: I represent {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} For the tenancy, I am looking for the following: {LANDLORD_PRIORITIES}", "Hello {PLAYER_NAME}. Thank you for enquiring about farmland {FARMLAND_ID}. I am writing on behalf of {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} These are the terms and standards I will be looking for: {LANDLORD_PRIORITIES}"},
        WARM={"Hello {PLAYER_NAME}, thanks for your interest in the tenancy for farmland {FARMLAND_ID}. Let me introduce myself: I look after the land for {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} What I am looking for is straightforward: {LANDLORD_PRIORITIES}", "Hello {PLAYER_NAME}, it is good to hear of your interest in farmland {FARMLAND_ID}. I represent {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} These are the things that matter most to me in any tenancy: {LANDLORD_PRIORITIES}"},
        DIRECT={"Hello {PLAYER_NAME}. Thanks for your interest in farmland {FARMLAND_ID}. I represent {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} These are the requirements I will be looking for: {LANDLORD_PRIORITIES}", "Hello {PLAYER_NAME}. I am responding to your enquiry for farmland {FARMLAND_ID} on behalf of {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} The terms I want to see are clear: {LANDLORD_PRIORITIES}"},
        BALANCED={"Hello {PLAYER_NAME}, thank you for your interest in the tenancy for farmland {FARMLAND_ID}. Let me introduce myself: I represent {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} These are the terms and standards I am looking for: {LANDLORD_PRIORITIES}", "Hello {PLAYER_NAME}, thanks for enquiring about farmland {FARMLAND_ID}. I look after the letting for {LANDLORD_NAME}. {LANDLORD_DESCRIPTION} What I will be looking for from the tenancy is: {LANDLORD_PRIORITIES}"}
    },
    CREDIT_ASSESSMENT = {
        FORMAL={"The financial assessment records a tenancy score of {CREDIT_SCORE}, band {CREDIT_BAND}. Payment conduct is {CREDIT_CONDUCT} and affordability is assessed as {CREDIT_AFFORDABILITY}. The resulting position is that {CREDIT_REASON}.", "Financial enquiries are complete: score {CREDIT_SCORE}, band {CREDIT_BAND}, with {CREDIT_CONDUCT} conduct and {CREDIT_AFFORDABILITY} affordability. Accordingly, {CREDIT_REASON}."},
        WARM={"The financial check is back at {CREDIT_SCORE}, band {CREDIT_BAND}. Your payment record reads as {CREDIT_CONDUCT} and the rent looks {CREDIT_AFFORDABILITY}; on that basis, {CREDIT_REASON}.", "We've completed the credit work: {CREDIT_SCORE}, band {CREDIT_BAND}. With conduct marked {CREDIT_CONDUCT} and affordability {CREDIT_AFFORDABILITY}, {CREDIT_REASON}."},
        DIRECT={"Financial check: {CREDIT_SCORE}, band {CREDIT_BAND}. Conduct: {CREDIT_CONDUCT}. Affordability: {CREDIT_AFFORDABILITY}. Decision basis: {CREDIT_REASON}.", "Score {CREDIT_SCORE} ({CREDIT_BAND}). {CREDIT_REASON}."},
        BALANCED={"The tenancy financial assessment is complete at score {CREDIT_SCORE}, band {CREDIT_BAND}. Conduct is recorded as {CREDIT_CONDUCT} and affordability as {CREDIT_AFFORDABILITY}; therefore {CREDIT_REASON}.", "The application has returned a score of {CREDIT_SCORE}, band {CREDIT_BAND}. Taking the {CREDIT_CONDUCT} payment record and {CREDIT_AFFORDABILITY} affordability together, {CREDIT_REASON}."}
    },
    INITIAL_HEADS = {
        FORMAL={"Subject to contract, initial heads of terms are offered for {TERM_MONTHS} months at {LANDLORD_RENT} per year, payable {PAYMENT_FREQUENCY}. Completion requires a deposit of {DEPOSIT_AMOUNT}, first rent and legal and administration costs of {LEGAL_FEE}; total funds due on signing are {UPFRONT_COSTS}.", "Draft letting terms have been issued at {LANDLORD_RENT} per annum for {TERM_MONTHS} months. The signing requirement is {DEPOSIT_AMOUNT} deposit plus first rent and {LEGAL_FEE} professional costs, totalling {UPFRONT_COSTS}."},
        WARM={"I'm prepared to offer you {HOLDING} for {TERM_MONTHS} months at {LANDLORD_RENT} a year, payable {PAYMENT_FREQUENCY}. To sign, you would need {DEPOSIT_AMOUNT} deposit, the first rent and {LEGAL_FEE} costs, making {UPFRONT_COSTS} altogether.", "There is a workable letting here: {LANDLORD_RENT} a year for {TERM_MONTHS} months. The amount needed when we sign is {UPFRONT_COSTS}, including the {DEPOSIT_AMOUNT} deposit and {LEGAL_FEE} legal and administration charge."},
        DIRECT={"Initial heads: {LANDLORD_RENT} per year, {TERM_MONTHS} months, {PAYMENT_FREQUENCY}. Signing costs: {DEPOSIT_AMOUNT} deposit, first rent and {LEGAL_FEE} fees; {UPFRONT_COSTS} total.", "Offer: {TERM_MONTHS} months at {LANDLORD_RENT}. Cash due on execution: {UPFRONT_COSTS}."},
        BALANCED={"I can offer initial heads of terms for {TERM_MONTHS} months at {LANDLORD_RENT} per year, payable {PAYMENT_FREQUENCY}. Signing would require the {DEPOSIT_AMOUNT} deposit, first rent and {LEGAL_FEE} legal and administration costs, totalling {UPFRONT_COSTS}.", "The proposed letting is {LANDLORD_RENT} a year for {TERM_MONTHS} months. The completion statement totals {UPFRONT_COSTS}, including a {DEPOSIT_AMOUNT} deposit and {LEGAL_FEE} professional costs."}
    },
    APPLICATION_DECLINED = {
        FORMAL={"The tenancy application cannot proceed because {CREDIT_REASON}. The file is now closed without any right of occupation arising.", "Following review, the application is declined: {CREDIT_REASON}. No tenancy has been created."},
        WARM={"I'm sorry, but we cannot take the application forward because {CREDIT_REASON}. Nothing has been charged and no tenancy has begun.", "The application has had to stop here: {CREDIT_REASON}. The holding has not passed into your occupation."},
        DIRECT={"Application declined: {CREDIT_REASON}. No tenancy created.", "The letting will not proceed. Reason: {CREDIT_REASON}."},
        BALANCED={"The application has been declined because {CREDIT_REASON}. It is closed without a tenancy or occupation being created.", "The landlord cannot proceed with the letting: {CREDIT_REASON}. No funds have been taken."}
    },
    APPLICATION_WITHDRAWN = {
        FORMAL={"Your decision not to proceed has been recorded and application {REFERENCE} is closed without a tenancy arising.", "The proposed letting has been withdrawn before execution; no right of occupation has been created."},
        WARM={"I've noted that you do not want to proceed. The application is closed and nothing further is due.", "That's fine; we'll close {REFERENCE} without the tenancy beginning."},
        DIRECT={"Application {REFERENCE} withdrawn. No tenancy created.", "Withdrawal recorded. The letting is closed."},
        BALANCED={"Your withdrawal has been recorded and application {REFERENCE} is now closed without a tenancy being created.", "The proposed letting is closed at your request; no occupation or payment obligation has arisen."}
    },
    TENANCY_STARTED = {
        FORMAL={"The agreement is now in force at {LANDLORD_RENT} per year for a term of {TERM_MONTHS} months.", "The tenancy has commenced on the documented rent of {LANDLORD_RENT} per year."},
        WARM={"I'm pleased we've got the tenancy settled at {LANDLORD_RENT} a year for {TERM_MONTHS} months.", "The holding is yours to work under the new agreement at {LANDLORD_RENT} a year."},
        DIRECT={"The tenancy is agreed: {LANDLORD_RENT} a year, {TERM_MONTHS} months.", "Agreement commenced at {LANDLORD_RENT} per year."},
        BALANCED={"The tenancy is now in place at {LANDLORD_RENT} per year for {TERM_MONTHS} months.", "The agreement has commenced on the settled annual rent of {LANDLORD_RENT}."}
    },
    RENEWAL_OFFER = {
        FORMAL={"A renewal is offered for {TERM_MONTHS} months at {LANDLORD_RENT} per year, payable {PAYMENT_FREQUENCY}.", "The proposed renewal terms provide for an annual rent of {LANDLORD_RENT} over {TERM_MONTHS} months."},
        WARM={"I'd be happy to continue the tenancy for {TERM_MONTHS} months at {LANDLORD_RENT} a year, payable {PAYMENT_FREQUENCY}.", "There is a route to keeping you on the holding: {LANDLORD_RENT} a year for another {TERM_MONTHS} months."},
        DIRECT={"Renewal offer: {LANDLORD_RENT} a year for {TERM_MONTHS} months, payable {PAYMENT_FREQUENCY}.", "I will renew at {LANDLORD_RENT} per year for {TERM_MONTHS} months."},
        BALANCED={"I can offer a renewal for {TERM_MONTHS} months at {LANDLORD_RENT} per year, payable {PAYMENT_FREQUENCY}.", "The renewal figure is {LANDLORD_RENT} a year for a further {TERM_MONTHS} months."}
    },
    PROPOSAL_RECEIVED = {
        FORMAL={"Your proposal of {TENANT_RENT} per year has been received for consideration and preparation of draft heads of terms.", "The proposed annual rent of {TENANT_RENT} is now under formal review."},
        WARM={"I've received your figure of {TENANT_RENT} a year and will give it proper consideration.", "Your proposal of {TENANT_RENT} is with me now; I'll look at the whole position before responding."},
        DIRECT={"Your {TENANT_RENT} proposal is under review.", "Proposal received: {TENANT_RENT} per year."},
        BALANCED={"Your proposal of {TENANT_RENT} per year has been received and is being reviewed.", "I have the {TENANT_RENT} annual-rent proposal and will consider it against the agreement as a whole."}
    },
    REVISED_PROPOSAL_RECEIVED = {
        FORMAL={"Your revised proposal of {TENANT_RENT} per year has been added to the draft heads of terms for review.", "The amended annual-rent proposal of {TENANT_RENT} is now being considered."},
        WARM={"I've got your revised figure of {TENANT_RENT} and will look at whether it closes the gap.", "Thank you for moving the figure to {TENANT_RENT}; I'll consider the revised position."},
        DIRECT={"Revised proposal received: {TENANT_RENT}.", "The new {TENANT_RENT} figure is under review."},
        BALANCED={"Your revised proposal of {TENANT_RENT} per year is now under review.", "I have received the amended figure of {TENANT_RENT} and will reconsider the heads of terms."}
    },
    IMMEDIATE_REJECTED = {
        FORMAL={"The proposal of {TENANT_RENT} falls outside the range that can reasonably be considered; the current landlord figure remains {LANDLORD_RENT}.", "The proposed rent of {TENANT_RENT} cannot be referred for legal review because it is materially outside the acceptable range."},
        WARM={"I'm afraid {TENANT_RENT} is too far away from where I need the rent to be; my present figure is still {LANDLORD_RENT}.", "I cannot send {TENANT_RENT} forward as a serious basis for the tenancy, although you may come back with another figure."},
        DIRECT={"{TENANT_RENT} is outside the consideration range. The landlord figure remains {LANDLORD_RENT}.", "I will not consider {TENANT_RENT}. Submit a credible revision if you want to continue."},
        BALANCED={"The proposal of {TENANT_RENT} is too far below the acceptable range, so the landlord figure remains {LANDLORD_RENT}.", "I cannot take {TENANT_RENT} forward for legal review; a revised figure would be needed."}
    },
    FINAL_REJECTED = {
        FORMAL={"The proposal of {TENANT_RENT} is declined and the existing landlord figure of {LANDLORD_RENT} is now final.", "No further tenant proposal will be considered; the final tenancy rent is {LANDLORD_RENT} per year."},
        WARM={"We are not going to bridge the gap from {TENANT_RENT}; {LANDLORD_RENT} is my final figure.", "I've gone as far as I can. The tenancy can continue at {LANDLORD_RENT} a year, or the offer can be declined."},
        DIRECT={"Final position: {LANDLORD_RENT} a year. {TENANT_RENT} is rejected.", "No further negotiation. Accept or decline {LANDLORD_RENT}."},
        BALANCED={"The latest proposal of {TENANT_RENT} is declined and {LANDLORD_RENT} per year is the final landlord position.", "There is no further room to negotiate below {LANDLORD_RENT} a year."}
    },
    LEGAL_REVIEW = {
        FORMAL={"Draft heads of terms have been referred to an independent agricultural legal adviser for review.", "The working terms are now with the agricultural legal adviser for scrutiny before a substantive response is issued."},
        WARM={"I've asked the agricultural legal adviser to check the draft terms before I come back to you.", "The draft has gone across for a legal review so that we know exactly what is being agreed."},
        DIRECT={"Draft heads are with the agricultural legal adviser.", "Legal review is now under way."},
        BALANCED={"The draft heads of terms have now been sent for independent agricultural legal review.", "An agricultural legal adviser is checking the working terms before the next response."}
    },
    TERMS_AGREED = {
        FORMAL={"The revised heads of terms are approved at {AGREED_RENT} per year and are ready for execution.", "Agreement in principle has been reached at an annual rent of {AGREED_RENT}."},
        WARM={"That has brought us together. I'm happy with {AGREED_RENT} a year and the papers can now be signed.", "We've reached a sensible position at {AGREED_RENT} a year; the tenancy documents are ready."},
        DIRECT={"Terms agreed at {AGREED_RENT} per year. Sign the agreement to proceed.", "{AGREED_RENT} is accepted. Documents are ready."},
        BALANCED={"The revised heads of terms are agreed at {AGREED_RENT} per year and are ready for acceptance.", "We have agreement in principle at an annual rent of {AGREED_RENT}."}
    },
    COUNTER_OFFER = {
        FORMAL={"Following review, revised heads of terms are offered at {COUNTER_RENT} per year in response to your proposal of {TENANT_RENT}.", "The landlord is prepared to revise the annual rent to {COUNTER_RENT}."},
        WARM={"We're getting closer. I can move to {COUNTER_RENT} a year in response to your {TENANT_RENT} proposal.", "I cannot accept {TENANT_RENT}, but I can bring my figure down to {COUNTER_RENT}."},
        DIRECT={"Counter-offer: {COUNTER_RENT} per year.", "I decline {TENANT_RENT}. My revised figure is {COUNTER_RENT}."},
        BALANCED={"I cannot accept {TENANT_RENT}, but I can revise the landlord figure to {COUNTER_RENT} per year.", "The revised heads of terms put the annual rent at {COUNTER_RENT}."}
    },
    FINAL_COUNTER = {
        FORMAL={"Final heads of terms are issued at {COUNTER_RENT} per year and no further revision will be considered.", "The concluding landlord position is an annual rent of {COUNTER_RENT}."},
        WARM={"I've gone as far as I reasonably can: {COUNTER_RENT} a year is the final figure.", "This is the last movement I can make. The tenancy is available at {COUNTER_RENT} a year."},
        DIRECT={"Final offer: {COUNTER_RENT} per year.", "{COUNTER_RENT}. Accept or decline; there will be no further counter."},
        BALANCED={"The final heads of terms set the rent at {COUNTER_RENT} per year, with no further negotiation available.", "My final position is {COUNTER_RENT} a year."}
    },
    RENEWAL_ACCEPTED = {
        FORMAL={"The renewal has been executed and successor agreement {SUCCESSOR_AGREEMENT} will commence automatically at expiry.", "Acceptance is recorded; {SUCCESSOR_AGREEMENT} will take effect at the end of the current term."},
        WARM={"I'm pleased we've settled it. {SUCCESSOR_AGREEMENT} will take over when the current tenancy ends.", "That's agreed, then. The renewed tenancy will begin automatically under {SUCCESSOR_AGREEMENT}."},
        DIRECT={"Renewal executed. {SUCCESSOR_AGREEMENT} starts at expiry.", "Accepted. Successor agreement: {SUCCESSOR_AGREEMENT}."},
        BALANCED={"The renewal is accepted and {SUCCESSOR_AGREEMENT} will commence automatically at expiry.", "The agreed renewal has been recorded as {SUCCESSOR_AGREEMENT}."}
    },
    RENEWAL_DECLINED = {
        FORMAL={"The renewal offer has been declined and the tenancy will therefore conclude at the contractual end date.", "The decision not to renew is recorded; occupation continues only until the current agreement expires."},
        WARM={"I'm sorry we could not reach terms. The present tenancy will run to its agreed end date.", "We'll leave the current agreement to finish in the ordinary way, and the renewal is now closed."},
        DIRECT={"Renewal declined. The tenancy ends on the contractual date.", "Negotiation closed; no successor tenancy will be created."},
        BALANCED={"The renewal has been declined, so the existing tenancy will end on its contractual date.", "The renewal discussion is closed and no successor agreement will follow."}
    },
    CONSENT_REQUEST = {
        FORMAL={"Your application concerning {CONSENT_TYPE}, seeking {CONSENT_TARGET}, has been received for formal consideration.", "The request for {CONSENT_TARGET} under the {CONSENT_TYPE} provisions is now recorded."},
        WARM={"I've received your request for {CONSENT_TARGET} and will give it a proper look.", "Your {CONSENT_TYPE} request is with me now, and I'll consider how it fits the holding."},
        DIRECT={"Consent request received: {CONSENT_TARGET}.", "The {CONSENT_TYPE} application has been logged."},
        BALANCED={"Your application for {CONSENT_TARGET} has been received under the {CONSENT_TYPE} provisions.", "I have recorded the request for {CONSENT_TARGET} and will review it against the agreement."}
    },
    CONSENT_REVIEW = {
        FORMAL={"The application has been referred to the land agent for review against the tenancy and the holding's long-term management requirements.", "The land agent is now considering the request and any conditions needed to protect the landlord's position."},
        WARM={"I've asked the land agent to look over the practical detail before I give you a decision.", "The request is with the land agent now so we can make sure any permission works properly for the holding."},
        DIRECT={"The land agent is reviewing the request.", "Consent review is under way."},
        BALANCED={"The request has now been referred to the land agent for a practical and contractual review.", "The land agent is checking the proposal against the tenancy before a decision is issued."}
    },
    CONSENT_APPROVED = {
        FORMAL={"Written consent is granted for {CONSENT_TARGET} for the remainder of the current tenancy term.", "The landlord approves the application concerning {CONSENT_TYPE}."},
        WARM={"I'm happy to approve {CONSENT_TARGET}; you can proceed under the written consent.", "That request is sensible, and I'm content for {CONSENT_TARGET} to go ahead."},
        DIRECT={"Approved: {CONSENT_TARGET}.", "Written consent granted for {CONSENT_TARGET}."},
        BALANCED={"Written consent is granted for {CONSENT_TARGET} for the current tenancy term.", "The application concerning {CONSENT_TYPE} is approved."}
    },
    CONSENT_CONDITIONAL = {
        FORMAL={"Consent is granted for {CONSENT_TARGET}, subject to the following condition: {CONSENT_CONDITIONS}.", "The application is approved conditionally. {CONSENT_CONDITIONS}."},
        WARM={"I'm prepared to agree to {CONSENT_TARGET}, provided that {CONSENT_CONDITIONS}.", "You can go ahead, but I need the following protection kept in place: {CONSENT_CONDITIONS}."},
        DIRECT={"Conditional approval: {CONSENT_TARGET}. {CONSENT_CONDITIONS}.", "Approved with conditions: {CONSENT_CONDITIONS}."},
        BALANCED={"Consent is granted for {CONSENT_TARGET}, subject to this condition: {CONSENT_CONDITIONS}.", "The request is approved on a conditional basis. {CONSENT_CONDITIONS}."}
    },
    CONSENT_DECLINED = {
        FORMAL={"The application for {CONSENT_TARGET} is declined because it is not consistent with the present management requirements for the holding.", "Consent cannot be granted for the proposed {CONSENT_TYPE} matter under the current tenancy position."},
        WARM={"I'm afraid I cannot agree to {CONSENT_TARGET} at this point; it does not sit comfortably with how the holding needs to be managed.", "I've considered it properly, but I cannot give consent for {CONSENT_TARGET}."},
        DIRECT={"Consent declined: {CONSENT_TARGET}.", "The {CONSENT_TYPE} request is not approved."},
        BALANCED={"The request for {CONSENT_TARGET} is declined under the current management position for the holding.", "I cannot grant consent for the proposed {CONSENT_TYPE} matter."}
    },
    COVENANT_INSPECTION_CLEAR = {
        FORMAL={"The tenancy inspection has been completed against the recorded commencement condition, alterations and written consents. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The covenant review is complete. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        WARM={"I've completed the inspection and checked the changes on the holding against our written permissions. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "I've now looked over the holding and its recorded changes. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        DIRECT={"Inspection complete. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "Covenant review complete: {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        BALANCED={"I have completed the tenancy inspection and checked the recorded land use and alterations against the agreement. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The scheduled covenant review is complete. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"}
    },
    COVENANT_INSPECTION_FINDINGS = {
        FORMAL={"The tenancy inspection has identified matters requiring formal review. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The covenant review records the following position: {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        WARM={"I've completed the inspection, and there are some changes we need to address. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "I've checked the holding against the agreement and need to come back to you on a few points. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        DIRECT={"Inspection findings: {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "Covenant issues recorded: {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        BALANCED={"I have completed the tenancy inspection and identified matters that need review against the agreement. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The inspection has produced covenant findings: {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"}
    },
    COVENANT_REMEDY_NOTICE = {
        FORMAL={"The inspection findings constitute formal breaches of the tenancy and are now recorded under a remedy notice. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "A formal covenant-default case has been opened following the inspection. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        WARM={"I need to be clear that these changes breach the agreement and must be put right. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The holding has departed from the terms we agreed, so I have opened a formal remedy case. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        DIRECT={"The agreement has been breached. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "Formal remedy notice. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        BALANCED={"The inspection has established breaches of the tenancy and a formal remedy case is now open. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "A remedy notice is now recorded for covenant default. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"}
    },
    COVENANT_REMEDIED = {
        FORMAL={"The follow-up review confirms that the recorded covenant breach has been remedied. {INSPECTION_ACTION}", "The reinstatement has been verified and the covenant case is closed. {INSPECTION_ACTION}"},
        WARM={"I've checked the holding again and can see that the issue has been put right. {INSPECTION_ACTION}", "Thank you for restoring the holding; the follow-up review is clear. {INSPECTION_ACTION}"},
        DIRECT={"Remedy confirmed. Case closed.", "Follow-up clear. The covenant case is closed."},
        BALANCED={"The follow-up inspection confirms that the recorded breach has been remedied. {INSPECTION_ACTION}", "The required reinstatement has been verified and the covenant case is now closed. {INSPECTION_ACTION}"}
    },
    COVENANT_FINAL_WARNING = {
        FORMAL={"The remedy notice has not been complied with and the tenancy is now in serious covenant default. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The breach remains outstanding after the permitted remedy period. This correspondence is the final warning before termination proceedings. {INSPECTION_ACTION}"},
        WARM={"I gave you time to restore the holding, but the breach is still there. I cannot allow that to continue. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The remedy period has expired without compliance. This is now the final warning before I move to end the tenancy. {INSPECTION_ACTION}"},
        DIRECT={"You failed to comply with the remedy notice. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "Final warning. The covenant default remains. {INSPECTION_ACTION}"},
        BALANCED={"The remedy period has expired and the covenant default remains unresolved. This is the final warning before termination action. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The required reinstatement has not been completed. {INSPECTION_ACTION}"}
    },
    COVENANT_TERMINATION_NOTICE = {
        FORMAL={"Continued non-compliance has left the landlord no reasonable alternative but to serve formal notice terminating the tenancy. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "The final warning was not complied with. Formal termination notice is therefore served under reference {REFERENCE}. {INSPECTION_ACTION}"},
        WARM={"You have had both the remedy period and a final warning, but the holding is still in breach. I am now serving notice to end the tenancy. {INSPECTION_ACTION}", "I did not want the matter to reach this point, but the continuing breach means the tenancy is now under formal termination notice. {INSPECTION_ACTION}"},
        DIRECT={"The final warning was ignored. Notice to terminate is served. {INSPECTION_ACTION}", "Termination notice served for continuing covenant default. {INSPECTION_ACTION}"},
        BALANCED={"The breach remains after the final warning, so formal notice to terminate the tenancy has been served. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}", "Continued covenant default has triggered termination proceedings. {INSPECTION_ACTION}"}
    },
    COVENANT_TERMINATED = {
        FORMAL={"The final inspection confirms continuing covenant default. The tenancy is terminated with immediate effect. {INSPECTION_ACTION}", "The termination notice has expired without remedy. The agreement is ended and possession has reverted to the landlord. {INSPECTION_ACTION}"},
        WARM={"The final opportunity to put matters right has passed and the breaches remain. The tenancy has now ended. {INSPECTION_ACTION}", "The holding was not restored by the final deadline, so I have ended the tenancy. {INSPECTION_ACTION}"},
        DIRECT={"Covenant default continues. Tenancy terminated. {INSPECTION_ACTION}", "Final deadline missed. The tenancy is ended and access is withdrawn. {INSPECTION_ACTION}"},
        BALANCED={"The final review confirms that the covenant default remains. The tenancy is therefore terminated and possession returns to the landlord. {INSPECTION_ACTION}", "The termination deadline has passed without remedy. The agreement is ended. {INSPECTION_ACTION}"}
    },
    COVENANT_COSTS_SETTLED = {
        FORMAL={"Payment of {LEGAL_CHARGE} has been received and applied to the legal and land-agent costs under this case. {INSPECTION_ACTION}"},
        WARM={"Your payment of {LEGAL_CHARGE} has been received against the legal and land-agent costs on this case. {INSPECTION_ACTION}"},
        DIRECT={"Payment received: {LEGAL_CHARGE} toward legal and land-agent costs. {INSPECTION_ACTION}"},
        BALANCED={"Payment of {LEGAL_CHARGE} has been received for the legal and land-agent costs recorded on this case. {INSPECTION_ACTION}"}
    },
    HANDBACK_SCHEDULE = {
        FORMAL={"The pre-termination inspection has been completed and a schedule of dilapidations is issued under {REFERENCE}. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        WARM={"I've walked the holding ahead of handback and set out what needs attention under {REFERENCE}. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        DIRECT={"Handback schedule {REFERENCE}. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        BALANCED={"The pre-expiry handback inspection is complete and schedule {REFERENCE} records the current position. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"}
    },
    HANDBACK_CLEAR = {
        FORMAL={"The pre-termination inspection has been completed under {REFERENCE}. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        WARM={"I've walked the holding ahead of handback and the present position is clear. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        DIRECT={"Handback inspection {REFERENCE}: clear. {INSPECTION_ACTION}"},
        BALANCED={"The pre-expiry handback inspection is complete. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"}
    },
    HANDBACK_REMEDIED = {
        FORMAL={"The handback position has been reviewed under {REFERENCE}. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        WARM={"I've checked the handback work again. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        DIRECT={"Handback review {REFERENCE}: {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        BALANCED={"The handback schedule has been reviewed. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"}
    },
    HANDBACK_SETTLEMENT = {
        FORMAL={"The final possession inspection and tenancy settlement are complete under {REFERENCE}. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        WARM={"The holding has now been handed back and the final account is complete. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        DIRECT={"Final handback {REFERENCE}. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"},
        BALANCED={"The final handback inspection and deposit account are complete. {INSPECTION_SUMMARY}. {INSPECTION_ACTION}"}
    },
    LANDLORD_VARIATION_PROPOSED = {
        FORMAL={"The landlord proposes that the agreement be varied so that {CONSENT_TARGET}. The present terms remain in force unless you accept.", "A landlord-initiated variation concerning {CONSENT_TYPE} is offered for your consideration: {CONSENT_TARGET}."},
        WARM={"I'd like to suggest one change to the agreement: {CONSENT_TARGET}. Nothing changes unless you're content to accept it.", "There is one estate-management change I'd like you to consider, namely that {CONSENT_TARGET}."},
        DIRECT={"Landlord variation proposed: {CONSENT_TARGET}. Accept or decline; the current terms continue until then.", "Proposed agreement change: {CONSENT_TARGET}."},
        BALANCED={"The landlord proposes a variation concerning {CONSENT_TYPE}: {CONSENT_TARGET}. It will only take effect if you accept.", "A proposed change to the current agreement has been issued for your decision: {CONSENT_TARGET}."}
    },
    LANDLORD_VARIATION_ACCEPTED = {
        FORMAL={"Your acceptance is recorded and the agreement is varied with immediate effect so that {CONSENT_TARGET}.", "The landlord-initiated variation concerning {CONSENT_TYPE} has been accepted and is now part of the agreement."},
        WARM={"Thank you for agreeing the change. The tenancy now records that {CONSENT_TARGET}.", "We've recorded your acceptance, so the proposed change now forms part of the agreement."},
        DIRECT={"Variation accepted and effective: {CONSENT_TARGET}.", "The accepted landlord variation is now part of the tenancy."},
        BALANCED={"The landlord's proposed variation has been accepted and the agreement now provides that {CONSENT_TARGET}.", "Your acceptance has been recorded and the variation is effective for the current term."}
    },
    LANDLORD_VARIATION_DECLINED = {
        FORMAL={"Your decision not to accept the proposed variation is recorded. The current agreement remains unchanged.", "The landlord's proposed change concerning {CONSENT_TYPE} has not been accepted and will not take effect."},
        WARM={"I understand that you do not want to accept that change. We'll leave the current agreement as it is.", "Your decision is noted, and the existing tenancy terms will continue unchanged."},
        DIRECT={"Variation declined. Current terms unchanged.", "The landlord proposal will not take effect."},
        BALANCED={"The proposed variation has been declined, so the existing agreement remains unchanged.", "Your decision not to accept the landlord's proposal has been recorded; no change takes effect."}
    },
    LANDLORD_VARIATION_NOTICE = {
        FORMAL={"Formal notice is served under the landlord-variation clause so that {CONSENT_TARGET}. The change will take effect in {VARIATION_EFFECTIVE_DATE}, after the agreed {VARIATION_NOTICE_MONTHS}-month notice period.", "The landlord gives contractual notice of a change concerning {CONSENT_TYPE}: {CONSENT_TARGET}. It is due to take effect in {VARIATION_EFFECTIVE_DATE}."},
        WARM={"I am giving the agreed notice that {CONSENT_TARGET}. Nothing changes immediately; the new term is due to start in {VARIATION_EFFECTIVE_DATE}, after {VARIATION_NOTICE_MONTHS} months.", "I need to make one estate-management change: {CONSENT_TARGET}. This is formal notice, and the existing terms continue until {VARIATION_EFFECTIVE_DATE}."},
        DIRECT={"Formal notice: {CONSENT_TARGET}. Effective {VARIATION_EFFECTIVE_DATE} after {VARIATION_NOTICE_MONTHS} months.", "Landlord change notified: {CONSENT_TARGET}. Existing terms apply until {VARIATION_EFFECTIVE_DATE}."},
        BALANCED={"The landlord has served formal notice concerning {CONSENT_TYPE}: {CONSENT_TARGET}. The existing terms remain in force for the agreed {VARIATION_NOTICE_MONTHS}-month notice period, with the change taking effect in {VARIATION_EFFECTIVE_DATE}.", "Contractual notice has been issued so that {CONSENT_TARGET}. The change is scheduled for {VARIATION_EFFECTIVE_DATE}, not immediately."}
    },
    LANDLORD_VARIATION_LEGAL_REVIEW = {
        FORMAL={"I have reviewed notice {REFERENCE} against the tenancy. The landlord may impose this change under the agreed clause, subject to {VARIATION_NOTICE_MONTHS} months' notice. It is effective in {VARIATION_EFFECTIVE_DATE}; the landlord bears the professional costs.", "Our review confirms that the notice complies with the negotiated variation provision. The present covenant remains operative until {VARIATION_EFFECTIVE_DATE}, and the landlord must meet the associated legal and administration costs."},
        WARM={"I've checked the notice against your agreement. It uses the landlord's agreed change power, but the current term stays in place for {VARIATION_NOTICE_MONTHS} months, until {VARIATION_EFFECTIVE_DATE}. The landlord, not the farm, pays the professional costs.", "The papers are in order. The notified term cannot start before {VARIATION_EFFECTIVE_DATE}, and the landlord must cover the legal and administration bill."},
        DIRECT={"Legal review complete. Notice valid; effective {VARIATION_EFFECTIVE_DATE}. Landlord pays all professional costs.", "Notice {REFERENCE} complies with the agreement. Current terms continue until {VARIATION_EFFECTIVE_DATE}. No farm charge."},
        BALANCED={"I have checked the formal notice against the negotiated tenancy terms. It is valid, but the existing covenant remains in force until {VARIATION_EFFECTIVE_DATE}, following {VARIATION_NOTICE_MONTHS} months' notice. The landlord is responsible for the professional costs.", "The legal review confirms that the landlord may impose the notified change only after the agreed notice period. It becomes effective in {VARIATION_EFFECTIVE_DATE}, with no charge to the farm."}
    },
    LANDLORD_VARIATION_EFFECTIVE = {
        FORMAL={"The notified variation is now effective and the agreement records that {CONSENT_TARGET}. No further landlord-initiated variation may be served before {VARIATION_COOLDOWN_UNTIL_DATE}.", "Notice {REFERENCE} has taken effect. The tenancy now provides that {CONSENT_TARGET}; the agreed variation cooldown runs until {VARIATION_COOLDOWN_UNTIL_DATE}."},
        WARM={"The notice period has now finished, so the tenancy records that {CONSENT_TARGET}. The agreed {VARIATION_COOLDOWN_MONTHS}-month gap now protects the holding from another landlord change until {VARIATION_COOLDOWN_UNTIL_DATE}.", "The notified change is now in place: {CONSENT_TARGET}. There cannot be another landlord-initiated change before {VARIATION_COOLDOWN_UNTIL_DATE}."},
        DIRECT={"Variation effective: {CONSENT_TARGET}. Next landlord change not before {VARIATION_COOLDOWN_UNTIL_DATE}.", "Notice complete. New term effective; cooldown until {VARIATION_COOLDOWN_UNTIL_DATE}."},
        BALANCED={"The formal notice period has expired and the agreement now provides that {CONSENT_TARGET}. The negotiated {VARIATION_COOLDOWN_MONTHS}-month cooldown prevents another landlord-initiated change before {VARIATION_COOLDOWN_UNTIL_DATE}.", "The notified covenant change is now effective: {CONSENT_TARGET}. The landlord-change cooldown runs until {VARIATION_COOLDOWN_UNTIL_DATE}."}
    },
    VARIATION_COSTS_SETTLED = {
        FORMAL={"The outstanding professional costs associated with the accepted {CONSENT_TYPE} application have now been collected in full.", "Payment of the legal and administration costs for reference {REFERENCE} is recorded."},
        WARM={"The outstanding legal and administration costs for your earlier request have now been settled.", "The professional costs connected with {CONSENT_TARGET} have now been paid."},
        DIRECT={"Outstanding tenancy variation costs paid in full.", "Professional costs settled for {REFERENCE}."},
        BALANCED={"The outstanding legal and administration costs for the accepted variation have now been collected.", "Professional costs for the approved {CONSENT_TYPE} request are now settled."}
    }
}

local CONDITION_FACTS = {
    PERMANENT_GRASS="the permanent grass must remain undisturbed",
    BOUNDARY_CONSENT="boundary removal continues to require prior consent",
    IMPROVEMENT_CONSENT="capital improvements continue to require written consent",
    TENANT_MAINTENANCE="the tenant remains responsible for ordinary holding maintenance",
    AGRICULTURAL_USE="the holding remains restricted to agricultural use",
    BREAK_CLAUSE="the existing break provisions continue to apply"
}

local CONDITION_TEMPLATES = {
    FORMAL={"For the avoidance of doubt, {CONDITION}.", "The proposed terms continue to provide that {CONDITION}."},
    WARM={"I'd also want us to be clear that {CONDITION}.", "The practical point I still need protected is that {CONDITION}."},
    DIRECT={"Condition: {CONDITION}.", "The terms still require that {CONDITION}."},
    BALANCED={"The heads of terms also retain the requirement that {CONDITION}.", "One continuing condition is that {CONDITION}."}
}

local PACKAGE_TEMPLATES = {
    FORMAL={"The proposed covenant package records: {PACKAGE_SUMMARY}.", "For completeness, the draft heads provide: {PACKAGE_SUMMARY}."},
    WARM={"On the practical terms, the package is: {PACKAGE_SUMMARY}.", "The working arrangement alongside the rent is: {PACKAGE_SUMMARY}."},
    DIRECT={"Covenants: {PACKAGE_SUMMARY}.", "Other terms: {PACKAGE_SUMMARY}."},
    BALANCED={"The proposed heads also record: {PACKAGE_SUMMARY}.", "Alongside the rent, the covenant package is: {PACKAGE_SUMMARY}."}
}

local CLOSINGS = {
    RECORD_ONLY = {
        FORMAL={"The agreement will now be administered in accordance with its written terms.", "Please retain the agreement reference with the holding records."},
        WARM={"I hope the arrangement works well for both sides.", "Let's keep the communication straightforward from here."},
        DIRECT={"The written terms now apply.", "Keep to the agreement and the position is clear."},
        BALANCED={"The written agreement now governs the tenancy.", "The arrangement is in place and the holding can be worked under those terms."}
    },
    REPLY = {
        FORMAL={"Please accept, decline or submit a reasoned proposal within {REPLY_MONTHS} month(s).", "A response is required within {REPLY_MONTHS} month(s)."},
        WARM={"Have a think and let me know within {REPLY_MONTHS} month(s) whether we can make it work.", "Come back to me within {REPLY_MONTHS} month(s), either on these terms or with a sensible proposal."},
        DIRECT={"Respond within {REPLY_MONTHS} month(s).", "Accept, decline or counter within {REPLY_MONTHS} month(s)."},
        BALANCED={"You may accept, decline or put forward a proposal within {REPLY_MONTHS} month(s).", "A response is needed within {REPLY_MONTHS} month(s)."}
    },
    WAIT = {
        FORMAL={"A further response will be issued when that review is complete.", "No decision is required from you until the next substantive response."},
        WARM={"I'll come back to you when that work is finished.", "There is nothing more you need to do until I respond."},
        DIRECT={"Wait for the next response.", "No action is required yet."},
        BALANCED={"A further response will follow once the review is complete.", "No action is needed until the next update."}
    },
    REMEDY = {
        FORMAL={"Full reinstatement must be completed by {REMEDY_DEADLINE_DATE}.", "The breaches must be remedied within {REMEDY_MONTHS} month(s)."},
        WARM={"Please put every item right before {REMEDY_DEADLINE_DATE}; I will inspect again then.", "You now have {REMEDY_MONTHS} month(s) to restore the holding fully."},
        DIRECT={"Remedy every breach by {REMEDY_DEADLINE_DATE}.", "Comply within {REMEDY_MONTHS} month(s)."},
        BALANCED={"Every recorded breach must be remedied by {REMEDY_DEADLINE_DATE}.", "The holding must be restored within {REMEDY_MONTHS} month(s)."}
    },
    FINAL_REMEDY = {
        FORMAL={"Failure to complete the required reinstatement by the stated review will result in termination of the tenancy.", "No further extension of the remedy period should be expected."},
        WARM={"This is the last opportunity to restore the holding before the tenancy ends.", "There will not be another informal extension after this deadline."},
        DIRECT={"Miss the final deadline and the tenancy ends.", "No further extension will be given."},
        BALANCED={"This is the final opportunity to remedy the default before the tenancy is terminated.", "No further remedy extension will be available."}
    },
    REVISE = {
        FORMAL={"You may submit one of the remaining {REMAINING_ROUNDS} proposal(s), or accept the current landlord terms.", "A further credible proposal may be submitted while {REMAINING_ROUNDS} round(s) remain."},
        WARM={"There are {REMAINING_ROUNDS} proposal(s) left if you want to try to close the gap.", "You can accept the figure or come back once more while {REMAINING_ROUNDS} round(s) remain."},
        DIRECT={"{REMAINING_ROUNDS} proposal round(s) remain.", "Accept the landlord figure or revise your proposal; {REMAINING_ROUNDS} round(s) remain."},
        BALANCED={"You may accept the current figure or revise your proposal while {REMAINING_ROUNDS} round(s) remain.", "There are {REMAINING_ROUNDS} further proposal round(s) available."}
    },
    DECIDE = {
        FORMAL={"The documented terms are now available for acceptance or rejection.", "Please record a final decision on the issued terms."},
        WARM={"The papers are ready if you want to settle it on that basis.", "It's now for you to decide whether those terms work."},
        DIRECT={"Accept or decline the issued terms.", "A final decision is required."},
        BALANCED={"The issued terms can now be accepted or declined.", "The next step is a final decision on the documented terms."}
    },
    CLOSED = {
        FORMAL={"The correspondence on this tenancy matter is now concluded.", "The tenancy file has been updated accordingly."},
        WARM={"That brings this part of the discussion to a close.", "The position is settled now."},
        DIRECT={"The matter is closed.", "No further tenancy action is outstanding."},
        BALANCED={"The tenancy correspondence is now concluded.", "The tenancy position has been recorded."}
    }
}

local REFERENCE_LINES = {
    FORMAL={"The correspondence reference is {REFERENCE}.", "This position is recorded under reference {REFERENCE}."},
    WARM={"I've had the papers kept under reference {REFERENCE}.", "The file reference for this is {REFERENCE}."},
    DIRECT={"Reference: {REFERENCE}.", "File: {REFERENCE}."},
    BALANCED={"The correspondence is recorded under reference {REFERENCE}.", "Reference: {REFERENCE}."}
}

local LAYOUTS = {
    {"opening", "memory", "core", "package", "packageResponse", "condition", "closing", "reference"},
    {"opening", "core", "package", "packageResponse", "memory", "condition", "reference", "closing"},
    {"memory", "opening", "core", "package", "packageResponse", "condition", "closing", "reference"}
}

local DIRECT_LAYOUTS = {
    {"core", "package", "packageResponse", "memory", "condition", "closing", "reference"},
    {"opening", "core", "package", "packageResponse", "condition", "memory", "closing", "reference"}
}

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return tonumber(value) or 0
end

local function clamp01(value)
    return math.max(0, math.min(1, safeNumber(value)))
end

local function hashString(value)
    local hash = 104729
    value = tostring(value or "")
    for index = 1, #value do
        hash = (hash * 131 + string.byte(value, index) + index * 17) % 2147483647
    end
    return hash
end

local function choose(values, seed, salt)
    if type(values) ~= "table" or #values == 0 then return "" end
    local index = (hashString(tostring(seed or 0) .. ":" .. tostring(salt or "")) % #values) + 1
    return values[index]
end

local function render(template, tokens)
    local text = tostring(template or "")
    text = text:gsub("{([A-Z0-9_]+)}", function(key) return tostring(tokens[key] or "") end)
    text = text:gsub("%s+", " ")
    return (text:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function formatMoney(value)
    value = math.max(0, safeNumber(value))
    if g_i18n ~= nil and g_i18n.formatMoney ~= nil then return g_i18n:formatMoney(value, 0, true, true) end
    return string.format("%.0f", value)
end

local TENANCY_MONTH_KEYS = {
    "rff_month_january", "rff_month_february", "rff_month_march", "rff_month_april",
    "rff_month_may", "rff_month_june", "rff_month_july", "rff_month_august",
    "rff_month_september", "rff_month_october", "rff_month_november", "rff_month_december"
}

local TENANCY_MONTH_FALLBACKS = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
}

local function formatPeriodLabel(period)
    period = math.max(0, math.floor(safeNumber(period)))
    if period <= 0 then return "unscheduled" end
    local year = math.floor((period - 1) / 12)
    local seasonPeriod = ((period - 1) % 12) + 1
    local calendarMonth = ((seasonPeriod + 1) % 12) + 1
    local monthName = TENANCY_MONTH_FALLBACKS[calendarMonth]
    if g_i18n ~= nil and g_i18n.formatPeriod ~= nil then
        monthName = g_i18n:formatPeriod(seasonPeriod, false)
    elseif g_i18n ~= nil and g_i18n.getText ~= nil then
        local translated = g_i18n:getText(TENANCY_MONTH_KEYS[calendarMonth])
        if translated ~= nil and translated ~= "" and translated ~= TENANCY_MONTH_KEYS[calendarMonth] then
            monthName = translated
        end
    end
    return string.format("%s Y%d", monthName, year)
end

function RFF_NpcNarrativeService.new(repository)
    local self = setmetatable({}, RFF_NpcNarrativeService)
    self.repository = repository
    return self
end

function RFF_NpcNarrativeService:getBaseVoice(profileId)
    return BASE_VOICES[profileId] or BASE_VOICES.PRIVATE_LANDOWNER
end

function RFF_NpcNarrativeService:ensureTenancyVoice(tenancy, profileId, farmlandId)
    if tenancy == nil then return nil end
    tenancy.narrativeEvents = tenancy.narrativeEvents or {}
    tenancy.narrativeNextEventId = math.max(1, math.floor(safeNumber(tenancy.narrativeNextEventId)))

    local base = self:getBaseVoice(profileId or tenancy.landlord)
    local seed = math.floor(safeNumber(tenancy.npcVoiceSeed))
    if seed <= 0 then
        seed = hashString(string.format("landlord:%s:%d:%d", tostring(profileId or tenancy.landlord or "PRIVATE_LANDOWNER"),
            math.floor(safeNumber(farmlandId or tenancy.farmlandId)), math.floor(safeNumber(tenancy.id))))
    end
    local function varied(value, salt)
        local offset = ((hashString(tostring(seed) .. ":" .. salt) % 17) - 8) / 100
        return clamp01(safeNumber(value) + offset)
    end

    if safeNumber(tenancy.npcVoiceSchemaVersion) < self.SCHEMA_VERSION or tenancy.npcCommunicationStyle == nil or tenancy.npcCommunicationStyle == "" then
        tenancy.npcVoiceSchemaVersion = self.SCHEMA_VERSION
        tenancy.npcVoiceSeed = seed
        tenancy.npcVoiceId = base.voiceId
        tenancy.npcCommunicationStyle = base.style
        tenancy.npcFormality = varied(base.formality, "formality")
        tenancy.npcWarmth = varied(base.warmth, "warmth")
        tenancy.npcVerbosity = varied(base.verbosity, "verbosity")
        tenancy.npcPatience = varied(base.patience, "patience")
        tenancy.npcDirectness = varied(base.directness, "directness")
        tenancy.npcConservatism = varied(base.conservatism, "conservatism")
        tenancy.npcRelationshipWeight = varied(base.relationshipWeight, "relationship")
    end
    return {
        id=tenancy.npcVoiceId or base.voiceId,
        style=tenancy.npcCommunicationStyle or base.style,
        seed=seed,
        formality=clamp01(tenancy.npcFormality), warmth=clamp01(tenancy.npcWarmth),
        verbosity=clamp01(tenancy.npcVerbosity), patience=clamp01(tenancy.npcPatience),
        directness=clamp01(tenancy.npcDirectness), conservatism=clamp01(tenancy.npcConservatism),
        relationshipWeight=clamp01(tenancy.npcRelationshipWeight)
    }
end

function RFF_NpcNarrativeService:inheritTenancyVoice(target, source)
    if target == nil or source == nil then return end
    for _, field in ipairs({"npcVoiceSchemaVersion", "npcVoiceSeed", "npcVoiceId", "npcCommunicationStyle",
        "npcFormality", "npcWarmth", "npcVerbosity", "npcPatience", "npcDirectness",
        "npcConservatism", "npcRelationshipWeight"}) do
        target[field] = source[field]
    end
    target.narrativeEvents = target.narrativeEvents or {}
    target.narrativeNextEventId = math.max(1, math.floor(safeNumber(target.narrativeNextEventId)))
end

function RFF_NpcNarrativeService:getVoiceDescription(tenancy)
    local voice = self:ensureTenancyVoice(tenancy, tenancy ~= nil and tenancy.landlord or nil, tenancy ~= nil and tenancy.farmlandId or nil)
    return voice ~= nil and (VOICE_DESCRIPTIONS[voice.style] or VOICE_DESCRIPTIONS.BALANCED) or VOICE_DESCRIPTIONS.BALANCED
end

function RFF_NpcNarrativeService:getEventLabel(eventType)
    return EVENT_LABELS[eventType] or tostring(eventType or "Correspondence"):gsub("_", " ")
end

function RFF_NpcNarrativeService:getMemoryCode(tenancy, context)
    if context.memoryCode ~= nil and context.memoryCode ~= "" then return context.memoryCode end
    if safeNumber(tenancy.missedPayments) > 0 or safeNumber(tenancy.arrears or tenancy.rentDue) > 0.001 then return "STRAINED" end
    if safeNumber(tenancy.landlordNegotiationRejections) > 0 and context.round ~= nil and safeNumber(context.round) > 1 then return "PREVIOUS_POSITIONS" end
    local relationshipCode = context.relationshipCode or "PROFESSIONAL"
    if relationshipCode == "TRUSTED" or relationshipCode == "STRONG" then return "TRUSTED" end
    if safeNumber(tenancy.paymentsMade) >= 12 then return "RELIABLE" end
    if relationshipCode == "ESTABLISHED" or safeNumber(tenancy.paymentsMade) >= 3 then return "ESTABLISHED" end
    if relationshipCode == "STRAINED" then return "STRAINED" end
    return "NEW"
end

function RFF_NpcNarrativeService:getCondition(tenancy, context, seed)
    if context.conditionText ~= nil and context.conditionText ~= "" then
        return context.conditionCode or "CUSTOM", context.conditionText
    end
    local conditions = {}
    if tenancy.permanentGrassRestriction == true then conditions[#conditions + 1] = "PERMANENT_GRASS" end
    if tenancy.boundaryRemovalRequiresConsent ~= false then conditions[#conditions + 1] = "BOUNDARY_CONSENT" end
    if tenancy.improvementsRequireConsent ~= false then conditions[#conditions + 1] = "IMPROVEMENT_CONSENT" end
    if tenancy.tenantMaintenanceObligation ~= false then conditions[#conditions + 1] = "TENANT_MAINTENANCE" end
    if tenancy.agriculturalUsePermitted ~= false then conditions[#conditions + 1] = "AGRICULTURAL_USE" end
    if tenancy.breakEnabled == true then conditions[#conditions + 1] = "BREAK_CLAUSE" end
    if #conditions == 0 then return "", "" end
    local code = choose(conditions, seed, "conditionCode")
    return code, CONDITION_FACTS[code] or ""
end

function RFF_NpcNarrativeService:findTenancyEventByToken(tenancy, token)
    if tenancy == nil or token == nil or token == "" then return nil end
    for _, event in ipairs(tenancy.narrativeEvents or {}) do
        if event.token == token then return event end
    end
    return nil
end

function RFF_NpcNarrativeService:composeTenancyText(tenancy, eventType, context, voice, seed)
    local style = voice.style or "BALANCED"
    local action = EVENT_ACTIONS[eventType] or "WAIT"
    local relationshipCode = context.relationshipCode or "PROFESSIONAL"
    local memoryCode = self:getMemoryCode(tenancy, context)
    local conditionCode, conditionText = self:getCondition(tenancy, context, seed)
    local tokens = {
        LANDLORD_NAME=context.landlordName or "The landlord",
        HOLDING=context.holdingName or tenancy.holdingName or tenancy.agreementId or "the holding",
        PLAYER_NAME=context.playerName or "Farmer",
        FARMLAND_ID=math.max(0, math.floor(safeNumber(context.farmlandId or tenancy.farmlandId))),
        LANDLORD_RENT=formatMoney(context.landlordRent or tenancy.renewalOfferAnnualRent or tenancy.annualRent),
        TENANT_RENT=formatMoney(context.tenantRent or tenancy.renewalTenantProposalRent),
        COUNTER_RENT=formatMoney(context.counterRent or tenancy.renewalLandlordCounterRent or tenancy.renewalOfferAnnualRent),
        AGREED_RENT=formatMoney(context.agreedRent or tenancy.renewalNegotiatedAnnualRent or tenancy.renewalOfferAnnualRent),
        TERM_MONTHS=math.max(0, math.floor(safeNumber(context.termMonths or tenancy.renewalOfferTermMonths or tenancy.termMonths))),
        PAYMENT_FREQUENCY=tostring(context.paymentFrequency or tenancy.renewalOfferPaymentFrequency or tenancy.paymentFrequency or "MONTHLY"):gsub("_", " "):lower(),
        REPLY_MONTHS=math.max(0, math.floor(safeNumber(context.replyMonths))),
        REMAINING_ROUNDS=math.max(0, math.floor(safeNumber(context.remainingRounds))),
        REFERENCE=context.reference or tenancy.renewalLegalReference or "",
        SUCCESSOR_AGREEMENT=context.successorAgreement or "-",
        CONDITION=conditionText,
        RELATIONSHIP=relationshipCode,
        PACKAGE_SUMMARY=context.packageSummary or "",
        PACKAGE_RESPONSE=context.packageResponse or "",
        CONSENT_TYPE=context.consentType or "the consent covenant",
        CONSENT_TARGET=context.consentTarget or "the proposed works",
        CONSENT_CONDITIONS=context.consentConditions or "the written conditions are observed",
        VARIATION_NOTICE_MONTHS=math.max(0, math.floor(safeNumber(context.variationNoticeMonths))),
        VARIATION_EFFECTIVE_PERIOD=math.max(0, math.floor(safeNumber(context.variationEffectivePeriod))),
        VARIATION_EFFECTIVE_DATE=formatPeriodLabel(context.variationEffectivePeriod),
        VARIATION_COOLDOWN_MONTHS=math.max(0, math.floor(safeNumber(context.variationCooldownMonths))),
        VARIATION_COOLDOWN_UNTIL_PERIOD=math.max(0, math.floor(safeNumber(context.variationCooldownUntilPeriod))),
        VARIATION_COOLDOWN_UNTIL_DATE=formatPeriodLabel(context.variationCooldownUntilPeriod),
        PROFESSIONAL_FEE=context.professionalFeeText or "",
        INSPECTION_SUMMARY=context.inspectionSummary or "No inspection summary is available",
        INSPECTION_ACTION=context.inspectionAction or "The position has been recorded.",
        LANDLORD_APPROACH=context.landlordApproach or "balanced",
        REMEDY_MONTHS=math.max(0, math.floor(safeNumber(context.remedyMonths))),
        REMEDY_DEADLINE_PERIOD=math.max(0, math.floor(safeNumber(context.remedyDeadlinePeriod))),
        REMEDY_DEADLINE_DATE=formatPeriodLabel(context.remedyDeadlinePeriod),
        NEXT_REVIEW_PERIOD=math.max(0, math.floor(safeNumber(context.nextReviewPeriod))),
        NEXT_REVIEW_DATE=formatPeriodLabel(context.nextReviewPeriod),
        TERMINATION_EFFECTIVE_PERIOD=math.max(0, math.floor(safeNumber(context.terminationEffectivePeriod))),
        TERMINATION_EFFECTIVE_DATE=formatPeriodLabel(context.terminationEffectivePeriod),
        LEGAL_CHARGE=formatMoney(context.legalCharge),
        DEPOSIT_APPLIED=formatMoney(context.depositApplied),
        DEPOSIT_RETURNED=formatMoney(context.depositReturned),
        FINAL_BALANCE=formatMoney(context.finalBalance),
        LANDLORD_DESCRIPTION=context.landlordDescription or "",
        LANDLORD_PRIORITIES=context.landlordPriorities or "",
        CREDIT_SCORE=math.max(0, math.floor(safeNumber(context.creditScore))),
        CREDIT_BAND=context.creditBand or "-",
        CREDIT_CONDUCT=context.creditConduct or "not assessed",
        CREDIT_AFFORDABILITY=context.creditAffordability or "not assessed",
        CREDIT_REASON=context.creditReason or "the application has been assessed",
        DEPOSIT_MONTHS=math.max(0, math.floor(safeNumber(context.depositMonths))),
        DEPOSIT_AMOUNT=formatMoney(context.depositAmount),
        LEGAL_FEE=formatMoney(context.legalFee),
        UPFRONT_COSTS=formatMoney(context.upfrontCosts)
    }

    local blocks = {}
    blocks.opening = render(choose(OPENINGS[style] or OPENINGS.BALANCED, seed, "opening"), tokens)
    local memoryPool = MEMORY_LINES[memoryCode] or MEMORY_LINES.NEW
    blocks.memory = render(choose(memoryPool[style] or memoryPool.BALANCED, seed, "memory"), tokens)
    if eventType == "LANDLORD_VARIATION_LEGAL_REVIEW" or eventType == "LANDLORD_INTRODUCTION" then
        blocks.opening = ""
    end
    if eventType == "LANDLORD_VARIATION_LEGAL_REVIEW" then
        blocks.memory = ""
    end
    if eventType == "APPLICATION_RECEIVED" or eventType == "LANDLORD_INTRODUCTION"
        or eventType == "CREDIT_ASSESSMENT" or eventType == "INITIAL_HEADS"
        or eventType == "APPLICATION_DECLINED" or eventType == "APPLICATION_WITHDRAWN"
        or eventType == "COVENANT_FINAL_WARNING" or eventType == "COVENANT_TERMINATION_NOTICE"
        or eventType == "COVENANT_TERMINATED" then
        blocks.memory = ""
    end
    if eventType == "COVENANT_COSTS_SETTLED" or eventType == "HANDBACK_SETTLEMENT" then
        blocks.opening = ""
        blocks.memory = ""
    end
    local eventPool = EVENT_LINES[eventType] or EVENT_LINES.PROPOSAL_RECEIVED
    blocks.core = render(choose(eventPool[style] or eventPool.BALANCED, seed, "core"), tokens)
    blocks.package = ""
    if tokens.PACKAGE_SUMMARY ~= "" then
        blocks.package = render(choose(PACKAGE_TEMPLATES[style] or PACKAGE_TEMPLATES.BALANCED, seed, "package"), tokens)
    end
    blocks.packageResponse = render(tokens.PACKAGE_RESPONSE, tokens)
    blocks.condition = ""
    if tokens.PACKAGE_SUMMARY == "" and conditionText ~= "" and (eventType == "TENANCY_STARTED" or eventType == "RENEWAL_OFFER"
        or eventType == "TERMS_AGREED" or eventType == "COUNTER_OFFER" or eventType == "FINAL_COUNTER") then
        blocks.condition = render(choose(CONDITION_TEMPLATES[style] or CONDITION_TEMPLATES.BALANCED, seed, "condition"), tokens)
    end
    local closingPool = CLOSINGS[action] or CLOSINGS.WAIT
    blocks.closing = render(choose(closingPool[style] or closingPool.BALANCED, seed, "closing"), tokens)
    if eventType == "COVENANT_COSTS_SETTLED" or eventType == "HANDBACK_SETTLEMENT" then blocks.closing = "" end
    blocks.reference = ""
    if tokens.REFERENCE ~= "" then
        blocks.reference = render(choose(REFERENCE_LINES[style] or REFERENCE_LINES.BALANCED, seed, "reference"), tokens)
    end

    local layouts = style == "DIRECT" and DIRECT_LAYOUTS or LAYOUTS
    local layout = choose(layouts, seed, "layout")
    local parts = {}
    for _, blockName in ipairs(layout) do
        local value = blocks[blockName]
        if value ~= nil and value ~= "" then parts[#parts + 1] = value end
    end
    if tokens.PROFESSIONAL_FEE ~= "" then parts[#parts + 1] = tokens.PROFESSIONAL_FEE end
    return table.concat(parts, " "), conditionCode, memoryCode
end

function RFF_NpcNarrativeService:createTenancyEvent(tenancy, eventType, context)
    if tenancy == nil then return nil, false end
    context = context or {}
    local voice = self:ensureTenancyVoice(tenancy, context.profileId or tenancy.landlord, tenancy.farmlandId)
    local round = math.max(0, math.floor(safeNumber(context.round or tenancy.renewalNegotiationAttempts)))
    local day = math.max(0, math.floor(safeNumber(context.day)))
    local period = math.max(0, math.floor(safeNumber(context.period)))
    if period <= 0 and self.repository ~= nil and self.repository.getCurrentPeriodIndex ~= nil then
        period = math.max(0, math.floor(safeNumber(self.repository:getCurrentPeriodIndex())))
    end
    local token = tostring(context.token or string.format("tenancy:%d:%s:%d:%d", safeNumber(tenancy.id), tostring(eventType), round, day))
    local existing = self:findTenancyEventByToken(tenancy, token)
    if existing ~= nil then return existing, false end

    local seed = hashString(string.format("%d:%s:%s", voice.seed or 0, token, tostring(eventType)))
    local text, conditionCode, memoryCode = self:composeTenancyText(tenancy, eventType, context, voice, seed)
    local id = math.max(1, math.floor(safeNumber(tenancy.narrativeNextEventId)))
    local event = {
        id=id, token=token, eventType=eventType, label=self:getEventLabel(eventType), text=text,
        speaker=context.landlordName or "The landlord", day=day, period=period, round=round, seed=seed,
        voiceId=voice.id, style=voice.style, documentStatus=context.documentStatus or tenancy.renewalDocumentStatus or "",
        reference=context.reference or tenancy.renewalLegalReference or "", outcome=context.outcome or "",
        tenantRent=math.max(0, safeNumber(context.tenantRent or tenancy.renewalTenantProposalRent)),
        landlordRent=math.max(0, safeNumber(context.landlordRent or context.counterRent or tenancy.renewalOfferAnnualRent or tenancy.annualRent)),
        termMonths=math.max(0, math.floor(safeNumber(context.termMonths or tenancy.renewalOfferTermMonths or tenancy.termMonths))),
        relationshipCode=context.relationshipCode or "PROFESSIONAL",
        relationshipPoints=safeNumber(context.relationshipPoints or tenancy.landlordRelationshipPoints),
        memoryCode=memoryCode, conditionCode=conditionCode,
        packageSummary=context.packageSummary or "", packageResponse=context.packageResponse or "",
        tenantPackage=context.tenantPackage or "", landlordPackage=context.landlordPackage or "",
        consentType=context.consentType or "", consentTarget=context.consentTarget or "",
        consentConditions=context.consentConditions or "",
        variationNoticeMonths=math.max(0, math.floor(safeNumber(context.variationNoticeMonths))),
        variationEffectivePeriod=math.max(0, math.floor(safeNumber(context.variationEffectivePeriod))),
        variationCooldownMonths=math.max(0, math.floor(safeNumber(context.variationCooldownMonths))),
        variationCooldownUntilPeriod=math.max(0, math.floor(safeNumber(context.variationCooldownUntilPeriod)))
    }
    tenancy.narrativeEvents[#tenancy.narrativeEvents + 1] = event
    tenancy.narrativeNextEventId = id + 1
    tenancy.narrativeLatestEventId = id
    tenancy.narrativeLatestEventType = eventType
    tenancy.narrativeLatestText = text
    return event, true
end

function RFF_NpcNarrativeService:getLatestTenancyEvent(tenancy)
    if tenancy == nil then return nil end
    local events = tenancy.narrativeEvents or {}
    return events[#events]
end

function RFF_NpcNarrativeService:getTenancyEvent(tenancy, index)
    if tenancy == nil then return nil, 0, 0 end
    local events = tenancy.narrativeEvents or {}
    if #events == 0 then return nil, 0, 0 end
    index = math.max(1, math.min(#events, math.floor(safeNumber(index))))
    return events[index], index, #events
end
