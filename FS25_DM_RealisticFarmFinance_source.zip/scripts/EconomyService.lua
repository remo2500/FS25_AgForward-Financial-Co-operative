-- Original RFF reduced-form economy. Indicators model the surrounding economy,
-- not measured FS output or a replacement for the game's commodity-price system.
RFF_EconomyService = {}
RFF_EconomyService.__index = RFF_EconomyService
local E = RFF_EconomyService
local ROOT = "realisticFarmFinance.economy"
local FIELDS = {"period", "seed", "nextDriver", "nextReview", "activity", "inflation", "baseRate", "credit", "demand", "supply", "demandTarget", "supplyTarget", "realRateLag", "lastChange", "lastReview"}
local function clamp(n,a,b) return math.max(a,math.min(b,n)) end
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<math.huge end
local function move(n,target,speed,limit) return n+clamp((target-n)*speed,-limit,limit) end
local function random(s)
    s.seed=(s.seed*16807)%2147483647
    return s.seed/2147483647
end
local function copy(s)
    local c={history={}}
    for _,k in ipairs(FIELDS) do c[k]=s[k] end
    return c
end
function E.new(repository)
    return setmetatable({repository=repository},E)
end
function E.create(period,seed)
    local s={period=period,seed=clamp(math.floor(seed or 1),1,2147483646),nextDriver=period,
        nextReview=period+3,activity=0,inflation=2.5,baseRate=5.5,credit=0,demand=0,supply=0,
        demandTarget=0,supplyTarget=0,realRateLag=3,lastChange=0,lastReview=period,history={}}
    return s
end
function E.step(s,forecast)
    local period=s.period+1
    if not forecast and period>=s.nextDriver then
        -- Only slow external demand/cost targets vary. Rates and credit are responses,
        -- never independent dice rolls. Private saved PRNG cannot be rerolled by menus.
        s.demandTarget=clamp(s.demandTarget*.35+(random(s)*2-1)*1.8,-2,2)
        s.supplyTarget=clamp(s.supplyTarget*.35+(random(s)*2-1)*1.4,-1.6,1.6)
        s.nextDriver=period+18+math.floor(random(s)*19)
    end
    local activity=move(s.activity,1.1*s.demand-.4*s.supply-.65*(s.realRateLag-3)-.45*s.credit,.08,.12)
    local inflation=move(s.inflation,2.5+.7*s.activity+.65*s.supply,.055,.12)
    local credit=move(s.credit,clamp(.4*math.max(-s.activity,0)+.25*math.max(s.supply,0)+.12*math.max(s.baseRate-5.5,0),0,2),.08,.08)
    s.realRateLag=move(s.realRateLag,s.baseRate-s.inflation,.14,.15)
    s.demand=move(s.demand,s.demandTarget,.05,.10)
    s.supply=move(s.supply,s.supplyTarget,.04,.08)
    s.activity=clamp(activity,-3.5,3.5)
    s.inflation=clamp(inflation,0,8)
    s.credit=clamp(credit,0,2)
    if period>=s.nextReview then
        local target=clamp(5.5+1.15*(s.inflation-2.5)+.35*s.activity,1,10)
        local difference=target-s.baseRate
        s.lastChange=math.abs(difference)>=.20 and (difference>0 and .25 or -.25) or 0
        s.baseRate=clamp(s.baseRate+s.lastChange,1,10)
        s.lastReview=period;s.nextReview=period+3
    end
    s.period=period
    s.history[#s.history+1]={period=period,activity=s.activity,inflation=s.inflation,baseRate=s.baseRate,credit=s.credit}
    if #s.history>60 then table.remove(s.history,1) end
end
function E:advance()
    if g_currentMission==nil or not g_currentMission:getIsServer() or not self.repository.loaded then return end
    local period=math.floor(self.repository:getCurrentPeriodIndex())
    local s=self.repository.economyState
    if s==nil then
        s=E.create(period,math.random(1,1000000));self.repository.economyState=s
    end
    -- Calendar periods, not day count: identical progression at every days/month setting.
    -- Reject backwards time; loading or opening the menu never repeats a month.
    while s.period<period do
        if self.repository.investmentService then self.repository.investmentService:processTo(s.period+1) end
        E.step(s,false)
    end
end
function E.forecast(s,months)
    local c=copy(s)
    for _=1,months do E.step(c,true) end
    return c
end
function E.date(period)
    local p=(period-1)%12+1
    local names={"March","April","May","June","July","August","September","October","November","December","January","February"}
    local month=g_i18n~=nil and g_i18n.formatPeriod~=nil and g_i18n:formatPeriod(p,false) or names[p]
    return string.format("%s Y%d",month,math.floor((period-1)/12))
end
local function direction(delta,threshold,up,down,flat)
    if delta>threshold then return up elseif delta< -threshold then return down end
    return flat
end
function E:report()
    local s=self.repository.economyState
    if s==nil then return {summary="Economic data is not ready. Reopen this page after the save has loaded."} end
    local f=E.forecast(s,12)
    local activity=direction(s.activity,.35,"Above normal","Below normal","Near normal")
    local conditions=direction(s.activity,.35,"Demand is supporting activity.","Activity is subdued; lenders are more cautious about repayment capacity.","Activity is close to its long-run balance.")
    local costs=direction(s.supply,.2,"External cost pressure is elevated.","External cost pressures are easing.","External cost pressures are fairly balanced.")
    local rateBias=direction(f.baseRate-s.baseRate,.24,"upward","downward","broadly steady")
    local old=s.history[math.max(1,#s.history-12)]
    local trend=old and string.format("Since %s: base rate %+.2f percentage points; inflation %+.2f points.",E.date(old.period),s.baseRate-old.baseRate,s.inflation-old.inflation) or "A new economic history starts with this update; earlier conditions are not invented."
    return {
        date=E.date(s.period),activity=string.format("%s (%+.2f)",activity,s.activity),inflation=string.format("%.2f%%",s.inflation),
        baseRate=string.format("%.2f%%",s.baseRate),credit=string.format("+%.2f percentage points",s.credit),
        bankRate=string.format("%.2f%% p.a.",math.max(.25,s.baseRate-4)),review=E.date(s.nextReview),
        summary=conditions.." "..costs.." Interest rates respond gradually, with quarterly reviews and delayed effects on demand.",
        history=trend,
        outlook=string.format("Next 12 months: %s pressure on base rates. Activity looks %s and inflation %s if current external pressures persist. This is a conditional outlook, not a promised rate or return. Confidence falls further into the future.",rateBias,
            direction(f.activity-s.activity,.15,"firmer","weaker","broadly stable"),direction(f.inflation-s.inflation,.15,"higher","lower","broadly stable")),
        borrowing="New loan, mortgage and equipment-finance quotes follow the base rate and bank funding margin. Lenders also change appetite and terms. Your own credit record, collateral and affordability still matter. Existing fixed agreements keep their agreed rate.",
        planning=rateBias=="upward" and "Allow headroom for higher future borrowing quotes. Keep working cash available before locking money away. Comparing a fixed offer may be useful, but rates can develop differently." or rateBias=="downward" and "Future borrowing quotes may ease, but waiting is not guaranteed to be cheaper. Check fees before refinancing. Keep cash available for seasonal bills." or "Plan around affordability rather than trying to time a rate change. Keep a cash buffer for seasonal bills and unexpected repairs.",
        scope="Variable savings follow the economy; fixed deposits keep their opening rate. Economy-linked funds in Banking - Investments can gain or lose capital and have holding restrictions. Game crop, shop and land prices are unchanged. Crop-shortfall loans retain fixed 8% terms."
    }
end
function E.save(repository,xml)
    local s=repository.economyState;if s==nil then return end
    xml:setInt(ROOT.."#version",1)
    -- Float storage loses PRNG precision; numeric attributes use round-trip strings.
    for _,k in ipairs(FIELDS) do xml:setString(ROOT.."#"..k,string.format("%.17g",s[k])) end
    for i,h in ipairs(s.history) do
        local key=ROOT..".history.month("..(i-1)..")"
        for k,v in pairs(h) do xml:setString(key.."#"..k,string.format("%.17g",v)) end
    end
end
function E.load(repository,xml)
    repository.economyState=nil
    if xml:getInt(ROOT.."#version")~=1 then return end
    local s={history={}}
    for _,k in ipairs(FIELDS) do s[k]=tonumber(xml:getString(ROOT.."#"..k));if not finite(s[k]) then return end end
    if s.period<0 or s.period%1~=0 or s.seed<1 or s.seed>2147483646 or s.seed%1~=0 or
        s.baseRate<1 or s.baseRate>10 or s.inflation<0 or s.inflation>8 or math.abs(s.activity)>3.5 or
        s.credit<0 or s.credit>2 or math.abs(s.demand)>2 or math.abs(s.supply)>1.6 or
        math.abs(s.demandTarget)>2 or math.abs(s.supplyTarget)>1.6 or
        s.nextReview<s.period or s.nextReview>s.period+3 or s.nextDriver>s.period+37 then return end
    for i=0,59 do
        local key=ROOT..".history.month("..i..")"
        if not xml:hasProperty(key) then break end
        local h={};local valid=true
        for _,k in ipairs({"period","activity","inflation","baseRate","credit"}) do
            h[k]=tonumber(xml:getString(key.."#"..k));valid=valid and finite(h[k])
        end
        if valid and h.period<=s.period then s.history[#s.history+1]=h end
    end
    repository.economyState=s
end
function E:consoleTest(action,months)
    local s=self.repository.economyState;if s==nil then return "Economy not ready." end
    action=string.upper(tostring(action or "STATUS"))
    if action=="SIMULATE" then
        local n=tonumber(months) or 60
        if not finite(n) then return "Use SIMULATE 1..600" end
        n=clamp(math.floor(n),1,600)
        local c=copy(s)
        for i=1,n do
            E.step(c,false)
            if i%12==0 or i==n then print(string.format("[RFF economy TEST COPY] %s | activity %+.2f inflation %.2f%% base %.2f%% funding +%.2f",E.date(c.period),c.activity,c.inflation,c.baseRate,c.credit)) end
        end
        return "Simulation only: live economy, finances and saved random state are unchanged."
    end
    if action~="STATUS" then return "rffEconomy STATUS | SIMULATE 60 (read-only copy)" end
    return string.format("[RFF economy] %s | activity %+.2f inflation %.2f%% base %.2f%% funding +%.2f | next review %s",E.date(s.period),s.activity,s.inflation,s.baseRate,s.credit,E.date(s.nextReview))
end
