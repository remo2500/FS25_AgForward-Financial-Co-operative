RFF_VehicleComplianceService = {}
RFF_VehicleComplianceService.__index = RFF_VehicleComplianceService

RFF_VehicleComplianceService.CATEGORY_B = "B"
RFF_VehicleComplianceService.CATEGORY_F = "F"
RFF_VehicleComplianceService.CATEGORY_H = "H"
RFF_VehicleComplianceService.CATEGORY_C = "C"
RFF_VehicleComplianceService.LICENCE_MODE_FULL = "FULL"
RFF_VehicleComplianceService.LICENCE_MODE_REQUIRED = "REQUIRED"
RFF_VehicleComplianceService.ROAD_WIDTH_AUTHORISATION_METRES = 3.0
RFF_VehicleComplianceService.ROAD_MASS_AUTHORISATION_TONNES = 44
RFF_VehicleComplianceService.MOVEMENT_AUTHORISATION_HOURS = 4
RFF_VehicleComplianceService.ADS_MINIMUM_CONDITION = 0.35
RFF_VehicleComplianceService.PENALTY_SPEED_KMH = 25
RFF_VehicleComplianceService.PENALTY_THRESHOLD = 12
RFF_VehicleComplianceService.POINTS_EXPIRY_MONTHS = 6
RFF_VehicleComplianceService.PENALTY_MAX_MONTHS = 6
RFF_VehicleComplianceService.ASSESSMENT_NONE = "NONE"
RFF_VehicleComplianceService.ASSESSMENT_BOOKED = "BOOKED"
RFF_VehicleComplianceService.ASSESSMENT_SPAWNING = "SPAWNING"
RFF_VehicleComplianceService.ASSESSMENT_PRACTICAL = "PRACTICAL"
RFF_VehicleComplianceService.ASSESSMENT_RETURNING = "RETURNING"
RFF_VehicleComplianceService.ASSESSMENT_RETURNING_FAILED = "RETURNING_FAILED"
RFF_VehicleComplianceService.ASSESSMENT_THEORY = "THEORY"
RFF_VehicleComplianceService.ASSESSMENT_FAILED = "FAILED"
RFF_VehicleComplianceService.ASSESSMENT_PASSED = "PASSED"
RFF_VehicleComplianceService.OFFENCE_POINTS_BY_SEVERITY = {
    MINOR=3,
    MODERATE=4,
    SERIOUS=6,
    SEVERE=9
}

RFF_VehicleComplianceService.LICENCE_CONFIG = {
    F = {
        fee=350, theoryRetakeFee=75,
        vehicleXml="$data/vehicles/zetor/proximaHS120/proximaHS120.xml",
        distance=3000, roadDistance=1800, reverseDistance=75, movingSeconds=240,
        turnDegrees=180, speedFaultSeconds=4
    },
    H = {
        fee=450, theoryRetakeFee=75,
        vehicleXml="$data/vehicles/newHolland/tk4/tk4.xml",
        distance=500, roadDistance=300, reverseDistance=25, movingSeconds=150,
        turnDegrees=90, speedFaultSeconds=4
    },
    C = {
        fee=650, theoryRetakeFee=75,
        vehicleXml="$data/vehicles/international/cvSeries/cvSeries.xml",
        distance=4000, roadDistance=2400, reverseDistance=100, movingSeconds=300,
        turnDegrees=180, speedFaultSeconds=4
    },
    ADR = {fee=250, theoryOnly=true}
}

RFF_VehicleComplianceService.THEORY_QUESTIONS = {
    F = {
        {key="rff_licence_theory_f_1", answer=true},
        {key="rff_licence_theory_f_2", answer=false},
        {key="rff_licence_theory_f_3", answer=true},
        {key="rff_licence_theory_f_4", answer=false},
        {key="rff_licence_theory_f_5", answer=true}
    },
    H = {
        {key="rff_licence_theory_h_1", answer=true},
        {key="rff_licence_theory_h_2", answer=false},
        {key="rff_licence_theory_h_3", answer=true},
        {key="rff_licence_theory_h_4", answer=false},
        {key="rff_licence_theory_h_5", answer=true}
    },
    C = {
        {key="rff_licence_theory_c_1", answer=true},
        {key="rff_licence_theory_c_2", answer=false},
        {key="rff_licence_theory_c_3", answer=true},
        {key="rff_licence_theory_c_4", answer=false},
        {key="rff_licence_theory_c_5", answer=true}
    },
    ADR = {
        {key="rff_licence_theory_adr_1", answer=true},
        {key="rff_licence_theory_adr_2", answer=false},
        {key="rff_licence_theory_adr_3", answer=true},
        {key="rff_licence_theory_adr_4", answer=false},
        {key="rff_licence_theory_adr_5", answer=true}
    }
}

local CATEGORIES_C = {
    trucks=true, harvesters=true, forageharvesters=true, beetharvesters=true,
    beetloading=true, potatoharvesting=true, vegetableharvesters=true,
    spinachharvesters=true, greenbeanharvesters=true, peaharvesters=true,
    riceharvesters=true, sugarcaneharvesters=true, cottonharvesters=true,
    oliveharvesters=true, grapeharvesters=true, forestryharvesters=true,
    forestryforwarders=true, forestryexcavators=true, woodchippers=true,
    frontloadervehicles=true, teleloadervehicles=true, wheelloadervehicles=true,
    skidsteervehicles=true, forklifts=true, miscdrivables=true
}

local HAZARDOUS_LOADS = {
    DIESEL=true,
    METHANE=true
}

local function safeNumber(value, fallback)
    local numberValue = tonumber(value)
    if numberValue == nil or numberValue ~= numberValue then return fallback or 0 end
    return numberValue
end

local function call(object, methodName, ...)
    if object == nil or type(object[methodName]) ~= "function" then return false, nil end
    local ok, value = pcall(object[methodName], object, ...)
    if not ok then return false, nil end
    return true, value
end

local function getRootVehicle(vehicle)
    local ok, root = call(vehicle, "getRootVehicle")
    return ok and root ~= nil and root or vehicle
end

local function getVehicleChain(vehicle)
    vehicle = getRootVehicle(vehicle)
    local ok, children = call(vehicle, "getChildVehicles")
    if ok and type(children) == "table" and #children > 0 then return children, vehicle end
    return vehicle ~= nil and {vehicle} or {}, vehicle
end

local function getVehicleName(vehicle)
    local ok, name = call(vehicle, "getFullName")
    if ok and name ~= nil and tostring(name) ~= "" then return tostring(name) end
    ok, name = call(vehicle, "getName")
    if ok and name ~= nil and tostring(name) ~= "" then return tostring(name) end
    return tostring(vehicle ~= nil and vehicle.typeName or "Vehicle")
end

local function getText(key, fallback)
    if g_i18n ~= nil and type(g_i18n.getText) == "function" then
        local text = g_i18n:getText(key)
        if text ~= nil and text ~= "" and text ~= key then return text end
    end
    return fallback or key
end

local function formatDuration(seconds)
    local total = math.max(0, math.floor(safeNumber(seconds) + 0.5))
    return string.format("%d:%02d", math.floor(total / 60), total % 60)
end

local function otherMoneyType()
    if MoneyType == nil then return nil end
    return MoneyType.OTHER or MoneyType.MISC or MoneyType.SHOP_VEHICLE_BUY
end

function RFF_VehicleComplianceService.new(repository, fleetManagement)
    local self = setmetatable({}, RFF_VehicleComplianceService)
    self.repository = repository
    self.fleetManagement = fleetManagement
    self._assessmentRuntime = {}
    self._trafficCourtesyRetryMs = 0
    self._trafficCourtesyApi = nil
    self._trafficCourtesyRegistered = false
    self._movementAuthorisationCheckMs = 0
    return self
end

function RFF_VehicleComplianceService:ensureQualificationRecord(farmId)
    local state = self.repository ~= nil and self.repository:getFarmState(farmId, true) or nil
    if state == nil then return nil end
    local previousVersion = math.floor(safeNumber(state.driverQualificationVersion, 1))
    local previousStatus = tostring(state.driverAssessmentStatus or self.ASSESSMENT_NONE)
    local activeLegacyAssessment = previousStatus == self.ASSESSMENT_BOOKED or previousStatus == self.ASSESSMENT_SPAWNING
        or previousStatus == self.ASSESSMENT_PRACTICAL or previousStatus == self.ASSESSMENT_RETURNING
        or previousStatus == self.ASSESSMENT_RETURNING_FAILED
        or previousStatus == self.ASSESSMENT_THEORY
    state.driverQualificationVersion = math.max(4, math.floor(safeNumber(state.driverQualificationVersion, 4)))
    if (state.driverLicenceMode == nil or tostring(state.driverLicenceMode) == "") and previousVersion < 3 and activeLegacyAssessment then
        state.driverLicenceMode = self.LICENCE_MODE_REQUIRED
    end
    state.driverLicenceMode = string.upper(tostring(state.driverLicenceMode or self.LICENCE_MODE_FULL))
    if state.driverLicenceMode ~= self.LICENCE_MODE_REQUIRED then state.driverLicenceMode = self.LICENCE_MODE_FULL end
    state.driverCategoryB = true
    state.driverCategoryF = state.driverCategoryF == true
    state.driverCategoryH = state.driverCategoryH == true
    state.driverCategoryC = state.driverCategoryC == true
    state.driverAdr = state.driverAdr == true
    state.driverPenaltyPoints = math.max(0, math.floor(safeNumber(state.driverPenaltyPoints, 0)))
    -- Points now produce an optional speed restriction, never loss of entitlement.
    -- Old saves retain their points and earned categories without a retrospective sentence.
    state.driverSpecialistRevoked = false
    state.driverPenaltiesEnabled = state.driverPenaltiesEnabled == true
    state.driverRestrictionEnd = math.max(0, safeNumber(state.driverRestrictionEnd))
    state.driverRestrictionRepeats = math.max(0, math.floor(safeNumber(state.driverRestrictionRepeats)))
    state.driverRestrictionServedPoints = math.max(0, math.floor(safeNumber(state.driverRestrictionServedPoints)))
    state.driverAssessmentCategory = tostring(state.driverAssessmentCategory or "")
    state.driverAssessmentStatus = tostring(state.driverAssessmentStatus or self.ASSESSMENT_NONE)
    state.driverAssessmentBookedDay = math.max(0, math.floor(safeNumber(state.driverAssessmentBookedDay)))
    state.driverAssessmentAvailableDay = math.max(0, math.floor(safeNumber(state.driverAssessmentAvailableDay)))
    state.driverAssessmentDeadlineDay = math.max(0, math.floor(safeNumber(state.driverAssessmentDeadlineDay)))
    state.driverAssessmentReturnDeadlineHour = math.max(0, safeNumber(state.driverAssessmentReturnDeadlineHour))
    state.driverAssessmentVehicleUniqueId = tostring(state.driverAssessmentVehicleUniqueId or "")
    state.driverAssessmentVehicleName = tostring(state.driverAssessmentVehicleName or "")
    state.driverAssessmentDistance = math.max(0, safeNumber(state.driverAssessmentDistance))
    state.driverAssessmentRoadDistance = math.max(0, safeNumber(state.driverAssessmentRoadDistance))
    state.driverAssessmentReverseDistance = math.max(0, safeNumber(state.driverAssessmentReverseDistance))
    state.driverAssessmentMovingSeconds = math.max(0, safeNumber(state.driverAssessmentMovingSeconds))
    state.driverAssessmentLeftTurnDegrees = math.max(0, safeNumber(state.driverAssessmentLeftTurnDegrees))
    state.driverAssessmentRightTurnDegrees = math.max(0, safeNumber(state.driverAssessmentRightTurnDegrees))
    state.driverAssessmentSpeedFaultSeconds = math.max(0, safeNumber(state.driverAssessmentSpeedFaultSeconds))
    state.driverAssessmentCollisionCount = math.max(0, math.floor(safeNumber(state.driverAssessmentCollisionCount)))
    state.driverAssessmentTheoryIndex = math.max(0, math.floor(safeNumber(state.driverAssessmentTheoryIndex)))
    state.driverAssessmentTheoryScore = math.max(0, math.floor(safeNumber(state.driverAssessmentTheoryScore)))
    state.driverAssessmentFailureReason = tostring(state.driverAssessmentFailureReason or "")
    state.driverAssessmentLastResultCategory = tostring(state.driverAssessmentLastResultCategory or "")
    state.driverAssessmentLastResult = tostring(state.driverAssessmentLastResult or "")
    if type(state.movementAuthorisations) ~= "table" then state.movementAuthorisations = {} end
    if (state.driverPointsVersion or 0) < 1 then self:migrateDriverPoints(farmId, state) end
    return state
end

function RFF_VehicleComplianceService:getQualificationRecord(farmId)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return nil end
    self:expireSpeedPenalty(farmId, state)
    local fullLicence = state.driverLicenceMode == self.LICENCE_MODE_FULL
    return {
        categoryB = true,
        categoryF = fullLicence or state.driverCategoryF == true,
        categoryH = fullLicence or state.driverCategoryH == true,
        categoryC = fullLicence or state.driverCategoryC == true,
        adr = fullLicence or state.driverAdr == true,
        earnedCategoryF = state.driverCategoryF == true,
        earnedCategoryH = state.driverCategoryH == true,
        earnedCategoryC = state.driverCategoryC == true,
        earnedAdr = state.driverAdr == true,
        penaltyPoints = state.driverPenaltyPoints or 0,
        specialistRevoked = not fullLicence and state.driverSpecialistRevoked == true,
        licenceMode = state.driverLicenceMode
    }
end

function RFF_VehicleComplianceService:getLicenceMode(farmId)
    local state = self:ensureQualificationRecord(farmId)
    return state ~= nil and state.driverLicenceMode or self.LICENCE_MODE_FULL
end

-- Fractional game months preserve a full sentence even when it starts late in
-- a month, and follow the save's days-per-month setting without wall-clock time.
function RFF_VehicleComplianceService:getPenaltyClock()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    local period = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    if env == nil then return period end
    local days = math.max(1, safeNumber(env.daysPerPeriod, 1))
    local fraction = (math.max(0, safeNumber(env.currentDayInPeriod, 1) - 1)
        + math.max(0, safeNumber(env.dayTime)) / 86400000) / days
    return period + math.min(0.99999999, fraction)
end

function RFF_VehicleComplianceService:formatRestrictionEnd(endTime)
    local period = math.floor(endTime)
    local season = ((math.max(1, period) - 1) % 12) + 1
    local year = math.floor(math.max(0, period - 1) / 12)
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    local days = math.max(1, safeNumber(env ~= nil and env.daysPerPeriod, 1))
    local dayFraction = (endTime - period) * days
    local day = math.floor(dayFraction + 0.00001) + 1
    local minutes = math.floor((dayFraction - math.floor(dayFraction + 0.00001)) * 1440 + 0.01)
    minutes = math.max(0, math.min(1439, minutes))
    local month = g_i18n ~= nil and g_i18n.formatPeriod ~= nil and g_i18n:formatPeriod(season, false)
        or tostring(season)
    return string.format("%s Y%d, %s %d %02d:%02d", month, year,
        getText("rff_driver_restriction_day", "day"), day, math.floor(minutes / 60), minutes % 60)
end

function RFF_VehicleComplianceService:getSpeedPenalty(farmId)
    local state = self.repository ~= nil and self.repository:getFarmState(farmId, false) or nil
    if state == nil or state.driverPenaltiesEnabled ~= true then return nil end
    if (state.driverRestrictionEnd or 0) <= self:getPenaltyClock() then return nil end
    return self.PENALTY_SPEED_KMH, state
end

function RFF_VehicleComplianceService:setDrivingPenalties(farmId, enabled)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return false end
    state.driverPenaltiesEnabled = enabled == true
    -- Disabling suspends enforcement; the expiry continues to pass normally.
    return true
end

function RFF_VehicleComplianceService:migrateDriverPoints(farmId, state)
    local now = self:getPenaltyClock()
    local served = state.driverRestrictionServedPoints or 0
    local oldActive = math.max(0, (state.driverPenaltyPoints or 0) - served)
    local accountedActive = 0
    for _, offence in ipairs(self.repository.driverOffences or {}) do
        if offence.farmId == farmId then
            -- Older records only stored a season period, not the day within it.
            -- Preserve that known month rather than granting six new months on upgrade.
            offence.pointsIssuedAt = offence.pointsIssuedAt or ((offence.incidentPeriod or 0) > 0 and offence.incidentPeriod or now)
            offence.pointsExpireAt = offence.pointsExpireAt or (offence.pointsIssuedAt + self.POINTS_EXPIRY_MONTHS)
            if offence.status == "ACTIVE" and served > 0 and (offence.pointsTotalAfter or 0) > 0
                and offence.pointsTotalAfter <= served then
                offence.status = "SERVED"
            end
            if offence.status == "ACTIVE" then accountedActive = accountedActive + (offence.points or 0) end
        end
    end
    -- Preserve a legacy balance created before individual offence records existed.
    -- It has no reliable historical date, so its expiry starts at migration.
    if oldActive > accountedActive then
        self.repository:addDriverOffence({
            id=self.repository:getNextDriverOffenceId(), farmId=farmId, source="RFF_LEGACY",
            externalIncidentId="RFF-LEGACY-POINTS-" .. tostring(farmId), status="ACTIVE",
            offenceCode="LEGACY_POINTS", locationType="UNKNOWN", incidentDay=self:getCurrentDay(),
            incidentPeriod=math.floor(now), vehicleName="Legacy driving record", targetName="-",
            severityClass="MINOR", points=oldActive-accountedActive, pointsTotalAfter=oldActive,
            pointsIssuedAt=now, pointsExpireAt=now+self.POINTS_EXPIRY_MONTHS
        })
    end
    state.driverPointsVersion = 1
    state.driverRestrictionServedPoints = 0
    self:refreshDriverPoints(farmId, state)
end

function RFF_VehicleComplianceService:refreshDriverPoints(farmId, state)
    local now = self:getPenaltyClock()
    local deadline = state.driverRestrictionEnd or 0
    local completed = deadline > 0 and now >= deadline
    local total = 0
    for _, offence in ipairs(self.repository.driverOffences or {}) do
        if offence.farmId == farmId and offence.status == "ACTIVE" then
            local issuedAt = offence.pointsIssuedAt or offence.incidentPeriod or now
            local expiresAt = offence.pointsExpireAt or (issuedAt + self.POINTS_EXPIRY_MONTHS)
            offence.pointsIssuedAt, offence.pointsExpireAt = issuedAt, expiresAt
            -- Process in date order after a long time jump or reload: a sentence
            -- served before the six-month anniversary remains marked as served.
            if completed and issuedAt <= deadline and deadline <= expiresAt then
                offence.status, offence.pointsClosedAt = "SERVED", deadline
            elseif now >= expiresAt then
                offence.status, offence.pointsClosedAt = "EXPIRED", expiresAt
            end
            if offence.status == "ACTIVE" then total = total + math.max(0, math.floor(safeNumber(offence.points))) end
        end
    end
    state.driverPenaltyPoints = total
end

function RFF_VehicleComplianceService:expireSpeedPenalty(farmId, state)
    self:refreshDriverPoints(farmId, state)
    if (state.driverRestrictionEnd or 0) <= 0 or self:getPenaltyClock() < state.driverRestrictionEnd then return end
    state.driverRestrictionEnd = 0
    state.driverRestrictionRepeats = 0
    state.driverRestrictionServedPoints = 0
    if state.driverPenaltiesEnabled then
        self:notify(farmId, "rff_driver_restriction_complete_title", "Driving Restriction Completed",
            "rff_driver_restriction_complete", "Your speed restriction has ended. Normal vehicle speeds are restored and the points covered by this restriction have been cleared. Your offence history remains on record.")
    end
end

function RFF_VehicleComplianceService:applyOffenceSpeedPenalty(farmId, state)
    self:expireSpeedPenalty(farmId, state)
    if not state.driverPenaltiesEnabled then return "OFF" end
    local now = self:getPenaltyClock()
    local action
    if state.driverRestrictionEnd > now then
        state.driverRestrictionRepeats = state.driverRestrictionRepeats + 1
        local extension = math.min(3, state.driverRestrictionRepeats)
        state.driverRestrictionEnd = math.min(now + self.PENALTY_MAX_MONTHS, state.driverRestrictionEnd + extension)
        action = state.driverRestrictionRepeats == 1 and "EXTENDED"
            or (state.driverRestrictionRepeats == 2 and "FINAL" or "REPEAT")
    elseif (state.driverPenaltyPoints or 0) >= self.PENALTY_THRESHOLD then
        state.driverRestrictionEnd = now + 1
        state.driverRestrictionRepeats = 0
        action = "STARTED"
    end
    return action
end

function RFF_VehicleComplianceService:getControlledPenalty(vehicle)
    if vehicle == nil or g_currentMission == nil or g_localPlayer == nil then return nil end
    if vehicle.getIsAIActive ~= nil and vehicle:getIsAIActive() then return nil end
    local controlled = g_localPlayer.getCurrentVehicle ~= nil and g_localPlayer:getCurrentVehicle() or nil
    if controlled == nil or getRootVehicle(controlled) ~= vehicle then return nil end
    local farmId = g_currentMission.getFarmId ~= nil and g_currentMission:getFarmId() or 0
    return self:getSpeedPenalty(farmId)
end

function RFF_VehicleComplianceService:installSpeedPenaltyHook()
    if VehicleMotor == nil or type(VehicleMotor.setSpeedLimit) ~= "function" then return end
    RFF_VehicleComplianceService._speedPenaltyService = self
    if RFF_VehicleComplianceService._speedPenaltyHookInstalled then return end
    local original = VehicleMotor.setSpeedLimit
    VehicleMotor.setSpeedLimit = function(motor, limit, ...)
        local service = RFF_VehicleComplianceService._speedPenaltyService
        local cap = service ~= nil and service:getControlledPenalty(motor.vehicle) or nil
        if cap ~= nil then limit = math.min(limit, cap) end
        return original(motor, limit, ...)
    end
    RFF_VehicleComplianceService._speedPenaltyHookInstalled = true
end

function RFF_VehicleComplianceService:getRestrictionSummary(farmId)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return "" end
    self:expireSpeedPenalty(farmId, state)
    local active = state.driverRestrictionEnd > self:getPenaltyClock()
    if active then
        local key = state.driverPenaltiesEnabled and "rff_driver_restriction_active" or "rff_driver_restriction_paused"
        local summary = string.format(getText(key, "%d km/h until %s"), self.PENALTY_SPEED_KMH,
            self:formatRestrictionEnd(state.driverRestrictionEnd))
        if state.driverRestrictionRepeats >= 2 then
            summary = summary .. "\n" .. getText("rff_driver_restriction_final_status", "FINAL WARNING: further offences extend the restriction.")
        end
        return summary
    end
    if not state.driverPenaltiesEnabled then
        return getText("rff_driver_restriction_off", "Penalties off. Offences remain on record; vehicle speeds are unrestricted.")
    end
    local points = math.max(0, state.driverPenaltyPoints or 0)
    return string.format(getText("rff_driver_restriction_ready", "No speed restriction. %d / 12 points towards the next restriction."), points)
end

function RFF_VehicleComplianceService:setLicenceMode(farmId, mode)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return false, "farm" end
    mode = string.upper(tostring(mode or ""))
    if mode ~= self.LICENCE_MODE_FULL and mode ~= self.LICENCE_MODE_REQUIRED then return false, "mode" end
    if state.driverLicenceMode == mode then return true, "unchanged" end
    if self:isActiveAssessmentStatus(state.driverAssessmentStatus) then return false, "active" end
    state.driverLicenceMode = mode
    return true, "updated"
end

function RFF_VehicleComplianceService:hasEntitlement(record, category)
    if record == nil then return category == self.CATEGORY_B end
    if category == self.CATEGORY_B then return true end
    if record.specialistRevoked == true then return false end
    if category == self.CATEGORY_F then return record.categoryF == true end
    if category == self.CATEGORY_H then return record.categoryH == true end
    if category == self.CATEGORY_C then return record.categoryC == true end
    return false
end

function RFF_VehicleComplianceService:setQualificationForTest(farmId, action)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return false, "farm" end
    action = string.upper(tostring(action or ""))
    if action == "RESET" then
        self:removeAssessmentVehicle(farmId, state)
        self._assessmentRuntime[farmId] = nil
        if self.repository.clearDriverOffencesByFarm ~= nil then self.repository:clearDriverOffencesByFarm(farmId) end
        state.driverCategoryF = false
        state.driverCategoryH = false
        state.driverCategoryC = false
        state.driverAdr = false
        state.driverPenaltyPoints = 0
        state.driverSpecialistRevoked = false
        state.driverRestrictionEnd = 0
        state.driverRestrictionRepeats = 0
        state.driverRestrictionServedPoints = 0
        state.driverAssessmentCategory = ""
        state.driverAssessmentStatus = self.ASSESSMENT_NONE
        state.driverAssessmentVehicleUniqueId = ""
        state.driverAssessmentLastResultCategory = ""
        state.driverAssessmentLastResult = ""
    elseif action == "ALL" then
        state.driverCategoryF = true
        state.driverCategoryH = true
        state.driverCategoryC = true
        state.driverAdr = true
        state.driverSpecialistRevoked = false
    elseif action == "REVOKE" then
        state.driverPenaltyPoints = math.max(12, state.driverPenaltyPoints or 0)
        state.driverPenaltiesEnabled = true
        state.driverRestrictionEnd = self:getPenaltyClock() + 1
        state.driverRestrictionRepeats = 0
    elseif action == "F" then state.driverCategoryF = true
    elseif action == "H" then state.driverCategoryH = true
    elseif action == "C" then state.driverCategoryC = true
    elseif action == "ADR" then state.driverAdr = true
    elseif action ~= "B" then return false, "category" end
    return true, "updated", self:getQualificationRecord(farmId)
end

function RFF_VehicleComplianceService:getStoreCategory(vehicle)
    local configFileName = vehicle ~= nil and vehicle.configFileName or nil
    if configFileName == nil or g_storeManager == nil or type(g_storeManager.getItemByXMLFilename) ~= "function" then return "" end
    local ok, item = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, configFileName)
    if not ok or item == nil then return "" end
    return string.lower(tostring(item.categoryName or ""))
end

function RFF_VehicleComplianceService:hasTracks(vehicle)
    local chain = getVehicleChain(vehicle)
    for _, part in ipairs(chain) do
        if part ~= nil then
            if part.spec_tracks ~= nil then return true end

            -- GIANTS crawler vehicles normally use the standard Wheels specialization.
            -- Their selected wheel configuration exposes the loaded crawler belts here,
            -- rather than through the separate Tracks specialization.
            local crawlerSpec = part.spec_crawlers
            if crawlerSpec ~= nil and type(crawlerSpec.crawlers) == "table" and next(crawlerSpec.crawlers) ~= nil then
                return true
            end

            -- Some mod vehicles provide crawler physics without a loaded crawler visual.
            -- Check the active wheels as a fallback so this follows the purchased wheel
            -- configuration and does not classify every optional configuration as tracked.
            local wheels = part.spec_wheels ~= nil and part.spec_wheels.wheels or nil
            if type(wheels) == "table" and WheelsUtil ~= nil and type(WheelsUtil.getTireTypeName) == "function" then
                for _, wheel in pairs(wheels) do
                    local tireType = wheel ~= nil and wheel.physics ~= nil and wheel.physics.tireType or nil
                    if tireType ~= nil then
                        local ok, tireTypeName = pcall(WheelsUtil.getTireTypeName, tireType)
                        if ok and string.upper(tostring(tireTypeName or "")) == "CRAWLER" then return true end
                    end
                end
            end
        end
    end
    return false
end

function RFF_VehicleComplianceService:getRequiredCategory(vehicle)
    local categoryName = self:getStoreCategory(vehicle)
    if self:hasTracks(vehicle) then return self.CATEGORY_H, "TRACKED", categoryName end
    if categoryName == "cars" then return self.CATEGORY_B, "LIGHT_VEHICLE", categoryName end
    if categoryName == "tractorss" or categoryName == "tractorsm" then return self.CATEGORY_F, "WHEELED_TRACTOR", categoryName end
    if categoryName == "tractorsl" then return self.CATEGORY_C, "LARGE_TRACTOR", categoryName end
    if CATEGORIES_C[categoryName] == true then
        if categoryName == "trucks" then return self.CATEGORY_C, "ROAD_TRUCK", categoryName end
        if string.find(categoryName, "harvester", 1, true) ~= nil then return self.CATEGORY_C, "SELF_PROPELLED_HARVESTER", categoryName end
        return self.CATEGORY_C, "LARGE_SELF_PROPELLED", categoryName
    end
    return self.CATEGORY_C, "UNCLASSIFIED_DRIVEABLE", categoryName
end

function RFF_VehicleComplianceService:getRoadSpeedLimit(category, classificationBasis)
    -- Compatibility fallback only when both map and vehicle speed are unknown.
    if category == self.CATEGORY_B or classificationBasis == "ROAD_TRUCK" then return 80 end
    if category == self.CATEGORY_H then return 30 end
    return 40
end

function RFF_VehicleComplianceService:getSpeedRules(farmId, vehicle, context, width, mass, location, roadInfo)
    context = context or {}
    if width == nil then width, mass = self:getDimensions(vehicle) end
    if tonumber(context.grossWeight) ~= nil then mass = math.max(0, tonumber(context.grossWeight)) end
    if location == nil then location, roadInfo = self.fleetManagement:classifyVehicleUse(farmId, vehicle, context) end
    if roadInfo == nil and location == "ROAD" then roadInfo = RFF_RoadSpeedRules.getRoadInfo(self.fleetManagement, vehicle, context) end
    local category, basis = self:getRequiredCategory(vehicle)
    local result = RFF_RoadSpeedRules.calculate(roadInfo ~= nil and roadInfo.limitKmh or nil,
        RFF_RoadSpeedRules.getVehicleMaximum(vehicle), width, mass, self:getSpeedPenalty(farmId),
        self:getRoadSpeedLimit(category, basis))
    result.locationType, result.splineId = location, roadInfo ~= nil and roadInfo.splineId or nil
    return result
end

function RFF_VehicleComplianceService:getVehicleSpeed(vehicle, context)
    if context ~= nil and tonumber(context.speedKmh) ~= nil then return math.max(0, tonumber(context.speedKmh)) end
    local ok, speed = call(vehicle, "getLastSpeed")
    return ok and math.max(0, safeNumber(speed, 0)) or 0
end

function RFF_VehicleComplianceService:getDimensions(vehicle)
    local chain, root = getVehicleChain(vehicle)
    local width = 0
    local trailerMass = 0
    local hasTrailer = false
    for _, part in ipairs(chain) do
        if part ~= nil then
            width = math.max(width, safeNumber(part.size ~= nil and part.size.width or 0))
            if part ~= root then
                hasTrailer = true
                local ok, mass = call(part, "getTotalMass", true)
                if ok then trailerMass = trailerMass + math.max(0, safeNumber(mass)) end
            end
        end
    end
    local grossMass = self.fleetManagement ~= nil and self.fleetManagement:getVehicleGrossWeight(root) or 0
    return width, grossMass, trailerMass, hasTrailer
end

function RFF_VehicleComplianceService:getHazardousLoad(vehicle)
    local chain, root = getVehicleChain(vehicle)
    local foundName = nil
    local foundLevel = 0
    for _, part in ipairs(chain) do
        -- Engine fuel is a FillUnit too. Restrict this first ADR pass to attached
        -- cargo equipment so a tractor's own diesel tank is never treated as a load.
        if part ~= nil and part ~= root and part.spec_fillUnit ~= nil then
            for index, fillUnit in ipairs(part.spec_fillUnit.fillUnits or {}) do
                local okLevel, level = call(part, "getFillUnitFillLevel", index)
                level = okLevel and safeNumber(level) or safeNumber(fillUnit.fillLevel)
                if level > 0.01 then
                    local okType, fillTypeIndex = call(part, "getFillUnitFillType", index)
                    fillTypeIndex = okType and fillTypeIndex or fillUnit.fillType
                    local fillType = nil
                    if g_fillTypeManager ~= nil and type(g_fillTypeManager.getFillTypeByIndex) == "function" and fillTypeIndex ~= nil then
                        local okFill, value = pcall(g_fillTypeManager.getFillTypeByIndex, g_fillTypeManager, fillTypeIndex)
                        if okFill then fillType = value end
                    end
                    local name = string.upper(tostring(fillType ~= nil and fillType.name or ""))
                    if HAZARDOUS_LOADS[name] == true then
                        foundName = name
                        foundLevel = foundLevel + level
                    end
                end
            end
        end
    end
    return foundName ~= nil, foundName or "", foundLevel
end

function RFF_VehicleComplianceService:getAdsRoadworthiness(vehicle)
    local technical = RFF_ADSIntegration ~= nil and RFF_ADSIntegration:getTechnicalAssessment(vehicle) or {adsApplied=false}
    if technical.adsApplied ~= true then return nil, technical end
    local roadworthy = safeNumber(technical.breakdownCount) <= 0
        and safeNumber(technical.conditionLevel, 1) >= self.ADS_MINIMUM_CONDITION
    return roadworthy, technical
end

function RFF_VehicleComplianceService:getAssessment(farmId, vehicleUniqueId, context)
    if self.fleetManagement == nil then return nil, "service" end
    local vehicle = nil
    if type(vehicleUniqueId) == "table" then vehicle = getRootVehicle(vehicleUniqueId)
    else vehicle = self.fleetManagement:findVehicle(farmId, vehicleUniqueId) end
    if vehicle == nil then return nil, "vehicle" end
    local uniqueId = tostring(vehicle.uniqueId or vehicleUniqueId or "")
    local record = self:getQualificationRecord(farmId)
    local category, basis, storeCategory = self:getRequiredCategory(vehicle)
    local width, grossMass, trailerMass, hasTrailer = self:getDimensions(vehicle)
    context = context or {}
    if tonumber(context.grossWeight) ~= nil then grossMass = math.max(0, tonumber(context.grossWeight)) end
    local locationType, roadInfo = self.fleetManagement:classifyVehicleUse(farmId, vehicle, context)
    local speed = self:getVehicleSpeed(vehicle, context)
    local speedRules = self:getSpeedRules(farmId, vehicle, context, width, grossMass, locationType, roadInfo)
    local speedLimit = speedRules.limitKmh
    local hazardousLoad, hazardousLoadName, hazardousLoadLevel = self:getHazardousLoad(vehicle)
    local roadworthy, technical = self:getAdsRoadworthiness(vehicle)
    local ownership, agreement = self.fleetManagement:getOwnership(vehicle)
    local insuranceStatus, insured, policy = self.fleetManagement:getInsurance(vehicle, farmId, ownership)
    local entitlementHeld = self:hasEntitlement(record, category)
    local adrHeld = record ~= nil and record.adr == true and record.specialistRevoked ~= true
    local widthAuthorisationRequired = width > self.ROAD_WIDTH_AUTHORISATION_METRES + 0.001
    local massAuthorisationRequired = grossMass > self.ROAD_MASS_AUTHORISATION_TONNES + 0.001
    local movementAuthorisation, movementAuthorisationRemainingHours = self:getMovementAuthorisation(farmId, uniqueId, width)
    local movementAuthorisationActive = movementAuthorisation ~= nil
    local movementAuthorisationRequired = (widthAuthorisationRequired and not movementAuthorisationActive)
        or massAuthorisationRequired
    local violations = {}
    if locationType == "ROAD" then
        if not entitlementHeld then violations[#violations + 1] = "ENTITLEMENT" end
        if hazardousLoad and not adrHeld then violations[#violations + 1] = "ADR" end
        if speed > speedLimit + 1 then violations[#violations + 1] = "SPEED" end
        if roadworthy == false then violations[#violations + 1] = "ROADWORTHINESS" end
    end
    local overallStatus = "PRIVATE_USE"
    if locationType == "ROAD" then
        if #violations > 0 then overallStatus = "NON_COMPLIANT"
        elseif movementAuthorisationRequired then overallStatus = "AUTHORISATION_REQUIRED"
        elseif movementAuthorisationActive and widthAuthorisationRequired then overallStatus = "AUTHORISED"
        else overallStatus = "COMPLIANT" end
    end
    return {
        vehicle = vehicle,
        vehicleUniqueId = uniqueId,
        vehicleName = getVehicleName(vehicle),
        storeCategory = storeCategory,
        requiredCategory = category,
        classificationBasis = basis,
        qualificationRecord = record,
        entitlementHeld = entitlementHeld,
        adrHeld = adrHeld,
        locationType = locationType,
        roadRulesApply = locationType == "ROAD",
        speedKmh = speed,
        speedLimitKmh = speedLimit,
        speedRules = speedRules,
        widthMetres = width,
        grossMassTonnes = grossMass,
        trailerMassTonnes = trailerMass,
        hasTrailer = hasTrailer,
        hazardousLoad = hazardousLoad,
        hazardousLoadName = hazardousLoadName,
        hazardousLoadLevel = hazardousLoadLevel,
        widthAuthorisationRequired = widthAuthorisationRequired,
        massAuthorisationRequired = massAuthorisationRequired,
        movementAuthorisationRequired = movementAuthorisationRequired,
        movementAuthorisationActive = movementAuthorisationActive,
        movementAuthorisation = movementAuthorisation,
        movementAuthorisationRemainingHours = movementAuthorisationRemainingHours,
        adsRoadworthy = roadworthy,
        adsTechnical = technical,
        ownership = ownership,
        assetAgreement = agreement,
        insuranceStatus = insuranceStatus,
        insured = insured,
        insurancePolicy = policy,
        violations = violations,
        overallStatus = overallStatus
    }, "assessed"
end

function RFF_VehicleComplianceService:getControlledVehicleAssessment(farmId)
    local vehicle = g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function" and g_localPlayer:getCurrentVehicle() or nil
    if vehicle == nil then return nil, "controlled_vehicle" end
    return self:getAssessment(farmId, vehicle)
end

function RFF_VehicleComplianceService:getCurrentDay()
    local environment = g_currentMission ~= nil and g_currentMission.environment or nil
    if environment == nil then return 0 end
    return math.max(0, math.floor(safeNumber(environment.currentMonotonicDay or environment.currentDay)))
end

function RFF_VehicleComplianceService:getMonotonicHour()
    local environment = g_currentMission ~= nil and g_currentMission.environment or nil
    if environment == nil then return 0 end
    if type(environment.getMonotonicHour) == "function" then
        local ok, hour = pcall(environment.getMonotonicHour, environment)
        if ok then return math.max(0, safeNumber(hour)) end
    end
    local day = math.max(0, safeNumber(environment.currentMonotonicDay or environment.currentDay))
    return day * 24 + math.max(0, safeNumber(environment.dayTime)) / 3600000
end

function RFF_VehicleComplianceService:getMovementAuthorisation(farmId, vehicleUniqueId, currentWidth)
    local state = self:ensureQualificationRecord(farmId)
    local uniqueId = tostring(vehicleUniqueId or "")
    if state == nil or uniqueId == "" then return nil, 0 end
    local authorisation = state.movementAuthorisations[uniqueId]
    if type(authorisation) ~= "table" then return nil, 0 end
    local remainingHours = safeNumber(authorisation.expiresHour) - self:getMonotonicHour()
    local authorisedWidth = safeNumber(authorisation.authorisedWidth)
    if remainingHours <= 0 or authorisedWidth + 0.001 < safeNumber(currentWidth) then return nil, 0 end
    return authorisation, remainingHours
end

function RFF_VehicleComplianceService:notifyMovementAuthorisation(farmId, titleKey, titleFallback, messageKey, messageFallback, ...)
    local title = getText(titleKey, titleFallback)
    local template = getText(messageKey, messageFallback)
    local ok, message = pcall(string.format, template, ...)
    if not ok then message = template end
    local sender = getText("rff_licence_sender", "Rural Driver Standards")
    if RFF_NotificationService ~= nil and type(RFF_NotificationService.send) == "function" then
        RFF_NotificationService:send(farmId, sender, title, message, "compliance",
            getText("rff_movement_authorisation_hud_update", "Movement authorisation update received"), false)
    end
end

function RFF_VehicleComplianceService:requestOversizeMovement(farmId, vehicleUniqueId)
    if self.fleetManagement == nil then return false, "service" end
    local suppliedId = type(vehicleUniqueId) == "table" and tostring(vehicleUniqueId.uniqueId or "") or tostring(vehicleUniqueId or "")
    local vehicle = type(vehicleUniqueId) == "table" and getRootVehicle(vehicleUniqueId)
        or self.fleetManagement:findVehicle(farmId, suppliedId)
    if vehicle == nil then return false, "vehicle" end
    local uniqueId = tostring(vehicle.uniqueId or suppliedId)
    if uniqueId == "" then return false, "vehicle" end
    local width = self:getDimensions(vehicle)
    if width <= self.ROAD_WIDTH_AUTHORISATION_METRES + 0.001 then return false, "width" end
    local existing = self:getMovementAuthorisation(farmId, uniqueId, width)
    if existing ~= nil then return false, "active", existing end
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return false, "farm" end
    local now = self:getMonotonicHour()
    local authorisation = {
        vehicleUniqueId=uniqueId,
        vehicleName=getVehicleName(vehicle),
        authorisedWidth=width,
        issuedHour=now,
        expiresHour=now + self.MOVEMENT_AUTHORISATION_HOURS
    }
    state.movementAuthorisations[uniqueId] = authorisation
    self:notifyMovementAuthorisation(farmId,
        "rff_movement_authorisation_title_granted", "Oversize Movement Authorised",
        "rff_movement_authorisation_message_granted",
        "%s is authorised for road movement at up to %.2f m wide for the next %d in-game hours.",
        authorisation.vehicleName, authorisation.authorisedWidth, self.MOVEMENT_AUTHORISATION_HOURS)
    print(string.format("[RealisticFarmFinance] Oversize movement authorised farm=%d vehicle=%s width=%.2f issuedHour=%.3f expiresHour=%.3f",
        farmId, uniqueId, width, authorisation.issuedHour, authorisation.expiresHour))
    return true, "granted", authorisation
end

function RFF_VehicleComplianceService:cleanupExpiredMovementAuthorisations(farmId, state)
    state = state or self:ensureQualificationRecord(farmId)
    if state == nil or type(state.movementAuthorisations) ~= "table" then return end
    local now = self:getMonotonicHour()
    for uniqueId, authorisation in pairs(state.movementAuthorisations) do
        if type(authorisation) ~= "table" or safeNumber(authorisation.expiresHour) <= now then
            local vehicleName = type(authorisation) == "table" and tostring(authorisation.vehicleName or "Vehicle") or "Vehicle"
            state.movementAuthorisations[uniqueId] = nil
            self:notifyMovementAuthorisation(farmId,
                "rff_movement_authorisation_title_expired", "Oversize Movement Authorisation Expired",
                "rff_movement_authorisation_message_expired",
                "The four-hour oversize movement authorisation for %s has expired. A new authorisation is required before further public-road movement above 3.00 m.",
                vehicleName)
            print(string.format("[RealisticFarmFinance] Oversize movement authorisation expired farm=%d vehicle=%s hour=%.3f",
                farmId, tostring(uniqueId), now))
        end
    end
end

function RFF_VehicleComplianceService:getLicenceConfig(category)
    return self.LICENCE_CONFIG[string.upper(tostring(category or ""))]
end

function RFF_VehicleComplianceService:isActiveAssessmentStatus(status)
    return status == self.ASSESSMENT_BOOKED or status == self.ASSESSMENT_SPAWNING
        or status == self.ASSESSMENT_PRACTICAL or status == self.ASSESSMENT_RETURNING
        or status == self.ASSESSMENT_RETURNING_FAILED
        or status == self.ASSESSMENT_THEORY
end

function RFF_VehicleComplianceService:clearAssessmentProgress(state)
    state.driverAssessmentDeadlineDay = 0
    state.driverAssessmentReturnDeadlineHour = 0
    state.driverAssessmentVehicleUniqueId = ""
    state.driverAssessmentVehicleName = ""
    state.driverAssessmentDistance = 0
    state.driverAssessmentRoadDistance = 0
    state.driverAssessmentReverseDistance = 0
    state.driverAssessmentMovingSeconds = 0
    state.driverAssessmentLeftTurnDegrees = 0
    state.driverAssessmentRightTurnDegrees = 0
    state.driverAssessmentSpeedFaultSeconds = 0
    state.driverAssessmentCollisionCount = 0
    state.driverAssessmentTheoryIndex = 0
    state.driverAssessmentTheoryScore = 0
    state.driverAssessmentFailureReason = ""
end

function RFF_VehicleComplianceService:getLicenceProcess(farmId, category)
    category = string.upper(tostring(category or "F"))
    local config = self:getLicenceConfig(category)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil or config == nil then return nil end
    local record = self:getQualificationRecord(farmId)
    local held = category == "ADR" and record.adr == true and record.specialistRevoked ~= true
        or category ~= "ADR" and self:hasEntitlement(record, category)
    local persistedStatus = tostring(state.driverAssessmentStatus or self.ASSESSMENT_NONE)
    local assessmentCategory = tostring(state.driverAssessmentCategory or "")
    local failureReason = tostring(state.driverAssessmentFailureReason or "")
    local theoryRetake = config.theoryOnly ~= true and assessmentCategory == category
        and ((persistedStatus == self.ASSESSMENT_FAILED and failureReason == "THEORY")
            or ((persistedStatus == self.ASSESSMENT_BOOKED or persistedStatus == self.ASSESSMENT_THEORY)
                and failureReason == "THEORY_RETAKE"))
    local fullLicence = state.driverLicenceMode == self.LICENCE_MODE_FULL
    local status = fullLicence and "FULL" or held and "HELD" or self.ASSESSMENT_NONE
    if fullLicence then
        status = "FULL"
    elseif assessmentCategory == category and persistedStatus ~= self.ASSESSMENT_NONE then
        status = persistedStatus
        if persistedStatus == self.ASSESSMENT_PASSED and held then status = "HELD" end
    elseif self:isActiveAssessmentStatus(persistedStatus) then
        status = "OTHER_ACTIVE"
    elseif state.driverAssessmentLastResultCategory == category and state.driverAssessmentLastResult == self.ASSESSMENT_FAILED then
        status = self.ASSESSMENT_FAILED
    end
    local questions = self.THEORY_QUESTIONS[category] or {}
    return {
        category=category,
        status=status,
        persistedStatus=persistedStatus,
        activeCategory=assessmentCategory,
        licenceMode=state.driverLicenceMode,
        canChangeLicenceMode=not self:isActiveAssessmentStatus(persistedStatus),
        held=held,
        fee=theoryRetake and (config.theoryRetakeFee or config.fee or 0) or (config.fee or 0),
        theoryOnly=config.theoryOnly == true,
        theoryRetake=theoryRetake,
        availableDay=state.driverAssessmentAvailableDay or 0,
        currentDay=self:getCurrentDay(),
        ready=self:getCurrentDay() >= (state.driverAssessmentAvailableDay or 0),
        vehicleName=state.driverAssessmentVehicleName or "",
        distance=state.driverAssessmentDistance or 0,
        roadDistance=state.driverAssessmentRoadDistance or 0,
        reverseDistance=state.driverAssessmentReverseDistance or 0,
        movingSeconds=state.driverAssessmentMovingSeconds or 0,
        leftTurnDegrees=state.driverAssessmentLeftTurnDegrees or 0,
        rightTurnDegrees=state.driverAssessmentRightTurnDegrees or 0,
        speedFaultSeconds=state.driverAssessmentSpeedFaultSeconds or 0,
        collisionCount=state.driverAssessmentCollisionCount or 0,
        returnMinutes=math.max(0, math.ceil(((state.driverAssessmentReturnDeadlineHour or 0) - self:getMonotonicHour()) * 60)),
        theoryIndex=state.driverAssessmentTheoryIndex or 0,
        theoryScore=state.driverAssessmentTheoryScore or 0,
        theoryTotal=#questions,
        failureReason=failureReason,
        requirements=config,
        trafficCourtesyConnected=self._trafficCourtesyRegistered == true
    }
end

function RFF_VehicleComplianceService:getRoadComplianceSettings(farmId)
    if self._trafficCourtesyRegistered ~= true then self:installTrafficCourtesyHook() end
    local record = self:getQualificationRecord(farmId)
    local state = self:ensureQualificationRecord(farmId)
    return {
        licenceMode=record ~= nil and record.licenceMode or self.LICENCE_MODE_FULL,
        canChangeLicenceMode=state ~= nil and not self:isActiveAssessmentStatus(state.driverAssessmentStatus),
        trafficCourtesyConnected=self._trafficCourtesyRegistered == true,
        randomStopsActive=state ~= nil and state.roadsideChecksEnabled == true,
        automaticPenaltyPointsActive=self._trafficCourtesyRegistered == true
            or (state ~= nil and (state.speedingEnforcementEnabled == true or state.roadsideChecksEnabled == true)),
        drivingPenaltiesEnabled=state ~= nil and state.driverPenaltiesEnabled == true,
        penaltyPoints=record ~= nil and record.penaltyPoints or 0,
        offenceCount=self.repository ~= nil and self.repository.getDriverOffencesByFarm ~= nil
            and #self.repository:getDriverOffencesByFarm(farmId) or 0
    }
end

function RFF_VehicleComplianceService:getDriverOffences(farmId)
    if self.repository == nil or self.repository.getDriverOffencesByFarm == nil then return {} end
    local state = self:ensureQualificationRecord(farmId)
    if state ~= nil then self:expireSpeedPenalty(farmId, state) end
    return self.repository:getDriverOffencesByFarm(farmId)
end

function RFF_VehicleComplianceService:getTrafficCourtesyOffencePoints(severityClass)
    severityClass = string.upper(tostring(severityClass or "MINOR"))
    return self.OFFENCE_POINTS_BY_SEVERITY[severityClass] or self.OFFENCE_POINTS_BY_SEVERITY.MINOR, severityClass
end

function RFF_VehicleComplianceService:notifyDriverOffence(farmId, offence, penaltyAction)
    local title = getText("rff_driver_offence_title", "Driving Offence Recorded")
    local severity = getText("rff_driver_offence_severity_" .. string.lower(offence.severityClass or "MINOR"),
        tostring(offence.severityClass or "MINOR"):lower())
    local template = getText("rff_driver_offence_message",
        "%s involving %s and %s has been recorded as a %s reportable collision. %d points have been added; the principal operator now has %d of 12 points.")
    local message = string.format(template, offence.externalIncidentId or "Traffic incident", offence.vehicleName or "Vehicle",
        offence.targetName or "another road user", severity, offence.points or 0, offence.pointsTotalAfter or 0)
    if penaltyAction ~= nil then
        message = message .. " " .. getText("rff_driver_restriction_message_" .. string.lower(penaltyAction), "")
    end
    local cap, state = self:getSpeedPenalty(farmId)
    if cap ~= nil then
        message = message .. " " .. string.format(getText("rff_driver_restriction_active", "%d km/h until %s"),
            cap, self:formatRestrictionEnd(state.driverRestrictionEnd))
    end
    local sender = getText("rff_licence_sender", "Rural Driver Standards")
    if RFF_NotificationService ~= nil and type(RFF_NotificationService.send) == "function" then
        RFF_NotificationService:send(farmId, sender, title, message, "licensing",
            getText("rff_driver_offence_hud_update", "Driving record update received"), cap ~= nil)
    end
end

function RFF_VehicleComplianceService:recordTrafficCourtesyOffence(entry)
    if type(entry) ~= "table" or self.repository == nil then return false, "entry" end
    if g_currentMission ~= nil and type(g_currentMission.getIsServer) == "function" and not g_currentMission:getIsServer() then
        return false, "server"
    end
    local farmId = math.floor(safeNumber(entry.farmId))
    local externalIncidentId = tostring(entry.incidentId or "")
    if farmId <= 0 or externalIncidentId == "" then return false, "identity" end
    local locationType = self.fleetManagement ~= nil and self.fleetManagement:classifyVehicleUse(farmId, nil, {
        x=entry.x, y=entry.y, z=entry.z, locationType=entry.locationType
    }) or "UNKNOWN"
    if entry.rffTestOffence ~= true and locationType ~= "ROAD" then return false, "not_road" end
    if self.repository.getDriverOffenceByExternalId ~= nil
        and self.repository:getDriverOffenceByExternalId(externalIncidentId) ~= nil then
        return false, "duplicate"
    end
    local points, severityClass = self:getTrafficCourtesyOffencePoints(entry.severityClass)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return false, "farm" end
    -- Expire before adding this offence so its points belong to the new cycle.
    self:expireSpeedPenalty(farmId, state)
    local previousPoints = math.max(0, math.floor(safeNumber(state.driverPenaltyPoints)))
    local fullLicence = state.driverLicenceMode == self.LICENCE_MODE_FULL
    state.driverPenaltyPoints = previousPoints + points
    local offence = {
        id=self.repository:getNextDriverOffenceId(),
        farmId=farmId,
        source="TRAFFIC_COURTESY",
        externalIncidentId=externalIncidentId,
        status="ACTIVE",
        offenceCode="REPORTABLE_COLLISION",
        locationType=locationType,
        incidentDay=math.max(0, math.floor(safeNumber(entry.day, self:getCurrentDay()))),
        incidentPeriod=self.repository.getCurrentPeriodIndex ~= nil and self.repository:getCurrentPeriodIndex() or 0,
        pointsIssuedAt=self:getPenaltyClock(),
        pointsExpireAt=self:getPenaltyClock() + self.POINTS_EXPIRY_MONTHS,
        dayTimeMs=math.max(0, math.floor(safeNumber(entry.dayTimeMs))),
        vehicleUniqueId=tostring(entry.vehicleId or ""),
        vehicleName=tostring(entry.vehicleName or entry.partName or "Vehicle"),
        targetName=tostring(entry.targetVehicleName or entry.targetName or "another road user"),
        severityClass=severityClass,
        points=points,
        sourceSpeedKph=math.max(0, safeNumber(entry.sourceSpeedMps) * 3.6),
        closingSpeedKph=math.max(0, safeNumber(entry.closingSpeedMps) * 3.6),
        pointsTotalAfter=state.driverPenaltyPoints
    }
    self.repository:addDriverOffence(offence)
    local penaltyAction = self:applyOffenceSpeedPenalty(farmId, state)
    self:notifyDriverOffence(farmId, offence, penaltyAction)
    print(string.format("[RealisticFarmFinance] Driver offence %s recorded from %s farm=%d severity=%s points=%d total=%d fullLicence=%s penalties=%s restrictionEnd=%.6f repeats=%d",
        string.format("RFF-O-%06d", offence.id or 0), externalIncidentId, farmId, severityClass, points,
        state.driverPenaltyPoints or 0, tostring(fullLicence), tostring(state.driverPenaltiesEnabled), state.driverRestrictionEnd, state.driverRestrictionRepeats))
    return true, "recorded", offence
end

function RFF_VehicleComplianceService:addDriverOffenceForTest(farmId, severityClass)
    severityClass = string.upper(tostring(severityClass or "MODERATE"))
    if self.OFFENCE_POINTS_BY_SEVERITY[severityClass] == nil then return false, "severity" end
    local vehicle = g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function"
        and getRootVehicle(g_localPlayer:getCurrentVehicle()) or nil
    local nextId = self.repository ~= nil and (self.repository.nextDriverOffenceId or 1) or 1
    return self:recordTrafficCourtesyOffence({
        incidentId=string.format("RFF-TEST-%08d", nextId),
        farmId=farmId,
        day=self:getCurrentDay(),
        dayTimeMs=g_currentMission ~= nil and g_currentMission.environment ~= nil
            and math.floor(safeNumber(g_currentMission.environment.dayTime)) or 0,
        vehicleId=vehicle ~= nil and tostring(vehicle.uniqueId or "") or "",
        vehicleName=vehicle ~= nil and getVehicleName(vehicle) or "Test Vehicle",
        targetName="Roadside test record",
        locationType="ROAD",
        rffTestOffence=true,
        severityClass=severityClass,
        sourceSpeedMps=vehicle ~= nil and self:getVehicleSpeed(vehicle) / 3.6 or 0,
        closingSpeedMps=vehicle ~= nil and self:getVehicleSpeed(vehicle) / 3.6 or 0
    })
end

function RFF_VehicleComplianceService:clearDriverOffencesForTest(farmId)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil or self.repository == nil then return false, "farm" end
    if self.repository.clearDriverOffencesByFarm ~= nil then self.repository:clearDriverOffencesByFarm(farmId) end
    state.driverPenaltyPoints = 0
    state.driverSpecialistRevoked = false
    state.driverRestrictionEnd = 0
    state.driverRestrictionRepeats = 0
    state.driverRestrictionServedPoints = 0
    return true, "cleared"
end

function RFF_VehicleComplianceService:getFarmMoney(farmId)
    if g_currentMission == nil or type(g_currentMission.getMoney) ~= "function" then return 0 end
    local ok, amount = pcall(g_currentMission.getMoney, g_currentMission, farmId)
    return ok and safeNumber(amount) or 0
end

function RFF_VehicleComplianceService:notify(farmId, titleKey, titleFallback, messageKey, messageFallback, ...)
    local title = getText(titleKey, titleFallback)
    local template = getText(messageKey, messageFallback)
    local ok, message = pcall(string.format, template, ...)
    if not ok then message = template end
    local sender = getText("rff_licence_sender", "Rural Driver Standards")
    if RFF_NotificationService ~= nil and type(RFF_NotificationService.send) == "function" then
        RFF_NotificationService:send(farmId, sender, title, message, "licensing",
            getText("rff_licence_hud_update", "Driving licence update received"), false)
    end
end

function RFF_VehicleComplianceService:bookAssessment(farmId, category)
    category = string.upper(tostring(category or ""))
    local config = self:getLicenceConfig(category)
    local state = self:ensureQualificationRecord(farmId)
    if config == nil or state == nil then return false, "category" end
    local process = self:getLicenceProcess(farmId, category)
    if process.held then return false, "held" end
    if self:isActiveAssessmentStatus(state.driverAssessmentStatus) then return false, "active", state.driverAssessmentCategory end
    if g_currentMission == nil or type(g_currentMission.addMoney) ~= "function" then return false, "mission" end
    local theoryRetake = process.theoryRetake == true
    local fee = process.fee or config.fee or 0
    if self:getFarmMoney(farmId) + 0.001 < fee then return false, "funds" end

    if self.repository ~= nil and type(self.repository.setNextTransactionDescription) == "function" then
        self.repository:setNextTransactionDescription(farmId, theoryRetake
            and string.format("Category %s theory assessment retake", category)
            or string.format("Category %s driving qualification assessment", category))
    end
    g_currentMission:addMoney(-fee, farmId, otherMoneyType(), true, true)
    self:clearAssessmentProgress(state)
    state.driverAssessmentCategory = category
    state.driverAssessmentStatus = self.ASSESSMENT_BOOKED
    state.driverAssessmentFailureReason = theoryRetake and "THEORY_RETAKE" or ""
    state.driverAssessmentBookedDay = self:getCurrentDay()
    state.driverAssessmentAvailableDay = self:getCurrentDay() + 1
    state.driverAssessmentLastResultCategory = category
    state.driverAssessmentLastResult = self.ASSESSMENT_BOOKED
    if theoryRetake then
        self:notify(farmId, "rff_licence_title_theory_retake_booked", "Theory Retake Booked",
            "rff_licence_message_theory_retake_booked", "Your Category %s theory-only retake has been booked. Your completed practical remains valid and the appointment will be available from the next game day.", category)
    else
        self:notify(farmId, "rff_licence_title_booked", "Assessment Booked",
            "rff_licence_message_booked", "Your Category %s assessment has been booked. The appointment will be available from the next game day.", category)
    end
    print(string.format("[RealisticFarmFinance] Licence assessment booked farm=%d category=%s fee=%.2f theoryRetake=%s availableDay=%d",
        farmId, category, fee, tostring(theoryRetake), state.driverAssessmentAvailableDay or 0))
    return true, theoryRetake and "theory_retake_booked" or "booked", process
end

function RFF_VehicleComplianceService:findAssessmentVehicle(uniqueId)
    uniqueId = tostring(uniqueId or "")
    if uniqueId == "" or g_currentMission == nil or g_currentMission.vehicleSystem == nil then return nil end
    if type(g_currentMission.vehicleSystem.getVehicleByUniqueId) == "function" then
        local vehicle = g_currentMission.vehicleSystem:getVehicleByUniqueId(uniqueId)
        if vehicle ~= nil then return vehicle end
    end
    for _, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles or {}) do
        if tostring(vehicle.uniqueId or "") == uniqueId then return vehicle end
    end
    return nil
end

function RFF_VehicleComplianceService:createDrivingExaminerStyle()
    local npc = nil
    if g_npcManager ~= nil and type(g_npcManager.getRandomNPC) == "function" then
        local ok, selected = pcall(g_npcManager.getRandomNPC, g_npcManager)
        if ok then npc = selected end
    end
    if npc ~= nil and npc.playerStyle ~= nil then return npc.playerStyle, false end
    if PlayerStyle ~= nil and type(PlayerStyle.defaultStyle) == "function" then
        local ok, style = pcall(PlayerStyle.defaultStyle)
        if ok and style ~= nil then return style, true end
    end
    return nil, false
end

function RFF_VehicleComplianceService:attachDrivingExaminer(farmId, vehicle, runtime)
    runtime = runtime or {}
    local spec = vehicle ~= nil and vehicle.spec_enterablePassenger or nil
    if spec == nil or type(spec.passengerSeats) ~= "table" or type(vehicle.setPassengerSeatCharacter) ~= "function" then
        return false, "NO_PASSENGER_SEAT"
    end
    local seatIndex = nil
    for index, seat in ipairs(spec.passengerSeats) do
        if seat ~= nil and seat.isUsed ~= true and seat.vehicleCharacter ~= nil then
            seatIndex = index
            break
        end
    end
    if seatIndex == nil then return false, "NO_AVAILABLE_SEAT" end

    local style, ownsStyle = self:createDrivingExaminerStyle()
    if style == nil then return false, "NO_EXAMINER_STYLE" end
    local seat = spec.passengerSeats[seatIndex]
    runtime.examinerSeatIndex = seatIndex
    runtime.examinerStyle = style
    runtime.examinerOwnsStyle = ownsStyle
    runtime.examinerOriginalAvailable = spec.available == true
    runtime.examinerOriginalAllowInSingleplayer = spec.allowInSingleplayer
    spec.available = true
    if spec.allowInSingleplayer ~= nil then spec.allowInSingleplayer = true end
    seat.rffDrivingExaminer = true
    seat.isUsed = true
    seat.playerStyle = style
    -- A synthetic seat occupant has no multiplayer user record. Zero is safe for
    -- the base-game name lookup and prevents an empty examiner nameplate.
    seat.userId = 0
    local ok = pcall(vehicle.setPassengerSeatCharacter, vehicle, seatIndex, style)
    if not ok then
        seat.rffDrivingExaminer = nil
        seat.isUsed = false
        seat.playerStyle = nil
        seat.userId = nil
        spec.available = runtime.examinerOriginalAvailable
        if spec.allowInSingleplayer ~= nil then spec.allowInSingleplayer = runtime.examinerOriginalAllowInSingleplayer end
        if ownsStyle and type(style.delete) == "function" then pcall(style.delete, style) end
        runtime.examinerSeatIndex = nil
        runtime.examinerStyle = nil
        runtime.examinerOwnsStyle = nil
        return false, "CHARACTER_LOAD"
    end
    runtime.examinerAttached = true
    print(string.format("[RealisticFarmFinance] Driving examiner seated farm=%d vehicle=%s seat=%d",
        farmId, getVehicleName(vehicle), seatIndex))
    return true, "ATTACHED"
end

function RFF_VehicleComplianceService:detachDrivingExaminer(runtime, vehicle)
    if runtime == nil or runtime.examinerSeatIndex == nil then return end
    vehicle = vehicle or runtime.vehicle
    local spec = vehicle ~= nil and vehicle.spec_enterablePassenger or nil
    local seat = spec ~= nil and spec.passengerSeats ~= nil and spec.passengerSeats[runtime.examinerSeatIndex] or nil
    if vehicle ~= nil and type(vehicle.setPassengerSeatCharacter) == "function" then
        pcall(vehicle.setPassengerSeatCharacter, vehicle, runtime.examinerSeatIndex, nil)
    end
    if seat ~= nil and seat.rffDrivingExaminer == true then
        seat.rffDrivingExaminer = nil
        seat.isUsed = false
        seat.playerStyle = nil
        seat.userId = nil
    end
    if spec ~= nil then
        spec.available = runtime.examinerOriginalAvailable == true
        if spec.allowInSingleplayer ~= nil then
            spec.allowInSingleplayer = runtime.examinerOriginalAllowInSingleplayer
        end
    end
    if runtime.examinerOwnsStyle == true and runtime.examinerStyle ~= nil and type(runtime.examinerStyle.delete) == "function" then
        pcall(runtime.examinerStyle.delete, runtime.examinerStyle)
    end
    runtime.examinerAttached = nil
    runtime.examinerSeatIndex = nil
    runtime.examinerStyle = nil
    runtime.examinerOwnsStyle = nil
end

function RFF_VehicleComplianceService:removeAssessmentVehicle(farmId, state)
    local uniqueId = state ~= nil and state.driverAssessmentVehicleUniqueId or ""
    local vehicle = self:findAssessmentVehicle(uniqueId)
    local runtime = self._assessmentRuntime[farmId]
    self:detachDrivingExaminer(runtime, vehicle)
    if vehicle ~= nil and type(vehicle.delete) == "function" then vehicle:delete() end
    if state ~= nil then
        state.driverAssessmentVehicleUniqueId = ""
        state.driverAssessmentVehicleName = ""
    end
end

function RFF_VehicleComplianceService:beginTheory(state)
    state.driverAssessmentStatus = self.ASSESSMENT_THEORY
    state.driverAssessmentTheoryIndex = 1
    state.driverAssessmentTheoryScore = 0
    state.driverAssessmentDeadlineDay = 0
    state.driverAssessmentReturnDeadlineHour = 0
end

function RFF_VehicleComplianceService:vehicleXmlHasPassengerSeat(xmlFilename)
    if XMLFile == nil or type(XMLFile.loadIfExists) ~= "function" or xmlFilename == nil or tostring(xmlFilename) == "" then
        return false
    end
    local loaded, xmlFile = pcall(XMLFile.loadIfExists, "rffAssessmentPassengerCheck", xmlFilename)
    if not loaded or xmlFile == nil then return false end
    local hasSeat = false
    local checked, checkResult = pcall(function()
        if xmlFile:hasProperty("vehicle.enterable.passengerSeats.passengerSeat(0)") then return true end
        for _, key in xmlFile:iterator("vehicle.enterable.enterablePassengerConfigurations.enterablePassengerConfiguration") do
            if xmlFile:hasProperty(key .. ".passengerSeat(0)") then return true end
        end
        return false
    end)
    if checked then hasSeat = checkResult == true end
    if type(xmlFile.delete) == "function" then pcall(xmlFile.delete, xmlFile) end
    return hasSeat
end

function RFF_VehicleComplianceService:getAssessmentStoreItem(category, config)
    if g_storeManager == nil or config == nil then return nil, nil end
    local vehicleFilename = config.vehicleXml
    if Utils ~= nil and type(Utils.getFilename) == "function" then
        local resolvedOk, resolvedFilename = pcall(Utils.getFilename, config.vehicleXml, "")
        if resolvedOk and resolvedFilename ~= nil and tostring(resolvedFilename) ~= "" then
            vehicleFilename = resolvedFilename
        end
    end
    local preferredItem = type(g_storeManager.getItemByXMLFilename) == "function"
        and g_storeManager:getItemByXMLFilename(vehicleFilename) or nil
    if category ~= self.CATEGORY_F or (preferredItem ~= nil and self:vehicleXmlHasPassengerSeat(vehicleFilename)) then
        return preferredItem, vehicleFilename
    end

    -- Some DLC or map packs may supply a small/medium tractor with a genuine
    -- passenger seat even though the base-game Category F test tractor does not.
    -- Prefer one of those when available, but keep the Zetor as a safe fallback.
    local candidates = {}
    local items = type(g_storeManager.getItems) == "function" and g_storeManager:getItems() or {}
    for _, item in ipairs(items or {}) do
        local storeCategory = string.lower(tostring(item.categoryName or ""))
        local itemFilename = item.xmlFilename
        local unlocked = type(g_storeManager.getIsItemUnlocked) ~= "function" or g_storeManager:getIsItemUnlocked(item)
        if unlocked and (storeCategory == "tractorss" or storeCategory == "tractorsm")
            and itemFilename ~= nil and self:vehicleXmlHasPassengerSeat(itemFilename) then
            candidates[#candidates + 1] = item
        end
    end
    table.sort(candidates, function(a, b)
        local priceA, priceB = safeNumber(a.price, math.huge), safeNumber(b.price, math.huge)
        if priceA ~= priceB then return priceA < priceB end
        return string.lower(tostring(a.xmlFilename or "")) < string.lower(tostring(b.xmlFilename or ""))
    end)
    if candidates[1] ~= nil then
        local selected = candidates[1]
        print(string.format("[RealisticFarmFinance] Category F assessment selected passenger-equipped tractor filename=%s",
            tostring(selected.xmlFilename or "")))
        return selected, selected.xmlFilename
    end
    print("[RealisticFarmFinance] No passenger-equipped Category F tractor is available; using the standard Zetor assessment tractor without a visible examiner")
    return preferredItem, vehicleFilename
end

function RFF_VehicleComplianceService:startAssessment(farmId, category)
    category = string.upper(tostring(category or ""))
    local config = self:getLicenceConfig(category)
    local state = self:ensureQualificationRecord(farmId)
    if config == nil or state == nil then return false, "category" end
    if state.driverAssessmentCategory ~= category or state.driverAssessmentStatus ~= self.ASSESSMENT_BOOKED then return false, "not_booked" end
    if self:getCurrentDay() < (state.driverAssessmentAvailableDay or 0) then return false, "waiting" end
    local theoryRetake = state.driverAssessmentFailureReason == "THEORY_RETAKE"
    if config.theoryOnly or theoryRetake then
        self:beginTheory(state)
        self:notify(farmId, theoryRetake and "rff_licence_title_theory_retake" or "rff_licence_title_theory",
            theoryRetake and "Theory Retake Ready" or "Theory Assessment Ready",
            theoryRetake and "rff_licence_message_theory_retake" or "rff_licence_message_theory",
            theoryRetake and "Your Category %s theory retake is ready. Your completed practical remains valid; answer the five questions in Vehicles - Compliance."
                or "Your Category %s theory assessment is ready. Open Vehicles - Compliance to answer five questions.", category)
        return true, "theory"
    end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "server" end
    if VehicleLoadingData == nil or VehiclePropertyState == nil then return false, "loading_api" end
    if g_currentMission.storeSpawnPlaces == nil or g_currentMission.usedStorePlaces == nil then return false, "dealer" end

    -- StoreManager indexes built-in vehicles by the fully resolved game path.
    -- Category F also checks unlocked DLC/mod tractors for a real passenger seat.
    local storeItem, vehicleFilename = self:getAssessmentStoreItem(category, config)
    if storeItem == nil then
        print(string.format("[RealisticFarmFinance] Licence assessment test vehicle is unavailable category=%s filename=%s",
            category, tostring(vehicleFilename)))
        return false, "test_vehicle"
    end

    local loadingData = VehicleLoadingData.new()
    loadingData:setStoreItem(storeItem)
    if loadingData.isValid ~= true then return false, "test_vehicle" end
    loadingData:setPropertyState(VehiclePropertyState.MISSION)
    loadingData:setOwnerFarmId(farmId)
    loadingData:setIsSaved(false)
    if not loadingData:setLoadingPlace(g_currentMission.storeSpawnPlaces, g_currentMission.usedStorePlaces) then return false, "dealer_space" end
    local dealerX = loadingData.position ~= nil and safeNumber(loadingData.position[1]) or 0
    local dealerZ = loadingData.position ~= nil and safeNumber(loadingData.position[3]) or 0
    local resumeProgress = state.driverAssessmentFailureReason == "RESUME"
    if not resumeProgress then
        self:clearAssessmentProgress(state)
    else
        state.driverAssessmentVehicleUniqueId = ""
        state.driverAssessmentVehicleName = ""
        state.driverAssessmentFailureReason = ""
    end
    state.driverAssessmentCategory = category
    state.driverAssessmentStatus = self.ASSESSMENT_SPAWNING
    state.driverAssessmentDeadlineDay = self:getCurrentDay() + 1
    self._assessmentRuntime[farmId] = {loading=true, missingMs=0, dealerX=dealerX, dealerZ=dealerZ}
    loadingData:load(self.onAssessmentVehicleLoaded, self, {
        farmId=farmId,
        category=category,
        dealerX=dealerX,
        dealerZ=dealerZ
    })
    return true, "spawning"
end

function RFF_VehicleComplianceService:onAssessmentVehicleLoaded(vehicles, loadingState, arguments)
    local farmId = arguments ~= nil and arguments.farmId or 0
    local category = arguments ~= nil and tostring(arguments.category or "") or ""
    local dealerX = arguments ~= nil and safeNumber(arguments.dealerX) or 0
    local dealerZ = arguments ~= nil and safeNumber(arguments.dealerZ) or 0
    local state = self:ensureQualificationRecord(farmId)
    local ok = VehicleLoadingState ~= nil and loadingState == VehicleLoadingState.OK and vehicles ~= nil and vehicles[1] ~= nil
    if state == nil or state.driverAssessmentStatus ~= self.ASSESSMENT_SPAWNING or state.driverAssessmentCategory ~= category or not ok then
        for _, vehicle in ipairs(vehicles or {}) do if vehicle ~= nil and type(vehicle.delete) == "function" then vehicle:delete() end end
        if state ~= nil and state.driverAssessmentStatus == self.ASSESSMENT_SPAWNING then self:failAssessment(farmId, "SPAWN_FAILED") end
        return
    end
    local vehicle = getRootVehicle(vehicles[1])
    local dealerNode = vehicle ~= nil and (vehicle.rootNode or (vehicle.components ~= nil and vehicle.components[1] ~= nil and vehicle.components[1].node)) or nil
    if dealerNode ~= nil and dealerNode ~= 0 and getWorldTranslation ~= nil then
        local positionOk, x, _, z = pcall(getWorldTranslation, dealerNode)
        if positionOk then dealerX, dealerZ = x, z end
    end
    vehicle.rffDrivingTestVehicle = true
    vehicle.rffDrivingTestCategory = category
    state.driverAssessmentVehicleUniqueId = tostring(vehicle.uniqueId or "")
    state.driverAssessmentVehicleName = getVehicleName(vehicle)
    state.driverAssessmentStatus = self.ASSESSMENT_PRACTICAL
    state.driverAssessmentDeadlineDay = self:getCurrentDay() + 1
    self._assessmentRuntime[farmId] = {
        vehicle=vehicle,
        missingMs=0,
        dealerX=dealerX,
        dealerZ=dealerZ,
        briefingShown=false
    }
    local examinerAttached, examinerReason = self:attachDrivingExaminer(farmId, vehicle, self._assessmentRuntime[farmId])
    if not examinerAttached then
        print(string.format("[RealisticFarmFinance] Driving examiner visual unavailable farm=%d category=%s reason=%s",
            farmId, category, tostring(examinerReason)))
    end
    self:notify(farmId, "rff_licence_title_vehicle", "Assessment Vehicle Ready",
        "rff_licence_message_vehicle", "Your Category %s assessment vehicle is waiting at the dealership. Complete the recorded road, reversing and manoeuvring requirements by the end of the next game day.", category)
    print(string.format("[RealisticFarmFinance] Licence assessment vehicle ready farm=%d category=%s vehicle=%s id=%s",
        farmId, category, state.driverAssessmentVehicleName, state.driverAssessmentVehicleUniqueId))
end

function RFF_VehicleComplianceService:grantQualification(state, category)
    if category == self.CATEGORY_F then state.driverCategoryF = true
    elseif category == self.CATEGORY_H then state.driverCategoryH = true
    elseif category == self.CATEGORY_C then state.driverCategoryC = true
    elseif category == "ADR" then state.driverAdr = true end
    if state.driverSpecialistRevoked == true then
        state.driverPenaltyPoints = 0
        state.driverSpecialistRevoked = false
    end
end

function RFF_VehicleComplianceService:passAssessment(farmId)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return false end
    local category = state.driverAssessmentCategory
    self:removeAssessmentVehicle(farmId, state)
    self:grantQualification(state, category)
    state.driverAssessmentStatus = self.ASSESSMENT_PASSED
    state.driverAssessmentLastResultCategory = category
    state.driverAssessmentLastResult = self.ASSESSMENT_PASSED
    state.driverAssessmentFailureReason = ""
    self._assessmentRuntime[farmId] = nil
    self:showExaminerFeedback(state, true, "")
    self:notify(farmId, "rff_licence_title_passed", "Qualification Awarded",
        "rff_licence_message_passed", "You passed the Category %s assessment. The entitlement has been added to the principal operator record.", category)
    print(string.format("[RealisticFarmFinance] Licence assessment passed farm=%d category=%s score=%d",
        farmId, category, state.driverAssessmentTheoryScore or 0))
    return true
end

function RFF_VehicleComplianceService:finalizeFailedAssessment(farmId, state, reason, showFeedback)
    if state == nil then return false end
    local category = state.driverAssessmentCategory
    local failureReason = tostring(reason or state.driverAssessmentFailureReason or "UNSUCCESSFUL")
    self:removeAssessmentVehicle(farmId, state)
    state.driverAssessmentStatus = self.ASSESSMENT_FAILED
    state.driverAssessmentFailureReason = failureReason
    state.driverAssessmentLastResultCategory = category
    state.driverAssessmentLastResult = self.ASSESSMENT_FAILED
    state.driverAssessmentDeadlineDay = 0
    state.driverAssessmentReturnDeadlineHour = 0
    self._assessmentRuntime[farmId] = nil
    if showFeedback ~= false then
        self:showExaminerFeedback(state, false, failureReason, false)
    end
    local config = self:getLicenceConfig(category) or {}
    local theoryRetake = failureReason == "THEORY" and config.theoryOnly ~= true
    self:notify(farmId, theoryRetake and "rff_licence_title_theory_failed" or "rff_licence_title_failed",
        theoryRetake and "Theory Assessment Unsuccessful" or "Assessment Unsuccessful",
        theoryRetake and "rff_licence_message_theory_failed" or "rff_licence_message_failed",
        theoryRetake and "The Category %s theory assessment was unsuccessful, but your completed practical remains valid. Book a theory-only retake from Vehicles - Compliance."
            or "The Category %s assessment was unsuccessful. Review the recorded reason in Vehicles - Compliance before booking another attempt.", category)
    print(string.format("[RealisticFarmFinance] Licence assessment failed farm=%d category=%s reason=%s",
        farmId, category, failureReason))
    return true
end

function RFF_VehicleComplianceService:beginFailedPracticalReturn(farmId, state, runtime, reason)
    local now = self:getMonotonicHour()
    local failureReason = tostring(reason or "UNSUCCESSFUL")
    state.driverAssessmentStatus = self.ASSESSMENT_RETURNING_FAILED
    state.driverAssessmentFailureReason = failureReason
    state.driverAssessmentLastResultCategory = state.driverAssessmentCategory
    state.driverAssessmentLastResult = self.ASSESSMENT_FAILED
    state.driverAssessmentDeadlineDay = 0
    state.driverAssessmentReturnDeadlineHour = now + 1
    runtime.returnStartedHour = now
    runtime.returnDistance = nil
    self:showExaminerFeedback(state, false, failureReason, true)
    self:notify(farmId, "rff_licence_title_failed_return", "Assessment Ended — Return Vehicle",
        "rff_licence_message_failed_return", "The Category %s practical assessment was unsuccessful. Return the assessment vehicle to the dealership, park in the delivery area and exit. It will be collected automatically after one in-game hour.", state.driverAssessmentCategory)
    print(string.format("[RealisticFarmFinance] Licence practical failed; vehicle return requested farm=%d category=%s reason=%s deadlineHour=%.3f",
        farmId, tostring(state.driverAssessmentCategory or ""), failureReason, state.driverAssessmentReturnDeadlineHour))
    return true
end

function RFF_VehicleComplianceService:failAssessment(farmId, reason)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil then return false end
    local failureReason = tostring(reason or "UNSUCCESSFUL")
    local runtime = self._assessmentRuntime[farmId]
    local vehicle = self:findAssessmentVehicle(state.driverAssessmentVehicleUniqueId)
    local canReturnVehicle = state.driverAssessmentStatus == self.ASSESSMENT_PRACTICAL
        and runtime ~= nil and vehicle ~= nil
        and (failureReason == "COLLISION" or failureReason == "SPEED" or failureReason == "TIME")
    if canReturnVehicle then
        return self:beginFailedPracticalReturn(farmId, state, runtime, failureReason)
    end
    return self:finalizeFailedAssessment(farmId, state, failureReason, true)
end

function RFF_VehicleComplianceService:getPracticalFeedbackSummary(state)
    return string.format(getText("rff_licence_examiner_drive_summary",
        "Recorded drive: %.1f km total; %.1f km on recognised roads; %.0f m reversing; %s moving; left %.0f deg / right %.0f deg; %d collision(s); %.1f seconds speeding."),
        safeNumber(state.driverAssessmentDistance) / 1000,
        safeNumber(state.driverAssessmentRoadDistance) / 1000,
        safeNumber(state.driverAssessmentReverseDistance),
        formatDuration(state.driverAssessmentMovingSeconds),
        safeNumber(state.driverAssessmentLeftTurnDegrees),
        safeNumber(state.driverAssessmentRightTurnDegrees),
        math.floor(safeNumber(state.driverAssessmentCollisionCount)),
        safeNumber(state.driverAssessmentSpeedFaultSeconds))
end

function RFF_VehicleComplianceService:showExaminerFeedback(state, passed, reason, returnRequired)
    if state == nil or InfoDialog == nil or type(InfoDialog.show) ~= "function" then return end
    local category = tostring(state.driverAssessmentCategory or "")
    local config = self:getLicenceConfig(category) or {}
    local questions = self.THEORY_QUESTIONS[category] or {}
    local total = #questions
    local score = math.floor(safeNumber(state.driverAssessmentTheoryScore))
    local heading = getText("rff_licence_examiner_feedback_title", "Driving examiner feedback")
    local statement
    if passed then
        if config.theoryOnly == true then
            statement = string.format(getText("rff_licence_examiner_pass_theory",
                "The examiner says: That's a pass for Category %s. You scored %d out of %d in the theory assessment. Your qualification will now be issued."),
                category, score, total)
        else
            statement = string.format(getText("rff_licence_examiner_pass",
                "The examiner says: That's a pass for Category %s. You met the practical standard and scored %d out of %d in the theory assessment. Your qualification will now be issued."),
                category, score, total)
        end
    else
        local reasonKeys = {
            COLLISION="rff_licence_examiner_fail_collision",
            SPEED="rff_licence_examiner_fail_speed",
            TIME="rff_licence_examiner_fail_time",
            THEORY="rff_licence_examiner_fail_theory",
            VEHICLE_MISSING="rff_licence_examiner_fail_vehicle",
            INTERRUPTED="rff_licence_examiner_fail_interrupted",
            SPAWN_FAILED="rff_licence_examiner_fail_spawn",
            CATEGORY="rff_licence_examiner_fail_general"
        }
        local key = reasonKeys[tostring(reason or "")] or "rff_licence_examiner_fail_general"
        local fallbacks = {
            COLLISION="The examiner says: I'm sorry, but I have to end your Category %s test. A collision was recorded during the practical assessment. Safe observation and control must be maintained throughout.",
            SPEED="The examiner says: I'm sorry, but the Category %s test is unsuccessful. The road-speed tolerance was exceeded for too long; speed control must remain consistent throughout the drive.",
            TIME="The examiner says: I'm sorry, but the Category %s assessment period ended before all of the required work was completed.",
            THEORY="The examiner says: I'm sorry, but the Category %s assessment is unsuccessful. You scored %d out of %d; at least four correct answers are required.",
            VEHICLE_MISSING="The examiner says: I'm sorry, but the Category %s test could not continue because the assessment vehicle became unavailable.",
            INTERRUPTED="The examiner says: I'm sorry, but the Category %s assessment was interrupted before the test vehicle could be issued.",
            SPAWN_FAILED="The examiner says: We could not prepare the Category %s assessment vehicle, so this appointment could not proceed.",
            CATEGORY="The examiner says: I'm sorry, but the Category %s assessment could not be completed."
        }
        if reason == "THEORY" then
            statement = string.format(getText(key, fallbacks.THEORY), category, score, total)
        else
            statement = string.format(getText(key, fallbacks[reason] or fallbacks.CATEGORY), category)
        end
        if returnRequired == true then
            statement = statement .. "\n\n" .. getText("rff_licence_examiner_return_then_rebook",
                "Please return the assessment vehicle to the dealership, park in the delivery area and exit. You have one in-game hour before it is collected automatically. You may book another attempt after the handover is complete.")
        elseif reason == "THEORY" and config.theoryOnly ~= true then
            statement = statement .. "\n\n" .. getText("rff_licence_examiner_theory_retake",
                "Your practical result remains valid. You may book a theory-only retake from Vehicles - Compliance; the driving test will not be repeated.")
        else
            statement = statement .. "\n\n" .. getText("rff_licence_examiner_rebook",
                "You may review the result and book another attempt from Vehicles - Compliance.")
        end
    end
    local parts = {heading, "", statement}
    local practicalStarted = reason ~= "THEORY" and reason ~= "SPAWN_FAILED"
        and reason ~= "INTERRUPTED" and reason ~= "CATEGORY"
    if config.theoryOnly ~= true and practicalStarted then
        parts[#parts + 1] = ""
        parts[#parts + 1] = self:getPracticalFeedbackSummary(state)
    end
    InfoDialog.show(table.concat(parts, "\n"))
end

function RFF_VehicleComplianceService:getTheoryQuestion(farmId, category)
    local state = self:ensureQualificationRecord(farmId)
    category = string.upper(tostring(category or ""))
    if state == nil or state.driverAssessmentCategory ~= category or state.driverAssessmentStatus ~= self.ASSESSMENT_THEORY then return nil, "not_theory" end
    local questions = self.THEORY_QUESTIONS[category] or {}
    local index = math.max(1, state.driverAssessmentTheoryIndex or 1)
    return questions[index], "question", index, #questions
end

function RFF_VehicleComplianceService:answerTheory(farmId, category, answer)
    local state = self:ensureQualificationRecord(farmId)
    local question, reason, index, total = self:getTheoryQuestion(farmId, category)
    if state == nil or question == nil then return false, reason end
    local correct = (answer == true) == (question.answer == true)
    if correct then state.driverAssessmentTheoryScore = (state.driverAssessmentTheoryScore or 0) + 1 end
    if index >= total then
        local passed = (state.driverAssessmentTheoryScore or 0) >= math.ceil(total * 0.8)
        if passed then self:passAssessment(farmId) else self:failAssessment(farmId, "THEORY") end
        return true, passed and "passed" or "failed", {complete=true, passed=passed, score=state.driverAssessmentTheoryScore or 0, total=total, correct=correct}
    end
    state.driverAssessmentTheoryIndex = index + 1
    return true, "next", {complete=false, score=state.driverAssessmentTheoryScore or 0, total=total, correct=correct, nextIndex=index + 1}
end

function RFF_VehicleComplianceService:getPracticalVehicleNode(vehicle)
    return vehicle ~= nil and (vehicle.rootNode or (vehicle.components ~= nil and vehicle.components[1] ~= nil and vehicle.components[1].node)) or nil
end

function RFF_VehicleComplianceService:isPracticalComplete(state, config)
    return (state.driverAssessmentDistance or 0) >= (config.distance or 0)
        and (state.driverAssessmentRoadDistance or 0) >= (config.roadDistance or 0)
        and (state.driverAssessmentReverseDistance or 0) >= (config.reverseDistance or 0)
        and (state.driverAssessmentMovingSeconds or 0) >= (config.movingSeconds or 0)
        and (state.driverAssessmentLeftTurnDegrees or 0) >= (config.turnDegrees or 0)
        and (state.driverAssessmentRightTurnDegrees or 0) >= (config.turnDegrees or 0)
        and (state.driverAssessmentCollisionCount or 0) == 0
        and (state.driverAssessmentSpeedFaultSeconds or 0) < (config.speedFaultSeconds or 4)
end

function RFF_VehicleComplianceService:showPracticalBriefing(state, config)
    local template = getText("rff_licence_practical_briefing_dynamic",
        "Category %s practical assessment. To pass: drive %.1f km in total, including %.1f km on recognised roads; reverse %.0f m; remain moving for %d minutes; and complete %.0f degrees of both left and right manoeuvring. Follow the changing limit in the lower-left HUD: the lowest applicable road, vehicle, width/weight or penalty limit. A Traffic Courtesy collision or %d cumulative seconds above the speed tolerance fails the attempt.")
    local category = tostring(state.driverAssessmentCategory or "")
    local text = string.format(template,
        category,
        (config.distance or 0) / 1000,
        (config.roadDistance or 0) / 1000,
        config.reverseDistance or 0,
        math.ceil((config.movingSeconds or 0) / 60),
        config.turnDegrees or 0,
        config.speedFaultSeconds or 4)
    if InfoDialog ~= nil and type(InfoDialog.show) == "function" then
        InfoDialog.show(text)
    end
end

function RFF_VehicleComplianceService:beginPracticalReturn(farmId, state, runtime)
    local now = self:getMonotonicHour()
    state.driverAssessmentStatus = self.ASSESSMENT_RETURNING
    state.driverAssessmentDeadlineDay = 0
    state.driverAssessmentReturnDeadlineHour = now + 1
    runtime.returnStartedHour = now
    runtime.returnDistance = nil
    self:notify(farmId, "rff_licence_title_practical", "Practical Assessment Complete",
        "rff_licence_message_practical", "Your Category %s practical requirements are complete. Return the assessment vehicle to the dealership, park in the delivery area and exit. It will be collected automatically after one in-game hour.", state.driverAssessmentCategory)
    local text = getText("rff_licence_practical_complete_popup",
        "Practical assessment complete. Return the test vehicle to the dealership, park in the delivery area and exit. You have one in-game hour before the vehicle is collected automatically.")
    if InfoDialog ~= nil and type(InfoDialog.show) == "function" then
        InfoDialog.show(text)
    end
    print(string.format("[RealisticFarmFinance] Licence practical complete; vehicle return requested farm=%d category=%s deadlineHour=%.3f distance=%.0f road=%.0f reverse=%.0f moving=%.0fs left=%.0f right=%.0f",
        farmId, state.driverAssessmentCategory, state.driverAssessmentReturnDeadlineHour,
        state.driverAssessmentDistance, state.driverAssessmentRoadDistance,
        state.driverAssessmentReverseDistance, state.driverAssessmentMovingSeconds,
        state.driverAssessmentLeftTurnDegrees, state.driverAssessmentRightTurnDegrees))
end

function RFF_VehicleComplianceService:completePracticalHandover(farmId, state, reason)
    local category = tostring(state.driverAssessmentCategory or "")
    local failedReturn = state.driverAssessmentStatus == self.ASSESSMENT_RETURNING_FAILED
    local failureReason = tostring(state.driverAssessmentFailureReason or "UNSUCCESSFUL")
    self:removeAssessmentVehicle(farmId, state)
    self._assessmentRuntime[farmId] = nil
    if failedReturn then
        state.driverAssessmentStatus = self.ASSESSMENT_FAILED
        state.driverAssessmentFailureReason = failureReason
        state.driverAssessmentLastResultCategory = category
        state.driverAssessmentLastResult = self.ASSESSMENT_FAILED
        state.driverAssessmentDeadlineDay = 0
        state.driverAssessmentReturnDeadlineHour = 0
        self:notify(farmId, "rff_licence_title_failed_returned", "Assessment Vehicle Returned",
            "rff_licence_message_failed_returned", "The Category %s assessment vehicle has been collected and the unsuccessful result is now recorded. You may book another attempt from Vehicles - Compliance.", category)
        print(string.format("[RealisticFarmFinance] Failed licence assessment vehicle collected farm=%d category=%s reason=%s handover=%s",
            farmId, category, failureReason, tostring(reason or "UNKNOWN")))
        return
    end
    self:beginTheory(state)
    self:notify(farmId, "rff_licence_title_handover", "Assessment Vehicle Returned",
        "rff_licence_message_handover", "The Category %s assessment vehicle has been collected. Your five-question theory assessment is now ready in Vehicles - Compliance.", category)
    print(string.format("[RealisticFarmFinance] Licence assessment vehicle collected farm=%d category=%s reason=%s",
        farmId, category, tostring(reason or "UNKNOWN")))
end

function RFF_VehicleComplianceService:updatePracticalReturn(farmId, state)
    local runtime = self._assessmentRuntime[farmId]
    if runtime == nil then
        -- Test vehicles are intentionally not saved. A save/reload completes the
        -- handover while preserving either the practical pass or failure result.
        self:completePracticalHandover(farmId, state, "RELOAD")
        return
    end
    local vehicle = self:findAssessmentVehicle(state.driverAssessmentVehicleUniqueId)
    if vehicle == nil then
        self:completePracticalHandover(farmId, state, "VEHICLE_MISSING")
        return
    end
    if self:getMonotonicHour() >= (state.driverAssessmentReturnDeadlineHour or 0) then
        self:completePracticalHandover(farmId, state, "TIME")
        return
    end
    local node = self:getPracticalVehicleNode(vehicle)
    if node == nil or node == 0 or getWorldTranslation == nil then return end
    local okPosition, x, _, z = pcall(getWorldTranslation, node)
    if not okPosition then return end
    local dx = x - safeNumber(runtime.dealerX)
    local dz = z - safeNumber(runtime.dealerZ)
    runtime.returnDistance = math.sqrt(dx * dx + dz * dz)
    local controlled = g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function" and g_localPlayer:getCurrentVehicle() or nil
    controlled = getRootVehicle(controlled)
    if runtime.returnDistance <= 25 and self:getVehicleSpeed(vehicle) <= 2 and controlled ~= vehicle then
        self:completePracticalHandover(farmId, state, "DEALER")
    end
end

function RFF_VehicleComplianceService:updatePractical(farmId, state, dt)
    local config = self:getLicenceConfig(state.driverAssessmentCategory)
    if config == nil then self:failAssessment(farmId, "CATEGORY"); return end
    if self:getCurrentDay() > (state.driverAssessmentDeadlineDay or 0) then self:failAssessment(farmId, "TIME"); return end
    local vehicle = self:findAssessmentVehicle(state.driverAssessmentVehicleUniqueId)
    local runtime = self._assessmentRuntime[farmId] or {missingMs=0}
    self._assessmentRuntime[farmId] = runtime
    if vehicle == nil then
        runtime.missingMs = (runtime.missingMs or 0) + (dt or 0)
        if runtime.missingMs > 5000 then self:failAssessment(farmId, "VEHICLE_MISSING") end
        return
    end
    runtime.missingMs = 0
    local controlled = g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function" and g_localPlayer:getCurrentVehicle() or nil
    controlled = getRootVehicle(controlled)
    if controlled ~= vehicle then return end
    if runtime.briefingShown ~= true then
        runtime.briefingShown = true
        self:showPracticalBriefing(state, config)
    end
    local node = self:getPracticalVehicleNode(vehicle)
    if node == nil or node == 0 or getWorldTranslation == nil or getWorldRotation == nil then return end
    local okPosition, x, _, z = pcall(getWorldTranslation, node)
    local okRotation, _, yaw, _ = pcall(getWorldRotation, node)
    if not okPosition or not okRotation then return end
    if runtime.x == nil then
        runtime.x, runtime.z, runtime.yaw = x, z, yaw
        return
    end
    local dx, dz = x - runtime.x, z - runtime.z
    local distance = math.sqrt(dx * dx + dz * dz)
    local seconds = math.max(0, math.min(1, safeNumber(dt) / 1000))
    if distance <= 30 then
        local speed = self:getVehicleSpeed(vehicle)
        if speed > 1 then
            state.driverAssessmentDistance = (state.driverAssessmentDistance or 0) + distance
            state.driverAssessmentMovingSeconds = (state.driverAssessmentMovingSeconds or 0) + seconds
            local location, roadInfo = self.fleetManagement:classifyVehicleUse(farmId, vehicle)
            if location == "ROAD" then
                state.driverAssessmentRoadDistance = (state.driverAssessmentRoadDistance or 0) + distance
                local limit = self:getSpeedRules(farmId, vehicle, nil, nil, nil, location, roadInfo).limitKmh
                if speed > limit + 1 then
                    state.driverAssessmentSpeedFaultSeconds = (state.driverAssessmentSpeedFaultSeconds or 0) + seconds
                    if state.driverAssessmentSpeedFaultSeconds >= (config.speedFaultSeconds or 4) then
                        self:failAssessment(farmId, "SPEED")
                        return
                    end
                end
            end
            local direction = 0
            local okDirection, value = call(vehicle, "getDrivingDirection")
            if okDirection then direction = safeNumber(value) end
            if direction < 0 then state.driverAssessmentReverseDistance = (state.driverAssessmentReverseDistance or 0) + distance end
        end
        local yawDelta = yaw - (runtime.yaw or yaw)
        while yawDelta > math.pi do yawDelta = yawDelta - math.pi * 2 end
        while yawDelta < -math.pi do yawDelta = yawDelta + math.pi * 2 end
        local degrees = math.abs(math.deg(yawDelta))
        if distance > 0.05 and degrees < 45 then
            if yawDelta >= 0 then state.driverAssessmentLeftTurnDegrees = (state.driverAssessmentLeftTurnDegrees or 0) + degrees
            else state.driverAssessmentRightTurnDegrees = (state.driverAssessmentRightTurnDegrees or 0) + degrees end
        end
    end
    runtime.x, runtime.z, runtime.yaw = x, z, yaw
    if self:isPracticalComplete(state, config) then
        self:beginPracticalReturn(farmId, state, runtime)
    end
end

function RFF_VehicleComplianceService:resolveTrafficCourtesyApi()
    local direct = _G["DerwenTrafficIncidents"]
    if type(direct) == "table" then return direct end
    local environment = _G["FS25_DM_TrafficCourtesy"]
    return type(environment) == "table" and rawget(environment, "DerwenTrafficIncidents") or nil
end

function RFF_VehicleComplianceService:installTrafficCourtesyHook()
    local api = self:resolveTrafficCourtesyApi()
    if type(api) ~= "table" or type(api.registerIncidentListener) ~= "function" then return false end
    if self._trafficCourtesyRegistered and self._trafficCourtesyApi == api then return true end
    if self._trafficCourtesyApi ~= nil and type(self._trafficCourtesyApi.unregisterIncidentListener) == "function" then
        pcall(self._trafficCourtesyApi.unregisterIncidentListener, self._trafficCourtesyApi, self)
    end
    local ok, registered = pcall(api.registerIncidentListener, api, self, self.onTrafficCourtesyIncident)
    if not ok or registered ~= true then return false end
    self._trafficCourtesyApi = api
    self._trafficCourtesyRegistered = true
    print("[RealisticFarmFinance] Driver assessment and offence monitoring connected to Traffic Courtesy")
    return true
end

function RFF_VehicleComplianceService:shutdownTrafficCourtesyHook()
    if RFF_VehicleComplianceService._speedPenaltyService == self then
        RFF_VehicleComplianceService._speedPenaltyService = nil
    end
    if self._trafficCourtesyApi ~= nil and type(self._trafficCourtesyApi.unregisterIncidentListener) == "function" then
        pcall(self._trafficCourtesyApi.unregisterIncidentListener, self._trafficCourtesyApi, self)
    end
    self._trafficCourtesyApi = nil
    self._trafficCourtesyRegistered = false
end

function RFF_VehicleComplianceService:onTrafficCourtesyIncident(entry)
    if type(entry) ~= "table" then return end
    local farmId = math.floor(safeNumber(entry.farmId))
    self:recordTrafficCourtesyOffence(entry)
    local state = self:ensureQualificationRecord(farmId)
    if state == nil or state.driverAssessmentStatus ~= self.ASSESSMENT_PRACTICAL then return end
    local vehicleId = tostring(state.driverAssessmentVehicleUniqueId or "")
    if vehicleId ~= "" and (tostring(entry.vehicleId or "") == vehicleId or tostring(entry.partId or "") == vehicleId) then
        state.driverAssessmentCollisionCount = (state.driverAssessmentCollisionCount or 0) + 1
        self:failAssessment(farmId, "COLLISION")
    end
end

function RFF_VehicleComplianceService:drawSpeedPenalty()
    if g_currentMission == nil or g_localPlayer == nil or renderText == nil or drawFilledRect == nil then return end
    if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil and g_gui:getIsGuiVisible() then return end
    local vehicle = g_localPlayer.getCurrentVehicle ~= nil and getRootVehicle(g_localPlayer:getCurrentVehicle()) or nil
    local cap, state = self:getControlledPenalty(vehicle)
    if cap == nil then return end
    local finalWarning = (state.driverRestrictionRepeats or 0) >= 2
    local title = string.format(getText("rff_driver_restriction_hud", "RESTRICTED DRIVING: %d km/h"), cap)
    local deadline = string.format(getText("rff_driver_restriction_hud_end", "Ends %s"), self:formatRestrictionEnd(state.driverRestrictionEnd))
    local x, y, width = 0.018, 0.200, 0.40
    drawFilledRect(x, y, width, 0.075, 0, 0, 0, 0.76)
    if setTextAlignment ~= nil and RenderText ~= nil then setTextAlignment(RenderText.ALIGN_LEFT) end
    if setTextVerticalAlignment ~= nil and RenderText ~= nil then setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE) end
    if setTextBold ~= nil then setTextBold(true) end
    if setTextColor ~= nil then setTextColor(1, 0.65, 0.15, 1) end
    renderText(x + 0.009, y + 0.052, 0.017, title)
    if setTextBold ~= nil then setTextBold(false) end
    if setTextColor ~= nil then setTextColor(1, 1, 1, 1) end
    renderText(x + 0.009, y + 0.030, 0.0135, deadline)
    local note = getText(finalWarning and "rff_driver_restriction_final_short" or "rff_driver_restriction_hud_note",
        "Further offences extend this restriction")
    renderText(x + 0.009, y + 0.010, 0.0125, note)
end

function RFF_VehicleComplianceService:draw()
    self:drawSpeedPenalty()
    if g_currentMission == nil or self.repository == nil or renderText == nil or drawFilledRect == nil then return end
    if g_gui ~= nil and type(g_gui.getIsGuiVisible) == "function" and g_gui:getIsGuiVisible() then return end
    local farmId = type(g_currentMission.getFarmId) == "function" and g_currentMission:getFarmId() or 0
    if farmId == nil or farmId <= 0 then return end
    local state = self.repository:getFarmState(farmId, false)
    if state == nil then return end
    local status = tostring(state.driverAssessmentStatus or "")
    if status ~= self.ASSESSMENT_PRACTICAL and status ~= self.ASSESSMENT_RETURNING
        and status ~= self.ASSESSMENT_RETURNING_FAILED then return end
    local runtime = self._assessmentRuntime[farmId]
    if runtime == nil then return end
    local vehicle = self:findAssessmentVehicle(state.driverAssessmentVehicleUniqueId)
    if status == self.ASSESSMENT_PRACTICAL then
        local controlled = g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function" and g_localPlayer:getCurrentVehicle() or nil
        if getRootVehicle(controlled) ~= vehicle then return end
    end

    local lines = {}
    local title
    if status == self.ASSESSMENT_RETURNING or status == self.ASSESSMENT_RETURNING_FAILED then
        local failedReturn = status == self.ASSESSMENT_RETURNING_FAILED
        title = failedReturn and getText("rff_licence_hud_failed_return_title", "TEST ENDED")
            or getText("rff_licence_hud_return_title", "PRACTICAL COMPLETE")
        lines[#lines + 1] = {failedReturn and getText("rff_licence_hud_failed_return", "Return the test vehicle before rebooking")
            or getText("rff_licence_hud_return", "Return the test vehicle to the dealership"), false}
        lines[#lines + 1] = {getText("rff_licence_hud_return_exit", "Park in the delivery area and exit the vehicle"), false}
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_return_distance", "Dealer distance: %.0f m"), safeNumber(runtime.returnDistance)), false}
        local minutes = math.max(0, math.ceil(((state.driverAssessmentReturnDeadlineHour or 0) - self:getMonotonicHour()) * 60))
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_return_time", "Automatic collection in %d in-game minute(s)"), minutes), false}
    else
        local config = self:getLicenceConfig(state.driverAssessmentCategory)
        if config == nil then return end
        local category = tostring(state.driverAssessmentCategory or "")
        local currentSpeed = self:getVehicleSpeed(vehicle)
        local rules = self:getSpeedRules(farmId, vehicle)
        local roadLimit = rules.limitKmh
        local location = rules.locationType
        local speedingOnRoad = location == "ROAD" and currentSpeed > roadLimit + 1
        title = string.format(getText("rff_licence_hud_title", "CATEGORY %s PRACTICAL ASSESSMENT"), category)
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_dynamic_speed", "Speed: %s | Limit: %s"),
            RFF_RoadSpeedRules.formatSpeed(currentSpeed, g_i18n), RFF_RoadSpeedRules.formatSpeed(roadLimit, g_i18n)),
            location == "ROAD" and not speedingOnRoad, speedingOnRoad}
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_total", "Total distance: %.1f / %.1f km"),
            (state.driverAssessmentDistance or 0) / 1000, (config.distance or 0) / 1000), (state.driverAssessmentDistance or 0) >= (config.distance or 0)}
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_road", "Recognised road: %.1f / %.1f km"),
            (state.driverAssessmentRoadDistance or 0) / 1000, (config.roadDistance or 0) / 1000), (state.driverAssessmentRoadDistance or 0) >= (config.roadDistance or 0)}
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_reverse", "Reversing: %.0f / %.0f m"),
            state.driverAssessmentReverseDistance or 0, config.reverseDistance or 0), (state.driverAssessmentReverseDistance or 0) >= (config.reverseDistance or 0)}
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_moving", "Moving time: %s / %s"),
            formatDuration(state.driverAssessmentMovingSeconds), formatDuration(config.movingSeconds)), (state.driverAssessmentMovingSeconds or 0) >= (config.movingSeconds or 0)}
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_turns", "Manoeuvring: L %.0f / %.0f deg | R %.0f / %.0f deg"),
            state.driverAssessmentLeftTurnDegrees or 0, config.turnDegrees or 0,
            state.driverAssessmentRightTurnDegrees or 0, config.turnDegrees or 0),
            (state.driverAssessmentLeftTurnDegrees or 0) >= (config.turnDegrees or 0) and (state.driverAssessmentRightTurnDegrees or 0) >= (config.turnDegrees or 0)}
        lines[#lines + 1] = {string.format(getText("rff_licence_hud_conduct", "Conduct: %d collision(s) | %.1f / %.1f sec speeding"),
            state.driverAssessmentCollisionCount or 0, state.driverAssessmentSpeedFaultSeconds or 0, config.speedFaultSeconds or 4),
            (state.driverAssessmentCollisionCount or 0) == 0 and (state.driverAssessmentSpeedFaultSeconds or 0) < (config.speedFaultSeconds or 4)}
    end

    local x, y, width = 0.018, 0.285, 0.365
    local padding, titleSize, textSize, lineHeight = 0.009, 0.019, 0.0145, 0.022
    local height = padding * 2 + titleSize + 0.008 + #lines * lineHeight
    drawFilledRect(x, y, width, height, 0, 0, 0, 0.76)
    drawFilledRect(x, y + height - 0.004, width, 0.004, 0.42, 0.66, 0, 1)
    if setTextAlignment ~= nil and RenderText ~= nil then setTextAlignment(RenderText.ALIGN_LEFT) end
    if setTextVerticalAlignment ~= nil and RenderText ~= nil then setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE) end
    if setTextBold ~= nil then setTextBold(true) end
    if setTextColor ~= nil then setTextColor(0.58, 0.80, 0.12, 1) end
    local textY = y + height - padding - titleSize
    renderText(x + padding, textY, titleSize, title)
    if setTextBold ~= nil then setTextBold(false) end
    textY = textY - 0.028
    for _, line in ipairs(lines) do
        if setTextColor ~= nil then
            if line[3] then setTextColor(0.93, 0.25, 0.18, 1)
            elseif line[2] then setTextColor(0.58, 0.80, 0.12, 1)
            else setTextColor(0.92, 0.92, 0.92, 1) end
        end
        renderText(x + padding, textY, textSize, line[1])
        textY = textY - lineHeight
    end
    if setTextBold ~= nil then setTextBold(false) end
    if setTextColor ~= nil then setTextColor(1, 1, 1, 1) end
    if setTextAlignment ~= nil and RenderText ~= nil then setTextAlignment(RenderText.ALIGN_LEFT) end
    if setTextVerticalAlignment ~= nil and RenderText ~= nil then setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE) end
end

function RFF_VehicleComplianceService:update(dt)
    self:installSpeedPenaltyHook()
    self._trafficCourtesyRetryMs = (self._trafficCourtesyRetryMs or 0) - (dt or 0)
    if self._trafficCourtesyRetryMs <= 0 then
        self._trafficCourtesyRetryMs = 3000
        self:installTrafficCourtesyHook()
    end
    self._movementAuthorisationCheckMs = (self._movementAuthorisationCheckMs or 0) - (dt or 0)
    local checkMovementAuthorisations = self._movementAuthorisationCheckMs <= 0
    if checkMovementAuthorisations then self._movementAuthorisationCheckMs = 1000 end
    for farmId, state in pairs(self.repository ~= nil and self.repository.farms or {}) do
        self:ensureQualificationRecord(farmId)
        if checkMovementAuthorisations then
            self:cleanupExpiredMovementAuthorisations(farmId, state)
            self:expireSpeedPenalty(farmId, state)
        end
        if state.driverAssessmentStatus == self.ASSESSMENT_PRACTICAL then
            if self._assessmentRuntime[farmId] == nil then
                -- Assessment vehicles deliberately do not belong to or persist in the
                -- savegame. Re-open the appointment after a save/reload while retaining
                -- the measurements already completed.
                state.driverAssessmentStatus = self.ASSESSMENT_BOOKED
                state.driverAssessmentAvailableDay = self:getCurrentDay()
                state.driverAssessmentVehicleUniqueId = ""
                state.driverAssessmentVehicleName = ""
                state.driverAssessmentFailureReason = "RESUME"
            else
                self:updatePractical(farmId, state, dt)
            end
        elseif state.driverAssessmentStatus == self.ASSESSMENT_RETURNING
            or state.driverAssessmentStatus == self.ASSESSMENT_RETURNING_FAILED then
            self:updatePracticalReturn(farmId, state)
        elseif state.driverAssessmentStatus == self.ASSESSMENT_SPAWNING then
            local runtime = self._assessmentRuntime[farmId]
            if runtime == nil or runtime.loading ~= true then
                state.driverAssessmentStatus = self.ASSESSMENT_BOOKED
                state.driverAssessmentAvailableDay = self:getCurrentDay()
                state.driverAssessmentFailureReason = "RESUME"
            end
        end
    end
end

function RFF_VehicleComplianceService:onDayChanged()
    for farmId, state in pairs(self.repository ~= nil and self.repository.farms or {}) do
        if state.driverAssessmentStatus == self.ASSESSMENT_PRACTICAL
            and self:getCurrentDay() > (state.driverAssessmentDeadlineDay or 0) then
            self:failAssessment(farmId, "TIME")
        elseif state.driverAssessmentStatus == self.ASSESSMENT_BOOKED
            and self:getCurrentDay() == (state.driverAssessmentAvailableDay or 0) then
            local theoryRetake = state.driverAssessmentFailureReason == "THEORY_RETAKE"
            self:notify(farmId, theoryRetake and "rff_licence_title_theory_retake_ready" or "rff_licence_title_ready",
                theoryRetake and "Theory Retake Appointment Ready" or "Assessment Appointment Ready",
                theoryRetake and "rff_licence_message_theory_retake_ready" or "rff_licence_message_ready",
                theoryRetake and "Your Category %s theory-only retake is now ready. Start it from Vehicles - Compliance; the practical test will not be repeated."
                    or "Your Category %s assessment appointment is now ready. Start it from Vehicles - Compliance when you are prepared.", state.driverAssessmentCategory)
        end
    end
end
