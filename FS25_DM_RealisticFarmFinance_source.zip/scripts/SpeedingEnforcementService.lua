-- Optional gameplay patrol checks. No cameras, roadside stops or collision dependency.
RFF_SpeedingEnforcementService = {}
RFF_SpeedingEnforcementService.__index = RFF_SpeedingEnforcementService
RFF_SpeedingEnforcementService.CHECK_MIN_SECONDS = 600
RFF_SpeedingEnforcementService.CHECK_MAX_SECONDS = 1200
RFF_SpeedingEnforcementService.WINDOW_SECONDS = 45
RFF_SpeedingEnforcementService.SUSTAINED_SECONDS = 12
RFF_SpeedingEnforcementService.COOLDOWN_HOURS = 72

local function server()
    return g_currentMission ~= nil and g_currentMission:getIsServer()
end
local function text(key, fallback)
    if g_i18n ~= nil and g_i18n:hasText(key) then return g_i18n:getText(key) end
    return fallback
end
function RFF_SpeedingEnforcementService.new(repository, compliance)
    return setmetatable({repository=repository,compliance=compliance,elapsed=0,runtime={}},RFF_SpeedingEnforcementService)
end
function RFF_SpeedingEnforcementService:randomDelay()
    return math.random(self.CHECK_MIN_SECONDS,self.CHECK_MAX_SECONDS)
end
function RFF_SpeedingEnforcementService:setEnabled(farmId, enabled)
    if not server() or farmId == nil or farmId <= 0 then return false end
    local state=self.repository:getFarmState(farmId,true)
    if state == nil then return false end
    state.speedingEnforcementEnabled=enabled == true
    if state.speedingCheckRemaining == nil then state.speedingCheckRemaining=self:randomDelay() end
    state.speedingWindowRemaining=0
    self.runtime[farmId]=nil
    if not enabled then
        for _,notice in ipairs(self.repository.speedingNotices or {}) do
            if notice.farmId == farmId and notice.status == "PENDING" then notice.status="CANCELLED" end
        end
    end
    return true
end
function RFF_SpeedingEnforcementService:hasPending(farmId)
    for _,notice in ipairs(self.repository.speedingNotices or {}) do
        if notice.farmId == farmId and notice.status == "PENDING" then return true end
    end
    return false
end
function RFF_SpeedingEnforcementService:getOutcome(speed, limit)
    local excess=(speed-limit)/limit
    if excess <= 0.20 then return 0,0,"MINOR" end
    if excess <= 0.40 then return 250,3,"MODERATE" end
    if excess <= 0.60 then return 500,4,"SERIOUS" end
    return 1000,6,"SEVERE"
end
function RFF_SpeedingEnforcementService:queueNotice(farmId, vehicle, speed, limit, reason)
    if not server() or vehicle == nil or type(speed) ~= "number" or type(limit) ~= "number"
        or limit <= 0 or speed ~= speed or limit ~= limit or speed == math.huge or limit == math.huge
        or speed <= limit+math.max(3,limit*0.1) then return nil end
    local state=self.repository:getFarmState(farmId,false)
    if not server() or state == nil or not state.speedingEnforcementEnabled or self:hasPending(farmId) then return nil end
    local now=self.compliance:getMonotonicHour()
    if now < (state.speedingCooldownUntil or 0) then return nil end
    local id=1
    for _,n in ipairs(self.repository.speedingNotices or {}) do id=math.max(id,(n.id or 0)+1) end
    local fine,points,severity=self:getOutcome(speed,limit)
    local env=g_currentMission.environment
    local notice={id=id,farmId=farmId,status="PENDING",detectedHour=now,dueHour=now+math.random(1,2)*24,
        incidentPeriod=self.repository:getCurrentPeriodIndex(),incidentDay=self.compliance:getCurrentDay(),
        dayTimeMs=env ~= nil and env.dayTime or 0,vehicleUniqueId=tostring(vehicle.uniqueId or ""),
        vehicleName=vehicle.getName ~= nil and vehicle:getName() or "Vehicle",speedKph=speed,limitKph=limit,
        limitReason=reason or "ROAD",fine=fine,points=points,severityClass=severity}
    table.insert(self.repository.speedingNotices,notice)
    state.speedingCooldownUntil=now+self.COOLDOWN_HOURS
    state.speedingCheckRemaining=self:randomDelay()
    state.speedingWindowRemaining=0
    self.runtime[farmId]=nil
    return notice
end
function RFF_SpeedingEnforcementService:getNoticeMessage(notice)
    local when=self.compliance:formatRestrictionEnd(notice.incidentPeriod or 0)
    local speed=RFF_RoadSpeedRules.formatSpeed(notice.speedKph,g_i18n)
    local limit=RFF_RoadSpeedRules.formatSpeed(notice.limitKph,g_i18n)
    local money=g_i18n ~= nil and g_i18n:formatMoney(notice.fine or 0,0,true,true) or tostring(notice.fine or 0)
    local time=math.floor((notice.dayTimeMs or 0)/60000)
    local body=string.format(text("rff_speeding_notice_body",
        "Notice RFF-SN-%06d. Vehicle: %s. Offence: day %d, %s, %02d:%02d. Recorded speed: %s. Applicable limit: %s."),
        notice.id,notice.vehicleName,notice.incidentDay,when:match("^(.-),") or when,math.floor(time/60),time%60,speed,limit)
    if (notice.points or 0) == 0 then
        body=body.." "..text("rff_speeding_warning_body","This is a written warning. No fine or points have been applied. Please observe the displayed road limit.")
    else
        body=body.." "..string.format(text("rff_speeding_penalty_body",
            "Fine debited on delivery: %s. Points added: %d. Points run for six months from delivery, not the offence date. View the driving record in Vehicles > Road Options."),money,notice.points)
    end
    if notice.restrictionMessage ~= nil and notice.restrictionMessage ~= "" then body=body.." "..notice.restrictionMessage end
    return body
end
function RFF_SpeedingEnforcementService:deliver(notice)
    if not server() or notice.status ~= "PENDING" or self.compliance:getMonotonicHour() < notice.dueHour then return false end
    if g_farmManager ~= nil and g_farmManager:getFarmById(notice.farmId) == nil then return false end
    local state=self.compliance:ensureQualificationRecord(notice.farmId)
    if state == nil then return false end
    if state.speedingEnforcementEnabled ~= true then notice.status="CANCELLED";return false end
    local reference=string.format("RFF-SN-%06d",notice.id)
    if self.repository:getDriverOffenceByExternalId(reference) ~= nil then notice.status="DELIVERED";return false end
    if (notice.fine or 0)>0 and (g_currentMission.addMoney == nil or MoneyType == nil or MoneyType.OTHER == nil) then return false end
    self.compliance:expireSpeedPenalty(notice.farmId,state)
    local now=self.compliance:getPenaltyClock()
    local offence={id=self.repository:getNextDriverOffenceId(),farmId=notice.farmId,source="RFF_SPEEDING",
        externalIncidentId=reference,status=notice.points>0 and "ACTIVE" or "WARNING",offenceCode="SPEEDING",
        locationType="ROAD",incidentDay=notice.incidentDay,incidentPeriod=notice.incidentPeriod,
        dayTimeMs=notice.dayTimeMs,vehicleUniqueId=notice.vehicleUniqueId,vehicleName=notice.vehicleName,
        targetName="",severityClass=notice.severityClass,points=notice.points,sourceSpeedKph=notice.speedKph,
        closingSpeedKph=0,pointsIssuedAt=notice.points>0 and now or nil,
        pointsExpireAt=notice.points>0 and now+self.compliance.POINTS_EXPIRY_MONTHS or nil,
        pointsTotalAfter=(state.driverPenaltyPoints or 0)+notice.points}
    -- Set idempotency state before callbacks from money/notifications can re-enter.
    notice.status="DELIVERED"
    notice.deliveredHour=self.compliance:getMonotonicHour()
    self.repository:addDriverOffence(offence)
    if notice.fine>0 then g_currentMission:addMoney(-notice.fine,notice.farmId,MoneyType.OTHER,true,true) end
    state.driverPenaltyPoints=offence.pointsTotalAfter
    if notice.points>0 then
        local action=self.compliance:applyOffenceSpeedPenalty(notice.farmId,state)
        if action ~= nil and action ~= "OFF" then notice.restrictionMessage=self.compliance:getRestrictionSummary(notice.farmId) end
    end
    if RFF_NotificationService ~= nil then
        RFF_NotificationService:send(notice.farmId,text("rff_speeding_sender","Road Enforcement Office"),
            text("rff_speeding_notice_title","Speeding Notice"),self:getNoticeMessage(notice),"licensing",
            text("rff_speeding_notice_hud","Speeding notice received"),false)
    end
    return true
end
function RFF_SpeedingEnforcementService:processNotices()
    if not server() then return end
    local now=self.compliance:getMonotonicHour()
    for _,notice in ipairs(self.repository.speedingNotices or {}) do
        if notice.status=="PENDING" and now >= notice.dueHour then self:deliver(notice) end
    end
end
function RFF_SpeedingEnforcementService:getContext(settingKey)
    if not server() or g_localPlayer == nil or g_localPlayer.getCurrentVehicle == nil then return nil end
    if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil and g_gui:getIsGuiVisible() then return nil end
    if g_currentMission.paused == true then return nil end
    local vehicle=g_localPlayer:getCurrentVehicle()
    local farmId=g_currentMission:getFarmId()
    local state=self.repository:getFarmState(farmId,false)
    if vehicle==nil or state==nil or state[settingKey or "speedingEnforcementEnabled"]~=true then return nil end
    if vehicle.spec_motorized==nil or (vehicle.getIsAIActive~=nil and vehicle:getIsAIActive()) then return nil end
    if not self.compliance.fleetManagement:isDriveableFarmVehicle(vehicle,farmId) then return nil end
    if self.compliance:isActiveAssessmentStatus(state.driverAssessmentStatus) then return nil end
    return farmId,vehicle,state
end
function RFF_SpeedingEnforcementService:sample(farmId,vehicle,state,rules,speed,seconds)
    if not server() or state == nil or state.speedingEnforcementEnabled ~= true then return end
    if rules==nil or rules.locationType~="ROAD" or rules.limitKmh==nil or rules.limitKmh<=0 or speed<5 then self.runtime[farmId]=nil;return end
    if self:hasPending(farmId) or self.compliance:getMonotonicHour()<(state.speedingCooldownUntil or 0) then self.runtime[farmId]=nil;return end
    if state.speedingCheckRemaining==nil then state.speedingCheckRemaining=self:randomDelay() end
    if (state.speedingWindowRemaining or 0)<=0 then
        state.speedingCheckRemaining=math.max(0,state.speedingCheckRemaining-seconds)
        if state.speedingCheckRemaining>0 then self.runtime[farmId]=nil;return end
        state.speedingWindowRemaining=self.WINDOW_SECONDS
        state.speedingCheckRemaining=self:randomDelay()
    end
    state.speedingWindowRemaining=math.max(0,state.speedingWindowRemaining-seconds)
    local limit=rules.limitKmh
    if speed <= limit+math.max(3,limit*0.1) then self.runtime[farmId]=nil;return end
    local r=self.runtime[farmId]
    if r==nil or r.vehicle~=vehicle or math.abs(r.limit-limit)>0.5 then r={vehicle=vehicle,limit=limit,seconds=0,speed=speed};self.runtime[farmId]=r end
    r.seconds=r.seconds+seconds
    r.speed=math.min(r.speed,speed) -- Do not turn a momentary spike into a higher fine band.
    if r.seconds>=self.SUSTAINED_SECONDS then self:queueNotice(farmId,vehicle,r.speed,limit,rules.reason) end
    if state.speedingWindowRemaining<=0 then self.runtime[farmId]=nil end
end
function RFF_SpeedingEnforcementService:update(dt)
    if not server() then return end
    self.elapsed=self.elapsed+math.max(0,tonumber(dt) or 0)
    if self.elapsed<1000 then return end
    local seconds=math.min(1,self.elapsed/1000);self.elapsed=0
    self:processNotices()
    local farmId,vehicle,state=self:getContext()
    if farmId==nil then self.runtime={};return end
    for id in pairs(self.runtime) do if id~=farmId then self.runtime[id]=nil end end
    self:sample(farmId,vehicle,state,self.compliance:getSpeedRules(farmId,vehicle),self.compliance:getVehicleSpeed(vehicle),seconds)
end
function RFF_SpeedingEnforcementService:findNotice(reference)
    for _,n in ipairs(self.repository.speedingNotices or {}) do
        if string.format("RFF-SN-%06d",n.id)==reference then return n end
    end
    return nil
end
function RFF_SpeedingEnforcementService:consoleTest(action)
    if not server() then return "Server only" end
    local farmId=g_currentMission:getFarmId()
    local state=self.repository:getFarmState(farmId,false)
    if state==nil then return "No farm" end
    action=string.upper(tostring(action or "STATUS"))
    if action=="ARM" then
        if not state.speedingEnforcementEnabled then return "Enable occasional speeding notices in Vehicles > Road Options first." end
        if self:hasPending(farmId) then return "A notice is already pending. Wait for delivery." end
        state.speedingCooldownUntil=0;state.speedingCheckRemaining=0;state.speedingWindowRemaining=0;self.runtime[farmId]=nil
        return "TEST: next eligible road-driving sample starts a 45-second patrol check. Sustain speeding for 12 seconds. This can produce real fines/points after 24 or 48 game hours."
    end
    if action~="STATUS" then return "rffSpeedingTest [STATUS|ARM] - use a test save" end
    local rows={string.format("Speeding notices enabled=%s; road-driving seconds to check=%.0f; cooldown until game hour=%.2f; now=%.2f",
        tostring(state.speedingEnforcementEnabled==true),state.speedingCheckRemaining or -1,state.speedingCooldownUntil or 0,self.compliance:getMonotonicHour())}
    for _,n in ipairs(self.repository.speedingNotices or {}) do
        if n.farmId==farmId then rows[#rows+1]=string.format("RFF-SN-%06d %s: %.1f / %.1f km/h; fine=%d points=%d; due in %.2f game hours",n.id,n.status,n.speedKph,n.limitKph,n.fine,n.points,math.max(0,n.dueHour-self.compliance:getMonotonicHour())) end
    end
    return table.concat(rows,"\n")
end
