-- Original RFF implementation. GIANTS human/vehicle loading APIs; no reference-mod code.
RFF_DealerHandover = {}
local H = RFF_DealerHandover
H.__index = H
H.HOURLY_CHARGE = 25
H.MOVEMENT_METRES = 10

local function mission() return g_currentMission end
local function copy(v) return RFF_DealershipService.copy(v) end
local function money(v) return g_i18n:formatMoney(v,0,true,true) end
local function validNode(node) return node ~= nil and node ~= 0 and entityExists(node) end
local function vehiclePosition(v)
    local node = v and v.components and v.components[1] and v.components[1].node or v and v.rootNode
    if not validNode(node) then return nil end
    local x,y,z = getWorldTranslation(node)
    return x,y,z,node
end

function H.new(dealer)
    local self = setmetatable({dealer=dealer,runtime={},timer=0,alive=true},H)
    dealer.handover = self
    return self
end

function H:hour()
    local e = mission().environment
    return ((e.currentMonotonicDay or e.currentDay or 1)-1)*24 + (e.dayTime or 0)/3600000
end

function H:vehicles(order)
    local system = mission().vehicleSystem
    local vehicles = {}
    for _,id in ipairs(order.vehicleIds or {}) do
        local v = system and system:getVehicleByUniqueId(id)
        if v == nil or v.isDeleted or v.markedForDeletion or v.ownerFarmId ~= order.farmId then return nil end
        vehicles[#vehicles+1] = v
    end
    return #vehicles > 0 and vehicles or nil
end

function H:forVehicle(v)
    if v == nil then return nil end
    for _,o in ipairs(self.dealer:state().orders) do
        if o.status ~= "DELIVERED" and o.status ~= "CANCELLED" then
            for _,id in ipairs(o.vehicleIds or {}) do if id == v.uniqueId then return o end end
        end
    end
end

function H:stage(o)
    if o.status ~= "READY" or o.vehicleIds ~= nil or self.loading ~= nil then return end
    if self.dealer.demo and self.dealer.demo.loading then return end
    local item = g_storeManager:getItemByXMLFilename(o.xml)
    if not item or not mission().storeSpawnPlaces or not mission().slotSystem:hasEnoughSlots(item) then return end
    local load = VehicleLoadingData.new()
    load:setStoreItem(item)
    load:setConfigurations(copy(o.payload.configurations))
    load:setConfigurationData(copy(o.payload.configurationData))
    load:setLoadingPlace(mission().storeSpawnPlaces,mission().usedStorePlaces)
    -- Saved, farm-accessible delivery vehicle, but not yet a purchased/leased asset.
    load:setPropertyState(VehiclePropertyState.MISSION)
    load:setOwnerFarmId(o.farmId)
    self.loading = o.id
    o.status = "STAGING"
    local ok = pcall(load.load,load,self.onStaged,self,o)
    if not ok then
        self.loading=nil;o.status="READY"
        print("[RFF dealer] Delivery loading failed; order retained without a payment.")
    end
end

function H:onStaged(vehicles,state,o)
    if o.status~="STAGING" then return end
    self.loading=nil
    if not self.alive then return end
    if not vehicles or #vehicles == 0 then
        o.status="READY";return
    end
    o.vehicleIds={}
    for _,v in ipairs(vehicles) do
        if not v.uniqueId then
            o.status="REVIEW";o.ads="Delivery identity unavailable; inspect save before recovery.";return
        end
        o.vehicleIds[#o.vehicleIds+1]=v.uniqueId
        v.isVehicleSaved=true
        if v.setLicensePlatesData and v.getHasLicensePlates and v:getHasLicensePlates() then
            v:setLicensePlatesData(copy(o.payload.licensePlateData))
        end
    end
    if state~=VehicleLoadingState.OK then
        o.status="REVIEW";o.ads="Partial delivery load; inspect the save before recovery.";return
    end
    o.status="READY"
    o.expires=math.max(o.expires,self.dealer:clock()+1)
    self.runtime[o.id]={settle=2000}
    self.dealer:notify(o,"Delivery at the dealership","Your machine is waiting. Speak to the representative to complete handover. Moving it over 10 m first starts a 25/hour game-time charge.")
end

function H:accrue(o,final)
    if o.useStartedHour == nil then return 0 end
    local elapsed=math.max(0,self:hour()-o.useStartedHour)
    local hours=final and elapsed or math.floor(elapsed+0.000001)
    local target=math.floor(hours*self.HOURLY_CHARGE*100+0.5)
    local previous=o.handoverChargeCents or 0
    if target<=previous then return 0 end
    local amount=(target-previous)/100
    -- Mark before the synchronous money callback; no repeated hour on reload.
    o.handoverChargeCents=target
    self.dealer.repository:setNextTransactionDescription(o.farmId,"Uncompleted vehicle handover D-"..o.id)
    mission():addMoney(-amount,o.farmId,MoneyType.OTHER,true,true)
    return amount
end

function H:positionRepresentative(o,vehicles)
    local x,y,z,node=vehiclePosition(vehicles[1]);if not x then return false end
    o.deliveryOrigins={}
    for i,v in ipairs(vehicles) do
        local vx,vy,vz=vehiclePosition(v);if not vx then return false end
        o.deliveryOrigins[i]={x=vx,y=vy,z=vz}
    end
    local length=math.max(2,tonumber(vehicles[1].size and vehicles[1].size.length) or 4)
    local fx,_,fz=localDirectionToWorld(node,0,0,1)
    local nx,nz=x+fx*(length/2+1.5),z+fz*(length/2+1.5)
    local ground=getTerrainHeightAtWorldPos(mission().terrainRootNode,nx,0,nz)
    o.representative={x=nx,y=ground,z=nz,angle=math.atan(fx,fz)}
    return true
end

function H:createNPC(o,r)
    if r.model or r.npcAttempted or not o.representative or HumanModel == nil or PlayerStyle == nil then return end
    r.npcAttempted=true
    local ok,style=pcall(PlayerStyle.defaultStyle)
    if not ok or style == nil then return end
    r.style=style;r.model=HumanModel.new()
    local context={id=o.id,runtime=r}
    local started=pcall(r.model.load,r.model,style.xmlFilename,false,false,true,self.onNPCLoaded,self,context)
    if not started then self:removeNPC(o.id) end
end

function H:onNPCLoaded(state,context)
    local r=context.runtime
    if not self.alive or self.runtime[context.id]~=r or not r.model then return end
    if state~=HumanModelLoadingState.OK then self:removeNPC(context.id);return end
    local o=self.dealer:find(context.id,mission():getFarmId())
    if not o or o.status~="READY" or not o.representative then self:removeNPC(context.id);return end
    local p=o.representative
    link(getRootNode(),r.model.rootNode)
    setWorldTranslation(r.model.rootNode,p.x,p.y,p.z)
    setWorldRotation(r.model.rootNode,0,p.angle,0)
    r.model:loadFromStyleAsync(r.style,self.onNPCStyled,self,context)
end

function H:startIdle(r)
    if r.idleStarted or not r.visible or not r.model then return end
    -- The full standing-player cache puts the charset on the skeleton's first
    -- child. VEHICLE_CHARACTER is a different rig/cache, not a standing NPC.
    if not g_animCache or not AnimationCache then return end
    local sourceNode=g_animCache:getNode(AnimationCache.CHARACTER)
    if not validNode(sourceNode) then return end -- async cache: try again later
    local ok,err=pcall(function()
        local skeleton=r.model.skeleton
        assert(validNode(skeleton) and getNumOfChildren(skeleton)>0,"missing skeleton")
        assert(getNumOfChildren(sourceNode)>0,"missing cached character")
        cloneAnimCharacterSet(getChildAt(sourceNode,0),skeleton)
        local charset=getAnimCharacterSet(getChildAt(skeleton,0))
        assert(charset~=nil and charset~=0,"missing standing animation charset")
        local clip=getAnimClipIndex(charset,"idle1Source")
        assert(clip~=nil and clip>=0,"missing standing idle clip")
        clearAnimTrackClip(charset,0)
        assignAnimTrackClip(charset,0,clip)
        setAnimTrackLoopState(charset,0,true)
        setAnimTrackSpeedScale(charset,0,1)
        enableAnimTrack(charset,0)
        setAnimTrackTime(charset,0,0,true)
        r.idleStarted=true
    end)
    if not ok and not r.idleWarning then
        r.idleWarning=true
        print("[RFF dealer] Representative standing idle unavailable: "..tostring(err))
    end
end

function H:onNPCStyled(state,context)
    local r=context.runtime
    if not self.alive or self.runtime[context.id]~=r or not r.model then return end
    if state==HumanModelLoadingState.OK then r.visible=true;self:startIdle(r) end
end

function H:removeNPC(id)
    local r=self.runtime[id]
    if not r then return end
    self.runtime[id]=nil
    if r.model then r.model:delete() end
    if r.style and r.style.delete then r.style:delete() end
end

function H:nearby()
    if g_gui and g_gui.currentGui ~= nil then return nil end
    local player=g_localPlayer
    if not player or not player.getPosition or (player.getCurrentVehicle and player:getCurrentVehicle()) then return nil end
    local x,y,z=player:getPosition()
    local nearest,best=nil,9
    for _,o in ipairs(self.dealer:orders(mission():getFarmId())) do
        local p=o.representative
        if o.status=="READY" and p and o.vehicleIds then
            local distance=(x-p.x)^2+(y-p.y)^2+(z-p.z)^2
            if distance<best then nearest=o;best=distance end
        end
    end
    return nearest
end

function H:interact()
    local o=self:nearby();if not o then return end
    self.pending={id=o.id,farmId=o.farmId}
    YesNoDialog.show(self.confirm,self,string.format("Complete handover of %s (D-%d) and pay %s?\n\nAny accrued handover charge will also be settled. Payment can take your account into unauthorised overdraft: 39%% annual interest plus %s per game day.",o.name,o.id,money(o.payable-o.deposit),money(10)),"Dealer handover")
end

function H:confirm(yes)
    local p=self.pending;self.pending=nil
    if not yes or not p then return end
    local _,message=self.dealer:collect(p.id,p.farmId)
    InfoDialog.show(message)
end

function H:registerInteraction()
    if not g_localPlayer or not g_inputBinding or not PlayerInputComponent or not InputAction or not InputAction.RFF_DEALER_HANDOVER then return end
    -- Shop/vehicle contexts are transient. Always register in native on-foot
    -- controls, and recover if a controls reload removed the previous event.
    if self.actionId and g_inputBinding.events[self.actionId] then return end
    self.actionId=nil
    g_inputBinding:beginActionEventsModification(PlayerInputComponent.INPUT_CONTEXT_NAME)
    local ok,id=g_inputBinding:registerActionEvent(InputAction.RFF_DEALER_HANDOVER,self,self.interact,false,true,false,false)
    g_inputBinding:endActionEventsModification()
    if ok then
        self.actionId=id
        g_inputBinding:setActionEventTextPriority(id,GS_PRIO_HIGH)
    end
end

function H:update(dt)
    if not self.alive or not self.dealer.repository.loaded or not mission():getIsServer() then return end
    if mission().missionDynamicInfo and mission().missionDynamicInfo.isMultiplayer then return end
    self.timer=self.timer-(dt or 0);if self.timer>0 then return end;self.timer=500
    self:registerInteraction()
    for _,o in ipairs(self.dealer:state().orders) do
        if o.status=="READY" then
            if not o.vehicleIds then
                local r=self.runtime[o.id] or {};self.runtime[o.id]=r
                r.retry=(r.retry or 0)-500
                if r.retry<=0 and self.loading==nil then r.retry=10000;self:stage(o) end
            else
                local vehicles=self:vehicles(o)
                if vehicles then
                    local r=self.runtime[o.id] or {settle=2000};self.runtime[o.id]=r
                    r.settle=(r.settle or 0)-500
                    if not o.deliveryOrigins and r.settle<=0 then self:positionRepresentative(o,vehicles) end
                    if o.deliveryOrigins and o.useStartedHour==nil then
                        for i,v in ipairs(vehicles) do
                            local p=o.deliveryOrigins[i];local x,_,z=vehiclePosition(v)
                            if x and p and (x-p.x)^2+(z-p.z)^2>self.MOVEMENT_METRES^2 then
                                o.useStartedHour=self:hour()
                                if mission().addIngameNotification and FSBaseMission then
                                    mission():addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO,
                                        "D-"..o.id..": handover outstanding. "..money(25).." per game hour now applies until handover, including while parked.")
                                end
                                break
                            end
                        end
                    end
                    self:accrue(o,false)
                    self:createNPC(o,r)
                    self:startIdle(r)
                    if r.visible and r.model then r.model:setVisibility(true) end
                end
            end
        end
    end
    if self.actionId then
        local o=self:nearby()
        g_inputBinding:setActionEventActive(self.actionId,o~=nil)
        g_inputBinding:setActionEventTextVisibility(self.actionId,o~=nil)
        if o then g_inputBinding:setActionEventText(self.actionId,"Handover D-"..o.id.." - "..o.name) end
    end
end

function H:collect(o)
    if o.status~="READY" then return false,"This order is not ready for handover." end
    local vehicles=self:vehicles(o)
    if not vehicles then return false,"The delivery vehicle is not available yet. Wait for delivery space, or restore a missing vehicle mod. No payment was taken." end
    -- Never retry a partially failed financial handover automatically.
    o.status="COLLECTING"
    local ok,err=pcall(function()
        self:accrue(o,true)
        local finance=o.payload.finance
        if finance then
            local agreement=self.dealer.manager.assetFinance:createAgreementFromPurchase(finance,vehicles[1])
            if not agreement then error("Finance agreement could not be created") end
        end
        self.dealer:money(o.farmId,o.deposit,"Dealer deposit applied at handover D-"..o.id)
        self.dealer.repository:setNextTransactionDescription(o.farmId,"Dealer handover D-"..o.id.." - "..o.name)
        mission():addMoney(-o.payable,o.farmId,o.lease and MoneyType.LEASING_COSTS or MoneyType.SHOP_VEHICLE_BUY,true,true)
        for _,v in ipairs(vehicles) do
            v.propertyState=o.lease and VehiclePropertyState.LEASED or VehiclePropertyState.OWNED
            if o.lease then mission():addLeasedItem(v) else mission():addOwnedItem(v) end
            if not o.lease and self.dealer.manager.fleetManagement then self.dealer.manager.fleetManagement:grantDealershipCover(o.farmId,v) end
        end
    end)
    if not ok then
        o.status="REVIEW";o.ads="Interrupted financial handover. Inspect the log/save before recovery."
        self:removeNPC(o.id)
        print("[RFF dealer] Handover D-"..o.id.." requires review: "..tostring(err))
        return false,"Handover needs review. Do not retry; check the log. The order has been retained to prevent a duplicate charge."
    end
    self:removeNPC(o.id)
    self.dealer:onCollected(vehicles,VehicleLoadingState.OK,o)
    return true,"Handover completed. Your machine is available; the remaining payment has been taken."
end

function H:cancel(o)
    if o.vehicleIds==nil then return true end
    local vehicles=self:vehicles(o)
    if not vehicles then return false,"The delivered vehicle is missing. Restore it before cancelling; no refund has been made." end
    for _,v in ipairs(vehicles) do
        local root=v.getRootVehicle and v:getRootVehicle() or v
        if (v.getIsEntered and v:getIsEntered()) or (root.getIsAIActive and root:getIsAIActive())
            or (v.getAttacherVehicle and v:getAttacherVehicle()) or (v.getAttachedImplements and #v:getAttachedImplements()>0) then
            return false,"Stop and leave the machine, stop any helper and detach equipment before cancelling."
        end
    end
    self:accrue(o,true)
    self:removeNPC(o.id)
    local ok=pcall(function() for _,v in ipairs(vehicles) do v:delete() end end)
    if not ok then
        o.status="REVIEW";o.ads="Cancellation interrupted. Check vehicle state before refund/recovery."
        return false,"Cancellation requires review. No reservation refund has been made."
    end
    return true
end

function H:delete()
    self.alive=false
    if self.actionId and g_inputBinding then g_inputBinding:removeActionEvent(self.actionId) end
    local ids={};for id in pairs(self.runtime) do ids[#ids+1]=id end
    for _,id in ipairs(ids) do self:removeNPC(id) end
    -- Delivery vehicles are saved by GIANTS. Do not delete them on map exit.
end
