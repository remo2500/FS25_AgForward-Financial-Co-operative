-- Original RFF demo-day implementation. Native field polygons and saved vehicles.
RFF_DemoDayService={}
local S=RFF_DemoDayService;S.__index=S
S.DISCOUNT=.05;S.LATE_RATE=25
S.BRANDS={"CASEIH","JOHNDEERE","FENDT","MASSEYFERGUSON","DEUTZFAHR"}
S.BRAND_LABELS={CASEIH="Case IH",JOHNDEERE="John Deere",FENDT="Fendt",MASSEYFERGUSON="Massey Ferguson",DEUTZFAHR="Deutz-Fahr"}
S.CULTIVATOR="data/vehicles/amazone/cenio4000/cenio4000.xml"
local function m() return g_currentMission end
local function round(n) return math.floor(n*100+.5)/100 end
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<math.huge end
local function pos(v)
    local node=v and v.rootNode
    if not node or node==0 or not entityExists(node) then return nil end
    return getWorldTranslation(node)
end
function S.new(manager)
    local self=setmetatable({manager=manager,dealer=manager.dealership,timer=0,alive=true,bound=setmetatable({},{__mode="k"})},S)
    manager.dealership.demo=self
    return self
end
function S:state()
    local d=self.dealer:state()
    d.demo=d.demo or {enabled=false,farmlandId=0,nextPeriod=0,serial=0}
    return d.demo
end
function S:time() return self.dealer:clock() end
function S:days() return math.max(1,m().environment.daysPerPeriod or 1) end
function S:at(e,h) return e.period+(math.min(e.day,self:days())-1+h/24)/self:days() end
function S:hour() return self.manager.dealerHandover:hour() end
function S:event() return self:state().event end
function S:live(e) return e and (e.status=="OPEN" or e.status=="RETURNING") end
function S:open(e) return e and e.status=="OPEN" and self:time()>=self:at(e,10) and self:time()<self:at(e,16) end
function S:screen(text)
    m():addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO,"RFF Demo Day: "..text)
end
function S:notify(e,title,text)
    if RFF_NotificationService and RFF_NotificationService.send then
        pcall(RFF_NotificationService.send,RFF_NotificationService,e.farmId,"RFF Dealership",title,
            "DEMO-"..e.id.." | "..e.brand.."\n"..text,"dealership",title..". View dealership Demo Days.",false)
    end
end
function S:date(e) return self.dealer:date(self:at(e,10)) end
function S:field(id) return g_fieldManager and g_fieldManager:getFieldById(id) end
function S:eligibleField(id)
    -- Demo permission is not a purchase or tenancy offer. Never consult Farmland
    -- Market's listing/negotiation flags here; retain native ownership safeguards.
    local f=self:field(id)
    if not f or not f.farmland then return nil,"The nominated field is missing." end
    if f:getHasOwner() then return nil,"The nominated field is no longer NPC-owned." end
    if f.grassMissionOnly then return nil,"The nominated field is grass-only." end
    if f.currentMission~=nil then return nil,"The nominated field is reserved for a contract." end
    if m().growthSystem and m().growthSystem:getIsGrowingInProgress() then return nil,"Field growth is currently being updated." end
    local polygon=f:getDensityMapPolygon()
    if not polygon or #polygon.pointsX<3 then return nil,"The nominated field has no usable boundary." end
    if (g_fieldManager.fieldNumUpdateTasks[f] or 0)>0 then return nil,"The nominated field is currently being updated." end
    for _,t in ipairs(self.manager.repository.tenancies or {}) do
        if t.status~="TERMINATED" and t.status~="EXPIRED" and t.status~="CANCELLED" then
            for _,land in ipairs(t.farmlandIds or {t.farmlandId}) do if land==id then return nil,"The nominated field has a tenancy commitment." end end
        end
    end
    -- Check the whole mission list too, including reserved/unstarted contracts.
    for _,mission in pairs(g_missionManager and g_missionManager.missions or {}) do
        if mission.field==f then return nil,"The nominated field is in the contract register." end
    end
    return f
end
function S:choices()
    local choices={};local sx,sz=0,0
    local shop=m().storeSpawnPlaces and m().storeSpawnPlaces[1]
    if shop then sx=shop.startX or 0;sz=shop.startZ or 0 end
    for _,f in ipairs(g_fieldManager:getFields()) do
        local id=f:getId()
        if self:eligibleField(id) then
            local x,z=f:getCenterOfFieldWorldPosition()
            choices[#choices+1]={id=id,distance=math.sqrt((x-sx)^2+(z-sz)^2),name=f:getName()}
        end
    end
    table.sort(choices,function(a,b) return a.distance<b.distance end)
    return choices
end
function S:lineup(brand)
    local buckets={TRACTORSS={},TRACTORSM={},TRACTORSL={}};local rest={};local selected={};local seen={}
    for _,item in ipairs(g_storeManager:getItems()) do
        local b=buckets[RFF_DealershipService.categoryName(item)]
        if b and RFF_DealershipService.brandName(item)==brand and self.dealer:eligible(item) and not seen[item.xmlFilename] then
            seen[item.xmlFilename]=true;b[#b+1]=item
        end
    end
    local function cheaper(a,b) if a.price==b.price then return a.xmlFilename<b.xmlFilename end;return a.price<b.price end
    for _,name in ipairs({"TRACTORSS","TRACTORSM","TRACTORSL"}) do
        local list=buckets[name];table.sort(list,cheaper)
        if #list>0 then selected[#selected+1]=table.remove(list,math.ceil(#list/2)) end
        for _,item in ipairs(list) do rest[#rest+1]=item end
    end
    table.sort(rest,cheaper)
    if #rest>0 and #selected<5 then selected[#selected+1]=table.remove(rest,1) end
    if #rest>0 and #selected<5 then selected[#selected+1]=table.remove(rest,#rest) end
    while #rest>0 and #selected<5 do selected[#selected+1]=table.remove(rest,1) end
    local rows={}
    for _,item in ipairs(selected) do
        local configs=RFF_DealershipService.resolveConfigurations(item,RFF_DealershipService.defaultConfigurations(item))
        if configs then rows[#rows+1]={xml=item.xmlFilename,name=item.name or "Tractor",configs=configs,status="PENDING"} end
    end
    return rows
end
function S:brandLabel(brand) return S.BRAND_LABELS[brand] or brand end
function S:rotationIndex()
    local s=self:state()
    if s.nextBrandIndex==nil then
        s.nextBrandIndex=1
        for i,brand in ipairs(S.BRANDS) do
            if s.event and s.event.brand==brand then s.nextBrandIndex=i%#S.BRANDS+1;break end
        end
    end
    return s.nextBrandIndex
end
function S:addCultivator(e)
    for _,row in ipairs(e.rows) do if row.xml==S.CULTIVATOR then row.role="IMPLEMENT";return true end end
    if #e.rows>=6 then return false end
    local item=g_storeManager:getItemByXMLFilename(S.CULTIVATOR)
    if not item then return false end
    local configs=RFF_DealershipService.resolveConfigurations(item,RFF_DealershipService.defaultConfigurations(item))
    if not configs then return false end
    e.rows[#e.rows+1]={xml=S.CULTIVATOR,name="Amazone Cenio 4000 Super",configs=configs,status="PENDING",role="IMPLEMENT"}
    return true
end
function S:schedule()
    local s=self:state()
    if not s.enabled or not self.dealer:active() or self:time()<(s.nextPeriod or 0) then return end
    local e=s.event
    if e and (e.status=="ANNOUNCED" or self:live(e) or e.status=="REVIEW" or e.status=="PREPARING") then return end
    if self:hasOutstanding(e) then return end
    if not self:eligibleField(s.farmlandId) then return end
    local index=self:rotationIndex();local brand,rows
    -- Skip brands without usable tractors on this installation, without consuming
    -- a rotation slot when no invitation can be issued.
    for offset=0,#S.BRANDS-1 do
        local candidate=(index+offset-1)%#S.BRANDS+1
        local lineup=self:lineup(S.BRANDS[candidate])
        if #lineup>0 then index=candidate;brand=S.BRANDS[candidate];rows=lineup;break end
    end
    if not rows then return end
    local tractorCount=#rows
    local equipment={rows=rows};if not self:addCultivator(equipment) then return end
    s.serial=s.serial+1
    e={id=s.serial,brand=brand,farmlandId=s.farmlandId,farmId=m():getFarmId(),period=self:nextEventPeriod(),
        day=e and e.day or m().environment.currentDayInPeriod or 1,status="ANNOUNCED",rows=rows}
    s.event=e;s.nextPeriod=e.period+2;s.cadenceVersion=2
    s.nextBrandIndex=index%#S.BRANDS+1
    self:notify(e,"Demo day invitation",self:date(e).." - 16:00. Farmland "..e.farmlandId..". Up to "..tractorCount.." tractors plus an Amazone Cenio 4000 Super; 5% off new "..self:brandLabel(e.brand).." purchases ordered during the event. Plough/cultivator work only. Return and detach all demo equipment by 17:00; moved machines retained after that cost 25 per game hour each.")
end
-- Events are dealer-led. The next invitation is one month before the next
-- three-month slot; missed quarters are skipped, never replayed in a burst.
function S:nextEventPeriod()
    local now=math.floor(self:time());local e=self:event()
    local period=e and e.period+3 or now+1
    if period<=now then period=period+(math.floor((now-period)/3)+1)*3 end
    return period
end
function S:nextEventDate()
    local e=self:event()
    return self:date({period=self:nextEventPeriod(),day=e and e.day or m().environment.currentDayInPeriod or 1})
end
function S:hasOutstanding(e)
    for _,r in ipairs(e and e.rows or {}) do
        if r.status=="READY" or r.status=="LOADING" or r.status=="REVIEW" or r.status=="RETURNING"
            or (#(r.ids or {})>0 and r.status~="RETURNED") then return true end
    end
    return false
end
function S:setEnabled(enabled)
    if not self.dealer:available() or not self:validate() then return end
    local s=self:state();s.enabled=enabled==true
    if not s.enabled and s.event then
        if s.event.status=="ANNOUNCED" then s.event.status="CANCELLED";s.event.cancelReason="Demo invitations were disabled."
        elseif s.event.status=="OPEN" then
            s.event.status="RETURNING";self:screen("Demo day disabled. Field work and offers have ended; return all demo machines by 17:00.")
        end
    end
    self:schedule()
end
function S:canChooseField()
    local e=self:event()
    return not e or (e.status~="ANNOUNCED" and not self:live(e) and e.status~="REVIEW" and e.status~="PREPARING")
end
function S:chooseField(id)
    if not self.dealer:available() or not self:validate() or not self:canChooseField() or not self:eligibleField(id) then return false end
    self:state().farmlandId=id
    return true
end
function S:returnAvailable()
    local e=self:event();local count=0
    if self.dealer:available() and self:validate() and e then
        for _,r in ipairs(e.rows) do if r.status=="READY" and self:returnRow(r) then count=count+1 end end
    end
    return count
end
function S:inside(e,x,z)
    if g_farmlandManager:getFarmlandIdAtWorldPosition(x,z)~=e.farmlandId then return false end
    local f=self:field(e.farmlandId);if not f then return false end
    local p=f:getDensityMapPolygon();local inside=false;local j=#p.pointsX
    for i=1,#p.pointsX do
        local xi,zi=p.pointsX[i],p.pointsZ[i];local xj,zj=p.pointsX[j],p.pointsZ[j]
        if (zi>z)~=(zj>z) and x<(xj-xi)*(z-zi)/(zj-zi)+xi then inside=not inside end;j=i
    end
    return inside
end
function S:prepare(e)
    local f,reason=self:eligibleField(e.farmlandId)
    if not f then return false,(reason or "The nominated field is unavailable.").." Nothing was cleared." end
    -- Restrict to existing field ground AND this farmland, inside the native field
    -- polygon. No ownership writes, terrain painting, dropped cargo or height edits.
    local task=FieldUpdateTask.new();task:setField(f)
    local map,first,count=m().fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
    local ground=DensityMapFilter.new(map,first,count)
    ground:setValueCompareParams(DensityValueCompareType.GREATER,0)
    local land=DensityMapFilter.new(g_farmlandManager:getLocalMap(),0,g_farmlandManager.numberOfBits)
    land:setValueCompareParams(DensityValueCompareType.EQUAL,e.farmlandId)
    task:addFilter(ground);task:addFilter(land)
    task:setFruit(FruitType.UNKNOWN,0);task:setGroundType(FieldGroundType.HARVEST_READY)
    task:setWeedState(0);task:setPlowLevel(0)
    e.status="PREPARING" -- never silently replay a partial terrain operation
    g_fieldManager:addFieldUpdateTask(task,true)
    e.prepared=true;e.status="OPEN"
    return true
end
function S:record(v)
    if not v then return nil end
    local e=self:event()
    if e then for _,r in ipairs(e.rows) do
        for _,id in ipairs(r.ids or {}) do if v.uniqueId==id and r.status~="RETURNED" then return r,e end end
    end end
end
function S:rootRecord(v)
    local root=v and v.getRootVehicle and v:getRootVehicle() or v
    local r,e=self:record(root)
    if r then return r,e end
    -- A supplied implement retains demo restrictions even on a player tractor.
    return self:record(v)
end
function S:demoTractor(v)
    local root=v and v.getRootVehicle and v:getRootVehicle() or v
    local r=self:record(root)
    return r~=nil and r.role~="IMPLEMENT" and r.xml~=S.CULTIVATOR
end
function S:vehicles(r)
    local result={}
    for _,id in ipairs(r.ids or {}) do
        local v=m().vehicleSystem:getVehicleByUniqueId(id)
        if not v or v.isDeleted or v.propertyState~=VehiclePropertyState.MISSION or v.ownerFarmId~=self:event().farmId then return nil end
        result[#result+1]=v
    end
    return #result>0 and result or nil
end
function S:loadRow(e,r)
    if self.loading or self.manager.dealerHandover.loading then return end
    local item=g_storeManager:getItemByXMLFilename(r.xml)
    if not item then r.status="UNAVAILABLE";return end
    if not m().slotSystem:hasEnoughSlots(item) or not m().storeSpawnPlaces then return end
    local load=VehicleLoadingData.new();load:setStoreItem(item);load:setConfigurations(RFF_DealershipService.copy(r.configs))
    load:setPropertyState(VehiclePropertyState.MISSION);load:setOwnerFarmId(e.farmId)
    load:setLoadingPlace(m().storeSpawnPlaces,m().usedStorePlaces)
    r.status="LOADING";self.loading=r
    local ok=pcall(load.load,load,self.onLoaded,self,{event=e,row=r})
    if not ok then self.loading=nil;r.status="REVIEW" end
end
function S:onLoaded(vehicles,state,c)
    self.loading=nil;if not self.alive then return end
    local r,e=c.row,c.event
    if r.status~="LOADING" then return end
    if not vehicles or #vehicles==0 then r.status="UNAVAILABLE";return end
    r.ids={}
    for _,v in ipairs(vehicles) do
        if not v.uniqueId then r.status="REVIEW";return end
        r.ids[#r.ids+1]=v.uniqueId;v.isVehicleSaved=true;self:bind(v)
    end
    if state~=VehicleLoadingState.OK then r.status="REVIEW";return end
    r.status="READY";r.settleHour=self:hour()+2/3600
    self:screen(r.name.." is ready at the dealer. Free trial until 16:00; plough/cultivator only on farmland "..e.farmlandId..".")
end
function S:allowedWork(v,area)
    local r,e=self:rootRecord(v);if not r then return true end
    if not self:demoTractor(v) or not self:open(e) or not self:eligibleField(e.farmlandId) then return false end
    if not area or not area.start or not area.width or not area.height then return false end
    local ax,_,az=getWorldTranslation(area.start);local bx,_,bz=getWorldTranslation(area.width);local cx,_,cz=getWorldTranslation(area.height)
    -- Reject straddling work areas, not just an implement's centre point.
    for i=0,4 do for j=0,4 do
        if not self:inside(e,ax+(bx-ax)*i/4+(cx-ax)*j/4,az+(bz-az)*i/4+(cz-az)*j/4) then return false end
    end end
    return true
end
function S:workAccess(vehicle,farmId,x,z,kind)
    local r,e=self:rootRecord(vehicle)
    local permitted=kind~=nil and (kind==WorkAreaType.CULTIVATOR or kind==WorkAreaType.PLOW or kind==WorkAreaType.PLOWSHARE)
    return r~=nil and self:demoTractor(vehicle) and permitted and self:open(e) and farmId==e.farmId
        and self:eligibleField(e.farmlandId)~=nil and self:inside(e,x,z)
end
function S:bind(v)
    if self.bound[v] then return end;self.bound[v]=true
    local function wrap(name,fn)
        local old=v[name];if old then v[name]=function(vehicle,...) return fn(vehicle,old,...) end end
    end
    wrap("getIsAccessibleAtWorldPosition",function(vehicle,old,farmId,x,z,kind)
        local r,e=self:rootRecord(vehicle)
        if r then
            return self:workAccess(vehicle,farmId,x,z,kind),FarmlandManager.NO_OWNER_FARM_ID,true
        end
        return old(vehicle,farmId,x,z,kind)
    end)
    for _,name in ipairs({"processPlowArea","processPlowShareArea","processCultivatorArea","processVineCultivatorArea"}) do
        wrap(name,function(vehicle,old,area,...)
            if not self:allowedWork(vehicle,area) then return 0,0 end
            local spec=vehicle.spec_plow or vehicle.spec_cultivator
            if self:rootRecord(vehicle) and spec and spec.workAreaParameters then
                local previous=spec.workAreaParameters.limitToField
                spec.workAreaParameters.limitToField=true
                local ok,changed,total=pcall(old,vehicle,area,...)
                spec.workAreaParameters.limitToField=previous
                if not ok then error(changed) end
                return changed,total
            end
            return old(vehicle,area,...)
        end)
    end
    -- WorkArea caches these callbacks while loading: refresh them to the guarded
    -- instance functions, otherwise later wrapping would leave a bypass.
    for _,area in ipairs(v.spec_workArea and v.spec_workArea.workAreas or {}) do
        if area.functionName and v[area.functionName] then area.processingFunction=v[area.functionName] end
    end
    wrap("isAttachAllowed",function(vehicle,old,farmId,tractor)
        local own=self:record(vehicle)
        if own and own.role=="IMPLEMENT" and not self:demoTractor(tractor) then return false,nil end
        local item=g_storeManager:getItemByXMLFilename(vehicle.configFileName)
        local weight=item and RFF_DealershipService.categoryName(item)=="WEIGHTS"
        if self:rootRecord(tractor) and not ((vehicle.spec_plow or vehicle.spec_cultivator or weight) and not vehicle.spec_sowingMachine) then return false,nil end
        return old(vehicle,farmId,tractor)
    end)
    for _,name in ipairs({"getCanStartAIVehicle","getCanStartFieldWork","getCanBeSold","getCanBeReset"}) do
        wrap(name,function(vehicle,old,...)
            if self:rootRecord(vehicle) then return false end
            return old(vehicle,...)
        end)
    end
    wrap("getName",function(vehicle,old,...)
        if self:record(vehicle) then return "DEMO - "..old(vehicle,...) end
        return old(vehicle,...)
    end)
end
function S:charge(r,final)
    if not r.moved or not r.lateStart then return end
    local elapsed=math.max(0,self:hour()-r.lateStart)
    local total=math.floor((final and elapsed or math.floor(elapsed+.000001))*S.LATE_RATE*100+.5)
    local amount=(total-(r.charged or 0))/100
    if amount>0 then
        r.charged=total
        self.manager.repository:setNextTransactionDescription(self:event().farmId,"Overdue demo machine - "..r.name)
        m():addMoney(-amount,self:event().farmId,MoneyType.OTHER,true,true)
    end
end
function S:returnRow(r)
    local vehicles=self:vehicles(r);if not vehicles then return false end
    for _,v in ipairs(vehicles) do
        if (v.getIsEntered and v:getIsEntered()) or (v.getIsAIActive and v:getIsAIActive())
            or (v.getAttacherVehicle and v:getAttacherVehicle()) or (v.getAttachedImplements and #v:getAttachedImplements()>0) then return false end
    end
    self:charge(r,true);r.status="RETURNING"
    for _,v in ipairs(vehicles) do v:delete() end
    r.status="RETURNED";return true
end
function S:discount(item,price)
    local e=self:event()
    if self.dealer:active() and self:open(e) and RFF_DealershipService.brandName(item)==e.brand and self.dealer:eligible(item) then
        return round(price*(1-S.DISCOUNT)),true
    end
    return price,false
end
function S:validate()
    local s=self:state();if self.checked==s then return true end
    local valid=type(s.enabled)=="boolean" and finite(s.farmlandId) and finite(s.nextPeriod) and finite(s.serial)
    if s.nextBrandIndex~=nil then valid=valid and finite(s.nextBrandIndex) and s.nextBrandIndex%1==0 and s.nextBrandIndex>=1 and s.nextBrandIndex<=#S.BRANDS end
    local e=s.event
    if e then
        valid=valid and type(e)=="table" and finite(e.period) and finite(e.day) and e.day>=1 and finite(e.farmId)
            and finite(e.farmlandId) and finite(e.id) and type(e.brand)=="string" and type(e.rows)=="table" and #e.rows<=6
        local tractors,implements=0,0
        if valid then for _,r in ipairs(e.rows) do
            if type(r)~="table" then valid=false;break end
            valid=valid and type(r.xml)=="string" and type(r.name)=="string" and type(r.configs)=="table" and type(r.status)=="string"
            valid=valid and (r.role==nil or (r.role=="IMPLEMENT" and r.xml==S.CULTIVATOR))
            if r.xml==S.CULTIVATOR then implements=implements+1 else tractors=tractors+1 end
            if r.ids then
                if type(r.ids)~="table" then valid=false;break end
                for _,id in ipairs(r.ids) do valid=valid and type(id)=="string" end
            end
            if r.origin then valid=valid and type(r.origin)=="table" and finite(r.origin.x) and finite(r.origin.y) and finite(r.origin.z) end
            for _,key in ipairs({"lateStart","charged","settleHour"}) do if r[key]~=nil then valid=valid and finite(r[key]) and r[key]>=0 end end
            if r.status=="LOADING" or r.status=="RETURNING" then r.status="REVIEW" end
        end end
        valid=valid and tractors<=5 and implements<=1
        if valid and e.status=="PREPARING" then e.status="REVIEW" end
    end
    if not valid then self.invalid=true;return false end
    -- Migrate the old annual invitation wait without moving an announced event,
    -- respawning tractors or revisiting previously prepared ground.
    if s.cadenceVersion~=2 then
        s.nextPeriod=e and e.period+2 or 0;s.cadenceVersion=2
    end
    self.checked=s;return true
end
function S:update(dt)
    if not self.alive or not self.dealer:available() or not self:validate() then return end
    self.timer=self.timer-(dt or 0);if self.timer>0 then return end;self.timer=1000
    -- FS25 moved the authoritative list into VehicleSystem. Looking at the old
    -- mission.vehicles silently skipped all player implements and reloaded demos.
    local system=m().vehicleSystem
    for _,v in ipairs(system and system.vehicles or m().vehicles or {}) do self:bind(v) end
    self:schedule();local e=self:event();if not e then return end
    -- Upgrade ongoing legacy demos without replacing tractors, changing the
    -- advertised brand/date or clearing the field again. Persisted rows prevent duplicates.
    if e.status=="ANNOUNCED" or self:open(e) then self:addCultivator(e) end
    local now=self:time()
    if e.status=="ANNOUNCED" then
        if now>=self:at(e,16) then e.status="MISSED";self:notify(e,"Demo day missed","The event has ended. No crops or vehicles were changed. The dealership will invite you to the next quarterly event, subject to venue availability.");return end
        if not e.reminded and now>=self:at(e,0)-1/self:days() and now<self:at(e,10) then
            e.reminded=true;self:notify(e,"Demo day reminder",self:date(e).." - 16:00, farmland "..e.farmlandId..". 5% off featured-brand purchases.")
        end
        if now>=self:at(e,10) then
            local ok,result,reason=pcall(self.prepare,self,e)
            if not ok or not result then
                e.status=ok and "CANCELLED" or "REVIEW"
                e.cancelReason=reason or tostring(result)
                print(string.format("[RFF demo] Event %s field %s %s: %s",tostring(e.id),tostring(e.farmlandId),e.status,e.cancelReason))
                self:notify(e,"Demo day unavailable",e.cancelReason..(ok and " Choose an available field in the dealership page for the next quarterly event." or " Review is required before another event can be arranged."));return
            end
            self:screen("Open until 16:00. Demo field "..e.farmlandId.." prepared; tractors are arriving at the dealer.")
        end
    end
    if not self:live(e) then return end
    if self:open(e) and not e.warned and now>=self:at(e,15.5) then e.warned=true;self:screen("Closes at 16:00. Please return tractors and cultivator, detach all implements and leave the cab by 17:00.") end
    if e.status=="OPEN" and (now>=self:at(e,16) or not self.dealer:active() or not self:eligibleField(e.farmlandId)) then
        e.status="RETURNING";self:screen("Demonstration work and discount have ended. Return by 17:00; overdue moved machines cost 25 per game hour each. Detach all implements before collection.")
    end
    local remaining=false
    for _,r in ipairs(e.rows) do
        if r.status=="PENDING" and self:open(e) then self:loadRow(e,r) end
        if r.status=="READY" then
            remaining=true;local vehicles=self:vehicles(r)
            if vehicles then
                local v=vehicles[1];local x,y,z=pos(v)
                if x and not r.origin and self:hour()>=(r.settleHour or 0) then r.origin={x=x,y=y,z=z} end
                if x and r.origin and (x-r.origin.x)^2+(z-r.origin.z)^2>100 then r.moved=true end
                if v.getIsAIActive and v:getIsAIActive() and v.stopCurrentAIJob then v:stopCurrentAIJob(AIMessageErrorUnknown.new()) end
                if e.status=="RETURNING" then
                    if now>=self:at(e,17) and not r.lateStart then
                        r.lateStart=self:hour()-math.max(0,(now-self:at(e,17))*self:days()*24)
                    end
                    self:charge(r,false)
                    local atDealer=x and r.origin and (x-r.origin.x)^2+(z-r.origin.z)^2<900
                    if not r.moved or atDealer then self:returnRow(r) end
                end
            end
        elseif r.status=="LOADING" or r.status=="REVIEW" or r.status=="RETURNING" then remaining=true end
    end
    if e.status=="RETURNING" and not remaining then e.status="CLOSED";self:notify(e,"Demo day complete","Thank you for attending. All demo machines have been returned.") end
end
function S:status()
    local s=self:state();local e=s.event
    if not e then return "No demo event announced.\nInvitations: "..(s.enabled and "On" or "Off").."\nDemo field: "..(s.farmlandId>0 and tostring(s.farmlandId) or "Not selected") end
    local rows={self:brandLabel(e.brand).." Demo Day",self:date(e).." - 16:00", "Demo field: "..e.farmlandId,"Status: "..e.status,"Return by 17:00 | 5% off new "..self:brandLabel(e.brand).." purchases during the event.","\nEquipment:"}
    for _,r in ipairs(e.rows) do rows[#rows+1]=r.name.." - "..r.status end
    if e.cancelReason then rows[#rows+1]="\nReason: "..e.cancelReason end
    if e.status=="MISSED" or e.status=="CANCELLED" or e.status=="CLOSED" then
        rows[#rows+1]="\nNext scheduled window: "..self:nextEventDate()
    end
    return table.concat(rows,"\n")
end
function S:console(command)
    command=string.upper(command or "STATUS")
    if command=="TOMORROW" then
        local e=self:event()
        if not e or e.status~="ANNOUNCED" then return "First enable demo days and nominate a field in dealership options." end
        e.day=(m().environment.currentDayInPeriod or 1)+1;e.period=math.floor(self:time())
        if e.day>self:days() then e.day=1;e.period=e.period+1 end
        self:state().nextPeriod=e.period+2
        e.reminded=nil;self:notify(e,"TEST: demo rescheduled",self:date(e).." - 16:00. The nominated field crop will be cleared at opening.")
    end
    return self:status()
end
function S:delete() self.alive=false end
function S.install()
    if S.installed then return end;S.installed=true
    local function service() return RFF_RealisticFarmFinance.manager and RFF_RealisticFarmFinance.manager.demoDays end
    -- Native WorkArea's network-area check does not call the vehicle's access
    -- method. Its mission-work fallback carries the exact implement and work type,
    -- unlike broad farm access. Grant only the demo combination's tillage work;
    -- never transfer title or grant construction, sale, harvest or other-farm access.
    if MissionManager and MissionManager.getIsMissionWorkAllowed then
        MissionManager.getIsMissionWorkAllowed=Utils.overwrittenFunction(MissionManager.getIsMissionWorkAllowed,function(manager,old,farmId,x,z,kind,vehicle)
            local s=service()
            if s and s:rootRecord(vehicle) then return s:workAccess(vehicle,farmId,x,z,kind) end
            return old(manager,farmId,x,z,kind,vehicle)
        end)
    end
    local function reserved(field,includeInvitation)
        local s=service();local e=s and s:event()
        return e and field and field:getId()==e.farmlandId and (s:open(e) or (includeInvitation and e.status=="ANNOUNCED"))
    end
    FieldManager.getIsFieldReadyForMission=Utils.overwrittenFunction(FieldManager.getIsFieldReadyForMission,function(manager,old,field)
        if reserved(field,true) then return false end;return old(manager,field)
    end)
    FieldManager.getFieldForMission=Utils.overwrittenFunction(FieldManager.getFieldForMission,function(manager,old,...)
        local field=old(manager,...);if reserved(field,true) then return nil end;return field
    end)
    FieldManager.updateField=Utils.overwrittenFunction(FieldManager.updateField,function(manager,old,field)
        if reserved(field) then return end;return old(manager,field)
    end)
    ShopConfigScreen.getConfigurationCostsAndChanges=Utils.overwrittenFunction(ShopConfigScreen.getConfigurationCostsAndChanges,function(screen,old,item,vehicle,saleItem)
        local s=service()
        if s and vehicle and s:record(vehicle) then return 0,0,false end
        local base,upgrades,changed=old(screen,item,vehicle,saleItem)
        if s and not vehicle and not saleItem then
            local price,discount=s:discount(item,base+upgrades)
            if discount then return price-upgrades,upgrades,changed end
        end
        return base,upgrades,changed
    end)
end
