-- Original, deterministic, paid in-game interpretation of the farm's records.
-- Reports are immutable snapshots. No trading, refinancing or deposit actions are taken.
RFF_FinancialAdviserService={}
RFF_FinancialAdviserService.__index=RFF_FinancialAdviserService
local A=RFF_FinancialAdviserService
A.FEE=250
A.DELIVERY_DAYS=2
local function num(n) return type(n)=="number" and n==n and math.abs(n)<math.huge and n or 0 end
local function finite(n) return type(n)=="number" and n==num(n) end
local function money(n)
    if g_i18n~=nil and g_i18n.formatMoney~=nil then return g_i18n:formatMoney(n,0,true,true) end
    return string.format("%.0f",n)
end
local function server() return g_currentMission~=nil and g_currentMission:getIsServer() end
local function farm(id) return g_farmManager~=nil and g_farmManager:getFarmById(id) or nil end
local function direction(delta)
    if delta>.24 then return "higher" elseif delta<-.24 then return "lower" end
    return "broadly unchanged"
end
local RUNNING={wagePayment=true,purchaseSeeds=true,purchaseFertilizer=true,purchaseFuel=true,purchaseSaplings=true,
    purchaseWater=true,purchaseBales=true,purchasePallets=true,purchaseConsumable=true,animalUpkeep=true,
    vehicleRunningCost=true,propertyMaintenance=true,productionCosts=true}
function A.new(manager)
    return setmetatable({manager=manager,repository=manager.repository},A)
end
function A:records(farmId)
    local list={}
    for _,r in ipairs(self.repository.adviserReports or {}) do if r.farmId==farmId then list[#list+1]=r end end
    return list
end
function A:lastId(farmId)
    local id=0;for _,r in ipairs(self:records(farmId)) do id=math.max(id,r.id) end;return id
end
function A:clock()
    local e=g_currentMission and g_currentMission.environment
    if e==nil or not finite(e.currentMonotonicDay) or not finite(e.dayTime) then return nil end
    return e.currentMonotonicDay+e.dayTime/86400000
end
function A:pending(farmId)
    for _,r in ipairs(self:records(farmId)) do if r.status=="PENDING" then return r end end
    return nil
end
function A:quote(farmId)
    if not self.repository.loaded or self.repository.economyState==nil or farm(farmId)==nil or farmId<=0 or self:clock()==nil or self:pending(farmId)~=nil then return nil end
    return {farmId=farmId,fee=self.FEE,period=self.repository:getCurrentPeriodIndex(),previousId=self:lastId(farmId)}
end
-- Optional read-only provider readings. Missing values are not presented as zero.
function A:redTape(farmId)
    local rt=g_currentMission and g_currentMission.RedTape
    local result={provision=0}
    local tax={"RED TAPE: TAX BOOKS"}
    local function show(value) return finite(value) and money(value) or "Unavailable" end
    if type(rt)~="table" then
        result.tax="Red Tape is not active. Tax-book profit/loss and tax estimates are unavailable; this review still uses RFF's own recorded cash and commitments."
        result.grants="Red Tape is not active. Grant eligibility and awards are unavailable. No grant income has been assumed."
        return result
    end
    local ts=rt.TaxSystem
    if not (rt.settings and rt.settings.taxEnabled==true) then
        tax[#tax+1]="Red Tape taxation is disabled. Tax-book figures and estimates are unavailable."
    elseif type(ts)=="table" then
        local ok,s=false,nil
        if type(ts.getCurrentYearTaxToDate)=="function" then ok,s=pcall(ts.getCurrentYearTaxToDate,ts,farmId) end
        if ok and type(s)=="table" and s.farmId==farmId then
            tax[#tax+1]="Current tax year to date:\nRecorded taxable receipts: "..show(s.totalTaxableIncome).."\nDeductible expenses: "..show(s.totalExpenses)
            if finite(s.totalTaxableIncome) and finite(s.totalExpenses) then
                local profit=s.totalTaxableIncome-s.totalExpenses
                tax[#tax+1]="Tax-book "..(profit<0 and "loss: " or "surplus: ")..money(math.abs(profit)).." before income adjustments and loss relief. This is not a complete accounting profit/loss statement."
            end
            tax[#tax+1]="YTD tax estimate: "..show(s.totalTax)..". Rate: "..(finite(s.taxRate) and string.format("%.2f%%",s.taxRate*100) or "Unavailable").."."
            if finite(s.totalTax) then result.provision=math.max(0,s.totalTax) end
        else tax[#tax+1]="Year-to-date tax books could not be read. No zero-profit or zero-tax assumption has been made." end
        tax[#tax+1]="Recorded loss carry-forward: "..show(type(ts.lossRollover)=="table" and ts.lossRollover[farmId] or nil).."."
        if type(ts.taxStatements)=="table" then
            local unpaid,unknown=0,false
            for _,annual in pairs(ts.taxStatements) do
                if type(annual)=="table" and annual.farmId==farmId and annual.paid~=true then
                    if annual.paid==false and finite(annual.totalTax) then unpaid=unpaid+math.max(0,annual.totalTax) else unknown=true end
                end
            end
            result.provision=result.provision+unpaid
            tax[#tax+1]="Unpaid closed-year assessments: "..money(unpaid)..(unknown and " (some records incomplete)" or "")..". This known amount is also kept aside; it is separate from the current-year estimate."
        else tax[#tax+1]="Closed-year assessment records are unavailable; check whether an earlier tax bill remains payable." end
    else tax[#tax+1]="Tax provider is not ready; figures are unavailable." end
    tax[#tax+1]="The YTD estimate is provisional, not a charge, and may change. Both cash buffers include available tax allowances. RFF compliance penalties remain separate. Check Red Tape before filing or paying."
    result.tax=table.concat(tax,"\n\n")
    local gs=rt.GrantSystem
    local grants={"RED TAPE: GRANT OPPORTUNITIES"}
    if not (rt.settings and rt.settings.grantsEnabled==true) then
        grants[#grants+1]="Grants are disabled. No award income has been assumed."
    elseif type(gs)~="table" or type(gs.grants)~="table" then
        grants[#grants+1]="Grant records are not ready. No award income has been assumed."
    else
        local pending,approved,complete,amount,paid,unknown=0,0,0,0,0,false
        for _,g in pairs(gs.grants) do if type(g)=="table" and g.farmId==farmId then
            if g.status==1 then pending=pending+1
            elseif g.status==2 then approved=approved+1;if finite(g.amount) then amount=amount+math.max(0,g.amount) else unknown=true end
            elseif g.status==4 then complete=complete+1;if finite(g.amount) then paid=paid+math.max(0,g.amount) else unknown=true end end
        end end
        grants[#grants+1]=string.format("Pending applications: %d.\nApproved, awaiting qualifying purchase: %d (%s).\nCompleted awards in retained history: %d (%s).",pending,approved,unknown and "amounts incomplete" or money(amount),complete,unknown and "amounts incomplete" or money(paid))
        local ok,eligible=false,nil
        if type(gs.canFarmApplyForGrant)=="function" then ok,eligible=pcall(gs.canFarmApplyForGrant,gs,farmId) end
        if ok and type(eligible)=="boolean" then
            grants[#grants+1]=eligible and "Red Tape currently permits another application. If a qualifying building project is already planned, check its grant terms before purchasing. Eligibility is not approval; application costs and project conditions still apply."
                or "Another application is not currently available. Review your pending/approved award or Red Tape's cooldown before planning another."
        else grants[#grants+1]="New-application eligibility is unavailable; check Red Tape directly." end
        grants[#grants+1]="Do not buy an unnecessary building just to obtain a grant. Pending and approved awards are excluded from available cash. Completed awards are historical, not extra money to add again."
    end
    result.grants=table.concat(grants,"\n\n")
    return result
end
-- A conservative allocation, not an income forecast. Each pound is allocated once.
-- Keep six months accessible before suggesting a six-month or longer lock.
function A.plan(r,loans,assets,fixedRate)
    local monthly=math.max(0,r.commitments+r.admin+r.running)
    local balloons=0
    for _,loan in ipairs(loans) do
        if loan.type==RFF_LoanService.TYPE_BULLET and num(loan.remainingMonths)<=6 then balloons=balloons+math.max(0,num(loan.principal)) end
    end
    for _,a in ipairs(assets) do
        if a.status=="ACTIVE" and num(a.remainingMonths)<=6 then balloons=balloons+math.max(0,num(a.balloonAmount)) end
    end
    local p={reserve=6*monthly+r.billed+balloons+num(r.taxProvision),monthly=monthly,repay=0,short=0,long=0}
    p.gap=math.max(0,p.reserve-r.liquid)
    p.threeMonth=r.liquid-r.reserve
    -- Existing easy savings may support the buffer, but cannot fund a new action without withdrawal.
    p.available=math.max(0,math.min(r.cash,r.liquid-p.reserve))
    p.available=math.floor(p.available/100)*100
    if r.months>=3 and r.billed<=.01 and p.gap<=.01 then
        local eligible,rate=0,0
        for _,loan in ipairs(loans) do
            if not loan.paidOff and not loan.currentDefault and num(loan.arrearsBalance)<=.01
                and loan.type~=RFF_LoanService.TYPE_OVERDRAFT and num(loan.interestRate)>fixedRate then
                local balance=loan.type==RFF_LoanService.TYPE_REVOLVING and num(loan.drawnAmount) or num(loan.principal)
                if balance>0 then eligible=eligible+balance;rate=math.max(rate,num(loan.interestRate)) end
            end
        end
        p.debtRate=rate
        p.repay=math.floor(math.min(eligible,p.available*.5)/100)*100
        local remaining=p.available-p.repay
        p.short=math.min(10000000,math.floor(remaining*.5/100)*100)
        p.long=math.min(10000000,math.floor(remaining*.25/100)*100)
    end
    p.unallocated=p.available-p.repay-p.short-p.long
    return p
end
function A:recommend(r,loans,assets)
    local p=A.plan(r,loans,assets,self.manager.savings:rate("FIXED12"))
    local lines={"MY SUGGESTED NEXT STEPS",
        "Keep "..money(p.reserve).." accessible: six months of recorded outgoings, billed obligations, known bullet/balloon amounts due within six months and any Red Tape tax allowance. This is more cautious than the three-month starting reserve shown on the left."}
    if r.billed>.01 then
        lines[#lines+1]="Prioritise "..money(r.billed).." of billed obligations. Do not open new locked savings until these are dealt with."
    elseif p.gap>.01 then
        lines[#lines+1]="Your accessible reserves are "..money(p.gap).." below that buffer. Limit discretionary spending; do not commit more to locked savings."
    elseif r.months<3 then
        lines[#lines+1]="Keep any spare cash flexible for now. Fewer than three recorded months is not enough evidence for a term-savings allocation."
    else
        lines[#lines+1]="Current-account cash available above that buffer: "..money(p.available)..". My suggested split is:"
        if p.repay>0 then lines[#lines+1]=string.format("Loan repayment: up to %s, starting with eligible loans charging %.2f%%. Review the agreement before paying; asset leases are not included.",money(p.repay),p.debtRate) end
        lines[#lines+1]=string.format("Six-month fixed savings: %s.\nTwelve-month fixed savings: %s.\nLeave a further %s uncommitted for surprises.",money(p.short),money(p.long),money(p.unallocated))
    end
    lines[#lines+1]="These amounts are suggestions, not transactions. Deduct your planned purchases, seasonal bills and other unrecorded costs before using them."
    r.recommendations=table.concat(lines,"\n\n")
    local stress=p.threeMonth<0 and ("If no further receipts arrive, the recorded three-month costs and bills would leave a shortfall of "..money(-p.threeMonth)..". Act before a payment is missed.")
        or ("With no further receipts, "..money(p.threeMonth).." would remain after the recorded three-month costs and bills. This is a stress check, not a promise of spare cash.")
    r.actionPlan=string.format("CASH PRESSURE CHECK\n\nFinance and tenancy commitments: %s per month. Recorded running costs and administration: %s per month.\n\n%s",money(r.commitments),money(r.running+r.admin),stress)
    if p.gap>.01 or r.billed>.01 then
        r.actionPlan=r.actionPlan.."\n\nFirst postpone optional spending. If you hold easy-access savings, withdraw enough before bills fall due; transfers are not automatic."
        r.actionPlan=r.actionPlan.."\n\nIf the gap persists, review equipment you rarely use, lease-return or termination options, and land that is not earning its keep. Check finance settlement, return fees and lost income first. I cannot determine which assets are unnecessary or which land is unproductive; only sell what you own and are permitted to sell."
    else
        r.actionPlan=r.actionPlan.."\n\nThere is no cash-buffer reason here to recommend selling assets. Avoid tying up the full surplus: a good savings rate cannot pay a bill while the money is locked away."
    end
    r.actionPlan=r.actionPlan..string.format("\n\nHistorical receipts average %s across %d recorded months, but are deliberately not promised as future cash. Locked savings, unused credit and unsold crops are excluded. Known later maturities and unrecorded costs still need your own seasonal budget.",money(r.income),r.months)
end
function A:build(farmId)
    local repo,m=self.repository,self.manager
    local period=repo:getCurrentPeriodIndex()
    local r={farmId=farmId,period=period,fee=self.FEE,cash=num(farm(farmId).money)-self.FEE,easy=0,locked=0,months=0,running=0,income=0,balloons=0}
    local state=repo:getFarmState(farmId,false)
    for offset=1,3 do
        local p=state and state.periods and state.periods[period-offset]
        if p~=nil then
            r.months=r.months+1;r.income=r.income+num(p.operatingIncome)
            for _,t in ipairs(p.transactions or {}) do
                if num(t.amount)<0 and RUNNING[t.statistic] then r.running=r.running-t.amount end
            end
        end
    end
    if r.months>0 then r.income=r.income/r.months;r.running=r.running/r.months end
    local loans=repo:getLoansByFarm(farmId,true)
    local highestRate=0
    for _,loan in ipairs(loans) do
        highestRate=math.max(highestRate,num(loan.interestRate))
        if loan.type==RFF_LoanService.TYPE_BULLET and num(loan.remainingMonths)<=3 then r.balloons=r.balloons+math.max(0,num(loan.principal)) end
    end
    for _,loan in ipairs(repo:getAssetFinanceByFarm(farmId,true)) do
        if loan.status=="ACTIVE" then highestRate=math.max(highestRate,num(loan.interestRate)) end
        if loan.status=="ACTIVE" and num(loan.remainingMonths)<=3 then r.balloons=r.balloons+math.max(0,num(loan.balloonAmount)) end
    end
    r.commitments=math.max(0,m.loanService:getMonthlyDebtService(farmId))+math.max(0,repo:getMonthlyTenancyRent(farmId))
    r.admin=m.businessAdministration~=nil and math.max(0,num(m.businessAdministration:calculateMonthlyAdminCost(farmId))) or 0
    r.billed=math.max(0,num(repo:getRepaymentRecord(farmId).currentArrears))+math.max(0,repo:getTenancyArrears(farmId))+math.max(0,repo:getOutstandingBusinessObligations(farmId))
    for _,a in ipairs(m.savings:records(farmId)) do
        if a.status~="CLOSED" then
            local value=num(a.principal)+num(a.interest)
            if a.product=="EASY" then r.easy=r.easy+value else r.locked=r.locked+value end
        end
    end
    local rt=self:redTape(farmId)
    r.taxProvision=rt.provision;r.taxAdvice=rt.tax;r.grantAdvice=rt.grants
    r.reserve=3*(r.commitments+r.admin+r.running)+r.billed+r.balloons+r.taxProvision
    r.liquid=r.cash+r.easy
    local gap=math.max(0,r.reserve-r.liquid)
    local prefix="I've reviewed the figures available for your farm. "
    if r.billed>.01 then
        r.priority="Clear billed obligations first"
        r.cashAdvice=prefix.."You have "..money(r.billed).." in arrears or billed business obligations. Settle or plan those before opening another locked deposit. A good savings return is not worth missing a payment."
    elseif r.liquid<0 or gap>.01 then
        r.priority="Protect working cash"
        r.cashAdvice=prefix.."I would hold off on further locked savings. Cash after this fee plus easy-access savings is "..money(r.liquid)..", against a starting reserve of "..money(r.reserve)..". That leaves a gap of "..money(gap).." before unrecorded seasonal spending."
    elseif r.months<3 then
        r.priority="Build a seasonal cash plan"
        r.cashAdvice=prefix.."There is not yet enough completed-month history to call your spare cash a dependable surplus. Start with easy access while you work out your seed, fertiliser, fuel and harvest bills."
    else
        r.priority="Keep a reserve; stagger spare savings"
        r.cashAdvice=prefix.."Your recorded cash position covers the starting reserve. That is room to consider saving, not a reason to lock everything away. Keep seasonal bills and planned purchases separate, and stagger maturities so money returns when you need it."
    end
    r.cashAdvice=r.cashAdvice..string.format("\n\nThe reserve is three months of finance/rent (%s per month), administration (%s) and recorded running costs (%s), plus billed obligations (%s) and bullet/balloon payments within three months (%s).",money(r.commitments),money(r.admin),money(r.running),money(r.billed),money(r.balloons))
    if r.taxProvision>0 then r.cashAdvice=r.cashAdvice.."\n\nAn additional "..money(r.taxProvision).." is included for available Red Tape tax estimates and unpaid closed-year assessments; see Tax books and outlook." end
    if r.cash<r.reserve and r.easy>0 then r.cashAdvice=r.cashAdvice.."\n\nSome of your buffer is in easy-access savings: you must withdraw it before bills can use it. RFF will not sweep it into the current account automatically." end
    r.savingsAdvice=string.format("Easy access holds %s; notice/fixed deposits hold %s. The latter are not emergency cash. Higher term rates compensate you for giving up access; they do not remove the risk of being short when a bill arrives.",money(r.easy),money(r.locked))
    r.savingsAdvice=r.savingsAdvice.."\n\nToday's rates:"
    for _,p in ipairs(RFF_SavingsService.PRODUCTS) do
        local rate=m.savings:rate(p.id)
        r.savingsAdvice=r.savingsAdvice..string.format("\n%s: %.2f%% p.a.",p.name,rate)
    end
    local comparison=10000*(m.savings:rate("FIXED12")-m.savings:rate("EASY"))/100
    r.savingsAdvice=r.savingsAdvice..string.format("\n\nOn %s, a new 12-month fixed deposit would pay %s %s over a year than easy access IF today's easy-access rate stayed unchanged. Is that difference worth losing access for a year?",money(10000),money(math.abs(comparison)),comparison>=0 and "more" or "less")
    if r.billed>.01 or gap>.01 or r.months<3 then r.savingsAdvice=r.savingsAdvice.." My recommendation for now is to keep flexibility, rather than chase the term premium."
    else r.savingsAdvice=r.savingsAdvice.." Consider splitting genuinely spare money between terms, rather than one large 24-month deposit." end
    if highestRate>m.savings:rate("FIXED12") then
        r.savingsAdvice=r.savingsAdvice..string.format("\n\nAn active finance rate reaches %.2f%%, above today's 12-month savings offer. Compare permitted repayment savings and any fees before locking spare cash away. Do not borrow simply to chase deposit interest.",highestRate)
    end
    local e=repo.economyState
    local f6=RFF_EconomyService.forecast(e,6);local f12=RFF_EconomyService.forecast(e,12)
    r.baseRate=e.baseRate
    r.outlook=string.format("The base rate is %.2f%%. If today's underlying demand and cost pressures persist, the model points to rates %s over six months and %s over twelve months. That is a scenario, not a prediction of the next outside-world event.",e.baseRate,direction(f6.baseRate-e.baseRate),direction(f12.baseRate-e.baseRate))
    if f12.baseRate-e.baseRate>.24 then r.outlook=r.outlook.."\n\nRising-rate pressure can improve later savings offers, but also make new finance dearer. Keep flexibility if you expect to borrow; do not assume today's best fixed offer will stay best."
    elseif f12.baseRate-e.baseRate<-.24 then r.outlook=r.outlook.."\n\nEasing rates can make a fixed savings rate attractive, provided you can truly spare the cash. It may also improve future borrowing quotes. Neither outcome is guaranteed, so check costs before refinancing."
    else r.outlook=r.outlook.."\n\nWith no strong rate direction, choose savings by when the farm needs the money. There is little reason to make a large commitment just to guess the next rate review." end
    r.outlook=r.outlook.."\n\nStress-test a new loan quote at one percentage point more: on 10,000 outstanding, that is roughly 100 extra annual interest before repayments reduce the balance. Your existing fixed loans and deposits do not reprice with the base rate. Paying for this review does not give me knowledge of future random events."
    r.cautions=string.format("This is a snapshot taken in %s, after allowing for the %s review fee. Rereading it is free; it does not update when your finances change. A fresh paid review is optional.\n\nThere are %d completed months in the three-month sample. Average recorded operating receipts are %s per month, not guaranteed future income. Seasonal harvest receipts can distort short samples.",RFF_EconomyService.date(period),money(self.FEE),r.months,money(r.income))
    r.cautions=r.cautions.."\n\nThe reserve is a starting point, not a complete budget: available Red Tape tax estimates and unpaid assessments are allowed for, but not unknown future tax increases, annual insurance renewals, planned purchases or unidentified costs. Savings transfers and capital purchases are excluded from recorded running costs. Unused credit, unsold crops and locked deposits cannot pay today's bills."
    local cropCount,litres=0,0
    for _,a in ipairs(repo.cropAdvances or {}) do if a.farmId==farmId and a.status=="ACTIVE" then cropCount=cropCount+1;litres=litres+math.max(0,num(a.committedLitres)-num(a.deliveredLitres)) end end
    if cropCount>0 then r.cautions=r.cautions..string.format("\n\nYou also have %d active crop %s with %.0f litres still committed. Those deliveries will not pay you a second time; a shortfall can become a loan. Protect the harvest plan before locking more cash away.",cropCount,cropCount==1 and "advance" or "advances",litres) end
    self:recommend(r,loans,repo:getAssetFinanceByFarm(farmId,true))
    local investments=m.investments
    if investments then
        local held,cost=0,0
        for _,holding in ipairs(investments:records(farmId)) do if holding.status~="CLOSED" then held=held+holding.value;cost=cost+holding.principal end end
        local allocation=A.plan(r,loans,repo:getAssetFinanceByFarm(farmId,true),m.savings:rate("FIXED12"))
        local amount=math.floor(math.min(allocation.long*.5,allocation.available*.1)/100)*100
        r.investmentAdvice=string.format("CAPITAL AT RISK\n\nYour open funds are worth %s against %s invested: an unrealised gain/loss of %s. These holdings are not part of the accessible cash buffer or loan collateral.",money(held),money(cost),money(held-cost))
        if amount>=100 and allocation.repay==0 then
            r.investmentAdvice=r.investmentAdvice.."\n\nIf you can genuinely spare the money beyond the holding period, consider up to "..money(amount).." in the conservative fund INSTEAD OF that much of the suggested twelve-month fixed savings allocation. This is an alternative, not extra spending. Keep the rest of the plan and your contingency intact."
        else
            r.investmentAdvice=r.investmentAdvice.."\n\nI would not suggest a new fund allocation yet. Protect cash, settle bills and consider costly borrowing first; a short financial history is also a reason to wait. A higher potential return does not justify risking money needed by the farm."
        end
        r.investmentAdvice=r.investmentAdvice.."\n\nConservative: minimum 12 months, then one month's sale notice. Agricultural growth: minimum 24 months, then notice, with greater exposure to weak demand and tight credit. Both can lose capital, including during notice. Fees are included in values.\n\nGrowth is for money you can leave alone through a downturn. Neither the economy forecast nor past gains guarantee a return. Realised gains use other income; capital losses are recorded in the fund history, not automatically claimed as tax deductions."
    end
    return r
end
function A:buy(farmId,quote)
    if not server() then return nil,"Financial reviews are server-only." end
    local current=self:quote(farmId)
    if current==nil or quote==nil or quote.farmId~=farmId or quote.fee~=current.fee or quote.period~=current.period or quote.previousId~=current.previousId then return nil,"The review request changed. Please confirm a fresh quote." end
    local f=farm(farmId)
    if num(f.money)<self.FEE then return nil,"The review needs 250 in current-account cash; it cannot use your overdraft or savings automatically." end
    local report=self:build(farmId)
    report.status="PENDING";report.dueDay=self:clock()+self.DELIVERY_DAYS
    local list=self.repository.adviserReports or {};self.repository.adviserReports=list
    local id=0;for _,r in ipairs(list) do id=math.max(id,r.id) end;report.id=id+1
    list[#list+1]=report
    self.repository:setNextTransactionDescription(farmId,"Financial adviser review FA-"..report.id)
    g_currentMission:addMoney(-self.FEE,farmId,MoneyType~=nil and MoneyType.OTHER or nil,true,true)
    return report
end
function A:update(dt)
    if not server() or not self.repository.loaded then return end
    self.timer=(self.timer or 0)-dt;if self.timer>0 then return end;self.timer=1000
    local now=self:clock();if now==nil then return end
    for _,r in ipairs(self.repository.adviserReports or {}) do
        if r.status=="PENDING" and now>=r.dueDay then
            -- Mark first so repeated updates/reloads cannot issue the same delivery again.
            r.status="READY"
            if RFF_NotificationService and RFF_NotificationService.send then
                pcall(RFF_NotificationService.send,RFF_NotificationService,r.farmId,"Financial adviser","Your financial review is ready",
                    "I've finished your review FA-"..r.id..". Read my recommendations in Banking - Financial Adviser. The figures reflect your position when commissioned in "..RFF_EconomyService.date(r.period).."; check anything that has changed since.",
                    "adviser","Financial adviser report received. Read it in Banking - Financial Adviser.",false)
            end
        end
    end
end
local NUMBERS={"id","farmId","period","fee","cash","easy","locked","months","running","income","balloons","commitments","admin","billed","reserve","liquid","baseRate"}
local TEXTS={"priority","cashAdvice","savingsAdvice","outlook","cautions","recommendations","actionPlan","taxAdvice","grantAdvice","investmentAdvice"}
function A.save(repository,xml)
    for i,r in ipairs(repository.adviserReports or {}) do
        local key="realisticFarmFinance.adviser.report("..(i-1)..")"
        for _,k in ipairs(NUMBERS) do xml:setString(key.."#"..k,string.format("%.17g",r[k])) end
        for _,k in ipairs(TEXTS) do xml:setString(key.."#"..k,r[k] or "") end
        xml:setString(key.."#status",r.status or "READY")
        xml:setString(key.."#dueDay",string.format("%.17g",num(r.dueDay)))
        xml:setString(key.."#taxProvision",string.format("%.17g",num(r.taxProvision)))
    end
end
function A.load(repository,xml)
    repository.adviserReports={};local i=0;local ids={}
    while xml:hasProperty("realisticFarmFinance.adviser.report("..i..")") do
        local key="realisticFarmFinance.adviser.report("..i..")";local r={};local valid=true
        for _,k in ipairs(NUMBERS) do local n=tonumber(xml:getString(key.."#"..k));valid=valid and n~=nil and n==num(n);r[k]=n end
        for _,k in ipairs(TEXTS) do r[k]=xml:getString(key.."#"..k) or "" end
        r.status=xml:getString(key.."#status")=="PENDING" and "PENDING" or "READY"
        r.dueDay=num(tonumber(xml:getString(key.."#dueDay")))
        r.taxProvision=num(tonumber(xml:getString(key.."#taxProvision")))
        if valid and r.id>0 and r.id%1==0 and r.farmId>0 and not ids[r.id] then ids[r.id]=true;repository.adviserReports[#repository.adviserReports+1]=r end
        i=i+1
    end
end
