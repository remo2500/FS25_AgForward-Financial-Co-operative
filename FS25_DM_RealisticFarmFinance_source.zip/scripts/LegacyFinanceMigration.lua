RFF_LegacyFinanceMigration = {}
RFF_LegacyFinanceMigration.__index = RFF_LegacyFinanceMigration

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return tonumber(value) or 0
end

local function safeInt(value)
    return math.floor(safeNumber(value) + 0.00001)
end

local function getSavegameDirectory()
    if g_currentMission == nil or g_currentMission.missionInfo == nil then return nil end
    local path = g_currentMission.missionInfo.savegameDirectory
    if path == nil and g_currentMission.missionInfo.savegameIndex ~= nil then
        path = string.format("%ssavegame%d", getUserProfileAppPath(), g_currentMission.missionInfo.savegameIndex)
    end
    return path
end

local function modFlag(name)
    return type(g_modIsLoaded) == "table" and g_modIsLoaded[name] == true
end

local function modEnvironment(name)
    if type(_G) ~= "table" then return nil end
    local environment = rawget(_G, name)
    return type(environment) == "table" and environment or nil
end

local function parseMigrationIds(value)
    local result = {}
    if type(value) ~= "string" or value == "" then return result end
    for token in string.gmatch(value, "[^|]+") do result[token] = true end
    return result
end

local function joinMigrationIds(set)
    local values = {}
    for token, enabled in pairs(set or {}) do
        if enabled == true then values[#values + 1] = token end
    end
    table.sort(values)
    return table.concat(values, "|")
end

local function bankRiskGrade(riskLevel)
    riskLevel = safeInt(riskLevel)
    if riskLevel <= 1 then return "B" end
    if riskLevel == 2 then return "C" end
    return "D"
end

local function hirePurchaseRatePercent(baseCost, deposit)
    local base = math.max(1, safeNumber(baseCost))
    local ratio = math.max(0, safeNumber(deposit)) / base
    if ratio <= 0.051 then return 5.0 end
    if ratio <= 0.11 then return 4.0 end
    if ratio <= 0.21 then return 3.5 end
    if ratio <= 0.31 then return 2.95 end
    return 2.5
end

local function hirePurchaseMonthlyPayment(baseCost, deposit, durationMonths, finalFee, annualRatePercent)
    local pv = math.max(0, safeNumber(baseCost) - safeNumber(deposit))
    local fv = math.max(0, safeNumber(finalFee))
    local n = math.max(1, safeInt(durationMonths))
    local r = math.max(0, safeNumber(annualRatePercent)) / 100 / 12
    if r <= 0 then return math.max(0, (pv - fv) / n) end
    local growth = (1 + r) ^ n
    return (pv - fv / growth) * (r * growth) / (growth - 1)
end

local function hirePurchaseOutstandingPrincipal(baseCost, deposit, durationMonths, finalFee, monthsPaid, annualRatePercent, monthlyPayment)
    local pv = math.max(0, safeNumber(baseCost) - safeNumber(deposit))
    local paid = math.max(0, math.min(safeInt(monthsPaid), math.max(1, safeInt(durationMonths))))
    if paid <= 0 then return pv end
    local r = math.max(0, safeNumber(annualRatePercent)) / 100 / 12
    local payment = math.max(0, safeNumber(monthlyPayment))
    if r <= 0 then return math.max(0, pv - payment * paid) end
    local growth = (1 + r) ^ paid
    return math.max(0, pv * growth - payment * ((growth - 1) / r))
end

-- Enhanced Loan System calculates an annual annuity from the original amount
-- and term, then divides it into twelve monthly instalments. Preserve that exact
-- scheduled commitment rather than repricing the transferred balance in RFF.
local function enhancedLoanMonthlyPayment(originalAmount, annualRatePercent, durationYears)
    local amount = math.max(0, safeNumber(originalAmount))
    local years = math.max(1, safeInt(durationYears))
    local rate = math.max(0, safeNumber(annualRatePercent)) / 100
    if rate <= 0 then return amount / (years * 12) end
    local growth = (1 + rate) ^ years
    if growth <= 1 then return amount / (years * 12) end
    return amount * ((growth * rate) / (growth - 1)) / 12
end

function RFF_LegacyFinanceMigration.new(manager)
    local self = setmetatable({}, RFF_LegacyFinanceMigration)
    self.manager = manager
    self.repository = manager ~= nil and manager.repository or nil
    return self
end

function RFF_LegacyFinanceMigration:isSourceActive(source)
    if source == "BANKCREDIT" then
        if modFlag("FS25_BankCredit") then return true end
        if BankCredit ~= nil and BankCredit.manager ~= nil then return true end
        return g_currentMission ~= nil and g_currentMission.bankManager ~= nil
    elseif source == "HIREPURCHASING" then
        if modFlag("FS25_HirePurchasing") then return true end
        return g_currentMission ~= nil and g_currentMission.LeasingOptions ~= nil
    elseif source == "FIELDFINANCE" then
        if modFlag("FS25_FieldFinance") then return true end
        return g_fieldLeasingManager ~= nil
    elseif source == "ENHANCEDLOANSYSTEM" then
        if modFlag("FS25_EnhancedLoanSystem") then return true end
        local environment = modEnvironment("FS25_EnhancedLoanSystem")
        if environment ~= nil and (environment.g_els_loanManager ~= nil or environment.ELS_loanManager ~= nil) then return true end
        return type(_G) == "table" and rawget(_G, "g_els_loanManager") ~= nil
    end
    return false
end

function RFF_LegacyFinanceMigration:hasMigrationId(farmId, migrationId)
    if self.repository == nil or farmId == nil or farmId <= 0 or migrationId == nil then return false end
    local state = self.repository:getFarmState(farmId, true)
    local set = parseMigrationIds(state.externalFinanceMigrationIds or "")
    return set[migrationId] == true
end

function RFF_LegacyFinanceMigration:markMigrationId(farmId, migrationId)
    if self.repository == nil or farmId == nil or farmId <= 0 or migrationId == nil then return end
    local state = self.repository:getFarmState(farmId, true)
    local set = parseMigrationIds(state.externalFinanceMigrationIds or "")
    set[migrationId] = true
    state.externalFinanceMigrationIds = joinMigrationIds(set)
end

function RFF_LegacyFinanceMigration:getVehicleByUniqueId(uniqueId)
    if uniqueId == nil or uniqueId == "" or g_currentMission == nil or g_currentMission.vehicleSystem == nil then return nil end
    for _, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles or {}) do
        if vehicle ~= nil and vehicle.uniqueId == uniqueId then return vehicle end
    end
    return nil
end

function RFF_LegacyFinanceMigration:baseLoanRecord(farmId, loanType, purpose, originalAmount, principal, interestRate, termMonths, remainingMonths, monthlyPayment, riskGrade, paymentsMade, missedPayments)
    local current = self.repository:getCurrentPeriodIndex()
    paymentsMade = math.max(0, safeInt(paymentsMade))
    missedPayments = math.max(0, safeInt(missedPayments))
    return {
        id = self.repository:getNextLoanId(), farmId = farmId, type = loanType, purpose = purpose or "GENERAL",
        originalAmount = math.max(0, safeNumber(originalAmount)), creditLimit = 0,
        principal = math.max(0, safeNumber(principal)), drawnAmount = 0,
        interestRate = math.max(0, safeNumber(interestRate)), termMonths = math.max(0, safeInt(termMonths)),
        remainingMonths = math.max(0, safeInt(remainingMonths)), monthlyPayment = math.max(0, safeNumber(monthlyPayment)),
        riskGrade = riskGrade or "C", createdPeriod = math.max(0, current - paymentsMade), lastPaymentPeriod = current,
        paymentsMade = paymentsMade, missedPayments = missedPayments,
        arrearsPrincipal = 0, arrearsInterest = 0, arrearsRent = 0, arrearsFees = 0, arrearsBalance = 0,
        arrearsAgeMonths = 0, arrearsStage = "CURRENT", defaultInterestAccrued = 0, adminChargesAccrued = 0,
        defaultEvents = 0, currentDefault = false, defaultRecorded = false, recoveryEligible = false,
        lastDefaultManagementPeriod = current, consecutiveMissedPayments = missedPayments,
        maxConsecutiveMissedPayments = missedPayments, lastMissedPeriod = missedPayments > 0 and current or 0,
        lastSuccessfulPaymentPeriod = paymentsMade > 0 and current or 0, lastArrearsClearedPeriod = 0,
        arrearsSchemaVersion = 1, principalPaid = math.max(0, safeNumber(originalAmount) - safeNumber(principal)),
        interestPaid = 0, completedPeriod = 0, paidOff = false, legacyImported = false,
        relationshipCompletionRecorded = false,
        securityFarmlandId = 0, securityFarmlandIds = "", securityFarmlandCount = 0,
        releasedSecurityFarmlandIds = "", releasedSecurityFarmlandCount = 0,
        purchasePrice = 0, depositPaid = 0, lenderValuation = 0, propertyLtv = 0, propertyLtvLimit = 0,
        applicationId = 0, propertyFinanceMode = "", equityRelease = false, holdingEquityRelease = false,
        equityReleasedAmount = 0,
        lenderId = "PRIMARY_BANK", lenderNameKey = "rff_lender_primary_bank", brokered = false, brokerCaseId = 0,
        arrangementFee = 0, brokerFee = 0,
        overdraftSuspended = false, overdraftOverLimit = 0, overdraftLimitBreaches = 0,
        lastOverdraftBreachPeriod = 0, overdraftReviewCount = 0, overdraftWarningTwoMonths = false,
        overdraftWarningOneMonth = false,
        forbearanceCount = 0, forbearanceLastPeriod = 0, forbearanceLastType = "", forbearanceMode = "",
        forbearanceRemainingPeriods = 0, forbearanceCapitalisedArrears = 0, forbearanceCapitalisedInterest = 0,
        forbearanceOriginalPayment = 0, forbearanceOriginalRate = 0, forbearanceBroken = false,
        forbearanceOfferStatus = "", forbearanceOfferType = "", forbearanceOfferCreatedPeriod = 0,
        forbearanceOfferExpiryPeriod = 0, forbearanceOfferLastPeriod = 0
    }
end

function RFF_LegacyFinanceMigration:importBankCredit()
    if self:isSourceActive("BANKCREDIT") then
        print("[RealisticFarmFinance] BankCredit is active; bankCredit.xml migration disabled to prevent duplicate finance")
        return 0
    end
    local dir = getSavegameDirectory()
    if dir == nil then return 0 end
    local xmlFile = XMLFile.loadIfExists("rffBankCreditMigration", dir .. "/bankCredit.xml", "bankcredit")
    if xmlFile == nil then return 0 end

    local imported = 0
    local index = 0
    while true do
        local key = string.format("bankcredit.loan(%d)", index)
        if not xmlFile:hasProperty(key) then break end
        local sourceId = safeInt(xmlFile:getInt(key .. "#id"))
        local farmId = safeInt(xmlFile:getInt(key .. "#farmId"))
        local paidOff = xmlFile:getBool(key .. "#paidOff") == true
        local restAmount = math.max(0, safeNumber(xmlFile:getFloat(key .. "#restAmount")))
        local migrationId = string.format("BC:%d", sourceId)
        if farmId > 0 and sourceId > 0 and not paidOff and restAmount > 0.01 and not self:hasMigrationId(farmId, migrationId) then
            local sourceType = safeInt(xmlFile:getInt(key .. "#type"))
            local amount = math.max(restAmount, safeNumber(xmlFile:getFloat(key .. "#amount")))
            local rate = math.max(0, safeNumber(xmlFile:getFloat(key .. "#interestRate")))
            local duration = math.max(0, safeInt(xmlFile:getInt(key .. "#duration")))
            local restDuration = math.max(0, safeInt(xmlFile:getInt(key .. "#restDuration")))
            local payment = math.max(0, safeNumber(xmlFile:getFloat(key .. "#monthlyPayment")))
            local riskLevel = safeInt(xmlFile:getInt(key .. "#riskLevel"))
            local typeName = RFF_LoanService.TYPE_TERM
            if sourceType == 2 then typeName = RFF_LoanService.TYPE_BULLET
            elseif sourceType == 3 then typeName = RFF_LoanService.TYPE_REVOLVING end
            local paymentsMade = sourceType == 3 and 0 or math.max(0, duration - restDuration)
            local loan = self:baseLoanRecord(farmId, typeName, "GENERAL", amount, sourceType == 3 and 0 or restAmount,
                rate, sourceType == 3 and 0 or duration, sourceType == 3 and 0 or restDuration,
                sourceType == 3 and 0 or payment, bankRiskGrade(riskLevel), paymentsMade, 0)
            if sourceType == 3 then
                loan.creditLimit = math.max(0, safeNumber(xmlFile:getFloat(key .. "#amount")))
                loan.drawnAmount = restAmount
                loan.originalAmount = loan.creditLimit
                loan.principalPaid = 0
            end
            self.repository:addLoan(loan)
            self:markMigrationId(farmId, migrationId)
            imported = imported + 1
            print(string.format("[RealisticFarmFinance] Imported BankCredit loan source=%d farm=%d as RFF #%d type=%s balance=%.2f rate=%.2f%% remaining=%d",
                sourceId, farmId, loan.id or 0, tostring(typeName), restAmount, rate, loan.remainingMonths or 0))
        end
        index = index + 1
    end
    xmlFile:delete()
    return imported
end

function RFF_LegacyFinanceMigration:importHirePurchasing()
    if self:isSourceActive("HIREPURCHASING") then
        print("[RealisticFarmFinance] Hire Purchasing is active; leaseDeals.xml migration disabled to prevent duplicate finance")
        return 0
    end
    local dir = getSavegameDirectory()
    if dir == nil then return 0 end
    local xmlFile = XMLFile.loadIfExists("rffHirePurchasingMigration", dir .. "/leaseDeals.xml", "leaseDeals")
    if xmlFile == nil then return 0 end

    local imported = 0
    local index = 0
    while true do
        local key = string.format("leaseDeals.leaseDeals.deal(%d)", index)
        if not xmlFile:hasProperty(key) then break end
        local sourceId = xmlFile:getString(key .. "#id") or tostring(index)
        local farmId = safeInt(xmlFile:getInt(key .. "#farmId"))
        local vehicleId = xmlFile:getString(key .. "#vehicle") or ""
        local migrationId = "HP:" .. sourceId
        if farmId > 0 and vehicleId ~= "" and not self:hasMigrationId(farmId, migrationId) then
            local existing = self.repository:getAssetFinanceByVehicle(vehicleId, true)
            local vehicle = self:getVehicleByUniqueId(vehicleId)
            if existing ~= nil then
                self:markMigrationId(farmId, migrationId)
            elseif vehicle ~= nil and (safeInt(vehicle.ownerFarmId) == 0 or safeInt(vehicle.ownerFarmId) == farmId) then
                local baseCost = math.max(0, safeNumber(xmlFile:getInt(key .. "#baseCost")))
                local deposit = math.max(0, safeNumber(xmlFile:getInt(key .. "#deposit")))
                local duration = math.max(1, safeInt(xmlFile:getInt(key .. "#durationMonths")))
                local finalFee = math.max(0, safeNumber(xmlFile:getInt(key .. "#finalFee")))
                local monthsPaid = math.max(0, math.min(duration, safeInt(xmlFile:getInt(key .. "#monthsPaid"))))
                local rate = hirePurchaseRatePercent(baseCost, deposit)
                local monthly = hirePurchaseMonthlyPayment(baseCost, deposit, duration, finalFee, rate)
                local principal = hirePurchaseOutstandingPrincipal(baseCost, deposit, duration, finalFee, monthsPaid, rate, monthly)
                local remainingRegular = math.max(0, duration - monthsPaid)
                local remaining = remainingRegular + (finalFee > 0.01 and 1 or 0)
                if remaining <= 0 and finalFee <= 0.01 then
                    self:markMigrationId(farmId, migrationId)
                else
                    local product = finalFee > 0.01 and RFF_AssetFinanceService.TYPE_BALLOON or RFF_AssetFinanceService.TYPE_HIRE_PURCHASE
                    local financed = math.max(0, baseCost - deposit)
                    local current = self.repository:getCurrentPeriodIndex()
                    local agreement = {
                        id = self.repository:getNextAssetFinanceId(), farmId = farmId, product = product,
                        vehicleUniqueId = vehicleId,
                        vehicleName = vehicle.getName ~= nil and vehicle:getName() or "Financed asset",
                        storeItemXml = "", basePrice = baseCost,
                        depositPercent = baseCost > 0 and deposit / baseCost * 100 or 0, depositPaid = deposit, refundableDeposit = 0,
                        originalFinanced = financed, principal = principal, balloonAmount = finalFee, residualValue = 0,
                        interestRate = rate, termMonths = duration + (finalFee > 0.01 and 1 or 0), remainingMonths = remaining,
                        monthlyPayment = monthly, riskGrade = "C", lenderId = "", lenderNameKey = "",
                        lenderMarketState = "SELECTIVE", lenderDealFit = "STANDARD", lenderAssignmentLegacy = true,
                        relationshipDealRecorded = true, relationshipCompletionRecorded = false, relationshipRecoveryRecorded = false,
                        createdPeriod = math.max(0, current - monthsPaid), lastPaymentPeriod = current,
                        paymentsMade = monthsPaid, missedPayments = 0,
                        arrearsPrincipal = 0, arrearsInterest = 0, arrearsRent = 0, arrearsFees = 0, arrearsBalance = 0,
                        arrearsAgeMonths = 0, arrearsStage = "CURRENT", defaultInterestAccrued = 0, adminChargesAccrued = 0,
                        defaultEvents = 0, currentDefault = false, defaultRecorded = false, recoveryEligible = false,
                        lastDefaultManagementPeriod = current, consecutiveMissedPayments = 0, maxConsecutiveMissedPayments = 0,
                        lastMissedPeriod = 0, lastSuccessfulPaymentPeriod = monthsPaid > 0 and current or 0, lastArrearsClearedPeriod = 0,
                        arrearsSchemaVersion = 1,
                        principalPaid = math.max(0, financed - principal),
                        interestPaid = math.max(0, monthly * monthsPaid - math.max(0, financed - principal)), leaseRentPaid = 0,
                        completedPeriod = 0, status = "ACTIVE", titleRetained = true,
                        returnDue = false, returned = false, leaseWarningTwoMonths = false, leaseWarningOneMonth = false,
                        returnedPeriod = 0, returnRepairCost = 0, returnMaintenancePenalty = 0, returnWashingCost = 0,
                        returnEarlyTerminationCharge = 0, returnEarlyTerminated = false, returnRemainingMonths = 0, returnFutureRent = 0,
                        returnArrearsApplied = 0, returnDeductions = 0, returnDepositRefund = 0, returnAdditionalCharge = 0,
                        returnDamage = 0, returnDirt = 0, returnAdsApplied = false, returnAdsCondition = 0,
                        returnAdsServiceLevel = 0, returnAdsBreakdownCount = 0,
                        recoveryEligiblePeriod = 0, recoveryPending = false, lastRecoveryBlockedPeriod = 0, recovered = false,
                        recoveredPeriod = 0, recoveryMethod = "", recoveryMarketValue = 0, recoveryAdjustedMarketValue = 0,
                        recoveryTechnicalAdjustment = 0, recoveryRealisedValue = 0, recoveryCosts = 0, recoveryDebtAtRecovery = 0,
                        recoveryDepositApplied = 0, recoveryShortfall = 0, recoverySurplus = 0, recoveryLiabilityLoanId = 0,
                        recoveryAdsApplied = false, recoveryAdsCondition = 0, recoveryAdsServiceLevel = 0,
                        recoveryAdsBreakdownCount = 0, recoveryAdsRepairCost = 0, recoveryAdsMaintenancePenalty = 0
                    }
                    if self.manager.relationshipService ~= nil and self.manager.relationshipService.assignLegacyAssetLender ~= nil then
                        self.manager.relationshipService:assignLegacyAssetLender(agreement)
                    end
                    self.repository:addAssetFinance(agreement)
                    self:markMigrationId(farmId, migrationId)
                    imported = imported + 1
                    print(string.format("[RealisticFarmFinance] Imported Hire Purchasing deal %s farm=%d as asset #%d product=%s vehicle=%s balance=%.2f payment=%.2f remaining=%d",
                        tostring(sourceId), farmId, agreement.id or 0, tostring(product), tostring(agreement.vehicleName), principal, monthly, remaining))
                end
            end
        end
        index = index + 1
    end
    xmlFile:delete()
    return imported
end

function RFF_LegacyFinanceMigration:hasMortgageForFarmland(farmId, farmlandId)
    for _, loan in ipairs(self.repository:getLoansByFarm(farmId, true)) do
        if loan.type == RFF_LoanService.TYPE_MORTGAGE and safeInt(loan.securityFarmlandId) == farmlandId then return true end
    end
    return false
end

function RFF_LegacyFinanceMigration:importFieldFinance()
    if self:isSourceActive("FIELDFINANCE") then
        print("[RealisticFarmFinance] Field Finance is active; fieldLoanContracts.xml migration disabled to prevent duplicate finance")
        return 0
    end
    local dir = getSavegameDirectory()
    if dir == nil then return 0 end
    local xmlFile = XMLFile.loadIfExists("rffFieldFinanceMigration", dir .. "/fieldLoanContracts.xml", "fieldLoanContracts")
    if xmlFile == nil then return 0 end

    local imported = 0
    local index = 0
    while true do
        local key = string.format("fieldLoanContracts.fieldLoanContract(%d)", index)
        if not xmlFile:hasProperty(key) then break end
        local farmlandId = safeInt(xmlFile:getInt(key .. "#farmlandId"))
        local farmId = safeInt(xmlFile:getInt(key .. "#farmId"))
        local contractType = xmlFile:getString(key .. "#contractType") or "loan"
        local purchasePrice = math.max(0, safeNumber(xmlFile:getInt(key .. "#purchasePrice")))
        local principalOriginal = math.max(0, safeNumber(xmlFile:getInt(key .. "#principal")))
        local balance = math.max(0, safeNumber(xmlFile:getInt(key .. "#remainingBalance")))
        local monthly = math.max(0, safeNumber(xmlFile:getInt(key .. "#monthlyPayment")))
        local monthsTotal = math.max(1, safeInt(xmlFile:getInt(key .. "#monthsTotal")))
        local monthsPaid = math.max(0, safeInt(xmlFile:getInt(key .. "#monthsPaid")))
        local missed = math.max(0, safeInt(xmlFile:getInt(key .. "#missedPayments")))
        local status = xmlFile:getString(key .. "#status") or "active"
        local downPayment = math.max(0, safeNumber(xmlFile:getInt(key .. "#downPayment")))
        local migrationId = string.format("FF:%d:%s:%d:%d:%d", farmlandId, contractType, safeInt(principalOriginal), monthsTotal, safeInt(monthly))

        local activeStatus = status == "active" or status == "overdue"
        if farmId > 0 and farmlandId > 0 and activeStatus and not self:hasMigrationId(farmId, migrationId) then
            local owner = g_farmlandManager ~= nil and g_farmlandManager:getFarmlandOwner(farmlandId) or nil
            if owner == farmId then
                if contractType == "lease" then
                    if self.repository:getTenancyByFarmland(farmlandId, true) ~= nil then
                        self:markMigrationId(farmId, migrationId)
                    else
                        local current = self.repository:getCurrentPeriodIndex()
                        local remaining = math.max(0, monthsTotal - monthsPaid)
                        local tenancy = {
                            id = self.repository:getNextTenancyId(), farmId = farmId, farmlandId = farmlandId,
                            purchasePrice = purchasePrice, securityDeposit = 0, monthlyRent = monthly,
                            termMonths = monthsTotal, remainingMonths = remaining,
                            createdPeriod = math.max(0, current - monthsPaid), lastPaymentPeriod = current,
                            paymentsMade = monthsPaid, missedPayments = missed, status = "ACTIVE", depositForfeited = false
                        }
                        self.repository:addTenancy(tenancy)
                        self:markMigrationId(farmId, migrationId)
                        imported = imported + 1
                        print(string.format("[RealisticFarmFinance] Imported Field Finance tenancy farm=%d land=%d as tenancy #%d rent=%.2f remaining=%d missed=%d",
                            farmId, farmlandId, tenancy.id or 0, monthly, remaining, missed))
                    end
                elseif balance > 0.01 then
                    if self:hasMortgageForFarmland(farmId, farmlandId) then
                        self:markMigrationId(farmId, migrationId)
                    else
                        local scheduledRemaining = monthly > 0 and math.max(1, math.ceil(balance / monthly)) or math.max(1, monthsTotal - monthsPaid)
                        local arrearsPrincipal = status == "overdue" and math.min(balance, monthly * math.max(1, missed)) or 0
                        local currentPrincipal = math.max(0, balance - arrearsPrincipal)
                        local loan = self:baseLoanRecord(farmId, RFF_LoanService.TYPE_MORTGAGE, "LAND_PROPERTY",
                            math.max(principalOriginal, balance), currentPrincipal, 0, monthsPaid + scheduledRemaining,
                            scheduledRemaining, monthly, "C", monthsPaid, missed)
                        loan.arrearsPrincipal = arrearsPrincipal
                        loan.arrearsBalance = arrearsPrincipal
                        loan.arrearsAgeMonths = status == "overdue" and math.max(1, missed) or 0
                        loan.arrearsStage = status == "overdue" and "ARREARS" or "CURRENT"
                        loan.consecutiveMissedPayments = missed
                        loan.maxConsecutiveMissedPayments = missed
                        loan.principalPaid = math.max(0, math.max(principalOriginal, balance) - balance)
                        loan.securityFarmlandId = farmlandId
                        loan.securityFarmlandIds = tostring(farmlandId)
                        loan.securityFarmlandCount = 1
                        loan.purchasePrice = purchasePrice
                        loan.depositPaid = downPayment
                        loan.lenderValuation = purchasePrice
                        loan.propertyLtv = purchasePrice > 0 and balance / purchasePrice or 0
                        loan.propertyLtvLimit = 0.75
                        loan.propertyFinanceMode = "PURCHASE"
                        self.repository:addLoan(loan)
                        self:markMigrationId(farmId, migrationId)
                        imported = imported + 1
                        print(string.format("[RealisticFarmFinance] Imported Field Finance loan farm=%d land=%d as mortgage #%d balance=%.2f payment=%.2f remaining=%d missed=%d",
                            farmId, farmlandId, loan.id or 0, balance, monthly, scheduledRemaining, missed))
                    end
                end
            end
        end
        index = index + 1
    end
    xmlFile:delete()
    return imported
end

function RFF_LegacyFinanceMigration:importEnhancedLoanSystem()
    if self:isSourceActive("ENHANCEDLOANSYSTEM") then
        print("[RealisticFarmFinance] Enhanced Loan System is active; els_loans.xml migration disabled to prevent duplicate finance")
        return 0
    end
    local dir = getSavegameDirectory()
    if dir == nil then return 0 end
    local xmlFile = XMLFile.loadIfExists("rffEnhancedLoanSystemMigration", dir .. "/els_loans.xml", "loans")
    if xmlFile == nil then return 0 end

    local imported = 0
    local farmIndex = 0
    while true do
        local farmKey = string.format("loans.farmId(%d)", farmIndex)
        if not xmlFile:hasProperty(farmKey) then break end
        local parentFarmId = safeInt(xmlFile:getInt(farmKey .. "#farmId"))
        local loanIndex = 0
        while true do
            local loanKey = string.format("%s.loan(%d)", farmKey, loanIndex)
            if not xmlFile:hasProperty(loanKey) then break end

            local farmId = safeInt(xmlFile:getInt(loanKey .. "#farmId"))
            if farmId <= 0 then farmId = parentFarmId end
            local originalAmount = math.max(0, safeNumber(xmlFile:getInt(loanKey .. "#amount")))
            local restAmount = math.max(0, safeNumber(xmlFile:getInt(loanKey .. "#restAmount")))
            local annualRate = math.max(0, safeNumber(xmlFile:getFloat(loanKey .. "#interest")))
            local durationYears = math.max(1, safeInt(xmlFile:getInt(loanKey .. "#duration")))
            local originalTermMonths = durationYears * 12
            local remainingMonths = math.max(0, safeInt(xmlFile:getInt(loanKey .. "#restDuration")))
            local paidOff = xmlFile:getBool(loanKey .. "#paidOff") == true
            local migrationId = string.format("ELS:%d:%d:%d:%d:%d", farmId, loanIndex,
                safeInt(originalAmount), durationYears, safeInt(annualRate * 10000 + 0.5))

            local farmExists = g_farmManager == nil or g_farmManager:getFarmById(farmId) ~= nil
            if farmId > 0 and farmExists and not paidOff and restAmount > 0.01
                and not self:hasMigrationId(farmId, migrationId) then
                remainingMonths = math.max(1, remainingMonths)
                local termMonths = math.max(originalTermMonths, remainingMonths)
                local paymentsMade = math.max(0, termMonths - remainingMonths)
                local monthlyPayment = enhancedLoanMonthlyPayment(originalAmount, annualRate, durationYears)
                if monthlyPayment <= 0 then monthlyPayment = restAmount / remainingMonths end

                local loan = self:baseLoanRecord(farmId, RFF_LoanService.TYPE_TERM, "LEGACY_FINANCE",
                    math.max(originalAmount, restAmount), restAmount, annualRate, termMonths,
                    remainingMonths, monthlyPayment, "C", paymentsMade, 0)
                loan.legacyImported = true
                loan.principalPaid = math.max(0, math.max(originalAmount, restAmount) - restAmount)
                self.repository:addLoan(loan)
                self:markMigrationId(farmId, migrationId)
                imported = imported + 1
                print(string.format("[RealisticFarmFinance] Imported Enhanced Loan System agreement farm=%d sourceIndex=%d as Legacy Farm Loan #%d balance=%.2f payment=%.2f rate=%.2f%% remaining=%d; farm cash unchanged",
                    farmId, loanIndex, loan.id or 0, restAmount, monthlyPayment, annualRate, remainingMonths))
            end
            loanIndex = loanIndex + 1
        end
        farmIndex = farmIndex + 1
    end
    xmlFile:delete()
    return imported
end

function RFF_LegacyFinanceMigration:migrateInactiveLegacyMods()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local bank = self:importBankCredit()
    local hire = self:importHirePurchasing()
    local field = self:importFieldFinance()
    local enhanced = self:importEnhancedLoanSystem()
    local total = bank + hire + field + enhanced
    if total > 0 then
        print(string.format("[RealisticFarmFinance] Legacy external finance migration complete: BankCredit=%d HirePurchasing=%d FieldFinance=%d EnhancedLoanSystem=%d total=%d", bank, hire, field, enhanced, total))
    end
end
