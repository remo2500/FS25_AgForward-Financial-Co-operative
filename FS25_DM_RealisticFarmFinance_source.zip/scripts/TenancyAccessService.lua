-- Contract-backed tenancy-access bridge.
-- GIANTS remains authoritative for farmland ownership. RFF only grants the
-- occupying farm agricultural access while an RFF tenancy is active.
RFF_TenancyAccessService = {}
RFF_TenancyAccessService._installed = false
RFF_TenancyAccessService._temporaryOriginalOwners = setmetatable({}, {__mode="k"})
RFF_TenancyAccessService._authorizedFixtureRemovals = setmetatable({}, {__mode="k"})
RFF_TenancyAccessService._operationalFixtureOriginalOwners = setmetatable({}, {__mode="k"})
RFF_TenancyAccessService._operationalFixtureTenancies = setmetatable({}, {__mode="k"})

local TENANCY_POSSESSION_STATES = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true}

local function getManager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function getRepository()
    local manager = getManager()
    return manager ~= nil and manager.repository or nil
end

local function getPropertyFinanceService()
    local manager = getManager()
    return manager ~= nil and manager.propertyFinance or nil
end

local function getLocalFarmId()
    if g_localPlayer ~= nil and g_localPlayer.farmId ~= nil then return tonumber(g_localPlayer.farmId) or 0 end
    if g_currentMission ~= nil and g_currentMission.getFarmId ~= nil then return tonumber(g_currentMission:getFarmId()) or 0 end
    return 0
end

local function getPlaceablePosition(placeable)
    if placeable == nil then return nil end
    if placeable.getPosition ~= nil then
        local ok, x, y, z = pcall(placeable.getPosition, placeable)
        if ok then return x, y, z end
    end
    local node = placeable.rootNode or placeable.nodeId
    if node ~= nil and node ~= 0 then
        local ok, x, y, z = pcall(getWorldTranslation, node)
        if ok then return x, y, z end
    end
    return nil
end

local function getPlaceableName(placeable)
    if placeable ~= nil and placeable.getName ~= nil then
        local ok, name = pcall(placeable.getName, placeable)
        if ok and name ~= nil and name ~= "" then return tostring(name) end
    end
    local storeItem = placeable ~= nil and placeable.storeItem or nil
    return storeItem ~= nil and tostring(storeItem.name or storeItem.rawName or "Placeable") or "Placeable"
end

local function getPlaceableCategory(placeable)
    if placeable ~= nil and (placeable.spec_husbandryAnimals ~= nil or placeable.spec_husbandry ~= nil) then return "HUSBANDRY" end
    if placeable ~= nil and placeable.spec_fence ~= nil then return "FENCE" end
    local storeItem = placeable ~= nil and placeable.storeItem or nil
    return tostring(storeItem ~= nil and (storeItem.categoryName or storeItem.categoryNameLong or storeItem.category) or "PLACEABLE")
end

local function getPlaceableOwnerFarmId(placeable)
    if placeable == nil then return 0 end
    if placeable.getOwnerFarmId ~= nil then
        local ok, farmId = pcall(placeable.getOwnerFarmId, placeable)
        if ok and farmId ~= nil then return math.floor(tonumber(farmId) or 0) end
    end
    return math.floor(tonumber(placeable.ownerFarmId) or 0)
end

local function getPlaceableFarmlandId(placeable)
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return 0 end
    local x, _, z = getPlaceablePosition(placeable)
    if x == nil then return 0 end
    local ok, farmlandId = pcall(g_farmlandManager.getFarmlandIdAtWorldPosition, g_farmlandManager, x, z)
    return ok and math.floor(tonumber(farmlandId) or 0) or 0
end

local function isFarmlandLinkedFixture(placeable)
    if placeable == nil or placeable.isDeleted == true then return false end
    -- `boughtWithFarmland` is the authoritative GIANTS marker for a fixture
    -- conveyed with a parcel. Some base-map farm fixtures (including Zielonka's
    -- silos, sheds and husbandries) are deliberately saved without isPreplaced,
    -- so requiring that separate lifecycle flag excludes valid landlord assets.
    local conveyedWithFarmland = placeable.boughtWithFarmlandSavegameOverwrite
    if conveyedWithFarmland == nil then conveyedWithFarmland = placeable.boughtWithFarmland end
    return conveyedWithFarmland == true
end

local function getTenancyKey(tenancy)
    if tenancy == nil then return "" end
    return tostring(tenancy.agreementId or tenancy.id or "")
end

local function setPlaceableOwnerFarmId(placeable, farmId, noEventSend)
    if placeable == nil or placeable.setOwnerFarmId == nil then return false, "unsupported" end
    local buysFarmland = placeable.buysFarmland
    if buysFarmland == true then placeable.buysFarmland = false end
    local ok, result = pcall(placeable.setOwnerFarmId, placeable, farmId, noEventSend)
    if buysFarmland == true then placeable.buysFarmland = true end
    if not ok then return false, result end
    return getPlaceableOwnerFarmId(placeable) == math.floor(tonumber(farmId) or 0), result
end

function RFF_TenancyAccessService:getActiveTenancy(farmId, farmlandId)
    farmId = tonumber(farmId) or 0
    farmlandId = tonumber(farmlandId) or 0
    if farmId <= 0 or farmlandId <= 0 then return nil end

    local repository = getRepository()
    if repository == nil then return nil end

    for _, tenancy in ipairs(repository.tenancies or {}) do
        if tenancy ~= nil
            and TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] == true
            and tonumber(tenancy.farmId) == farmId then
            for _, id in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
                if tonumber(id) == farmlandId then return tenancy end
            end
        end
    end
    return nil
end

function RFF_TenancyAccessService:hasAgriculturalAccess(farmId, farmlandId)
    return self:getActiveTenancy(farmId, farmlandId) ~= nil
end

function RFF_TenancyAccessService:hasAgriculturalAccessAtWorldPosition(farmId, x, z)
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return false end
    local farmlandId = g_farmlandManager:getFarmlandIdAtWorldPosition(x, z)
    return self:hasAgriculturalAccess(farmId, farmlandId)
end

function RFF_TenancyAccessService:getActiveTenancyAtWorldPosition(farmId, x, z)
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return nil end
    return self:getActiveTenancy(farmId, g_farmlandManager:getFarmlandIdAtWorldPosition(x, z))
end

function RFF_TenancyAccessService:getActiveTenancyAlongLine(farmId, x1, z1, x2, z2)
    local dx, dz = (x2 or x1) - x1, (z2 or z1) - z1
    local distance = math.sqrt(dx * dx + dz * dz)
    local steps = math.max(1, math.ceil(distance / 3))
    local tenancy = nil
    for index = 0, steps do
        local factor = index / steps
        local candidate = self:getActiveTenancyAtWorldPosition(farmId, x1 + dx * factor, z1 + dz * factor)
        if candidate == nil then return nil end
        if tenancy == nil then tenancy = candidate
        elseif tonumber(tenancy.id) ~= tonumber(candidate.id) then return nil end
    end
    return tenancy
end

function RFF_TenancyAccessService:getActiveTenancyForArea(farmId, sx, sz, wx, wz, hx, hz)
    local tenancy = self:getActiveTenancyAlongLine(farmId, sx, sz, wx, wz)
    if tenancy == nil then return nil end
    local edges = {
        {sx, sz, hx, hz},
        {hx, hz, hx + (wx - sx), hz + (wz - sz)},
        {wx, wz, wx + (hx - sx), wz + (hz - sz)}
    }
    for _, edge in ipairs(edges) do
        local candidate = self:getActiveTenancyAlongLine(farmId, edge[1], edge[2], edge[3], edge[4])
        if candidate == nil or tonumber(candidate.id) ~= tonumber(tenancy.id) then return nil end
    end
    return tenancy
end

function RFF_TenancyAccessService:getActiveTenancyForPlaceablePlacement(placeable, x, z, rotY, farmId)
    local spec = placeable ~= nil and placeable.spec_placement or nil
    if spec == nil or type(spec.testAreas) ~= "table" or #spec.testAreas == 0 then
        return self:getActiveTenancyAtWorldPosition(farmId, x, z)
    end
    local tenancy = nil
    for _, area in ipairs(spec.testAreas) do
        local size = area.size
        local center = area.center
        if size ~= nil and center ~= nil then
            local dirX, dirZ = MathUtil.getDirectionFromYRotation(rotY)
            local normX, _, normZ = MathUtil.crossProduct(0, 1, 0, dirX, 0, dirZ)
            local centerX = x + dirX * center.z + normX * center.x
            local centerZ = z + dirZ * center.z + normZ * center.x
            local halfX, halfZ = size.x * 0.5, size.z * 0.5
            local candidate = self:getActiveTenancyForArea(farmId,
                centerX + dirX * halfZ - normX * halfX, centerZ + dirZ * halfZ - normZ * halfX,
                centerX + dirX * halfZ + normX * halfX, centerZ + dirZ * halfZ + normZ * halfX,
                centerX - dirX * halfZ - normX * halfX, centerZ - dirZ * halfZ - normZ * halfX)
            if candidate == nil then return nil end
            if tenancy == nil then tenancy = candidate
            elseif tonumber(tenancy.id) ~= tonumber(candidate.id) then return nil end
        end
    end
    return tenancy
end

function RFF_TenancyAccessService:getActiveTenancyForPlaceable(farmId, placeable, hitX, hitZ)
    -- The cursor hit is authoritative for a pre-placed map fixture. Some of these
    -- buildings have a root node outside the visible footprint even though the part
    -- selected by the player is on the leased parcel.
    if hitX ~= nil and hitZ ~= nil then
        local tenancy = self:getActiveTenancyAtWorldPosition(farmId, hitX, hitZ)
        if tenancy ~= nil then return tenancy end
    end
    local x, _, z = getPlaceablePosition(placeable)
    return x ~= nil and self:getActiveTenancyAtWorldPosition(farmId, x, z) or nil
end

-- Pre-placed farm fixtures use their placeable/storage owner for silo, husbandry,
-- workshop, farmhouse and animated-object permissions. During a tenancy GIANTS
-- farmland ownership deliberately remains with the NPC estate, so give only the
-- fixtures which the map declares as conveyed with that farmland temporary
-- operational possession. RFF keeps the original legal owner separately and
-- restores it for save serialisation and at handback.
function RFF_TenancyAccessService:getPlaceableLegalOwnerFarmId(placeable)
    local originalOwner = placeable ~= nil and (self._operationalFixtureOriginalOwners[placeable]
        or placeable.rffTenancyFixtureOriginalOwnerFarmId) or nil
    return originalOwner ~= nil and math.floor(tonumber(originalOwner) or 0) or getPlaceableOwnerFarmId(placeable)
end

function RFF_TenancyAccessService:grantTenancyFixturePossession(tenancy)
    local result = {matched=0, granted=0, retained=0, failed=0}
    if tenancy == nil or TENANCY_POSSESSION_STATES[tenancy.status or ""] ~= true
        or g_currentMission == nil or not g_currentMission:getIsServer()
        or g_currentMission.placeableSystem == nil then return result end

    local tenantFarmId = math.floor(tonumber(tenancy.farmId) or 0)
    if tenantFarmId <= 0 then return result end
    local farmlandSet = {}
    for _, value in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
        local farmlandId = math.floor(tonumber(value) or 0)
        if farmlandId > 0 then farmlandSet[farmlandId] = true end
    end
    if next(farmlandSet) == nil then return result end

    local tenancyKey = getTenancyKey(tenancy)
    local nobodyFarmId = AccessHandler ~= nil and AccessHandler.NOBODY or 15
    for _, placeable in pairs(g_currentMission.placeableSystem.placeables or {}) do
        local farmlandId = getPlaceableFarmlandId(placeable)
        if isFarmlandLinkedFixture(placeable) and farmlandSet[farmlandId] == true then
            result.matched = result.matched + 1
            local runtimeOwner = getPlaceableOwnerFarmId(placeable)
            local existingKey = placeable.rffTenancyFixtureAgreementId
                or (self._operationalFixtureTenancies[placeable] ~= nil
                    and getTenancyKey(self._operationalFixtureTenancies[placeable]) or nil)
            local ownerAvailable = runtimeOwner == tenantFarmId
                or runtimeOwner == nobodyFarmId
                or runtimeOwner == (AccessHandler ~= nil and AccessHandler.EVERYONE or 0)
                or runtimeOwner == (FarmlandManager ~= nil and FarmlandManager.NO_OWNER_FARM_ID or 0)
            if existingKey ~= nil and tostring(existingKey) ~= tenancyKey then ownerAvailable = false end

            if ownerAvailable then
                local originalOwner = self._operationalFixtureOriginalOwners[placeable]
                    or placeable.rffTenancyFixtureOriginalOwnerFarmId
                if originalOwner == nil then
                    originalOwner = runtimeOwner ~= tenantFarmId and runtimeOwner or nobodyFarmId
                end
                originalOwner = math.floor(tonumber(originalOwner) or nobodyFarmId)
                self._operationalFixtureOriginalOwners[placeable] = originalOwner
                self._operationalFixtureTenancies[placeable] = tenancy
                placeable.rffTenancyFixtureOriginalOwnerFarmId = originalOwner
                placeable.rffTenancyFixtureAgreementId = tenancyKey
                placeable.rffTenancyFixtureFarmlandId = farmlandId

                if runtimeOwner == tenantFarmId then
                    result.retained = result.retained + 1
                else
                    local granted, reason = setPlaceableOwnerFarmId(placeable, tenantFarmId, false)
                    if granted then
                        result.granted = result.granted + 1
                    else
                        result.failed = result.failed + 1
                        self._operationalFixtureOriginalOwners[placeable] = nil
                        self._operationalFixtureTenancies[placeable] = nil
                        placeable.rffTenancyFixtureOriginalOwnerFarmId = nil
                        placeable.rffTenancyFixtureAgreementId = nil
                        placeable.rffTenancyFixtureFarmlandId = nil
                        print(string.format("[RealisticFarmFinance] Tenancy fixture possession failed agreement=%s land=%d asset=%s owner=%d reason=%s",
                            tenancyKey, farmlandId, getPlaceableName(placeable), runtimeOwner, tostring(reason)))
                    end
                end
            end
        end
    end

    -- Keep a concise result in the game log even when nothing matched. This makes
    -- map-specific fixture metadata or farmland-position issues diagnosable.
    print(string.format("[RealisticFarmFinance] Tenancy fixture possession agreement=%s farm=%d matched=%d granted=%d retained=%d failed=%d",
        tenancyKey, tenantFarmId, result.matched, result.granted, result.retained, result.failed))
    return result
end

function RFF_TenancyAccessService:restoreTenancyFixturePossession(tenancy)
    local result = {restored=0, failed=0}
    if tenancy == nil or g_currentMission == nil or not g_currentMission:getIsServer() then return result end
    local tenancyKey = getTenancyKey(tenancy)
    local matches = {}
    for placeable, linkedTenancy in pairs(self._operationalFixtureTenancies) do
        local linkedKey = placeable ~= nil and (placeable.rffTenancyFixtureAgreementId
            or getTenancyKey(linkedTenancy)) or ""
        if linkedKey == tenancyKey then table.insert(matches, placeable) end
    end

    for _, placeable in ipairs(matches) do
        local originalOwner = self._operationalFixtureOriginalOwners[placeable]
            or placeable.rffTenancyFixtureOriginalOwnerFarmId
        local restored = placeable.isDeleted == true
        local reason = nil
        if not restored and originalOwner ~= nil then
            restored, reason = setPlaceableOwnerFarmId(placeable, originalOwner, false)
        end
        if restored then
            result.restored = result.restored + 1
            self._operationalFixtureOriginalOwners[placeable] = nil
            self._operationalFixtureTenancies[placeable] = nil
            placeable.rffTenancyFixtureOriginalOwnerFarmId = nil
            placeable.rffTenancyFixtureAgreementId = nil
            placeable.rffTenancyFixtureFarmlandId = nil
        else
            result.failed = result.failed + 1
            print(string.format("[RealisticFarmFinance] Tenancy fixture restoration failed agreement=%s asset=%s reason=%s",
                tenancyKey, getPlaceableName(placeable), tostring(reason)))
        end
    end

    if result.restored > 0 or result.failed > 0 then
        print(string.format("[RealisticFarmFinance] Tenancy fixture possession restored agreement=%s restored=%d failed=%d",
            tenancyKey, result.restored, result.failed))
    end
    return result
end

function RFF_TenancyAccessService:synchronizeTenancyFixturePossession()
    local result = {tenancies=0, granted=0, retained=0, failed=0}
    if g_currentMission == nil or not g_currentMission:getIsServer() then return result end
    local repository = getRepository()
    if repository == nil then return result end

    local activeKeys = {}
    for _, tenancy in ipairs(repository.tenancies or {}) do
        if tenancy ~= nil and TENANCY_POSSESSION_STATES[tenancy.status or ""] == true then
            local tenancyKey = getTenancyKey(tenancy)
            activeKeys[tenancyKey] = true
            result.tenancies = result.tenancies + 1
            local tenancyResult = self:grantTenancyFixturePossession(tenancy)
            result.granted = result.granted + tenancyResult.granted
            result.retained = result.retained + tenancyResult.retained
            result.failed = result.failed + tenancyResult.failed
        end
    end

    local orphanedTenancies = {}
    for placeable, linkedTenancy in pairs(self._operationalFixtureTenancies) do
        local linkedKey = placeable ~= nil and (placeable.rffTenancyFixtureAgreementId
            or getTenancyKey(linkedTenancy)) or ""
        if activeKeys[linkedKey] ~= true and linkedTenancy ~= nil then orphanedTenancies[linkedTenancy] = true end
    end
    for linkedTenancy in pairs(orphanedTenancies) do
        local restored = self:restoreTenancyFixturePossession(linkedTenancy)
        result.failed = result.failed + restored.failed
    end
    return result
end

function RFF_TenancyAccessService:canTenantAlterPlaceable(farmId, placeable, hitX, hitZ)
    return self:getActiveTenancyForPlaceable(farmId, placeable, hitX, hitZ) ~= nil
end

function RFF_TenancyAccessService:authorizeFixtureRemoval(farmId, placeable, hitX, hitZ)
    if placeable == nil then return nil end
    local tenancy = self:getActiveTenancyForPlaceable(farmId, placeable, hitX, hitZ)
    if tenancy == nil then
        self._authorizedFixtureRemovals[placeable] = nil
        return nil
    end
    local originalOwner = self:getPlaceableLegalOwnerFarmId(placeable)
    local farmlandId = g_farmlandManager ~= nil and hitX ~= nil
        and g_farmlandManager:getFarmlandIdAtWorldPosition(hitX, hitZ) or 0
    if farmlandId == nil or farmlandId <= 0 then farmlandId = tonumber(tenancy.farmlandId) or 0 end
    local authorization = {
        tenancy=tenancy, farmlandId=farmlandId, farmId=farmId, originalOwner=originalOwner
    }
    self._authorizedFixtureRemovals[placeable] = authorization
    return authorization
end

function RFF_TenancyAccessService:recordPlaceableAlteration(placeable, alterationType, value, farmId, farmlandId)
    local service = getPropertyFinanceService()
    if service == nil or g_currentMission == nil or not g_currentMission:getIsServer() then return nil end
    local x, _, z = getPlaceablePosition(placeable)
    farmId = tonumber(farmId) or (placeable ~= nil and placeable.getOwnerFarmId ~= nil and placeable:getOwnerFarmId()) or 0
    local ownerFarmId = self:getPlaceableLegalOwnerFarmId(placeable)
    local data = {
        farmlandId=farmlandId, ownerFarmId=ownerFarmId, assetName=getPlaceableName(placeable),
        category=getPlaceableCategory(placeable), value=tonumber(value) or 0,
        worldX=x, worldZ=z
    }
    if farmlandId ~= nil and farmlandId > 0 then
        local tenancy = service:getActiveTenancyForFarmland(farmlandId, farmId)
        return service:recordTenancyAlteration(tenancy, alterationType, data)
    end
    if x ~= nil then return service:recordTenancyAlterationAtWorldPosition(farmId, x, z, alterationType, data) end
    return nil
end

-- Public, read-only tenancy API for optional integrations such as Golden Hoof and
-- Freeform Pastures. External mods should keep GIANTS ownership as their first
-- authority and use this only as an additional authorisation route:
--   ownedByFarm OR RFF_TenancyAPI.canFarmUseFarmland(farmId, farmlandId)
-- No hard dependency on RFF is required; callers can simply test that the global
-- table exists and VERSION >= 1.
RFF_TenancyAPI = RFF_TenancyAPI or {}
RFF_TenancyAPI.VERSION = 2

function RFF_TenancyAPI.getVersion()
    return RFF_TenancyAPI.VERSION
end

function RFF_TenancyAPI.hasAgriculturalAccess(farmId, farmlandId)
    return RFF_TenancyAccessService:hasAgriculturalAccess(farmId, farmlandId)
end

function RFF_TenancyAPI.canFarmUseFarmland(farmId, farmlandId)
    return RFF_TenancyAccessService:hasAgriculturalAccess(farmId, farmlandId)
end

function RFF_TenancyAPI.hasAgriculturalAccessAtWorldPosition(farmId, x, z)
    return RFF_TenancyAccessService:hasAgriculturalAccessAtWorldPosition(farmId, x, z)
end

function RFF_TenancyAPI.getTenancySummary(farmId, farmlandId)
    local tenancy = RFF_TenancyAccessService:getActiveTenancy(farmId, farmlandId)
    if tenancy == nil then return nil end
    -- Return a copy so integrations cannot mutate RFF's authoritative agreement.
    return {
        id = tenancy.id,
        agreementId = tenancy.agreementId,
        farmId = tenancy.farmId,
        farmlandId = tenancy.farmlandId,
        farmlandIds = tenancy.farmlandIds,
        status = tenancy.status,
        monthlyRent = tenancy.monthlyRent,
        annualRent = tenancy.annualRent,
        paymentFrequency = tenancy.paymentFrequency,
        rentDue = tenancy.rentDue,
        arrears = tenancy.arrears,
        deposit = tenancy.depositHeld or tenancy.securityDeposit,
        remainingMonths = tenancy.remainingMonths,
        termMonths = tenancy.termMonths
    }
end

function RFF_TenancyAPI.getTenantedFarmlandIds(farmId)
    farmId = tonumber(farmId) or 0
    local result = {}
    if farmId <= 0 then return result end
    local repository = getRepository()
    if repository == nil then return result end
    for _, tenancy in ipairs(repository.tenancies or {}) do
        if tenancy ~= nil and TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] and tonumber(tenancy.farmId) == farmId then
            for _, value in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do
                local farmlandId = tonumber(value) or 0
                if farmlandId > 0 then table.insert(result, farmlandId) end
            end
        end
    end
    table.sort(result)
    return result
end

-- Older RFF tenancy code (and Field Finance before migration) made the tenant the
-- GIANTS farmland owner so field work was possible. Once the access bridge is live,
-- active tenancies no longer need that ownership fiction. Convert only land that is
-- both covered by an active tenancy and currently owned by that same tenant farm.
function RFF_TenancyAccessService:normalizeLegacyOwnership()
    if g_currentMission == nil or not g_currentMission:getIsServer() or g_farmlandManager == nil then return 0 end
    local repository = getRepository()
    if repository == nil then return 0 end

    local converted = 0
    for _, tenancy in ipairs(repository.tenancies or {}) do
        if tenancy ~= nil and tenancy.status == "ACTIVE" then
            local farmId = tonumber(tenancy.farmId) or 0
            local farmlandId = tonumber(tenancy.farmlandId) or 0
            if farmId > 0 and farmlandId > 0 and g_farmlandManager:getFarmlandOwner(farmlandId) == farmId then
                if g_farmlandManager:setLandOwnership(farmlandId, FarmlandManager.NO_OWNER_FARM_ID) then
                    converted = converted + 1
                    if g_messageCenter ~= nil then
                        g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, farmId)
                    end
                    print(string.format("[RealisticFarmFinance] Tenancy POC converted legacy ownership land=%d tenantFarm=%d -> GIANTS owner=%d; agricultural access retained by RFF tenancy",
                        farmlandId, farmId, FarmlandManager.NO_OWNER_FARM_ID))
                end
            end
        end
    end
    return converted
end

function RFF_TenancyAccessService:install()
    if self._installed then return end
    self._installed = true

    -- Operational tenancy possession must never become a permanent ownership
    -- rewrite in placeables.xml. Save each landlord fixture with its legal owner,
    -- then immediately restore the tenant's runtime access after serialisation.
    if Placeable ~= nil and Placeable.saveToXMLFile ~= nil then
        Placeable.saveToXMLFile = Utils.overwrittenFunction(
            Placeable.saveToXMLFile,
            function(placeable, superFunc, xmlFile, key, usedModNames)
                local originalOwner = RFF_TenancyAccessService._operationalFixtureOriginalOwners[placeable]
                    or placeable.rffTenancyFixtureOriginalOwnerFarmId
                local runtimeOwner = getPlaceableOwnerFarmId(placeable)
                if originalOwner == nil or runtimeOwner == math.floor(tonumber(originalOwner) or 0) then
                    return superFunc(placeable, xmlFile, key, usedModNames)
                end

                local restoredForSave, restoreReason = setPlaceableOwnerFarmId(placeable, originalOwner, true)
                if not restoredForSave then
                    print(string.format("[RealisticFarmFinance] Warning: tenancy fixture legal owner could not be applied for save asset=%s reason=%s",
                        getPlaceableName(placeable), tostring(restoreReason)))
                    return superFunc(placeable, xmlFile, key, usedModNames)
                end

                local ok, result = pcall(superFunc, placeable, xmlFile, key, usedModNames)
                local operationalFarmId = RFF_TenancyAccessService._operationalFixtureTenancies[placeable] ~= nil
                    and tonumber(RFF_TenancyAccessService._operationalFixtureTenancies[placeable].farmId) or runtimeOwner
                local regranted, grantReason = setPlaceableOwnerFarmId(placeable, operationalFarmId, true)
                if not regranted then
                    print(string.format("[RealisticFarmFinance] Warning: tenancy fixture operational owner could not be restored after save asset=%s reason=%s",
                        getPlaceableName(placeable), tostring(grantReason)))
                end
                if not ok then error(result) end
                return result
            end
        )
    end

    -- This is the narrowest GIANTS land-access route. A true owner/contractor keeps
    -- the native result. RFF only adds access for an active tenancy. Construction
    -- ownership stays native except for the explicit tenancy-possession hooks below.
    if AccessHandler ~= nil and AccessHandler.canFarmAccessLand ~= nil then
        AccessHandler.canFarmAccessLand = Utils.overwrittenFunction(
            AccessHandler.canFarmAccessLand,
            function(accessHandler, superFunc, farmId, x, z, disallowContracting)
                if superFunc(accessHandler, farmId, x, z, disallowContracting) then
                    return true
                end
                -- A tenancy is not contractor access. GIANTS uses disallowContracting=true
                -- for some actual field-work permission checks, so rejecting the RFF
                -- tenancy here lets the player enter the land but prevents the work area
                -- from modifying the field. Preserve the native result first, then allow
                -- an active tenancy regardless of the contracting flag. Owner-only
                -- operations are handled separately rather than by treating a tenant as
                -- a contractor or changing the GIANTS farmland owner.
                return RFF_TenancyAccessService:hasAgriculturalAccessAtWorldPosition(farmId, x, z)
            end
        )
    end



    -- Field work does not always use AccessHandler:canFarmAccessLand(). The base-game
    -- WorkArea specialization performs its own farmland lookup and then calls the very
    -- broad canFarmAccessOtherId() route. Do NOT widen canFarmAccessOtherId globally: it
    -- is also used for access to objects/placeables. Instead, add tenancy access only at
    -- the agricultural WorkArea boundary. This keeps construction and other owner-only
    -- systems separate while allowing cultivators, ploughs, seeders, sprayers, harvesters,
    -- etc. to work an actively tenanted parcel.
    if WorkArea ~= nil and WorkArea.getIsAccessibleAtWorldPosition ~= nil then
        WorkArea.getIsAccessibleAtWorldPosition = Utils.overwrittenFunction(
            WorkArea.getIsAccessibleAtWorldPosition,
            function(vehicle, superFunc, farmId, x, z, workAreaType)
                local accessible, landOwner, isBuyable = superFunc(vehicle, farmId, x, z, workAreaType)
                if accessible then
                    return accessible, landOwner, isBuyable
                end

                if RFF_TenancyAccessService:hasAgriculturalAccessAtWorldPosition(farmId, x, z) then
                    local farmlandId = g_farmlandManager ~= nil and g_farmlandManager:getFarmlandIdAtWorldPosition(x, z) or 0
                    local ownerFarmId = g_farmlandManager ~= nil and g_farmlandManager:getFarmlandOwner(farmlandId) or FarmlandManager.NO_OWNER_FARM_ID
                    return true, ownerFarmId, true
                end

                return accessible, landOwner, isBuyable
            end
        )
    end

    -- AI field workers use an ownership-specific helper rather than the WorkArea access
    -- result in some validation paths. Extend that AI-only check for active tenancies;
    -- do not alter FarmlandManager:getIsOwnedByFarm* because construction placement also
    -- relies on those ownership functions and must continue to see the tenant as non-owner.
    if AIVehicleUtil ~= nil and AIVehicleUtil.getIsAreaOwned ~= nil then
        local superGetIsAreaOwned = AIVehicleUtil.getIsAreaOwned
        AIVehicleUtil.getIsAreaOwned = function(vehicle, sX, sZ, wX, wZ, hX, hZ)
            if superGetIsAreaOwned(vehicle, sX, sZ, wX, wZ, hX, hZ) then
                return true
            end
            if vehicle == nil or vehicle.getAIJobFarmId == nil then
                return false
            end
            local farmId = vehicle:getAIJobFarmId()
            local centerX, centerZ = (sX + wX) * 0.5, (sZ + wZ) * 0.5
            return RFF_TenancyAccessService:hasAgriculturalAccessAtWorldPosition(farmId, centerX, centerZ)
        end
    end

    -- Some GIANTS systems ask FarmlandManager directly rather than going through
    -- AccessHandler:canFarmAccessLand. Preserve the native answer first, then grant
    -- access only where the exact farmland has an active RFF tenancy for that farm.
    if FarmlandManager ~= nil and FarmlandManager.getCanAccessLandAtWorldPosition ~= nil then
        FarmlandManager.getCanAccessLandAtWorldPosition = Utils.overwrittenFunction(
            FarmlandManager.getCanAccessLandAtWorldPosition,
            function(farmlandManager, superFunc, farmId, worldPosX, worldPosZ)
                if superFunc(farmlandManager, farmId, worldPosX, worldPosZ) then
                    return true
                end
                local farmlandId = farmlandManager:getFarmlandIdAtWorldPosition(worldPosX, worldPosZ)
                return RFF_TenancyAccessService:hasAgriculturalAccess(farmId, farmlandId)
            end
        )
    end

    -- Placeable footprints use a dedicated ownership test after ordinary construction
    -- access succeeds. Accept an entire footprint only when every sampled edge remains
    -- inside the same active agreement; no covenant is used as a physical lock.
    if PlaceablePlacement ~= nil and PlaceablePlacement.getIsAreaOwnedByFarm ~= nil then
        PlaceablePlacement.getIsAreaOwnedByFarm = Utils.overwrittenFunction(
            PlaceablePlacement.getIsAreaOwnedByFarm,
            function(placeable, superFunc, sx, sz, wx, wz, hx, hz, farmId)
                if superFunc(placeable, sx, sz, wx, wz, hx, hz, farmId) then return true end
                return RFF_TenancyAccessService:getActiveTenancyForArea(farmId, sx, sz, wx, wz, hx, hz) ~= nil
            end
        )
    end
    if ConstructionBrushPlaceable ~= nil and ConstructionBrushPlaceable.verifyPlacement ~= nil then
        ConstructionBrushPlaceable.verifyPlacement = Utils.overwrittenFunction(
            ConstructionBrushPlaceable.verifyPlacement,
            function(brush, superFunc, x, y, z, rotY)
                local placeable = brush.placeable
                local rawOriginalCheck = placeable ~= nil and rawget(placeable, "getIsOnOwnedFarmland") or nil
                local originalCheck = placeable ~= nil and placeable.getIsOnOwnedFarmland or nil
                if originalCheck ~= nil then
                    placeable.getIsOnOwnedFarmland = function(target, px, py, pz, rotation)
                        if originalCheck(target, px, py, pz, rotation) then return true end
                        return RFF_TenancyAccessService:getActiveTenancyForPlaceablePlacement(
                            target, px, pz, rotation, getLocalFarmId()) ~= nil
                    end
                end
                local errorCode, message = superFunc(brush, x, y, z, rotY)
                if originalCheck ~= nil then placeable.getIsOnOwnedFarmland = rawOriginalCheck end
                return errorCode, message
            end
        )
    end

    -- Fence validation performs another owner-only line test. Keep overlap and money
    -- checks native, but recognise a segment wholly inside one active tenancy.
    if FenceSegment ~= nil and FenceSegment.getHasBlockingOverlap ~= nil then
        FenceSegment.getHasBlockingOverlap = Utils.overwrittenFunction(
            FenceSegment.getHasBlockingOverlap,
            function(segment, superFunc, farmId)
                local blocked = superFunc(segment, farmId)
                if not blocked or segment.actualEndX == nil then return blocked end
                return RFF_TenancyAccessService:getActiveTenancyAlongLine(
                    farmId, segment.startPosX, segment.startPosZ, segment.actualEndX, segment.actualEndZ) == nil
            end
        )
    end
    if ConstructionBrushNewFence ~= nil and ConstructionBrushNewFence.validateCurrentSegment ~= nil then
        ConstructionBrushNewFence.validateCurrentSegment = Utils.overwrittenFunction(
            ConstructionBrushNewFence.validateCurrentSegment,
            function(brush, superFunc, x, z)
                if superFunc(brush, x, z) then return true end
                if brush.currentSegment == nil then return false end
                local sx, _, sz = brush.currentSegment:getStartPos()
                local farmId = getLocalFarmId()
                if sx == nil or RFF_TenancyAccessService:getActiveTenancyAlongLine(farmId, sx, sz, x, z) == nil then return false end
                local price = brush.currentSegment:getPrice()
                if g_currentMission:getMoney(farmId) < price then return false end
                if price ~= 0 then brush.cursor:setMessage(g_i18n:formatMoney(price)) end
                return true
            end
        )
    end

    -- Landscaping validates four ownership corners on the server. Extend only that
    -- validation function, leaving the broad FarmlandManager ownership API untouched.
    if Landscaping ~= nil and Landscaping.isModificationAreaOnOwnedLand ~= nil then
        local superModificationAreaOnOwnedLand = Landscaping.isModificationAreaOnOwnedLand
        Landscaping.isModificationAreaOnOwnedLand = function(x, z, radius, farmId)
            if superModificationAreaOnOwnedLand(x, z, radius, farmId) then return true end
            return RFF_TenancyAccessService:getActiveTenancyForArea(
                farmId, x - radius, z - radius, x - radius, z + radius, x + radius, z - radius) ~= nil
        end
    end

    -- The demolition brush normally filters by the placeable's owner. Temporarily
    -- relax only the UI-side selection/check for a landlord fixture standing on the
    -- player's active tenancy. The real owner is restored before the confirmed sale
    -- event, so native proceeds still go to the tenant only for tenant-owned assets.
    if ConstructionBrushDestruct ~= nil and ConstructionBrushDestruct.visualizeMouseOver ~= nil then
        ConstructionBrushDestruct.visualizeMouseOver = Utils.overwrittenFunction(
            ConstructionBrushDestruct.visualizeMouseOver,
            function(brush, superFunc)
                local placeable = brush.cursor ~= nil and brush.cursor:getHitPlaceable() or nil
                local farmId = getLocalFarmId()
                local hitX, hitZ = nil, nil
                if brush.cursor ~= nil then local x, _, z = brush.cursor:getPosition(); hitX, hitZ = x, z end
                local originalOwner = placeable ~= nil and placeable.ownerFarmId or nil
                local substitute = placeable ~= nil and originalOwner ~= farmId
                    and RFF_TenancyAccessService:canTenantAlterPlaceable(farmId, placeable, hitX, hitZ)
                if substitute then
                    RFF_TenancyAccessService._temporaryOriginalOwners[placeable] = originalOwner
                    placeable.ownerFarmId = farmId
                end
                local result = superFunc(brush)
                if substitute then
                    placeable.ownerFarmId = originalOwner
                    RFF_TenancyAccessService._temporaryOriginalOwners[placeable] = nil
                end
                return result
            end
        )
    end
    if ConstructionBrushDestruct ~= nil and ConstructionBrushDestruct.onButtonPrimary ~= nil then
        ConstructionBrushDestruct.onButtonPrimary = Utils.overwrittenFunction(
            ConstructionBrushDestruct.onButtonPrimary,
            function(brush, superFunc, isDown, isDrag, isUp)
                local placeable = brush.cursor ~= nil and brush.cursor:getHitPlaceable() or nil
                local farmId = getLocalFarmId()
                local hitX, hitZ = nil, nil
                if brush.cursor ~= nil then local x, _, z = brush.cursor:getPosition(); hitX, hitZ = x, z end
                local originalOwner = placeable ~= nil and placeable.ownerFarmId or nil
                local tenancy = placeable ~= nil and RFF_TenancyAccessService:getActiveTenancyForPlaceable(
                    farmId, placeable, hitX, hitZ) or nil
                local legalOwner = placeable ~= nil and RFF_TenancyAccessService:getPlaceableLegalOwnerFarmId(placeable) or originalOwner
                local landlordFixture = tenancy ~= nil and tonumber(legalOwner) ~= tonumber(farmId)
                local substitute = placeable ~= nil and originalOwner ~= farmId
                    and tenancy ~= nil
                if landlordFixture then
                    local authorization = RFF_TenancyAccessService:authorizeFixtureRemoval(farmId, placeable, hitX, hitZ)
                    if placeable:getDestructionMethod() ~= Placeable.DESTRUCTION.PER_NODE then
                        if isUp then brush.lastDragPlaceable = nil end
                        if isDown and not isDrag and brush:hasPlayerPermission() then
                            local canBeSold, warning = placeable:canBeSold()
                            local function confirmRemoval(yes)
                                if yes then
                                    print(string.format("[RealisticFarmFinance] Sending authorised tenancy fixture removal agreement=%s land=%d asset=%s originalOwner=%s",
                                        tostring(authorization.tenancy.agreementId or authorization.tenancy.id),
                                        tonumber(authorization.farmlandId) or 0, getPlaceableName(placeable), tostring(authorization.originalOwner)))
                                    g_client:getServerConnection():sendEvent(SellPlaceableEvent.new(placeable, true, false))
                                end
                            end
                            if warning == nil then
                                local text = string.format(g_i18n:getText("ui_constructionSellConfirmation"),
                                    placeable:getName(), g_i18n:formatMoney(0, 0, true, true))
                                YesNoDialog.show(confirmRemoval, nil, text)
                            elseif canBeSold then
                                YesNoDialog.show(confirmRemoval, nil, warning, nil,
                                    g_i18n:getText("button_ok"), g_i18n:getText("button_cancel"))
                            else
                                InfoDialog.show(warning, nil, nil, nil,
                                    g_i18n:getText("button_back"), InputAction.MENU_BACK)
                            end
                        end
                        return
                    end
                    if substitute then
                        RFF_TenancyAccessService._temporaryOriginalOwners[placeable] = originalOwner
                        placeable.ownerFarmId = farmId
                    end
                end
                local result = superFunc(brush, isDown, isDrag, isUp)
                if substitute then
                    placeable.ownerFarmId = originalOwner
                    RFF_TenancyAccessService._temporaryOriginalOwners[placeable] = nil
                end
                return result
            end
        )
    end

    -- The normal construction selection screen opens PlaceableInfoDialog instead
    -- of demolition mode. Authorise the fixture from the cursor before that dialog
    -- evaluates its owner, then expose a zero-proceeds sell button for the tenant.
    if ConstructionBrushSelect ~= nil and ConstructionBrushSelect.onButtonPrimary ~= nil then
        ConstructionBrushSelect.onButtonPrimary = Utils.overwrittenFunction(
            ConstructionBrushSelect.onButtonPrimary,
            function(brush, superFunc, ...)
                local placeable = brush.lastPlaceable
                if placeable ~= nil and placeable.isDeleted ~= true and brush.cursor ~= nil then
                    local hitX, _, hitZ = brush.cursor:getPosition()
                    RFF_TenancyAccessService:authorizeFixtureRemoval(getLocalFarmId(), placeable, hitX, hitZ)
                end
                return superFunc(brush, ...)
            end
        )
    end
    if PlaceableInfoDialog ~= nil and PlaceableInfoDialog.setPlaceable ~= nil then
        PlaceableInfoDialog.setPlaceable = Utils.overwrittenFunction(
            PlaceableInfoDialog.setPlaceable,
            function(dialog, superFunc, placeable)
                local authorization = placeable ~= nil and RFF_TenancyAccessService._authorizedFixtureRemovals[placeable] or nil
                local farmId = getLocalFarmId()
                local substitute = authorization ~= nil and tonumber(authorization.farmId) == farmId
                    and tonumber(authorization.originalOwner) ~= farmId
                local originalOwner = substitute and placeable.ownerFarmId or nil
                if substitute then placeable.ownerFarmId = farmId end
                local result = superFunc(dialog, placeable)
                if substitute then
                    placeable.ownerFarmId = originalOwner
                    if dialog.priceText ~= nil then dialog.priceText:setText(g_i18n:formatMoney(0)) end
                end
                return result
            end
        )
    end

    -- Record successful purchases after native placement has completed.
    if BuyPlaceableData ~= nil and BuyPlaceableData.onBought ~= nil then
        BuyPlaceableData.onBought = Utils.appendedFunction(
            BuyPlaceableData.onBought,
            function(data, placeable, loadingState, arguments)
                if placeable ~= nil and loadingState == PlaceableLoadingState.OK then
                    RFF_TenancyAccessService:recordPlaceableAlteration(
                        placeable, "PLACEABLE_BUILT", (tonumber(data.price) or 0) + (tonumber(data.displacementCosts) or 0), data.ownerFarmId)
                end
            end
        )
    end

    -- Capture sale/removal evidence before native deletion. Tenant-owned assets
    -- retain GIANTS' normal proceeds. A removable preplaced fixture is deleted
    -- for free because the tenant does not own the landlord's asset.
    if SellPlaceableEvent ~= nil and SellPlaceableEvent.run ~= nil then
        SellPlaceableEvent.run = Utils.overwrittenFunction(
            SellPlaceableEvent.run,
            function(event, superFunc, connection)
                local capture = nil
                local nativeOwnerRestore = nil
                if connection ~= nil and not connection:getIsServer() and event.placeable ~= nil and g_currentMission:getIsServer() then
                    local placeable = event.placeable
                    local x, _, z = getPlaceablePosition(placeable)
                    local authorization = RFF_TenancyAccessService._authorizedFixtureRemovals[placeable]
                    local farmId = authorization ~= nil and tonumber(authorization.farmId) or getLocalFarmId()
                    local farmlandId = authorization ~= nil and authorization.farmlandId
                        or (x ~= nil and g_farmlandManager:getFarmlandIdAtWorldPosition(x, z) or 0)
                    local tenancy = getPropertyFinanceService() ~= nil
                        and getPropertyFinanceService():getActiveTenancyForFarmland(farmlandId, farmId) or nil
                    local actualOwner = authorization ~= nil and authorization.originalOwner
                        or RFF_TenancyAccessService._temporaryOriginalOwners[placeable]
                        or RFF_TenancyAccessService:getPlaceableLegalOwnerFarmId(placeable)
                    local hasPermission = g_currentMission:getHasPlayerPermission("sellPlaceable", connection)
                    local canSell = placeable.canBeSold == nil or placeable:canBeSold()
                    if tenancy ~= nil and hasPermission and canSell then
                        local sellValue = placeable.getSellPrice ~= nil and placeable:getSellPrice() or 0
                        capture = {
                            tenancy=tenancy, farmlandId=farmlandId,
                            ownerFarmId=actualOwner,
                            assetName=getPlaceableName(placeable), category=getPlaceableCategory(placeable), value=sellValue,
                            worldX=x, worldZ=z,
                            forceDelete=tonumber(actualOwner) ~= tonumber(tenancy.farmId)
                                and placeable.canBeDeleted ~= false and placeable.canBeDeletedOverwrite ~= false
                        }
                        if tonumber(actualOwner) ~= tonumber(tenancy.farmId) then
                            -- A pre-existing landlord/map fixture may be removed but is
                            -- never sold for the tenant's benefit. Use the spectator farm
                            -- only while native deletion runs so GIANTS is not asked to
                            -- credit its NOBODY/invalid owner ID.
                            event.forFree = true
                            nativeOwnerRestore = placeable.ownerFarmId
                            placeable.ownerFarmId = FarmManager.SPECTATOR_FARM_ID
                        elseif RFF_TenancyAccessService._temporaryOriginalOwners[placeable] ~= nil then
                            placeable.ownerFarmId = actualOwner
                        end
                        print(string.format("[RealisticFarmFinance] Authorised tenancy fixture removal received agreement=%s land=%d asset=%s originalOwner=%s forceDelete=%s",
                            tostring(tenancy.agreementId or tenancy.id), tonumber(farmlandId) or 0,
                            getPlaceableName(placeable), tostring(actualOwner), tostring(capture.forceDelete)))
                    end
                end
                local result = superFunc(event, connection)
                if capture ~= nil then
                    -- A preplaced object on land which GIANTS still regards as
                    -- public normally changes to the spectator farm instead of
                    -- disappearing. The tenancy authorisation makes that one
                    -- successful, otherwise-native sale an actual free removal.
                    if capture.forceDelete and event.placeable ~= nil
                        and event.placeable.markedForDeletion ~= true
                        and event.placeable.isDeleting ~= true and event.placeable.isDeleted ~= true then
                        event.placeable:delete()
                    end
                    local removalCompleted = event.placeable == nil
                        or event.placeable.markedForDeletion == true
                        or event.placeable.isDeleting == true or event.placeable.isDeleted == true
                    if removalCompleted then
                        getPropertyFinanceService():recordTenancyAlteration(capture.tenancy, "PLACEABLE_REMOVED", capture)
                    end
                    if event.placeable ~= nil then
                        RFF_TenancyAccessService._authorizedFixtureRemovals[event.placeable] = nil
                    end
                end
                if nativeOwnerRestore ~= nil and event.placeable ~= nil and event.placeable.isDeleted ~= true then
                    event.placeable.ownerFarmId = nativeOwnerRestore
                end
                return result
            end
        )
    end

    if FenceNewSegmentEvent ~= nil and FenceNewSegmentEvent.run ~= nil then
        FenceNewSegmentEvent.run = Utils.appendedFunction(
            FenceNewSegmentEvent.run,
            function(event, connection)
                if event.fencePlaceable == nil or event.segment == nil or g_currentMission == nil or not g_currentMission:getIsServer() then return end
                local x, _, z = event.segment:getEndPos()
                local farmId = event.fencePlaceable:getOwnerFarmId()
                local service = getPropertyFinanceService()
                if service ~= nil then
                    service:recordTenancyAlterationAtWorldPosition(farmId, x, z, "FENCE_BUILT", {
                        ownerFarmId=farmId, assetName=getPlaceableName(event.fencePlaceable), category="FENCE",
                        value=event.segment:getPrice()
                    })
                end
            end
        )
    end

    if FenceDeleteSegmentEvent ~= nil and FenceDeleteSegmentEvent.run ~= nil then
        FenceDeleteSegmentEvent.run = Utils.overwrittenFunction(
            FenceDeleteSegmentEvent.run,
            function(event, superFunc, connection)
                local capture = nil
                if event.fencePlaceable ~= nil and g_currentMission ~= nil and g_currentMission:getIsServer() then
                    local fence = event.fencePlaceable:getFence()
                    local segment = fence ~= nil and fence:getSegmentById(event.segmentId) or nil
                    if segment ~= nil then
                        local x, _, z = segment:getEndPos()
                        capture = {x=x, z=z, farmId=getLocalFarmId(), ownerFarmId=event.fencePlaceable:getOwnerFarmId(),
                            assetName=getPlaceableName(event.fencePlaceable), category="FENCE", value=segment:getPrice()}
                    end
                end
                local result = superFunc(event, connection)
                if capture ~= nil and getPropertyFinanceService() ~= nil then
                    getPropertyFinanceService():recordTenancyAlterationAtWorldPosition(
                        capture.farmId, capture.x, capture.z, "FENCE_REMOVED", capture)
                end
                return result
            end
        )
    end

    if Landscaping ~= nil and Landscaping.onSculptingApplied ~= nil then
        Landscaping.onSculptingApplied = Utils.appendedFunction(
            Landscaping.onSculptingApplied,
            function(landscaping, errorCode, displacedVolumeOrArea)
                if errorCode ~= TerrainDeformation.STATE_SUCCESS or landscaping.validateOnly or g_currentMission == nil or not g_currentMission:getIsServer() then return end
                local farm = g_farmManager ~= nil and g_farmManager:getFarmByUserId(landscaping.userId) or nil
                local service = getPropertyFinanceService()
                if farm ~= nil and service ~= nil then
                    local operationNames = {
                        [Landscaping.OPERATION.RAISE]="raise terrain", [Landscaping.OPERATION.LOWER]="lower terrain",
                        [Landscaping.OPERATION.SMOOTH]="smooth terrain", [Landscaping.OPERATION.FLATTEN]="flatten terrain",
                        [Landscaping.OPERATION.PAINT]="paint ground", [Landscaping.OPERATION.FOLIAGE]="change foliage",
                        [Landscaping.OPERATION.SLOPE]="create slope"
                    }
                    service:recordTenancyAlterationAtWorldPosition(farm:getId(), landscaping.targetPositionX, landscaping.targetPositionZ,
                        "LANDSCAPING", {ownerFarmId=farm:getId(), assetName="Landscaping works", category="LANDSCAPING",
                            value=landscaping:getCost(displacedVolumeOrArea), details=operationNames[landscaping.sculptingOperation] or "landscaping"})
                end
            end
        )
    end

    print("[RealisticFarmFinance] Contract-backed tenancy access installed (agricultural work + tenant alterations + operational landlord fixtures; legal ownership preserved)")
    print("[RealisticFarmFinance] RFF_TenancyAPI v2 available for optional integrations")
end
