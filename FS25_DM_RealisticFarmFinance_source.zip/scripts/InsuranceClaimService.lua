RFF_InsuranceClaimService = {}
RFF_InsuranceClaimService.__index = RFF_InsuranceClaimService

-- Legacy pre-v0.9.2.3 state retained only so old test records still load safely.
RFF_InsuranceClaimService.STATUS_AWAITING_SUBMISSION = "AWAITING_SUBMISSION"
RFF_InsuranceClaimService.STATUS_UNDER_REVIEW = "UNDER_REVIEW"
RFF_InsuranceClaimService.STATUS_APPROVED = "APPROVED"
RFF_InsuranceClaimService.STATUS_DECLINED = "DECLINED"
RFF_InsuranceClaimService.STATUS_PAID = "PAID"
RFF_InsuranceClaimService.STATUS_AWAITING_RESPONSE = "AWAITING_RESPONSE"
RFF_InsuranceClaimService.STATUS_AWAITING_ADS_INSPECTION = "AWAITING_ADS_INSPECTION"
RFF_InsuranceClaimService.STATUS_AWAITING_OEM_REPAIR = "AWAITING_OEM_REPAIR"
RFF_InsuranceClaimService.STATUS_DEFAULTED = "DEFAULTED"
RFF_InsuranceClaimService.STATUS_SETTLED = "SETTLED"

RFF_InsuranceClaimService.DEATH_RECORDED = "RECORDED"
RFF_InsuranceClaimService.DEATH_CLAIMED = "CLAIMED"
RFF_InsuranceClaimService.DEATH_EXPIRED = "EXPIRED"
-- Compatibility aliases for v0.9.2.3/v0.9.2.4 saves and callers. These are death records, not claims.
RFF_InsuranceClaimService.LOSS_CLAIMABLE = RFF_InsuranceClaimService.DEATH_RECORDED
RFF_InsuranceClaimService.LOSS_CLAIMED = RFF_InsuranceClaimService.DEATH_CLAIMED
RFF_InsuranceClaimService.LOSS_EXPIRED = RFF_InsuranceClaimService.DEATH_EXPIRED
RFF_InsuranceClaimService.CLAIM_WINDOW_PERIODS = 2

RFF_InsuranceClaimService.INSURER_ID = "AGRICULTURAL_MUTUAL"
RFF_InsuranceClaimService.INSURER_NAME = "Agricultural Mutual"

RFF_InsuranceClaimService.LIVESTOCK_TERMS = {
    BASIC = {
        indemnity = 0.70, excess = 100,
        accidentalCovered = true, healthCovered = false,
        veterinaryCovered = false, missingCovered = false,
        oldAgeCovered = false, neglectCovered = false
    },
    STANDARD = {
        indemnity = 0.85, excess = 75,
        accidentalCovered = true, healthCovered = true,
        veterinaryCovered = false, missingCovered = false,
        oldAgeCovered = false, neglectCovered = false
    },
    COMPREHENSIVE = {
        indemnity = 0.95, excess = 50,
        accidentalCovered = true, healthCovered = true,
        veterinaryCovered = true, veterinaryIndemnity = 0.85, veterinaryExcess = 35,
        missingCovered = true, missingIndemnity = 0.85, missingExcess = 50,
        oldAgeCovered = false, neglectCovered = false
    }
}

-- RLRM bills configured disease treatment monthly. Comprehensive veterinary expenses
-- remain claimable for three periods so a multi-month course (for example a three-month
-- treatment) can be submitted together rather than forcing one insurance claim per tick.
RFF_InsuranceClaimService.VET_CLAIM_WINDOW_PERIODS = 3
RFF_InsuranceClaimService.VET_EXPENSE_RECORDED = "RECORDED"
RFF_InsuranceClaimService.VET_EXPENSE_CLAIMED = "CLAIMED"
RFF_InsuranceClaimService.VET_EXPENSE_EXPIRED = "EXPIRED"
RFF_InsuranceClaimService.TRAFFIC_INCIDENT_RECORDED = "RECORDED"
RFF_InsuranceClaimService.TRAFFIC_INCIDENT_CLAIMED = "CLAIMED"
RFF_InsuranceClaimService.TRAFFIC_INCIDENT_EXPIRED = "EXPIRED"
RFF_InsuranceClaimService.VEHICLE_CLAIM_WINDOW_PERIODS = 2
RFF_InsuranceClaimService.TRAFFIC_WORKFLOW_VERSION = 2
RFF_InsuranceClaimService.TRAFFIC_RESPONSE_WINDOW_PERIODS = 1
RFF_InsuranceClaimService.TRAFFIC_GROUP_WINDOW_MS = 2000
RFF_InsuranceClaimService.TRAFFIC_GROUP_DISTANCE_METRES = 5
RFF_InsuranceClaimService.LICENCE_SNAPSHOT_VERSION = 1

RFF_InsuranceClaimService.TRAFFIC_SEVERITY_RANK = {
    UNKNOWN = 0, MINOR = 1, MODERATE = 2, SERIOUS = 3, SEVERE = 4
}

RFF_InsuranceClaimService.TRAFFIC_OWN_DAMAGE_RATE = {
    MINOR = 0.010,
    MODERATE = 0.040,
    SERIOUS = 0.120,
    SEVERE = 0.300,
    UNKNOWN = 0.020
}

RFF_InsuranceClaimService.TRAFFIC_OWN_DAMAGE_MINIMUM = {
    MINOR = 250,
    MODERATE = 750,
    SERIOUS = 2500,
    SEVERE = 8000,
    UNKNOWN = 500
}

local function safeNumber(value)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then
        return value
    end
    return 0
end

local function clamp(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, value))
end

local function roundReserve(value)
    return math.max(0, math.floor(math.max(0, safeNumber(value)) / 25 + 0.5) * 25)
end

local function normaliseIdentifier(value)
    return string.lower(tostring(value or "")):gsub("[^%w]+", "")
end

local function appendUniqueDelimited(existing, value)
    existing = tostring(existing or "")
    value = tostring(value or "")
    if value == "" then return existing end
    local padded = "," .. existing .. ","
    if string.find(padded, "," .. value .. ",", 1, true) ~= nil then return existing end
    return existing == "" and value or (existing .. "," .. value)
end

local function mergeEvidenceText(existing, value)
    existing = tostring(existing or "")
    value = tostring(value or "")
    if value == "" then return existing end
    if existing == "" then return value end
    if string.find(existing, value, 1, true) ~= nil then return existing end
    return existing .. "; " .. value
end

local function otherMoneyType()
    return MoneyType ~= nil and MoneyType.OTHER or nil
end

local function formatMoney(value)
    if g_i18n ~= nil and g_i18n.formatMoney ~= nil then
        return g_i18n:formatMoney(math.max(0, safeNumber(value)), 0, true, true)
    end
    return string.format("£%.0f", math.max(0, safeNumber(value)))
end

function RFF_InsuranceClaimService.new(repository, businessAdministration, fleetManagement, vehicleCompliance)
    local self = setmetatable({}, RFF_InsuranceClaimService)
    self.repository = repository
    self.businessAdministration = businessAdministration
    self.fleetManagement = fleetManagement
    -- VehicleCompliance remains authoritative for the principal operator's
    -- category and ADR position. InsuranceClaimService freezes that evidence at
    -- the collision so a later qualification or mode change cannot rewrite it.
    self.vehicleCompliance = vehicleCompliance
    self.rlrHookAvailable = nil
    self.rlrSafetyHookAvailable = false
    self.rlrTreatmentHookAvailable = nil
    self._hookRetryMs = 0
    self._trafficCourtesyRetryMs = 0
    self._trafficCourtesyRegistered = false
    self._trafficCourtesyApi = nil
    self._trafficCourtesyLookupWarningLogged = false
    self._technicalEvidenceRetryMs = 0
    self._reportedDeathKeys = {}
    self._reportedTreatmentKeys = {}
    self._pendingDeathReasonByAnimal = setmetatable({}, { __mode = "k" })
    self._rlrmAnimalClass = nil
    self._rlrmLiveClassWrapper = nil
    self._rlrmTreatmentClass = nil
    self._rlrmTreatmentWrapper = nil
    return self
end

function RFF_InsuranceClaimService:normaliseLicenceSnapshot(source)
    source = type(source) == "table" and source or {}
    local version = math.max(0, math.floor(safeNumber(source.licenceSnapshotVersion)))
    if version < self.LICENCE_SNAPSHOT_VERSION then
        return {
            licenceSnapshotVersion=0, licenceModeAtIncident="", licenceRequiredCategory="",
            licenceEntitlementHeld=false, licenceSpecialistRevoked=false,
            licenceRulesApplied=false, licenceAdrRequired=false, licenceAdrHeld=false,
            licenceHazardousLoadName="", licenceHazardousLoadLevel=0,
            licenceCategoryBreach=false, licenceAdrBreach=false,
            licenceComplianceStatus="NOT_ASSESSED"
        }
    end

    local rulesApplied = source.licenceRulesApplied == true
    local entitlementHeld = source.licenceEntitlementHeld == true
    local adrRequired = source.licenceAdrRequired == true
    local adrHeld = source.licenceAdrHeld == true
    local categoryBreach = rulesApplied and not entitlementHeld
    local adrBreach = rulesApplied and adrRequired and not adrHeld
    local status = "COMPLIANT"
    if not rulesApplied then status = "NOT_APPLICABLE"
    elseif categoryBreach and adrBreach then status = "CATEGORY_AND_ADR_MISSING"
    elseif categoryBreach then status = "CATEGORY_MISSING"
    elseif adrBreach then status = "ADR_MISSING" end

    return {
        licenceSnapshotVersion=self.LICENCE_SNAPSHOT_VERSION,
        licenceModeAtIncident=tostring(source.licenceModeAtIncident or "FULL"),
        licenceRequiredCategory=tostring(source.licenceRequiredCategory or ""),
        licenceEntitlementHeld=entitlementHeld,
        licenceSpecialistRevoked=source.licenceSpecialistRevoked == true,
        licenceRulesApplied=rulesApplied,
        licenceAdrRequired=adrRequired,
        licenceAdrHeld=adrHeld,
        licenceHazardousLoadName=tostring(source.licenceHazardousLoadName or ""),
        licenceHazardousLoadLevel=math.max(0, safeNumber(source.licenceHazardousLoadLevel)),
        licenceCategoryBreach=categoryBreach,
        licenceAdrBreach=adrBreach,
        licenceComplianceStatus=status
    }
end

function RFF_InsuranceClaimService:captureLicenceSnapshot(farmId, vehicleUniqueId, policyCompliance, context)
    if self.vehicleCompliance == nil or type(self.vehicleCompliance.getAssessment) ~= "function" then
        return self:normaliseLicenceSnapshot(nil)
    end
    context = context or {}
    local vehicle = policyCompliance ~= nil and policyCompliance.vehicle or nil
    if vehicle == nil and self.fleetManagement ~= nil then
        vehicle = self.fleetManagement:findVehicle(farmId, vehicleUniqueId)
    end
    local assessment = nil
    if vehicle ~= nil then
        assessment = self.vehicleCompliance:getAssessment(farmId, vehicle, context)
    else
        assessment = self.vehicleCompliance:getAssessment(farmId, vehicleUniqueId, context)
    end
    if assessment == nil then return self:normaliseLicenceSnapshot(nil) end

    local record = assessment.qualificationRecord or {}
    return self:normaliseLicenceSnapshot({
        licenceSnapshotVersion=self.LICENCE_SNAPSHOT_VERSION,
        licenceModeAtIncident=record.licenceMode or "FULL",
        licenceRequiredCategory=assessment.requiredCategory or "",
        licenceEntitlementHeld=assessment.entitlementHeld == true,
        licenceSpecialistRevoked=record.specialistRevoked == true,
        licenceRulesApplied=assessment.roadRulesApply == true,
        licenceAdrRequired=assessment.hazardousLoad == true,
        licenceAdrHeld=assessment.adrHeld == true,
        licenceHazardousLoadName=assessment.hazardousLoadName or "",
        licenceHazardousLoadLevel=assessment.hazardousLoadLevel or 0
    })
end

function RFF_InsuranceClaimService:applyLicenceSnapshot(target, source)
    if target == nil then return nil end
    local snapshot = self:normaliseLicenceSnapshot(source)
    for key, value in pairs(snapshot) do target[key] = value end
    return target
end

function RFF_InsuranceClaimService:hasLicenceClaimBreach(source)
    local snapshot = self:normaliseLicenceSnapshot(source)
    return snapshot.licenceSnapshotVersion >= self.LICENCE_SNAPSHOT_VERSION
        and (snapshot.licenceCategoryBreach or snapshot.licenceAdrBreach), snapshot
end

function RFF_InsuranceClaimService:getLicenceClaimReason(source)
    local breach, snapshot = self:hasLicenceClaimBreach(source)
    if not breach then return nil end
    if snapshot.licenceCategoryBreach and snapshot.licenceAdrBreach then return "DRIVING_LICENCE_AND_ADR_NOT_HELD" end
    if snapshot.licenceAdrBreach then return "ADR_NOT_HELD" end
    return "DRIVING_LICENCE_NOT_HELD"
end

function RFF_InsuranceClaimService:getLicenceDecisionSummary(source)
    local snapshot = self:normaliseLicenceSnapshot(source)
    if snapshot.licenceSnapshotVersion < self.LICENCE_SNAPSHOT_VERSION then return "" end
    if not snapshot.licenceRulesApplied then
        return "Non-road operation: specialist road-licence conditions did not apply at the collision."
    end
    local category = snapshot.licenceRequiredCategory ~= "" and snapshot.licenceRequiredCategory or "required"
    local parts = {string.format("Category %s %s", category, snapshot.licenceEntitlementHeld and "held" or "not held")}
    if snapshot.licenceAdrRequired then
        local load = snapshot.licenceHazardousLoadName ~= "" and (" for " .. snapshot.licenceHazardousLoadName) or ""
        parts[#parts + 1] = string.format("ADR %s%s", snapshot.licenceAdrHeld and "held" or "not held", load)
    end
    local breach = snapshot.licenceCategoryBreach or snapshot.licenceAdrBreach
    return string.format("Licence at collision: %s%s.", table.concat(parts, "; "), breach and " - breach recorded" or "")
end

function RFF_InsuranceClaimService:getCurrentDay()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return env ~= nil and math.floor(safeNumber(env.currentMonotonicDay)) or 0
end

function RFF_InsuranceClaimService:getCurrentPeriod()
    if self.repository ~= nil and self.repository.getCurrentPeriodIndex ~= nil then
        return self.repository:getCurrentPeriodIndex()
    end
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    if env == nil then return 0 end
    return (env.currentYear or 0) * 12 + (env.currentPeriod or 0)
end

function RFF_InsuranceClaimService:getDaysPerPeriod()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return math.max(1, math.floor(safeNumber(env ~= nil and env.daysPerPeriod or 1)))
end

function RFF_InsuranceClaimService:getAssessmentDelayDays()
    return math.max(1, math.floor(self:getDaysPerPeriod() * 0.20 + 0.5))
end

function RFF_InsuranceClaimService:getSettlementDelayDays()
    return math.max(1, math.floor(self:getDaysPerPeriod() * 0.12 + 0.5))
end

function RFF_InsuranceClaimService:getTerms(tierId)
    return self.LIVESTOCK_TERMS[tierId or "STANDARD"] or self.LIVESTOCK_TERMS.STANDARD
end

function RFF_InsuranceClaimService:getClaimReference(claim)
    return string.format("AM-%04d", claim ~= nil and (claim.id or 0) or 0)
end

function RFF_InsuranceClaimService:getLossReference(loss)
    return string.format("LOSS-%04d", loss ~= nil and (loss.id or 0) or 0)
end

function RFF_InsuranceClaimService:notify(farmId, title, message)
    if RFF_NotificationService == nil then return false end
    return RFF_NotificationService:send(
        farmId,
        self.INSURER_NAME,
        title,
        message,
        "insurance",
        message,
        true
    )
end

function RFF_InsuranceClaimService:notifyLoss(farmId, title, message)
    if RFF_NotificationService == nil then return false end
    return RFF_NotificationService:send(
        farmId,
        "Farm Insurance",
        title,
        message,
        "insurance",
        message,
        true
    )
end

function RFF_InsuranceClaimService:getAnimalOwnerFarmId(animal)
    if animal == nil then return 0 end
    local clusterSystem = animal.clusterSystem
    local owner = clusterSystem ~= nil and clusterSystem.owner or nil
    if owner ~= nil then
        if owner.getOwnerFarmId ~= nil then
            local ok, farmId = pcall(owner.getOwnerFarmId, owner)
            if ok and safeNumber(farmId) > 0 then return math.floor(farmId) end
        end
        if safeNumber(owner.ownerFarmId) > 0 then return math.floor(owner.ownerFarmId) end
    end
    if safeNumber(animal.ownerFarmId) > 0 then return math.floor(animal.ownerFarmId) end
    return 0
end

function RFF_InsuranceClaimService:getAnimalTypeCode(animal)
    if animal == nil then return "UNKNOWN" end
    local typeIndex = animal.animalTypeIndex
    if AnimalType ~= nil then
        if typeIndex == AnimalType.SHEEP then return "SHEEP" end
        if typeIndex == AnimalType.COW then return "COW" end
        if AnimalType.PIG ~= nil and typeIndex == AnimalType.PIG then return "PIG" end
        if AnimalType.CHICKEN ~= nil and typeIndex == AnimalType.CHICKEN then return "CHICKEN" end
    end
    local subtype = string.upper(tostring(animal.subType or animal.breed or ""))
    if string.find(subtype, "SHEEP", 1, true) ~= nil or string.find(subtype, "RAM", 1, true) ~= nil then return "SHEEP" end
    if string.find(subtype, "COW", 1, true) ~= nil or string.find(subtype, "CATTLE", 1, true) ~= nil then return "COW" end
    return "UNKNOWN"
end

function RFF_InsuranceClaimService:getAnimalMarketValue(animal)
    if animal == nil then return 0 end
    if animal.getSellPrice ~= nil then
        local ok, value = pcall(animal.getSellPrice, animal)
        if ok and safeNumber(value) > 0 then return safeNumber(value) end
    end

    local animalSystem = g_currentMission ~= nil and g_currentMission.animalSystem or nil
    local subType = animalSystem ~= nil and animalSystem.subTypes ~= nil and animalSystem.subTypes[animal.subTypeIndex] or nil
    if subType ~= nil and subType.sellPrice ~= nil and subType.sellPrice.get ~= nil then
        local ok, unitPrice = pcall(subType.sellPrice.get, subType.sellPrice, animal.age or 0)
        if ok and safeNumber(unitPrice) > 0 then
            local health = math.max(0, math.min(100, safeNumber(animal.health))) / 100
            return math.max(0, safeNumber(unitPrice) * (0.4 + 0.6 * health))
        end
    end
    return 0
end

function RFF_InsuranceClaimService:normaliseDeathReason(reason)
    local value = tostring(reason or "")
    if value == "rl_death_accident" or value == "ACCIDENT" then return "ACCIDENT" end
    if value == "rl_death_health" or value == "HEALTH" then return "HEALTH" end
    if value == "rl_death_age" or value == "OLD_AGE" then return "OLD_AGE" end
    return "UNKNOWN"
end

function RFF_InsuranceClaimService:isPolicyInForce(status)
    return status == "ACTIVE" or status == "GRACE" or status == "TEMPORARY"
end

function RFF_InsuranceClaimService:getVeterinaryExpenseMonthsRemaining(expense)
    if expense == nil or expense.status ~= self.VET_EXPENSE_RECORDED then return 0 end
    local deadline = expense.deadlinePeriod or ((expense.incidentPeriod or self:getCurrentPeriod()) + self.VET_CLAIM_WINDOW_PERIODS)
    return math.max(0, deadline - self:getCurrentPeriod())
end

function RFF_InsuranceClaimService:isVeterinaryExpenseExpired(expense)
    if expense == nil then return true end
    if expense.status == self.VET_EXPENSE_EXPIRED then return true end
    if expense.status ~= self.VET_EXPENSE_RECORDED then return false end
    local deadline = expense.deadlinePeriod or ((expense.incidentPeriod or self:getCurrentPeriod()) + self.VET_CLAIM_WINDOW_PERIODS)
    return self:getCurrentPeriod() >= deadline
end

function RFF_InsuranceClaimService:getEligibleVeterinaryExpenses(farmId)
    local result = {}
    if self.repository == nil or self.repository.getInsuranceVeterinaryExpensesByFarm == nil then return result end
    for _, expense in ipairs(self.repository:getInsuranceVeterinaryExpensesByFarm(farmId) or {}) do
        local terms = self:getTerms(expense.policyTier)
        if expense.status == self.VET_EXPENSE_RECORDED
            and not self:isVeterinaryExpenseExpired(expense)
            and self:isPolicyInForce(expense.policyStatusAtIncident)
            and terms.veterinaryCovered == true then
            table.insert(result, expense)
        end
    end
    return result
end

function RFF_InsuranceClaimService:getEligibleVeterinaryExpenseTotal(farmId)
    local total = 0
    local expenses = self:getEligibleVeterinaryExpenses(farmId)
    for _, expense in ipairs(expenses) do total = total + math.max(0, safeNumber(expense.treatmentCost)) end
    return total, #expenses
end

function RFF_InsuranceClaimService:hasVeterinaryExpenseForPeriod(farmId, uniqueId, incidentPeriod)
    if self.repository == nil or self.repository.getInsuranceVeterinaryExpensesByFarm == nil then return false end
    local uid = tostring(uniqueId or "")
    for _, expense in ipairs(self.repository:getInsuranceVeterinaryExpensesByFarm(farmId) or {}) do
        if tostring(expense.animalUniqueId or "") == uid and (expense.incidentPeriod or 0) == incidentPeriod then return true end
    end
    return false
end

function RFF_InsuranceClaimService:recordVeterinaryTreatmentExpense(farmId, animalData, treatmentCost, diseaseNames, source)
    if self.repository == nil or self.repository.addInsuranceVeterinaryExpense == nil or farmId == nil or farmId <= 0 then return nil, "farm" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return nil, "not_server" end
    local cost = math.max(0, safeNumber(treatmentCost))
    if cost <= 0 then return nil, "cost" end

    local farmState = self.businessAdministration ~= nil and self.businessAdministration:getFarmState(farmId, true)
        or self.repository:getFarmState(farmId, true)
    if farmState == nil then return nil, "state" end

    local terms = self:getTerms(farmState.insuranceTier or "STANDARD")
    if not self:isPolicyInForce(farmState.insuranceStatus or "ACTIVE") or terms.veterinaryCovered ~= true then
        return nil, "not_covered"
    end

    local currentPeriod = self:getCurrentPeriod()
    local uniqueId = tostring(animalData.uniqueId or "")
    if uniqueId ~= "" and self:hasVeterinaryExpenseForPeriod(farmId, uniqueId, currentPeriod) then return nil, "duplicate" end

    local names = {}
    if type(diseaseNames) == "table" then
        for _, name in ipairs(diseaseNames) do
            local value = tostring(name or "")
            if value ~= "" then names[#names + 1] = value end
        end
    elseif diseaseNames ~= nil and tostring(diseaseNames) ~= "" then
        names[1] = tostring(diseaseNames)
    end

    local expense = {
        id = self.repository:getNextInsuranceVeterinaryExpenseId(),
        farmId = farmId,
        source = source or "RLRM",
        status = self.VET_EXPENSE_RECORDED,
        incidentDay = self:getCurrentDay(),
        incidentPeriod = currentPeriod,
        deadlinePeriod = currentPeriod + self.VET_CLAIM_WINDOW_PERIODS,
        claimId = 0,
        policyTier = farmState.insuranceTier or "STANDARD",
        policyStatusAtIncident = farmState.insuranceStatus or "ACTIVE",
        animalUniqueId = uniqueId,
        animalName = tostring(animalData.name or ""),
        animalBreed = tostring(animalData.breed or ""),
        animalSubType = tostring(animalData.subType or ""),
        animalType = tostring(animalData.animalType or "UNKNOWN"),
        diseaseNames = table.concat(names, ", "),
        treatmentCost = cost
    }
    self.repository:addInsuranceVeterinaryExpense(expense)
    print(string.format("[RealisticFarmFinance] veterinary treatment recorded=VET-%04d farm=%d animal=%s diseases=%s cost=%.2f policyTier=%s policyStatus=%s deadlinePeriod=%d (no claim created)",
        expense.id or 0, farmId, tostring(expense.animalUniqueId), tostring(expense.diseaseNames), expense.treatmentCost,
        tostring(expense.policyTier), tostring(expense.policyStatusAtIncident), expense.deadlinePeriod or 0))
    return expense, "recorded"
end

function RFF_InsuranceClaimService:onRLRMVeterinaryTreatment(animal, treatmentCost, diseaseNames)
    if animal == nil then return nil, "animal" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return nil, "not_server" end
    local farmId = self:getAnimalOwnerFarmId(animal)
    if farmId <= 0 then return nil, "farm" end
    local uniqueId = tostring(animal.uniqueId or "")
    local key = string.format("%d:%s:%d", farmId, uniqueId, self:getCurrentPeriod())
    if self._reportedTreatmentKeys[key] then return nil, "duplicate" end

    local data = {
        uniqueId = uniqueId,
        name = animal.name or "",
        breed = animal.breed or "",
        subType = animal.subType or "",
        animalType = self:getAnimalTypeCode(animal),
        age = animal.age or 0,
        health = animal.health or 0
    }
    local expense, result = self:recordVeterinaryTreatmentExpense(farmId, data, treatmentCost, diseaseNames, "RLRM")
    if expense ~= nil then self._reportedTreatmentKeys[key] = true end
    return expense, result
end

function RFF_InsuranceClaimService:getLossMonthsRemaining(loss)
    if loss == nil or (loss.status ~= self.DEATH_RECORDED and loss.status ~= "CLAIMABLE") then return 0 end
    local deadline = loss.deadlinePeriod or ((loss.incidentPeriod or self:getCurrentPeriod()) + self.CLAIM_WINDOW_PERIODS)
    return math.max(0, deadline - self:getCurrentPeriod())
end

function RFF_InsuranceClaimService:isLossExpired(loss)
    if loss == nil then return true end
    if loss.status == self.DEATH_EXPIRED then return true end
    if loss.status ~= self.DEATH_RECORDED and loss.status ~= "CLAIMABLE" then return false end
    local deadline = loss.deadlinePeriod or ((loss.incidentPeriod or self:getCurrentPeriod()) + self.CLAIM_WINDOW_PERIODS)
    return self:getCurrentPeriod() >= deadline
end

function RFF_InsuranceClaimService:getEligibleDeathRecords(farmId)
    local result = {}
    if self.repository == nil or self.repository.getInsuranceLossesByFarm == nil then return result end
    for _, death in ipairs(self.repository:getInsuranceLossesByFarm(farmId) or {}) do
        if (death.status == self.DEATH_RECORDED or death.status == "CLAIMABLE") and not self:isLossExpired(death) then
            table.insert(result, death)
        end
    end
    table.sort(result, function(a, b)
        if (a.incidentDay or 0) == (b.incidentDay or 0) then return (a.id or 0) > (b.id or 0) end
        return (a.incidentDay or 0) > (b.incidentDay or 0)
    end)
    return result
end

function RFF_InsuranceClaimService:getEligibleDeathCount(farmId)
    return #self:getEligibleDeathRecords(farmId)
end

function RFF_InsuranceClaimService:hasRecordedAnimalLoss(farmId, uniqueId)
    local id = tostring(uniqueId or "")
    if id == "" or self.repository == nil then return false end
    if self.repository.getInsuranceLossesByFarm ~= nil then
        for _, loss in ipairs(self.repository:getInsuranceLossesByFarm(farmId) or {}) do
            if tostring(loss.animalUniqueId or "") == id then return true end
        end
    end
    for _, claim in ipairs(self.repository:getInsuranceClaimsByFarm(farmId) or {}) do
        if tostring(claim.animalUniqueId or "") == id then return true end
    end
    return false
end

function RFF_InsuranceClaimService:recordLivestockLoss(farmId, animalData, reasonCode, source)
    if self.repository == nil or self.repository.addInsuranceLoss == nil or farmId == nil or farmId <= 0 then return nil, "farm" end
    local farmState = self.businessAdministration ~= nil and self.businessAdministration:getFarmState(farmId, true)
        or self.repository:getFarmState(farmId, true)
    if farmState == nil then return nil, "state" end

    local uniqueId = tostring(animalData.uniqueId or "")
    if uniqueId ~= "" and self:hasRecordedAnimalLoss(farmId, uniqueId) then return nil, "duplicate" end

    local tier = farmState.insuranceTier or "STANDARD"
    local currentDay = self:getCurrentDay()
    local currentPeriod = self:getCurrentPeriod()
    local loss = {
        id = self.repository:getNextInsuranceLossId(),
        farmId = farmId,
        source = source or "RLRM",
        status = self.DEATH_RECORDED,
        incidentDay = currentDay,
        incidentPeriod = currentPeriod,
        deadlinePeriod = currentPeriod + self.CLAIM_WINDOW_PERIODS,
        claimId = 0,
        policyTier = tier,
        policyStatusAtIncident = farmState.insuranceStatus or "ACTIVE",
        animalUniqueId = uniqueId,
        animalName = tostring(animalData.name or ""),
        animalBreed = tostring(animalData.breed or ""),
        animalSubType = tostring(animalData.subType or ""),
        animalType = tostring(animalData.animalType or "UNKNOWN"),
        animalAge = math.max(0, math.floor(safeNumber(animalData.age))),
        animalHealth = math.max(0, math.min(100, safeNumber(animalData.health))),
        deathReason = reasonCode or "UNKNOWN",
        incidentValue = math.max(0, safeNumber(animalData.marketValue))
    }
    self.repository:addInsuranceLoss(loss)

    local reference = self:getLossReference(loss)
    -- Deliberately no RFF notification here. RFF records the mortality event quietly;
    -- the player must notice the death and choose to begin a claim within the time limit.
    print(string.format("[RealisticFarmFinance] livestock death recorded=%s farm=%d source=%s type=%s animal=%s reason=%s value=%.2f policyTierAtDeath=%s policyStatusAtDeath=%s deadlinePeriod=%d (no claim created)",
        reference, farmId, tostring(loss.source), tostring(loss.animalType), tostring(loss.animalUniqueId), tostring(loss.deathReason),
        loss.incidentValue, tostring(loss.policyTier), tostring(loss.policyStatusAtIncident), loss.deadlinePeriod or 0))
    return loss, "recorded"
end

-- Legacy helper retained for existing v0.9.2.2 saves/test records only.
function RFF_InsuranceClaimService:createLivestockClaim(farmId, animalData, reasonCode, source)
    return self:recordLivestockLoss(farmId, animalData, reasonCode, source)
end

function RFF_InsuranceClaimService:initiateClaim(farmId, lossId, formData)
    if self.repository == nil or farmId == nil or farmId <= 0 then return false, "farm" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end
    local loss = self.repository:getInsuranceLossById(farmId, lossId)
    if loss == nil then return false, "loss" end
    if loss.status ~= self.DEATH_RECORDED and loss.status ~= "CLAIMABLE" then return false, "status" end
    if self:isLossExpired(loss) then
        loss.status = self.LOSS_EXPIRED
        return false, "expired"
    end

    local currentDay = self:getCurrentDay()
    local terms = self:getTerms(loss.policyTier)
    local claim = {
        id = self.repository:getNextInsuranceClaimId(),
        farmId = farmId,
        insurerId = self.INSURER_ID,
        source = loss.source or "RLRM",
        claimType = "MORTALITY",
        status = self.STATUS_UNDER_REVIEW,
        lossId = loss.id or 0,
        incidentDay = loss.incidentDay or currentDay,
        incidentPeriod = loss.incidentPeriod or self:getCurrentPeriod(),
        submittedDay = currentDay,
        decisionDay = currentDay + self:getAssessmentDelayDays(),
        approvedDay = 0,
        settlementDay = 0,
        paidDay = 0,
        policyTier = loss.policyTier or "STANDARD",
        policyStatusAtIncident = loss.policyStatusAtIncident or "ACTIVE",
        animalUniqueId = loss.animalUniqueId or "",
        animalName = loss.animalName or "",
        animalBreed = loss.animalBreed or "",
        animalSubType = loss.animalSubType or "",
        animalType = loss.animalType or "UNKNOWN",
        animalAge = loss.animalAge or 0,
        animalHealth = loss.animalHealth or 0,
        deathReason = loss.deathReason or "UNKNOWN",
        incidentValue = loss.incidentValue or 0,
        indemnityFactor = terms.indemnity or 0,
        excess = terms.excess or 0,
        amountClaimed = loss.incidentValue or 0,
        formSignedBy = formData ~= nil and tostring(formData.signedBy or "") or "",
        formVersion = 1,
        approvedAmount = 0,
        paidAmount = 0,
        outcomeReason = ""
    }
    self.repository:addInsuranceClaim(claim)
    loss.status = self.DEATH_CLAIMED
    loss.claimId = claim.id

    local reference = self:getClaimReference(claim)
    self:notify(farmId, "Livestock Claim Submitted", string.format(
        "%s has been submitted to %s. The claim is now under review.", reference, self.INSURER_NAME))
    print(string.format("[RealisticFarmFinance] livestock claim initiated=%s fromLoss=%s farm=%d decisionDay=%d",
        reference, self:getLossReference(loss), farmId, claim.decisionDay or 0))
    return true, "submitted", claim
end

function RFF_InsuranceClaimService:initiateVeterinaryClaim(farmId)
    if self.repository == nil or farmId == nil or farmId <= 0 then return false, "farm" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end

    local expenses = self:getEligibleVeterinaryExpenses(farmId)
    if #expenses == 0 then return false, "none" end

    local total = 0
    local latestDay = 0
    local ids = {}
    local diseases = {}
    local diseaseSeen = {}
    local firstAnimalId = nil
    local sameAnimal = true
    local representative = expenses[1]
    for _, expense in ipairs(expenses) do
        total = total + math.max(0, safeNumber(expense.treatmentCost))
        latestDay = math.max(latestDay, expense.incidentDay or 0)
        ids[#ids + 1] = tostring(expense.id or 0)
        local uid = tostring(expense.animalUniqueId or "")
        if firstAnimalId == nil then firstAnimalId = uid elseif uid ~= firstAnimalId then sameAnimal = false end
        for name in (tostring(expense.diseaseNames or "") .. ","):gmatch("%s*([^,]-)%s*,") do
            if name ~= "" and not diseaseSeen[name] then diseaseSeen[name] = true; diseases[#diseases + 1] = name end
        end
    end
    if total <= 0 then return false, "amount" end

    local terms = self:getTerms("COMPREHENSIVE")
    local currentDay = self:getCurrentDay()
    local animalName = sameAnimal and tostring(representative.animalName or "") or "Multiple livestock treatments"
    local animalBreed = sameAnimal and tostring(representative.animalBreed or "") or ""
    local animalType = sameAnimal and tostring(representative.animalType or "LIVESTOCK") or "LIVESTOCK"
    local animalUniqueId = sameAnimal and tostring(representative.animalUniqueId or "") or ""
    local claim = {
        id = self.repository:getNextInsuranceClaimId(),
        farmId = farmId,
        insurerId = self.INSURER_ID,
        source = "RLRM",
        claimType = "VETERINARY",
        status = self.STATUS_UNDER_REVIEW,
        lossId = 0,
        incidentDay = latestDay,
        incidentPeriod = self:getCurrentPeriod(),
        submittedDay = currentDay,
        decisionDay = currentDay + self:getAssessmentDelayDays(),
        approvedDay = 0, settlementDay = 0, paidDay = 0,
        policyTier = "COMPREHENSIVE",
        policyStatusAtIncident = representative.policyStatusAtIncident or "ACTIVE",
        animalUniqueId = animalUniqueId,
        animalName = animalName,
        animalBreed = animalBreed,
        animalSubType = sameAnimal and tostring(representative.animalSubType or "") or "",
        animalType = animalType,
        animalAge = 0, animalHealth = 0,
        deathReason = "VETERINARY",
        incidentValue = total,
        indemnityFactor = terms.veterinaryIndemnity or 0,
        excess = terms.veterinaryExcess or 0,
        amountClaimed = total,
        formSignedBy = "", formVersion = 0,
        approvedAmount = 0, paidAmount = 0, outcomeReason = "",
        treatmentDetails = #diseases > 0 and table.concat(diseases, ", ") or "RLRM disease treatment",
        veterinaryExpenseIds = table.concat(ids, ",")
    }
    self.repository:addInsuranceClaim(claim)
    for _, expense in ipairs(expenses) do
        expense.status = self.VET_EXPENSE_CLAIMED
        expense.claimId = claim.id
    end

    local reference = self:getClaimReference(claim)
    self:notify(farmId, "Veterinary Claim Submitted", string.format(
        "%s has been submitted to %s for %s of eligible veterinary treatment expenses.",
        reference, self.INSURER_NAME, formatMoney(total)))
    print(string.format("[RealisticFarmFinance] veterinary claim initiated=%s farm=%d expenses=%d claimed=%.2f decisionDay=%d",
        reference, farmId, #expenses, total, claim.decisionDay or 0))
    return true, "submitted", claim
end

-- Legacy v0.9.2.2 path: old Awaiting Submission claim records can still be submitted.
function RFF_InsuranceClaimService:submitClaim(farmId, claimId)
    if self.repository == nil or farmId == nil or farmId <= 0 then return false, "farm" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end
    local claim = self.repository:getInsuranceClaimById(farmId, claimId)
    if claim == nil then return false, "claim" end
    if claim.status ~= self.STATUS_AWAITING_SUBMISSION then return false, "status" end

    local currentDay = self:getCurrentDay()
    claim.status = self.STATUS_UNDER_REVIEW
    claim.submittedDay = currentDay
    claim.decisionDay = currentDay + self:getAssessmentDelayDays()
    local reference = self:getClaimReference(claim)
    self:notify(farmId, "Livestock Claim Submitted", string.format(
        "%s has been submitted to %s. The claim is now under review.", reference, self.INSURER_NAME))
    return true, "submitted", claim
end

function RFF_InsuranceClaimService:onRLRMAnimalDeath(animal, reason)
    if animal == nil then return nil, "animal" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return nil, "not_server" end

    local animalType = self:getAnimalTypeCode(animal)
    if animalType ~= "SHEEP" and animalType ~= "COW" then return nil, "unsupported_type" end

    local farmId = self:getAnimalOwnerFarmId(animal)
    if farmId <= 0 then return nil, "farm" end

    local uniqueId = tostring(animal.uniqueId or "")
    local deathKey = uniqueId ~= "" and string.format("rlrm:%d:%s", farmId, uniqueId) or nil
    if deathKey ~= nil and self._reportedDeathKeys[deathKey] then return nil, "duplicate" end
    if uniqueId ~= "" and self:hasRecordedAnimalLoss(farmId, uniqueId) then
        if deathKey ~= nil then self._reportedDeathKeys[deathKey] = true end
        return nil, "duplicate"
    end

    local data = {
        uniqueId = uniqueId,
        name = animal.name or "",
        breed = animal.breed or "",
        subType = animal.subType or "",
        animalType = animalType,
        age = animal.age or 0,
        health = animal.health or 0,
        marketValue = self:getAnimalMarketValue(animal)
    }
    local loss, result = self:recordLivestockLoss(farmId, data, self:normaliseDeathReason(reason), "RLRM")
    if loss ~= nil and deathKey ~= nil then self._reportedDeathKeys[deathKey] = true end
    return loss, result
end

function RFF_InsuranceClaimService:_captureRLRMDeath(animal, reason, hookName)
    local manager = g_currentMission ~= nil and g_currentMission.realisticFarmFinance or nil
    local service = manager ~= nil and manager.insuranceClaims or nil
    if service == nil then return end
    local ok, result, detail = pcall(service.onRLRMAnimalDeath, service, animal, reason)
    if not ok then
        print(string.format("[RealisticFarmFinance] Warning: livestock death capture failed via %s: %s", tostring(hookName), tostring(result)))
    elseif result ~= nil then
        print(string.format("[RealisticFarmFinance] RLRM death captured via %s loss=%s", tostring(hookName), service:getLossReference(result)))
    elseif detail ~= "duplicate" and detail ~= "unsupported_type" then
        print(string.format("[RealisticFarmFinance] RLRM death ignored via %s reason=%s", tostring(hookName), tostring(detail)))
    end
end

function RFF_InsuranceClaimService:_getRLRMAnimalClass(animal)
    if type(animal) ~= "table" or animal.isIndividual ~= true or animal.uniqueId == nil or type(animal.die) ~= "function" then
        return nil
    end

    local ok, mt = pcall(getmetatable, animal)
    if not ok or type(mt) ~= "table" then return nil end

    local classTable = rawget(mt, "__index")
    if type(classTable) == "table" and type(classTable.die) == "function" then
        return classTable
    end
    if type(mt.die) == "function" then return mt end
    return nil
end

function RFF_InsuranceClaimService:_discoverRLRMAnimalClass()
    if g_currentMission == nil then return nil end

    local function tryAnimal(animal)
        return self:_getRLRMAnimalClass(animal)
    end

    -- Native husbandry storage is the preferred discovery route.  The RLRM Animal
    -- object itself crosses the mod sandbox boundary, so its metatable gives RFF the
    -- authoritative live class without depending on RLRM's private globals.
    local placeableSystem = g_currentMission.placeableSystem
    if placeableSystem ~= nil then
        for _, placeable in pairs(placeableSystem.placeables or {}) do
            local spec = placeable ~= nil and placeable.spec_husbandryAnimals or nil
            local clusterSystem = spec ~= nil and spec.clusterSystem or nil
            if clusterSystem ~= nil then
                for _, animal in pairs(clusterSystem.animals or {}) do
                    local classTable = tryAnimal(animal)
                    if classTable ~= nil then return classTable end
                end
            end
        end
    end

    -- RLRM also keeps individual animals in animal-system collections (dealer/AI
    -- pools depending on version).  These are useful for class discovery even when
    -- the player's own animals currently live outside a conventional husbandry.
    local animalSystem = g_currentMission.animalSystem
    if animalSystem ~= nil then
        for _, bucket in pairs(animalSystem.animals or {}) do
            local classTable = tryAnimal(bucket)
            if classTable ~= nil then return classTable end
            if type(bucket) == "table" then
                for _, animal in pairs(bucket) do
                    classTable = tryAnimal(animal)
                    if classTable ~= nil then return classTable end
                end
            end
        end
    end

    -- Once FP/GH register the v2 provider bridge, their runtime clusterRef records
    -- provide the same authoritative RLRM Animal object and can therefore be used
    -- for discovery too.  Provider failures are already isolated by the registry.
    if RFF_LivestockAssetRegistry ~= nil and RFF_LivestockAssetRegistry.collectProviderRecords ~= nil and g_farmManager ~= nil then
        for farmId, farm in pairs(g_farmManager.farmIdToFarm or {}) do
            if farmId ~= nil and farmId > 0 and farm ~= nil and farm.isSpectator ~= true then
                local records = RFF_LivestockAssetRegistry:collectProviderRecords(farmId)
                for _, record in ipairs(records or {}) do
                    local classTable = tryAnimal(record.clusterRef)
                    if classTable ~= nil then return classTable end
                end
            end
        end
    end

    return nil
end

function RFF_InsuranceClaimService:_installLiveRLRMDeathHook()
    local classTable = self:_discoverRLRMAnimalClass()
    if classTable == nil or type(classTable.die) ~= "function" then return false end

    if self._rlrmAnimalClass == classTable and self._rlrmLiveClassWrapper ~= nil and classTable.die == self._rlrmLiveClassWrapper then
        return true
    end

    local original = classTable.die
    local wrapper = Utils.prependedFunction(original, function(animal, reason)
        local manager = g_currentMission ~= nil and g_currentMission.realisticFarmFinance or nil
        local service = manager ~= nil and manager.insuranceClaims or nil
        if service ~= nil and animal ~= nil and animal.isIndividual == true and animal.uniqueId ~= nil then
            service._pendingDeathReasonByAnimal[animal] = reason
            service:_captureRLRMDeath(animal, reason, "RLRM Animal:die")
        end
    end)

    classTable.die = wrapper
    self._rlrmAnimalClass = classTable
    self._rlrmLiveClassWrapper = wrapper
    return true
end

function RFF_InsuranceClaimService:_installLiveRLRMTreatmentHook()
    local classTable = self:_discoverRLRMAnimalClass()
    if classTable == nil or type(classTable.onPeriodChanged) ~= "function" then return false end

    if self._rlrmTreatmentClass == classTable and self._rlrmTreatmentWrapper ~= nil
        and classTable.onPeriodChanged == self._rlrmTreatmentWrapper then
        return true
    end

    local original = classTable.onPeriodChanged
    local wrapper = function(animal, ...)
        local activeTreatments = {}
        for _, disease in pairs(type(animal) == "table" and animal.diseases or {}) do
            if disease ~= nil and disease.beingTreated == true and disease.type ~= nil and disease.type.treatment ~= nil then
                activeTreatments[#activeTreatments + 1] = tostring(disease.type.name or disease.type.title or disease.type.key or "Treatment")
            end
        end

        local treatmentCost = original(animal, ...)
        local cost = safeNumber(treatmentCost)
        if cost > 0 then
            local manager = g_currentMission ~= nil and g_currentMission.realisticFarmFinance or nil
            local service = manager ~= nil and manager.insuranceClaims or nil
            if service ~= nil and g_currentMission:getIsServer() then
                local ok, expense, detail = pcall(service.onRLRMVeterinaryTreatment, service, animal, cost, activeTreatments)
                if not ok then
                    print(string.format("[RealisticFarmFinance] Warning: RLRM veterinary treatment capture failed: %s", tostring(expense)))
                elseif expense ~= nil then
                    print(string.format("[RealisticFarmFinance] RLRM veterinary treatment captured expense=VET-%04d cost=%.2f", expense.id or 0, cost))
                elseif detail ~= "duplicate" then
                    print(string.format("[RealisticFarmFinance] RLRM veterinary treatment ignored reason=%s", tostring(detail)))
                end
            end
        end
        return treatmentCost
    end

    classTable.onPeriodChanged = wrapper
    self._rlrmTreatmentClass = classTable
    self._rlrmTreatmentWrapper = wrapper
    return true
end

function RFF_InsuranceClaimService:_installClusterRemovalSafetyHook()
    if AnimalClusterSystem == nil or type(AnimalClusterSystem.addPendingRemoveCluster) ~= "function" then return false end

    if RFF_InsuranceClaimService._clusterRemovalWrapper ~= nil
        and AnimalClusterSystem.addPendingRemoveCluster == RFF_InsuranceClaimService._clusterRemovalWrapper then
        return true
    end

    local original = AnimalClusterSystem.addPendingRemoveCluster
    local wrapper = Utils.prependedFunction(original, function(clusterSystem, animal)
        -- RLRM sets isDead before it queues removal.  Sales/transfers do not satisfy
        -- this guard, so this is an authoritative death safety net rather than a
        -- generic "animal disappeared" inference.
        if type(animal) == "table" and animal.isIndividual == true and animal.uniqueId ~= nil
            and animal.isDead == true and animal.isSold ~= true then
            local manager = g_currentMission ~= nil and g_currentMission.realisticFarmFinance or nil
            local service = manager ~= nil and manager.insuranceClaims or nil
            if service ~= nil then
                local reason = service._pendingDeathReasonByAnimal[animal] or "UNKNOWN"
                service:_captureRLRMDeath(animal, reason, "AnimalClusterSystem.addPendingRemoveCluster")
                service._pendingDeathReasonByAnimal[animal] = nil
            end
        end
    end)

    AnimalClusterSystem.addPendingRemoveCluster = wrapper
    RFF_InsuranceClaimService._clusterRemovalWrapper = wrapper
    return true
end

function RFF_InsuranceClaimService:installRLRMDeathHooks()
    local previous = self.rlrHookAvailable
    local previousTreatment = self.rlrTreatmentHookAvailable
    local liveInstalled = self:_installLiveRLRMDeathHook()
    local treatmentInstalled = self:_installLiveRLRMTreatmentHook()
    local safetyInstalled = self:_installClusterRemovalSafetyHook()

    self.rlrHookAvailable = liveInstalled
    self.rlrTreatmentHookAvailable = treatmentInstalled
    self.rlrSafetyHookAvailable = safetyInstalled

    if liveInstalled and previous ~= true then
        print("[RealisticFarmFinance] RLRM livestock mortality integration active (authoritative live Animal:die + GIANTS removal safety net)")
    elseif not liveInstalled and previous ~= false then
        print(string.format("[RealisticFarmFinance] RLRM live Animal class not yet discoverable; safetyHook=%s, RFF will retry automatically", tostring(safetyInstalled)))
    end
    if treatmentInstalled and previousTreatment ~= true then
        print("[RealisticFarmFinance] RLRM veterinary treatment integration active (authoritative Animal:onPeriodChanged treatment cost capture)")
    end

    return liveInstalled or treatmentInstalled or safetyInstalled
end

function RFF_InsuranceClaimService:expireLosses(farmId)
    if self.repository == nil or self.repository.getInsuranceLossesByFarm == nil then return 0 end
    local expired = 0
    for _, loss in ipairs(self.repository:getInsuranceLossesByFarm(farmId) or {}) do
        if (loss.status == self.DEATH_RECORDED or loss.status == "CLAIMABLE") and self:isLossExpired(loss) then
            loss.status = self.DEATH_EXPIRED
            expired = expired + 1
            -- No reminder is sent: noticing the death and filing in time is the player's responsibility.
            print(string.format("[RealisticFarmFinance] livestock death claim window expired=%s farm=%d", self:getLossReference(loss), farmId))
        end
    end
    return expired
end

function RFF_InsuranceClaimService:expireVeterinaryExpenses(farmId)
    if self.repository == nil or self.repository.getInsuranceVeterinaryExpensesByFarm == nil then return 0 end
    local expired = 0
    for _, expense in ipairs(self.repository:getInsuranceVeterinaryExpensesByFarm(farmId) or {}) do
        if expense.status == self.VET_EXPENSE_RECORDED and self:isVeterinaryExpenseExpired(expense) then
            expense.status = self.VET_EXPENSE_EXPIRED
            expired = expired + 1
            print(string.format("[RealisticFarmFinance] veterinary treatment claim window expired=VET-%04d farm=%d", expense.id or 0, farmId))
        end
    end
    return expired
end

function RFF_InsuranceClaimService:getTrafficCourtesyIncidentReference(incident)
    return string.format("RFF-TI-%06d", incident ~= nil and (incident.id or 0) or 0)
end

function RFF_InsuranceClaimService:getTrafficCourtesyIncidentMonthsRemaining(incident)
    if incident == nil or incident.status ~= self.TRAFFIC_INCIDENT_RECORDED then return 0 end
    return math.max(0, math.floor((incident.deadlinePeriod or 0) - self:getCurrentPeriod()))
end

function RFF_InsuranceClaimService:isTrafficCourtesyIncidentExpired(incident)
    return incident == nil or incident.status == self.TRAFFIC_INCIDENT_EXPIRED
        or (incident.status == self.TRAFFIC_INCIDENT_RECORDED and self:getCurrentPeriod() >= (incident.deadlinePeriod or 0))
end

function RFF_InsuranceClaimService:getTrafficCourtesyIncidentExcess(incident)
    if incident == nil then return 0 end
    if incident.policyStatusAtIncident == "TEMPORARY" then return 750 end
    if incident.policyCoverType == "COMPREHENSIVE" then return 350 end
    if incident.policyCoverType == "THIRD_PARTY" then return 500 end
    return 0
end

function RFF_InsuranceClaimService:getTrafficCourtesyTargetOwnerFarmId(entry)
    local ownerFarmId = math.floor(safeNumber(entry ~= nil and entry.targetVehicleFarmId))
    if ownerFarmId <= 0 then ownerFarmId = math.floor(safeNumber(entry ~= nil and entry.targetFarmId)) end
    if ownerFarmId <= 0 then
        local farmlandId = math.floor(safeNumber(entry ~= nil and entry.targetFarmlandId))
        if farmlandId > 0 and g_farmlandManager ~= nil and g_farmlandManager.farmlandMapping ~= nil then
            ownerFarmId = math.floor(safeNumber(g_farmlandManager.farmlandMapping[farmlandId]))
        end
    end
    return ownerFarmId
end

function RFF_InsuranceClaimService:getTrafficCourtesyThirdPartyReserve(targetType, severity, targetMassKg)
    local reserves = {
        AI_VEHICLE = {MINOR=600, MODERATE=1800, SERIOUS=6000, SEVERE=18000, UNKNOWN=1200},
        VEHICLE = {MINOR=600, MODERATE=1800, SERIOUS=6000, SEVERE=18000, UNKNOWN=1200},
        PEDESTRIAN = {MINOR=2500, MODERATE=10000, SERIOUS=30000, SEVERE=75000, UNKNOWN=10000},
        BUILDING = {MINOR=1000, MODERATE=4000, SERIOUS=15000, SEVERE=40000, UNKNOWN=3000},
        FENCE = {MINOR=250, MODERATE=800, SERIOUS=2500, SEVERE=7000, UNKNOWN=600},
        GATE = {MINOR=250, MODERATE=800, SERIOUS=2500, SEVERE=7000, UNKNOWN=600},
        WALL = {MINOR=400, MODERATE=1400, SERIOUS=4500, SEVERE=12000, UNKNOWN=1000},
        TREE = {MINOR=300, MODERATE=1200, SERIOUS=4000, SEVERE=10000, UNKNOWN=900},
        STREET_FURNITURE = {MINOR=300, MODERATE=1200, SERIOUS=4000, SEVERE=10000, UNKNOWN=900},
        OTHER_STATIC = {MINOR=300, MODERATE=1200, SERIOUS=4000, SEVERE=10000, UNKNOWN=900}
    }
    targetType = tostring(targetType or "OTHER_STATIC")
    severity = tostring(severity or "UNKNOWN")
    local tableForType = reserves[targetType] or reserves.OTHER_STATIC
    local reserve = tableForType[severity] or tableForType.UNKNOWN
    if (targetType == "AI_VEHICLE" or targetType == "VEHICLE") and safeNumber(targetMassKg) > 0 then
        reserve = reserve * clamp(0.75 + safeNumber(targetMassKg) / 20000, 0.75, 1.60)
    end
    return roundReserve(reserve)
end

function RFF_InsuranceClaimService:estimateTrafficCourtesyLoss(entry, insuredValue, thirdPartyTarget)
    local severity = tostring(entry ~= nil and entry.severityClass or "UNKNOWN")
    local value = math.max(25000, safeNumber(insuredValue))
    local damageRate = self.TRAFFIC_OWN_DAMAGE_RATE[severity] or self.TRAFFIC_OWN_DAMAGE_RATE.UNKNOWN
    local adsRate = clamp(safeNumber(entry ~= nil and entry.adsSourceDamage) * 1.10, 0, 0.45)
    local ownDamage = math.max(self.TRAFFIC_OWN_DAMAGE_MINIMUM[severity] or self.TRAFFIC_OWN_DAMAGE_MINIMUM.UNKNOWN,
        value * math.max(damageRate, adsRate))
    local thirdParty = thirdPartyTarget == true
        and self:getTrafficCourtesyThirdPartyReserve(entry.targetType, severity, entry.targetPartMassKg) or 0
    local legalCosts = 0
    if thirdPartyTarget == true then
        if entry.targetType == "PEDESTRIAN" then
            legalCosts = ({MINOR=1500, MODERATE=3000, SERIOUS=6000, SEVERE=10000, UNKNOWN=3000})[severity] or 3000
        elseif severity == "SERIOUS" then legalCosts = 1500
        elseif severity == "SEVERE" then legalCosts = 4000 end
    end
    return roundReserve(ownDamage), roundReserve(thirdParty), roundReserve(legalCosts)
end

function RFF_InsuranceClaimService:resolveTrafficCourtesyVehicleId(entry)
    local vehicleUniqueId = tostring(entry ~= nil and entry.vehicleId or "")
    if vehicleUniqueId ~= "" then return vehicleUniqueId end
    local vehicle = g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil and g_localPlayer:getCurrentVehicle() or nil
    if vehicle ~= nil and vehicle.getRootVehicle ~= nil then vehicle = vehicle:getRootVehicle() end
    return vehicle ~= nil and tostring(vehicle.uniqueId or "") or ""
end

function RFF_InsuranceClaimService:getTrafficCourtesyGroupingTargetKey(value)
    if value == nil then return "" end
    local targetVehicleId = tostring(value.targetVehicleId or "")
    if targetVehicleId ~= "" then return "VEHICLE:" .. targetVehicleId end
    local ownerFarmId = self:getTrafficCourtesyTargetOwnerFarmId(value)
    return table.concat({
        tostring(value.targetType or "UNKNOWN"),
        tostring(ownerFarmId),
        normaliseIdentifier(value.targetName),
        normaliseIdentifier(value.targetObjectFilename)
    }, ":")
end

function RFF_InsuranceClaimService:findGroupedTrafficCourtesyIncident(farmId, vehicleUniqueId, entry)
    if self.repository == nil then return nil end
    local incidentDay = self:getCurrentDay()
    local dayTimeMs = math.floor(safeNumber(entry ~= nil and entry.dayTimeMs))
    local x, y, z = safeNumber(entry ~= nil and entry.x), safeNumber(entry ~= nil and entry.y), safeNumber(entry ~= nil and entry.z)
    local targetKey = self:getTrafficCourtesyGroupingTargetKey(entry)
    local maxDistanceSquared = self.TRAFFIC_GROUP_DISTANCE_METRES * self.TRAFFIC_GROUP_DISTANCE_METRES

    for _, incident in ipairs(self.repository:getTrafficCourtesyIncidentsByFarm(farmId) or {}) do
        local timeDifference = math.abs(dayTimeMs - math.floor(safeNumber(incident.dayTimeMs)))
        local dx, dy, dz = x - safeNumber(incident.x), y - safeNumber(incident.y), z - safeNumber(incident.z)
        local distanceSquared = dx * dx + dy * dy + dz * dz
        if tostring(incident.vehicleUniqueId or "") == tostring(vehicleUniqueId or "")
                and math.floor(safeNumber(incident.incidentDay)) == incidentDay
                and timeDifference <= self.TRAFFIC_GROUP_WINDOW_MS
                and distanceSquared <= maxDistanceSquared
                and targetKey ~= "" and self:getTrafficCourtesyGroupingTargetKey(incident) == targetKey then
            return incident
        end
    end
    return nil
end

function RFF_InsuranceClaimService:refreshTrafficClaimFromIncident(incident)
    if incident == nil or self.repository == nil or safeNumber(incident.claimId) <= 0 then return end
    local claim = self.repository:getInsuranceClaimById(incident.farmId, incident.claimId)
    if claim == nil or math.floor(safeNumber(claim.trafficWorkflowVersion)) < self.TRAFFIC_WORKFLOW_VERSION then return end

    claim.groupedExternalIncidentIds = incident.groupedExternalIncidentIds or incident.externalIncidentId or ""
    claim.groupedIncidentCount = math.max(1, math.floor(safeNumber(incident.groupedIncidentCount)))
    claim.incidentSeverity = incident.severityClass or claim.incidentSeverity
    claim.incidentClosingSpeedMps = math.max(safeNumber(claim.incidentClosingSpeedMps), safeNumber(incident.closingSpeedMps))
    claim.incidentAdsSourceDamage = math.max(safeNumber(claim.incidentAdsSourceDamage), safeNumber(incident.adsSourceDamage))
    claim.incidentAdsSourceSystems = mergeEvidenceText(claim.incidentAdsSourceSystems, incident.adsSourceSystems)
    claim.incidentAdsSourceBreakdowns = mergeEvidenceText(claim.incidentAdsSourceBreakdowns, incident.adsSourceBreakdowns)
    claim.ownDamageEstimate = math.max(safeNumber(claim.ownDamageEstimate), safeNumber(incident.ownDamageEstimate))
    claim.thirdPartyLiability = math.max(safeNumber(claim.thirdPartyLiability), safeNumber(incident.thirdPartyEstimate))
    claim.legalCosts = math.max(safeNumber(claim.legalCosts), safeNumber(incident.legalCostEstimate))
    if claim.ownDamageStatus == "READY" or claim.ownDamageStatus == "AWAITING_INSPECTION"
            or claim.ownDamageStatus == "AWAITING_OEM_REPAIR" then
        claim.vehicleDamageCost = claim.ownDamageEstimate
    end
    claim.incidentValue = safeNumber(claim.vehicleDamageCost) + claim.thirdPartyLiability + claim.legalCosts
    claim.amountClaimed = claim.incidentValue
    self:refreshVehicleClaimEvaluation(claim)
end

function RFF_InsuranceClaimService:mergeTrafficCourtesyIncident(incident, entry)
    if incident == nil or entry == nil then return incident end
    local groupedIds = tostring(incident.groupedExternalIncidentIds or "")
    if groupedIds == "" then groupedIds = tostring(incident.externalIncidentId or "") end
    incident.groupedExternalIncidentIds = appendUniqueDelimited(groupedIds, entry.incidentId)
    incident.groupedIncidentCount = math.max(1, math.floor(safeNumber(incident.groupedIncidentCount))) + 1

    local currentRank = self.TRAFFIC_SEVERITY_RANK[tostring(incident.severityClass or "UNKNOWN")] or 0
    local incomingRank = self.TRAFFIC_SEVERITY_RANK[tostring(entry.severityClass or "UNKNOWN")] or 0
    if incomingRank > currentRank then incident.severityClass = tostring(entry.severityClass or "UNKNOWN") end
    incident.sourceSpeedMps = math.max(safeNumber(incident.sourceSpeedMps), safeNumber(entry.sourceSpeedMps))
    incident.targetSpeedMps = math.max(safeNumber(incident.targetSpeedMps), safeNumber(entry.targetSpeedMps or entry.trafficSpeedMps))
    incident.closingSpeedMps = math.max(safeNumber(incident.closingSpeedMps), safeNumber(entry.closingSpeedMps))
    incident.combinationMassKg = math.max(safeNumber(incident.combinationMassKg), safeNumber(entry.combinationMassKg))
    incident.targetPartMassKg = math.max(safeNumber(incident.targetPartMassKg), safeNumber(entry.targetPartMassKg))
    incident.adsSourceDamage = math.max(safeNumber(incident.adsSourceDamage), safeNumber(entry.adsSourceDamage))
    incident.adsTargetDamage = math.max(safeNumber(incident.adsTargetDamage), safeNumber(entry.adsTargetDamage))
    incident.adsSourceSystems = mergeEvidenceText(incident.adsSourceSystems, entry.adsSourceSystems)
    incident.adsTargetSystems = mergeEvidenceText(incident.adsTargetSystems, entry.adsTargetSystems)
    incident.adsSourceBreakdowns = mergeEvidenceText(incident.adsSourceBreakdowns, entry.adsSourceBreakdowns or entry.adsSourceBreakdown)
    incident.adsTargetBreakdowns = mergeEvidenceText(incident.adsTargetBreakdowns, entry.adsTargetBreakdowns or entry.adsTargetBreakdown)

    local ownDamage, thirdParty, legalCosts = self:estimateTrafficCourtesyLoss(entry, incident.policyInsuredValue, incident.thirdPartyTarget == true)
    incident.ownDamageEstimate = math.max(safeNumber(incident.ownDamageEstimate), ownDamage)
    incident.thirdPartyEstimate = math.max(safeNumber(incident.thirdPartyEstimate), thirdParty)
    incident.legalCostEstimate = math.max(safeNumber(incident.legalCostEstimate), legalCosts)
    incident.estimatedClaimTotal = incident.ownDamageEstimate + incident.thirdPartyEstimate + incident.legalCostEstimate
    local evaluation = self:evaluateVehicleClaim({
        policyCoverType=incident.policyCoverType, policyStatusAtIncident=incident.policyStatusAtIncident,
        policyLegalCover=incident.policyLegalCover, policyUseScope=incident.policyUseScope,
        policyMaxGrossWeight=incident.policyMaxGrossWeight, incidentLocationType=incident.locationType,
        incidentGrossWeight=incident.combinationMassKg/1000, vehicleDamageCost=incident.ownDamageEstimate,
        thirdPartyLiability=incident.thirdPartyEstimate, legalCosts=incident.legalCostEstimate,
        excess=self:getTrafficCourtesyIncidentExcess(incident)
    }, incident)
    incident.estimatedPayout = evaluation ~= nil and (evaluation.estimatedPayout or 0) or incident.estimatedPayout
    self:refreshTrafficClaimFromIncident(incident)
    print(string.format("[RealisticFarmFinance] Traffic Courtesy incident %s grouped into %s count=%d; financial reserves were not duplicated",
        tostring(entry.incidentId or "?"), self:getTrafficCourtesyIncidentReference(incident), incident.groupedIncidentCount))
    return incident
end

function RFF_InsuranceClaimService:recordTrafficCourtesyIncident(entry)
    if self.repository == nil or self.fleetManagement == nil or type(entry) ~= "table" then return false, "service" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end
    local externalIncidentId = tostring(entry.incidentId or "")
    if externalIncidentId == "" then return false, "incident" end
    local existing = self.repository:getTrafficCourtesyIncidentByExternalId(externalIncidentId)
    if existing ~= nil then return false, "duplicate", existing end

    local farmId = math.floor(safeNumber(entry.farmId))
    if farmId <= 0 then return false, "farm" end
    local vehicleUniqueId = self:resolveTrafficCourtesyVehicleId(entry)
    local groupedIncident = self:findGroupedTrafficCourtesyIncident(farmId, vehicleUniqueId, entry)
    if groupedIncident ~= nil then
        self:mergeTrafficCourtesyIncident(groupedIncident, entry)
        return false, "grouped", groupedIncident
    end
    local grossWeight = math.max(0, safeNumber(entry.combinationMassKg) / 1000)
    local context = {x=entry.x, y=entry.y, z=entry.z, grossWeight=grossWeight}
    local compliance = vehicleUniqueId ~= "" and self.fleetManagement:getPolicyCompliance(farmId, vehicleUniqueId, context) or nil
    local locationType = compliance ~= nil and compliance.locationType
        or self.fleetManagement:classifyVehicleUse(farmId, nil, context)
    local policy = compliance ~= nil and compliance.policy or nil
    local insuredValue = policy ~= nil and safeNumber(policy.insuredValue) or 0
    if insuredValue <= 0 and compliance ~= nil and compliance.vehicle ~= nil then
        insuredValue = self.fleetManagement:getVehicleValue(compliance.vehicle)
    end
    local targetOwnerFarmId = self:getTrafficCourtesyTargetOwnerFarmId(entry)
    local thirdPartyTarget = entry.targetType == "PEDESTRIAN" or targetOwnerFarmId <= 0 or targetOwnerFarmId ~= farmId
    local ownDamage, thirdParty, legalCosts = self:estimateTrafficCourtesyLoss(entry, insuredValue, thirdPartyTarget)
    local incidentPeriod = self:getCurrentPeriod()
    local adsCheckpoint = RFF_ADSIntegration ~= nil and compliance ~= nil
        and RFF_ADSIntegration:getClaimEvidenceCheckpoint(compliance.vehicle) or 0
    local licenceSnapshot = self:captureLicenceSnapshot(farmId, vehicleUniqueId, compliance, {
        x=entry.x, y=entry.y, z=entry.z, locationType=locationType, grossWeight=grossWeight
    })
    local incident = {
        id = self.repository:getNextTrafficCourtesyIncidentId(),
        farmId = farmId,
        source = "TRAFFIC_COURTESY",
        externalIncidentId = externalIncidentId,
        groupedExternalIncidentIds = externalIncidentId,
        groupedIncidentCount = 1,
        status = self.TRAFFIC_INCIDENT_RECORDED,
        claimId = 0,
        incidentDay = self:getCurrentDay(),
        incidentPeriod = incidentPeriod,
        deadlinePeriod = incidentPeriod + self.VEHICLE_CLAIM_WINDOW_PERIODS,
        dayTimeMs = math.floor(safeNumber(entry.dayTimeMs)),
        vehicleUniqueId = vehicleUniqueId,
        vehicleName = tostring(entry.vehicleName or "Vehicle"),
        partId = tostring(entry.partId or ""),
        partName = tostring(entry.partName or entry.vehicleName or "Vehicle"),
        partFilename = tostring(entry.partFilename or ""),
        targetName = tostring(entry.targetName or "Unknown object"),
        targetType = tostring(entry.targetType or "UNKNOWN"),
        targetVehicleName = tostring(entry.targetVehicleName or ""),
        targetVehicleId = tostring(entry.targetVehicleId or ""),
        targetPartId = tostring(entry.targetPartId or ""),
        targetObjectFilename = tostring(entry.targetObjectFilename or ""),
        targetOwnershipQuality = tostring(entry.targetOwnershipQuality or ""),
        targetFarmId = math.floor(safeNumber(entry.targetFarmId)),
        targetVehicleFarmId = math.floor(safeNumber(entry.targetVehicleFarmId)),
        targetFarmlandId = math.floor(safeNumber(entry.targetFarmlandId)),
        x = safeNumber(entry.x), y = safeNumber(entry.y), z = safeNumber(entry.z),
        locationType = tostring(locationType or "UNKNOWN"),
        sourceSpeedMps = math.max(0, safeNumber(entry.sourceSpeedMps)),
        targetSpeedMps = math.max(0, safeNumber(entry.targetSpeedMps or entry.trafficSpeedMps)),
        closingSpeedMps = math.max(0, safeNumber(entry.closingSpeedMps)),
        combinationMassKg = math.max(0, safeNumber(entry.combinationMassKg)),
        targetPartMassKg = math.max(0, safeNumber(entry.targetPartMassKg)),
        severityClass = tostring(entry.severityClass or "UNKNOWN"),
        sourceFaultAssessment = tostring(entry.faultAssessment or "UNKNOWN"),
        faultAssessment = thirdPartyTarget and "PRESUMED_PLAYER" or "OWN_PROPERTY",
        impactZone = tostring(entry.impactZone or "UNKNOWN"),
        targetImpactZone = tostring(entry.targetImpactZone or "UNKNOWN"),
        contactQuality = tostring(entry.contactQuality or ""),
        impactSpeedBasis = tostring(entry.impactSpeedBasis or ""),
        adsSourceDamage = math.max(0, safeNumber(entry.adsSourceDamage)),
        adsTargetDamage = math.max(0, safeNumber(entry.adsTargetDamage)),
        adsSourceSystems = tostring(entry.adsSourceSystems or ""),
        adsTargetSystems = tostring(entry.adsTargetSystems or ""),
        adsSourceBreakdowns = tostring(entry.adsSourceBreakdowns or entry.adsSourceBreakdown or ""),
        adsTargetBreakdowns = tostring(entry.adsTargetBreakdowns or entry.adsTargetBreakdown or ""),
        adsLogBaselineId = adsCheckpoint,
        ownDamageEstimate = ownDamage,
        thirdPartyEstimate = thirdParty,
        legalCostEstimate = legalCosts,
        estimatedClaimTotal = ownDamage + thirdParty + legalCosts,
        thirdPartyTarget = thirdPartyTarget,
        policyId = policy ~= nil and (policy.id or 0) or 0,
        policyStatusAtIncident = compliance ~= nil and tostring(compliance.insuranceStatus or "UNINSURED") or "UNINSURED",
        policyCoverType = policy ~= nil and tostring(policy.coverType or "NONE") or "NONE",
        policyLegalCover = policy ~= nil and policy.legalCover == true or false,
        policyUseScope = policy ~= nil and tostring(policy.useScope or "AGRICULTURAL_ROAD") or "NONE",
        policyMaxGrossWeight = policy ~= nil and math.max(0, safeNumber(policy.maxGrossWeight)) or 0,
        policyInsuredValue = math.max(0, insuredValue)
    }
    self:applyLicenceSnapshot(incident, licenceSnapshot)
    local evaluation = self:evaluateVehicleClaim({
        policyCoverType=incident.policyCoverType, policyStatusAtIncident=incident.policyStatusAtIncident,
        policyLegalCover=incident.policyLegalCover, policyUseScope=incident.policyUseScope,
        policyMaxGrossWeight=incident.policyMaxGrossWeight, incidentLocationType=incident.locationType,
        incidentGrossWeight=incident.combinationMassKg/1000, vehicleDamageCost=ownDamage,
        thirdPartyLiability=thirdParty, legalCosts=legalCosts, excess=self:getTrafficCourtesyIncidentExcess(incident)
    }, incident)
    incident.estimatedPayout = evaluation ~= nil and (evaluation.estimatedPayout or 0) or 0
    self.repository:addTrafficCourtesyIncident(incident)
    local reference = self:getTrafficCourtesyIncidentReference(incident)
    local automaticClaim = nil
    if thirdPartyTarget then
        local opened, reason, claim = self:initiateTrafficCourtesyClaim(farmId, incident.id, {automaticThirdParty=true})
        if opened then
            automaticClaim = claim
        else
            print(string.format("[RealisticFarmFinance] Warning: automatic third-party claim was not opened for %s: %s", reference, tostring(reason)))
        end
    end
    if automaticClaim == nil then
        self:notify(farmId, "Own-Property Incident Recorded", string.format(
            "%s records the %s impact involving %s and the farm's own %s. No third-party claim has been opened; any eligible own-damage claim remains your decision.",
            reference, string.lower(incident.severityClass), incident.partName, incident.targetName))
    end
    print(string.format("[RealisticFarmFinance] Traffic Courtesy incident=%s external=%s farm=%d vehicle=%s targetType=%s target=%s severity=%s closing=%.1fkm/h location=%s mass=%.2ft cover=%s status=%s licence=%s category=%s held=%s adrRequired=%s adrHeld=%s own=%.2f third=%.2f legal=%.2f estimatedPayout=%.2f",
        reference, externalIncidentId, farmId, vehicleUniqueId, incident.targetType, incident.targetName,
        incident.severityClass, incident.closingSpeedMps*3.6, incident.locationType, incident.combinationMassKg/1000,
        incident.policyCoverType, incident.policyStatusAtIncident, incident.licenceComplianceStatus,
        incident.licenceRequiredCategory, tostring(incident.licenceEntitlementHeld), tostring(incident.licenceAdrRequired),
        tostring(incident.licenceAdrHeld), ownDamage, thirdParty, legalCosts, incident.estimatedPayout))
    return true, automaticClaim ~= nil and "automatic_claim" or "recorded", incident
end

function RFF_InsuranceClaimService:onTrafficCourtesyIncident(entry)
    local ok, reason = self:recordTrafficCourtesyIncident(entry)
    if not ok and reason ~= "duplicate" and reason ~= "grouped" then
        print(string.format("[RealisticFarmFinance] Traffic Courtesy incident was not recorded: %s", tostring(reason)))
    end
end

function RFF_InsuranceClaimService:resolveTrafficCourtesyApi()
    -- GIANTS runs each scripted mod in its own environment. A value declared by
    -- Traffic Courtesy therefore belongs to the FS25_DM_TrafficCourtesy table,
    -- rather than RFF's own _G table. Keep the direct lookup as a compatibility
    -- fallback for API versions that may publish into the shared environment.
    local directApi = _G["DerwenTrafficIncidents"]
    if type(directApi) == "table" then return directApi, "shared environment" end

    local trafficCourtesyEnvironment = _G["FS25_DM_TrafficCourtesy"]
    local modApi = type(trafficCourtesyEnvironment) == "table"
        and rawget(trafficCourtesyEnvironment, "DerwenTrafficIncidents") or nil
    if type(modApi) == "table" then return modApi, "FS25_DM_TrafficCourtesy mod environment" end
    return nil, nil
end

function RFF_InsuranceClaimService:installTrafficCourtesyHook()
    local api, source = self:resolveTrafficCourtesyApi()
    if type(api) ~= "table" or type(api.registerIncidentListener) ~= "function" then
        local loadedMods = _G["g_modIsLoaded"]
        local isLoaded = type(loadedMods) == "table" and loadedMods["FS25_DM_TrafficCourtesy"] == true
        if isLoaded and self._trafficCourtesyLookupWarningLogged ~= true then
            print("[RealisticFarmFinance] Warning: Traffic Courtesy is active but its incident API could not be resolved; RFF collision notifications and claim records are unavailable")
            self._trafficCourtesyLookupWarningLogged = true
        end
        return false
    end
    local version = type(api.getApiVersion) == "function" and safeNumber(api:getApiVersion()) or safeNumber(api.API_VERSION)
    if version < 1 then
        if self._trafficCourtesyLookupWarningLogged ~= true then
            print(string.format("[RealisticFarmFinance] Warning: Traffic Courtesy incident API version %.0f is unsupported", version))
            self._trafficCourtesyLookupWarningLogged = true
        end
        return false
    end
    if self._trafficCourtesyRegistered and self._trafficCourtesyApi == api then return true end
    if self._trafficCourtesyApi ~= nil and type(self._trafficCourtesyApi.unregisterIncidentListener) == "function" then
        pcall(self._trafficCourtesyApi.unregisterIncidentListener, self._trafficCourtesyApi, self)
    end
    local ok, registered = pcall(api.registerIncidentListener, api, self, self.onTrafficCourtesyIncident)
    if not ok or registered ~= true then
        if self._trafficCourtesyLookupWarningLogged ~= true then
            print(string.format("[RealisticFarmFinance] Warning: Traffic Courtesy incident-listener registration failed: %s",
                ok and "API returned false" or tostring(registered)))
            self._trafficCourtesyLookupWarningLogged = true
        end
        return false
    end
    self._trafficCourtesyApi = api
    self._trafficCourtesyRegistered = true
    self._trafficCourtesyLookupWarningLogged = false
    print(string.format("[RealisticFarmFinance] Traffic Courtesy incident API connected via %s (version %d)", source or "unknown source", version))
    return true
end

function RFF_InsuranceClaimService:shutdownTrafficCourtesyHook()
    if self._trafficCourtesyApi ~= nil and type(self._trafficCourtesyApi.unregisterIncidentListener) == "function" then
        pcall(self._trafficCourtesyApi.unregisterIncidentListener, self._trafficCourtesyApi, self)
    end
    self._trafficCourtesyApi = nil
    self._trafficCourtesyRegistered = false
end

function RFF_InsuranceClaimService:expireTrafficCourtesyIncidents(farmId)
    if self.repository == nil then return 0 end
    local expired = 0
    for _, incident in ipairs(self.repository:getTrafficCourtesyIncidentsByFarm(farmId) or {}) do
        if incident.status == self.TRAFFIC_INCIDENT_RECORDED and self:isTrafficCourtesyIncidentExpired(incident) then
            incident.status = self.TRAFFIC_INCIDENT_EXPIRED
            expired = expired + 1
        end
    end
    return expired
end

function RFF_InsuranceClaimService:getTrafficCourtesyIncidentDescription(incident)
    if incident == nil then return "Traffic Courtesy incident details are unavailable." end
    local adsText = incident.adsSourceSystems ~= nil and incident.adsSourceSystems ~= "" and incident.adsSourceSystems or "no compatible ADS system damage recorded"
    if incident.adsSourceBreakdowns ~= nil and incident.adsSourceBreakdowns ~= "" then adsText = adsText .. "; breakdowns " .. incident.adsSourceBreakdowns end
    return string.format("%s %s impact: %s to %s at %.0f km/h closing speed. Zones %s / %s; %s; train mass %.1f t; fault %s. ADS: %s.",
        incident.externalIncidentId or "Traffic Courtesy", string.lower(incident.severityClass or "unknown"),
        incident.partName or incident.vehicleName or "Vehicle", incident.targetName or "Unknown object",
        safeNumber(incident.closingSpeedMps)*3.6, incident.impactZone or "UNKNOWN", incident.targetImpactZone or "UNKNOWN",
        incident.locationType or "UNKNOWN", safeNumber(incident.combinationMassKg)/1000,
        string.lower(incident.faultAssessment or "unknown"), adsText)
end

function RFF_InsuranceClaimService:initiateTrafficCourtesyClaim(farmId, incidentId, options)
    if self.repository == nil or g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end
    options = options or {}
    local incident = self.repository:getTrafficCourtesyIncidentById(farmId, incidentId)
    if incident == nil then return false, "incident" end
    if incident.status ~= self.TRAFFIC_INCIDENT_RECORDED then return false, "status" end
    if self:isTrafficCourtesyIncidentExpired(incident) then
        incident.status = self.TRAFFIC_INCIDENT_EXPIRED
        return false, "expired"
    end
    local policy = incident.policyCoverType ~= "NONE" and {
        id=incident.policyId, coverType=incident.policyCoverType, legalCover=incident.policyLegalCover,
        useScope=incident.policyUseScope, maxGrossWeight=incident.policyMaxGrossWeight,
        insuredValue=incident.policyInsuredValue
    } or nil
    local ok, reason, claim = self:createVehicleClaim(farmId, incident.vehicleUniqueId, {
        source="TRAFFIC_COURTESY", externalIncidentId=incident.externalIncidentId,
        groupedExternalIncidentIds=incident.groupedExternalIncidentIds,
        groupedIncidentCount=incident.groupedIncidentCount,
        trafficIncidentId=incident.id, incidentDay=incident.incidentDay, incidentPeriod=incident.incidentPeriod,
        x=incident.x, y=incident.y, z=incident.z, locationType=incident.locationType,
        grossWeight=incident.combinationMassKg/1000, vehicleDamageCost=incident.ownDamageEstimate,
        thirdPartyLiability=incident.thirdPartyEstimate, legalCosts=incident.legalCostEstimate,
        description=self:getTrafficCourtesyIncidentDescription(incident), partName=incident.partName,
        targetName=incident.targetName, targetType=incident.targetType, severity=incident.severityClass,
        impactZone=incident.impactZone, targetImpactZone=incident.targetImpactZone,
        closingSpeedMps=incident.closingSpeedMps, faultAssessment=incident.faultAssessment,
        adsSourceDamage=incident.adsSourceDamage, adsSourceSystems=incident.adsSourceSystems,
        adsSourceBreakdowns=incident.adsSourceBreakdowns,
        adsLogBaselineId=incident.adsLogBaselineId,
        licenceSnapshot=incident,
        automaticThirdParty=options.automaticThirdParty == true,
        thirdPartyReported=incident.thirdPartyTarget == true,
        policySnapshot={
            vehicleUniqueId=incident.vehicleUniqueId, vehicleName=incident.vehicleName,
            insuranceStatus=incident.policyStatusAtIncident, policy=policy,
            locationType=incident.locationType, grossWeight=incident.combinationMassKg/1000,
            positionX=incident.x, positionY=incident.y, positionZ=incident.z
        }
    })
    if not ok and reason == "duplicate" and claim ~= nil then
        incident.status = self.TRAFFIC_INCIDENT_CLAIMED
        incident.claimId = claim.id or 0
        return true, "existing", claim
    end
    if not ok or claim == nil then return false, reason end
    incident.status = self.TRAFFIC_INCIDENT_CLAIMED
    incident.claimId = claim.id or 0
    return true, "submitted", claim
end

function RFF_InsuranceClaimService:evaluateVehicleClaim(claim, licenceSource)
    if claim == nil then return nil end
    local coverType = tostring(claim.policyCoverType or claim.policyTier or "NONE")
    local locationType = tostring(claim.incidentLocationType or "UNKNOWN")
    local useScope = tostring(claim.policyUseScope or "AGRICULTURAL_ROAD")
    local grossWeight = math.max(0, safeNumber(claim.incidentGrossWeight))
    local weightLimit = math.max(0, safeNumber(claim.policyMaxGrossWeight))
    local vehicleDamage = math.max(0, safeNumber(claim.vehicleDamageCost))
    local thirdParty = math.max(0, safeNumber(claim.thirdPartyLiability))
    local legalCosts = math.max(0, safeNumber(claim.legalCosts))
    local declineReason = nil
    local licenceBreach, licenceSnapshot = self:hasLicenceClaimBreach(licenceSource or claim)
    local licenceReason = licenceBreach and self:getLicenceClaimReason(licenceSnapshot) or nil

    if not self:isPolicyInForce(claim.policyStatusAtIncident) or coverType == "NONE" then
        declineReason = "NO_VEHICLE_COVER"
    elseif useScope == "FARMLAND_ONLY" and locationType == "ROAD" then
        declineReason = "ROAD_USE_EXCLUDED"
    elseif useScope == "FARMLAND_ONLY" and locationType == "OTHER" then
        declineReason = "USE_SCOPE_EXCLUDED"
    elseif weightLimit > 0 and grossWeight > weightLimit + 0.001 then
        declineReason = "WEIGHT_LIMIT_EXCEEDED"
    end

    local eligibleVehicleDamage = coverType == "COMPREHENSIVE" and not licenceBreach and vehicleDamage or 0
    local eligibleThirdParty = (coverType == "COMPREHENSIVE" or coverType == "THIRD_PARTY") and thirdParty or 0
    local eligibleLegalCosts = claim.policyLegalCover == true and legalCosts or 0
    if declineReason ~= nil then
        eligibleVehicleDamage, eligibleThirdParty, eligibleLegalCosts = 0, 0, 0
    end

    local excluded = {}
    if vehicleDamage > 0 and eligibleVehicleDamage <= 0 and declineReason == nil then
        excluded[#excluded + 1] = licenceBreach and "own vehicle damage following the recorded licence breach" or "own vehicle damage"
    end
    if legalCosts > 0 and eligibleLegalCosts <= 0 and declineReason == nil then excluded[#excluded + 1] = "legal costs" end
    local eligibleDamageAndLiability = eligibleVehicleDamage + eligibleThirdParty
    local indemnityFactor = coverType == "COMPREHENSIVE" and 0.95 or 0.90
    local excess = math.max(0, safeNumber(claim.excess))
    local grossSettlement = eligibleDamageAndLiability * indemnityFactor + eligibleLegalCosts
    local claimValue = vehicleDamage + thirdParty + legalCosts
    local payout = math.min(claimValue, math.max(0, math.floor(grossSettlement - excess + 0.5)))

    if declineReason == nil and eligibleDamageAndLiability + eligibleLegalCosts <= 0 then
        if vehicleDamage > 0 and licenceBreach then declineReason = licenceReason
        elseif vehicleDamage > 0 and coverType == "THIRD_PARTY" then declineReason = "OWN_DAMAGE_NOT_COVERED"
        elseif legalCosts > 0 and claim.policyLegalCover ~= true then declineReason = "LEGAL_COVER_NOT_INCLUDED"
        else declineReason = "NO_ELIGIBLE_VEHICLE_LOSS" end
    elseif declineReason == nil and payout <= 0 then
        declineReason = "BELOW_EXCESS"
    end

    local summary = "All submitted vehicle-loss components are within the recorded policy terms."
    if #excluded > 0 then summary = "Excluded from this claim: " .. table.concat(excluded, " and ") .. "." end
    if licenceBreach and declineReason == nil then
        summary = "Own-vehicle damage is excluded following the recorded licence breach. Eligible third-party payments remain protected, but the insurer may recover its contribution from the farm."
    end
    if declineReason ~= nil then summary = self:getOutcomeText(declineReason) .. "." end
    return {
        declineReason = declineReason,
        eligibleVehicleDamage = eligibleVehicleDamage,
        eligibleThirdPartyLiability = eligibleThirdParty,
        eligibleLegalCosts = eligibleLegalCosts,
        indemnityFactor = indemnityFactor,
        excess = excess,
        estimatedPayout = payout,
        coverageSummary = summary,
        licenceBreach = licenceBreach,
        licenceReason = licenceReason,
        insurerRecoveryApplies = licenceBreach and eligibleThirdParty + eligibleLegalCosts > 0
    }
end

function RFF_InsuranceClaimService:refreshVehicleClaimEvaluation(claim)
    local evaluation = self:evaluateVehicleClaim(claim)
    if evaluation == nil then return nil end
    claim.eligibleVehicleDamage = evaluation.eligibleVehicleDamage
    claim.eligibleThirdPartyLiability = evaluation.eligibleThirdPartyLiability
    claim.eligibleLegalCosts = evaluation.eligibleLegalCosts
    claim.indemnityFactor = evaluation.indemnityFactor
    claim.excess = evaluation.excess
    local claimValue = math.max(0, safeNumber(claim.incidentValue))
    if claimValue <= 0 then
        claimValue = math.max(0, safeNumber(claim.vehicleDamageCost))
            + math.max(0, safeNumber(claim.thirdPartyLiability))
            + math.max(0, safeNumber(claim.legalCosts))
    end
    claim.estimatedPayout = math.min(claimValue, math.max(0, safeNumber(evaluation.estimatedPayout)))
    claim.coverageSummary = evaluation.coverageSummary
    claim.licenceRecoveryApplies = evaluation.insurerRecoveryApplies == true
    return evaluation
end

function RFF_InsuranceClaimService:createVehicleClaim(farmId, vehicleUniqueId, incidentData)
    if self.repository == nil or self.fleetManagement == nil or farmId == nil or farmId <= 0 then return false, "service" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end
    incidentData = incidentData or {}
    local externalIncidentId = tostring(incidentData.externalIncidentId or "")
    if externalIncidentId ~= "" and self.repository.getInsuranceClaimByExternalId ~= nil then
        local existingClaim = self.repository:getInsuranceClaimByExternalId(externalIncidentId)
        if existingClaim ~= nil then return false, "duplicate", existingClaim end
    end
    local context = {
        x = incidentData.x,
        y = incidentData.y,
        z = incidentData.z,
        locationType = incidentData.locationType,
        grossWeight = incidentData.grossWeight
    }
    local compliance = type(incidentData.policySnapshot) == "table" and incidentData.policySnapshot or nil
    local reason = compliance ~= nil and "snapshot" or nil
    if compliance == nil then compliance, reason = self.fleetManagement:getPolicyCompliance(farmId, vehicleUniqueId, context) end
    if compliance == nil then return false, reason or "vehicle" end
    local hasFrozenLicenceSource = type(incidentData.licenceSnapshot) == "table"
    local licenceSnapshot = self:normaliseLicenceSnapshot(incidentData.licenceSnapshot)
    if licenceSnapshot.licenceSnapshotVersion < self.LICENCE_SNAPSHOT_VERSION and not hasFrozenLicenceSource then
        licenceSnapshot = self:captureLicenceSnapshot(farmId, vehicleUniqueId, compliance, context)
    end
    local licenceBreach = self:hasLicenceClaimBreach(licenceSnapshot)

    local vehicleDamage = math.max(0, safeNumber(incidentData.vehicleDamageCost))
    local thirdParty = math.max(0, safeNumber(incidentData.thirdPartyLiability))
    local legalCosts = math.max(0, safeNumber(incidentData.legalCosts))
    local fallbackAmount = math.max(0, safeNumber(incidentData.amount))
    local lossType = string.upper(tostring(incidentData.lossType or "OWN_DAMAGE"))
    if vehicleDamage + thirdParty + legalCosts <= 0 and fallbackAmount > 0 then
        if lossType == "THIRD_PARTY" then thirdParty = fallbackAmount
        elseif lossType == "LEGAL" then legalCosts = fallbackAmount
        elseif lossType == "MIXED" then
            vehicleDamage = fallbackAmount * 0.50
            thirdParty = fallbackAmount * 0.40
            legalCosts = fallbackAmount * 0.10
        else vehicleDamage = fallbackAmount end
    end
    local total = vehicleDamage + thirdParty + legalCosts
    if total <= 0 then return false, "amount" end

    local policy = compliance.policy
    local coverType = policy ~= nil and tostring(policy.coverType or "NONE") or "NONE"
    local excess = compliance.insuranceStatus == "TEMPORARY" and 750
        or (coverType == "COMPREHENSIVE" and 350 or (coverType == "THIRD_PARTY" and 500 or 0))
    local currentDay = self:getCurrentDay()
    local source = tostring(incidentData.source or "RFF_VEHICLE")
    local trafficWorkflow = source == "TRAFFIC_COURTESY"
    local automaticThirdParty = trafficWorkflow and incidentData.automaticThirdParty == true and thirdParty > 0
    local adsVehicle = compliance.vehicle
    if adsVehicle == nil and self.fleetManagement ~= nil then adsVehicle = self.fleetManagement:findVehicle(farmId, vehicleUniqueId) end
    local adsRequired = trafficWorkflow and vehicleDamage > 0 and coverType == "COMPREHENSIVE" and not licenceBreach
        and self:isPolicyInForce(compliance.insuranceStatus)
        and RFF_ADSIntegration ~= nil and RFF_ADSIntegration:isAvailable()
        and RFF_ADSIntegration:isVehicleSupported(adsVehicle)
    local ownDamageStatus = "NOT_APPLICABLE"
    if vehicleDamage > 0 then
        if coverType ~= "COMPREHENSIVE" or not self:isPolicyInForce(compliance.insuranceStatus) then
            ownDamageStatus = "NOT_COVERED"
        elseif licenceBreach then
            ownDamageStatus = "NOT_COVERED_LICENCE"
        elseif adsRequired then
            ownDamageStatus = "AWAITING_INSPECTION"
        else
            ownDamageStatus = "READY"
        end
    end
    local initialStatus = self.STATUS_UNDER_REVIEW
    if automaticThirdParty then initialStatus = self.STATUS_AWAITING_RESPONSE
    elseif ownDamageStatus == "AWAITING_INSPECTION" then initialStatus = self.STATUS_AWAITING_ADS_INSPECTION end
    local responseWindowDays = automaticThirdParty and math.max(1, self:getDaysPerPeriod() * self.TRAFFIC_RESPONSE_WINDOW_PERIODS) or 0
    local initialDecisionDay = currentDay + self:getAssessmentDelayDays()
    if automaticThirdParty or ownDamageStatus == "AWAITING_INSPECTION" then initialDecisionDay = 0 end
    local claim = {
        id = self.repository:getNextInsuranceClaimId(),
        farmId = farmId,
        insurerId = self.INSURER_ID,
        source = source,
        claimType = "VEHICLE",
        status = initialStatus,
        lossId = 0,
        incidentDay = math.floor(safeNumber(incidentData.incidentDay) > 0 and safeNumber(incidentData.incidentDay) or currentDay),
        incidentPeriod = math.floor(safeNumber(incidentData.incidentPeriod) > 0 and safeNumber(incidentData.incidentPeriod) or self:getCurrentPeriod()),
        submittedDay = currentDay,
        decisionDay = initialDecisionDay,
        approvedDay = 0, settlementDay = 0, paidDay = 0,
        policyTier = coverType,
        policyStatusAtIncident = compliance.insuranceStatus or "UNINSURED",
        policyId = policy ~= nil and (policy.id or 0) or 0,
        policyCoverType = coverType,
        policyLegalCover = policy ~= nil and policy.legalCover == true or false,
        policyUseScope = policy ~= nil and tostring(policy.useScope or "AGRICULTURAL_ROAD") or "NONE",
        policyMaxGrossWeight = policy ~= nil and math.max(0, safeNumber(policy.maxGrossWeight)) or 0,
        vehicleUniqueId = tostring(compliance.vehicleUniqueId or vehicleUniqueId or ""),
        vehicleName = compliance.vehicleName or "Vehicle",
        incidentLocationType = compliance.locationType or "UNKNOWN",
        incidentGrossWeight = compliance.grossWeight or 0,
        incidentX = safeNumber(compliance.positionX), incidentY = safeNumber(compliance.positionY), incidentZ = safeNumber(compliance.positionZ),
        externalIncidentId = externalIncidentId,
        groupedExternalIncidentIds = tostring(incidentData.groupedExternalIncidentIds or externalIncidentId),
        groupedIncidentCount = math.max(1, math.floor(safeNumber(incidentData.groupedIncidentCount))),
        incidentDescription = tostring(incidentData.description or "Vehicle incident"),
        trafficIncidentId = math.floor(safeNumber(incidentData.trafficIncidentId)),
        incidentPartName = tostring(incidentData.partName or ""),
        incidentTargetName = tostring(incidentData.targetName or ""),
        incidentTargetType = tostring(incidentData.targetType or ""),
        incidentSeverity = tostring(incidentData.severity or ""),
        incidentImpactZone = tostring(incidentData.impactZone or ""),
        incidentTargetImpactZone = tostring(incidentData.targetImpactZone or ""),
        incidentClosingSpeedMps = math.max(0, safeNumber(incidentData.closingSpeedMps)),
        incidentFaultAssessment = tostring(incidentData.faultAssessment or "UNKNOWN"),
        incidentAdsSourceDamage = math.max(0, safeNumber(incidentData.adsSourceDamage)),
        incidentAdsSourceSystems = tostring(incidentData.adsSourceSystems or ""),
        incidentAdsSourceBreakdowns = tostring(incidentData.adsSourceBreakdowns or ""),
        trafficWorkflowVersion = trafficWorkflow and self.TRAFFIC_WORKFLOW_VERSION or 0,
        thirdPartyReported = incidentData.thirdPartyReported == true,
        responseDeadlineDay = automaticThirdParty and (currentDay + responseWindowDays) or 0,
        responseWarningSent = false,
        defaultAfterDay = 0,
        responseDay = 0,
        liabilityStatus = thirdParty > 0 and (automaticThirdParty and "AWAITING_RESPONSE" or "UNDER_REVIEW") or "NOT_APPLICABLE",
        liabilityDecisionDay = automaticThirdParty and 0 or (thirdParty > 0 and currentDay + self:getAssessmentDelayDays() or 0),
        liabilitySettlementDay = 0,
        liabilityInsurerPaid = 0,
        liabilityFarmCharge = 0,
        liabilityPolicyShortfall = 0,
        liabilityInsurerRecovery = 0,
        liabilityExcessConsumed = 0,
        ownDamageEstimate = vehicleDamage,
        ownDamageStatus = ownDamageStatus,
        adsRequired = adsRequired,
        adsLogBaselineId = math.max(0, math.floor(safeNumber(incidentData.adsLogBaselineId))),
        adsInspectionLogId = 0,
        adsInspectionCost = 0,
        adsRepairCost = 0,
        adsInspectionIssueCount = 0,
        adsWarrantyRepair = false,
        adsNonOemRepair = false,
        actualOwnDamageCost = adsRequired and 0 or vehicleDamage,
        ownDecisionDay = ownDamageStatus == "READY" and currentDay + self:getAssessmentDelayDays() or 0,
        ownSettlementDay = 0,
        ownApprovedAmount = 0,
        ownPaidAmount = 0,
        defaultCharge = 0,
        vehicleDamageCost = vehicleDamage,
        thirdPartyLiability = thirdParty,
        legalCosts = legalCosts,
        animalUniqueId = "", animalName = "", animalBreed = "", animalSubType = "",
        animalType = "VEHICLE", animalAge = 0, animalHealth = 0,
        deathReason = "VEHICLE_INCIDENT",
        incidentValue = total,
        indemnityFactor = coverType == "COMPREHENSIVE" and 0.95 or 0.90,
        excess = excess,
        amountClaimed = total,
        formSignedBy = tostring(incidentData.signedBy or ""), formVersion = 1,
        approvedAmount = 0, paidAmount = 0, outcomeReason = ""
    }
    self:applyLicenceSnapshot(claim, licenceSnapshot)
    local evaluation = self:refreshVehicleClaimEvaluation(claim)
    self.repository:addInsuranceClaim(claim)
    if trafficWorkflow then self:updateTrafficClaimStatus(claim) end
    if trafficWorkflow and claim.status == self.STATUS_DECLINED then
        claim.outcomeReason = evaluation.declineReason or "OWN_DAMAGE_NOT_COVERED"
    end

    local reference = self:getClaimReference(claim)
    if automaticThirdParty then
        local licenceText = self:getLicenceDecisionSummary(claim)
        if licenceText ~= "" then licenceText = " " .. licenceText end
        self:notify(farmId, "Third-Party Claim Received", string.format(
            "%s has been reported by the other party following the collision involving %s and %s. Liability is presumed against the farm.%s Respond in Business Insurance within one month; if no response is received, a final warning will be issued before the estimated third-party costs become payable by the farm.",
            reference, claim.incidentPartName ~= "" and claim.incidentPartName or claim.vehicleName, claim.incidentTargetName ~= "" and claim.incidentTargetName or "the third party", licenceText))
    elseif claim.status == self.STATUS_DECLINED and licenceBreach then
        self:notify(farmId, "Vehicle Claim Declined - Licence Breach", string.format(
            "%s cannot include own-vehicle damage because the required licence or ADR entitlement was not held at the road incident. The collision record remains in the central claims register.", reference))
    else
        local licenceText = self:getLicenceDecisionSummary(claim)
        if licenceText ~= "" then licenceText = " " .. licenceText end
        self:notify(farmId, "Vehicle Claim Submitted", string.format(
            "%s has been submitted for %s. The incident location, operating mass, policy terms and collision-time licence position have been recorded for assessment.%s",
            reference, formatMoney(total), licenceText))
    end
    print(string.format("[RealisticFarmFinance] vehicle claim submitted=%s farm=%d vehicle=%s cover=%s status=%s location=%s grossWeight=%.2ft limit=%.2ft licence=%s category=%s held=%s adrRequired=%s adrHeld=%s ownDamage=%.2f thirdParty=%.2f legal=%.2f estimated=%.2f",
        reference, farmId, tostring(vehicleUniqueId), coverType, tostring(claim.policyStatusAtIncident),
        tostring(claim.incidentLocationType), claim.incidentGrossWeight or 0, claim.policyMaxGrossWeight or 0,
        claim.licenceComplianceStatus, claim.licenceRequiredCategory, tostring(claim.licenceEntitlementHeld),
        tostring(claim.licenceAdrRequired), tostring(claim.licenceAdrHeld),
        vehicleDamage, thirdParty, legalCosts, claim.estimatedPayout or 0))
    return true, "submitted", claim
end

function RFF_InsuranceClaimService:isTrafficWorkflowClaim(claim)
    return claim ~= nil and claim.claimType == "VEHICLE" and claim.source == "TRAFFIC_COURTESY"
        and math.floor(safeNumber(claim.trafficWorkflowVersion)) >= self.TRAFFIC_WORKFLOW_VERSION
end

function RFF_InsuranceClaimService:getTrafficClaimResponseDaysRemaining(claim)
    if claim == nil or claim.liabilityStatus ~= "AWAITING_RESPONSE" then return 0 end
    return math.max(0, math.floor(safeNumber(claim.responseDeadlineDay) - self:getCurrentDay()))
end

function RFF_InsuranceClaimService:updateTrafficClaimStatus(claim)
    if not self:isTrafficWorkflowClaim(claim) then return end
    self:refreshVehicleClaimEvaluation(claim)
    if claim.liabilityStatus == "DEFAULTED" then
        claim.status = self.STATUS_DEFAULTED
    elseif claim.liabilityStatus == "AWAITING_RESPONSE" then
        claim.status = self.STATUS_AWAITING_RESPONSE
    elseif claim.ownDamageStatus == "AWAITING_INSPECTION" then
        claim.status = self.STATUS_AWAITING_ADS_INSPECTION
    elseif claim.ownDamageStatus == "AWAITING_OEM_REPAIR" then
        claim.status = self.STATUS_AWAITING_OEM_REPAIR
    elseif claim.ownDamageStatus == "APPROVED" then
        claim.status = self.STATUS_APPROVED
    elseif claim.liabilityStatus == "UNDER_REVIEW" or claim.ownDamageStatus == "READY" then
        claim.status = self.STATUS_UNDER_REVIEW
    elseif claim.liabilityStatus == "NOT_APPLICABLE"
            and (claim.ownDamageStatus == "NOT_COVERED" or claim.ownDamageStatus == "NOT_COVERED_LICENCE"
                or claim.ownDamageStatus == "DECLINED_NON_OEM") then
        claim.status = self.STATUS_DECLINED
    else
        claim.status = self.STATUS_SETTLED
    end
    local claimValue = math.max(0, safeNumber(claim.incidentValue))
    claim.approvedAmount = math.min(claimValue,
        math.max(0, safeNumber(claim.liabilityInsurerPaid)) + math.max(0, safeNumber(claim.ownApprovedAmount)))
    claim.paidAmount = math.min(claimValue,
        math.max(0, safeNumber(claim.liabilityInsurerPaid)) + math.max(0, safeNumber(claim.ownPaidAmount)))
end

function RFF_InsuranceClaimService:acknowledgeTrafficCourtesyClaim(farmId, claimId)
    if self.repository == nil or g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end
    local claim = self.repository:getInsuranceClaimById(farmId, claimId)
    if not self:isTrafficWorkflowClaim(claim) then return false, "claim" end
    if claim.liabilityStatus ~= "AWAITING_RESPONSE" then return false, "status" end

    local currentDay = self:getCurrentDay()
    claim.responseDay = currentDay
    claim.liabilityStatus = "UNDER_REVIEW"
    claim.liabilityDecisionDay = currentDay + self:getAssessmentDelayDays()
    claim.responseWarningSent = claim.responseWarningSent == true
    self:updateTrafficClaimStatus(claim)

    local technicalText = ""
    if claim.ownDamageStatus == "AWAITING_INSPECTION" then
        technicalText = " For any own-damage settlement, complete a Full Defectoscopy in ADS and repair every identified fault using OEM parts."
    end
    local licenceText = self:getLicenceDecisionSummary(claim)
    if licenceText ~= "" then licenceText = " " .. licenceText end
    self:notify(farmId, "Claim Response Recorded", string.format(
        "%s has been acknowledged and referred to the insurer. Third-party liability will now be assessed under the policy and licence position recorded at the collision.%s%s",
        self:getClaimReference(claim), licenceText, technicalText))
    return true, "acknowledged", claim
end

function RFF_InsuranceClaimService:chargeTrafficClaimCost(claim, amount, description)
    amount = math.max(0, safeNumber(amount))
    if amount <= 0 then return true end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false end
    if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(claim.farmId, description or "Third-party collision liability")
    end
    g_currentMission:addMoney(-amount, claim.farmId, otherMoneyType(), true, true)
    return true
end

function RFF_InsuranceClaimService:defaultTrafficCourtesyClaim(claim, currentDay)
    local amount = math.max(0, safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts))
    if not self:chargeTrafficClaimCost(claim, amount, "Unanswered third-party collision claim") then return false end
    claim.liabilityStatus = "DEFAULTED"
    claim.liabilityFarmCharge = amount
    claim.defaultCharge = amount
    claim.liabilitySettlementDay = currentDay
    claim.ownDamageStatus = "ABANDONED"
    claim.outcomeReason = "POLICYHOLDER_NO_RESPONSE"
    self:updateTrafficClaimStatus(claim)
    self:notify(claim.farmId, "Third-Party Claim Determined", string.format(
        "%s was not answered after the response period and final warning. Liability has been determined in default and %s of estimated third-party and associated legal costs has been charged to the farm.",
        self:getClaimReference(claim), formatMoney(amount)))
    return true
end

function RFF_InsuranceClaimService:processTrafficClaimResponse(claim, currentDay, forceNow)
    if claim.liabilityStatus ~= "AWAITING_RESPONSE" then return false end
    local deadlineDay = math.floor(safeNumber(claim.responseDeadlineDay))
    if claim.responseWarningSent == true then
        if forceNow == true or currentDay >= math.max(deadlineDay + 1, math.floor(safeNumber(claim.defaultAfterDay))) then
            return self:defaultTrafficCourtesyClaim(claim, currentDay)
        end
        return false
    end
    if forceNow == true or currentDay >= deadlineDay then
        claim.responseWarningSent = true
        claim.defaultAfterDay = currentDay + 1
        self:notify(claim.farmId, "Final Claim Response Warning", string.format(
            "%s has not been answered. Respond in Business Insurance before the next day change or the estimated third-party and associated legal costs of %s will be charged directly to the farm.",
            self:getClaimReference(claim), formatMoney(safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts))))
        return true
    end
    return false
end

function RFF_InsuranceClaimService:processTrafficClaimTechnicalEvidence(claim, currentDay)
    if claim.ownDamageStatus ~= "AWAITING_INSPECTION" and claim.ownDamageStatus ~= "AWAITING_OEM_REPAIR" then return false end
    if RFF_ADSIntegration == nil or self.fleetManagement == nil then return false end
    local vehicle = self.fleetManagement:findVehicle(claim.farmId, claim.vehicleUniqueId)
    if vehicle == nil or not RFF_ADSIntegration:isVehicleSupported(vehicle) then return false end
    local evidence = RFF_ADSIntegration:getAccidentClaimEvidence(vehicle, claim.adsLogBaselineId)
    if not evidence.adsApplied or not evidence.inspectionCompleted then return false end

    local changed = false
    if safeNumber(claim.adsInspectionLogId) ~= safeNumber(evidence.inspectionLogId) then
        claim.adsInspectionLogId = evidence.inspectionLogId
        claim.adsInspectionCost = evidence.inspectionCost
        claim.adsInspectionIssueCount = evidence.inspectionIssueCount
        changed = true
    end
    if evidence.nonOemRepairCompleted then
        claim.adsNonOemRepair = true
        claim.ownDamageStatus = "DECLINED_NON_OEM"
        claim.actualOwnDamageCost = 0
        claim.vehicleDamageCost = 0
        claim.incidentValue = math.max(0, safeNumber(claim.thirdPartyLiability)) + math.max(0, safeNumber(claim.legalCosts))
        claim.amountClaimed = claim.incidentValue
        claim.outcomeReason = "ADS_OEM_REPAIR_REQUIRED"
        self:notify(claim.farmId, "Own-Damage Evidence Rejected", string.format(
            "%s cannot include the vehicle repair because ADS records show that a post-inspection repair used non-OEM parts. The third-party part of the case is unaffected.",
            self:getClaimReference(claim)))
        self:updateTrafficClaimStatus(claim)
        return true
    end

    if evidence.inspectionIssueCount <= 0 then
        claim.adsRepairCost = 0
        claim.adsWarrantyRepair = false
        claim.actualOwnDamageCost = math.max(0, evidence.inspectionCost)
        claim.vehicleDamageCost = claim.actualOwnDamageCost
        claim.ownDamageStatus = "READY"
        claim.ownDecisionDay = currentDay + self:getAssessmentDelayDays()
        claim.incidentValue = claim.vehicleDamageCost + safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts)
        claim.amountClaimed = claim.incidentValue
        self:notify(claim.farmId, "Defectoscopy Evidence Received", string.format(
            "%s now records a completed ADS Full Defectoscopy. No repairable faults were identified; the verified own-damage cost is the %s inspection charge.",
            self:getClaimReference(claim), formatMoney(claim.adsInspectionCost)))
        self:updateTrafficClaimStatus(claim)
        return true
    end

    if evidence.oemRepairCompleted and evidence.remainingVisibleBreakdowns <= 0 then
        claim.adsRepairCost = evidence.repairCost
        claim.adsWarrantyRepair = evidence.warrantyRepair == true
        claim.actualOwnDamageCost = math.max(0, evidence.inspectionCost + evidence.repairCost)
        claim.vehicleDamageCost = claim.actualOwnDamageCost
        claim.ownDamageStatus = "READY"
        claim.ownDecisionDay = currentDay + self:getAssessmentDelayDays()
        claim.incidentValue = claim.vehicleDamageCost + safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts)
        claim.amountClaimed = claim.incidentValue
        local warrantyText = claim.adsWarrantyRepair and " The OEM repair was completed under warranty at no repair cost." or ""
        self:notify(claim.farmId, "OEM Repair Evidence Received", string.format(
            "%s now records the completed ADS Full Defectoscopy and OEM repair. The verified assessment and repair cost is %s.%s",
            self:getClaimReference(claim), formatMoney(claim.actualOwnDamageCost), warrantyText))
        self:updateTrafficClaimStatus(claim)
        return true
    end

    if claim.ownDamageStatus ~= "AWAITING_OEM_REPAIR" then
        claim.ownDamageStatus = "AWAITING_OEM_REPAIR"
        self:notify(claim.farmId, "OEM Repair Required", string.format(
            "%s has received the ADS Full Defectoscopy. Complete the identified repair using OEM parts before the own-damage amount can be assessed.",
            self:getClaimReference(claim)))
        changed = true
    end
    self:updateTrafficClaimStatus(claim)
    return changed
end

function RFF_InsuranceClaimService:assessTrafficClaimLiability(claim, currentDay, forceNow)
    if claim.liabilityStatus ~= "UNDER_REVIEW"
            or (forceNow ~= true and currentDay < math.floor(safeNumber(claim.liabilityDecisionDay))) then return false end
    local evaluation = self:evaluateVehicleClaim({
        policyCoverType=claim.policyCoverType, policyTier=claim.policyTier,
        policyStatusAtIncident=claim.policyStatusAtIncident, policyLegalCover=claim.policyLegalCover,
        policyUseScope=claim.policyUseScope, policyMaxGrossWeight=claim.policyMaxGrossWeight,
        incidentLocationType=claim.incidentLocationType, incidentGrossWeight=claim.incidentGrossWeight,
        vehicleDamageCost=0, thirdPartyLiability=claim.thirdPartyLiability,
        legalCosts=claim.legalCosts, excess=claim.excess
    }, claim)
    local totalDemand = math.max(0, safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts))
    local insurerPaid = math.min(totalDemand, math.max(0, safeNumber(evaluation.estimatedPayout)))
    local policyShortfall = math.max(0, totalDemand - insurerPaid)
    local insurerRecovery = evaluation.insurerRecoveryApplies == true and insurerPaid or 0
    local farmCharge = policyShortfall + insurerRecovery
    local chargeDescription = insurerRecovery > 0 and "Third-party liability and insurer licence recovery"
        or "Third-party collision liability and policy shortfall"
    if not self:chargeTrafficClaimCost(claim, farmCharge, chargeDescription) then return false end

    local coveredBeforeExcess = math.max(0,
        safeNumber(evaluation.eligibleThirdPartyLiability) * safeNumber(evaluation.indemnityFactor)
        + safeNumber(evaluation.eligibleLegalCosts))
    claim.liabilityExcessConsumed = math.min(math.max(0, safeNumber(claim.excess)), coveredBeforeExcess)
    claim.liabilityInsurerPaid = insurerPaid
    claim.liabilityFarmCharge = farmCharge
    claim.liabilityPolicyShortfall = policyShortfall
    claim.liabilityInsurerRecovery = insurerRecovery
    claim.liabilitySettlementDay = currentDay
    claim.liabilityStatus = "SETTLED"
    claim.eligibleThirdPartyLiability = evaluation.eligibleThirdPartyLiability
    claim.eligibleLegalCosts = evaluation.eligibleLegalCosts
    claim.indemnityFactor = evaluation.indemnityFactor
    claim.coverageSummary = evaluation.coverageSummary
    if insurerRecovery > 0 then
        self:notify(claim.farmId, "Third-Party Liability Settled - Recovery", string.format(
            "%s has been assessed. The insurer paid %s directly toward the eligible third-party and legal costs, preserving the third party's compensation. Because of the licence breach recorded at the collision, that contribution is recoverable from the policyholder. The farm has been charged %s in total.",
            self:getClaimReference(claim), formatMoney(insurerPaid), formatMoney(farmCharge)))
    elseif insurerPaid > 0 then
        self:notify(claim.farmId, "Third-Party Liability Settled", string.format(
            "%s has been assessed. The insurer has paid %s directly toward the third-party and eligible legal costs; the farm has been charged %s for the policy excess or uncovered balance.",
            self:getClaimReference(claim), formatMoney(insurerPaid), formatMoney(farmCharge)))
    else
        self:notify(claim.farmId, "Third-Party Liability Payable", string.format(
            "%s is not covered under the policy terms recorded at the collision. %s has been charged to the farm for the third-party and associated legal costs.",
            self:getClaimReference(claim), formatMoney(farmCharge)))
    end
    self:updateTrafficClaimStatus(claim)
    return true
end

function RFF_InsuranceClaimService:processTrafficClaimOwnDamage(claim, currentDay, forceNow)
    if claim.ownDamageStatus == "READY"
            and (forceNow == true or currentDay >= math.floor(safeNumber(claim.ownDecisionDay))) then
        local remainingExcess = math.max(0, safeNumber(claim.excess) - safeNumber(claim.liabilityExcessConsumed))
        local evaluation = self:evaluateVehicleClaim({
            policyCoverType=claim.policyCoverType, policyTier=claim.policyTier,
            policyStatusAtIncident=claim.policyStatusAtIncident, policyLegalCover=false,
            policyUseScope=claim.policyUseScope, policyMaxGrossWeight=claim.policyMaxGrossWeight,
            incidentLocationType=claim.incidentLocationType, incidentGrossWeight=claim.incidentGrossWeight,
            vehicleDamageCost=claim.vehicleDamageCost, thirdPartyLiability=0, legalCosts=0,
            excess=remainingExcess
        }, claim)
        claim.ownApprovedAmount = math.max(0, safeNumber(evaluation.estimatedPayout))
        claim.eligibleVehicleDamage = evaluation.eligibleVehicleDamage
        if claim.ownApprovedAmount > 0 then
            claim.ownDamageStatus = "APPROVED"
            claim.ownSettlementDay = currentDay + self:getSettlementDelayDays()
            self:notify(claim.farmId, "Own-Damage Amount Approved", string.format(
                "%s has been approved for an own-damage reimbursement of %s based on the verified cost and remaining policy excess.",
                self:getClaimReference(claim), formatMoney(claim.ownApprovedAmount)))
        else
            claim.ownDamageStatus = "SETTLED"
            claim.outcomeReason = evaluation.declineReason or claim.outcomeReason
            self:notify(claim.farmId, "Own-Damage Assessment Complete", string.format(
                "%s has no own-damage reimbursement payable after the recorded policy terms and excess. The third-party part of the case is unaffected.",
                self:getClaimReference(claim)))
        end
        self:updateTrafficClaimStatus(claim)
        return true
    end
    if claim.ownDamageStatus == "APPROVED"
            and (forceNow == true or currentDay >= math.floor(safeNumber(claim.ownSettlementDay))) then
        local amount = math.max(0, safeNumber(claim.ownApprovedAmount))
        if amount > 0 and g_currentMission ~= nil and g_currentMission:getIsServer() then
            if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
                self.repository:setNextTransactionDescription(claim.farmId, "Verified vehicle own-damage reimbursement")
            end
            g_currentMission:addMoney(amount, claim.farmId, otherMoneyType(), true, true)
        end
        claim.ownPaidAmount = amount
        claim.ownDamageStatus = "SETTLED"
        claim.paidDay = currentDay
        self:notify(claim.farmId, "Own-Damage Reimbursement Settled", string.format(
            "%s has been completed. %s of verified own-damage costs has been credited to the farm account.",
            self:getClaimReference(claim), formatMoney(amount)))
        self:updateTrafficClaimStatus(claim)
        return true
    end
    return false
end

function RFF_InsuranceClaimService:processTrafficWorkflowClaim(claim, currentDay, forceNow)
    local changed = self:processTrafficClaimResponse(claim, currentDay, forceNow)
    if claim.liabilityStatus == "DEFAULTED" then return changed end
    if claim.liabilityStatus ~= "AWAITING_RESPONSE" then
        if self:assessTrafficClaimLiability(claim, currentDay, forceNow) then changed = true end
        if self:processTrafficClaimTechnicalEvidence(claim, currentDay) then changed = true end
        if self:processTrafficClaimOwnDamage(claim, currentDay, forceNow) then changed = true end
    end
    self:updateTrafficClaimStatus(claim)
    return changed
end

function RFF_InsuranceClaimService:assessVehicleClaim(claim, currentDay)
    local evaluation = self:refreshVehicleClaimEvaluation(claim)
    local reference = self:getClaimReference(claim)
    if evaluation.declineReason ~= nil then
        claim.status = self.STATUS_DECLINED
        claim.outcomeReason = evaluation.declineReason
        claim.approvedAmount = 0
        claim.approvedDay = currentDay
        self:notify(claim.farmId, "Vehicle Claim Decision", string.format(
            "%s has been declined. Reason: %s.", reference, self:getOutcomeText(evaluation.declineReason)))
        return true, "declined"
    end
    claim.status = self.STATUS_APPROVED
    claim.approvedAmount = evaluation.estimatedPayout
    claim.approvedDay = currentDay
    claim.settlementDay = currentDay + self:getSettlementDelayDays()
    claim.outcomeReason = (claim.coverageSummary or ""):find("Excluded", 1, true) ~= nil and "COVERED_WITH_EXCLUSIONS" or "COVERED"
    self:notify(claim.farmId, "Vehicle Claim Approved", string.format(
        "%s has been approved for %s after the policy excess of %s. %s",
        reference, formatMoney(claim.approvedAmount), formatMoney(claim.excess), claim.coverageSummary or "Settlement is being arranged."))
    return true, "approved"
end

function RFF_InsuranceClaimService:assessClaim(claim, forceNow)
    if claim == nil or claim.status ~= self.STATUS_UNDER_REVIEW then return false, "status" end
    local currentDay = self:getCurrentDay()
    if forceNow ~= true and currentDay < (claim.decisionDay or currentDay) then return false, "not_due" end
    if claim.claimType == "VEHICLE" then return self:assessVehicleClaim(claim, currentDay) end

    local terms = self:getTerms(claim.policyTier)
    local isVeterinary = claim.claimType == "VETERINARY"
    local declineReason = nil
    if not self:isPolicyInForce(claim.policyStatusAtIncident) then
        declineReason = "NO_COVER"
    elseif isVeterinary then
        if terms.veterinaryCovered ~= true then
            declineReason = "VETERINARY_NOT_COVERED"
        elseif safeNumber(claim.incidentValue) <= 0 then
            declineReason = "NO_TREATMENT_COST"
        end
    else
        if claim.deathReason == "OLD_AGE" and terms.oldAgeCovered ~= true then
            declineReason = "OLD_AGE_EXCLUDED"
        elseif claim.deathReason == "ACCIDENT" and terms.accidentalCovered ~= true then
            declineReason = "CAUSE_NOT_COVERED"
        elseif claim.deathReason == "HEALTH" and terms.healthCovered ~= true then
            declineReason = "BASIC_ACCIDENT_ONLY"
        elseif claim.deathReason ~= "ACCIDENT" and claim.deathReason ~= "HEALTH" then
            declineReason = "CAUSE_NOT_COVERED"
        elseif safeNumber(claim.incidentValue) <= 0 then
            declineReason = "NO_INSURABLE_VALUE"
        end
    end

    local factor = isVeterinary and (claim.indemnityFactor or terms.veterinaryIndemnity or 0) or (terms.indemnity or 0)
    local excess = isVeterinary and (claim.excess or terms.veterinaryExcess or 0) or (terms.excess or 0)
    local indemnity = math.max(0, safeNumber(claim.incidentValue) * math.max(0, safeNumber(factor)))
    local payout = math.max(0, math.floor(indemnity - math.max(0, safeNumber(excess)) + 0.5))
    if declineReason == nil and payout <= 0 then declineReason = "BELOW_EXCESS" end

    local reference = self:getClaimReference(claim)
    local decisionTitle = isVeterinary and "Veterinary Claim Decision" or "Livestock Claim Decision"
    local approvedTitle = isVeterinary and "Veterinary Claim Approved" or "Livestock Claim Approved"
    if declineReason ~= nil then
        claim.status = self.STATUS_DECLINED
        claim.outcomeReason = declineReason
        claim.approvedAmount = 0
        claim.approvedDay = currentDay
        self:notify(claim.farmId, decisionTitle, string.format(
            "%s has been declined. Reason: %s.", reference, self:getOutcomeText(declineReason)))
        return true, "declined"
    end

    claim.status = self.STATUS_APPROVED
    claim.approvedAmount = payout
    claim.approvedDay = currentDay
    claim.settlementDay = currentDay + self:getSettlementDelayDays()
    claim.outcomeReason = "COVERED"
    self:notify(claim.farmId, approvedTitle, string.format(
        "%s has been approved for %s after the policy excess of %s. Settlement is being arranged.",
        reference, formatMoney(payout), formatMoney(excess)))
    return true, "approved"
end

function RFF_InsuranceClaimService:getOutcomeText(reason)
    if reason == "NO_COVER" then return "the policy was not in force at the time of loss" end
    if reason == "OLD_AGE_EXCLUDED" then return "death from old age is excluded" end
    if reason == "BASIC_ACCIDENT_ONLY" then return "Basic livestock cover applies to accidental death only" end
    if reason == "VETERINARY_NOT_COVERED" then return "veterinary treatment expenses require Comprehensive cover" end
    if reason == "NO_TREATMENT_COST" then return "no eligible veterinary treatment cost could be established" end
    if reason == "CAUSE_NOT_COVERED" then return "the recorded cause is not covered" end
    if reason == "NO_INSURABLE_VALUE" then return "no insurable animal value could be established" end
    if reason == "BELOW_EXCESS" then return "the covered value does not exceed the policy excess" end
    if reason == "NO_VEHICLE_COVER" then return "no individual vehicle policy was in force at the time of the incident" end
    if reason == "ROAD_USE_EXCLUDED" then return "the incident occurred on a traffic route but the policy permits farmland-only use" end
    if reason == "USE_SCOPE_EXCLUDED" then return "the incident occurred outside the permitted farmland-only use" end
    if reason == "WEIGHT_LIMIT_EXCEEDED" then return "the recorded operating mass exceeded the policy's declared maximum" end
    if reason == "OWN_DAMAGE_NOT_COVERED" then return "Third Party cover does not insure damage to the policyholder's own vehicle" end
    if reason == "LEGAL_COVER_NOT_INCLUDED" then return "legal expenses were claimed but Legal Cover was not included" end
    if reason == "NO_ELIGIBLE_VEHICLE_LOSS" then return "none of the submitted vehicle-loss components fall within the selected cover" end
    if reason == "POLICYHOLDER_NO_RESPONSE" then return "the third-party claim was not answered after the final warning" end
    if reason == "ADS_OEM_REPAIR_REQUIRED" then return "ADS records show that the post-inspection repair did not use OEM parts" end
    if reason == "DRIVING_LICENCE_NOT_HELD" then return "the required driving-licence category was not held at the time of the road incident" end
    if reason == "ADR_NOT_HELD" then return "the required ADR endorsement was not held for the hazardous load at the time of the road incident" end
    if reason == "DRIVING_LICENCE_AND_ADR_NOT_HELD" then return "neither the required driving-licence category nor the ADR endorsement was held at the time of the road incident" end
    return tostring(reason or "claim terms not met")
end

function RFF_InsuranceClaimService:settleClaim(claim, forceNow)
    if claim == nil or claim.status ~= self.STATUS_APPROVED then return false, "status" end
    local currentDay = self:getCurrentDay()
    if forceNow ~= true and currentDay < (claim.settlementDay or currentDay) then return false, "not_due" end
    local amount = math.max(0, safeNumber(claim.approvedAmount))
    if amount <= 0 then return false, "amount" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end

    local isVeterinary = claim.claimType == "VETERINARY"
    local isVehicle = claim.claimType == "VEHICLE"
    if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(claim.farmId, isVehicle and "Vehicle insurance claim settlement" or (isVeterinary and "Veterinary insurance claim settlement" or "Livestock insurance claim settlement"))
    end
    g_currentMission:addMoney(amount, claim.farmId, otherMoneyType(), true, true)
    claim.status = self.STATUS_PAID
    claim.paidAmount = amount
    claim.paidDay = currentDay

    local reference = self:getClaimReference(claim)
    self:notify(claim.farmId, isVehicle and "Vehicle Claim Settled" or (isVeterinary and "Veterinary Claim Settled" or "Livestock Claim Settled"), string.format(
        "%s has been settled. %s has been credited to the farm account.", reference, formatMoney(amount)))
    return true, "paid"
end

-- Reviews use the original policy/licence snapshot and verified claim costs only.
-- Current policies, penalty points and unrelated workshop visits are not evidence.
function RFF_InsuranceClaimService:isDecisionFinal(claim)
    return claim ~= nil and claim.claimType == "VEHICLE"
        and (claim.status == self.STATUS_SETTLED or claim.status == self.STATUS_PAID
            or claim.status == self.STATUS_DECLINED or claim.status == self.STATUS_DEFAULTED)
end

function RFF_InsuranceClaimService:requestDecisionReview(farmId, claimId)
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "not_server" end
    local claim = self.repository:getInsuranceClaimById(farmId, claimId)
    if not self:isDecisionFinal(claim) then return false, "not_final" end
    if claim.reviewStatus ~= nil and claim.reviewStatus ~= "" then return false, "already_requested" end
    claim.reviewStatus = "PENDING"
    claim.reviewOriginalOwnPaid = safeNumber(claim.ownPaidAmount)
    claim.reviewOriginalFarmCharge = safeNumber(claim.liabilityFarmCharge)
    claim.reviewRequestedDay = self:getCurrentDay()
    claim.reviewDueDay = claim.reviewRequestedDay + 2
    claim.reviewResult = "Review requested. A written response will follow in two game days."
    self:notify(farmId, "Claim Review Requested", self:getClaimReference(claim) .. ": " .. claim.reviewResult)
    return true
end

function RFF_InsuranceClaimService:getDecisionText(claim)
    if not self:isDecisionFinal(claim) then return "The decision is not complete. No settlement estimate is available." end
    local lines = {self:getClaimReference(claim) .. " - CLAIM DECISION"}
    local traffic = self:isTrafficWorkflowClaim(claim)
    if traffic then
        table.insert(lines, "Third-party / legal demand: " .. formatMoney(safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts)))
        table.insert(lines, "Insurer paid to third party: " .. formatMoney(safeNumber(claim.liabilityInsurerPaid)))
        table.insert(lines, "Verified own repair / inspection: " .. (safeNumber(claim.adsInspectionLogId) > 0 and formatMoney(safeNumber(claim.actualOwnDamageCost)) or "No ADS evidence recorded"))
        table.insert(lines, "Own-damage credited to farm: " .. formatMoney(safeNumber(claim.ownPaidAmount)))
        if safeNumber(claim.adsInspectionLogId) > 0 then
            table.insert(lines, "Own costs retained by farm: " .. formatMoney(math.max(0, safeNumber(claim.actualOwnDamageCost) - safeNumber(claim.ownPaidAmount))))
        end
        table.insert(lines, "Farm shortfall / default: " .. formatMoney(safeNumber(claim.liabilityFarmCharge) - safeNumber(claim.liabilityInsurerRecovery)))
        table.insert(lines, "Insurer recovery from farm: " .. formatMoney(safeNumber(claim.liabilityInsurerRecovery)))
    else
        table.insert(lines, "Recorded claim value: " .. formatMoney(safeNumber(claim.incidentValue)))
        table.insert(lines, "Credited to farm: " .. formatMoney(safeNumber(claim.paidAmount)))
    end
    table.insert(lines, "Policy excess: " .. formatMoney(safeNumber(claim.excess)) .. " (included in deductions)")
    local cover = claim.policyCoverType or claim.policyTier
    if self:isPolicyInForce(claim.policyStatusAtIncident) and (cover == "COMPREHENSIVE" or cover == "THIRD_PARTY") then
        table.insert(lines, "Policy contribution: " .. tostring(cover == "COMPREHENSIVE" and 95 or 90) .. "% of eligible damage; legal cover separately.")
    else
        table.insert(lines, "No indemnity under the recorded policy at the incident.")
    end
    if claim.outcomeReason ~= nil and claim.outcomeReason ~= "COVERED" and claim.outcomeReason ~= "COVERED_WITH_EXCLUSIONS" then
        table.insert(lines, self:getOutcomeText(claim.outcomeReason))
    end
    if claim.coverageSummary ~= nil and claim.coverageSummary ~= "" then table.insert(lines, claim.coverageSummary) end
    if traffic and claim.ownDamageStatus == "DECLINED_NON_OEM" then table.insert(lines, "Own damage excluded: OEM repair evidence was not supplied.") end
    if self:hasLicenceClaimBreach(claim) then table.insert(lines, self:getLicenceDecisionSummary(claim)) end
    if claim.reviewStatus == "PENDING" then
        table.insert(lines, "Review pending: " .. tostring(math.max(0, safeNumber(claim.reviewDueDay) - self:getCurrentDay())) .. " game day(s) remaining.")
    else
        table.insert(lines, claim.reviewResult or "One review is available using the recorded accident and repair evidence.")
    end
    if claim.reviewStatus == "ADJUSTED" then
        table.insert(lines, "Before review - own credit: " .. formatMoney(safeNumber(claim.reviewOriginalOwnPaid))
            .. "; farm charge: " .. formatMoney(safeNumber(claim.reviewOriginalFarmCharge)))
    end
    return table.concat(lines, "\n")
end

function RFF_InsuranceClaimService:processDecisionReview(claim)
    if claim.reviewStatus ~= "PENDING" or self:getCurrentDay() < safeNumber(claim.reviewDueDay)
            or not self:isDecisionFinal(claim) then return false end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false end
    local credit, ownCorrection, liabilityRefund = 0, 0, 0
    local result = "Decision upheld. The recorded policy, loss and deductions support the settlement."
    if claim.status == self.STATUS_DEFAULTED then
        result = "Decision upheld. The third-party demand became payable after the response deadline and warning were missed. A review does not reopen that deadline."
    elseif self:isTrafficWorkflowClaim(claim) then
        -- Only completed, verified components can be recalculated. Estimates and
        -- abandoned/non-OEM work must never turn into a payment during review.
        local liability = {}
        for k, v in pairs(claim) do liability[k] = v end
        liability.vehicleDamageCost = 0
        local evaluation = self:evaluateVehicleClaim(liability, claim)
        local demand = safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts)
        local expectedInsurer = math.min(demand, math.max(0, evaluation.estimatedPayout))
        local expectedCharge = demand - expectedInsurer + (evaluation.insurerRecoveryApplies and expectedInsurer or 0)
        if claim.liabilityStatus == "SETTLED" then
            liabilityRefund = math.max(0, safeNumber(claim.liabilityFarmCharge) - expectedCharge)
        end
        local consumed = claim.liabilityStatus == "SETTLED" and math.min(safeNumber(claim.excess),
            evaluation.eligibleThirdPartyLiability * evaluation.indemnityFactor + evaluation.eligibleLegalCosts) or 0
        if claim.ownDamageStatus == "SETTLED" and safeNumber(claim.adsInspectionLogId) > 0
                and claim.adsNonOemRepair ~= true and safeNumber(claim.actualOwnDamageCost) == safeNumber(claim.vehicleDamageCost) then
            local own = {}
            for k, v in pairs(claim) do own[k] = v end
            own.thirdPartyLiability, own.legalCosts, own.policyLegalCover = 0, 0, false
            own.excess = math.max(0, safeNumber(claim.excess) - consumed)
            local ownEvaluation = self:evaluateVehicleClaim(own, claim)
            ownCorrection = math.max(0, math.min(safeNumber(claim.actualOwnDamageCost), ownEvaluation.estimatedPayout) - safeNumber(claim.ownPaidAmount))
        end
        credit = liabilityRefund + ownCorrection
        if credit > 0 then
            result = "Decision adjusted: recorded costs and deductions were reconciled. Additional own-damage reimbursement: " .. formatMoney(ownCorrection)
                .. "; refund of farm liability overcharge: " .. formatMoney(liabilityRefund) .. "."
        end
    else
        -- Legacy/manual cases lack the separated ADS evidence ledger: explain
        -- their decision without treating unverified estimates as new receipts.
        result = "Decision upheld on the recorded evidence. This legacy/manual case has no separated ADS evidence ledger; no additional repair reimbursement can be verified."
    end
    -- Commit the one-shot outcome before money callbacks can re-enter processing.
    claim.reviewStatus = credit > 0 and "ADJUSTED" or "UPHELD"
    claim.reviewCompletedDay = self:getCurrentDay()
    claim.reviewCredit = credit
    claim.reviewResult = result
    if credit > 0 then
        claim.ownPaidAmount = safeNumber(claim.ownPaidAmount) + ownCorrection
        claim.ownApprovedAmount = math.max(safeNumber(claim.ownApprovedAmount), claim.ownPaidAmount)
        claim.liabilityFarmCharge = safeNumber(claim.liabilityFarmCharge) - liabilityRefund
        claim.liabilityPolicyShortfall = math.max(0, safeNumber(claim.liabilityPolicyShortfall) - liabilityRefund)
        -- With no licence recovery, the insurer assumes the refunded portion
        -- of the demand. This is not an additional own-damage farm credit.
        if not self:hasLicenceClaimBreach(claim) then
            claim.liabilityInsurerPaid = math.min(safeNumber(claim.thirdPartyLiability) + safeNumber(claim.legalCosts),
                safeNumber(claim.liabilityInsurerPaid) + liabilityRefund)
        end
        self:updateTrafficClaimStatus(claim)
        self.repository:setNextTransactionDescription(claim.farmId, "Vehicle claim review adjustment")
        g_currentMission:addMoney(credit, claim.farmId, otherMoneyType(), true, true)
    end
    self:notify(claim.farmId, "Claim Review Complete", self:getClaimReference(claim) .. ": " .. result)
    return true
end

function RFF_InsuranceClaimService:processClaims(farmId, forceNow)
    if self.repository == nil then return 0 end
    local processed = 0
    for _, claim in ipairs(self.repository:getInsuranceClaimsByFarm(farmId) or {}) do
        if self:isTrafficWorkflowClaim(claim) then
            local changed = self:processTrafficWorkflowClaim(claim, self:getCurrentDay(), forceNow)
            if changed then processed = processed + 1 end
        elseif claim.status == self.STATUS_UNDER_REVIEW then
            local changed = self:assessClaim(claim, forceNow)
            if changed then processed = processed + 1 end
        end
        if not self:isTrafficWorkflowClaim(claim) and claim.status == self.STATUS_APPROVED then
            local changed = self:settleClaim(claim, forceNow)
            if changed then processed = processed + 1 end
        end
    end
        -- Review dates remain real game-day deadlines, even when ordinary claim
        -- settlement is advanced with the developer console.
    for _, claim in ipairs(self.repository:getInsuranceClaimsByFarm(farmId) or {}) do
        if self:processDecisionReview(claim) then processed = processed + 1 end
    end
    return processed
end

function RFF_InsuranceClaimService:onDayChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    self:installRLRMDeathHooks()
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if farmId ~= nil and farmId > 0 and farm ~= nil and farm.isSpectator ~= true then
            self:expireLosses(farmId)
            self:expireVeterinaryExpenses(farmId)
            self:expireTrafficCourtesyIncidents(farmId)
            self:processClaims(farmId, false)
        end
    end
end

function RFF_InsuranceClaimService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    self:installRLRMDeathHooks()
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if farmId ~= nil and farmId > 0 and farm ~= nil and farm.isSpectator ~= true then
            self:expireLosses(farmId)
            self:expireVeterinaryExpenses(farmId)
            self:expireTrafficCourtesyIncidents(farmId)
        end
    end
end

function RFF_InsuranceClaimService:update(dt)
    self._hookRetryMs = (self._hookRetryMs or 0) - (dt or 0)
    if self._hookRetryMs <= 0 then
        self._hookRetryMs = 3000
        self:installRLRMDeathHooks()
    end
    self._trafficCourtesyRetryMs = (self._trafficCourtesyRetryMs or 0) - (dt or 0)
    if self._trafficCourtesyRetryMs <= 0 then
        self._trafficCourtesyRetryMs = 3000
        self:installTrafficCourtesyHook()
    end
    self._technicalEvidenceRetryMs = (self._technicalEvidenceRetryMs or 0) - (dt or 0)
    if self._technicalEvidenceRetryMs <= 0 then
        self._technicalEvidenceRetryMs = 3000
        if g_currentMission ~= nil and g_currentMission:getIsServer() and self.repository ~= nil then
            for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
                if farmId ~= nil and farmId > 0 and farm ~= nil and farm.isSpectator ~= true then
                    for _, claim in ipairs(self.repository:getInsuranceClaimsByFarm(farmId) or {}) do
                        if self:isTrafficWorkflowClaim(claim)
                                and (claim.ownDamageStatus == "AWAITING_INSPECTION" or claim.ownDamageStatus == "AWAITING_OEM_REPAIR") then
                            self:processTrafficClaimTechnicalEvidence(claim, self:getCurrentDay())
                        end
                    end
                end
            end
        end
    end
end

function RFF_InsuranceClaimService:onLoaded()
    self:installRLRMDeathHooks()
    self:installTrafficCourtesyHook()
    self:onDayChanged()
end

function RFF_InsuranceClaimService:createTestVeterinaryExpense(farmId, value)
    local treatmentCost = math.max(1, safeNumber(value))
    if treatmentCost <= 1 then treatmentCost = 250 end
    return self:recordVeterinaryTreatmentExpense(farmId, {
        uniqueId = "TEST-VET-" .. tostring(self.repository ~= nil and self.repository.nextInsuranceVeterinaryExpenseId or 0),
        name = "Test livestock animal",
        breed = "Test",
        subType = "TEST_SHEEP",
        animalType = "SHEEP"
    }, treatmentCost, {"Test disease"}, "TEST")
end

function RFF_InsuranceClaimService:createTestLoss(farmId, reason, value)
    local reasonText = string.upper(tostring(reason or "ACCIDENT"))
    if reasonText == "AGE" or reasonText == "OLD" then reasonText = "OLD_AGE" end
    if reasonText ~= "ACCIDENT" and reasonText ~= "HEALTH" and reasonText ~= "OLD_AGE" then reasonText = "ACCIDENT" end
    local marketValue = math.max(1, safeNumber(value))
    if marketValue <= 1 then marketValue = 750 end
    return self:recordLivestockLoss(farmId, {
        uniqueId = "TEST-LOSS-" .. tostring(self.repository ~= nil and self.repository.nextInsuranceLossId or 0),
        name = "Test livestock animal",
        breed = "Test",
        subType = "TEST_SHEEP",
        animalType = "SHEEP",
        age = 24,
        health = 100,
        marketValue = marketValue
    }, reasonText, "TEST")
end

-- Backward compatible console helper name.
function RFF_InsuranceClaimService:createTestClaim(farmId, reason, value)
    return self:createTestLoss(farmId, reason, value)
end

function RFF_InsuranceClaimService:forceProcess(farmId, claimId)
    if self.repository == nil then return 0 end
    local processed = 0
    for _, claim in ipairs(self.repository:getInsuranceClaimsByFarm(farmId) or {}) do
        if claimId == nil or (claim.id or 0) == claimId then
            if self:isTrafficWorkflowClaim(claim) then
                local changed = self:processTrafficWorkflowClaim(claim, self:getCurrentDay(), true)
                if changed then processed = processed + 1 end
            elseif claim.status == self.STATUS_UNDER_REVIEW then
                local changed = self:assessClaim(claim, true)
                if changed then processed = processed + 1 end
            end
            if not self:isTrafficWorkflowClaim(claim) and claim.status == self.STATUS_APPROVED then
                local changed = self:settleClaim(claim, true)
                if changed then processed = processed + 1 end
            end
        end
    end
    return processed
end
