RFF_FarmlandMapExtension = {}
RFF_FarmlandMapExtension._installed = false
RFF_FarmlandMapExtension.selectedDownPaymentIndex = 4
RFF_FarmlandMapExtension.selectedMortgageTermIndex = 4
RFF_FarmlandMapExtension.selectedTenancyTermIndex = 2

local function manager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function formatMoney(v)
    return g_i18n:formatMoney(v or 0, 0, true, true)
end

local function hasActiveMission(farmland)
    return g_missionManager ~= nil and g_missionManager:getIsMissionRunningOnFarmland(farmland)
end

function RFF_FarmlandMapExtension.install()
    if RFF_FarmlandMapExtension._installed or InGameMenuMapFrame == nil then return end
    RFF_FarmlandMapExtension._installed = true

    InGameMenuMapFrame.onLoadMapFinished = Utils.overwrittenFunction(InGameMenuMapFrame.onLoadMapFinished, function(self, superFunc)
        if InGameMenuMapFrame.ACTIONS.RFF_MORTGAGE == nil then
            local maxId = 0
            for _, actionId in pairs(InGameMenuMapFrame.ACTIONS) do
                if type(actionId) == "number" then maxId = math.max(maxId, actionId) end
            end
            InGameMenuMapFrame.ACTIONS.RFF_MORTGAGE = maxId + 1
            InGameMenuMapFrame.ACTIONS.RFF_TENANCY = maxId + 2
            InGameMenuMapFrame.ACTIONS.RFF_END_TENANCY = maxId + 3
        end
        self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_MORTGAGE] = self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_MORTGAGE] or {title=g_i18n:getText("rff_map_mortgage"), callback=RFF_FarmlandMapExtension.startMortgage, isActive=false}
        self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_TENANCY] = self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_TENANCY] or {title=g_i18n:getText("rff_map_tenancy"), callback=RFF_FarmlandMapExtension.startTenancy, isActive=false}
        self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_END_TENANCY] = self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_END_TENANCY] or {title=g_i18n:getText("rff_map_end_tenancy"), callback=RFF_FarmlandMapExtension.endTenancy, isActive=false}
        superFunc(self)
    end)

    InGameMenuMapFrame.setMapInputContext = Utils.overwrittenFunction(InGameMenuMapFrame.setMapInputContext, function(self, superFunc, enterVehicleActive, resetVehicleActive, sellVehicleActive, visitPlaceActive, setMarkerActive, removeMarkerActive, buyFarmlandActive, sellFarmlandActive, manageActive)
        local m = manager()
        local acquisitionAvailable = true
        if self.selectedFarmland ~= nil and m ~= nil and m.propertyFinance ~= nil then
            acquisitionAvailable = m.propertyFinance:isFarmlandAvailableForAcquisition(self.selectedFarmland.id)
        end
        if self.contextActions ~= nil and InGameMenuMapFrame.ACTIONS.RFF_MORTGAGE ~= nil then
            self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_MORTGAGE].isActive = buyFarmlandActive == true and acquisitionAvailable
            self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_TENANCY].isActive = buyFarmlandActive == true and acquisitionAvailable
            self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_END_TENANCY].isActive = false
        end
        if self.selectedFarmland ~= nil and m ~= nil and m.repository ~= nil and m.propertyFinance ~= nil then
            local tenancy = m.repository:getTenancyByFarmland(self.selectedFarmland.id, true)
            local tenancyApplication = m.propertyFinance:getOpenTenancyApplicationForFarmland(self.selectedFarmland.id)
            local mortgage = m.propertyFinance:getMortgageByFarmland(self.selectedFarmland.id, true)
            if tenancy ~= nil then
                sellFarmlandActive = false
                buyFarmlandActive = false
                self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_MORTGAGE].isActive = false
                self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_TENANCY].isActive = false
                self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_END_TENANCY].isActive = tenancy.farmId == g_currentMission:getFarmId()
            elseif tenancyApplication ~= nil then
                self.contextActions[InGameMenuMapFrame.ACTIONS.RFF_TENANCY].isActive = false
            elseif mortgage ~= nil then
                sellFarmlandActive = false
            end
        end
        superFunc(self, enterVehicleActive, resetVehicleActive, sellVehicleActive, visitPlaceActive, setMarkerActive, removeMarkerActive, buyFarmlandActive, sellFarmlandActive, manageActive)
    end)
end

function RFF_FarmlandMapExtension.startMortgage(frame)
    local m = manager()
    local land = frame ~= nil and frame.selectedFarmland or nil
    if m == nil or m.propertyFinance == nil or land == nil then return true end
    if not m.propertyFinance:isFarmlandAvailableForAcquisition(land.id) then
        InfoDialog.show(g_i18n:getText("rff_farmland_not_for_sale"))
        return false
    end
    if hasActiveMission(land) then
        InfoDialog.show(g_i18n:getText(InGameMenuMapFrame.L10N_SYMBOL.DIALOG_BUY_FARMLAND_ACTIVE_MISSION))
        return false
    end
    if not RFF_LandFinanceDialog.showMortgage(frame, land.id) then
        InfoDialog.show(g_i18n:getText("rff_application_changed"))
        return false
    end
    return true
end

function RFF_FarmlandMapExtension.startTenancy(frame)
    local m = manager()
    local land = frame ~= nil and frame.selectedFarmland or nil
    if m == nil or m.propertyFinance == nil or land == nil then return true end
    if not m.propertyFinance:isFarmlandAvailableForAcquisition(land.id) then
        InfoDialog.show(g_i18n:getText("rff_farmland_not_for_sale"))
        return false
    end
    if m.propertyFinance:getOpenTenancyApplicationForFarmland(land.id) ~= nil then
        InfoDialog.show(g_i18n:getText("rff_tenancy_existing_enquiry"))
        return false
    end
    if hasActiveMission(land) then
        InfoDialog.show(g_i18n:getText(InGameMenuMapFrame.L10N_SYMBOL.DIALOG_BUY_FARMLAND_ACTIVE_MISSION))
        return false
    end
    if not RFF_LandFinanceDialog.showTenancy(frame, land.id) then
        InfoDialog.show(g_i18n:getText("rff_application_changed"))
        return false
    end
    return true
end

function RFF_FarmlandMapExtension.endTenancy(frame)
    local m=manager(); local land=frame ~= nil and frame.selectedFarmland or nil
    if m==nil or land==nil then return true end
    local tenancy=m.repository:getTenancyByFarmland(land.id, true)
    if tenancy==nil then return true end
    frame.rffPendingEndTenancy=tenancy
    local text=string.format("End tenancy #%d early?\n\nUp to %s is refundable after rent arrears and outstanding covenant-review costs. Physical repair or dilapidations deductions are not yet assessed.", tenancy.id or 0, formatMoney(tenancy.depositHeld or tenancy.securityDeposit))
    YesNoDialog.show(RFF_FarmlandMapExtension.onEndTenancyConfirmed, frame, text, g_i18n:getText("rff_map_end_tenancy"))
    return true
end

function RFF_FarmlandMapExtension.onEndTenancyConfirmed(frame, accepted)
    local tenancy=frame.rffPendingEndTenancy; frame.rffPendingEndTenancy=nil
    if accepted and tenancy~=nil then
        local m=manager(); if m~=nil and m.propertyFinance:terminateTenancy(tenancy) then InfoDialog.show(g_i18n:getText("rff_tenancy_ended")) end
    end
end
