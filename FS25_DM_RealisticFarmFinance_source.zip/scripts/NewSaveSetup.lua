-- Original RFF startup assistance. Uses the native calendar initialisation path;
-- does not reset fields, weather, season, or the elapsed-day counter.
RFF_NewSaveSetup={}
local S=RFF_NewSaveSetup
local function finite(v) return type(v)=="number" and v==v and math.abs(v)<math.huge end
local function server(m)
    return m and m:getIsServer() and not (m.missionDynamicInfo and m.missionDynamicInfo.isMultiplayer)
end
function S.period(repository)
    local p=repository and repository.startupPeriod
    if p==nil and g_currentMission then p=g_currentMission.rffNewSaveSetupPeriod end
    return finite(p) and p or nil
end
function S.isOpen(repository)
    return server(g_currentMission) and repository and repository.loaded==true
        and S.period(repository)~=nil and repository:getCurrentPeriodIndex()==S.period(repository)
end
function S.load(repository,xml)
    repository.startupPeriod=xml:getInt("realisticFarmFinance.startup#period")
end
function S.save(repository,xml)
    local p=S.period(repository)
    if p~=nil then xml:setInt("realisticFarmFinance.startup#period",p) end
end
function S.install()
    if S.installed or not Environment then return end
    S.installed=true
    Environment.load=Utils.overwrittenFunction(Environment.load,function(env,superFunc,...)
        local mission=env.mission;local info=mission and mission.missionInfo
        local fresh=server(mission) and info and info.isValid==false and info.environmentXMLLoad==nil
            and not mission.rffCalendarInitialized
        env.rffInitialisingCalendar=fresh==true
        local result=superFunc(env,...)
        env.rffInitialisingCalendar=nil
        if fresh and mission.rffCalendarInitialized then
            mission.rffNewSaveSetupPeriod=env.currentYear*12+env.currentPeriod
            print("[RFF] New save: five-day months from the start; optional instant land decisions during the opening month.")
        end
        return result
    end)
    Environment.setEnvironmentTime=Utils.overwrittenFunction(Environment.setEnvironmentTime,function(env,superFunc,monotonicDay,day,time,days,isDelta)
        if env.rffInitialisingCalendar and not isDelta then
            env.rffInitialisingCalendar=nil
            -- Rescale the calendar day only. Monotonic day measures actual elapsed play days.
            day=math.floor((day-1)/math.max(1,days)*5)+1
            days=5;env.timeAdjustment=1/5;env.plannedDaysPerPeriod=5
            env.mission.missionInfo.plannedDaysPerPeriod=5
            env.mission.rffCalendarInitialized=true
        end
        return superFunc(env,monotonicDay,day,time,days,isDelta)
    end)
end
S.install()
