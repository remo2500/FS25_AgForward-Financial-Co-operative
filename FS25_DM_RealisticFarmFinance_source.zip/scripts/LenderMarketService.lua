RFF_LenderMarketService = {}
RFF_LenderMarketService.__index = RFF_LenderMarketService

RFF_LenderMarketService.STATUS_OFFERED = "OFFERED"
RFF_LenderMarketService.STATUS_ACCEPTED = "ACCEPTED"
RFF_LenderMarketService.STATUS_DECLINED = "DECLINED"
RFF_LenderMarketService.STATUS_EXPIRED = "EXPIRED"

RFF_LenderMarketService.GLOBAL_COOLDOWN_PERIODS = 9
RFF_LenderMarketService.LENDER_COOLDOWN_PERIODS = 18
RFF_LenderMarketService.OFFER_VALID_PERIODS = 2

RFF_LenderMarketService.PROFILES = {
    PRIMARY_BANK = {
        id="PRIMARY_BANK", nameKey="rff_lender_primary_bank", styleKey="rff_lender_style_relationship_bank",
        specialismKey="rff_market_specialism_primary", baseRateAdjustment=0.00, feePercent=0.0000,
        amountFactor=0.90, maxAmount=350000, termMonths=60, minPoints=8, minSuccessfulPayments=6, proactive=true,
        appetiteWeights={OPEN=45, SELECTIVE=50, RESTRICTED=5},
        purposeFocus={GENERAL=1, WORKING_CAPITAL=2, MACHINERY=0, LAND_PROPERTY=1, REFINANCE=2, DEBT_CONSOLIDATION=1, RESCUE_FINANCE=0},
        productFocus={TERM=1, BULLET=0, REVOLVING=2, OVERDRAFT=2, MORTGAGE=1, HIRE_PURCHASE=0, BALLOON_FINANCE=0, OPERATING_LEASE=0}
    },
    RURAL_AGRI_BANK = {
        id="RURAL_AGRI_BANK", nameKey="rff_lender_rural_agri_bank", styleKey="rff_lender_style_conservative",
        specialismKey="rff_market_specialism_rural", baseRateAdjustment=-0.35, feePercent=0.0060,
        amountFactor=0.85, maxAmount=500000, termMonths=72, minPoints=8, minSuccessfulPayments=6, proactive=true,
        appetiteWeights={OPEN=35, SELECTIVE=50, RESTRICTED=15},
        purposeFocus={GENERAL=0, WORKING_CAPITAL=-1, MACHINERY=1, LAND_PROPERTY=2, REFINANCE=1, DEBT_CONSOLIDATION=0, RESCUE_FINANCE=-1},
        productFocus={TERM=0, BULLET=-1, REVOLVING=-1, OVERDRAFT=-1, MORTGAGE=2, HIRE_PURCHASE=2, BALLOON_FINANCE=1, OPERATING_LEASE=-1}
    },
    COUNTY_COMMERCIAL = {
        id="COUNTY_COMMERCIAL", nameKey="rff_lender_county_commercial", styleKey="rff_lender_style_mainstream",
        specialismKey="rff_market_specialism_county", baseRateAdjustment=0.05, feePercent=0.0080,
        amountFactor=1.00, maxAmount=450000, termMonths=60, minPoints=8, minSuccessfulPayments=5, proactive=true,
        appetiteWeights={OPEN=30, SELECTIVE=55, RESTRICTED=15},
        purposeFocus={GENERAL=1, WORKING_CAPITAL=2, MACHINERY=1, LAND_PROPERTY=0, REFINANCE=1, DEBT_CONSOLIDATION=1, RESCUE_FINANCE=0},
        productFocus={TERM=1, BULLET=1, REVOLVING=2, OVERDRAFT=1, MORTGAGE=0, HIRE_PURCHASE=1, BALLOON_FINANCE=1, OPERATING_LEASE=2}
    },
    AGRIGROWTH_FINANCE = {
        id="AGRIGROWTH_FINANCE", nameKey="rff_lender_agrigrowth", styleKey="rff_lender_style_specialist",
        specialismKey="rff_market_specialism_agrigrowth", baseRateAdjustment=0.65, feePercent=0.0110,
        amountFactor=1.15, maxAmount=650000, termMonths=84, minPoints=8, minSuccessfulPayments=5, proactive=true,
        appetiteWeights={OPEN=40, SELECTIVE=45, RESTRICTED=15},
        purposeFocus={GENERAL=1, WORKING_CAPITAL=0, MACHINERY=2, LAND_PROPERTY=1, REFINANCE=0, DEBT_CONSOLIDATION=-1, RESCUE_FINANCE=-1},
        productFocus={TERM=1, BULLET=1, REVOLVING=0, OVERDRAFT=-1, MORTGAGE=1, HIRE_PURCHASE=2, BALLOON_FINANCE=2, OPERATING_LEASE=2}
    },
    FRONTIER_CAPITAL = {
        id="FRONTIER_CAPITAL", nameKey="rff_lender_frontier_capital", styleKey="rff_lender_style_alternative",
        specialismKey="rff_market_specialism_frontier", baseRateAdjustment=1.75, feePercent=0.0175,
        amountFactor=0.75, maxAmount=300000, termMonths=48, minPoints=18, minSuccessfulPayments=10, proactive=true,
        appetiteWeights={OPEN=25, SELECTIVE=55, RESTRICTED=20},
        purposeFocus={GENERAL=0, WORKING_CAPITAL=1, MACHINERY=0, LAND_PROPERTY=-1, REFINANCE=1, DEBT_CONSOLIDATION=2, RESCUE_FINANCE=2},
        productFocus={TERM=0, BULLET=1, REVOLVING=1, OVERDRAFT=0, MORTGAGE=-1, HIRE_PURCHASE=0, BALLOON_FINANCE=1, OPERATING_LEASE=1}
    }
}

RFF_LenderMarketService.LENDER_ORDER = {
    "PRIMARY_BANK", "RURAL_AGRI_BANK", "COUNTY_COMMERCIAL", "AGRIGROWTH_FINANCE", "FRONTIER_CAPITAL"
}

RFF_LenderMarketService.APPETITE = {
    OPEN = {key="rff_market_appetite_open", rateAdjustment=-0.15, feeFactor=0.95, collateralFactor=1.02, incomeFactor=1.02, dscrFloorAdjustment=-0.03, ltvAdjustment=0.01},
    SELECTIVE = {key="rff_market_appetite_selective", rateAdjustment=0.10, feeFactor=1.00, collateralFactor=1.00, incomeFactor=1.00, dscrFloorAdjustment=0.00, ltvAdjustment=0.00},
    RESTRICTED = {key="rff_market_appetite_restricted", rateAdjustment=0.60, feeFactor=1.15, collateralFactor=0.96, incomeFactor=0.98, dscrFloorAdjustment=0.08, ltvAdjustment=-0.03}
}

RFF_LenderMarketService.DEAL_FIT = {
    CORE = {key="rff_market_fit_core", rateAdjustment=-0.35, feeFactor=0.85, collateralFactor=1.03, incomeFactor=1.03, dscrFloorAdjustment=-0.05, ltvAdjustment=0.02, amountFactor=1.00},
    PREFERRED = {key="rff_market_fit_preferred", rateAdjustment=-0.15, feeFactor=0.92, collateralFactor=1.02, incomeFactor=1.02, dscrFloorAdjustment=-0.03, ltvAdjustment=0.01, amountFactor=1.00},
    STANDARD = {key="rff_market_fit_standard", rateAdjustment=0.00, feeFactor=1.00, collateralFactor=1.00, incomeFactor=1.00, dscrFloorAdjustment=0.00, ltvAdjustment=0.00, amountFactor=1.00},
    CAUTIOUS = {key="rff_market_fit_cautious", rateAdjustment=0.35, feeFactor=1.10, collateralFactor=0.97, incomeFactor=0.97, dscrFloorAdjustment=0.05, ltvAdjustment=-0.02, amountFactor=0.85},
    LIMITED = {key="rff_market_fit_limited", rateAdjustment=0.75, feeFactor=1.20, collateralFactor=0.94, incomeFactor=0.94, dscrFloorAdjustment=0.10, ltvAdjustment=-0.04, amountFactor=0.70}
}

local function safeNumber(value)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then return value end
    return 0
end

local function roundDown(value, step)
    step = math.max(1, safeNumber(step))
    return math.floor(math.max(0, safeNumber(value)) / step) * step
end

local function feeMoneyType()
    if MoneyType ~= nil then return MoneyType.LOAN_INTEREST or MoneyType.OTHER end
    return nil
end

local function stableStringValue(value)
    local total = 0
    value = tostring(value or "")
    for i = 1, #value do total = total + string.byte(value, i) * i end
    return total
end

function RFF_LenderMarketService.new(repository, loanService, relationshipService)
    local self = setmetatable({}, RFF_LenderMarketService)
    self.repository = repository
    self.loanService = loanService
    self.relationshipService = relationshipService
    return self
end

function RFF_LenderMarketService:getProfile(lenderId)
    return self.PROFILES[lenderId] or self.PROFILES.PRIMARY_BANK
end

function RFF_LenderMarketService:getProfiles()
    local result = {}
    for _, lenderId in ipairs(self.LENDER_ORDER) do table.insert(result, self:getProfile(lenderId)) end
    return result
end

function RFF_LenderMarketService:getCurrentPeriod()
    return self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
end

function RFF_LenderMarketService:getAppetiteState(lenderId, periodIndex)
    local profile = self:getProfile(lenderId)
    local economy = self.repository ~= nil and self.repository.economyState or nil
    if economy ~= nil then
        local biases = {PRIMARY_BANK=0, RURAL_AGRI_BANK=.20, COUNTY_COMMERCIAL=.10, AGRIGROWTH_FINANCE=-.20, FRONTIER_CAPITAL=-.10}
        local pressure = economy.credit - .4 * economy.activity + (biases[lenderId] or 0)
        if pressure > .65 then return "RESTRICTED" end
        if pressure < -.15 then return "OPEN" end
        return "SELECTIVE"
    end
    periodIndex = periodIndex or self:getCurrentPeriod()
    local quarter = math.floor(safeNumber(periodIndex) / 3)
    local roll = (stableStringValue(lenderId) + quarter * 37 + 17) % 100
    local openWeight = safeNumber(profile.appetiteWeights ~= nil and profile.appetiteWeights.OPEN or 33)
    local selectiveWeight = safeNumber(profile.appetiteWeights ~= nil and profile.appetiteWeights.SELECTIVE or 50)
    if roll < openWeight then return "OPEN" end
    if roll < openWeight + selectiveWeight then return "SELECTIVE" end
    return "RESTRICTED"
end

function RFF_LenderMarketService:getMarketAdjustment(lenderId, periodIndex)
    local state = self:getAppetiteState(lenderId, periodIndex)
    local adjustment = self.APPETITE[state] or self.APPETITE.SELECTIVE
    return {
        state=state, key=adjustment.key,
        rateAdjustment=safeNumber(adjustment.rateAdjustment),
        feeFactor=safeNumber(adjustment.feeFactor),
        collateralFactor=safeNumber(adjustment.collateralFactor),
        incomeFactor=safeNumber(adjustment.incomeFactor),
        dscrFloorAdjustment=safeNumber(adjustment.dscrFloorAdjustment),
        ltvAdjustment=safeNumber(adjustment.ltvAdjustment)
    }
end

function RFF_LenderMarketService:getDealFitCode(score)
    score = safeNumber(score)
    if score >= 2 then return "CORE" end
    if score >= 1 then return "PREFERRED" end
    if score >= 0 then return "STANDARD" end
    if score >= -1 then return "CAUTIOUS" end
    return "LIMITED"
end

function RFF_LenderMarketService:getDealAdjustment(lenderId, product, purpose, amount, grade, periodIndex)
    local profile = self:getProfile(lenderId)
    local purposeScore = safeNumber(profile.purposeFocus ~= nil and profile.purposeFocus[purpose or "GENERAL"] or 0)
    local productScore = safeNumber(profile.productFocus ~= nil and profile.productFocus[product or RFF_LoanService.TYPE_TERM] or 0)
    local score = purposeScore + productScore

    amount = math.max(0, safeNumber(amount))
    if lenderId == "AGRIGROWTH_FINANCE" and amount >= 150000 then score = score + 1 end
    if lenderId == "PRIMARY_BANK" and amount > 300000 then score = score - 1 end
    if lenderId == "FRONTIER_CAPITAL" and grade ~= nil then
        if grade == "C" or grade == "D" then score = score + 1 else score = score - 1 end
    elseif lenderId == "RURAL_AGRI_BANK" and grade ~= nil and (grade == "C" or grade == "D") then
        score = score - 1
    end

    -- Purpose and product are deliberately allowed to reinforce one another, but cap the
    -- visible fit so a lender never becomes unrealistically dominant from a single table.
    score = math.max(-2, math.min(2, score))
    local code = self:getDealFitCode(score)
    local adjustment = self.DEAL_FIT[code] or self.DEAL_FIT.STANDARD
    local marketState = self:getAppetiteState(lenderId, periodIndex)
    local available = true
    if marketState == "RESTRICTED" and score < 0 then available = false end
    if score <= -2 and marketState ~= "OPEN" then available = false end

    return {
        code=code, key=adjustment.key, score=score, available=available,
        rateAdjustment=safeNumber(adjustment.rateAdjustment),
        feeFactor=safeNumber(adjustment.feeFactor),
        collateralFactor=safeNumber(adjustment.collateralFactor),
        incomeFactor=safeNumber(adjustment.incomeFactor),
        dscrFloorAdjustment=safeNumber(adjustment.dscrFloorAdjustment),
        ltvAdjustment=safeNumber(adjustment.ltvAdjustment),
        amountFactor=safeNumber(adjustment.amountFactor)
    }
end

function RFF_LenderMarketService:getFocusSummary(lenderId)
    local profile = self:getProfile(lenderId)
    local labels = {
        {purpose="WORKING_CAPITAL", key="rff_market_focus_working_capital"},
        {purpose="MACHINERY", key="rff_market_focus_machinery"},
        {purpose="LAND_PROPERTY", key="rff_market_focus_property"},
        {purpose="REFINANCE", key="rff_market_focus_refinance"}
    }
    local parts = {}
    for _, item in ipairs(labels) do
        local fit = self:getDealAdjustment(lenderId, RFF_LoanService.TYPE_TERM, item.purpose, 100000, nil)
        table.insert(parts, {purpose=item.purpose, key=item.key, fit=fit.code})
    end
    return parts
end

function RFF_LenderMarketService:getOffersByFarm(farmId)
    return self.repository ~= nil and self.repository:getPreApprovedOffersByFarm(farmId) or {}
end

function RFF_LenderMarketService:getOfferById(offerId)
    if self.repository == nil then return nil end
    for _, offer in ipairs(self.repository.preApprovedOffers or {}) do
        if safeNumber(offer.id) == safeNumber(offerId) then return offer end
    end
    return nil
end

function RFF_LenderMarketService:getActiveOffer(farmId)
    local current = self:getCurrentPeriod()
    local latest = nil
    for _, offer in ipairs(self:getOffersByFarm(farmId)) do
        if offer.status == self.STATUS_OFFERED and safeNumber(offer.expiryPeriod) > current then
            if latest == nil or safeNumber(offer.id) > safeNumber(latest.id) then latest = offer end
        end
    end
    return latest
end

function RFF_LenderMarketService:getLatestOffer(farmId)
    local latest = nil
    for _, offer in ipairs(self:getOffersByFarm(farmId)) do
        if latest == nil or safeNumber(offer.id) > safeNumber(latest.id) then latest = offer end
    end
    return latest
end

function RFF_LenderMarketService:getLastFarmOfferPeriod(farmId)
    local last = -100000
    for _, offer in ipairs(self:getOffersByFarm(farmId)) do last = math.max(last, safeNumber(offer.createdPeriod)) end
    return last
end

function RFF_LenderMarketService:getFarmIds()
    local ids = {}
    for farmId, _ in pairs(self.repository ~= nil and self.repository.farms or {}) do if safeNumber(farmId) > 0 then ids[farmId] = true end end
    for _, loan in ipairs(self.repository ~= nil and self.repository.loans or {}) do if safeNumber(loan.farmId) > 0 then ids[loan.farmId] = true end end
    for _, agreement in ipairs(self.repository ~= nil and self.repository.assetFinance or {}) do if safeNumber(agreement.farmId) > 0 then ids[agreement.farmId] = true end end
    local result = {}
    for farmId, _ in pairs(ids) do table.insert(result, farmId) end
    table.sort(result)
    return result
end

function RFF_LenderMarketService:isRelationshipEligible(farmId, lenderId)
    if self.relationshipService == nil then return false, nil, nil end
    local rel = self.relationshipService:getRelationship(farmId, lenderId, false)
    if rel == nil then return false, nil, nil end
    local profile = self:getProfile(lenderId)
    local code = self.relationshipService:getTier(rel.relationshipPoints or 0)
    local enoughHistory = safeNumber(rel.successfulPayments) >= safeNumber(profile.minSuccessfulPayments)
        or safeNumber(rel.completedAgreements) >= 1
    if safeNumber(rel.relationshipPoints) < safeNumber(profile.minPoints) or not enoughHistory then return false, rel, code end
    if safeNumber(rel.lastProactiveOfferPeriod) > 0 and self:getCurrentPeriod() - safeNumber(rel.lastProactiveOfferPeriod) < self.LENDER_COOLDOWN_PERIODS then
        return false, rel, code
    end
    return profile.proactive == true, rel, code
end

function RFF_LenderMarketService:isFarmEligible(farmId)
    if self:getActiveOffer(farmId) ~= nil then return false end
    if self:getCurrentPeriod() - self:getLastFarmOfferPeriod(farmId) < self.GLOBAL_COOLDOWN_PERIODS then return false end
    if self.loanService == nil then return false end
    local conduct = self.loanService:getPaymentConduct(farmId)
    if conduct ~= nil and conduct.declineNewCredit then return false end
    return true
end

function RFF_LenderMarketService:passesPeriodicGate(farmId, lenderId, relationshipCode)
    local current = self:getCurrentPeriod()
    local chance = relationshipCode == "TRUSTED" and 30 or 18
    local roll = (safeNumber(farmId) * 29 + current * 43 + stableStringValue(lenderId)) % 100
    return roll < chance
end

function RFF_LenderMarketService:buildCandidateAmounts(farmId, profile, valuation, credit)
    local monthlyIncome = math.max(0, safeNumber(credit ~= nil and credit.monthlyIncome))
    local netWorth = math.max(0, safeNumber(valuation ~= nil and valuation.netWorth))
    local incomeBasis = monthlyIncome * 6
    local equityBasis = netWorth * 0.035
    local raw = math.max(5000, incomeBasis, equityBasis)
    raw = math.min(raw * safeNumber(profile.amountFactor), safeNumber(profile.maxAmount))
    raw = roundDown(raw, 2500)
    if raw < 5000 then return {} end
    local result, used = {}, {}
    -- A proactive offer should find the amount the lender is actually comfortable
    -- pre-approving, rather than failing simply because the first relationship-based
    -- target is too ambitious. Keep stepping down to a still-meaningful facility.
    for _, factor in ipairs({1.00, 0.80, 0.60, 0.45, 0.30, 0.20}) do
        local amount = math.max(5000, roundDown(raw * factor, 2500))
        if not used[amount] then table.insert(result, amount); used[amount] = true end
    end
    return result
end

function RFF_LenderMarketService:buildOffer(farmId, lenderId)
    if self.repository == nil or self.loanService == nil then return nil, "service_unavailable" end
    local profile = self:getProfile(lenderId)
    local rel = self.relationshipService ~= nil and self.relationshipService:getRelationship(farmId, lenderId, false) or nil
    local relationshipBenefits = self.relationshipService ~= nil and self.relationshipService:getBenefits(farmId, lenderId) or {code="NEW", rateAdjustment=0, arrangementFeeFactor=1}
    local appetite = self:getMarketAdjustment(lenderId)
    if appetite.state == "RESTRICTED" then return nil, "restricted_market" end
    local fit = self:getDealAdjustment(lenderId, RFF_LoanService.TYPE_TERM, "GENERAL", 100000, nil)
    if fit.available ~= true then return nil, "specialism_out_of_appetite" end

    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    local relationshipCode = relationshipBenefits.code or "NEW"

    -- Reuse the existing relationship-underwriting benefits rather than creating a
    -- separate proactive-loan scoring system. Appetite then sits on top of the same
    -- LTV/DSCR tolerance already used elsewhere in RFF.
    local relationshipCollateralFactor = math.max(0.75, 1.00 + safeNumber(relationshipBenefits.ltvBonus))
    local relationshipIncomeFactor = math.max(0.75, 1.00 + safeNumber(relationshipBenefits.dscrTolerance))
    local effectiveCredit = {}
    for key, value in pairs(credit or {}) do effectiveCredit[key] = value end
    effectiveCredit.monthlyIncome = math.max(0, safeNumber(credit ~= nil and credit.monthlyIncome))
        * math.max(0.75, safeNumber(appetite.incomeFactor)) * math.max(0.75, safeNumber(fit.incomeFactor)) * relationshipIncomeFactor
    effectiveCredit.collateral = math.max(0, safeNumber(credit ~= nil and credit.collateral))
        * math.max(0.75, safeNumber(appetite.collateralFactor)) * math.max(0.75, safeNumber(fit.collateralFactor)) * relationshipCollateralFactor

    local months = safeNumber(profile.termMonths)
    local best = nil
    local lastEvaluation = nil
    local candidateProfile = {amountFactor=safeNumber(profile.amountFactor) * math.max(0.50, safeNumber(fit.amountFactor)), maxAmount=profile.maxAmount}
    local triedAmounts = self:buildCandidateAmounts(farmId, candidateProfile, valuation, effectiveCredit)
    for _, amount in ipairs(triedAmounts) do
        local evaluation = self.loanService:evaluateApplication(farmId, amount, months, RFF_LoanService.TYPE_TERM, valuation, effectiveCredit)
        lastEvaluation = evaluation
        if evaluation ~= nil and evaluation.approved == true then
            best = {amount=amount, evaluation=evaluation}
            break
        end
    end
    if best == nil then
        local reason = lastEvaluation ~= nil and lastEvaluation.reason or (#triedAmounts == 0 and "no_candidate_amount" or "underwriting")
        return nil, reason, {valuation=valuation, credit=credit, effectiveCredit=effectiveCredit, evaluation=lastEvaluation, triedAmounts=triedAmounts}
    end

    fit = self:getDealAdjustment(lenderId, RFF_LoanService.TYPE_TERM, "GENERAL", best.amount, best.evaluation.grade)
    if fit.available ~= true then return nil, "specialism_out_of_appetite", {valuation=valuation, credit=credit, effectiveCredit=effectiveCredit, evaluation=best.evaluation, triedAmounts=triedAmounts, fit=fit} end
    local loyaltyDiscount = relationshipCode == "TRUSTED" and -0.45 or -0.25
    local finalRate = math.max(2.50, safeNumber(best.evaluation.interestRate)
        + safeNumber(profile.baseRateAdjustment)
        + safeNumber(relationshipBenefits.rateAdjustment)
        + safeNumber(appetite.rateAdjustment)
        + safeNumber(fit.rateAdjustment)
        + loyaltyDiscount)
    local monthlyPayment = self.loanService:calculateMonthlyPayment(best.amount, finalRate, months, RFF_LoanService.TYPE_TERM)
    local fee = best.amount * safeNumber(profile.feePercent) * math.max(0.5, safeNumber(relationshipBenefits.arrangementFeeFactor))
        * safeNumber(appetite.feeFactor) * math.max(0.5, safeNumber(fit.feeFactor)) * 0.75
    fee = roundDown(fee + 5, 10)

    local current = self:getCurrentPeriod()
    local offer = {
        id=self.repository:getNextPreApprovedOfferId(), farmId=farmId,
        lenderId=lenderId, lenderNameKey=profile.nameKey,
        product=RFF_LoanService.TYPE_TERM, purpose="GENERAL",
        amount=best.amount, months=months, interestRate=finalRate, monthlyPayment=monthlyPayment,
        grade=best.evaluation.grade or "C", arrangementFee=fee,
        relationshipTier=relationshipCode, relationshipPoints=safeNumber(rel ~= nil and rel.relationshipPoints),
        marketState=appetite.state, dealFit=fit.code, status=self.STATUS_OFFERED,
        createdPeriod=current, expiryPeriod=current + self.OFFER_VALID_PERIODS,
        acceptedPeriod=0, declinedPeriod=0, linkedLoanId=0
    }
    return offer
end

function RFF_LenderMarketService:notifyOffer(offer)
    if offer == nil or RFF_NotificationService == nil then return end
    local sender = RFF_NotificationService:getSender(offer.lenderNameKey, "Lender")
    local title = RFF_NotificationService:getText("rff_phone_title_preapproved", "Pre-approved Finance")
    local message = RFF_NotificationService:formatText("rff_phone_preapproved_offer",
        "We can offer you pre-approved finance of %s over %d months at %.2f%%. Open Finance > Lender Market to accept or decline.",
        g_i18n ~= nil and g_i18n:formatMoney(offer.amount or 0, 0, true, true) or tostring(offer.amount or 0), offer.months or 0, offer.interestRate or 0)
    local fallback = RFF_NotificationService:formatText("rff_preapproved_fallback",
        "%s has offered pre-approved finance. Open Finance > Lender Market to respond.", sender)
    if RFF_NotificationService.pushPhoneActionable ~= nil then
        if RFF_NotificationService:pushPhoneActionable(offer.farmId, sender, title, message, "lenderOffer",
            "preapproved:" .. tostring(offer.id), self, "rff_phone_accept", "rff_phone_decline") then return end
    end
    RFF_NotificationService:send(offer.farmId, sender, title, message, "lenderOffer", fallback, false)
end

function RFF_LenderMarketService:createProactiveOffer(farmId, lenderId, bypassGate)
    if g_currentMission == nil or not g_currentMission:getIsServer() or not self:isFarmEligible(farmId) then return nil, "ineligible_farm" end
    local eligible, rel, relationshipCode = self:isRelationshipEligible(farmId, lenderId)
    if not eligible then return nil, "ineligible_relationship" end
    if not bypassGate and not self:passesPeriodicGate(farmId, lenderId, relationshipCode) then return nil, "periodic_gate" end

    local offer, underwritingReason, underwritingData = self:buildOffer(farmId, lenderId)
    if offer == nil then
        return nil, "underwriting:" .. tostring(underwritingReason or "declined"), underwritingData
    end
    self.repository:addPreApprovedOffer(offer)
    rel.lastProactiveOfferPeriod = self:getCurrentPeriod()
    rel.proactiveOffersMade = safeNumber(rel.proactiveOffersMade) + 1
    if self.relationshipService ~= nil then self.relationshipService:recordOffer(farmId, lenderId) end
    self:notifyOffer(offer)
    print(string.format("[RealisticFarmFinance] Proactive lender offer #%d farm=%d lender=%s amount=%.2f rate=%.2f term=%d tier=%s market=%s fit=%s",
        offer.id or 0, farmId, tostring(lenderId), offer.amount or 0, offer.interestRate or 0, offer.months or 0, tostring(offer.relationshipTier), tostring(offer.marketState), tostring(offer.dealFit or "STANDARD")))
    return offer, nil
end

function RFF_LenderMarketService:chooseEligibleLender(farmId, bypassGate)
    local candidates = {}
    for _, lenderId in ipairs(self.LENDER_ORDER) do
        local eligible, rel, code = self:isRelationshipEligible(farmId, lenderId)
        if eligible and self:getAppetiteState(lenderId) ~= "RESTRICTED" and (bypassGate or self:passesPeriodicGate(farmId, lenderId, code)) then
            local score = safeNumber(rel.relationshipPoints)
            if code == "TRUSTED" then score = score + 4 end
            local profile = self:getProfile(lenderId)
            score = score - math.max(0, safeNumber(profile.baseRateAdjustment)) * 0.5
            table.insert(candidates, {id=lenderId, score=score})
        end
    end
    table.sort(candidates, function(a, b)
        if a.score == b.score then return tostring(a.id) < tostring(b.id) end
        return a.score > b.score
    end)
    return candidates[1] ~= nil and candidates[1].id or nil
end

function RFF_LenderMarketService:evaluateFarm(farmId, bypassGate)
    if not self:isFarmEligible(farmId) then return nil, "ineligible_farm" end
    local lenderId = self:chooseEligibleLender(farmId, bypassGate == true)
    if lenderId == nil then return nil, "no_lender" end
    return self:createProactiveOffer(farmId, lenderId, bypassGate == true)
end

function RFF_LenderMarketService:expireOffers()
    local current = self:getCurrentPeriod()
    for _, offer in ipairs(self.repository ~= nil and self.repository.preApprovedOffers or {}) do
        if offer.status == self.STATUS_OFFERED and current >= safeNumber(offer.expiryPeriod) then
            offer.status = self.STATUS_EXPIRED
        end
    end
end

function RFF_LenderMarketService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() then return end
    self:expireOffers()
    for _, farmId in ipairs(self:getFarmIds()) do self:evaluateFarm(farmId, false) end
end

function RFF_LenderMarketService:onLoaded()
    self:expireOffers()
end

function RFF_LenderMarketService:acceptOffer(offer)
    if g_currentMission == nil or not g_currentMission:getIsServer() or offer == nil then return nil, "server_only" end
    if offer.status ~= self.STATUS_OFFERED then return nil, "not_open" end
    if self:getCurrentPeriod() >= safeNumber(offer.expiryPeriod) then offer.status = self.STATUS_EXPIRED; return nil, "expired" end

    local formal = {
        approved=true, interestRate=offer.interestRate, monthlyPayment=offer.monthlyPayment, grade=offer.grade,
        lenderId=offer.lenderId, lenderNameKey=offer.lenderNameKey, arrangementFee=offer.arrangementFee,
        brokerFee=0, brokered=false, brokerCaseId=0
    }
    local loan, reason = self.loanService:createLoanFromOffer(offer.farmId, offer.amount, offer.months, offer.product, offer.purpose, formal)
    if loan == nil then return nil, reason or "loan_create_failed" end

    if safeNumber(offer.arrangementFee) > 0 then
        if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(offer.farmId, "Pre-approved finance arrangement fee") end
        g_currentMission:addMoney(-safeNumber(offer.arrangementFee), offer.farmId, feeMoneyType(), true, true)
    end
    offer.status = self.STATUS_ACCEPTED
    offer.acceptedPeriod = self:getCurrentPeriod()
    offer.linkedLoanId = loan.id or 0
    local rel = self.relationshipService ~= nil and self.relationshipService:getRelationship(offer.farmId, offer.lenderId, true) or nil
    if rel ~= nil then rel.proactiveOffersAccepted = safeNumber(rel.proactiveOffersAccepted) + 1 end
    if self.relationshipService ~= nil then self.relationshipService:recordAcceptedDeal(offer.farmId, offer.lenderId, offer.amount, false) end

    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(offer.lenderNameKey, "Lender")
        RFF_NotificationService:send(offer.farmId, sender,
            RFF_NotificationService:getText("rff_phone_title_completed", "Finance Completed"),
            RFF_NotificationService:formatText("rff_phone_preapproved_accepted", "Your pre-approved facility of %s is now active.", g_i18n ~= nil and g_i18n:formatMoney(offer.amount or 0, 0, true, true) or tostring(offer.amount or 0)),
            "lenderOffer", nil, false)
    end
    return loan, nil
end

function RFF_LenderMarketService:declineOffer(offer)
    if g_currentMission == nil or not g_currentMission:getIsServer() or offer == nil then return false, "server_only" end
    if offer.status ~= self.STATUS_OFFERED then return false, "not_open" end
    offer.status = self.STATUS_DECLINED
    offer.declinedPeriod = self:getCurrentPeriod()
    local rel = self.relationshipService ~= nil and self.relationshipService:getRelationship(offer.farmId, offer.lenderId, true) or nil
    if rel ~= nil then rel.proactiveOffersDeclined = safeNumber(rel.proactiveOffersDeclined) + 1 end
    return true, nil
end

local function phoneDecisionFailureText(reason)
    reason = tostring(reason or "")
    if reason == "expired" then return "Offer has expired" end
    if reason == "not_open" then return "Offer no longer available" end
    if reason == "unknown_offer" or reason == "invalid_token" then return "Offer no longer available" end
    if reason == "wrong_farm" then return "Offer is not available to this farm" end
    if reason == "server_only" then return "Decision could not be processed" end
    if reason == "insufficient_funds" then return "Unable to complete this offer" end
    if reason == "loan_create_failed" then return "Unable to activate this offer" end
    if reason ~= "" then return "Unable to process offer: " .. reason end
    return "Unable to process this offer"
end

function RFF_LenderMarketService:getOfferFromPhoneContext(context)
    if type(context) ~= "table" then return nil, "invalid_token" end
    local offerId = tonumber(string.match(tostring(context.token or ""), "^preapproved:(%d+)$"))
    if offerId == nil then return nil, "invalid_token" end
    local offer = self:getOfferById(offerId)
    if offer == nil then return nil, "unknown_offer" end
    local contextFarmId = tonumber(context.farmId)
    if contextFarmId == nil or contextFarmId ~= tonumber(offer.farmId) then return nil, "wrong_farm" end
    if offer.status ~= self.STATUS_OFFERED then return nil, "not_open" end
    if self:getCurrentPeriod() >= safeNumber(offer.expiryPeriod) then
        offer.status = self.STATUS_EXPIRED
        return nil, "expired"
    end
    return offer, nil
end

function RFF_LenderMarketService:handlePhoneDecision(context, response)
    if g_currentMission == nil or not g_currentMission:getIsServer() then
        return false, phoneDecisionFailureText("server_only")
    end

    local offer, reason = self:getOfferFromPhoneContext(context)
    if offer == nil then return false, phoneDecisionFailureText(reason) end

    response = string.lower(tostring(response or ""))
    if response == "accept" or response == "yes" then
        local loan, acceptReason = self:acceptOffer(offer)
        if loan ~= nil then
            print(string.format("[RealisticFarmFinance] Mobile Phone accepted proactive offer #%d farm=%d lender=%s", offer.id or 0, offer.farmId or 0, tostring(offer.lenderId)))
            return true, "ACCEPTED"
        end
        return false, phoneDecisionFailureText(acceptReason)
    elseif response == "decline" or response == "no" then
        local ok, declineReason = self:declineOffer(offer)
        if ok then
            print(string.format("[RealisticFarmFinance] Mobile Phone declined proactive offer #%d farm=%d lender=%s", offer.id or 0, offer.farmId or 0, tostring(offer.lenderId)))
            return true, "DECLINED"
        end
        return false, phoneDecisionFailureText(declineReason)
    end
    return false, "Unknown response"
end
