RFF_ApplicationService = {}
RFF_ApplicationService.__index = RFF_ApplicationService

RFF_ApplicationService.STATUS_SUBMITTED = "SUBMITTED"
RFF_ApplicationService.STATUS_INITIAL_REVIEW = "INITIAL_REVIEW"
RFF_ApplicationService.STATUS_VALUATION_INSTRUCTED = "VALUATION_INSTRUCTED"
RFF_ApplicationService.STATUS_VALUATION_RETURNED = "VALUATION_RETURNED"
RFF_ApplicationService.STATUS_UNDERWRITING = "UNDERWRITING"
RFF_ApplicationService.STATUS_FINAL_REVIEW = "FINAL_REVIEW"
RFF_ApplicationService.STATUS_OFFERED = "OFFERED"
RFF_ApplicationService.STATUS_DECLINED = "DECLINED"
RFF_ApplicationService.STATUS_ACCEPTED = "ACCEPTED"
RFF_ApplicationService.STATUS_WITHDRAWN = "WITHDRAWN"
RFF_ApplicationService.STATUS_EXPIRED = "EXPIRED"

RFF_ApplicationService.ROUTE_AUTOMATED = "AUTOMATED"
RFF_ApplicationService.ROUTE_STANDARD = "STANDARD"
RFF_ApplicationService.ROUTE_REFERRED = "REFERRED"

local function safeNumber(value)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then
        return value
    end
    return 0
end

local function roundDown(value, step)
    step = math.max(1, safeNumber(step))
    return math.floor(math.max(0, safeNumber(value)) / step) * step
end

local function roundNearest(value)
    return math.floor(safeNumber(value) + 0.5)
end

function RFF_ApplicationService.new(repository, loanService)
    local self = setmetatable({}, RFF_ApplicationService)
    self.repository = repository
    self.loanService = loanService
    self.propertyFinance = nil
    self.relationshipService = nil
    self.marketService = nil
    return self
end

function RFF_ApplicationService:setPropertyFinanceService(propertyFinance)
    self.propertyFinance = propertyFinance
end

function RFF_ApplicationService:setRelationshipService(service)
    self.relationshipService = service
end

function RFF_ApplicationService:setMarketService(service)
    self.marketService = service
end

function RFF_ApplicationService:getPrimaryMarketTerms(product, purpose, amount, grade)
    local market = self.marketService ~= nil and self.marketService:getMarketAdjustment("PRIMARY_BANK")
        or {state="SELECTIVE", rateAdjustment=0, collateralFactor=1, incomeFactor=1, dscrFloorAdjustment=0, ltvAdjustment=0}
    local fit = self.marketService ~= nil and self.marketService:getDealAdjustment("PRIMARY_BANK", product, purpose or "GENERAL", amount, grade)
        or {code="STANDARD", key="rff_market_fit_standard", available=true, rateAdjustment=0, collateralFactor=1, incomeFactor=1, dscrFloorAdjustment=0, ltvAdjustment=0}
    return market, fit
end

function RFF_ApplicationService:buildPrimaryMarketCredit(product, purpose, amount, credit)
    local market, fit = self:getPrimaryMarketTerms(product, purpose, amount, nil)
    if fit.available ~= true then return nil, market, fit end
    local effective = {}
    for key, value in pairs(credit or {}) do effective[key] = value end
    effective.monthlyIncome = math.max(0, safeNumber(credit ~= nil and credit.monthlyIncome))
        * math.max(0.75, safeNumber(market.incomeFactor)) * math.max(0.75, safeNumber(fit.incomeFactor))
    effective.collateral = math.max(0, safeNumber(credit ~= nil and credit.collateral))
        * math.max(0.75, safeNumber(market.collateralFactor)) * math.max(0.75, safeNumber(fit.collateralFactor))
    return effective, market, fit
end

function RFF_ApplicationService:getCurrentDay()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return env ~= nil and safeNumber(env.currentMonotonicDay) or 0
end

function RFF_ApplicationService:getCurrentHourOfDay()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return env ~= nil and math.max(0, math.min(23, math.floor(safeNumber(env.currentHour)))) or 0
end

function RFF_ApplicationService:getCurrentHourStamp()
    return math.floor(self:getCurrentDay()) * 24 + self:getCurrentHourOfDay()
end

function RFF_ApplicationService:getDaysPerPeriod()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return math.max(1, math.floor(safeNumber(env ~= nil and env.daysPerPeriod or 1)))
end

function RFF_ApplicationService:getPeriodHours()
    return self:getDaysPerPeriod() * 24
end

function RFF_ApplicationService:isRecommendedPacing()
    return self:getDaysPerPeriod() >= 3
end

function RFF_ApplicationService:isPending(application)
    if application == nil then return false end
    return application.status == self.STATUS_SUBMITTED
        or application.status == self.STATUS_INITIAL_REVIEW
        or application.status == self.STATUS_VALUATION_INSTRUCTED
        or application.status == self.STATUS_VALUATION_RETURNED
        or application.status == self.STATUS_UNDERWRITING
        or application.status == self.STATUS_FINAL_REVIEW
end

function RFF_ApplicationService:isOfferOpen(application)
    return application ~= nil and application.status == self.STATUS_OFFERED
end

function RFF_ApplicationService:getRouteLabelKey(route)
    if route == self.ROUTE_AUTOMATED then return "rff_route_automated" end
    if route == self.ROUTE_REFERRED then return "rff_route_referred" end
    return "rff_route_standard"
end

function RFF_ApplicationService:getStatusLabelKey(status, application)
    local isMortgage = application ~= nil and application.product == RFF_LoanService.TYPE_MORTGAGE
    if isMortgage then
        if status == self.STATUS_SUBMITTED then return "rff_mortgage_status_submitted" end
        if status == self.STATUS_INITIAL_REVIEW then return "rff_mortgage_status_initial_review" end
        if status == self.STATUS_VALUATION_INSTRUCTED then return "rff_mortgage_status_valuation_instructed" end
        if status == self.STATUS_VALUATION_RETURNED then return "rff_mortgage_status_valuation_returned" end
        if status == self.STATUS_UNDERWRITING then return "rff_mortgage_status_underwriting" end
        if status == self.STATUS_FINAL_REVIEW then return "rff_mortgage_status_final_review" end
    end
    if status == self.STATUS_SUBMITTED then return "rff_app_status_submitted" end
    if status == self.STATUS_INITIAL_REVIEW then return "rff_app_status_initial_review" end
    if status == self.STATUS_VALUATION_INSTRUCTED then return "rff_app_status_valuation_instructed" end
    if status == self.STATUS_VALUATION_RETURNED then return "rff_app_status_valuation_returned" end
    if status == self.STATUS_UNDERWRITING then return "rff_app_status_underwriting" end
    if status == self.STATUS_FINAL_REVIEW then return "rff_app_status_final_review" end
    if status == self.STATUS_OFFERED then return "rff_app_status_offered" end
    if status == self.STATUS_DECLINED then return "rff_app_status_declined" end
    if status == self.STATUS_ACCEPTED then return "rff_app_status_accepted" end
    if status == self.STATUS_WITHDRAWN then return "rff_app_status_withdrawn" end
    if status == self.STATUS_EXPIRED then return "rff_app_status_expired" end
    return "rff_app_status_unknown"
end

-- Underwriting time is expressed as a proportion of one in-game month/period rather than
-- fixed game days. This keeps 3-5 day months deliberate without allowing a routine credit
-- decision to consume several whole months on shorter calendar settings.
function RFF_ApplicationService:estimateRoute(amount, loanType, valuation, credit, evaluation, farmId)
    local assets = math.max(1, safeNumber(valuation ~= nil and valuation.totalAssets or 0))
    local ratio = safeNumber(amount) / assets
    local tracked = safeNumber(credit ~= nil and credit.trackedPeriods or 0)
    local periodHours = self:getPeriodHours()

    local route = self.ROUTE_STANDARD
    local minShare, maxShare = 0.16, 0.30

    if safeNumber(amount) <= 50000 and ratio <= 0.10 and evaluation ~= nil and evaluation.approved then
        route = self.ROUTE_AUTOMATED
        minShare, maxShare = 0.06, 0.14
    elseif loanType == RFF_LoanService.TYPE_MORTGAGE then
        route = self.ROUTE_REFERRED
        minShare, maxShare = 0.50, 0.82
    elseif safeNumber(amount) > 250000 or ratio > 0.25 then
        route = self.ROUTE_REFERRED
        minShare, maxShare = 0.32, 0.55
    end

    if evaluation ~= nil and not evaluation.approved and route == self.ROUTE_AUTOMATED then
        route = self.ROUTE_STANDARD
        minShare, maxShare = 0.16, 0.30
    end

    if self.relationshipService ~= nil and safeNumber(farmId) > 0 and loanType ~= RFF_LoanService.TYPE_MORTGAGE and evaluation ~= nil and evaluation.approved then
        local benefits = self.relationshipService:getBenefits(farmId, "PRIMARY_BANK")
        if benefits.code == "TRUSTED" and safeNumber(amount) <= 150000 and ratio <= 0.20 then
            route = self.ROUTE_AUTOMATED
            minShare, maxShare = 0.04, 0.10
        elseif benefits.code == "PROVEN" and safeNumber(amount) <= 100000 and ratio <= 0.15 then
            route = self.ROUTE_AUTOMATED
            minShare, maxShare = 0.05, 0.12
        end
    end

    local minHours = math.max(4, roundNearest(periodHours * minShare))
    local maxHours = math.max(minHours, roundNearest(periodHours * maxShare))

    -- A lender has less evidence for a genuinely new/unseasoned farm, so initial review
    -- takes a little longer. This is deliberately modest and still scales with the calendar.
    if tracked < 3 then
        local historyAllowance = math.max(2, roundNearest(periodHours * 0.05))
        minHours = minHours + historyAllowance
        maxHours = maxHours + historyAllowance
    end

    if self.relationshipService ~= nil and safeNumber(farmId) > 0 then
        local benefits = self.relationshipService:getBenefits(farmId, "PRIMARY_BANK")
        local factor = math.max(0.75, math.min(1.20, safeNumber(benefits.timingFactor)))
        minHours = math.max(4, roundNearest(minHours * factor))
        maxHours = math.max(minHours, roundNearest(maxHours * factor))
    end

    return route, minHours, maxHours
end

function RFF_ApplicationService:chooseDecisionDelay(applicationId, minHours, maxHours)
    minHours = math.max(4, math.floor(safeNumber(minHours)))
    maxHours = math.max(minHours, math.floor(safeNumber(maxHours)))
    local span = maxHours - minHours + 1
    return minHours + ((math.max(1, math.floor(safeNumber(applicationId))) - 1) % span)
end

function RFF_ApplicationService:buildStageSchedule(submittedHour, decisionDelayHours)
    local delay = math.max(4, math.floor(safeNumber(decisionDelayHours)))
    local initialOffset = math.max(1, math.floor(delay * 0.18))
    local underwritingOffset = math.max(initialOffset + 1, math.floor(delay * 0.45))
    local finalOffset = math.max(underwritingOffset + 1, math.floor(delay * 0.78))

    if finalOffset >= delay then finalOffset = delay - 1 end
    if underwritingOffset >= finalOffset then underwritingOffset = math.max(initialOffset + 1, finalOffset - 1) end
    if initialOffset >= underwritingOffset then initialOffset = math.max(1, underwritingOffset - 1) end

    return submittedHour + initialOffset,
        submittedHour + underwritingOffset,
        submittedHour + finalOffset,
        submittedHour + delay
end

function RFF_ApplicationService:buildMortgageStageSchedule(submittedHour, decisionDelayHours)
    local delay = math.max(10, math.floor(safeNumber(decisionDelayHours)))
    local initialOffset = math.max(1, math.floor(delay * 0.12))
    local instructionOffset = math.max(initialOffset + 1, math.floor(delay * 0.25))
    local valuationOffset = math.max(instructionOffset + 1, math.floor(delay * 0.48))
    local underwritingOffset = math.max(valuationOffset + 1, math.floor(delay * 0.64))
    local finalOffset = math.max(underwritingOffset + 1, math.floor(delay * 0.84))
    if finalOffset >= delay then finalOffset = delay - 1 end
    return submittedHour + initialOffset,
        submittedHour + instructionOffset,
        submittedHour + valuationOffset,
        submittedHour + underwritingOffset,
        submittedHour + finalOffset,
        submittedHour + delay
end

function RFF_ApplicationService:getOfferValidityHours(application)
    local periods = application ~= nil and application.product == RFF_LoanService.TYPE_MORTGAGE and 2 or 1
    return math.max(24, self:getPeriodHours() * periods)
end

function RFF_ApplicationService:normaliseApplicationTiming(application)
    if application == nil then return end

    local fallbackDay = safeNumber(application.submittedDay)
    if safeNumber(application.submittedHour) <= 0 then
        application.submittedHour = math.floor(fallbackDay) * 24
    end

    if safeNumber(application.expectedMinHours) <= 0 then
        application.expectedMinHours = math.max(4, math.floor(safeNumber(application.expectedMinDays) * 24))
    end
    if safeNumber(application.expectedMaxHours) <= 0 then
        application.expectedMaxHours = math.max(application.expectedMinHours or 4, math.floor(safeNumber(application.expectedMaxDays) * 24))
    end

    if safeNumber(application.decisionHour) <= 0 then
        if safeNumber(application.decisionDay) > 0 then
            application.decisionHour = math.floor(safeNumber(application.decisionDay)) * 24
        else
            application.decisionHour = application.submittedHour + math.max(4, application.expectedMaxHours or 4)
        end
    end

    local totalDelay = math.max(4, application.decisionHour - application.submittedHour)
    if application.product == RFF_LoanService.TYPE_MORTGAGE then
        local initialHour, instructionHour, valuationHour, underwritingHour, finalHour = self:buildMortgageStageSchedule(application.submittedHour, totalDelay)
        if safeNumber(application.initialReviewHour) <= 0 then application.initialReviewHour = initialHour end
        if safeNumber(application.valuationInstructionHour) <= 0 then application.valuationInstructionHour = instructionHour end
        if safeNumber(application.valuationReturnHour) <= 0 then application.valuationReturnHour = valuationHour end
        if safeNumber(application.underwritingHour) <= 0 then application.underwritingHour = underwritingHour end
        if safeNumber(application.finalReviewHour) <= 0 then application.finalReviewHour = finalHour end
    else
        local initialHour, underwritingHour, finalHour = self:buildStageSchedule(application.submittedHour, totalDelay)
        if safeNumber(application.initialReviewHour) <= 0 then application.initialReviewHour = initialHour end
        if safeNumber(application.underwritingHour) <= 0 then application.underwritingHour = underwritingHour end
        if safeNumber(application.finalReviewHour) <= 0 then application.finalReviewHour = finalHour end
    end

    if safeNumber(application.offerExpiryHour) <= 0 and safeNumber(application.offerExpiryDay) > 0 then
        application.offerExpiryHour = math.floor(safeNumber(application.offerExpiryDay)) * 24
    end
    if safeNumber(application.acceptedHour) <= 0 and safeNumber(application.acceptedDay) > 0 then
        application.acceptedHour = math.floor(safeNumber(application.acceptedDay)) * 24
    end

    application.calendarDaysPerPeriod = math.max(1, math.floor(safeNumber(application.calendarDaysPerPeriod) > 0 and application.calendarDaysPerPeriod or self:getDaysPerPeriod()))

    -- Retain the v0.3.2 day fields for backward readability/migration.
    application.submittedDay = math.floor(application.submittedHour / 24)
    application.initialReviewDay = math.floor(application.initialReviewHour / 24)
    application.decisionDay = math.floor(application.decisionHour / 24)
    application.expectedMinDays = math.max(1, math.ceil((application.expectedMinHours or 4) / 24))
    application.expectedMaxDays = math.max(application.expectedMinDays, math.ceil((application.expectedMaxHours or 4) / 24))
    if safeNumber(application.offerExpiryHour) > 0 then application.offerExpiryDay = math.floor(application.offerExpiryHour / 24) end
    if safeNumber(application.acceptedHour) > 0 then application.acceptedDay = math.floor(application.acceptedHour / 24) end
end

function RFF_ApplicationService:submitApplication(farmId, amount, months, loanType, purpose, valuation, credit)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or self.loanService == nil then
        return nil, "server_only"
    end

    for _, existing in ipairs(self.repository:getApplicationsByFarm(farmId) or {}) do
        if self:isPending(existing) or existing.status == self.STATUS_OFFERED then
            return nil, "existing_open_application"
        end
    end

    amount = math.max(0, safeNumber(amount))
    months = math.max(1, math.floor(safeNumber(months)))
    if farmId == nil or farmId <= 0 or amount < 1000 then
        return nil, "invalid"
    end

    local underwritingCredit, submissionMarket, submissionFit = self:buildPrimaryMarketCredit(loanType, purpose or "GENERAL", amount, credit)
    underwritingCredit = underwritingCredit or credit
    local evaluation = self.loanService:evaluateApplication(farmId, amount, months, loanType, valuation, underwritingCredit)
    if loanType == RFF_LoanService.TYPE_OVERDRAFT then months = 12 end
    local id = self.repository:getNextApplicationId()
    local route, minHours, maxHours = self:estimateRoute(amount, loanType, valuation, underwritingCredit, evaluation, farmId)
    local delayHours = self:chooseDecisionDelay(id, minHours, maxHours)
    local submittedHour = self:getCurrentHourStamp()
    local initialReviewHour, underwritingHour, finalReviewHour, decisionHour = self:buildStageSchedule(submittedHour, delayHours)

    local application = {
        id = id,
        farmId = farmId,
        product = loanType,
        purpose = purpose or "GENERAL",
        requestedAmount = amount,
        requestedMonths = months,
        status = self.STATUS_SUBMITTED,
        route = route,
        submittedHour = submittedHour,
        initialReviewHour = initialReviewHour,
        underwritingHour = underwritingHour,
        finalReviewHour = finalReviewHour,
        decisionHour = decisionHour,
        expectedMinHours = minHours,
        expectedMaxHours = maxHours,
        calendarDaysPerPeriod = self:getDaysPerPeriod(),
        offerExpiryHour = 0,
        acceptedHour = 0,
        offeredAmount = 0,
        offeredMonths = 0,
        offeredRate = 0,
        offeredPayment = 0,
        offeredGrade = "",
        outcome = "PENDING",
        decisionReason = "",
        linkedLoanId = 0,
        submissionAssets = safeNumber(valuation ~= nil and valuation.totalAssets or 0),
        submissionCollateral = safeNumber(credit ~= nil and credit.collateral or 0),
        submissionIncome = safeNumber(credit ~= nil and credit.monthlyIncome or 0),
        submissionTrackedPeriods = safeNumber(credit ~= nil and credit.trackedPeriods or 0),
        submissionLtv = safeNumber(evaluation ~= nil and evaluation.ltv or 0),
        submissionDscr = evaluation ~= nil and evaluation.dscr ~= math.huge and evaluation.dscr or nil,
        submissionIndicativeApproved = evaluation ~= nil and evaluation.approved == true or false,
        submissionIndicativeGrade = evaluation ~= nil and evaluation.grade or "",
        submissionIndicativeRate = safeNumber(evaluation ~= nil and evaluation.interestRate or 0),
        submissionIndicativePayment = safeNumber(evaluation ~= nil and evaluation.monthlyPayment or 0),
        lenderId = "PRIMARY_BANK", lenderNameKey = "rff_lender_primary_bank",
        marketState = submissionMarket ~= nil and submissionMarket.state or "SELECTIVE",
        dealFit = submissionFit ~= nil and submissionFit.code or "STANDARD"
    }

    self:normaliseApplicationTiming(application)
    self.repository:addApplication(application)
    if self.relationshipService ~= nil then self.relationshipService:recordApplication(farmId, "PRIMARY_BANK") end
    self:notifyPhone(application, "rff_phone_application_submitted")
    return application, nil
end

function RFF_ApplicationService:submitMortgageApplication(farmId, farmlandId, downPaymentPercent, months)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or self.propertyFinance == nil then
        return nil, "server_only"
    end
    for _, existing in ipairs(self.repository:getApplicationsByFarm(farmId) or {}) do
        if self:isPending(existing) or existing.status == self.STATUS_OFFERED then
            return nil, "existing_open_application"
        end
    end

    local farmland = self.propertyFinance:getFarmland(farmlandId)
    if farmland == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID then return nil, "property_unavailable" end
    if not self.propertyFinance:isFarmlandAvailableForAcquisition(farmlandId) then return nil, "farmland_not_for_sale" end
    local evaluation = self.propertyFinance:evaluateMortgage(farmId, farmlandId, downPaymentPercent, months)
    if evaluation.reason == "funds" then return nil, "funds" end
    if evaluation.price == nil or evaluation.principal == nil or evaluation.principal < 1000 then return nil, "invalid" end

    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    local id = self.repository:getNextApplicationId()
    local route, minHours, maxHours = self:estimateRoute(evaluation.principal, RFF_LoanService.TYPE_MORTGAGE, valuation, credit, evaluation, farmId)
    local delayHours = self:chooseDecisionDelay(id, minHours, maxHours)
    local submittedHour = self:getCurrentHourStamp()
    local initialHour, instructionHour, valuationHour, underwritingHour, finalHour, decisionHour = self:buildMortgageStageSchedule(submittedHour, delayHours)

    local application = {
        id=id, farmId=farmId, product=RFF_LoanService.TYPE_MORTGAGE, purpose="LAND_PROPERTY",
        farmlandId=farmlandId, purchasePrice=evaluation.price, requestedDepositPercent=downPaymentPercent,
        requestedDepositAmount=evaluation.deposit, requestedAmount=evaluation.principal, requestedMonths=evaluation.months,
        status=self.STATUS_SUBMITTED, route=route, submittedHour=submittedHour, initialReviewHour=initialHour,
        valuationInstructionHour=instructionHour, valuationReturnHour=valuationHour, underwritingHour=underwritingHour,
        finalReviewHour=finalHour, decisionHour=decisionHour, expectedMinHours=minHours, expectedMaxHours=maxHours,
        calendarDaysPerPeriod=self:getDaysPerPeriod(), offerExpiryHour=0, acceptedHour=0,
        offeredAmount=0, offeredMonths=0, offeredRate=0, offeredPayment=0, offeredGrade="", offeredDeposit=0,
        outcome="PENDING", decisionReason="", linkedLoanId=0,
        submissionAssets=safeNumber(valuation.totalAssets), submissionCollateral=safeNumber(credit.collateral),
        submissionIncome=safeNumber(credit.monthlyIncome), submissionTrackedPeriods=safeNumber(credit.trackedPeriods),
        submissionLtv=safeNumber(evaluation.ltv), submissionDscr=evaluation.dscr ~= math.huge and evaluation.dscr or nil,
        submissionPropertyLtv=evaluation.propertyLtv ~= math.huge and evaluation.propertyLtv or nil,
        submissionIndicativeApproved=evaluation.approved == true, submissionIndicativeGrade=evaluation.grade or "",
        submissionIndicativeRate=safeNumber(evaluation.interestRate), submissionIndicativePayment=safeNumber(evaluation.monthlyPayment),
        lenderValuation=0, lenderValuationRatio=0, valuationCompletedHour=0, offeredPropertyLtv=0, propertyLtvLimit=0,
        lenderId="PRIMARY_BANK", lenderNameKey="rff_lender_primary_bank"
    }
    self:normaliseApplicationTiming(application)
    self.repository:addApplication(application)
    if self.relationshipService ~= nil then self.relationshipService:recordApplication(farmId, "PRIMARY_BANK") end
    self:notifyPhone(application, "rff_phone_mortgage_submitted")
    return application, nil
end

function RFF_ApplicationService:submitEquityReleaseApplication(farmId, farmlandId, advancePercent, months)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or self.propertyFinance == nil then return nil,"server_only" end
    for _,existing in ipairs(self.repository:getApplicationsByFarm(farmId) or {}) do
        if self:isPending(existing) or existing.status == self.STATUS_OFFERED then return nil,"existing_open_application" end
    end
    local farmland=self.propertyFinance:getFarmland(farmlandId)
    if farmland == nil or g_farmlandManager == nil or g_farmlandManager:getFarmlandOwner(farmlandId) ~= farmId then return nil,"property_unavailable" end
    if self.propertyFinance:getMortgageByFarmland(farmlandId,true) ~= nil then return nil,"already_mortgaged" end
    local evaluation=self.propertyFinance:evaluateEquityRelease(farmId,farmlandId,advancePercent,months)
    if evaluation.price == nil or evaluation.principal == nil or evaluation.principal < 1000 then return nil,"invalid" end
    local valuation=RFF_FarmValuation:calculate(farmId,self.repository)
    local credit=RFF_CreditProfile:calculate(farmId,valuation,self.repository)
    local id=self.repository:getNextApplicationId()
    local route,minHours,maxHours=self:estimateRoute(evaluation.principal,RFF_LoanService.TYPE_MORTGAGE,valuation,credit,evaluation,farmId)
    local delayHours=self:chooseDecisionDelay(id,minHours,maxHours)
    local submittedHour=self:getCurrentHourStamp()
    local initialHour,instructionHour,valuationHour,underwritingHour,finalHour,decisionHour=self:buildMortgageStageSchedule(submittedHour,delayHours)
    local application={
        id=id,farmId=farmId,product=RFF_LoanService.TYPE_MORTGAGE,purpose="LAND_PROPERTY",propertyFinanceMode="EQUITY_RELEASE",
        farmlandId=farmlandId,purchasePrice=evaluation.price,requestedDepositPercent=0,requestedDepositAmount=0,
        requestedAdvancePercent=advancePercent,requestedAmount=evaluation.principal,requestedMonths=evaluation.months,
        status=self.STATUS_SUBMITTED,route=route,submittedHour=submittedHour,initialReviewHour=initialHour,
        valuationInstructionHour=instructionHour,valuationReturnHour=valuationHour,underwritingHour=underwritingHour,
        finalReviewHour=finalHour,decisionHour=decisionHour,expectedMinHours=minHours,expectedMaxHours=maxHours,
        calendarDaysPerPeriod=self:getDaysPerPeriod(),offerExpiryHour=0,acceptedHour=0,
        offeredAmount=0,offeredMonths=0,offeredRate=0,offeredPayment=0,offeredGrade="",offeredDeposit=0,
        outcome="PENDING",decisionReason="",linkedLoanId=0,
        submissionAssets=safeNumber(valuation.totalAssets),submissionCollateral=safeNumber(credit.collateral),
        submissionIncome=safeNumber(credit.monthlyIncome),submissionTrackedPeriods=safeNumber(credit.trackedPeriods),
        submissionLtv=safeNumber(evaluation.ltv),submissionDscr=evaluation.dscr ~= math.huge and evaluation.dscr or nil,
        submissionPropertyLtv=evaluation.propertyLtv ~= math.huge and evaluation.propertyLtv or nil,
        submissionIndicativeApproved=evaluation.approved == true,submissionIndicativeGrade=evaluation.grade or "",
        submissionIndicativeRate=safeNumber(evaluation.interestRate),submissionIndicativePayment=safeNumber(evaluation.monthlyPayment),
        lenderValuation=0,lenderValuationRatio=0,valuationCompletedHour=0,offeredPropertyLtv=0,propertyLtvLimit=0,
        lenderId="PRIMARY_BANK",lenderNameKey="rff_lender_primary_bank"
    }
    self:normaliseApplicationTiming(application)
    self.repository:addApplication(application)
    if self.relationshipService ~= nil then self.relationshipService:recordApplication(farmId,"PRIMARY_BANK") end
    self:notifyPhone(application,"rff_phone_equity_release_submitted")
    return application,nil
end

function RFF_ApplicationService:submitHoldingEquityReleaseApplication(farmId, advancePercent, months)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or self.propertyFinance == nil then return nil,"server_only" end
    for _,existing in ipairs(self.repository:getApplicationsByFarm(farmId) or {}) do
        if self:isPending(existing) or existing.status == self.STATUS_OFFERED then return nil,"existing_open_application" end
    end
    local farmlands=self.propertyFinance:getHoldingEquityReleaseFarmlands(farmId)
    if #farmlands < 2 then return nil,"insufficient_security" end
    local evaluation=self.propertyFinance:evaluateHoldingEquityRelease(farmId,advancePercent,months)
    if evaluation.price == nil or evaluation.principal == nil or evaluation.principal < 1000 then return nil,"invalid" end
    local valuation=RFF_FarmValuation:calculate(farmId,self.repository)
    local credit=RFF_CreditProfile:calculate(farmId,valuation,self.repository)
    local id=self.repository:getNextApplicationId()
    local route,minHours,maxHours=self:estimateRoute(evaluation.principal,RFF_LoanService.TYPE_MORTGAGE,valuation,credit,evaluation,farmId)
    local delayHours=self:chooseDecisionDelay(id,minHours,maxHours)
    local submittedHour=self:getCurrentHourStamp()
    local initialHour,instructionHour,valuationHour,underwritingHour,finalHour,decisionHour=self:buildMortgageStageSchedule(submittedHour,delayHours)
    local application={
        id=id,farmId=farmId,product=RFF_LoanService.TYPE_MORTGAGE,purpose="LAND_PROPERTY",propertyFinanceMode="HOLDING_EQUITY_RELEASE",
        farmlandId=farmlands[1] ~= nil and farmlands[1].id or 0,securityFarmlandIds=evaluation.securityFarmlandIds or "",securityFarmlandCount=#farmlands,
        purchasePrice=evaluation.price,requestedDepositPercent=0,requestedDepositAmount=0,
        requestedAdvancePercent=advancePercent,requestedAmount=evaluation.principal,requestedMonths=evaluation.months,
        status=self.STATUS_SUBMITTED,route=route,submittedHour=submittedHour,initialReviewHour=initialHour,
        valuationInstructionHour=instructionHour,valuationReturnHour=valuationHour,underwritingHour=underwritingHour,
        finalReviewHour=finalHour,decisionHour=decisionHour,expectedMinHours=minHours,expectedMaxHours=maxHours,
        calendarDaysPerPeriod=self:getDaysPerPeriod(),offerExpiryHour=0,acceptedHour=0,
        offeredAmount=0,offeredMonths=0,offeredRate=0,offeredPayment=0,offeredGrade="",offeredDeposit=0,
        outcome="PENDING",decisionReason="",linkedLoanId=0,
        submissionAssets=safeNumber(valuation.totalAssets),submissionCollateral=safeNumber(credit.collateral),
        submissionIncome=safeNumber(credit.monthlyIncome),submissionTrackedPeriods=safeNumber(credit.trackedPeriods),
        submissionLtv=safeNumber(evaluation.ltv),submissionDscr=evaluation.dscr ~= math.huge and evaluation.dscr or nil,
        submissionPropertyLtv=evaluation.propertyLtv ~= math.huge and evaluation.propertyLtv or nil,
        submissionIndicativeApproved=evaluation.approved == true,submissionIndicativeGrade=evaluation.grade or "",
        submissionIndicativeRate=safeNumber(evaluation.interestRate),submissionIndicativePayment=safeNumber(evaluation.monthlyPayment),
        lenderValuation=0,lenderValuationRatio=0,valuationCompletedHour=0,offeredPropertyLtv=0,propertyLtvLimit=0,
        lenderId="PRIMARY_BANK",lenderNameKey="rff_lender_primary_bank"
    }
    self:normaliseApplicationTiming(application)
    self.repository:addApplication(application)
    if self.relationshipService ~= nil then self.relationshipService:recordApplication(farmId,"PRIMARY_BANK") end
    self:notifyPhone(application,"rff_phone_holding_equity_release_submitted")
    return application,nil
end

function RFF_ApplicationService:findCounterOffer(farmId, application, valuation, credit)
    local requested = math.max(0, safeNumber(application.requestedAmount))
    if requested < 10000 then return nil end

    local low = 1000
    local high = requested
    local bestAmount = 0
    local bestEvaluation = nil

    for _ = 1, 18 do
        local candidate = roundDown((low + high) * 0.5, 1000)
        if candidate < 1000 then candidate = 1000 end
        local evaluation = self.loanService:evaluateApplication(
            farmId,
            candidate,
            application.requestedMonths,
            application.product,
            valuation,
            credit)
        if evaluation.approved then
            bestAmount = candidate
            bestEvaluation = evaluation
            low = candidate + 1000
        else
            high = candidate - 1000
        end
        if high < low then break end
    end

    if bestAmount <= 0 then return nil end
    bestAmount = roundDown(bestAmount, 1000)
    if bestAmount < math.max(10000, requested * 0.50) then
        return nil
    end

    bestEvaluation = self.loanService:evaluateApplication(
        farmId,
        bestAmount,
        application.requestedMonths,
        application.product,
        valuation,
        credit)
    if bestEvaluation == nil or not bestEvaluation.approved then return nil end

    return bestAmount, bestEvaluation
end

function RFF_ApplicationService:getPhoneSender(application)
    local key = application ~= nil and application.lenderNameKey or "rff_lender_primary_bank"
    if RFF_NotificationService ~= nil then
        return RFF_NotificationService:getSender(key, "Primary Farm Bank")
    end
    return "Primary Farm Bank"
end

function RFF_ApplicationService:getPhoneTitle(application)
    local isMortgage = application ~= nil and application.product == RFF_LoanService.TYPE_MORTGAGE
    if RFF_NotificationService ~= nil then
        return RFF_NotificationService:getText(isMortgage and "rff_phone_title_mortgage" or "rff_phone_title_application", isMortgage and "Mortgage Update" or "Application Update")
    end
    return isMortgage and "Mortgage Update" or "Application Update"
end

function RFF_ApplicationService:notifyPhone(application, messageKey)
    if application == nil or RFF_NotificationService == nil then return false end
    local message = RFF_NotificationService:formatText(messageKey, "Finance application #%d has been updated.", application.id or 0)
    return RFF_NotificationService:pushPhone(application.farmId, self:getPhoneSender(application), self:getPhoneTitle(application), message, "application")
end

function RFF_ApplicationService:notify(application, messageKey)
    if g_currentMission == nil or g_i18n == nil then return end
    local text = g_i18n:getText(messageKey)
    if text == nil then return end
    if application ~= nil then
        text = string.format(text, application.id or 0)
    end

    local phoneKeys = {
        rff_notification_offer_ready = "rff_phone_application_offer_ready",
        rff_notification_counteroffer_ready = "rff_phone_application_counteroffer_ready",
        rff_notification_application_declined = "rff_phone_application_declined",
        rff_notification_offer_expired = "rff_phone_application_expired",
        rff_notification_mortgage_offer_ready = "rff_phone_mortgage_offer_ready",
        rff_notification_mortgage_counteroffer_ready = "rff_phone_mortgage_counteroffer_ready"
    }

    if application ~= nil and RFF_NotificationService ~= nil then
        local phoneKey = phoneKeys[messageKey]
        local message = phoneKey ~= nil and RFF_NotificationService:formatText(phoneKey, text, application.id or 0) or text
        if RFF_NotificationService:send(application.farmId, self:getPhoneSender(application), self:getPhoneTitle(application), message, "application", text, false) then
            return
        end
    end

    if g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, text)
    end
end

function RFF_ApplicationService:setFormalOffer(application, outcome, amount, evaluation, decisionReason)
    application.status = self.STATUS_OFFERED
    application.outcome = outcome
    application.offeredAmount = amount
    application.offeredMonths = evaluation ~= nil and math.max(1, math.floor(safeNumber(evaluation.months))) or application.requestedMonths
    local offeredRate = safeNumber(evaluation ~= nil and evaluation.interestRate or 0)
    if self.relationshipService ~= nil then
        local benefits = self.relationshipService:getBenefits(application.farmId, application.lenderId or "PRIMARY_BANK")
        offeredRate = math.max(0, offeredRate + safeNumber(benefits.rateAdjustment))
    end
    if self.marketService ~= nil and (evaluation == nil or evaluation.marketRateApplied ~= true) then
        local market, fit = self:getPrimaryMarketTerms(application.product, application.purpose, amount, evaluation ~= nil and evaluation.grade or nil)
        offeredRate = math.max(0, offeredRate + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment))
        application.marketState = market.state or application.marketState or "SELECTIVE"
        application.dealFit = fit.code or application.dealFit or "STANDARD"
    elseif evaluation ~= nil then
        application.marketState = evaluation.marketState or application.marketState or "SELECTIVE"
        application.dealFit = evaluation.dealFit or application.dealFit or "STANDARD"
    end
    application.offeredRate = offeredRate
    if self.loanService ~= nil then
        application.offeredPayment = self.loanService:calculateMonthlyPayment(amount, offeredRate, application.offeredMonths, application.product)
    else
        application.offeredPayment = safeNumber(evaluation ~= nil and evaluation.monthlyPayment or 0)
    end
    application.offeredGrade = evaluation ~= nil and evaluation.grade or ""
    application.offeredDeposit = evaluation ~= nil and safeNumber(evaluation.deposit) or safeNumber(application.offeredDeposit)
    application.offeredPropertyLtv = evaluation ~= nil and safeNumber(evaluation.propertyLtv) or safeNumber(application.offeredPropertyLtv)
    application.propertyLtvLimit = evaluation ~= nil and safeNumber(evaluation.propertyLtvLimit) or safeNumber(application.propertyLtvLimit)
    application.decisionReason = decisionReason or (evaluation ~= nil and evaluation.reason) or "approved"
    application.offerExpiryHour = self:getCurrentHourStamp() + self:getOfferValidityHours(application)
    application.offerExpiryDay = math.floor(application.offerExpiryHour / 24)
    if self.relationshipService ~= nil then self.relationshipService:recordOffer(application.farmId, application.lenderId or "PRIMARY_BANK") end
end

function RFF_ApplicationService:processMortgageDecision(application)
    if application == nil or self.propertyFinance == nil then return end
    local mode = application.propertyFinanceMode or ""
    local isEquityRelease = mode == "EQUITY_RELEASE"
    local isHoldingRelease = mode == "HOLDING_EQUITY_RELEASE"

    if isHoldingRelease then
        local ids = self.propertyFinance:getApplicationSecurityFarmlandIds(application)
        if #ids < 2 then
            application.status = self.STATUS_DECLINED
            application.outcome = "DECLINED"
            application.decisionReason = "security_unavailable"
            self:notify(application, "rff_notification_application_declined")
            return
        end
        local currentValue = 0
        for _, farmlandId in ipairs(ids) do
            local farmland = self.propertyFinance:getFarmland(farmlandId)
            local owner = farmland ~= nil and g_farmlandManager:getFarmlandOwner(farmlandId) or nil
            if farmland == nil or owner ~= application.farmId or self.propertyFinance:getMortgageByFarmland(farmlandId, true) ~= nil then
                application.status = self.STATUS_DECLINED
                application.outcome = "DECLINED"
                application.decisionReason = "security_unavailable"
                self:notify(application, "rff_notification_application_declined")
                return
            end
            currentValue = currentValue + math.max(0, safeNumber(farmland.price))
        end
        if math.abs(currentValue - safeNumber(application.purchasePrice)) > 1 then
            application.status = self.STATUS_DECLINED
            application.outcome = "DECLINED"
            application.decisionReason = "price_changed"
            self:notify(application, "rff_notification_application_declined")
            return
        end
    else
        local farmland = self.propertyFinance:getFarmland(application.farmlandId)
        local owner = farmland ~= nil and g_farmlandManager:getFarmlandOwner(application.farmlandId) or nil
        local propertyAvailable = isEquityRelease and owner == application.farmId or (not isEquityRelease and owner == FarmlandManager.NO_OWNER_FARM_ID)
        if farmland == nil or not propertyAvailable or (isEquityRelease and self.propertyFinance:getMortgageByFarmland(application.farmlandId, true) ~= nil) then
            application.status = self.STATUS_DECLINED
            application.outcome = "DECLINED"
            application.decisionReason = isEquityRelease and "security_unavailable" or "property_unavailable"
            self:notify(application, "rff_notification_application_declined")
            return
        end
        if not isEquityRelease and not self.propertyFinance:isFarmlandAvailableForAcquisition(application.farmlandId) then
            application.status = self.STATUS_DECLINED
            application.outcome = "DECLINED"
            application.decisionReason = "farmland_not_for_sale"
            self:notify(application, "rff_notification_application_declined")
            return
        end
        if math.abs(safeNumber(farmland.price) - safeNumber(application.purchasePrice)) > 1 then
            application.status = self.STATUS_DECLINED
            application.outcome = "DECLINED"
            application.decisionReason = "price_changed"
            self:notify(application, "rff_notification_application_declined")
            return
        end
    end

    local lenderValuation = self.propertyFinance:performLenderValuation(application)
    application.valuationCompletedHour = application.valuationCompletedHour > 0 and application.valuationCompletedHour or self:getCurrentHourStamp()
    local evaluation
    if isHoldingRelease then
        evaluation = self.propertyFinance:evaluateHoldingEquityReleasePrincipal(application.farmId, self.propertyFinance:getApplicationSecurityFarmlandIds(application), application.requestedAmount, application.requestedMonths, lenderValuation)
    elseif isEquityRelease then
        evaluation = self.propertyFinance:evaluateEquityReleasePrincipal(application.farmId, application.farmlandId, application.requestedAmount, application.requestedMonths, lenderValuation)
    else
        evaluation = self.propertyFinance:evaluateMortgagePrincipal(application.farmId, application.farmlandId, application.requestedAmount, application.requestedMonths, lenderValuation, false)
    end
    if evaluation.approved then
        self:setFormalOffer(application, "APPROVED", application.requestedAmount, evaluation, evaluation.reason or "approved")
        if isHoldingRelease then self:notify(application, "rff_notification_holding_equity_release_offer_ready")
        elseif isEquityRelease then self:notify(application, "rff_notification_equity_release_offer_ready")
        else self:notify(application, "rff_notification_mortgage_offer_ready") end
        return
    end

    local counterAmount, counterEvaluation
    if isHoldingRelease then counterAmount, counterEvaluation = self.propertyFinance:findHoldingEquityReleaseCounterOffer(application)
    elseif isEquityRelease then counterAmount, counterEvaluation = self.propertyFinance:findEquityReleaseCounterOffer(application)
    else counterAmount, counterEvaluation = self.propertyFinance:findMortgageCounterOffer(application) end
    if counterAmount ~= nil and counterEvaluation ~= nil then
        local reason = evaluation.reason
        if reason == "property_ltv" and lenderValuation < safeNumber(application.purchasePrice) then reason = "valuation_shortfall" end
        self:setFormalOffer(application, "COUNTEROFFER", counterAmount, counterEvaluation, reason or "property_ltv")
        if isHoldingRelease then self:notify(application, "rff_notification_holding_equity_release_counteroffer_ready")
        elseif isEquityRelease then self:notify(application, "rff_notification_equity_release_counteroffer_ready")
        else self:notify(application, "rff_notification_mortgage_counteroffer_ready") end
        return
    end

    application.status = self.STATUS_DECLINED
    application.outcome = "DECLINED"
    application.decisionReason = evaluation.reason or "affordability"
    application.offeredAmount = 0
    application.offeredMonths = 0
    application.offeredRate = safeNumber(evaluation.interestRate)
    application.offeredPayment = safeNumber(evaluation.monthlyPayment)
    application.offeredGrade = evaluation.grade or ""
    application.propertyLtvLimit = safeNumber(evaluation.propertyLtvLimit)
    self:notify(application, "rff_notification_application_declined")
end

function RFF_ApplicationService:processDecision(application)
    if application == nil or not self:isPending(application) then return end
    if application.product == RFF_LoanService.TYPE_MORTGAGE then
        self:processMortgageDecision(application)
        return
    end

    local farmId = application.farmId
    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    local underwritingCredit, market, fit = self:buildPrimaryMarketCredit(application.product, application.purpose, application.requestedAmount, credit)
    if underwritingCredit == nil or fit.available ~= true then
        application.status = self.STATUS_DECLINED
        application.outcome = "DECLINED"
        application.decisionReason = "lender_appetite"
        application.marketState = market ~= nil and market.state or "RESTRICTED"
        application.dealFit = fit ~= nil and fit.code or "LIMITED"
        self:notify(application, "rff_notification_application_declined")
        return
    end
    local evaluation = self.loanService:evaluateApplication(
        farmId,
        application.requestedAmount,
        application.requestedMonths,
        application.product,
        valuation,
        underwritingCredit)

    if evaluation.approved then
        self:setFormalOffer(application, "APPROVED", application.requestedAmount, evaluation, evaluation.reason or "approved")
        self:notify(application, "rff_notification_offer_ready")
        return
    end

    local counterAmount, counterEvaluation = self:findCounterOffer(farmId, application, valuation, underwritingCredit)
    if counterAmount ~= nil and counterEvaluation ~= nil then
        self:setFormalOffer(application, "COUNTEROFFER", counterAmount, counterEvaluation, evaluation.reason or "affordability")
        self:notify(application, "rff_notification_counteroffer_ready")
        return
    end

    application.status = self.STATUS_DECLINED
    application.outcome = "DECLINED"
    application.decisionReason = evaluation.reason or "affordability"
    application.offeredAmount = 0
    application.offeredMonths = 0
    application.offeredRate = safeNumber(evaluation.interestRate)
    application.offeredPayment = safeNumber(evaluation.monthlyPayment)
    application.offeredGrade = evaluation.grade or ""
    self:notify(application, "rff_notification_application_declined")
end

function RFF_ApplicationService:processTime()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local nowHour = self:getCurrentHourStamp()

    for _, application in ipairs(self.repository.applications or {}) do
        self:normaliseApplicationTiming(application)

        if application.product == RFF_LoanService.TYPE_MORTGAGE then
            if application.status == self.STATUS_SUBMITTED and nowHour >= safeNumber(application.initialReviewHour) then
                application.status = self.STATUS_INITIAL_REVIEW
                self:notifyPhone(application, "rff_phone_application_initial_review")
            end
            if application.status == self.STATUS_INITIAL_REVIEW and nowHour >= safeNumber(application.valuationInstructionHour) then
                application.status = self.STATUS_VALUATION_INSTRUCTED
                self:notifyPhone(application, "rff_phone_mortgage_valuation_instructed")
            end
            if application.status == self.STATUS_VALUATION_INSTRUCTED and nowHour >= safeNumber(application.valuationReturnHour) then
                if self.propertyFinance ~= nil then self.propertyFinance:performLenderValuation(application) end
                application.valuationCompletedHour = nowHour
                application.status = self.STATUS_VALUATION_RETURNED
                self:notifyPhone(application, "rff_phone_mortgage_valuation_returned")
            end
            if application.status == self.STATUS_VALUATION_RETURNED and nowHour >= safeNumber(application.underwritingHour) then
                application.status = self.STATUS_UNDERWRITING
                self:notifyPhone(application, "rff_phone_application_underwriting")
            end
            if application.status == self.STATUS_UNDERWRITING and nowHour >= safeNumber(application.finalReviewHour) then
                application.status = self.STATUS_FINAL_REVIEW
                self:notifyPhone(application, "rff_phone_application_final_review")
            end
        else
            if application.status == self.STATUS_SUBMITTED and nowHour >= safeNumber(application.initialReviewHour) then
                application.status = self.STATUS_INITIAL_REVIEW
                self:notifyPhone(application, "rff_phone_application_initial_review")
            end
            if application.status == self.STATUS_INITIAL_REVIEW and nowHour >= safeNumber(application.underwritingHour) then
                application.status = self.STATUS_UNDERWRITING
                self:notifyPhone(application, "rff_phone_application_underwriting")
            end
            if application.status == self.STATUS_UNDERWRITING and nowHour >= safeNumber(application.finalReviewHour) then
                application.status = self.STATUS_FINAL_REVIEW
                self:notifyPhone(application, "rff_phone_application_final_review")
            end
        end

        if self:isPending(application) and nowHour >= safeNumber(application.decisionHour) then
            self:processDecision(application)
        elseif application.status == self.STATUS_OFFERED and safeNumber(application.offerExpiryHour) > 0 and nowHour >= safeNumber(application.offerExpiryHour) then
            application.status = self.STATUS_EXPIRED
            application.outcome = "EXPIRED"
            self:notify(application, "rff_notification_offer_expired")
        end
    end
end

function RFF_ApplicationService:canInstantDecision(application,farmId)
    if not RFF_NewSaveSetup or not RFF_NewSaveSetup.isOpen(self.repository) or not application
        or application.farmId~=farmId
        or (application.propertyFinanceMode or "")~="" or not self:isPending(application) then return false end
    local p=application.product
    if p==nil or not (p==RFF_LoanService.TYPE_MORTGAGE or p==RFF_LoanService.TYPE_TERM
        or p==RFF_LoanService.TYPE_BULLET or p==RFF_LoanService.TYPE_REVOLVING
        or p==RFF_LoanService.TYPE_OVERDRAFT) then return false end
    for _,record in ipairs(self.repository.applications or {}) do if record==application then return true end end
    return false
end
function RFF_ApplicationService:instantDecision(application,farmId)
    if not self:canInstantDecision(application,farmId) then return false end
    -- Retain the ordinary valuation, availability and underwriting decision.
    -- No other applications, game time, funds or land ownership are advanced.
    local now=self:getCurrentHourStamp()
    self:processDecision(application)
    if self:isPending(application) then return false end
    application.decisionHour=now;application.decisionDay=math.floor(now/24)
    return true
end

function RFF_ApplicationService:onHourChanged()
    self:processTime()
end

function RFF_ApplicationService:onDayChanged()
    -- Safety pass for very high time acceleration or save loads which cross several hours.
    self:processTime()
end

function RFF_ApplicationService:acceptOffer(application)
    if g_currentMission == nil or not g_currentMission:getIsServer() or application == nil or application.status ~= self.STATUS_OFFERED then
        return nil, "invalid"
    end

    self:normaliseApplicationTiming(application)
    local nowHour = self:getCurrentHourStamp()
    if safeNumber(application.offerExpiryHour) > 0 and nowHour >= safeNumber(application.offerExpiryHour) then
        application.status = self.STATUS_EXPIRED
        application.outcome = "EXPIRED"
        return nil, "expired"
    end

    local offer = {
        approved = true,
        amount = application.offeredAmount,
        months = application.offeredMonths,
        loanType = application.product,
        interestRate = application.offeredRate,
        monthlyPayment = application.offeredPayment,
        grade = application.offeredGrade,
        reason = "formal_offer",
        lenderId = application.lenderId or "PRIMARY_BANK",
        lenderNameKey = application.lenderNameKey or "rff_lender_primary_bank",
        brokered = false, brokerCaseId = 0, arrangementFee = 0, brokerFee = 0
    }

    local loan, reason
    if application.product == RFF_LoanService.TYPE_MORTGAGE then
        if self.propertyFinance == nil then return nil, "property_service_unavailable" end
        loan, reason = self.propertyFinance:completeMortgageFromApplication(application)
    else
        loan, reason = self.loanService:createLoanFromOffer(
            application.farmId,
            application.offeredAmount,
            application.offeredMonths,
            application.product,
            application.purpose,
            offer)
    end

    if loan == nil then return nil, reason or "loan_create_failed" end

    application.status = self.STATUS_ACCEPTED
    application.outcome = application.outcome == "COUNTEROFFER" and "COUNTEROFFER_ACCEPTED" or "APPROVED_ACCEPTED"
    application.linkedLoanId = loan.id or 0
    application.acceptedHour = nowHour
    application.acceptedDay = math.floor(nowHour / 24)
    if self.relationshipService ~= nil then self.relationshipService:recordAcceptedDeal(application.farmId, application.lenderId or "PRIMARY_BANK", application.offeredAmount or 0, false) end
    local completionKey = "rff_phone_application_completed"
    if application.product == RFF_LoanService.TYPE_MORTGAGE then
        if application.propertyFinanceMode == "HOLDING_EQUITY_RELEASE" then completionKey = "rff_phone_holding_equity_release_completed"
        elseif application.propertyFinanceMode == "EQUITY_RELEASE" then completionKey = "rff_phone_equity_release_completed"
        else completionKey = "rff_phone_mortgage_completed" end
    end
    self:notifyPhone(application, completionKey)
    return loan, nil
end

function RFF_ApplicationService:withdrawApplication(application)
    if application == nil then return false end
    if self:isPending(application) or application.status == self.STATUS_OFFERED then
        application.status = self.STATUS_WITHDRAWN
        application.outcome = "WITHDRAWN"
        return true
    end
    return false
end

function RFF_ApplicationService:forceProcessAll(farmId)
    if self.repository == nil then return 0 end
    local count = 0
    for _, application in ipairs(self.repository.applications or {}) do
        if (farmId == nil or application.farmId == farmId) and self:isPending(application) then
            self:normaliseApplicationTiming(application)
            self:processDecision(application)
            count = count + 1
        end
    end
    return count
end
