RFF_DefaultManagementService = {}
RFF_DefaultManagementService.__index = RFF_DefaultManagementService

RFF_DefaultManagementService.DEFAULT_INTEREST_SURCHARGE = 4.00
RFF_DefaultManagementService.ADMIN_FEES = {[1]=25, [2]=50, [3]=100}
RFF_DefaultManagementService.ONGOING_DEFAULT_ADMIN_FEE = 50

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local function moneyTypeCharges()
    if MoneyType ~= nil then return MoneyType.LOAN_INTEREST or MoneyType.OTHER end
    return nil
end

function RFF_DefaultManagementService.new(repository)
    local self = setmetatable({}, RFF_DefaultManagementService)
    self.repository = repository
    self.assetFinanceService = nil
    self.propertyFinanceService = nil
    return self
end

function RFF_DefaultManagementService:setAssetFinanceService(service)
    self.assetFinanceService = service
end

function RFF_DefaultManagementService:setPropertyFinanceService(service)
    self.propertyFinanceService = service
end

function RFF_DefaultManagementService:getRecoveryAge(entity, isAsset)
    if not isAsset and entity ~= nil and entity.type == RFF_LoanService.TYPE_MORTGAGE then return 6 end
    return 4
end

function RFF_DefaultManagementService:getStage(age, entity, isAsset)
    age = math.max(0, math.floor(safeNumber(age)))
    if age <= 0 then return "CURRENT" end
    if age == 1 then return "REMINDER" end
    if age == 2 then return "ARREARS_WARNING" end
    if age == 3 then return "DEFAULT_NOTICE" end
    if not isAsset and entity ~= nil and entity.type == RFF_LoanService.TYPE_MORTGAGE then
        if age == 4 then return "FORMAL_DEMAND" end
        if age == 5 then return "POSSESSION_WARNING" end
    end
    return "RECOVERY"
end

function RFF_DefaultManagementService:getStageTextKey(stage)
    if stage == "REMINDER" then return "rff_arrears_stage_reminder" end
    if stage == "ARREARS_WARNING" then return "rff_arrears_stage_warning" end
    if stage == "DEFAULT_NOTICE" then return "rff_arrears_stage_default_notice" end
    if stage == "FORMAL_DEMAND" then return "rff_arrears_stage_formal_demand" end
    if stage == "POSSESSION_WARNING" then return "rff_arrears_stage_possession_warning" end
    if stage == "RECOVERY" then return "rff_arrears_stage_recovery" end
    return "rff_arrears_stage_current"
end

function RFF_DefaultManagementService:getEntityName(entity, isAsset)
    if isAsset then return entity.vehicleName or "Asset finance agreement" end
    if entity.type == RFF_LoanService.TYPE_MORTGAGE then return "Agricultural mortgage" end
    if entity.type == RFF_LoanService.TYPE_OVERDRAFT then return "Overdraft facility" end
    if entity.type == RFF_LoanService.TYPE_REVOLVING then return "Revolving credit facility" end
    if entity.type == RFF_LoanService.TYPE_BULLET then return "Interest-only / bullet loan" end
    return "Farm term loan"
end

function RFF_DefaultManagementService:notify(entity, isAsset, stage, charge, defaultInterest)
    if entity == nil or g_currentMission == nil then return end
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(entity) or math.max(0, safeNumber(entity.arrearsBalance))
    local name = self:getEntityName(entity, isAsset)
    local stageKey = self:getStageTextKey(stage)
    local stageText = g_i18n ~= nil and g_i18n:getText(stageKey) or stage
    local text = string.format(g_i18n:getText("rff_arrears_escalation_notification"),
        name,
        stageText,
        g_i18n:formatMoney(arrears, 0, true, true),
        g_i18n:formatMoney(math.max(0, safeNumber(defaultInterest)), 0, true, true),
        g_i18n:formatMoney(math.max(0, safeNumber(charge)), 0, true, true))

    if RFF_NotificationService ~= nil then
        local sender
        if isAsset then
            sender = RFF_NotificationService:getSender(entity.lenderNameKey, RFF_NotificationService:getText("rff_phone_sender_asset_finance", "Asset Finance Provider"))
        else
            sender = RFF_NotificationService:getSender(entity.lenderNameKey, "Primary Farm Bank")
        end
        local isDefault = stage == "DEFAULT_NOTICE" or stage == "FORMAL_DEMAND" or stage == "POSSESSION_WARNING" or stage == "RECOVERY"
        local title = RFF_NotificationService:getText(isDefault and "rff_phone_title_default" or "rff_phone_title_arrears", isDefault and "Default Notice" or "Arrears Update")
        if RFF_NotificationService:send(entity.farmId, sender, title, text, "payment", text, true) then return end
    end

    if g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, text)
    end
end

function RFF_DefaultManagementService:normaliseEntity(entity)
    if entity == nil then return end
    entity.arrearsFees = math.max(0, safeNumber(entity.arrearsFees))
    entity.defaultInterestAccrued = math.max(0, safeNumber(entity.defaultInterestAccrued))
    entity.adminChargesAccrued = math.max(0, safeNumber(entity.adminChargesAccrued))
    entity.defaultEvents = math.max(0, math.floor(safeNumber(entity.defaultEvents)))
    entity.arrearsAgeMonths = math.max(0, math.floor(safeNumber(entity.arrearsAgeMonths)))
    entity.lastDefaultManagementPeriod = math.max(0, math.floor(safeNumber(entity.lastDefaultManagementPeriod)))
    -- Only reconstruct an arrears age for agreements loaded from the pre-default-management schema.
    -- Fresh misses are advanced by processEntity below, so the first missed month correctly starts at REMINDER.
    if (RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(entity) or safeNumber(entity.arrearsBalance)) > 0.01
        and entity.arrearsAgeMonths <= 0 and entity.lastDefaultManagementPeriod <= 0 then
        local historic = math.max(0, math.floor(safeNumber(entity.consecutiveMissedPayments)))
        if historic > 0 then entity.arrearsAgeMonths = math.min(4, math.max(0, historic - 1)) end
    end
    entity.arrearsStage = entity.arrearsStage or self:getStage(entity.arrearsAgeMonths, entity, false)
    entity.recoveryEligible = entity.recoveryEligible == true or entity.arrearsAgeMonths >= self:getRecoveryAge(entity, false)
    -- v0.5.1 extends mortgage enforcement beyond the generic four-month asset/default path.
    -- Existing v0.5.0 mortgage defaults therefore migrate into the appropriate slower property stage.
    if entity.type == RFF_LoanService.TYPE_MORTGAGE and entity.arrearsAgeMonths < self:getRecoveryAge(entity, false) then
        entity.arrearsStage = self:getStage(entity.arrearsAgeMonths, entity, false)
        entity.recoveryEligible = false
        entity.mortgageRecoveryEligiblePeriod = 0
        entity.mortgageRecoveryPending = false
    end
end

function RFF_DefaultManagementService:processEntity(entity, isAsset, currentPeriod)
    if entity == nil then return end
    self:normaliseEntity(entity)
    if safeNumber(entity.lastDefaultManagementPeriod) >= currentPeriod then return end

    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(entity) or math.max(0, safeNumber(entity.arrearsBalance))
    if arrears <= 0.01 then
        entity.arrearsAgeMonths = 0
        entity.arrearsStage = "CURRENT"
        entity.recoveryEligible = false
        entity.currentDefault = false
        entity.lastDefaultManagementPeriod = currentPeriod
        return
    end

    entity.arrearsAgeMonths = math.max(1, math.floor(safeNumber(entity.arrearsAgeMonths)) + 1)
    local stage = self:getStage(entity.arrearsAgeMonths, entity, isAsset)
    entity.arrearsStage = stage

    local defaultInterest = arrears * (self.DEFAULT_INTEREST_SURCHARGE / 100) / 12
    if defaultInterest > 0.005 then
        entity.arrearsInterest = math.max(0, safeNumber(entity.arrearsInterest)) + defaultInterest
        entity.defaultInterestAccrued = safeNumber(entity.defaultInterestAccrued) + defaultInterest
    else
        defaultInterest = 0
    end

    local adminFee
    if not isAsset and entity.type == RFF_LoanService.TYPE_MORTGAGE then
        if entity.arrearsAgeMonths == 1 then adminFee = 25
        elseif entity.arrearsAgeMonths == 2 then adminFee = 50
        elseif entity.arrearsAgeMonths == 3 then adminFee = 100
        elseif entity.arrearsAgeMonths == 4 then adminFee = 100
        elseif entity.arrearsAgeMonths == 5 then adminFee = 150
        else adminFee = 200 end
    else
        adminFee = self.ADMIN_FEES[entity.arrearsAgeMonths] or (entity.arrearsAgeMonths >= 4 and self.ONGOING_DEFAULT_ADMIN_FEE or 0)
    end
    if adminFee > 0 then
        entity.arrearsFees = math.max(0, safeNumber(entity.arrearsFees)) + adminFee
        entity.adminChargesAccrued = safeNumber(entity.adminChargesAccrued) + adminFee
    end

    if stage == "DEFAULT_NOTICE" or stage == "FORMAL_DEMAND" or stage == "POSSESSION_WARNING" or stage == "RECOVERY" then
        entity.currentDefault = true
        if entity.defaultRecorded ~= true then
            entity.defaultRecorded = true
            entity.defaultEvents = math.max(0, math.floor(safeNumber(entity.defaultEvents))) + 1
        end
    end
    if stage == "RECOVERY" then
        entity.recoveryEligible = true
        if isAsset and safeNumber(entity.recoveryEligiblePeriod) <= 0 then
            entity.recoveryEligiblePeriod = currentPeriod
            entity.recoveryPending = true
            if self.assetFinanceService ~= nil and self.assetFinanceService.notifyRecoveryEligible ~= nil then
                self.assetFinanceService:notifyRecoveryEligible(entity)
            end
        elseif not isAsset and entity.type == RFF_LoanService.TYPE_MORTGAGE and safeNumber(entity.mortgageRecoveryEligiblePeriod) <= 0 then
            entity.mortgageRecoveryEligiblePeriod = currentPeriod
            entity.mortgageRecoveryPending = true
            if self.propertyFinanceService ~= nil and self.propertyFinanceService.notifyMortgageRecoveryEligible ~= nil then
                self.propertyFinanceService:notifyMortgageRecoveryEligible(entity)
            end
        end
    end

    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:getArrears(entity) end
    entity.lastDefaultManagementPeriod = currentPeriod
    self:notify(entity, isAsset, stage, adminFee, defaultInterest)
end

function RFF_DefaultManagementService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for _, loan in ipairs(self.repository.loans or {}) do
        if not loan.paidOff and loan.type ~= RFF_LoanService.TYPE_OVERDRAFT and loan.type ~= RFF_LoanService.TYPE_RECOVERY_SHORTFALL then
            self:processEntity(loan, false, current)
            if loan.type == RFF_LoanService.TYPE_MORTGAGE and loan.recoveryEligible == true and self.propertyFinanceService ~= nil then
                self.propertyFinanceService:attemptForcedMortgageRecovery(loan)
            end
        end
    end
    for _, agreement in ipairs(self.repository.assetFinance or {}) do
        if agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE" then
            self:processEntity(agreement, true, current)
            if agreement.recoveryEligible == true and self.assetFinanceService ~= nil then
                self.assetFinanceService:attemptForcedRecovery(agreement)
            end
        end
    end
end
