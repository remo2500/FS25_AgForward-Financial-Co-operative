RFF_UsedEquipmentYardsIntegration = {}
RFF_UsedEquipmentYardsIntegration._installed = false
RFF_UsedEquipmentYardsIntegration._retryTimer = 0

local USED_EQUIPMENT_YARDS_MOD = "FS25_UsedEquipmentYards"

local function rffManager()
    return RFF_RealisticFarmFinance ~= nil and RFF_RealisticFarmFinance.manager or nil
end

local function getUsedEquipmentEnvironment()
    local environment = _G[USED_EQUIPMENT_YARDS_MOD]
    return type(environment) == "table" and environment or nil
end

local function getUsedEquipmentMember(name)
    local environment = getUsedEquipmentEnvironment()
    local value = environment ~= nil and rawget(environment, name) or nil
    if value ~= nil then return value end
    return rawget(_G, name)
end

local function formatMoney(value)
    if g_i18n ~= nil and type(g_i18n.formatMoney) == "function" then
        return g_i18n:formatMoney(value or 0, 0, true, true)
    end
    return string.format("%.0f", value or 0)
end

function RFF_UsedEquipmentYardsIntegration:isModActive()
    return g_modIsLoaded ~= nil and g_modIsLoaded[USED_EQUIPMENT_YARDS_MOD] == true
end

function RFF_UsedEquipmentYardsIntegration:getLocalFarmId(barterDialog)
    if barterDialog ~= nil and type(barterDialog.getLocalFarmId) == "function" then
        local ok, farmId = pcall(barterDialog.getLocalFarmId)
        if ok and tonumber(farmId) ~= nil then return math.floor(tonumber(farmId)) end
    end
    if g_currentMission ~= nil and type(g_currentMission.getFarmId) == "function" then
        return math.floor(tonumber(g_currentMission:getFarmId()) or 0)
    end
    return 0
end

function RFF_UsedEquipmentYardsIntegration:isYardHirePurchaseAvailable(dialog)
    local finance = rffManager()
    return finance ~= nil
        and finance.assetFinance ~= nil
        and dialog ~= nil
        and dialog.item ~= nil
        and dialog.item.vehicle ~= nil
        and dialog.yard ~= nil
        and dialog.yard.inventory ~= nil
        and dialog.yard.inventory.config ~= nil
        and dialog.yard.inventory.config.allowHirePurchase ~= false
end

function RFF_UsedEquipmentYardsIntegration:install()
    if self._installed then return true end
    if not self:isModActive() then return false end

    local barterDialog = getUsedEquipmentMember("BarterDialog")
    if type(barterDialog) ~= "table" or type(barterDialog.updateButtonStates) ~= "function"
            or type(barterDialog.onClickHirePurchase) ~= "function" then
        return false
    end

    barterDialog.updateButtonStates = Utils.appendedFunction(barterDialog.updateButtonStates, function(dialog)
        local available = RFF_UsedEquipmentYardsIntegration:isYardHirePurchaseAvailable(dialog)
        if not available then return end
        local onTestDrive = dialog.item ~= nil and dialog.item.testDrive ~= nil
        if dialog.hirePurchaseButton ~= nil then
            dialog.hirePurchaseButton:setVisible(true)
            dialog.hirePurchaseButton.disabled = onTestDrive
        end
        if dialog.hirePurchaseSeparator ~= nil then dialog.hirePurchaseSeparator:setVisible(true) end
    end)

    barterDialog.onClickHirePurchase = Utils.overwrittenFunction(barterDialog.onClickHirePurchase,
        function(dialog, superFunc, ...)
            if not RFF_UsedEquipmentYardsIntegration:isYardHirePurchaseAvailable(dialog) then
                return superFunc(dialog, ...)
            end
            return RFF_UsedEquipmentYardsIntegration:openHirePurchase(dialog, barterDialog)
        end)

    self._installed = true
    print("[RealisticFarmFinance] Used Equipment Yards Hire Purchase integration active")
    return true
end

function RFF_UsedEquipmentYardsIntegration:update(dt)
    if self._installed or not self:isModActive() then return end
    self._retryTimer = math.max(0, (self._retryTimer or 0) - (tonumber(dt) or 0))
    if self._retryTimer > 0 then return end
    self._retryTimer = 2000
    self:install()
end

function RFF_UsedEquipmentYardsIntegration:openHirePurchase(dialog, barterDialog)
    local farmId = self:getLocalFarmId(barterDialog)
    if farmId <= 0 or dialog == nil or dialog.item == nil or dialog.yard == nil then return end

    local item = dialog.item
    local vehicle = item.vehicle
    local yardCredit = getUsedEquipmentMember("YardCredit")
    local credit = 0
    if type(yardCredit) == "table" and type(yardCredit.getBalance) == "function" then
        local ok, value = pcall(yardCredit.getBalance, farmId, dialog.yard.id)
        if ok then credit = math.max(0, tonumber(value) or 0) end
    end
    credit = math.min(math.max(0, tonumber(item.price) or 0), credit)
    local financeAmount = math.max(0, (tonumber(item.price) or 0) - credit)
    if financeAmount < 1000 then
        InfoDialog.show(g_i18n:getText("rff_asset_used_yard_credit_covers"))
        return
    end

    local storeItem = vehicle ~= nil and g_storeManager ~= nil
        and g_storeManager:getItemByXMLFilename(vehicle.configFileName) or nil
    if storeItem == nil then
        InfoDialog.show(g_i18n:getText("rff_asset_used_yard_unavailable"))
        return
    end

    local context = {
        type = "USED_EQUIPMENT_YARD",
        farmId = farmId,
        yardId = dialog.yard.id,
        itemIndex = dialog.itemIndex,
        vehicleUniqueId = tostring(vehicle.uniqueId or ""),
        advertisedPrice = math.max(0, tonumber(item.price) or 0),
        quotedCredit = credit
    }

    if type(dialog.close) == "function" then dialog:close() end
    local shown = g_gui ~= nil and g_gui:showDialog("RFFAssetFinanceDialog") or nil
    if shown == nil or shown.target == nil then
        InfoDialog.show(g_i18n:getText("rff_asset_used_yard_unavailable"))
        return
    end
    shown.target:setData(storeItem, vehicle.configurations or {}, nil, financeAmount, nil,
        vehicle.configurationData or {}, context)
end

function RFF_UsedEquipmentYardsIntegration:completeHirePurchase(context, purchaseData)
    local finance = rffManager()
    if finance == nil or finance.assetFinance == nil or finance.repository == nil then return false, "service" end
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "server" end
    if context == nil or context.type ~= "USED_EQUIPMENT_YARD" then return false, "context" end

    local usedEquipmentYards = getUsedEquipmentMember("UsedEquipmentYards")
    local yardCredit = getUsedEquipmentMember("YardCredit")
    local yardInventory = getUsedEquipmentMember("YardInventory")
    local priceTagRenderer = getUsedEquipmentMember("PriceTagRenderer")
    if type(usedEquipmentYards) ~= "table" or usedEquipmentYards.yardManager == nil
            or type(yardCredit) ~= "table" then
        return false, "service"
    end

    local yard = usedEquipmentYards.yardManager.yards[context.yardId]
    local item = yard ~= nil and yard.inventory ~= nil and yard.inventory.items[context.itemIndex] or nil
    local vehicle = item ~= nil and item.vehicle or nil
    if item == nil or vehicle == nil then return false, "sold" end
    if tostring(context.vehicleUniqueId or "") ~= "" and tostring(vehicle.uniqueId or "") ~= tostring(context.vehicleUniqueId) then
        return false, "changed"
    end
    if item.testDrive ~= nil then return false, "test_drive" end
    if type(vehicle.setOwnerFarmId) ~= "function" then return false, "vehicle" end

    local farmId = math.floor(tonumber(context.farmId) or 0)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    if farmId <= 0 or farm == nil then return false, "farm" end

    local price = math.max(0, tonumber(item.price) or 0)
    local creditAvailable = type(yardCredit.getBalance) == "function"
        and math.max(0, tonumber(yardCredit.getBalance(farmId, context.yardId)) or 0) or 0
    local expectedCredit = math.min(price, creditAvailable)
    local financeAmount = math.max(0, price - expectedCredit)
    if financeAmount < 1000 then return false, "credit_covers" end
    if math.abs(financeAmount - (tonumber(purchaseData.basePrice) or 0)) > 1 then return false, "changed" end

    local quote = finance.assetFinance:evaluateQuote(
        farmId,
        financeAmount,
        tonumber(purchaseData.depositPercent) or 0,
        tonumber(purchaseData.months) or 0,
        RFF_AssetFinanceService.TYPE_HIRE_PURCHASE,
        0
    )
    if quote == nil or quote.approved ~= true then return false, "underwriting" end
    if not finance.assetFinance:canAfford(farmId, quote.deposit or 0) then return false, "funds" end

    local creditUsed = 0
    if type(yardCredit.deductCredit) == "function" then
        creditUsed = math.max(0, tonumber(yardCredit.deductCredit(farmId, context.yardId, price)) or 0)
    end
    if math.abs(creditUsed - expectedCredit) > 1 then
        if creditUsed > 0 and type(yardCredit.addCredit) == "function" then yardCredit.addCredit(farmId, context.yardId, creditUsed) end
        return false, "changed"
    end

    local vehicleName = vehicle.getFullName ~= nil and vehicle:getFullName()
        or vehicle.getName ~= nil and vehicle:getName()
        or purchaseData.vehicleName
        or "Used equipment"
    if finance.repository.setNextTransactionDescription ~= nil then
        finance.repository:setNextTransactionDescription(farmId, string.format("Hire Purchase deposit - %s", vehicleName))
    end
    g_currentMission:addMoney(-(quote.deposit or 0), farmId,
        MoneyType ~= nil and (MoneyType.SHOP_VEHICLE_BUY or MoneyType.OTHER) or nil, true, true)

    local agreementData = {
        farmId = farmId,
        product = RFF_AssetFinanceService.TYPE_HIRE_PURCHASE,
        basePrice = financeAmount,
        depositPercent = quote.depositPercent,
        deposit = quote.deposit,
        months = quote.months,
        balloonPercent = 0,
        balloonAmount = 0,
        residualValue = 0,
        amountFinanced = quote.amountFinanced,
        interestRate = quote.interestRate,
        monthlyPayment = quote.monthlyPayment,
        grade = quote.grade,
        lenderId = quote.lenderId or "PRIMARY_BANK",
        lenderNameKey = quote.lenderNameKey or "rff_lender_primary_bank",
        marketState = quote.marketState or "SELECTIVE",
        dealFit = quote.dealFit or "STANDARD",
        vehicleName = vehicleName,
        storeItemXml = vehicle.configFileName or purchaseData.storeItemXml or ""
    }
    local agreement = finance.assetFinance:createAgreementFromPurchase(agreementData, vehicle)
    if agreement == nil then
        g_currentMission:addMoney(quote.deposit or 0, farmId,
            MoneyType ~= nil and (MoneyType.SHOP_VEHICLE_BUY or MoneyType.OTHER) or nil, true, true)
        if creditUsed > 0 and type(yardCredit.addCredit) == "function" then yardCredit.addCredit(farmId, context.yardId, creditUsed) end
        return false, "agreement"
    end

    if type(yardInventory) == "table" and type(yardInventory.detachVehicle) == "function" then
        yardInventory.detachVehicle(vehicle)
    end
    vehicle:setOwnerFarmId(farmId)
    if type(priceTagRenderer) == "table" and type(priceTagRenderer.removeTag) == "function" then priceTagRenderer.removeTag(vehicle) end
    if type(usedEquipmentYards.restoreLicensePlate) == "function" then usedEquipmentYards.restoreLicensePlate(vehicle) end
    if type(usedEquipmentYards.clearVehicleRestrictions) == "function" then usedEquipmentYards.clearVehicleRestrictions(vehicle) end
    if type(usedEquipmentYards.addRecentSale) == "function" then usedEquipmentYards.addRecentSale(vehicle.uniqueId or "", price) end
    yard.inventory:removeItem(item, true)

    if finance.fleetManagement ~= nil and type(finance.fleetManagement.grantDealershipCover) == "function" then
        finance.fleetManagement:grantDealershipCover(farmId, vehicle)
    end
    print(string.format("[RealisticFarmFinance] Used Equipment Yards Hire Purchase completed farm=%d vehicle=%s price=%.2f credit=%.2f financedPrice=%.2f deposit=%.2f agreement=%d",
        farmId, tostring(vehicleName), price, creditUsed, financeAmount, quote.deposit or 0, agreement.id or 0))
    return true, "completed", {vehicleName=vehicleName, creditUsed=creditUsed, deposit=quote.deposit or 0}
end

