RFF_BusinessAdministrationService = {}
RFF_BusinessAdministrationService.__index = RFF_BusinessAdministrationService

RFF_BusinessAdministrationService.INSURANCE_BASIC = "BASIC"
RFF_BusinessAdministrationService.INSURANCE_STANDARD = "STANDARD"
RFF_BusinessAdministrationService.INSURANCE_COMPREHENSIVE = "COMPREHENSIVE"
RFF_BusinessAdministrationService.INSURANCE_TIERS = {
    {id = RFF_BusinessAdministrationService.INSURANCE_BASIC, key = "rff_insurance_basic", multiplier = 0.75},
    {id = RFF_BusinessAdministrationService.INSURANCE_STANDARD, key = "rff_insurance_standard", multiplier = 1.00},
    {id = RFF_BusinessAdministrationService.INSURANCE_COMPREHENSIVE, key = "rff_insurance_comprehensive", multiplier = 1.55}
}

RFF_BusinessAdministrationService.INSURANCE_TERM_PERIODS = 12
RFF_BusinessAdministrationService.INSURANCE_GRACE_PERIODS = 1
RFF_BusinessAdministrationService.ADMIN_LATE_FEE_RATE = 0.01
RFF_BusinessAdministrationService.ANNUAL_FILING_PERIOD = 2 -- April in the base-game period calendar (March = 1)

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local function isManagedFarmFacility(placeable)
    if placeable == nil then return false end
    local typeName = string.lower(tostring(placeable.typeName or ""))
    local configName = string.lower(tostring(placeable.configFileName or ""))
    local looksLikeFence = typeName:find("fence", 1, true) ~= nil or typeName:find("gate", 1, true) ~= nil
        or configName:find("fence", 1, true) ~= nil or configName:find("gate", 1, true) ~= nil
    if placeable.spec_fence ~= nil or placeable.spec_fenceGate ~= nil or looksLikeFence then
        return false
    end

    local operationalSpecs = {
        "spec_farmhouse", "spec_husbandry", "spec_husbandryAnimals", "spec_silo", "spec_bunkerSilo",
        "spec_productionPoint", "spec_sellingStation", "spec_buyingStation", "spec_workshop",
        "spec_manureHeap", "spec_bga", "spec_storage"
    }
    for _, specName in ipairs(operationalSpecs) do
        if placeable[specName] ~= nil then return true end
    end

    -- Ordinary sheds/barns generally have upkeep even without a functional specialization.
    -- Decorative/fence-style placeables usually do not, so this provides a native-value
    -- fallback without maintaining a catalogue of every map/mod building type.
    if placeable.getDailyUpkeep ~= nil then
        local ok, upkeep = pcall(placeable.getDailyUpkeep, placeable)
        if ok and safeNumber(upkeep) > 0.001 then return true end
    end
    return false
end

local function getFarm(farmId)
    return g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
end

-- Business administration applies only to playable farms. GIANTS keeps a
-- spectator/system farm in farmIdToFarm; charging that farm creates ghost
-- arrears and, because it has no phone mailbox, can fall back to a global HUD
-- warning on a listen server.
local function isPlayableBusinessFarm(farmId, farm)
    if farmId == nil or farmId <= 0 or farm == nil then return false end
    if FarmManager ~= nil and FarmManager.SPECTATOR_FARM_ID ~= nil and farmId == FarmManager.SPECTATOR_FARM_ID then
        return false
    end
    if FarmlandManager ~= nil and FarmlandManager.NO_OWNER_FARM_ID ~= nil and farmId == FarmlandManager.NO_OWNER_FARM_ID then
        return false
    end
    if farm.isSpectator == true then return false end
    return true
end

local function otherMoneyType()
    if MoneyType ~= nil then return MoneyType.OTHER end
    return nil
end

function RFF_BusinessAdministrationService.new(repository, bankingService)
    local self = setmetatable({}, RFF_BusinessAdministrationService)
    self.repository = repository
    self.bankingService = bankingService
    return self
end

function RFF_BusinessAdministrationService:getTierConfig(tierId)
    for _, tier in ipairs(self.INSURANCE_TIERS) do
        if tier.id == tierId then return tier end
    end
    return self.INSURANCE_TIERS[2]
end

function RFF_BusinessAdministrationService:getFarmState(farmId, create)
    if self.repository == nil then return nil end
    local state = self.repository:getFarmState(farmId, create)
    if state == nil then return nil end

    local current = self.repository:getCurrentPeriodIndex()
    if state.adminLastProcessedPeriod == nil then state.adminLastProcessedPeriod = current end
    state.adminArrears = math.max(0, safeNumber(state.adminArrears))
    state.adminLastCharge = math.max(0, safeNumber(state.adminLastCharge))
    state.adminLastMonthlyCharge = math.max(0, safeNumber(state.adminLastMonthlyCharge))
    state.adminLastAnnualFilingCharge = math.max(0, safeNumber(state.adminLastAnnualFilingCharge))
    state.adminTotalPaid = math.max(0, safeNumber(state.adminTotalPaid))
    state.adminMissedPayments = math.max(0, math.floor(safeNumber(state.adminMissedPayments)))
    if state.adminLastAnnualFilingYear == nil then state.adminLastAnnualFilingYear = -1 end
    state.adminLastAnnualFilingYear = math.floor(safeNumber(state.adminLastAnnualFilingYear))
    state.adminLastLateFee = math.max(0, safeNumber(state.adminLastLateFee))

    state.insuranceTier = state.insuranceTier or self.INSURANCE_STANDARD
    state.insuranceNextTier = state.insuranceNextTier or state.insuranceTier
    state.insuranceStatus = state.insuranceStatus or "ACTIVE"
    if state.insuranceNextRenewalPeriod == nil or state.insuranceNextRenewalPeriod <= 0 then
        state.insuranceNextRenewalPeriod = current + 1
    end
    state.insurancePremiumDue = math.max(0, safeNumber(state.insurancePremiumDue))
    state.insuranceLastPremium = math.max(0, safeNumber(state.insuranceLastPremium))
    state.insuranceLastValuation = math.max(0, safeNumber(state.insuranceLastValuation))
    state.insuranceLastRenewalPeriod = math.floor(safeNumber(state.insuranceLastRenewalPeriod))
    state.insuranceGraceUntilPeriod = math.floor(safeNumber(state.insuranceGraceUntilPeriod))
    state.insuranceTotalPaid = math.max(0, safeNumber(state.insuranceTotalPaid))
    state.insuranceMissedPremiums = math.max(0, math.floor(safeNumber(state.insuranceMissedPremiums)))
    state.insuranceRenewalNoticePeriod = math.floor(safeNumber(state.insuranceRenewalNoticePeriod))

    -- v1.1.13.1 separates vehicle cover from the existing business policy. Existing
    -- saves inherit their current cover and renewal date once, but no outstanding
    -- legacy premium is duplicated across the two policies.
    if state.vehicleInsuranceMigrated ~= true then
        state.vehicleInsuranceTier = state.insuranceTier
        state.vehicleInsuranceNextTier = state.insuranceNextTier
        state.vehicleInsuranceStatus = state.insuranceStatus
        state.vehicleInsuranceNextRenewalPeriod = math.max(current + 1, state.insuranceNextRenewalPeriod or current + 1)
        state.vehicleInsurancePremiumDue = 0
        state.vehicleInsuranceLastPremium = 0
        state.vehicleInsuranceLastValuation = 0
        state.vehicleInsuranceLastRenewalPeriod = state.insuranceLastRenewalPeriod
        state.vehicleInsuranceGraceUntilPeriod = 0
        state.vehicleInsuranceTotalPaid = 0
        state.vehicleInsuranceMissedPremiums = state.insuranceMissedPremiums
        state.vehicleInsuranceRenewalNoticePeriod = 0
        state.vehicleInsuranceMigrated = true
    end
    state.vehicleInsuranceTier = state.vehicleInsuranceTier or self.INSURANCE_STANDARD
    state.vehicleInsuranceNextTier = state.vehicleInsuranceNextTier or state.vehicleInsuranceTier
    state.vehicleInsuranceStatus = state.vehicleInsuranceStatus or "ACTIVE"
    if state.vehicleInsuranceNextRenewalPeriod == nil or state.vehicleInsuranceNextRenewalPeriod <= 0 then
        state.vehicleInsuranceNextRenewalPeriod = current + 1
    end
    state.vehicleInsurancePremiumDue = math.max(0, safeNumber(state.vehicleInsurancePremiumDue))
    state.vehicleInsuranceLastPremium = math.max(0, safeNumber(state.vehicleInsuranceLastPremium))
    state.vehicleInsuranceLastValuation = math.max(0, safeNumber(state.vehicleInsuranceLastValuation))
    state.vehicleInsuranceLastRenewalPeriod = math.floor(safeNumber(state.vehicleInsuranceLastRenewalPeriod))
    state.vehicleInsuranceGraceUntilPeriod = math.floor(safeNumber(state.vehicleInsuranceGraceUntilPeriod))
    state.vehicleInsuranceTotalPaid = math.max(0, safeNumber(state.vehicleInsuranceTotalPaid))
    state.vehicleInsuranceMissedPremiums = math.max(0, math.floor(safeNumber(state.vehicleInsuranceMissedPremiums)))
    state.vehicleInsuranceRenewalNoticePeriod = math.floor(safeNumber(state.vehicleInsuranceRenewalNoticePeriod))
    return state
end

function RFF_BusinessAdministrationService:getOwnedCounts(farmId)
    local counts = {farmland=0, placeables=0, rawPlaceables=0, excludedPlaceables=0, vehicles=0, loans=0, tenancies=0, assetFinance=0}
    if g_farmlandManager ~= nil then
        for _, farmland in pairs(g_farmlandManager:getFarmlands() or {}) do
            if g_farmlandManager:getFarmlandOwner(farmland.id) == farmId then counts.farmland = counts.farmland + 1 end
        end
    end
    local placeableSystem = g_currentMission ~= nil and g_currentMission.placeableSystem or nil
    if placeableSystem ~= nil then
        for _, placeable in pairs(placeableSystem.placeables or {}) do
            if placeable ~= nil then
                local ownerFarmId = placeable.getOwnerFarmId ~= nil and placeable:getOwnerFarmId() or placeable.ownerFarmId
                if ownerFarmId == farmId then
                    counts.rawPlaceables = counts.rawPlaceables + 1
                    if isManagedFarmFacility(placeable) then
                        counts.placeables = counts.placeables + 1
                    else
                        counts.excludedPlaceables = counts.excludedPlaceables + 1
                    end
                end
            end
        end
    end
    local vehicleSystem = g_currentMission ~= nil and g_currentMission.vehicleSystem or nil
    if vehicleSystem ~= nil then
        for _, vehicle in pairs(vehicleSystem.vehicles or {}) do
            if vehicle ~= nil then
                local ownerFarmId = vehicle.getOwnerFarmId ~= nil and vehicle:getOwnerFarmId() or vehicle.ownerFarmId
                if ownerFarmId == farmId then
                    local typeName = vehicle.typeName or ""
                if typeName ~= "pallet" and typeName ~= "treeSaplingPallet" and typeName ~= "bigBag" then counts.vehicles = counts.vehicles + 1 end
                end
            end
        end
    end
    if self.repository ~= nil then
        counts.loans = #(self.repository:getLoansByFarm(farmId, true) or {})
        counts.tenancies = #(self.repository:getTenanciesByFarm(farmId, true) or {})
        counts.assetFinance = #(self.repository:getAssetFinanceByFarm(farmId, true) or {})
    end
    return counts
end

function RFF_BusinessAdministrationService:calculateMonthlyAdminCost(farmId)
    local counts = self:getOwnedCounts(farmId)
    local cost = 95
        + counts.farmland * 12
        + counts.placeables * 5
        + counts.vehicles * 4
        + counts.loans * 10
        + counts.tenancies * 8
        + counts.assetFinance * 8
    return math.floor(math.max(95, math.min(1500, cost)) + 0.5), counts
end

function RFF_BusinessAdministrationService:calculateAnnualFilingCost(farmId)
    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local cost = 350 + math.max(0, safeNumber(valuation.totalAssets)) * 0.00030
    return math.floor(math.max(350, math.min(3000, cost)) + 0.5), valuation
end

function RFF_BusinessAdministrationService:calculateInsurancePremium(farmId, tierId)
    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local insurable = math.max(0, safeNumber(valuation.buildings))
        + math.max(0, safeNumber(valuation.livestock))
        + math.max(0, safeNumber(valuation.inventory))
    local basePremium = 180
        + math.max(0, safeNumber(valuation.buildings)) * 0.0035
        + math.max(0, safeNumber(valuation.livestock)) * 0.0060
        + math.max(0, safeNumber(valuation.inventory)) * 0.0025
    local tier = self:getTierConfig(tierId)
    local premium = math.floor(math.max(200, basePremium * (tier.multiplier or 1)) + 0.5)
    return premium, insurable, valuation
end

function RFF_BusinessAdministrationService:getVehicleInsuranceValue(farmId)
    local total = 0
    local vehicleSystem = g_currentMission ~= nil and g_currentMission.vehicleSystem or nil
    if vehicleSystem == nil then return total end
    local ownedState = VehiclePropertyState ~= nil and VehiclePropertyState.OWNED or 2
    for _, vehicle in ipairs(vehicleSystem.vehicles or {}) do
        local ownerFarmId = vehicle.getOwnerFarmId ~= nil and vehicle:getOwnerFarmId() or vehicle.ownerFarmId
        local agreement = self.repository ~= nil and self.repository:getAssetFinanceByVehicle(tostring(vehicle.uniqueId or ""), true) or nil
        local operatingLease = agreement ~= nil and agreement.product == "OPERATING_LEASE"
        local financedAsset = agreement ~= nil and not operatingLease
        local owned = vehicle.propertyState == nil or vehicle.propertyState == ownedState
        if vehicle.spec_drivable ~= nil and ownerFarmId == farmId and (owned or financedAsset) and not operatingLease and vehicle.getSellPrice ~= nil then
            local ok, value = pcall(vehicle.getSellPrice, vehicle)
            if ok then total = total + math.max(0, safeNumber(value)) end
        end
    end
    return total
end

function RFF_BusinessAdministrationService:calculateVehicleInsurancePremium(farmId, tierId)
    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local insurable = self:getVehicleInsuranceValue(farmId)
    local basePremium = 60 + insurable * 0.0050
    local tier = self:getTierConfig(tierId)
    local premium = math.floor(math.max(100, basePremium * (tier.multiplier or 1)) + 0.5)
    return premium, insurable, valuation
end

function RFF_BusinessAdministrationService:getAvailableFunds(farmId)
    if self.bankingService ~= nil and self.bankingService.getAvailableFunds ~= nil then
        return self.bankingService:getAvailableFunds(farmId)
    end
    local farm = getFarm(farmId)
    return farm ~= nil and safeNumber(farm.money) or 0
end

function RFF_BusinessAdministrationService:recordRedTapeDeductibleExpense(farmId, amount)
    if amount == nil or amount <= 0 or g_currentMission == nil then return end
    local rt = g_currentMission.RedTape
    if rt == nil or rt.TaxSystem == nil or rt.settings == nil or rt.settings.taxEnabled ~= true then return end
    if RTTaxLineItem == nil or RTNewTaxLineItemEvent == nil then return end
    local lineItem = RTTaxLineItem.new()
    lineItem.amount = -math.floor(amount + 0.5)
    lineItem.statistic = "other"
    if g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(RTNewTaxLineItemEvent.new(farmId, lineItem))
    elseif g_currentMission:getIsServer() then
        rt.TaxSystem:recordLineItem(farmId, lineItem)
        if g_server ~= nil then g_server:broadcastEvent(RTNewTaxLineItemEvent.new(farmId, lineItem), false) end
    end
end

function RFF_BusinessAdministrationService:charge(farmId, amount, description)
    amount = math.max(0, safeNumber(amount))
    if amount <= 0 or g_currentMission == nil then return true end
    if self:getAvailableFunds(farmId) + 0.001 < amount then return false end
    if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then
        self.repository:setNextTransactionDescription(farmId, description)
    end
    g_currentMission:addMoney(-amount, farmId, otherMoneyType(), true, true)
    self:recordRedTapeDeductibleExpense(farmId, amount)
    return true
end

function RFF_BusinessAdministrationService:notify(farmId, titleKey, fallbackTitle, textKey, fallbackText, ...)
    if RFF_NotificationService == nil then return false end
    local args = {...}
    local message = RFF_NotificationService:formatText(textKey, fallbackText, unpack(args))
    local sender = RFF_NotificationService:getText("rff_phone_sender_business", "Farm Business Office")
    local title = RFF_NotificationService:getText(titleKey, fallbackTitle)
    return RFF_NotificationService:send(farmId, sender, title, message, "administration", message, true)
end

function RFF_BusinessAdministrationService:processAdministration(farmId, current)
    local state = self:getFarmState(farmId, true)
    if state == nil then return end
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    local monthlyCost = self:calculateMonthlyAdminCost(farmId)
    local annualCost = 0
    local currentYear = env ~= nil and (env.currentYear or 0) or 0
    local currentPeriod = env ~= nil and (env.currentPeriod or 0) or 0
    if currentPeriod == self.ANNUAL_FILING_PERIOD and state.adminLastAnnualFilingYear ~= currentYear then
        annualCost = self:calculateAnnualFilingCost(farmId)
        state.adminLastAnnualFilingYear = currentYear
        state.adminLastAnnualFilingCharge = annualCost
    end

    local lateFee = 0
    if state.adminArrears > 0.01 then
        lateFee = math.floor(state.adminArrears * self.ADMIN_LATE_FEE_RATE + 0.5)
        state.adminArrears = state.adminArrears + lateFee
    end

    local invoice = monthlyCost + annualCost
    local totalDue = state.adminArrears + invoice
    state.adminLastMonthlyCharge = monthlyCost
    state.adminLastCharge = invoice
    state.adminLastLateFee = lateFee

    if totalDue <= 0.01 then return end
    if self:charge(farmId, totalDue, annualCost > 0 and "Farm administration, accounts & annual filing" or "Farm administration & compliance") then
        state.adminTotalPaid = state.adminTotalPaid + totalDue
        local paidArrears = state.adminArrears > 0.01
        state.adminArrears = 0
        if paidArrears then
            self:notify(farmId, "rff_phone_title_admin", "Farm Administration", "rff_admin_arrears_cleared_phone", "Outstanding farm administration costs of %s have been collected.", g_i18n:formatMoney(totalDue, 0, true, true))
        end
    else
        state.adminArrears = totalDue
        state.adminMissedPayments = state.adminMissedPayments + 1
        self:notify(farmId, "rff_phone_title_admin", "Farm Administration", "rff_admin_payment_overdue_phone", "Farm administration costs of %s could not be collected and are now overdue.", g_i18n:formatMoney(totalDue, 0, true, true))
    end
end

function RFF_BusinessAdministrationService:issueInsuranceRenewal(farmId, current, force)
    local state = self:getFarmState(farmId, true)
    if state == nil then return false, "state" end
    if not force and current < state.insuranceNextRenewalPeriod then return false, "not_due" end
    local tierId = state.insuranceNextTier or state.insuranceTier or self.INSURANCE_STANDARD
    local premium, insurable = self:calculateInsurancePremium(farmId, tierId)
    state.insurancePremiumDue = premium
    state.insuranceLastValuation = insurable
    state.insuranceGraceUntilPeriod = current + self.INSURANCE_GRACE_PERIODS

    if self:charge(farmId, premium, "Annual business insurance premium") then
        state.insuranceTier = tierId
        state.insuranceStatus = "ACTIVE"
        state.insuranceLastPremium = premium
        state.insuranceLastRenewalPeriod = current
        state.insuranceNextRenewalPeriod = current + self.INSURANCE_TERM_PERIODS
        state.insurancePremiumDue = 0
        state.insuranceGraceUntilPeriod = 0
        state.insuranceTotalPaid = state.insuranceTotalPaid + premium
        state.insuranceRenewalNoticePeriod = 0
        self:notify(farmId, "rff_phone_title_insurance", "Business Insurance", "rff_insurance_renewed_phone", "Your business insurance has renewed for 12 months. Premium paid: %s.", g_i18n:formatMoney(premium, 0, true, true))
        return true, "paid"
    end

    state.insuranceStatus = "GRACE"
    state.insuranceMissedPremiums = state.insuranceMissedPremiums + 1
    state.insuranceNextRenewalPeriod = current
    self:notify(farmId, "rff_phone_title_insurance", "Business Insurance", "rff_insurance_grace_phone", "Your annual business insurance premium of %s could not be collected. Cover remains in force for one further month while payment is outstanding.", g_i18n:formatMoney(premium, 0, true, true))
    return false, "funds"
end

function RFF_BusinessAdministrationService:processInsurance(farmId, current)
    local state = self:getFarmState(farmId, true)
    if state == nil then return end

    if state.insurancePremiumDue > 0.01 then
        if self:charge(farmId, state.insurancePremiumDue, "Outstanding business insurance premium") then
            local premium = state.insurancePremiumDue
            state.insurancePremiumDue = 0
            state.insuranceTier = state.insuranceNextTier or state.insuranceTier
            state.insuranceStatus = "ACTIVE"
            state.insuranceLastPremium = premium
            state.insuranceLastRenewalPeriod = current
            state.insuranceNextRenewalPeriod = current + self.INSURANCE_TERM_PERIODS
            state.insuranceGraceUntilPeriod = 0
            state.insuranceTotalPaid = state.insuranceTotalPaid + premium
            state.insuranceRenewalNoticePeriod = 0
            self:notify(farmId, "rff_phone_title_insurance", "Business Insurance", "rff_insurance_reinstated_phone", "Your outstanding business insurance premium of %s has been paid and cover is active.", g_i18n:formatMoney(premium, 0, true, true))
            return
        end
        if state.insuranceStatus == "GRACE" and current > state.insuranceGraceUntilPeriod then
            state.insuranceStatus = "LAPSED"
            self:notify(farmId, "rff_phone_title_insurance", "Business Insurance", "rff_insurance_lapsed_phone", "Your business insurance has lapsed because the renewal premium remains unpaid. The outstanding premium must be paid before cover can be reinstated.")
        end
        return
    end

    local monthsUntil = state.insuranceNextRenewalPeriod - current
    if monthsUntil == 1 and state.insuranceRenewalNoticePeriod ~= current then
        local premium = self:calculateInsurancePremium(farmId, state.insuranceNextTier or state.insuranceTier)
        state.insuranceRenewalNoticePeriod = current
        self:notify(farmId, "rff_phone_title_insurance", "Business Insurance", "rff_insurance_renewal_notice_phone", "Your business insurance renews next month. The current estimated annual premium is %s.", g_i18n:formatMoney(premium, 0, true, true))
    elseif monthsUntil <= 0 then
        self:issueInsuranceRenewal(farmId, current, false)
    end
end

function RFF_BusinessAdministrationService:issueVehicleInsuranceRenewal(farmId, current, force)
    local state = self:getFarmState(farmId, true)
    if state == nil then return false, "state" end
    if not force and current < state.vehicleInsuranceNextRenewalPeriod then return false, "not_due" end
    local tierId = state.vehicleInsuranceNextTier or state.vehicleInsuranceTier or self.INSURANCE_STANDARD
    local premium, insurable = self:calculateVehicleInsurancePremium(farmId, tierId)
    state.vehicleInsurancePremiumDue = premium
    state.vehicleInsuranceLastValuation = insurable
    state.vehicleInsuranceGraceUntilPeriod = current + self.INSURANCE_GRACE_PERIODS

    if self:charge(farmId, premium, "Annual vehicle insurance premium") then
        state.vehicleInsuranceTier = tierId
        state.vehicleInsuranceStatus = "ACTIVE"
        state.vehicleInsuranceLastPremium = premium
        state.vehicleInsuranceLastRenewalPeriod = current
        state.vehicleInsuranceNextRenewalPeriod = current + self.INSURANCE_TERM_PERIODS
        state.vehicleInsurancePremiumDue = 0
        state.vehicleInsuranceGraceUntilPeriod = 0
        state.vehicleInsuranceTotalPaid = state.vehicleInsuranceTotalPaid + premium
        state.vehicleInsuranceRenewalNoticePeriod = 0
        self:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_insurance_renewed_phone", "Your vehicle insurance has renewed for 12 months. Premium paid: %s.", g_i18n:formatMoney(premium, 0, true, true))
        return true, "paid"
    end

    state.vehicleInsuranceStatus = "GRACE"
    state.vehicleInsuranceMissedPremiums = state.vehicleInsuranceMissedPremiums + 1
    state.vehicleInsuranceNextRenewalPeriod = current
    self:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_insurance_grace_phone", "Your annual vehicle insurance premium of %s could not be collected. Cover remains in force for one further month while payment is outstanding.", g_i18n:formatMoney(premium, 0, true, true))
    return false, "funds"
end

function RFF_BusinessAdministrationService:processVehicleInsurance(farmId, current)
    local state = self:getFarmState(farmId, true)
    if state == nil then return end

    if state.vehicleInsurancePremiumDue > 0.01 then
        if self:charge(farmId, state.vehicleInsurancePremiumDue, "Outstanding vehicle insurance premium") then
            local premium = state.vehicleInsurancePremiumDue
            state.vehicleInsurancePremiumDue = 0
            state.vehicleInsuranceTier = state.vehicleInsuranceNextTier or state.vehicleInsuranceTier
            state.vehicleInsuranceStatus = "ACTIVE"
            state.vehicleInsuranceLastPremium = premium
            state.vehicleInsuranceLastRenewalPeriod = current
            state.vehicleInsuranceNextRenewalPeriod = current + self.INSURANCE_TERM_PERIODS
            state.vehicleInsuranceGraceUntilPeriod = 0
            state.vehicleInsuranceTotalPaid = state.vehicleInsuranceTotalPaid + premium
            state.vehicleInsuranceRenewalNoticePeriod = 0
            self:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_insurance_reinstated_phone", "Your outstanding vehicle insurance premium of %s has been paid and cover is active.", g_i18n:formatMoney(premium, 0, true, true))
            return
        end
        if state.vehicleInsuranceStatus == "GRACE" and current > state.vehicleInsuranceGraceUntilPeriod then
            state.vehicleInsuranceStatus = "LAPSED"
            self:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_insurance_lapsed_phone", "Your vehicle insurance has lapsed because the renewal premium remains unpaid. The outstanding premium must be paid before cover can be reinstated.")
        end
        return
    end

    local monthsUntil = state.vehicleInsuranceNextRenewalPeriod - current
    if monthsUntil == 1 and state.vehicleInsuranceRenewalNoticePeriod ~= current then
        local premium = self:calculateVehicleInsurancePremium(farmId, state.vehicleInsuranceNextTier or state.vehicleInsuranceTier)
        state.vehicleInsuranceRenewalNoticePeriod = current
        self:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_insurance_renewal_notice_phone", "Your vehicle insurance renews next month. The current estimated annual premium is %s.", g_i18n:formatMoney(premium, 0, true, true))
    elseif monthsUntil <= 0 then
        self:issueVehicleInsuranceRenewal(farmId, current, false)
    end
end

function RFF_BusinessAdministrationService:onLoaded()
    if g_currentMission == nil or self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if isPlayableBusinessFarm(farmId, farm) then
            local state = self:getFarmState(farmId, true)
            if state ~= nil and state.adminLastProcessedPeriod == nil then state.adminLastProcessedPeriod = current end
        end
    end
end

function RFF_BusinessAdministrationService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if isPlayableBusinessFarm(farmId, farm) then
            local state = self:getFarmState(farmId, true)
            if state ~= nil and current > (state.adminLastProcessedPeriod or current) then
                self:processAdministration(farmId, current)
                self:processInsurance(farmId, current)
                state.adminLastProcessedPeriod = current
            end
        end
    end
end

function RFF_BusinessAdministrationService:setInsuranceNextTier(farmId, tierId)
    local tier = self:getTierConfig(tierId)
    if tier == nil then return false end
    local state = self:getFarmState(farmId, true)
    if state == nil then return false end
    state.insuranceNextTier = tier.id
    return true
end

function RFF_BusinessAdministrationService:setVehicleInsuranceNextTier(farmId, tierId)
    local tier = self:getTierConfig(tierId)
    if tier == nil then return false end
    local state = self:getFarmState(farmId, true)
    if state == nil then return false end
    state.vehicleInsuranceNextTier = tier.id
    return true
end

function RFF_BusinessAdministrationService:payInsurancePremium(farmId)
    local state = self:getFarmState(farmId, true)
    if state == nil or state.insurancePremiumDue <= 0.01 then return false, "nothing_due" end
    local premium = state.insurancePremiumDue
    if not self:charge(farmId, premium, "Outstanding business insurance premium") then return false, "funds" end
    local current = self.repository:getCurrentPeriodIndex()
    state.insurancePremiumDue = 0
    state.insuranceTier = state.insuranceNextTier or state.insuranceTier
    state.insuranceStatus = "ACTIVE"
    state.insuranceLastPremium = premium
    state.insuranceLastRenewalPeriod = current
    state.insuranceNextRenewalPeriod = current + self.INSURANCE_TERM_PERIODS
    state.insuranceGraceUntilPeriod = 0
    state.insuranceTotalPaid = state.insuranceTotalPaid + premium
    state.insuranceRenewalNoticePeriod = 0
    self:notify(farmId, "rff_phone_title_insurance", "Business Insurance", "rff_insurance_reinstated_phone", "Your outstanding business insurance premium of %s has been paid and cover is active.", g_i18n:formatMoney(premium, 0, true, true))
    return true, "paid"
end

function RFF_BusinessAdministrationService:payVehicleInsurancePremium(farmId)
    local state = self:getFarmState(farmId, true)
    if state == nil or state.vehicleInsurancePremiumDue <= 0.01 then return false, "nothing_due" end
    local premium = state.vehicleInsurancePremiumDue
    if not self:charge(farmId, premium, "Outstanding vehicle insurance premium") then return false, "funds" end
    local current = self.repository:getCurrentPeriodIndex()
    state.vehicleInsurancePremiumDue = 0
    state.vehicleInsuranceTier = state.vehicleInsuranceNextTier or state.vehicleInsuranceTier
    state.vehicleInsuranceStatus = "ACTIVE"
    state.vehicleInsuranceLastPremium = premium
    state.vehicleInsuranceLastRenewalPeriod = current
    state.vehicleInsuranceNextRenewalPeriod = current + self.INSURANCE_TERM_PERIODS
    state.vehicleInsuranceGraceUntilPeriod = 0
    state.vehicleInsuranceTotalPaid = state.vehicleInsuranceTotalPaid + premium
    state.vehicleInsuranceRenewalNoticePeriod = 0
    self:notify(farmId, "rff_phone_title_vehicle_insurance", "Vehicle Insurance", "rff_vehicle_insurance_reinstated_phone", "Your outstanding vehicle insurance premium of %s has been paid and cover is active.", g_i18n:formatMoney(premium, 0, true, true))
    return true, "paid"
end

function RFF_BusinessAdministrationService:getTaxSummary(farmId)
    local result = {
        available = false,
        enabled = false,
        source = "NONE",
        currentTaxableIncome = 0,
        currentExpenses = 0,
        currentTaxedIncome = 0,
        currentTax = 0,
        taxRate = 0,
        lossRollover = 0,
        lastTax = 0,
        lastPaid = false,
        lastAssessmentExists = false,
        calculationMonth = "-",
        paymentMonth = "-"
    }

    local rt = g_currentMission ~= nil and g_currentMission.RedTape or nil
    local taxSystem = rt ~= nil and rt.TaxSystem or nil
    if taxSystem == nil then return result end
    result.available = true
    result.source = "RED_TAPE"
    result.enabled = rt.settings ~= nil and rt.settings.taxEnabled == true
    if not result.enabled then return result end

    if taxSystem.getCurrentYearTaxToDate ~= nil then
        local ok, statement = pcall(taxSystem.getCurrentYearTaxToDate, taxSystem, farmId)
        if ok and statement ~= nil then
            result.currentTaxableIncome = safeNumber(statement.totalTaxableIncome)
            result.currentExpenses = safeNumber(statement.totalExpenses)
            result.currentTaxedIncome = safeNumber(statement.totalTaxedIncome)
            result.currentTax = safeNumber(statement.totalTax)
            result.taxRate = safeNumber(statement.taxRate)
        end
    end
    result.lossRollover = math.max(0, safeNumber(taxSystem.lossRollover ~= nil and taxSystem.lossRollover[farmId] or 0))

    local latest = nil
    for _, statement in pairs(taxSystem.taxStatements or {}) do
        if statement ~= nil and statement.farmId == farmId then
            if latest == nil or safeNumber(statement.month) > safeNumber(latest.month) then latest = statement end
        end
    end
    if latest ~= nil then
        result.lastAssessmentExists = true
        result.lastTax = safeNumber(latest.totalTax)
        result.lastPaid = latest.paid == true
    end

    if RedTape ~= nil and RedTape.monthToString ~= nil and RTTaxSystem ~= nil then
        result.calculationMonth = RedTape.monthToString(RTTaxSystem.TAX_CALCULATION_MONTH)
        result.paymentMonth = RedTape.monthToString(RTTaxSystem.TAX_PAYMENT_MONTH)
    end
    return result
end

function RFF_BusinessAdministrationService:getSummary(farmId)
    local state = self:getFarmState(farmId, true)
    local monthlyCost, counts = self:calculateMonthlyAdminCost(farmId)
    local filingCost = self:calculateAnnualFilingCost(farmId)
    local premiumEstimate, insurableValue = self:calculateInsurancePremium(farmId, state.insuranceNextTier or state.insuranceTier)
    local vehiclePremiumEstimate, vehicleInsurableValue = self:calculateVehicleInsurancePremium(farmId, state.vehicleInsuranceNextTier or state.vehicleInsuranceTier)
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    return {
        state = state,
        counts = counts,
        monthlyAdminCost = monthlyCost,
        annualFilingEstimate = filingCost,
        adminArrears = state.adminArrears,
        insuranceTier = state.insuranceTier,
        insuranceNextTier = state.insuranceNextTier,
        insuranceStatus = state.insuranceStatus,
        insurancePremiumEstimate = premiumEstimate,
        insurancePremiumDue = state.insurancePremiumDue,
        insuranceInsurableValue = insurableValue,
        insuranceMonthsToRenewal = math.max(0, (state.insuranceNextRenewalPeriod or current) - current),
        vehicleInsuranceTier = state.vehicleInsuranceTier,
        vehicleInsuranceNextTier = state.vehicleInsuranceNextTier,
        vehicleInsuranceStatus = state.vehicleInsuranceStatus,
        vehicleInsurancePremiumEstimate = vehiclePremiumEstimate,
        vehicleInsurancePremiumDue = state.vehicleInsurancePremiumDue,
        vehicleInsuranceInsurableValue = vehicleInsurableValue,
        vehicleInsuranceMonthsToRenewal = math.max(0, (state.vehicleInsuranceNextRenewalPeriod or current) - current),
        outstandingLiabilities = self.repository ~= nil and self.repository:getOutstandingBusinessObligations(farmId) or (math.max(0, state.adminArrears) + math.max(0, state.insurancePremiumDue) + math.max(0, state.vehicleInsurancePremiumDue)),
        tax = self:getTaxSummary(farmId)
    }
end

function RFF_BusinessAdministrationService:forceInsuranceRenewalForTest(farmId)
    local state = self:getFarmState(farmId, true)
    if state == nil then return false, "state" end
    local current = self.repository:getCurrentPeriodIndex()
    state.insuranceNextRenewalPeriod = current
    state.insuranceRenewalNoticePeriod = 0
    return self:issueInsuranceRenewal(farmId, current, true)
end
