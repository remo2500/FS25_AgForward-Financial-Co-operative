-- Read-only cross-mod insurance/mortality history API.
-- RFF remains authoritative for the underlying financial records. Consumers receive
-- copied primitive snapshots only and cannot mutate repository state through this API.
RFF_InsuranceHistoryAPI = RFF_InsuranceHistoryAPI or {}
RFF_InsuranceHistoryAPI.API_VERSION = 1

local globalRoot = _G
local globalMeta = getmetatable(_G)
if globalMeta ~= nil and type(globalMeta.__index) == "table" then
    globalRoot = globalMeta.__index
end
globalRoot.RFF_InsuranceHistoryAPI = RFF_InsuranceHistoryAPI

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local function getManager()
    local mission = g_currentMission
    if mission == nil then return nil end
    return mission.realisticFarmFinance
end

local function getRepository()
    local manager = getManager()
    return manager ~= nil and manager.repository or nil
end

local function isServerAuthority()
    if g_currentMission == nil then return false end
    if g_currentMission.getIsServer ~= nil then return g_currentMission:getIsServer() end
    return g_server ~= nil
end

local function validFarmId(farmId)
    return type(farmId) == "number" and farmId > 0
end

local function normaliseWindow(lookbackPeriods)
    if lookbackPeriods == nil then return nil end
    local value = math.floor(safeNumber(lookbackPeriods))
    if value <= 0 then return nil end
    return value
end

local function getCurrentPeriodIndex()
    local repository = getRepository()
    if repository ~= nil and repository.getCurrentPeriodIndex ~= nil then
        return repository:getCurrentPeriodIndex()
    end
    local environment = g_currentMission ~= nil and g_currentMission.environment or nil
    if environment == nil then return 0 end
    return (environment.currentYear or 0) * 12 + (environment.currentPeriod or 0)
end

-- A lookback of 1 means the current game period only; 2 means current + previous,
-- and so on. Nil/zero means all persisted history. Future-dated records are excluded.
local function isInsideWindow(incidentPeriod, lookbackPeriods)
    local window = normaliseWindow(lookbackPeriods)
    if window == nil then return true end
    local currentPeriod = getCurrentPeriodIndex()
    local period = math.floor(safeNumber(incidentPeriod))
    local firstPeriod = currentPeriod - window + 1
    return period >= firstPeriod and period <= currentPeriod
end

local function copyMortalityRecord(loss)
    return {
        recordType = "MORTALITY",
        id = loss.id or 0,
        reference = string.format("LOSS-%04d", loss.id or 0),
        farmId = loss.farmId or 0,
        source = tostring(loss.source or ""),
        status = tostring(loss.status or "RECORDED"),
        incidentDay = loss.incidentDay or 0,
        incidentPeriod = loss.incidentPeriod or 0,
        deadlinePeriod = loss.deadlinePeriod or 0,
        claimId = loss.claimId or 0,
        claimSubmitted = (loss.claimId or 0) > 0,
        policyTier = tostring(loss.policyTier or ""),
        policyStatusAtIncident = tostring(loss.policyStatusAtIncident or ""),
        animalUniqueId = tostring(loss.animalUniqueId or ""),
        animalType = tostring(loss.animalType or "UNKNOWN"),
        animalBreed = tostring(loss.animalBreed or ""),
        animalSubType = tostring(loss.animalSubType or ""),
        animalAge = loss.animalAge or 0,
        animalHealth = safeNumber(loss.animalHealth),
        deathReason = tostring(loss.deathReason or "UNKNOWN"),
        incidentValue = math.max(0, safeNumber(loss.incidentValue))
    }
end

local function copyClaimRecord(claim)
    return {
        recordType = "INSURANCE_CLAIM",
        id = claim.id or 0,
        reference = string.format("AM-%04d", claim.id or 0),
        farmId = claim.farmId or 0,
        insurerId = tostring(claim.insurerId or "AGRICULTURAL_MUTUAL"),
        source = tostring(claim.source or ""),
        claimType = tostring(claim.claimType or "MORTALITY"),
        status = tostring(claim.status or "UNDER_REVIEW"),
        lossId = claim.lossId or 0,
        incidentDay = claim.incidentDay or 0,
        incidentPeriod = claim.incidentPeriod or 0,
        submittedDay = claim.submittedDay or 0,
        decisionDay = claim.decisionDay or 0,
        approvedDay = claim.approvedDay or 0,
        paidDay = claim.paidDay or 0,
        policyTier = tostring(claim.policyTier or ""),
        policyStatusAtIncident = tostring(claim.policyStatusAtIncident or ""),
        animalUniqueId = tostring(claim.animalUniqueId or ""),
        animalType = tostring(claim.animalType or "UNKNOWN"),
        animalBreed = tostring(claim.animalBreed or ""),
        animalSubType = tostring(claim.animalSubType or ""),
        animalAge = claim.animalAge or 0,
        animalHealth = safeNumber(claim.animalHealth),
        deathReason = tostring(claim.deathReason or "UNKNOWN"),
        incidentValue = math.max(0, safeNumber(claim.incidentValue)),
        amountClaimed = math.max(0, safeNumber(claim.amountClaimed or claim.incidentValue)),
        approvedAmount = math.max(0, safeNumber(claim.approvedAmount)),
        paidAmount = math.max(0, safeNumber(claim.paidAmount)),
        outcomeReason = tostring(claim.outcomeReason or ""),
        treatmentDetails = tostring(claim.treatmentDetails or "")
    }
end

local function sortNewestFirst(records)
    table.sort(records, function(a, b)
        if (a.incidentPeriod or 0) == (b.incidentPeriod or 0) then
            if (a.incidentDay or 0) == (b.incidentDay or 0) then return (a.id or 0) > (b.id or 0) end
            return (a.incidentDay or 0) > (b.incidentDay or 0)
        end
        return (a.incidentPeriod or 0) > (b.incidentPeriod or 0)
    end)
end

function RFF_InsuranceHistoryAPI:getApiVersion()
    return self.API_VERSION
end

function RFF_InsuranceHistoryAPI:getCapabilities()
    return {
        apiVersion = self.API_VERSION,
        readOnly = true,
        serverAuthoritative = true,
        mortalityHistory = true,
        insuranceClaimHistory = true,
        veterinaryClaims = true,
        mutableRecordsExposed = false,
        windowBasis = "incidentPeriod"
    }
end

function RFF_InsuranceHistoryAPI:getCurrentPeriod()
    return getCurrentPeriodIndex()
end

function RFF_InsuranceHistoryAPI:getFarmMortalityRecords(farmId, lookbackPeriods)
    if not validFarmId(farmId) then return nil, "farm" end
    if not isServerAuthority() then return nil, "not_server" end
    local repository = getRepository()
    if repository == nil or repository.getInsuranceLossesByFarm == nil then return nil, "not_ready" end

    local result = {}
    for _, loss in ipairs(repository:getInsuranceLossesByFarm(farmId) or {}) do
        if isInsideWindow(loss.incidentPeriod, lookbackPeriods) then
            result[#result + 1] = copyMortalityRecord(loss)
        end
    end
    sortNewestFirst(result)
    return result, "ok"
end

function RFF_InsuranceHistoryAPI:getFarmClaims(farmId, lookbackPeriods, claimType)
    if not validFarmId(farmId) then return nil, "farm" end
    if not isServerAuthority() then return nil, "not_server" end
    local repository = getRepository()
    if repository == nil or repository.getInsuranceClaimsByFarm == nil then return nil, "not_ready" end

    local requestedType = claimType ~= nil and tostring(claimType):upper() or nil
    local result = {}
    for _, claim in ipairs(repository:getInsuranceClaimsByFarm(farmId) or {}) do
        local status = tostring(claim.status or "")
        local typeCode = tostring(claim.claimType or "MORTALITY"):upper()
        -- Legacy Awaiting Submission records are not insurer claims yet and must not
        -- contribute to welfare/regulatory claim frequency.
        if status ~= "AWAITING_SUBMISSION"
            and (requestedType == nil or requestedType == "" or typeCode == requestedType)
            and isInsideWindow(claim.incidentPeriod, lookbackPeriods) then
            result[#result + 1] = copyClaimRecord(claim)
        end
    end
    sortNewestFirst(result)
    return result, "ok"
end

function RFF_InsuranceHistoryAPI:getFarmMortalityCount(farmId, lookbackPeriods)
    local records, reason = self:getFarmMortalityRecords(farmId, lookbackPeriods)
    if records == nil then return nil, reason end
    return #records, "ok"
end

function RFF_InsuranceHistoryAPI:getFarmClaimCount(farmId, lookbackPeriods, claimType)
    local records, reason = self:getFarmClaims(farmId, lookbackPeriods, claimType)
    if records == nil then return nil, reason end
    return #records, "ok"
end

function RFF_InsuranceHistoryAPI:getFarmSummary(farmId, lookbackPeriods)
    local mortality, mortalityReason = self:getFarmMortalityRecords(farmId, lookbackPeriods)
    if mortality == nil then return nil, mortalityReason end
    local claims, claimsReason = self:getFarmClaims(farmId, lookbackPeriods)
    if claims == nil then return nil, claimsReason end

    local summary = {
        apiVersion = self.API_VERSION,
        farmId = farmId,
        lookbackPeriods = normaliseWindow(lookbackPeriods) or 0,
        currentPeriod = getCurrentPeriodIndex(),
        mortalityCount = #mortality,
        claimedMortalityCount = 0,
        unclaimedMortalityCount = 0,
        expiredUnclaimedMortalityCount = 0,
        claimCount = #claims,
        mortalityClaimCount = 0,
        veterinaryClaimCount = 0,
        underReviewClaimCount = 0,
        approvedClaimCount = 0,
        declinedClaimCount = 0,
        paidClaimCount = 0,
        totalMortalityValue = 0,
        totalAmountClaimed = 0,
        totalApprovedAmount = 0,
        totalPaidAmount = 0,
        causeCounts = {},
        animalTypeCounts = {},
        claimTypeCounts = {},
        claimStatusCounts = {}
    }

    for _, record in ipairs(mortality) do
        summary.totalMortalityValue = summary.totalMortalityValue + math.max(0, safeNumber(record.incidentValue))
        if record.claimSubmitted then
            summary.claimedMortalityCount = summary.claimedMortalityCount + 1
        else
            summary.unclaimedMortalityCount = summary.unclaimedMortalityCount + 1
            if record.status == "EXPIRED" then
                summary.expiredUnclaimedMortalityCount = summary.expiredUnclaimedMortalityCount + 1
            end
        end
        local cause = tostring(record.deathReason or "UNKNOWN")
        local animalType = tostring(record.animalType or "UNKNOWN")
        summary.causeCounts[cause] = (summary.causeCounts[cause] or 0) + 1
        summary.animalTypeCounts[animalType] = (summary.animalTypeCounts[animalType] or 0) + 1
    end

    for _, claim in ipairs(claims) do
        local claimTypeCode = tostring(claim.claimType or "MORTALITY")
        local statusCode = tostring(claim.status or "UNKNOWN")
        summary.claimTypeCounts[claimTypeCode] = (summary.claimTypeCounts[claimTypeCode] or 0) + 1
        summary.claimStatusCounts[statusCode] = (summary.claimStatusCounts[statusCode] or 0) + 1
        if claimTypeCode == "MORTALITY" then summary.mortalityClaimCount = summary.mortalityClaimCount + 1 end
        if claimTypeCode == "VETERINARY" then summary.veterinaryClaimCount = summary.veterinaryClaimCount + 1 end
        if statusCode == "UNDER_REVIEW" then summary.underReviewClaimCount = summary.underReviewClaimCount + 1 end
        if statusCode == "APPROVED" then summary.approvedClaimCount = summary.approvedClaimCount + 1 end
        if statusCode == "DECLINED" then summary.declinedClaimCount = summary.declinedClaimCount + 1 end
        if statusCode == "PAID" then summary.paidClaimCount = summary.paidClaimCount + 1 end
        summary.totalAmountClaimed = summary.totalAmountClaimed + math.max(0, safeNumber(claim.amountClaimed))
        summary.totalApprovedAmount = summary.totalApprovedAmount + math.max(0, safeNumber(claim.approvedAmount))
        summary.totalPaidAmount = summary.totalPaidAmount + math.max(0, safeNumber(claim.paidAmount))
    end

    return summary, "ok"
end

-- Convenience snapshot for regulatory/welfare systems. This intentionally contains facts
-- only. Thresholds, risk scoring, inspections and enforcement remain the consumer's job.
function RFF_InsuranceHistoryAPI:getFarmRiskHistory(farmId, lookbackPeriods)
    local summary, reason = self:getFarmSummary(farmId, lookbackPeriods)
    if summary == nil then return nil, reason end
    local mortality = self:getFarmMortalityRecords(farmId, lookbackPeriods)
    local claims = self:getFarmClaims(farmId, lookbackPeriods)
    return {
        apiVersion = self.API_VERSION,
        farmId = farmId,
        lookbackPeriods = normaliseWindow(lookbackPeriods) or 0,
        summary = summary,
        mortality = mortality or {},
        claims = claims or {}
    }, "ok"
end
