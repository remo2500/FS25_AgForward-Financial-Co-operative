-- Optional routine inspections. No physical police, forced braking or vehicle seizure.
RFF_RoadsideCheckService = {}
RFF_RoadsideCheckService.__index = RFF_RoadsideCheckService
RFF_RoadsideCheckService.COOLDOWN_HOURS = 120
RFF_RoadsideCheckService.MIN_SECONDS = 1200
RFF_RoadsideCheckService.MAX_SECONDS = 2400
RFF_RoadsideCheckService.STOP_SECONDS = 10
local function server() return g_currentMission ~= nil and g_currentMission:getIsServer() end
local function tr(key) return g_i18n:getText('rff_roadside_'..key) end
function RFF_RoadsideCheckService.new(repository, compliance, speeding)
    return setmetatable({repository=repository,compliance=compliance,speeding=speeding,elapsed=0,stopped={}},RFF_RoadsideCheckService)
end
function RFF_RoadsideCheckService:randomDelay() return math.random(self.MIN_SECONDS,self.MAX_SECONDS) end
function RFF_RoadsideCheckService:screenNotice(farmId,message)
    -- A roadside officer speaks directly to the driver; never route through a phone or modal dialog.
    if g_currentMission ~= nil and g_currentMission:getFarmId()==farmId
        and g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO,message)
    end
end
function RFF_RoadsideCheckService:pending(farmId)
    for _,r in ipairs(self.repository.roadsideChecks or {}) do if r.farmId==farmId and r.status=='REQUESTED' then return r end end
    return nil
end
function RFF_RoadsideCheckService:setEnabled(farmId,enabled)
    if not server() or farmId==nil or farmId<=0 then return false end
    local state=self.repository:getFarmState(farmId,true)
    state.roadsideChecksEnabled=enabled==true
    if state.roadsideCheckRemaining==nil then state.roadsideCheckRemaining=self:randomDelay() end
    self.stopped[farmId]=nil
    if not enabled then
        for _,r in ipairs(self.repository.roadsideChecks or {}) do
            if r.farmId==farmId and r.status=='REQUESTED' then r.status='CANCELLED' end
        end
    end
    return true
end
function RFF_RoadsideCheckService:findReport(reference)
    for _,r in ipairs(self.repository.roadsideChecks or {}) do if string.format('RFF-RC-%06d',r.id)==reference then return r end end
    return nil
end
function RFF_RoadsideCheckService:evaluate(a)
    local lines,codes={},{}
    local fine,points=0,0
    local function finding(code,charge,score)
        codes[#codes+1]=code;lines[#lines+1]=tr('finding_'..code)
        fine=math.min(1000,fine+charge);points=math.max(points,score)
    end
    if a.entitlementHeld==false then finding('licence',250,3) end
    if a.hazardousLoad==true and a.adrHeld==false then finding('adr',250,3) end
    local p=a.insurancePolicy
    if a.ownership=='NATIVE_LEASE' then
        lines[#lines+1]=tr('native_lease') -- RFF cannot sell a policy for a GIANTS rental.
    elseif a.insured==false then finding('uninsured',500,6)
    elseif a.insured==true and p~=nil then
        if p.coverType=='NONE' then finding('uninsured',500,6)
        elseif p.useScope=='FARMLAND_ONLY' then finding('road_cover',500,6)
        elseif (tonumber(p.maxGrossWeight) or 0)>0 and (a.grossMassTonnes or 0)>p.maxGrossWeight+0.001 then finding('policy_weight',250,3) end
    else lines[#lines+1]=tr('insurance_unknown') end
    if a.widthAuthorisationRequired==true and a.movementAuthorisationActive~=true then finding('width',250,3) end
    if a.massAuthorisationRequired==true then finding('mass',250,3) end
    if a.adsRoadworthy==false then finding('condition',250,3)
    elseif a.adsRoadworthy==nil then lines[#lines+1]=tr('ads_unknown') end
    -- Speed is intentionally absent: the separate delayed-notice system handles it.
    return table.concat(lines,'\n'),table.concat(codes,','),fine,points,#codes
end
function RFF_RoadsideCheckService:request(farmId,vehicle)
    if not server() or vehicle==nil or tostring(vehicle.uniqueId or '')=='' then return nil end
    local state=self.repository:getFarmState(farmId,false)
    local now=self.compliance:getMonotonicHour()
    if state==nil or state.roadsideChecksEnabled~=true or now<(state.roadsideCooldownUntil or 0) or self:pending(farmId)~=nil then return nil end
    local a=self.compliance:getAssessment(farmId,vehicle)
    if a==nil or a.locationType~='ROAD' then return nil end
    local lines,codes,fine,points,count=self:evaluate(a)
    local id=1;for _,r in ipairs(self.repository.roadsideChecks or {}) do id=math.max(id,r.id+1) end
    local r={id=id,farmId=farmId,status='REQUESTED',requestedHour=now,expiresHour=now+2,
        vehicleUniqueId=tostring(vehicle.uniqueId),vehicleName=a.vehicleName or 'Vehicle',
        incidentDay=self.compliance:getCurrentDay(),incidentPeriod=self.repository:getCurrentPeriodIndex(),
        dayTimeMs=g_currentMission.environment.dayTime or 0,findings=lines,findingCodes=codes,findingCount=count,
        fine=fine,points=points,popupShown=false}
    table.insert(self.repository.roadsideChecks,r)
    state.roadsideCooldownUntil=now+self.COOLDOWN_HOURS;state.roadsideCheckRemaining=self:randomDelay()
    self.stopped[farmId]=nil
    local message=string.format(tr('request'),r.vehicleName)
    self:screenNotice(farmId,message)
    return r
end
function RFF_RoadsideCheckService:getReportMessage(r)
    local when=self.compliance:formatRestrictionEnd(r.incidentPeriod)
    local body=string.format(tr('intro'),r.id,r.vehicleName,r.incidentDay,when:match('^(.-),') or when)
    body=body..'\n'..(r.findings or '')
    if r.findingCount==0 then body=body..'\n'..tr('clear')
    else body=body..'\n'..string.format(tr('penalty'),g_i18n:formatMoney(r.fine,0,true,true),r.points) end
    if r.restrictionMessage~=nil and r.restrictionMessage~='' then body=body..'\n'..r.restrictionMessage end
    return body
end
function RFF_RoadsideCheckService:complete(r)
    if not server() or r.status~='REQUESTED' or (self.stopped[r.farmId] or 0)<self.STOP_SECONDS then return false end
    local farmId,vehicle=self.speeding:getContext('roadsideChecksEnabled')
    if farmId~=r.farmId or vehicle==nil or tostring(vehicle.uniqueId)~=r.vehicleUniqueId or self.compliance:getVehicleSpeed(vehicle)>1 then return false end
    if self.compliance:getMonotonicHour()>=r.expiresHour then return false end
    if g_farmManager~=nil and g_farmManager:getFarmById(r.farmId)==nil then return false end
    local state=self.compliance:ensureQualificationRecord(r.farmId)
    if state==nil or state.roadsideChecksEnabled~=true then return false end
    if r.fine>0 and (g_currentMission.addMoney==nil or MoneyType==nil or MoneyType.OTHER==nil) then return false end
    local reference=string.format('RFF-RC-%06d',r.id)
    if self.repository:getDriverOffenceByExternalId(reference)~=nil then r.status='COMPLETED';return false end
    self.compliance:expireSpeedPenalty(r.farmId,state)
    local now=self.compliance:getPenaltyClock()
    local offence={id=self.repository:getNextDriverOffenceId(),farmId=r.farmId,source='RFF_ROADSIDE',externalIncidentId=reference,
        offenceCode='ROADSIDE',status=r.points>0 and 'ACTIVE' or 'CLEAR',locationType='ROAD',incidentDay=r.incidentDay,
        incidentPeriod=r.incidentPeriod,dayTimeMs=r.dayTimeMs,vehicleUniqueId=r.vehicleUniqueId,vehicleName=r.vehicleName,
        targetName='',severityClass=r.points>=6 and 'SERIOUS' or 'MINOR',points=r.points,sourceSpeedKph=0,closingSpeedKph=0,
        pointsIssuedAt=r.points>0 and now or nil,pointsExpireAt=r.points>0 and now+self.compliance.POINTS_EXPIRY_MONTHS or nil,
        pointsTotalAfter=(state.driverPenaltyPoints or 0)+r.points}
    r.status='COMPLETED';r.completedHour=self.compliance:getMonotonicHour();self.stopped[r.farmId]=nil
    self.repository:addDriverOffence(offence)
    if r.fine>0 then g_currentMission:addMoney(-r.fine,r.farmId,MoneyType.OTHER,true,true) end
    state.driverPenaltyPoints=offence.pointsTotalAfter
    if r.points>0 then
        local action=self.compliance:applyOffenceSpeedPenalty(r.farmId,state)
        if action~=nil and action~='OFF' then r.restrictionMessage=self.compliance:getRestrictionSummary(r.farmId) end
    end
    r.popupShown=false -- Show the full report once, only after the inspection while stopped.
    self:screenNotice(r.farmId,r.findingCount==0 and tr('screen_clear')
        or string.format(tr('screen_findings'),g_i18n:formatMoney(r.fine,0,true,true),r.points))
    return true
end
function RFF_RoadsideCheckService:showFeedback()
    if not server() or InfoDialog==nil or InfoDialog.INSTANCE==nil or type(InfoDialog.show)~='function' then return end
    local farmId,vehicle=self.speeding:getContext('roadsideChecksEnabled')
    -- getContext excludes menus, pause, AI and driving tests. Never interrupt a moving driver.
    if vehicle==nil or self.compliance:getVehicleSpeed(vehicle)>1 then return end
    for _,r in ipairs(self.repository.roadsideChecks or {}) do
        if r.farmId==farmId and r.status=='COMPLETED' and not r.popupShown and tostring(vehicle.uniqueId)==r.vehicleUniqueId then
            r.popupShown=true -- Set before opening the dialog; persist to prevent replay after reload.
            InfoDialog.show(self:getReportMessage(r))
            return
        end
    end
end
function RFF_RoadsideCheckService:getHudText()
    local farmId,vehicle=self.speeding:getContext('roadsideChecksEnabled')
    if farmId==nil then return nil end
    local r=self:pending(farmId)
    if r==nil or self.compliance:getMonotonicHour()>=r.expiresHour then return nil end
    if tostring(vehicle.uniqueId)~=r.vehicleUniqueId then return tr('hud_return') end
    if self.compliance:getVehicleSpeed(vehicle)>1 then return tr('hud_stop') end
    return string.format(tr('hud_progress'),math.min(self.STOP_SECONDS,self.stopped[farmId] or 0),self.STOP_SECONDS)
end
function RFF_RoadsideCheckService:draw()
    local message=self:getHudText()
    if message==nil or renderText==nil or drawFilledRect==nil then return end
    -- Same lower-left anchor as the practical-test HUD; tests are excluded from roadside checks.
    local x,y,w=0.018,0.285,0.40
    drawFilledRect(x,y,w,0.078,0,0,0,0.76)
    drawFilledRect(x,y+0.074,w,0.004,0.42,0.66,0,1)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE)
    setTextBold(true);setTextColor(0.58,0.80,0.12,1)
    renderText(x+0.009,y+0.046,0.017,tr('title'))
    setTextBold(false);setTextColor(1,1,1,1)
    renderText(x+0.009,y+0.018,0.0145,message)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE)
end
function RFF_RoadsideCheckService:update(dt)
    if not server() then return end
    self.elapsed=self.elapsed+math.max(0,tonumber(dt) or 0)
    if self.elapsed<1000 then return end
    self.elapsed=0 -- Never count a long frame as time spent stationary or driving.
    local now=self.compliance:getMonotonicHour()
    for _,r in ipairs(self.repository.roadsideChecks or {}) do
        if r.status=='REQUESTED' and now>=r.expiresHour then r.status='EXPIRED';self.stopped[r.farmId]=nil end
    end
    local farmId,vehicle,state=self.speeding:getContext('roadsideChecksEnabled')
    if farmId==nil then self.stopped={};return end
    for id in pairs(self.stopped) do if id~=farmId then self.stopped[id]=nil end end
    local pending=self:pending(farmId)
    local speed=self.compliance:getVehicleSpeed(vehicle)
    if pending~=nil then
        if tostring(vehicle.uniqueId)==pending.vehicleUniqueId and speed<=1 then
            self.stopped[farmId]=(self.stopped[farmId] or 0)+1
            if self.stopped[farmId]>=self.STOP_SECONDS then self:complete(pending) end
        else self.stopped[farmId]=nil end
    elseif now>=(state.roadsideCooldownUntil or 0) and speed>=5 then
        local rules=self.compliance:getSpeedRules(farmId,vehicle)
        if rules~=nil and rules.locationType=='ROAD' then
            state.roadsideCheckRemaining=math.max(0,(state.roadsideCheckRemaining or self:randomDelay())-1)
            if state.roadsideCheckRemaining<=0 then
                state.roadsideCheckRemaining=self:randomDelay() -- Also back off if assessment data are unavailable.
                self:request(farmId,vehicle)
            end
        end
    end
    self:showFeedback()
end
function RFF_RoadsideCheckService:consoleTest(action)
    if not server() then return 'Server only' end
    local farmId=g_currentMission:getFarmId();local state=self.repository:getFarmState(farmId,false)
    if state==nil then return 'No farm' end
    action=string.upper(tostring(action or 'STATUS'))
    if action=='ARM' then
        if state.roadsideChecksEnabled~=true then return 'Enable Random Roadside Stops in Vehicles > Road Options first.' end
        if self:pending(farmId)~=nil then return 'A check is already requested. Stop safely in the requested vehicle.' end
        state.roadsideCheckRemaining=0;state.roadsideCooldownUntil=0
        return 'TEST: next eligible road drive requests a check. Stop safely for ten seconds and watch the inspection HUD. Real fines and points may be applied.'
    end
    if action~='STATUS' then return 'rffRoadsideTest [STATUS|ARM] - use a test save' end
    local rows={string.format('Roadside checks enabled=%s; driving seconds to check=%.0f; cooldown remaining hours=%.2f',tostring(state.roadsideChecksEnabled==true),state.roadsideCheckRemaining or -1,math.max(0,(state.roadsideCooldownUntil or 0)-self.compliance:getMonotonicHour()))}
    for _,r in ipairs(self.repository.roadsideChecks or {}) do if r.farmId==farmId then rows[#rows+1]=string.format('RFF-RC-%06d %s %s | %d findings | fine=%d points=%d',r.id,r.status,r.vehicleName,r.findingCount,r.fine,r.points) end end
    return table.concat(rows,'\n')
end
