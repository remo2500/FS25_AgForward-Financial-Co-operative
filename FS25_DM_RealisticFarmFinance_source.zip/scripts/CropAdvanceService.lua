RFF_CropAdvanceService = {}
RFF_CropAdvanceService.__index = RFF_CropAdvanceService
RFF_CropAdvanceService.PERCENTAGES = {25, 50, 65, 80, 90}

local function num(x)
    x = tonumber(x)
    return x ~= nil and x == x and x ~= math.huge and x ~= -math.huge and x or 0
end
local function money(x) return math.floor(math.max(0, num(x)) * 100 + 0.5) / 100 end
local function server() return g_currentMission ~= nil and g_currentMission:getIsServer() end
local function fmt(x) return g_i18n:formatMoney(num(x), 0, true, true) end
local function inside(points, x, z)
    local hit, j = false, #points
    for i, a in ipairs(points) do
        local b = points[j]
        if (a.z > z) ~= (b.z > z) and x < (b.x-a.x)*(z-a.z)/(b.z-a.z)+a.x then hit = not hit end
        j = i
    end
    return hit
end

function RFF_CropAdvanceService.new(repository, loans)
    return setmetatable({repository=repository, loans=loans, timer=0}, RFF_CropAdvanceService)
end

function RFF_CropAdvanceService:period()
    return self.repository:getCurrentPeriodIndex()
end

function RFF_CropAdvanceService:date(period)
    local p = ((period-1)%12)+1
    return string.format("%s Y%d", g_i18n:formatPeriod(p, false), math.floor((period-1)/12))
end

function RFF_CropAdvanceService:records(farmId)
    local out = {}
    for _, a in ipairs(self.repository.cropAdvances or {}) do
        if a.farmId == farmId then out[#out+1] = a end
    end
    table.sort(out, function(a,b) return a.id < b.id end)
    return out
end

function RFF_CropAdvanceService:notify(a, title, text)
    a.lastMessage = text
    if RFF_NotificationService ~= nil then
        RFF_NotificationService:send(a.farmId, "Crop Finance", title, text, "FINANCE", title .. " - see Borrowing / Crop Advances.")
    end
end

function RFF_CropAdvanceService:getHistory(farmId)
    local completed, successful, converted, litres, delivered, unpaid = {},0,0,0,0,0
    for _, a in ipairs(self:records(farmId)) do
        if a.status == "FULFILLED" or a.status == "CONVERTED" then completed[#completed+1] = a end
    end
    for i = math.max(1,#completed-4), #completed do
        local a = completed[i]
        litres = litres + a.committedLitres
        delivered = delivered + a.deliveredLitres
        if a.status == "FULFILLED" then successful=successful+1 else
            converted=converted+1
            for _, loan in ipairs(self.repository.loans or {}) do
                if loan.id == a.loanId and not loan.paidOff then unpaid=unpaid+1 end
            end
        end
    end
    local shortfall = litres > 0 and math.max(0,1-delivered/litres) or 0
    -- New quotes only: signed agreements retain their saved advance and price.
    local rate = math.max(0.65, math.min(0.80, 0.75 + successful*0.01 - shortfall*0.20))
    local maxPercent = shortfall > 0.25 and 50 or successful >= 3 and 90 or 80
    return {successes=successful, converted=converted, shortfall=shortfall, rate=rate, maxPercent=maxPercent, blocked=unpaid>=3}
end

function RFF_CropAdvanceService:hasAccess(farmId, farmlandId)
    if g_farmlandManager == nil then return false end
    if g_farmlandManager:getFarmlandOwner(farmlandId) == farmId then return true end
    return RFF_TenancyAPI ~= nil and RFF_TenancyAPI.canFarmUseFarmland(farmId, farmlandId) == true
end

function RFF_CropAdvanceService:fields(farmId)
    local out={}
    for _, field in ipairs(g_fieldManager ~= nil and g_fieldManager:getFields() or {}) do
        local id=field:getId()
        if id ~= nil and self:hasAccess(farmId,id) then out[#out+1]=field end
    end
    table.sort(out,function(a,b) return tostring(a:getName()) < tostring(b:getName()) end)
    return out
end

-- Bounded density sampling, only on explicit quote/refresh. FieldState is a
-- centre-point cache; it must not value an entire partly planted field.
function RFF_CropAdvanceService:survey(field, farmId)
    if field == nil or not self:hasAccess(farmId,field:getId()) then return nil,"No accessible field selected." end
    local points,minX,minZ,maxX,maxZ={},math.huge,math.huge,-math.huge,-math.huge
    for _, node in ipairs(field:getPolygonPoints() or {}) do
        local x,_,z=getWorldTranslation(node)
        points[#points+1]={x=x,z=z}
        minX,minZ,maxX,maxZ=math.min(minX,x),math.min(minZ,z),math.max(maxX,x),math.max(maxZ,z)
    end
    if #points<3 or maxX<=minX or maxZ<=minZ then return nil,"Field geometry is unavailable." end
    local plane=g_fruitTypeManager:getDefaultDataPlaneId()
    if plane==nil then return nil,"Crop density data is unavailable." end
    local counts,insideCount,growingCount={},0,0
    for ix=0,31 do for iz=0,31 do
        local x,z=minX+(ix+0.5)*(maxX-minX)/32,minZ+(iz+0.5)*(maxZ-minZ)/32
        if inside(points,x,z) then
            insideCount=insideCount+1
            local desc=g_fruitTypeManager:getFruitTypeByDensityTypeIndex(getDensityTypeIndexAtWorldPos(plane,x,0,z))
            if desc ~= nil then
                local state=desc:getGrowthStateByDensityState(getDensityStatesAtWorldPos(plane,x,0,z))
                if state ~= nil and desc:getIsGrowing(state) and self:hasAccess(farmId,g_farmlandManager:getFarmlandIdAtWorldPosition(x,z)) then
                    growingCount=growingCount+1
                    counts[desc.index]=(counts[desc.index] or 0)+1
                end
            end
        end
    end end
    local best,n=nil,0
    for id,count in pairs(counts) do if count>n then best,n=id,count end end
    if best==nil or insideCount<8 or n<8 then return nil,"Select a planted, growing crop; bare, ripe or harvested fields are not eligible." end
    if n/growingCount<0.95 then return nil,"Mixed crops detected. This first version requires one predominant planted crop." end
    local fruit=g_fruitTypeManager:getFruitTypeByIndex(best)
    if fruit.regrows == true or fruit.allowsSeeding == false then return nil,"Regrowing and perennial crops are not supported in this first version." end
    if fruit.fillType==nil or num(fruit.literPerSqm)<=0 then return nil,"This crop has no supported harvested quantity." end
    return {fruit=fruit, areaHa=field:getAreaHa()*n/insideCount, farmlandId=field:getId(), fieldName=tostring(field:getName())}
end

-- Store absolute periods. End + 1 is the whole final delivery month;
-- conversion occurs at the start of End + 2, including cross-year windows.
function RFF_CropAdvanceService:harvestWindow(fruit, current)
    local periods=fruit.growthDataSeasonal and fruit.growthDataSeasonal.periods
    if periods==nil then return nil end
    local total=0
    for p=1,12 do if periods[p] and periods[p].isHarvestable then total=total+1 end end
    if total==0 or total==12 then return nil end
    local start
    for offset=0,11 do
        local absolute=current+offset
        if periods[((absolute-1)%12)+1] and periods[((absolute-1)%12)+1].isHarvestable then start=absolute;break end
    end
    if start==nil then return nil end
    local finish=start
    for offset=1,11 do
        local p=((start+offset-1)%12)+1
        if not (periods[p] and periods[p].isHarvestable) then break end
        finish=start+offset
    end
    return start,finish
end

function RFF_CropAdvanceService:quote(farmId, field, percent)
    if not self.repository.loaded then return nil,"Finance data is still loading." end
    if not self.hooked then return nil,"Standard selling-point integration is unavailable." end
    local valid=false
    for _,p in ipairs(self.PERCENTAGES) do if p==percent then valid=true end end
    if not valid then return nil,"Choose an offered commitment percentage." end
    local h=self:getHistory(farmId)
    if h.blocked then return nil,"New advances are suspended while three recent shortfall loans remain unpaid." end
    if percent>h.maxPercent then return nil,"Delivery history currently limits commitments to "..h.maxPercent.."%." end
    local conduct=self.loans:getPaymentConduct(farmId)
    if conduct ~= nil and conduct.declineNewCredit then return nil,"Existing missed repayments must be addressed before a new crop advance." end
    local s,reason=self:survey(field,farmId)
    if s==nil then return nil,reason end
    local start,finish=self:harvestWindow(s.fruit,self:period())
    if start==nil then return nil,"A defined seasonal harvest window is required; year-round crops are not supported." end
    for _,a in ipairs(self.repository.cropAdvances or {}) do
        -- Reserve the parcel through the entire agreed season even when
        -- fulfilled early, preventing repeated advances on the same crop.
        if a.farmlandId==s.farmlandId and (a.status=="ACTIVE" or self:period()<=a.duePeriod) then return nil,"This parcel is already pledged for this season." end
    end
    if g_farmlandManager:getFarmlandOwner(s.farmlandId) ~= farmId then
        local t=RFF_TenancyAPI.getTenancySummary(farmId,s.farmlandId)
        if t==nil or num(t.remainingMonths)<finish+2-self:period() then return nil,"The tenancy must cover the harvest and delivery window." end
    end
    local factor,count=0,0
    for p=start,finish do
        local seasonal=s.fruit.fillType.economy and s.fruit.fillType.economy.factors
        factor=factor+(seasonal and seasonal[((p-1)%12)+1] or 1);count=count+1
    end
    local reference=num(s.fruit.fillType.pricePerLiter)*EconomyManager.getPriceMultiplier()*factor/math.max(1,count)
    reference=math.floor(reference*1000000+0.5)/1000000
    local expected=math.floor(s.areaHa*10000*s.fruit.literPerSqm)
    local litres=math.floor(expected*percent/100)
    local advance=money(litres*reference*h.rate)
    if reference<=0 or litres<1 or advance<1 then return nil,"The assessed crop value is too small for an advance." end
    return {farmId=farmId, farmlandId=s.farmlandId, fieldName=s.fieldName, fruitName=s.fruit.name,
        fillTypeName=s.fruit.fillType.name, cropTitle=s.fruit.fillType.title or s.fruit.name,
        areaHa=s.areaHa, expectedLitres=expected, percentage=percent, committedLitres=litres,
        advance=advance, referencePrice=reference, advanceFactor=h.rate,
        createdPeriod=self:period(), harvestStart=start, harvestEnd=finish, duePeriod=finish+1,
        interestRate=8, loanMonths=12}
end

function RFF_CropAdvanceService:accept(farmId, field, previous)
    if not server() then return nil,"Only the server/host can accept crop advances." end
    local q,reason=self:quote(farmId,field,previous and previous.percentage)
    if q==nil then return nil,reason end
    for _,key in ipairs({"farmId","farmlandId","fruitName","fillTypeName","expectedLitres","committedLitres","advance","referencePrice","advanceFactor","createdPeriod","duePeriod"}) do
        if q[key]~=previous[key] then return nil,"The crop or offer changed. Refresh and review the new quote." end
    end
    local id=1
    for _,a in ipairs(self.repository.cropAdvances or {}) do id=math.max(id,a.id+1) end
    q.id=id;q.status="ACTIVE";q.deliveredLitres=0;q.loanId=0;q.shortfallAmount=0
    self.repository.cropAdvances=self.repository.cropAdvances or {}
    table.insert(self.repository.cropAdvances,q)
    self.repository:setNextTransactionDescription(farmId,"Crop advance CA-"..id.." - "..q.cropTitle)
    g_currentMission:addMoney(q.advance,farmId,MoneyType.OTHER,true,true)
    self:notify(q,"Crop advance accepted",string.format("CA-%d: %s advanced for %.0f L of %s. Deliver by the end of %s. Committed litres receive no second payment.",
        id,fmt(q.advance),q.committedLitres,q.cropTitle,self:date(q.duePeriod)))
    return q
end

function RFF_CropAdvanceService:processDue()
    if not server() or not self.repository.loaded then return end
    local now=self:period()
    for _,a in ipairs(self.repository.cropAdvances or {}) do
        if a.status=="ACTIVE" then
            local remaining=math.max(0,a.committedLitres-a.deliveredLitres)
            if now>a.duePeriod then
                local amount=money(remaining*a.referencePrice)
                if amount<0.01 then a.status="FULFILLED" else
                    local payment=self.loans:calculateMonthlyPayment(amount,a.interestRate,a.loanMonths,RFF_LoanService.TYPE_TERM)
                    local loan,reason=self.loans:createLoanFromOffer(a.farmId,amount,a.loanMonths,RFF_LoanService.TYPE_TERM,"WORKING_CAPITAL",
                        {approved=true,interestRate=a.interestRate,monthlyPayment=payment,grade="C"},
                        {disburse=false,allowDistressedCredit=true,allowSmallBalance=true})
                    if loan ~= nil then
                        a.loanId=loan.id;a.shortfallAmount=amount;a.status="CONVERTED";a.completedPeriod=now
                        self:notify(a,"Crop shortfall converted",string.format("CA-%d: %.0f L undelivered. %s is now loan #%d at %.1f%% fixed for %d months. No new cash was advanced; the crop commitment is closed.",
                            a.id,remaining,fmt(amount),loan.id,a.interestRate,a.loanMonths))
                    else a.lastMessage="Shortfall conversion pending: "..tostring(reason) end
                end
            elseif now==a.duePeriod and not a.finalWarning then
                a.finalWarning=true
                self:notify(a,"Final crop delivery month",string.format("CA-%d: %.0f L still due by the end of %s. Undelivered crop converts to an 8%% fixed, 12-month loan.",a.id,remaining,self:date(a.duePeriod)))
            elseif now>=a.harvestStart and now<a.duePeriod and not a.harvestReminder then
                a.harvestReminder=true
                self:notify(a,"Crop delivery reminder",string.format("CA-%d: harvest window open. %.0f L remain due by the end of %s.",a.id,remaining,self:date(a.duePeriod)))
            end
        end
    end
end

function RFF_CropAdvanceService:sell(station, original, farmId, litres, fillTypeIndex, toolType, attributes)
    if not server() or station.isServer==false or not self.repository.loaded or num(litres)<=0 then
        return original(station,farmId,litres,fillTypeIndex,toolType,attributes)
    end
    self:processDue()
    -- Owned/shared productions are transfers, not crop deliveries.
    if station.getSkipSell and station:getSkipSell(farmId,fillTypeIndex) then
        return original(station,farmId,litres,fillTypeIndex,toolType,attributes)
    end
    local fill=g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
    local allocations,left={},litres
    local list=self:records(farmId)
    table.sort(list,function(a,b) return a.duePeriod==b.duePeriod and a.id<b.id or a.duePeriod<b.duePeriod end)
    for _,a in ipairs(list) do
        if a.status=="ACTIVE" and self:period()<=a.duePeriod and fill~=nil and a.fillTypeName==fill.name then
            local n=math.min(left,math.max(0,a.committedLitres-a.deliveredLitres))
            if n>0 then allocations[#allocations+1]={a=a,n=n};left=left-n end
        end
        if left<=0 then break end
    end
    if #allocations==0 then return original(station,farmId,litres,fillTypeIndex,toolType,attributes) end
    local adjusted={}
    for k,v in pairs(attributes or {}) do adjusted[k]=v end
    -- Standard SellingStation honours priceScale. Preserve its normal handling
    -- of totals, price drops and sale events; only uncommitted litres earn cash.
    adjusted.priceScale=(attributes and attributes.priceScale or 1)*left/litres
    local result=original(station,farmId,litres,fillTypeIndex,toolType,adjusted)
    for _,item in ipairs(allocations) do
        local a=item.a
        a.deliveredLitres=math.min(a.committedLitres,a.deliveredLitres+item.n)
        a.lastDeliveryPeriod=self:period()
        a.lastStation=station.getName and station:getName() or "Selling point"
        if a.committedLitres-a.deliveredLitres<0.000001 then
            a.deliveredLitres=a.committedLitres;a.status="FULFILLED";a.completedPeriod=self:period()
            self:notify(a,"Crop commitment fulfilled",string.format("CA-%d: all %.0f L delivered. The advance is cleared. Delivery performance has been recorded.",a.id,a.committedLitres))
        end
    end
    return result
end

function RFF_CropAdvanceService:install()
    if not server() or self.hooked or SellingStation==nil or type(SellingStation.sellFillType)~="function" then return end
    local original=SellingStation.sellFillType
    self.originalSell=original
    local service=self
    self.saleWrapper=function(station,...)
        if not service.hooked then return original(station,...) end
        return service:sell(station,original,...)
    end
    SellingStation.sellFillType=self.saleWrapper
    self.hooked=true
end

function RFF_CropAdvanceService:shutdown()
    self.hooked=false
    if SellingStation~=nil and SellingStation.sellFillType==self.saleWrapper then SellingStation.sellFillType=self.originalSell end
end

function RFF_CropAdvanceService:update(dt)
    self.timer=self.timer-num(dt)
    if self.timer>0 then return end
    self.timer=1000
    self:install()
    self:processDue()
end

-- Additive persistence in the existing finance save; crop names rather than
-- runtime fill indices survive mod load-order changes.
RFF_CropAdvanceService.SAVE_FIELDS={
    Int={"id","farmId","farmlandId","createdPeriod","harvestStart","harvestEnd","duePeriod","loanId","loanMonths","completedPeriod","lastDeliveryPeriod"},
    Float={"areaHa","expectedLitres","percentage","committedLitres","deliveredLitres","advance","referencePrice","advanceFactor","interestRate","shortfallAmount"},
    String={"fieldName","fruitName","fillTypeName","cropTitle","status","lastMessage","lastStation"},
    Bool={"harvestReminder","finalWarning"}
}
function RFF_CropAdvanceService.save(repository,xml)
    for i,a in ipairs(repository.cropAdvances or {}) do
        local key="realisticFarmFinance.cropAdvances.advance("..(i-1)..")"
        for kind,fields in pairs(RFF_CropAdvanceService.SAVE_FIELDS) do for _,field in ipairs(fields) do
            local value=a[field]
            if value==nil then
                if kind=="String" then value="" elseif kind=="Bool" then value=false else value=0 end
            end
            xml["set"..kind](xml,key.."#"..field,value)
        end end
    end
end
function RFF_CropAdvanceService.load(repository,xml)
    repository.cropAdvances={}
    local i=0
    while xml:hasProperty("realisticFarmFinance.cropAdvances.advance("..i..")") do
        local key="realisticFarmFinance.cropAdvances.advance("..i..")"
        local a={}
        for kind,fields in pairs(RFF_CropAdvanceService.SAVE_FIELDS) do for _,field in ipairs(fields) do
            local value=xml["get"..kind](xml,key.."#"..field)
            if kind=="String" then a[field]=value or "" elseif kind=="Bool" then a[field]=value==true else a[field]=num(value) end
        end end
        if a.id>0 and a.farmId>0 and a.committedLitres>0 then
            a.deliveredLitres=math.max(0,math.min(a.committedLitres,a.deliveredLitres))
            repository.cropAdvances[#repository.cropAdvances+1]=a
        end
        i=i+1
    end
end

function RFF_CropAdvanceService:consoleTest(action,id)
    if not server() then return "Server only." end
    action=string.upper(tostring(action or "STATUS"))
    local farm=g_currentMission:getFarmId()
    if action=="EXPIRE" then
        for _,a in ipairs(self:records(farm)) do if a.id==tonumber(id) and a.status=="ACTIVE" then
            a.duePeriod=self:period()-1
            self:processDue()
            return "TEST: agreement expired; inspect Crop Advances and Borrowing / Agreements."
        end end
        return "Use rffCropAdvanceTest EXPIRE <active agreement id>. This creates a real shortfall loan."
    end
    for _,a in ipairs(self:records(farm)) do
        print(string.format("[RFF crop] CA-%d %s %s committed=%.0f delivered=%.2f due=%s loan=%d",a.id,a.status,a.fillTypeName,a.committedLitres,a.deliveredLitres,self:date(a.duePeriod),a.loanId))
    end
    return "Crop advance status printed. Standard sale hook: "..tostring(self.hooked)
end
