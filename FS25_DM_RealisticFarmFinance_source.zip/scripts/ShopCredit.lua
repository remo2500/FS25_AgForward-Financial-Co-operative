-- Include authorised overdraft only inside native vehicle affordability checks.
-- Never credit temporary money, alter a purchase price, or replace bank/HUD balances.
RFF_ShopCredit={}
local C=RFF_ShopCredit
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<math.huge end
local function pack(...) return {n=select('#',...),...} end
function C.withFunds(farmId,callback,target,...)
    local mission=g_currentMission
    local manager=RFF_RealisticFarmFinance and RFF_RealisticFarmFinance.manager
    local repo=manager and manager.repository
    local limit=repo and repo.loaded and repo.getOverdraftLimit and repo:getOverdraftLimit(farmId) or 0
    if not mission or not mission.getMoney or not finite(farmId) or farmId<=0 or not finite(limit) or limit<=0 then
        return callback(target,...)
    end
    local own=rawget(mission,"getMoney");local original=mission.getMoney
    -- An inner native callback must not add the same facility twice.
    if C.activeFarm==farmId then return callback(target,...) end
    local previous=C.activeFarm;C.activeFarm=farmId
    mission.getMoney=function(m,id,...)
        local cash=original(m,id,...)
        local selected=id or (m.getFarmId and m:getFarmId())
        if selected==farmId and finite(cash) then return cash+limit end
        return cash
    end
    local result=pack(pcall(callback,target,...))
    mission.getMoney=own;C.activeFarm=previous
    if not result[1] then error(result[2],0) end
    return (unpack or table.unpack)(result,2,result.n)
end
function C.install()
    if C.installed or not ShopConfigScreen or not BuyVehicleEvent then return end
    C.installed=true
    for _,name in ipairs({"onClickBuy","onClickLease"}) do
        ShopConfigScreen[name]=Utils.overwrittenFunction(ShopConfigScreen[name],function(screen,superFunc,...)
            local id=g_shopController and g_shopController.playerFarmId
            return C.withFunds(id,superFunc,screen,...)
        end)
    end
    if ShopController and ShopController.canBeBought then
        ShopController.canBeBought=Utils.overwrittenFunction(ShopController.canBeBought,function(controller,superFunc,item,...)
            if not StoreItemUtil.getIsVehicle(item) then return superFunc(controller,item,...) end
            return C.withFunds(controller.playerFarmId,superFunc,controller,item,...)
        end)
    end
    BuyVehicleEvent.run=Utils.overwrittenFunction(BuyVehicleEvent.run,function(event,superFunc,connection)
        if connection:getIsServer() then return superFunc(event,connection) end
        local mission=g_currentMission
        local userId=mission.userManager:getUserIdByConnection(connection)
        local farm=g_farmManager:getFarmByUserId(userId)
        local data=event.vehicleBuyData
        -- Native permission, validity, slot and purchase accounting checks remain intact.
        if not farm or not data or data.ownerFarmId~=farm.farmId then return superFunc(event,connection) end
        return C.withFunds(farm.farmId,superFunc,event,connection)
    end)
end
