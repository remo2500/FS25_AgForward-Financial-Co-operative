RFF_CreditProfile = {}

-- Session-only underwriting override for development/testing. This never changes the
-- persisted financial history or agreement balances; it only substitutes a healthy
-- established trading profile while enabled for the current farm.
RFF_TestCreditOverride = RFF_TestCreditOverride or {}

function RFF_CreditProfile:setTestOverride(farmId, enabled, monthlyIncome)
    if farmId == nil or farmId <= 0 then return end
    if enabled == true then
        RFF_TestCreditOverride[farmId] = {
            enabled = true,
            monthlyIncome = math.max(0, tonumber(monthlyIncome) or 0)
        }
    else
        RFF_TestCreditOverride[farmId] = nil
    end
end

function RFF_CreditProfile:getTestOverride(farmId)
    local override = RFF_TestCreditOverride ~= nil and RFF_TestCreditOverride[farmId] or nil
    return override ~= nil and override.enabled == true and override or nil
end

RFF_CreditProfile.HAIRCUTS = {
    cash = 0.30,
    farmland = 0.70,
    buildings = 0.55,
    equipment = 0.45,
    livestock = 0.60,
    inventory = 0.50
}

function RFF_CreditProfile:getStage(trackedPeriods)
    if trackedPeriods < 3 then
        return "rff_stage_startup"
    elseif trackedPeriods < 12 then
        return "rff_stage_developing"
    end
    return "rff_stage_established"
end

function RFF_CreditProfile:calculate(farmId, valuation, repository)
    local financeDebt = repository ~= nil and repository:getOutstandingLoanBalance(farmId) or 0
    -- Do not let borrowed cash recursively create more borrowing capacity.
    local cashCollateralBase = math.max(0, (valuation.cash or 0) - financeDebt)

    local collateral =
        cashCollateralBase * self.HAIRCUTS.cash +
        valuation.farmland * self.HAIRCUTS.farmland +
        valuation.buildings * self.HAIRCUTS.buildings +
        valuation.equipment * self.HAIRCUTS.equipment +
        valuation.livestock * self.HAIRCUTS.livestock +
        valuation.inventory * self.HAIRCUTS.inventory

    local debt = valuation.liabilities or 0
    local trackedPeriods = repository:getTrackedPeriodCount(farmId)
    local monthlyIncome = repository:getTrailingOperatingIncome(farmId, 12)
    local testOverride = self:getTestOverride(farmId)
    if testOverride ~= nil then
        trackedPeriods = math.max(12, trackedPeriods)
        monthlyIncome = math.max(monthlyIncome, testOverride.monthlyIncome or 0)
    end
    local debtToAssets = valuation.totalAssets > 0 and debt / valuation.totalAssets or 0
    local collateralLtv = collateral > 0 and debt / collateral or 0

    local maxSecuredLtv = trackedPeriods < 3 and 0.65 or (trackedPeriods < 12 and 0.85 or 0.90)
    local securedHeadroom = math.max(0, collateral * maxSecuredLtv - debt)
    local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(repository, farmId) or nil

    return {
        stageTextKey = self:getStage(trackedPeriods),
        collateral = collateral,
        debtToAssets = debtToAssets,
        collateralLtv = collateralLtv,
        securedHeadroom = securedHeadroom,
        monthlyIncome = monthlyIncome,
        trackedPeriods = trackedPeriods,
        conductTextKey = conduct ~= nil and conduct.key or "rff_conduct_excellent",
        conductCode = conduct ~= nil and conduct.code or "EXCELLENT",
        currentArrears = conduct ~= nil and conduct.currentArrears or 0,
        consecutiveMissedPayments = conduct ~= nil and conduct.consecutiveMissedPayments or 0,
        maxConsecutiveMissedPayments = conduct ~= nil and conduct.maxConsecutiveMissedPayments or 0,
        monthsSinceLastMiss = conduct ~= nil and conduct.monthsSinceLastMiss or nil,
        agreementsInArrears = conduct ~= nil and conduct.agreementsInArrears or 0,
        forcedPropertyRecoveryEvents = conduct ~= nil and conduct.forcedPropertyRecoveryEvents or 0,
        monthsSincePropertyRecovery = conduct ~= nil and conduct.monthsSincePropertyRecovery or nil,
        testCreditOverride = testOverride ~= nil
    }
end
