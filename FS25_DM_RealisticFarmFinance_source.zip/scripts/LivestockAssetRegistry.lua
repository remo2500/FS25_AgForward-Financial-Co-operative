-- Optional valuation bridge for animal systems that hold livestock outside normal GIANTS placeable husbandries.
-- RFF owns valuation. Providers only expose authoritative live animal/cluster records plus identity/location metadata.
-- API v2 extends the original livestock-provider registry; it does not introduce a second inventory contract.
RFF_LivestockAssetRegistry = RFF_LivestockAssetRegistry or {}
RFF_LivestockAssetRegistry.API_VERSION = 2
RFF_LivestockAssetRegistry.providers = RFF_LivestockAssetRegistry.providers or {}
RFF_LivestockAssetRegistry._providerFailureLogged = RFF_LivestockAssetRegistry._providerFailureLogged or {}
RFF_LivestockAssetRegistry._legacyProviderWarningLogged = RFF_LivestockAssetRegistry._legacyProviderWarningLogged or {}

-- Publish the livestock asset registry as an intentional cross-mod API.
-- GIANTS runs mods in separate Lua environments, so assigning only to this
-- mod's _G does not make the registry reliably visible to other mods.
local globalRoot = _G
local globalMeta = getmetatable(_G)

if globalMeta ~= nil and type(globalMeta.__index) == "table" then
    globalRoot = globalMeta.__index
end

globalRoot.RFF_LivestockAssetRegistry = RFF_LivestockAssetRegistry

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local function logWarning(message, ...)
    if Logging ~= nil and Logging.warning ~= nil then
        Logging.warning(message, ...)
    else
        print(string.format(message, ...))
    end
end

local function logInfo(message, ...)
    if Logging ~= nil and Logging.info ~= nil then
        Logging.info(message, ...)
    else
        print(string.format(message, ...))
    end
end

local function sortedProviderIds(providers)
    local ids = {}
    for providerId, _ in pairs(providers or {}) do
        table.insert(ids, providerId)
    end
    table.sort(ids)
    return ids
end

function RFF_LivestockAssetRegistry.registerProvider(providerId, provider)
    if type(providerId) ~= "string" or providerId == "" or provider == nil then return false end
    RFF_LivestockAssetRegistry.providers[providerId] = provider
    RFF_LivestockAssetRegistry._providerFailureLogged[providerId] = nil
    logInfo("[RFF] Livestock asset provider registered id=%s api=%d", providerId, RFF_LivestockAssetRegistry.API_VERSION)
    return true
end

function RFF_LivestockAssetRegistry.unregisterProvider(providerId)
    if type(providerId) ~= "string" then return end
    RFF_LivestockAssetRegistry.providers[providerId] = nil
    RFF_LivestockAssetRegistry._providerFailureLogged[providerId] = nil
    RFF_LivestockAssetRegistry._legacyProviderWarningLogged[providerId] = nil
end

function RFF_LivestockAssetRegistry:getProviderIds()
    return sortedProviderIds(self.providers)
end

function RFF_LivestockAssetRegistry:getProviderCount()
    local count = 0
    for _, _ in pairs(self.providers or {}) do count = count + 1 end
    return count
end

function RFF_LivestockAssetRegistry:_logProviderFailureOnce(providerId, err)
    if self._providerFailureLogged[providerId] == true then return end
    self._providerFailureLogged[providerId] = true
    logWarning("[RFF] External livestock provider '%s' failed: %s. Remaining providers/native livestock will still be valued.", providerId, tostring(err))
end

function RFF_LivestockAssetRegistry:_warnLegacyProviderOnce(providerId)
    if self._legacyProviderWarningLogged[providerId] == true then return end
    self._legacyProviderWarningLogged[providerId] = true
    logWarning("[RFF] External livestock provider '%s' is using legacy pre-valued output. API v2 records with clusterRef/dedupeKey are preferred so RFF can value and deduplicate livestock itself.", providerId)
end

-- Calls one registered provider. Preferred v2 provider methods are getLivestockAssets/getLivestockAssetRecords.
-- A function provider may return the same v2 records directly. Legacy getLivestockAssetValue is retained for compatibility.
function RFF_LivestockAssetRegistry:_callProvider(providerId, provider, farmId)
    local ok, result

    if type(provider) == "function" then
        ok, result = pcall(provider, farmId)
    elseif type(provider) == "table" and type(provider.getLivestockAssets) == "function" then
        ok, result = pcall(provider.getLivestockAssets, provider, farmId)
    elseif type(provider) == "table" and type(provider.getLivestockAssetRecords) == "function" then
        ok, result = pcall(provider.getLivestockAssetRecords, provider, farmId)
    elseif type(provider) == "table" and type(provider.getLivestockAssetValue) == "function" then
        ok, result = pcall(provider.getLivestockAssetValue, provider, farmId)
    else
        self:_logProviderFailureOnce(providerId, "provider exposes no supported livestock asset method")
        return nil
    end

    if not ok then
        self:_logProviderFailureOnce(providerId, result)
        return nil
    end

    return result
end

local function appendRecord(records, providerId, record)
    if type(record) ~= "table" then return end
    local copy = {}
    for key, value in pairs(record) do copy[key] = value end
    copy.providerId = providerId
    if copy.source == nil or copy.source == "" then copy.source = providerId end
    table.insert(records, copy)
end

-- Collects records from ALL registered providers. Collection is server-authoritative only.
-- Expected v2 record fields:
-- farmId, animalTypeIndex, subTypeIndex, count, persistentId, clusterId, dedupeKey,
-- clusterRef (runtime only), source, locationType, locationId.
-- clusterRef is never persisted by RFF.
function RFF_LivestockAssetRegistry:collectProviderRecords(farmId)
    local records = {}
    local legacyValues = {}

    if g_server == nil then
        return records, legacyValues
    end

    for _, providerId in ipairs(sortedProviderIds(self.providers)) do
        local provider = self.providers[providerId]
        local result = self:_callProvider(providerId, provider, farmId)

        if result ~= nil then
            if type(result) == "number" then
                self:_warnLegacyProviderOnce(providerId)
                legacyValues[providerId] = math.max(0, safeNumber(result))
            elseif type(result) == "table" then
                local payload = result.records or result.assets or result.animals
                if type(payload) == "table" then
                    for _, record in pairs(payload) do appendRecord(records, providerId, record) end
                elseif type(result.totalValue) == "number" then
                    self:_warnLegacyProviderOnce(providerId)
                    legacyValues[providerId] = math.max(0, safeNumber(result.totalValue))
                else
                    -- An array/map may be either v2 identity records or the legacy pre-valued assets.
                    local foundV2Record = false
                    local legacyTotal = 0
                    for _, record in pairs(result) do
                        if type(record) == "table" then
                            local looksLikeV2 = record.clusterRef ~= nil
                                or record.dedupeKey ~= nil
                                or record.persistentId ~= nil
                                or record.clusterId ~= nil
                                or record.farmId ~= nil
                                or record.animalTypeIndex ~= nil
                                or record.subTypeIndex ~= nil
                                or record.locationType ~= nil
                                or record.locationId ~= nil
                            if looksLikeV2 then
                                appendRecord(records, providerId, record)
                                foundV2Record = true
                            else
                                local value = safeNumber(record.marketValue or record.value)
                                local quantity = math.max(1, safeNumber(record.quantity or record.numAnimals or 1))
                                legacyTotal = legacyTotal + math.max(0, value) * quantity
                            end
                        end
                    end
                    if legacyTotal > 0 then
                        self:_warnLegacyProviderOnce(providerId)
                        legacyValues[providerId] = legacyTotal
                    elseif not foundV2Record and next(result) ~= nil then
                        self:_logProviderFailureOnce(providerId, "provider returned no recognisable livestock records")
                    end
                end
            end
        end
    end

    return records, legacyValues
end

-- Backward-compatible helper retained for third-party code that still asks the registry for a total.
-- New RFF valuation code does not use this because v2 records must pass through RFF's native valuation/dedupe path.
function RFF_LivestockAssetRegistry:getExternalValue(farmId)
    local records, legacyValues = self:collectProviderRecords(farmId)
    local total = 0

    for _, value in pairs(legacyValues) do total = total + math.max(0, safeNumber(value)) end
    for _, asset in pairs(records) do
        local value = safeNumber(asset.marketValue or asset.value)
        local quantity = math.max(1, safeNumber(asset.count or asset.quantity or asset.numAnimals or 1))
        total = total + math.max(0, value) * quantity
    end

    return total
end
