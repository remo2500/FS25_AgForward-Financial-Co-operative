RFF_FarmValuation = {}

local function safeNumber(value)
    if type(value) == "number" and value == value then
        return value
    end
    return 0
end

local function addFillValue(total, fillTypeIndex, fillLevel)
    if fillTypeIndex == nil or fillLevel == nil or fillLevel <= 0 then
        return total
    end

    local fillType = g_fillTypeManager ~= nil and g_fillTypeManager.fillTypes[fillTypeIndex] or nil
    if fillType == nil then
        return total
    end

    local price = safeNumber(fillType.pricePerLiter)
    if price <= 0 then
        return total
    end

    return total + fillLevel * price
end

function RFF_FarmValuation:getBankBalance(farmId)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    if farm ~= nil and farm.money ~= nil then
        return safeNumber(farm.money)
    end

    if g_currentMission ~= nil and g_currentMission.getMoney ~= nil then
        return safeNumber(g_currentMission:getMoney())
    end

    return 0
end

function RFF_FarmValuation:getCash(farmId)
    return math.max(0, self:getBankBalance(farmId))
end

function RFF_FarmValuation:getFarmlandValue(farmId, repository)
    local total = 0
    if g_farmlandManager == nil then
        return total
    end

    for _, farmland in pairs(g_farmlandManager:getFarmlands()) do
        if g_farmlandManager:getFarmlandOwner(farmland.id) == farmId then
            local tenancy = repository ~= nil and repository:getTenancyByFarmland(farmland.id, true) or nil
            if tenancy == nil then
                total = total + safeNumber(farmland.price)
            end
        end
    end

    return total
end

function RFF_FarmValuation:getBuildingValue(farmId)
    local total = 0
    local placeableSystem = g_currentMission ~= nil and g_currentMission.placeableSystem or nil
    if placeableSystem == nil or placeableSystem.placeables == nil then
        return total
    end

    for _, placeable in pairs(placeableSystem.placeables) do
        local legalOwnerFarmId = RFF_TenancyAccessService ~= nil
            and RFF_TenancyAccessService.getPlaceableLegalOwnerFarmId ~= nil
            and RFF_TenancyAccessService:getPlaceableLegalOwnerFarmId(placeable)
            or placeable.ownerFarmId
        -- A landlord fixture uses the tenant farm ID only as an operational
        -- permission bridge. It remains outside the tenant's balance-sheet
        -- building assets and cannot support borrowing or increase net worth.
        if placeable.ownerFarmId == farmId and legalOwnerFarmId == farmId and placeable.getSellPrice ~= nil then
            local ok, value = pcall(placeable.getSellPrice, placeable)
            if ok and value ~= nil and value > 0 then
                total = total + value
            end
        end
    end

    return total
end

function RFF_FarmValuation:getEquipmentValue(farmId, repository)
    local total = 0
    local vehicleSystem = g_currentMission ~= nil and g_currentMission.vehicleSystem or nil
    if vehicleSystem == nil or vehicleSystem.vehicles == nil then
        return total
    end

    for _, vehicle in ipairs(vehicleSystem.vehicles) do
        local isOwned = vehicle.propertyState == nil or vehicle.propertyState == VehiclePropertyState.OWNED
        local typeName = vehicle.typeName or ""
        local excluded = typeName == "pallet" or typeName == "treeSaplingPallet" or typeName == "bigBag"

        local assetAgreement = repository ~= nil and repository:getAssetFinanceByVehicle(vehicle.uniqueId, true) or nil
        local isOperatingLease = assetAgreement ~= nil and assetAgreement.product == "OPERATING_LEASE"
        if vehicle.ownerFarmId == farmId and isOwned and not excluded and not isOperatingLease and vehicle.getSellPrice ~= nil then
            local ok, value = pcall(vehicle.getSellPrice, vehicle)
            if ok and value ~= nil and value > 0 then
                total = total + value
            end
        end
    end

    return total
end

function RFF_FarmValuation:isRLRMIndividual(animal)
    -- RLRM's persistent uniqueId is the authoritative identity.  Do not require
    -- isIndividual here: that lifecycle flag is not guaranteed to survive every
    -- non-standard holding location even though the same live RLRM Animal does.
    return type(animal) == "table"
        and animal.uniqueId ~= nil
        and tostring(animal.uniqueId) ~= ""
end

function RFF_FarmValuation:getDirectAnimalSellValue(animal)
    if animal ~= nil and animal.getSellPrice ~= nil then
        local ok, value = pcall(animal.getSellPrice, animal)
        if ok and type(value) == "number" and value == value and value >= 0 then
            return value
        end
    end
    return nil
end

function RFF_FarmValuation:getFallbackLivestockUnitValue(recordOrCluster, animalSystem)
    if recordOrCluster == nil or animalSystem == nil then return 0 end

    local subTypeIndex = recordOrCluster.subTypeIndex
    local subType = animalSystem.subTypes ~= nil and animalSystem.subTypes[subTypeIndex] or nil
    if subType == nil and animalSystem.getSubTypeByIndex ~= nil and subTypeIndex ~= nil then
        local ok, resolved = pcall(animalSystem.getSubTypeByIndex, animalSystem, subTypeIndex)
        if ok then subType = resolved end
    end

    if subType ~= nil and subType.sellPrice ~= nil and subType.sellPrice.get ~= nil then
        local age = safeNumber(recordOrCluster.age)
        local ok, unitPrice = pcall(subType.sellPrice.get, subType.sellPrice, age)
        if ok and type(unitPrice) == "number" and unitPrice == unitPrice then
            local healthRaw = recordOrCluster.health
            if healthRaw == nil then
                return math.max(0, unitPrice)
            end
            local health = math.max(0, math.min(100, safeNumber(healthRaw))) / 100
            return math.max(0, unitPrice * (0.4 + 0.6 * health))
        end
    end

    return 0
end

function RFF_FarmValuation:getLivestockObjectValue(clusterRef, count, fallbackRecord, animalSystem)
    count = math.max(1, safeNumber(count))

    -- Priority 1: an authoritative RLRM individual Animal. Its own sell-price path contains
    -- RLRM weight/genetics/health logic and therefore remains authoritative for valuation.
    if self:isRLRMIndividual(clusterRef) then
        local direct = self:getDirectAnimalSellValue(clusterRef)
        if direct ~= nil then return direct * count end
    end

    -- Priority 2: GIANTS/native cluster or animal sale-value calculation.
    local direct = self:getDirectAnimalSellValue(clusterRef)
    if direct ~= nil then return direct * count end

    -- Priority 3: RFF's existing subtype/age/health fallback when no native route is available.
    return self:getFallbackLivestockUnitValue(clusterRef or fallbackRecord, animalSystem) * count
end

function RFF_FarmValuation:getStableClusterId(cluster, fallbackId)
    if cluster == nil then return fallbackId end
    if self:isRLRMIndividual(cluster) then return nil end

    local clusterId = cluster.clusterId
    if clusterId == nil and cluster.getId ~= nil then
        local ok, value = pcall(cluster.getId, cluster)
        if ok then clusterId = value end
    end
    if clusterId == nil then clusterId = cluster.id end
    if clusterId == nil then clusterId = fallbackId end
    return clusterId
end

function RFF_FarmValuation:getCanonicalLivestockDedupeKey(farmId, record, clusterRef, fallbackId)
    -- RLRM id/idFull are intentionally NEVER used as persistent identity. uniqueId is canonical.
    if self:isRLRMIndividual(clusterRef) then
        return string.format("rlrm:%s:%s", tostring(farmId), tostring(clusterRef.uniqueId))
    end

    -- If a provider has supplied the canonical identity, use it for non-RLRM records.
    if record ~= nil and type(record.dedupeKey) == "string" and record.dedupeKey ~= "" then
        return record.dedupeKey
    end

    local animalTypeIndex = record ~= nil and record.animalTypeIndex or (clusterRef ~= nil and clusterRef.animalTypeIndex or nil)
    local subTypeIndex = record ~= nil and record.subTypeIndex or (clusterRef ~= nil and clusterRef.subTypeIndex or nil)
    if animalTypeIndex == nil and subTypeIndex ~= nil and g_currentMission ~= nil and g_currentMission.animalSystem ~= nil and g_currentMission.animalSystem.getTypeIndexBySubTypeIndex ~= nil then
        local ok, resolvedType = pcall(g_currentMission.animalSystem.getTypeIndexBySubTypeIndex, g_currentMission.animalSystem, subTypeIndex)
        if ok then animalTypeIndex = resolvedType end
    end
    local clusterId = record ~= nil and record.clusterId or nil
    if clusterId == nil then clusterId = self:getStableClusterId(clusterRef, fallbackId) end

    if clusterId ~= nil then
        return string.format("giants:%s:%s:%s:%s", tostring(farmId), tostring(animalTypeIndex or 0), tostring(subTypeIndex or 0), tostring(clusterId))
    end

    if record ~= nil and record.persistentId ~= nil and tostring(record.persistentId) ~= "" then
        return string.format("external:%s:%s:%s", tostring(record.providerId or record.source or "provider"), tostring(farmId), tostring(record.persistentId))
    end

    return string.format("runtime:%s:%s:%s:%s", tostring(farmId), tostring(animalTypeIndex or 0), tostring(subTypeIndex or 0), tostring(fallbackId or clusterRef))
end

function RFF_FarmValuation:getLivestockSourceBucket(record)
    local source = tostring((record ~= nil and (record.source or record.providerId)) or "external")
    local lower = string.lower(source)
    if string.find(lower, "freeform", 1, true) ~= nil then return "freeform" end
    if string.find(lower, "goldenhoof", 1, true) ~= nil or string.find(lower, "golden_hoof", 1, true) ~= nil or string.find(lower, "golden hoof", 1, true) ~= nil then return "goldenHoof" end
    return source
end

local function formatLivestockDiagnosticMoney(value)
    local whole = math.floor(math.max(0, safeNumber(value)) + 0.5)
    local text = tostring(whole)
    while true do
        local updated, count = string.gsub(text, "^(%-?%d+)(%d%d%d)", "%1,%2")
        text = updated
        if count == 0 then break end
    end
    return "£" .. text
end

local function getSharedDerwenFarmingApi()
    -- Participating Derwen mods publish one shared API singleton into GIANTS'
    -- common Lua root.  RFF only consumes it; it does not source or duplicate
    -- the Derwen API implementation.
    local api = rawget(_G, "g_derwenFarming")
    if api ~= nil then return api end

    local globalMeta = getmetatable(_G)
    if globalMeta ~= nil and type(globalMeta.__index) == "table" then
        api = rawget(globalMeta.__index, "g_derwenFarming")
        if api == nil then api = rawget(globalMeta.__index, "DerwenFarming") end
    end
    return api
end

function RFF_FarmValuation:getDerwenGrazingLivestock(farmId)
    local records = {}
    local stats = {available = false, providers = 0, areas = 0, clusters = 0, errors = 0}
    local handledBuckets = {}
    local api = getSharedDerwenFarmingApi()

    if api == nil or type(api.getProviders) ~= "function" or type(api.callProvider) ~= "function" then
        return records, stats, handledBuckets
    end

    local okProviders, providers = pcall(api.getProviders, api, "grazing.area", false)
    if not okProviders or type(providers) ~= "table" then
        stats.errors = stats.errors + 1
        return records, stats, handledBuckets
    end

    stats.available = true
    local context = {farmId = farmId, silent = true, consumer = "RealisticFarmFinance"}

    for _, entry in ipairs(providers) do
        local providerId = type(entry) == "table" and entry.providerId or nil
        if providerId ~= nil then
            stats.providers = stats.providers + 1
            local okAreas, areas = api:callProvider("grazing.area", providerId, "getAreas", {}, context)
            if okAreas and type(areas) == "table" then
                local providerBucket = self:getLivestockSourceBucket({source = providerId})
                if providerBucket == "freeform" or providerBucket == "goldenHoof" then
                    -- The existing Derwen grazing/transfer contracts are authoritative
                    -- for FP/GH.  Their older RFF-specific adapters are ignored below.
                    handledBuckets[providerBucket] = true
                end

                for _, area in ipairs(areas) do
                    if type(area) == "table" then
                        stats.areas = stats.areas + 1
                        local transferProviderId = area.transferProviderId
                        if transferProviderId ~= nil then
                            local clusterContext = {
                                farmId = farmId,
                                sourceArea = area,
                                silent = true,
                                consumer = "RealisticFarmFinance"
                            }
                            local okClusters, clusters = api:callProvider(
                                "animal.transfer.endpoint",
                                transferProviderId,
                                "getAreaClusters",
                                {},
                                clusterContext
                            )
                            if okClusters and type(clusters) == "table" then
                                local source = area.bridgeProviderId or area.providerId or providerId
                                for _, cluster in ipairs(clusters) do
                                    if type(cluster) == "table" and cluster.isDead ~= true then
                                        stats.clusters = stats.clusters + 1
                                        records[#records + 1] = {
                                            farmId = area.farmId or farmId,
                                            source = source,
                                            providerId = providerId,
                                            locationType = area.sourceType or area.locationType,
                                            locationId = area.areaId or area.sourceId,
                                            animalTypeIndex = area.animalTypeIndex,
                                            subTypeIndex = cluster.subTypeIndex,
                                            clusterRef = cluster
                                        }
                                    end
                                end
                            else
                                stats.errors = stats.errors + 1
                            end
                        else
                            stats.errors = stats.errors + 1
                        end
                    end
                end
            else
                stats.errors = stats.errors + 1
            end
        end
    end

    return records, stats, handledBuckets
end

function RFF_FarmValuation:getLivestockBreakdown(farmId)
    local result = {
        farmId = farmId,
        native = 0,
        external = {},
        duplicatesSkipped = 0,
        total = 0,
        seen = {},
        derwen = {available = false, providers = 0, areas = 0, clusters = 0, errors = 0}
    }

    local placeableSystem = g_currentMission ~= nil and g_currentMission.placeableSystem or nil
    local animalSystem = g_currentMission ~= nil and g_currentMission.animalSystem or nil

    local function addRecordValue(sourceBucket, dedupeKey, value, count)
        count = math.max(1, safeNumber(count))
        if dedupeKey ~= nil and result.seen[dedupeKey] then
            result.duplicatesSkipped = result.duplicatesSkipped + count
            return false
        end
        if dedupeKey ~= nil then result.seen[dedupeKey] = true end

        value = math.max(0, safeNumber(value))
        if sourceBucket == "native" then
            result.native = result.native + value
        else
            result.external[sourceBucket] = safeNumber(result.external[sourceBucket]) + value
        end
        result.total = result.total + value
        return true
    end

    -- Native husbandries are scanned first and therefore win deduplication if an external provider
    -- accidentally still exposes an animal that has already returned to a conventional husbandry.
    if placeableSystem ~= nil and animalSystem ~= nil then
        for _, placeable in pairs(placeableSystem.placeables or {}) do
            local animalSpec = placeable.spec_husbandryAnimals
            if placeable.ownerFarmId == farmId and animalSpec ~= nil and animalSpec.clusterSystem ~= nil then
                local clusterSystem = animalSpec.clusterSystem
                local usedIndividualAnimals = false
                local placeableId = placeable.uniqueId or placeable.id or placeable.rootNode or tostring(placeable)

                -- RLRM exposes authoritative individual animals here. Value each individual through
                -- exactly the same path used when FP/GH later hands the same Animal back via clusterRef.
                if type(clusterSystem.animals) == "table" then
                    for animalIndex, animal in pairs(clusterSystem.animals) do
                        if type(animal) == "table" and animal.isDead ~= true and safeNumber(animal.numAnimals or 1) > 0 then
                            local count = math.max(1, safeNumber(animal.numAnimals or 1))
                            local directValue = self:getDirectAnimalSellValue(animal)
                            local key = self:getCanonicalLivestockDedupeKey(farmId, nil, animal, string.format("%s:%s", tostring(placeableId), tostring(animalIndex)))
                            local value = directValue ~= nil and (directValue * count) or self:getLivestockObjectValue(animal, count, animal, animalSystem)
                            addRecordValue("native", key, value, count)
                            if directValue ~= nil or self:isRLRMIndividual(animal) then usedIndividualAnimals = true end
                        end
                    end
                end

                if not usedIndividualAnimals then
                    for clusterIndex, cluster in pairs(clusterSystem.clusters or {}) do
                        if type(cluster) == "table" and cluster.isDead ~= true then
                            local count = safeNumber(cluster.numAnimals)
                            if count <= 0 then count = 1 end
                            local fallbackId = string.format("%s:%s", tostring(placeableId), tostring(clusterIndex))
                            local key = self:getCanonicalLivestockDedupeKey(farmId, nil, cluster, fallbackId)
                            local value = self:getLivestockObjectValue(cluster, count, cluster, animalSystem)
                            addRecordValue("native", key, value, count)
                        end
                    end
                end
            end
        end
    end

    -- Freeform Pastures and Golden Hoof already expose their authoritative resident
    -- animals through the shared Derwen grazing/transfer contracts used by herding.
    -- Reuse those live objects directly instead of maintaining a second FP/GH inventory API.
    local derwenHandledBuckets = {}
    if g_server ~= nil then
        local derwenRecords, derwenStats, handledBuckets = self:getDerwenGrazingLivestock(farmId)
        result.derwen = derwenStats or result.derwen
        derwenHandledBuckets = handledBuckets or {}

        for recordIndex, record in ipairs(derwenRecords or {}) do
            local clusterRef = record.clusterRef
            local count = 0
            if clusterRef ~= nil and type(clusterRef.getNumAnimals) == "function" then
                local okCount, resolvedCount = pcall(clusterRef.getNumAnimals, clusterRef)
                if okCount then count = safeNumber(resolvedCount) end
            end
            if count <= 0 and clusterRef ~= nil then count = safeNumber(clusterRef.numAnimals) end
            if count <= 0 then count = 1 end

            local fallbackId = string.format(
                "%s:%s:%s",
                tostring(record.providerId or record.source or "derwen"),
                tostring(record.locationId or "location"),
                tostring(recordIndex)
            )
            local dedupeKey = self:getCanonicalLivestockDedupeKey(farmId, record, clusterRef, fallbackId)
            local value = self:getLivestockObjectValue(clusterRef, count, record, animalSystem)
            addRecordValue(self:getLivestockSourceBucket(record), dedupeKey, value, count)
        end
    end

    -- Keep RFF's generic external registry for third-party/non-Derwen livestock systems.
    -- If the Derwen contracts are active for FP/GH, ignore their old test adapters so the
    -- same animals are not discovered through two parallel mechanisms.
    if RFF_LivestockAssetRegistry ~= nil and g_server ~= nil then
        local records, legacyValues = RFF_LivestockAssetRegistry:collectProviderRecords(farmId)

        for recordIndex, record in ipairs(records or {}) do
            local sourceBucket = self:getLivestockSourceBucket(record)
            if derwenHandledBuckets[sourceBucket] ~= true then
                local recordFarmId = tonumber(record.farmId) or record.farmId
                if recordFarmId == nil or tostring(recordFarmId) == tostring(farmId) then
                    local clusterRef = record.clusterRef
                    local count = safeNumber(record.count or record.quantity or record.numAnimals)
                    if count <= 0 then count = clusterRef ~= nil and safeNumber(clusterRef.numAnimals) or 1 end
                    if count <= 0 then count = 1 end

                    local fallbackId = string.format("%s:%s:%s", tostring(record.providerId or record.source or "provider"), tostring(record.locationId or "location"), tostring(recordIndex))
                    local dedupeKey = self:getCanonicalLivestockDedupeKey(farmId, record, clusterRef, fallbackId)
                    local value = self:getLivestockObjectValue(clusterRef, count, record, animalSystem)
                    addRecordValue(sourceBucket, dedupeKey, value, count)
                end
            end
        end

        for providerId, value in pairs(legacyValues or {}) do
            local record = {providerId = providerId, source = providerId}
            local bucket = self:getLivestockSourceBucket(record)
            if derwenHandledBuckets[bucket] ~= true then
                local amount = math.max(0, safeNumber(value))
                result.external[bucket] = safeNumber(result.external[bucket]) + amount
                result.total = result.total + amount
            end
        end
    end

    self.lastLivestockBreakdowns = self.lastLivestockBreakdowns or {}
    self.lastLivestockBreakdowns[farmId] = result
    return result
end

function RFF_FarmValuation:getLivestockValue(farmId)
    return self:getLivestockBreakdown(farmId).total
end

function RFF_FarmValuation:printLivestockBreakdown(farmId, useCached)
    self.lastLivestockBreakdowns = self.lastLivestockBreakdowns or {}
    local breakdown = useCached == true and self.lastLivestockBreakdowns[farmId] or nil
    if breakdown == nil then breakdown = self:getLivestockBreakdown(farmId) end

    local freeform = safeNumber(breakdown.external.freeform)
    local goldenHoof = safeNumber(breakdown.external.goldenHoof)
    local extras = {}
    for source, value in pairs(breakdown.external or {}) do
        if source ~= "freeform" and source ~= "goldenHoof" and safeNumber(value) > 0 then
            table.insert(extras, string.format("%s=%s", tostring(source), formatLivestockDiagnosticMoney(value)))
        end
    end
    table.sort(extras)

    local suffix = #extras > 0 and (" " .. table.concat(extras, " ")) or ""
    print(string.format(
        "[RFF] Livestock assets farm=%s native=%s freeform=%s goldenHoof=%s duplicatesSkipped=%d total=%s%s",
        tostring(farmId),
        formatLivestockDiagnosticMoney(breakdown.native),
        formatLivestockDiagnosticMoney(freeform),
        formatLivestockDiagnosticMoney(goldenHoof),
        math.floor(safeNumber(breakdown.duplicatesSkipped)),
        formatLivestockDiagnosticMoney(breakdown.total),
        suffix
    ))
    local derwen = breakdown.derwen or {}
    print(string.format(
        "[RFF] Derwen grazing livestock api=%s providers=%d areas=%d clusters=%d errors=%d",
        derwen.available == true and "active" or "unavailable",
        math.floor(safeNumber(derwen.providers)),
        math.floor(safeNumber(derwen.areas)),
        math.floor(safeNumber(derwen.clusters)),
        math.floor(safeNumber(derwen.errors))
    ))
    return breakdown
end

function RFF_FarmValuation:getInventoryValue(farmId)
    local total = 0
    local mission = g_currentMission
    if mission == nil then
        return total
    end

    -- Contents carried in owned vehicles, including pallets and trailers.
    if mission.vehicleSystem ~= nil then
        for _, vehicle in pairs(mission.vehicleSystem.vehicles or {}) do
            local isOwned = vehicle.propertyState == nil or vehicle.propertyState == VehiclePropertyState.OWNED
            if vehicle.ownerFarmId == farmId and isOwned and vehicle.spec_fillUnit ~= nil then
                for _, fillUnit in pairs(vehicle.spec_fillUnit.fillUnits or {}) do
                    total = addFillValue(total, fillUnit.fillType, safeNumber(fillUnit.fillLevel))
                end
            end
        end
    end

    -- Loose bales owned by the farm.
    if mission.itemSystem ~= nil then
        for _, wrapper in pairs(mission.itemSystem.itemsToSave or {}) do
            local item = wrapper.item
            if item ~= nil and item.ownerFarmId == farmId and item.fillType ~= nil and item.fillLevel ~= nil then
                total = addFillValue(total, item.fillType, safeNumber(item.fillLevel))
            end
        end
    end

    -- Owned farm storage. Calls are guarded because map placeables vary considerably.
    if mission.placeableSystem ~= nil then
        for _, placeable in pairs(mission.placeableSystem.placeables or {}) do
            if placeable.ownerFarmId == farmId then
                if placeable.spec_silo ~= nil and placeable.spec_silo.getFillLevels ~= nil then
                    local ok, levels = pcall(placeable.spec_silo.getFillLevels, placeable.spec_silo)
                    if ok and levels ~= nil then
                        for fillTypeIndex, fillLevel in pairs(levels) do
                            total = addFillValue(total, fillTypeIndex, safeNumber(fillLevel))
                        end
                    end
                end

                if placeable.spec_bunkerSilo ~= nil and placeable.spec_bunkerSilo.bunkerSilo ~= nil then
                    local bunker = placeable.spec_bunkerSilo.bunkerSilo
                    local fillTypeIndex = bunker.inputFillType
                    if BunkerSilo ~= nil and (bunker.state == BunkerSilo.STATE_FERMENTED or bunker.state == BunkerSilo.STATE_DRAIN) then
                        fillTypeIndex = bunker.outputFillType
                    end
                    total = addFillValue(total, fillTypeIndex, safeNumber(bunker.fillLevel))
                end

                if placeable.spec_husbandry ~= nil and placeable.spec_husbandry.storage ~= nil then
                    for fillTypeIndex, fillLevel in pairs(placeable.spec_husbandry.storage.fillLevels or {}) do
                        total = addFillValue(total, fillTypeIndex, safeNumber(fillLevel))
                    end
                end
            end
        end
    end

    -- Finished goods waiting at owned production points.
    if mission.productionChainManager ~= nil then
        for _, production in pairs(mission.productionChainManager.productionPoints or {}) do
            if production.ownerFarmId == farmId and production.storage ~= nil then
                for _, fillTypeIndex in pairs(production.outputFillTypeIdsArray or {}) do
                    local ok, fillLevel = pcall(production.storage.getFillLevel, production.storage, fillTypeIndex)
                    if ok then
                        total = addFillValue(total, fillTypeIndex, safeNumber(fillLevel))
                    end
                end
            end
        end
    end

    return total
end

function RFF_FarmValuation:getLiabilities(farmId, repository)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    if farm == nil then
        return 0
    end

    local vanillaLoan = math.max(0, safeNumber(farm.loan))
    local rffLoans = repository ~= nil and repository:getOutstandingLoanBalance(farmId) or 0
    local assetFinance = repository ~= nil and repository:getOutstandingAssetFinanceBalance(farmId) or 0
    local bankAccountDebt = repository ~= nil and repository.getBankAccountLiability ~= nil and repository:getBankAccountLiability(farmId) or math.max(0, -self:getBankBalance(farmId))
    local businessObligations = repository ~= nil and repository.getOutstandingBusinessObligations ~= nil and repository:getOutstandingBusinessObligations(farmId) or 0
    local cropAdvances = repository ~= nil and repository.getCropAdvanceLiability ~= nil and repository:getCropAdvanceLiability(farmId) or 0
    return vanillaLoan + math.max(0, safeNumber(rffLoans)) + math.max(0, safeNumber(assetFinance)) + math.max(0, safeNumber(bankAccountDebt)) + math.max(0, safeNumber(businessObligations)) + cropAdvances
end

function RFF_FarmValuation:calculate(farmId, repository)
    local value = {
        bankBalance = self:getBankBalance(farmId),
        cash = self:getCash(farmId),
        farmland = self:getFarmlandValue(farmId, repository),
        buildings = self:getBuildingValue(farmId),
        equipment = self:getEquipmentValue(farmId, repository),
        livestock = self:getLivestockValue(farmId),
        inventory = self:getInventoryValue(farmId),
        refundableDeposits = repository ~= nil and (repository:getRefundableTenancyDeposits(farmId) + repository:getRefundableAssetFinanceDeposits(farmId)) or 0,
        liabilities = self:getLiabilities(farmId, repository)
    }

    value.savings = repository ~= nil and repository.savingsService ~= nil and repository.savingsService:total(farmId) or 0
    value.investments = repository ~= nil and repository.investmentService ~= nil and repository.investmentService:total(farmId) or 0
    value.refundableDeposits = value.refundableDeposits + (repository ~= nil and repository.dealershipService ~= nil and repository.dealershipService:total(farmId) or 0)
    value.totalAssets = value.cash + value.farmland + value.buildings + value.equipment + value.livestock + value.inventory + value.refundableDeposits + value.savings + value.investments
    value.netWorth = value.totalAssets - value.liabilities
    return value
end
