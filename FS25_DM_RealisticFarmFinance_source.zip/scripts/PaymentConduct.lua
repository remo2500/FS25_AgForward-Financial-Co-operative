RFF_PaymentConduct = {}

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

RFF_PaymentConduct.GRADE_RANK = {A=1, B=2, C=3, D=4}
RFF_PaymentConduct.RANK_GRADE = {[1]="A", [2]="B", [3]="C", [4]="D"}

function RFF_PaymentConduct:getArrears(entity)
    if entity == nil then return 0 end
    local principal = math.max(0, safeNumber(entity.arrearsPrincipal))
    local interest = math.max(0, safeNumber(entity.arrearsInterest))
    local rent = math.max(0, safeNumber(entity.arrearsRent))
    local fees = math.max(0, safeNumber(entity.arrearsFees))
    local balance = principal + interest + rent + fees
    entity.arrearsBalance = balance
    return balance
end

function RFF_PaymentConduct:recordMissed(entity, repository, principal, interest, rent)
    if entity == nil then return 0 end
    entity.arrearsPrincipal = math.max(0, safeNumber(entity.arrearsPrincipal)) + math.max(0, safeNumber(principal))
    entity.arrearsInterest = math.max(0, safeNumber(entity.arrearsInterest)) + math.max(0, safeNumber(interest))
    entity.arrearsRent = math.max(0, safeNumber(entity.arrearsRent)) + math.max(0, safeNumber(rent))
    entity.arrearsFees = math.max(0, safeNumber(entity.arrearsFees))
    entity.missedPayments = math.max(0, safeNumber(entity.missedPayments)) + 1
    entity.consecutiveMissedPayments = math.max(0, safeNumber(entity.consecutiveMissedPayments)) + 1
    entity.maxConsecutiveMissedPayments = math.max(safeNumber(entity.maxConsecutiveMissedPayments), entity.consecutiveMissedPayments)
    entity.lastMissedPeriod = repository ~= nil and repository:getCurrentPeriodIndex() or safeNumber(entity.lastPaymentPeriod)
    return self:getArrears(entity)
end

function RFF_PaymentConduct:recordSuccessfulScheduledPayment(entity, repository)
    if entity == nil then return end
    entity.consecutiveMissedPayments = 0
    entity.lastSuccessfulPaymentPeriod = repository ~= nil and repository:getCurrentPeriodIndex() or safeNumber(entity.lastPaymentPeriod)
end

function RFF_PaymentConduct:recordArrearsCleared(entity, repository)
    if entity == nil then return end
    entity.arrearsPrincipal = 0
    entity.arrearsInterest = 0
    entity.arrearsRent = 0
    entity.arrearsFees = 0
    entity.arrearsBalance = 0
    entity.arrearsAgeMonths = 0
    entity.arrearsStage = "CURRENT"
    entity.recoveryEligible = false
    entity.currentDefault = false
    entity.defaultRecorded = false
    entity.consecutiveMissedPayments = 0
    entity.lastArrearsClearedPeriod = repository ~= nil and repository:getCurrentPeriodIndex() or 0
end

function RFF_PaymentConduct:capGrade(grade, minimumGrade)
    if grade == nil or minimumGrade == nil then return grade end
    local current = self.GRADE_RANK[grade] or 4
    local minimum = self.GRADE_RANK[minimumGrade] or 4
    return self.RANK_GRADE[math.max(current, minimum)] or "D"
end

function RFF_PaymentConduct:evaluate(repository, farmId)
    local record = repository ~= nil and repository:getRepaymentRecord(farmId) or {}
    local testOverride = RFF_TestCreditOverride ~= nil and RFF_TestCreditOverride[farmId] or nil
    if testOverride ~= nil and testOverride.enabled == true then
        return {
            key = "rff_conduct_excellent", code = "EXCELLENT",
            currentArrears = 0, consecutiveMissedPayments = 0, maxConsecutiveMissedPayments = 0,
            missedPayments = 0, lastMissedPeriod = 0, monthsSinceLastMiss = nil,
            agreementsInArrears = 0, agreementsInDefault = 0, defaultEvents = 0,
            forcedPropertyRecoveryEvents = 0, lastForcedPropertyRecoveryPeriod = 0, monthsSincePropertyRecovery = nil,
            rateAdjustment = 0, minimumGrade = nil, declineNewCredit = false, testOverride = true
        }
    end
    local currentPeriod = repository ~= nil and repository:getCurrentPeriodIndex() or 0
    local lastMissed = math.max(0, safeNumber(record.lastMissedPeriod))
    local monthsSinceLastMiss = lastMissed > 0 and math.max(0, currentPeriod - lastMissed) or nil
    local arrears = math.max(0, safeNumber(record.currentArrears))
    local consecutive = math.max(0, safeNumber(record.consecutiveMissedPayments))
    local lifetimeMissed = math.max(0, safeNumber(record.missedPayments))
    local propertyRecoveryEvents = math.max(0, safeNumber(record.forcedPropertyRecoveryEvents))
    local lastPropertyRecovery = math.max(0, safeNumber(record.lastForcedPropertyRecoveryPeriod))
    local monthsSincePropertyRecovery = lastPropertyRecovery > 0 and math.max(0, currentPeriod - lastPropertyRecovery) or nil

    local result = {
        key = "rff_conduct_excellent",
        code = "EXCELLENT",
        currentArrears = arrears,
        consecutiveMissedPayments = consecutive,
        maxConsecutiveMissedPayments = math.max(0, safeNumber(record.maxConsecutiveMissedPayments)),
        missedPayments = lifetimeMissed,
        lastMissedPeriod = lastMissed,
        monthsSinceLastMiss = monthsSinceLastMiss,
        agreementsInArrears = math.max(0, safeNumber(record.agreementsInArrears)),
        agreementsInDefault = math.max(0, safeNumber(record.agreementsInDefault)),
        defaultEvents = math.max(0, safeNumber(record.defaultEvents)),
        forcedPropertyRecoveryEvents = propertyRecoveryEvents,
        lastForcedPropertyRecoveryPeriod = lastPropertyRecovery,
        monthsSincePropertyRecovery = monthsSincePropertyRecovery,
        rateAdjustment = 0,
        minimumGrade = nil,
        declineNewCredit = false
    }

    -- An unresolved recovery/default liability remains a live default even after the original
    -- asset-finance arrears have been crystallised into a separate shortfall balance.
    if result.agreementsInDefault > 0 and arrears <= 0.01 then
        result.code = "DEFAULT_LIABILITY"
        result.key = "rff_conduct_default_liability"
        result.rateAdjustment = 3.00
        result.minimumGrade = "D"
        result.declineNewCredit = true
        return result
    end

    -- Current arrears are treated much more seriously than historic, cured misses. RFF does not
    -- use a consumer-style numeric credit score: lenders see concrete payment conduct instead.
    if arrears > 0.01 then
        local severe = consecutive >= 3 or result.maxConsecutiveMissedPayments >= 3 or result.agreementsInDefault > 0
        result.code = severe and "SEVERE_ARREARS" or "ARREARS"
        result.key = severe and "rff_conduct_severe_arrears" or "rff_conduct_arrears"
        result.rateAdjustment = severe and 2.50 or 1.50
        result.minimumGrade = "D"
        result.declineNewCredit = true
        return result
    end

    -- Forced lender possession of farmland is a severe secured-property credit event.
    -- Unlike vehicle recovery, its effect deliberately survives well beyond the cured missed
    -- payments that caused it: six periods of normal-credit exclusion, then progressively
    -- reducing grade/rate penalties through 36 clean periods. The development credit override
    -- above can still bypass this for rapid testing without rewriting saved history.
    if propertyRecoveryEvents > 0 and monthsSincePropertyRecovery ~= nil then
        if monthsSincePropertyRecovery <= 6 then
            result.code = "MORTGAGE_POSSESSION_SEVERE"
            result.key = "rff_conduct_mortgage_possession_severe"
            result.rateAdjustment = 4.00
            result.minimumGrade = "D"
            result.declineNewCredit = true
            return result
        elseif monthsSincePropertyRecovery <= 12 then
            result.code = "MORTGAGE_POSSESSION_POOR"
            result.key = "rff_conduct_mortgage_possession_poor"
            result.rateAdjustment = 3.00
            result.minimumGrade = "D"
            return result
        elseif monthsSincePropertyRecovery <= 24 then
            result.code = "MORTGAGE_POSSESSION_RECOVERING"
            result.key = "rff_conduct_mortgage_possession_recovering"
            result.rateAdjustment = 1.50
            result.minimumGrade = "C"
            return result
        elseif monthsSincePropertyRecovery <= 36 then
            result.code = "MORTGAGE_POSSESSION_HISTORIC"
            result.key = "rff_conduct_mortgage_possession_historic"
            result.rateAdjustment = 0.50
            result.minimumGrade = "B"
            return result
        end
    end

    if monthsSinceLastMiss ~= nil then
        if monthsSinceLastMiss <= 3 then
            result.code = "WATCH"
            result.key = "rff_conduct_watch"
            result.rateAdjustment = 1.00
            result.minimumGrade = "C"
        elseif monthsSinceLastMiss <= 6 then
            result.code = "RECOVERING"
            result.key = "rff_conduct_recovering"
            result.rateAdjustment = 0.75
            result.minimumGrade = "C"
        elseif monthsSinceLastMiss <= 12 then
            result.code = "RECOVERING"
            result.key = "rff_conduct_recovering"
            result.rateAdjustment = 0.25
            result.minimumGrade = "B"
        elseif lifetimeMissed > 0 then
            result.code = "GOOD"
            result.key = "rff_conduct_good"
        end
    elseif lifetimeMissed > 0 then
        result.code = "GOOD"
        result.key = "rff_conduct_good"
    end

    return result
end
