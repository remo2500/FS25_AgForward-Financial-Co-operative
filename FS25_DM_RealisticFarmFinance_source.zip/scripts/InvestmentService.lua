-- Original economy-linked investment model. No trading randomness or future-state access.
RFF_InvestmentService={}
RFF_InvestmentService.__index=RFF_InvestmentService
local I=RFF_InvestmentService
I.PRODUCTS={
    {id="CONSERVATIVE",name="Conservative fund",months=12,fee=.6},
    {id="AGRICULTURAL",name="Agricultural growth fund",months=24,fee=1.0}
}
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<math.huge end
local function clamp(n,a,b) return math.max(a,math.min(b,n)) end
local function round(n) return math.floor(n*100+.5)/100 end
local function server() return g_currentMission~=nil and g_currentMission:getIsServer() end
local function farm(id) return g_farmManager~=nil and g_farmManager:getFarmById(id) or nil end
function I.product(id) for _,p in ipairs(I.PRODUCTS) do if p.id==id then return p end end end
function I.new(repository,savings)
    local self=setmetatable({repository=repository,savings=savings,timer=0},I)
    repository.investmentService=self
    local mod=RFF_RealisticFarmFinance and RFF_RealisticFarmFinance.modName or g_currentModName
    self.transferType=MoneyType and MoneyType.register and MoneyType.register("rffInvestmentTransfer","rff_invest_transfer",mod) or nil
    return self
end
function I:clock() return self.savings:clock() end
function I:date(t) return self.savings:date(t) end
-- Annualised model inputs converted to bounded monthly changes. This is not an offered APR.
-- Management charges are embedded in valuation, including during a declining market.
function I.monthlyReturn(e,product)
    local p=I.product(product)
    if not p or not e then return nil end
    for _,k in ipairs({"baseRate","activity","inflation","credit"}) do if not finite(e[k]) then return nil end end
    local inflation=math.max(0,e.inflation-2.5)
    local gross
    if product=="CONSERVATIVE" then gross=clamp(e.baseRate+1.5+1.6*e.activity-3*e.credit-1.2*inflation,-9,12)
    else gross=clamp(8+4*e.activity-4*e.credit-1.5*inflation,-24,24) end
    return (gross-p.fee)/1200
end
function I:records(farmId)
    local list={};for _,a in ipairs(self.repository.investments or {}) do if a.farmId==farmId then list[#list+1]=a end end;return list
end
function I:find(farmId,id) for _,a in ipairs(self:records(farmId)) do if a.id==id then return a end end end
function I:total(farmId)
    local value=0;for _,a in ipairs(self:records(farmId)) do if a.status~="CLOSED" then value=value+a.value end end;return value
end
function I:stateAt(period)
    local e=self.repository.economyState
    if e and e.period==period then return e end
    for _,h in ipairs(e and e.history or {}) do if h.period==period then return h end end
    return nil -- never invent a missing historic return from today's conditions
end
function I:accrue(a,now)
    if a.status=="CLOSED" then return end
    local stop=a.status=="NOTICE" and math.min(now,a.due) or now
    while a.lastValued<stop-.000000001 do
        local t=a.lastValued;local ending=math.min(stop,math.floor(t)+1)
        local change=I.monthlyReturn(self:stateAt(math.floor(t)),a.product)
        if change==nil then return end
        a.value=a.value*(1+change)^(ending-t)
        a.lastValued=ending
    end
end
function I:money(id,amount,text,gain)
    if amount==0 then return end
    self.repository:setNextTransactionDescription(id,text)
    g_currentMission:addMoney(amount,id,gain and MoneyType.OTHER or self.transferType,true,true)
end
function I:close(a,now)
    if a.status~="NOTICE" or a.lastValued<a.due-.000000001 or farm(a.farmId)==nil then return end
    a.proceeds=round(a.value);a.realised=a.proceeds-a.principal;a.closed=now;a.status="CLOSED"
    -- Return only recovered capital. A capital loss is not a second cash debit.
    self:money(a.farmId,math.min(a.principal,a.proceeds),"Investment capital returned I-"..a.id,false)
    if a.realised>0 then self:money(a.farmId,a.realised,"Realised investment gain I-"..a.id,true) end
    if RFF_NotificationService and RFF_NotificationService.send then
        pcall(RFF_NotificationService.send,RFF_NotificationService,a.farmId,"Investment broker","Fund sale completed",
            string.format("I-%d returned %.2f to your account. Realised gain/loss: %+.2f. View Banking - Investments.",a.id,a.proceeds,a.realised),
            "investments","Investment sale completed. View Banking - Investments.",false)
    end
end
-- Called BEFORE each economy step, so even a long calendar jump uses every real intervening state.
function I:processTo(now)
    if not server() or not self.repository.loaded or self.processing or not finite(now) then return end
    self.processing=true
    for _,a in ipairs(self.repository.investments or {}) do
        self:accrue(a,now)
        if a.status=="NOTICE" and now>=a.due then self:close(a,a.due) end
    end
    self.processing=false
end
function I:process()
    local e=self.repository.economyState;if not e then return end
    self:processTo(math.min(self:clock(),e.period+1))
end
function I:update(dt)
    self.timer=self.timer-(dt or 0);if self.timer>0 then return end;self.timer=1000;self:process()
end
function I:quote(farmId,product,amount)
    local e=self.repository.economyState
    if not server() or not self.repository.loaded or not e or e.period~=math.floor(self:clock()) then return nil end
    if not I.product(product) or not finite(amount) or amount<100 or amount>10000000 or not finite(farmId) or farmId<=0 or not farm(farmId) then return nil end
    local last=0;for _,a in ipairs(self:records(farmId)) do last=math.max(last,a.id) end
    return {farmId=farmId,product=product,amount=round(amount),period=e.period,previousId=last}
end
function I:buy(q)
    if type(q)~="table" then return nil,"Please request a new investment quote." end
    local current=self:quote(q.farmId,q.product,q.amount)
    if not current or q.period~=current.period or q.previousId~=current.previousId then return nil,"The request changed. Please review and confirm again." end
    local f=farm(q.farmId)
    if not finite(f.money) or f.money<q.amount then return nil,"Insufficient current-account cash. Investments cannot use an overdraft." end
    if not self.transferType or not MoneyType.OTHER then return nil,"Investment money types are not ready." end
    self:process()
    local list=self.repository.investments or {};self.repository.investments=list
    local id=0;for _,a in ipairs(list) do id=math.max(id,a.id) end
    local now=self:clock();local p=I.product(q.product)
    local a={id=id+1,farmId=q.farmId,product=q.product,principal=current.amount,value=current.amount,opened=now,lastValued=now,
        unlock=now+p.months,due=0,status="ACTIVE",closed=0,proceeds=0,realised=0}
    list[#list+1]=a
    self:money(a.farmId,-a.principal,"Investment purchase I-"..a.id.." - "..p.name,false)
    return a
end
function I:sell(farmId,id)
    if not server() or not self.repository.loaded then return false,"Investments are server-only." end
    self:process();local a=self:find(farmId,id);local now=self:clock()
    if not a or a.status~="ACTIVE" then return false,"This holding is already on notice or closed." end
    if now<a.unlock then return false,"Minimum holding period ends "..self:date(a.unlock)..". No early sale." end
    if a.lastValued<now-.000000001 then return false,"Valuation is awaiting economic data. Please retry once it is current." end
    a.status="NOTICE";a.due=now+1
    return true,"Sale requested. Your full holding will be sold after one game month at its then-current value, which may be lower."
end
local FIELDS={"id","farmId","principal","value","opened","lastValued","unlock","due","closed","proceeds","realised"}
function I.save(repository,xml)
    for i,a in ipairs(repository.investments or {}) do
        local key="realisticFarmFinance.investments.holding("..(i-1)..")"
        for _,k in ipairs(FIELDS) do xml:setString(key.."#"..k,string.format("%.17g",a[k])) end
        xml:setString(key.."#product",a.product);xml:setString(key.."#status",a.status)
    end
end
function I.load(repository,xml)
    repository.investments={};local ids={};local i=0
    while xml:hasProperty("realisticFarmFinance.investments.holding("..i..")") do
        local key="realisticFarmFinance.investments.holding("..i..")";local a={};local valid=true
        for _,k in ipairs(FIELDS) do a[k]=tonumber(xml:getString(key.."#"..k));valid=valid and finite(a[k]) end
        a.product=xml:getString(key.."#product");a.status=xml:getString(key.."#status")
        if valid and I.product(a.product) and (a.status=="ACTIVE" or a.status=="NOTICE" or a.status=="CLOSED")
            and a.id>0 and a.id%1==0 and not ids[a.id] and a.farmId>0 and a.principal>=100 and a.value>=0
            and a.lastValued>=a.opened and a.unlock>=a.opened and (a.status~="NOTICE" or a.due>=a.unlock) then
            ids[a.id]=true;repository.investments[#repository.investments+1]=a
        else print("[RFF investments] Invalid holding "..i.." ignored. Restore a backup if unexpected.") end
        i=i+1
    end
end
function I:consoleStatus(action,months)
    local e=self.repository.economyState;if not e then return "Investments are not ready." end
    if string.upper(tostring(action or "STATUS"))=="SIMULATE" then
        local n=tonumber(months) or 60;if not finite(n) then return "Use SIMULATE 1..600." end;n=clamp(math.floor(n),1,600)
        local copy={history={}};for k,v in pairs(e) do if type(v)~="table" then copy[k]=v end end
        local low,growth=10000,10000
        for month=1,n do
            low=low*(1+I.monthlyReturn(copy,"CONSERVATIVE"));growth=growth*(1+I.monthlyReturn(copy,"AGRICULTURAL"))
            RFF_EconomyService.step(copy,false)
            if month%12==0 or month==n then print(string.format("[RFF investment TEST COPY] month %d | 10000 becomes conservative %.2f / agricultural %.2f",month,low,growth)) end
        end
        return "Simulation only. No money, holdings, live economy or saved seed changed. Not a forecast."
    end
    self:process()
    for _,a in ipairs(self:records(g_currentMission:getFarmId())) do print(string.format("[RFF investments] I-%d %s %s | cost %.2f value %.2f | gain/loss %+.2f | unlock %s",a.id,a.product,a.status,a.principal,a.value,a.value-a.principal,self:date(a.unlock))) end
    return "Investment records printed. SIMULATE 60 tests a copy; no real money or time changes."
end
