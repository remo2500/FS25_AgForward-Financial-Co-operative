RFF_BrokerService = {}
RFF_BrokerService.__index = RFF_BrokerService

RFF_BrokerService.STATUS_INSTRUCTED = "INSTRUCTED"
RFF_BrokerService.STATUS_LENDERS_APPROACHED = "LENDERS_APPROACHED"
RFF_BrokerService.STATUS_INDICATIVE_RESPONSES = "INDICATIVE_RESPONSES"
RFF_BrokerService.STATUS_OFFERS_PREPARING = "OFFERS_PREPARING"
RFF_BrokerService.STATUS_OFFERS_READY = "OFFERS_READY"
RFF_BrokerService.STATUS_ACCEPTED = "ACCEPTED"
RFF_BrokerService.STATUS_WITHDRAWN = "WITHDRAWN"
RFF_BrokerService.STATUS_EXPIRED = "EXPIRED"
RFF_BrokerService.STATUS_NO_OFFERS = "NO_OFFERS"

RFF_BrokerService.BROKER_ID = "AGRI_FINANCE_BROKER"
RFF_BrokerService.BROKER_FEE_PERCENT = 0.0050
RFF_BrokerService.BROKER_MIN_FEE = 350

RFF_BrokerService.LENDERS = {
    {
        id="RURAL_AGRI_BANK", nameKey="rff_lender_rural_agri_bank", styleKey="rff_lender_style_conservative",
        rateAdjustment=-0.35, collateralFactor=0.94, incomeFactor=0.95, feePercent=0.0060,
        propertyLtvMax=0.75, dscrFloor=1.15, securedLtvMax=0.50, securedOverallLtvMax=0.55, securedRateUplift=1.00
    },
    {
        id="COUNTY_COMMERCIAL", nameKey="rff_lender_county_commercial", styleKey="rff_lender_style_mainstream",
        rateAdjustment=0.05, collateralFactor=1.00, incomeFactor=1.00, feePercent=0.0080,
        propertyLtvMax=0.80, dscrFloor=1.00, securedLtvMax=0.60, securedOverallLtvMax=0.65, securedRateUplift=1.50
    },
    {
        id="AGRIGROWTH_FINANCE", nameKey="rff_lender_agrigrowth", styleKey="rff_lender_style_specialist",
        rateAdjustment=0.65, collateralFactor=1.08, incomeFactor=1.08, feePercent=0.0110,
        propertyLtvMax=0.85, dscrFloor=0.90, securedLtvMax=0.65, securedOverallLtvMax=0.75, securedRateUplift=2.25
    },
    {
        id="FRONTIER_CAPITAL", nameKey="rff_lender_frontier_capital", styleKey="rff_lender_style_alternative",
        rateAdjustment=1.75, collateralFactor=1.16, incomeFactor=1.12, feePercent=0.0175,
        propertyLtvMax=0.90, dscrFloor=0.80, securedLtvMax=0.70, securedOverallLtvMax=0.85, securedRateUplift=3.25
    }
}

local function safeNumber(value)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then return value end
    return 0
end

local function roundDown(value, step)
    step = math.max(1, safeNumber(step))
    return math.floor(math.max(0, safeNumber(value)) / step) * step
end

local function getFarmMoney(farmId)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    return farm ~= nil and safeNumber(farm.money) or 0
end

local function feeMoneyType()
    return MoneyType ~= nil and (MoneyType.OTHER or MoneyType.LOAN_INTEREST) or nil
end

function RFF_BrokerService.new(repository, loanService, applicationService, propertyFinance)
    local self = setmetatable({}, RFF_BrokerService)
    self.repository = repository
    self.loanService = loanService
    self.applicationService = applicationService
    self.propertyFinance = propertyFinance
    self.relationshipService = nil
    self.marketService = nil
    return self
end

function RFF_BrokerService:setRelationshipService(service)
    self.relationshipService = service
end

function RFF_BrokerService:setMarketService(service)
    self.marketService = service
end

function RFF_BrokerService:getCurrentHourStamp()
    return self.applicationService ~= nil and self.applicationService:getCurrentHourStamp() or 0
end

function RFF_BrokerService:getPeriodHours()
    return self.applicationService ~= nil and self.applicationService:getPeriodHours() or 72
end

function RFF_BrokerService:isPending(case)
    if case == nil then return false end
    return case.status == self.STATUS_INSTRUCTED
        or case.status == self.STATUS_LENDERS_APPROACHED
        or case.status == self.STATUS_INDICATIVE_RESPONSES
        or case.status == self.STATUS_OFFERS_PREPARING
end

function RFF_BrokerService:isOpen(case)
    return self:isPending(case) or (case ~= nil and case.status == self.STATUS_OFFERS_READY)
end

function RFF_BrokerService:getStatusTextKey(status)
    if status == self.STATUS_INSTRUCTED then return "rff_broker_status_instructed" end
    if status == self.STATUS_LENDERS_APPROACHED then return "rff_broker_status_lenders_approached" end
    if status == self.STATUS_INDICATIVE_RESPONSES then return "rff_broker_status_indicative" end
    if status == self.STATUS_OFFERS_PREPARING then return "rff_broker_status_preparing" end
    if status == self.STATUS_OFFERS_READY then return "rff_broker_status_offers_ready" end
    if status == self.STATUS_ACCEPTED then return "rff_broker_status_accepted" end
    if status == self.STATUS_WITHDRAWN then return "rff_broker_status_withdrawn" end
    if status == self.STATUS_EXPIRED then return "rff_broker_status_expired" end
    if status == self.STATUS_NO_OFFERS then return "rff_broker_status_no_offers" end
    return "rff_broker_status_unknown"
end

function RFF_BrokerService:getRelationshipTier(points)
    if self.relationshipService ~= nil then
        local code, tier = self.relationshipService:getTier(points)
        return code, tier.key
    end
    points = safeNumber(points)
    if points >= 15 then return "TRUSTED", "rff_relationship_trusted" end
    if points >= 8 then return "PROVEN", "rff_relationship_proven" end
    if points >= 3 then return "DEVELOPING", "rff_relationship_developing" end
    if points < 0 then return "STRAINED", "rff_relationship_strained" end
    return "NEW", "rff_relationship_new"
end

function RFF_BrokerService:getBrokerBenefits(farmId)
    local rel = self:getBrokerRelationship(farmId, false)
    local points = safeNumber(rel ~= nil and rel.relationshipPoints or 0)
    if points < 0 then return {timingFactor=1.10, feeFactor=1.10} end
    if points >= 15 then return {timingFactor=0.85, feeFactor=0.75} end
    if points >= 8 then return {timingFactor=0.92, feeFactor=0.85} end
    if points >= 3 then return {timingFactor=0.96, feeFactor=0.95} end
    return {timingFactor=1.00, feeFactor=1.00}
end

function RFF_BrokerService:getEffectiveLender(farmId, lender, deal)
    local effective = {}
    for key, value in pairs(lender or {}) do effective[key] = value end
    if self.relationshipService ~= nil and lender ~= nil then
        local benefits = self.relationshipService:getBenefits(farmId, lender.id)
        effective.rateAdjustment = safeNumber(effective.rateAdjustment) + safeNumber(benefits.rateAdjustment)
        effective.feePercent = safeNumber(effective.feePercent) * math.max(0.5, safeNumber(benefits.arrangementFeeFactor))
        effective.propertyLtvMax = math.max(0.40, math.min(0.95, safeNumber(effective.propertyLtvMax) + safeNumber(benefits.ltvBonus)))
        effective.securedLtvMax = math.max(0.40, math.min(0.90, safeNumber(effective.securedLtvMax) + safeNumber(benefits.ltvBonus)))
        effective.securedOverallLtvMax = math.max(0.45, math.min(0.95, safeNumber(effective.securedOverallLtvMax) + safeNumber(benefits.ltvBonus)))
        effective.dscrFloor = math.max(0.65, safeNumber(effective.dscrFloor) - safeNumber(benefits.dscrTolerance))
        effective.relationshipBenefits = benefits
    end
    if self.marketService ~= nil and lender ~= nil then
        local market = self.marketService:getMarketAdjustment(lender.id)
        local product = deal ~= nil and deal.product or RFF_LoanService.TYPE_TERM
        local purpose = deal ~= nil and deal.purpose or "GENERAL"
        local amount = deal ~= nil and deal.requestedAmount or 0
        local fit = self.marketService:getDealAdjustment(lender.id, product, purpose, amount, nil)
        effective.rateAdjustment = safeNumber(effective.rateAdjustment) + safeNumber(market.rateAdjustment) + safeNumber(fit.rateAdjustment)
        effective.feePercent = safeNumber(effective.feePercent) * math.max(0.5, safeNumber(market.feeFactor)) * math.max(0.5, safeNumber(fit.feeFactor))
        effective.collateralFactor = safeNumber(effective.collateralFactor) * math.max(0.75, safeNumber(market.collateralFactor)) * math.max(0.75, safeNumber(fit.collateralFactor))
        effective.incomeFactor = safeNumber(effective.incomeFactor) * math.max(0.75, safeNumber(market.incomeFactor)) * math.max(0.75, safeNumber(fit.incomeFactor))
        effective.dscrFloor = math.max(0.65, safeNumber(effective.dscrFloor) + safeNumber(market.dscrFloorAdjustment) + safeNumber(fit.dscrFloorAdjustment))
        effective.propertyLtvMax = math.max(0.40, math.min(0.95, safeNumber(effective.propertyLtvMax) + safeNumber(market.ltvAdjustment) + safeNumber(fit.ltvAdjustment)))
        effective.securedLtvMax = math.max(0.40, math.min(0.90, safeNumber(effective.securedLtvMax) + safeNumber(market.ltvAdjustment) + safeNumber(fit.ltvAdjustment)))
        effective.securedOverallLtvMax = math.max(0.45, math.min(0.95, safeNumber(effective.securedOverallLtvMax) + safeNumber(market.ltvAdjustment) + safeNumber(fit.ltvAdjustment)))
        effective.marketState = market.state
        effective.marketKey = market.key
        effective.dealFit = fit.code
        effective.dealFitKey = fit.key
        effective.dealFitAvailable = fit.available == true
        effective.specialismAmountFactor = math.max(0.50, safeNumber(fit.amountFactor))
    end
    return effective
end

function RFF_BrokerService:getLenderById(lenderId)
    for _, lender in ipairs(self.LENDERS) do
        if lender.id == lenderId then return lender end
    end
    return nil
end

function RFF_BrokerService:getBrokerRelationship(farmId, create)
    return self.repository ~= nil and self.repository:getBrokerRelationship(farmId, create) or nil
end

function RFF_BrokerService:getLenderRelationship(farmId, lenderId, create)
    return self.repository ~= nil and self.repository:getLenderRelationship(farmId, lenderId, create) or nil
end

function RFF_BrokerService:getCasesByFarm(farmId)
    return self.repository ~= nil and self.repository:getBrokerCasesByFarm(farmId) or {}
end

function RFF_BrokerService:getActiveCase(farmId)
    for _, case in ipairs(self:getCasesByFarm(farmId)) do
        if self:isOpen(case) then return case end
    end
    return nil
end

function RFF_BrokerService:canBrokerApplication(application)
    if application == nil or self.applicationService == nil then return false end
    if self.applicationService:isPending(application) then return false end
    if application.status == RFF_ApplicationService.STATUS_ACCEPTED or application.status == RFF_ApplicationService.STATUS_WITHDRAWN then return false end
    return application.requestedAmount ~= nil and safeNumber(application.requestedAmount) >= 1000
end

function RFF_BrokerService:estimateTiming(application, farmId)
    local periodHours = self:getPeriodHours()
    local minShare, maxShare = 0.34, 0.58
    if application ~= nil and application.product == RFF_LoanService.TYPE_MORTGAGE then
        minShare, maxShare = 0.48, 0.76
    elseif safeNumber(application ~= nil and application.requestedAmount) > 300000 then
        minShare, maxShare = 0.42, 0.68
    end

    local brokerBenefits = self:getBrokerBenefits(farmId)
    local minHours = math.max(8, math.floor(periodHours * minShare * brokerBenefits.timingFactor + 0.5))
    local maxHours = math.max(minHours, math.floor(periodHours * maxShare * brokerBenefits.timingFactor + 0.5))
    return minHours, maxHours
end

function RFF_BrokerService:chooseDelay(caseId, minHours, maxHours)
    minHours = math.max(8, math.floor(safeNumber(minHours)))
    maxHours = math.max(minHours, math.floor(safeNumber(maxHours)))
    return minHours + ((math.max(1, math.floor(safeNumber(caseId))) * 7) % (maxHours - minHours + 1))
end

function RFF_BrokerService:buildSchedule(startHour, delayHours)
    delayHours = math.max(8, math.floor(safeNumber(delayHours)))
    local approach = startHour + math.max(1, math.floor(delayHours * 0.20))
    local indicative = startHour + math.max(approach - startHour + 1, math.floor(delayHours * 0.48))
    local preparing = startHour + math.max(indicative - startHour + 1, math.floor(delayHours * 0.74))
    local ready = startHour + delayHours
    return approach, indicative, preparing, ready
end

function RFF_BrokerService:getOfferValidityHours(case)
    local periods = case ~= nil and case.product == RFF_LoanService.TYPE_MORTGAGE and 2 or 1
    return math.max(24, self:getPeriodHours() * periods)
end

function RFF_BrokerService:instructBroker(farmId, application)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return nil, "server_only" end
    if not self:canBrokerApplication(application) or application.farmId ~= farmId then return nil, "invalid_application" end
    if self:getActiveCase(farmId) ~= nil then return nil, "existing_case" end

    local id = self.repository:getNextBrokerCaseId()
    local minHours, maxHours = self:estimateTiming(application, farmId)
    local delay = self:chooseDelay(id, minHours, maxHours)
    local now = self:getCurrentHourStamp()
    local approach, indicative, preparing, ready = self:buildSchedule(now, delay)

    local case = {
        id=id, farmId=farmId, sourceApplicationId=application.id or 0,
        product=application.product, purpose=application.purpose or "GENERAL",
        requestedAmount=safeNumber(application.requestedAmount), requestedMonths=application.requestedMonths or 0,
        farmlandId=application.farmlandId or 0, purchasePrice=safeNumber(application.purchasePrice),
        requestedDepositAmount=safeNumber(application.requestedDepositAmount),
        status=self.STATUS_INSTRUCTED, instructedHour=now, lendersApproachedHour=approach,
        indicativeHour=indicative, offersPreparingHour=preparing, offersReadyHour=ready,
        expectedMinHours=minHours, expectedMaxHours=maxHours, offerExpiryHour=0,
        acceptedHour=0, acceptedOfferIndex=0, acceptedLenderId="", linkedLoanId=0,
        brokerFee=0, arrangementFee=0, offers={}
    }
    self.repository:addBrokerCase(case)

    local relationship = self:getBrokerRelationship(farmId, true)
    relationship.casesInstructed = safeNumber(relationship.casesInstructed) + 1
    relationship.relationshipPoints = safeNumber(relationship.relationshipPoints) + 1
    self:notifyPhone(case, "rff_phone_broker_instructed")
    return case, nil
end

function RFF_BrokerService:buildAdjustedCredit(credit, lender)
    return {
        collateral = safeNumber(credit ~= nil and credit.collateral) * safeNumber(lender.collateralFactor),
        monthlyIncome = safeNumber(credit ~= nil and credit.monthlyIncome) * safeNumber(lender.incomeFactor),
        trackedPeriods = safeNumber(credit ~= nil and credit.trackedPeriods)
    }
end

function RFF_BrokerService:repriceEvaluation(farmId, amount, months, product, evaluation, adjustedCredit, lender)
    if evaluation == nil or not evaluation.approved then return nil end
    local rate = math.max(0.1, safeNumber(evaluation.interestRate) + safeNumber(lender.rateAdjustment))
    local payment = self.loanService:calculateMonthlyPayment(amount, rate, months, product)
    local debtService = self.loanService:getMonthlyDebtService(farmId) + (self.repository:getMonthlyTenancyRent(farmId) or 0) + payment
    local income = safeNumber(adjustedCredit.monthlyIncome)
    local dscr = debtService > 0 and income / debtService or math.huge
    local tracked = safeNumber(adjustedCredit.trackedPeriods)
    if tracked >= 3 and income > 0 and dscr < safeNumber(lender.dscrFloor) then return nil end

    return {
        approved=true, amount=amount, months=months, grade=evaluation.grade or "C",
        interestRate=rate, monthlyPayment=payment, dscr=tracked >= 3 and dscr or nil,
        ltv=evaluation.ltv
    }
end

function RFF_BrokerService:evaluateGeneralAmount(case, lender, amount)
    local valuation = RFF_FarmValuation:calculate(case.farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(case.farmId, valuation, self.repository)
    local adjusted = self:buildAdjustedCredit(credit, lender)
    local evaluation = self.loanService:evaluateApplication(case.farmId, amount, case.requestedMonths, case.product, valuation, adjusted)
    return self:repriceEvaluation(case.farmId, amount, case.requestedMonths, case.product, evaluation, adjusted, lender)
end

function RFF_BrokerService:findGeneralOffer(case, lender)
    local originalRequested = math.max(1000, safeNumber(case.requestedAmount))
    local requested = math.max(1000, roundDown(originalRequested * math.min(1.00, math.max(0.50, safeNumber(lender.specialismAmountFactor or 1))), 1000))
    local full = self:evaluateGeneralAmount(case, lender, requested)
    if full ~= nil then return requested, full end

    local low, high = 1000, requested
    local bestAmount, bestEvaluation = 0, nil
    for _ = 1, 18 do
        local candidate = math.max(1000, roundDown((low + high) * 0.5, 1000))
        local evaluation = self:evaluateGeneralAmount(case, lender, candidate)
        if evaluation ~= nil then
            bestAmount, bestEvaluation = candidate, evaluation
            low = candidate + 1000
        else
            high = candidate - 1000
        end
        if high < low then break end
    end
    if bestAmount < math.max(10000, requested * 0.50) then return nil, nil end
    return bestAmount, bestEvaluation
end

function RFF_BrokerService:getMortgageValuation(case, lenderIndex)
    local price = math.max(0, safeNumber(case.purchasePrice))
    if price <= 0 then return 0 end
    local seed = (math.max(1, case.id or 1) * 13 + math.max(1, case.farmlandId or 1) * 7 + lenderIndex * 5) % 10
    local ratio = 0.93 + seed * 0.01
    return math.floor((price * ratio) / 100 + 0.5) * 100
end

function RFF_BrokerService:evaluateMortgageAmount(case, lender, lenderIndex, amount)
    if self.propertyFinance == nil or self.loanService == nil then return nil end
    local farmland = self.propertyFinance:getFarmland(case.farmlandId)
    if farmland == nil then return nil end

    local price = math.max(0, safeNumber(case.purchasePrice))
    amount = math.max(0, math.min(price, safeNumber(amount)))
    local lenderValue = self:getMortgageValuation(case, lenderIndex)
    if lenderValue <= 0 or amount < 1000 then return nil end

    local deposit = math.max(0, price - amount)
    local valuation = RFF_FarmValuation:calculate(case.farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(case.farmId, valuation, self.repository)
    local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(self.repository, case.farmId) or nil
    if conduct ~= nil and conduct.declineNewCredit then return nil end
    local conductRate = conduct ~= nil and safeNumber(conduct.rateAdjustment) or 0
    local adjusted = self:buildAdjustedCredit(credit, lender)

    local postCollateral = math.max(0, safeNumber(adjusted.collateral) - deposit * 0.30 + lenderValue * 0.70)
    if postCollateral <= 0 then return nil end
    local existingDebt = math.max(0, safeNumber(valuation.liabilities))
    local ltv = (existingDebt + amount) / postCollateral
    local propertyLtv = amount / lenderValue
    if propertyLtv > safeNumber(lender.propertyLtvMax) + 0.000001 then return nil end

    local baseRate = self.loanService:getBaseRate() + self.loanService:getProductSpread(RFF_LoanService.TYPE_MORTGAGE)
    local provisionalRate = baseRate + self.loanService:getPricingSpread("B") + safeNumber(lender.rateAdjustment) + conductRate
    local payment = self.loanService:calculateAnnuityPayment(amount, provisionalRate, case.requestedMonths)
    local commitments = self.loanService:getMonthlyDebtService(case.farmId) + (self.repository:getMonthlyTenancyRent(case.farmId) or 0) + payment
    local income = math.max(0, safeNumber(adjusted.monthlyIncome))
    local dscr = commitments > 0 and income / commitments or math.huge
    local tracked = safeNumber(adjusted.trackedPeriods)
    local hasIncome = income > 0

    local securedRoute = false
    local securedEligible = tracked >= 3
        and propertyLtv <= safeNumber(lender.securedLtvMax) + 0.000001
        and ltv <= safeNumber(lender.securedOverallLtvMax) + 0.000001
        and (conduct == nil or conduct.declineNewCredit ~= true)
    local grade
    if tracked < 3 then
        grade = self.loanService:scoreStartup(ltv)
        dscr = nil
    elseif tracked < 12 then
        grade = self.loanService:scoreDeveloping(dscr, ltv, hasIncome)
    else
        grade = self.loanService:scoreEstablished(dscr, ltv)
    end
    if grade == nil then
        if securedEligible then
            securedRoute = true
            grade = (propertyLtv <= 0.50 and ltv <= 0.55) and "C" or "D"
        else
            return nil
        end
    end
    if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end

    local routeRateUplift = securedRoute and safeNumber(lender.securedRateUplift) or 0
    local finalRate = baseRate + self.loanService:getPricingSpread(grade) + safeNumber(lender.rateAdjustment) + conductRate + routeRateUplift
    local finalPayment = self.loanService:calculateAnnuityPayment(amount, finalRate, case.requestedMonths)
    local finalCommitments = self.loanService:getMonthlyDebtService(case.farmId) + (self.repository:getMonthlyTenancyRent(case.farmId) or 0) + finalPayment
    local finalDscr = finalCommitments > 0 and income / finalCommitments or math.huge

    if tracked >= 3 and hasIncome and not securedRoute then
        local revised = tracked < 12 and self.loanService:scoreDeveloping(finalDscr, ltv, true) or self.loanService:scoreEstablished(finalDscr, ltv)
        if revised == nil or finalDscr < safeNumber(lender.dscrFloor) then
            if securedEligible then
                securedRoute = true
                grade = (propertyLtv <= 0.50 and ltv <= 0.55) and "C" or "D"
                if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end
                finalRate = baseRate + self.loanService:getPricingSpread(grade) + safeNumber(lender.rateAdjustment) + conductRate + safeNumber(lender.securedRateUplift)
                finalPayment = self.loanService:calculateAnnuityPayment(amount, finalRate, case.requestedMonths)
                finalCommitments = self.loanService:getMonthlyDebtService(case.farmId) + (self.repository:getMonthlyTenancyRent(case.farmId) or 0) + finalPayment
                finalDscr = finalCommitments > 0 and income / finalCommitments or math.huge
            else
                return nil
            end
        elseif revised ~= grade then
            grade = revised
            if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end
            finalRate = baseRate + self.loanService:getPricingSpread(grade) + safeNumber(lender.rateAdjustment) + conductRate
            finalPayment = self.loanService:calculateAnnuityPayment(amount, finalRate, case.requestedMonths)
            finalCommitments = self.loanService:getMonthlyDebtService(case.farmId) + (self.repository:getMonthlyTenancyRent(case.farmId) or 0) + finalPayment
            finalDscr = finalCommitments > 0 and income / finalCommitments or math.huge
            if finalDscr < safeNumber(lender.dscrFloor) then
                if securedEligible then
                    securedRoute = true
                    grade = (propertyLtv <= 0.50 and ltv <= 0.55) and "C" or "D"
                    if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end
                    finalRate = baseRate + self.loanService:getPricingSpread(grade) + safeNumber(lender.rateAdjustment) + conductRate + safeNumber(lender.securedRateUplift)
                    finalPayment = self.loanService:calculateAnnuityPayment(amount, finalRate, case.requestedMonths)
                    finalCommitments = self.loanService:getMonthlyDebtService(case.farmId) + (self.repository:getMonthlyTenancyRent(case.farmId) or 0) + finalPayment
                    finalDscr = finalCommitments > 0 and income / finalCommitments or math.huge
                else
                    return nil
                end
            end
        end
    end

    return {
        approved=true, amount=amount, months=case.requestedMonths, grade=grade or "C",
        interestRate=finalRate, monthlyPayment=finalPayment, dscr=tracked >= 3 and finalDscr or nil,
        lenderValuation=lenderValue, propertyLtv=propertyLtv,
        propertyLtvLimit=securedRoute and safeNumber(lender.securedLtvMax) or lender.propertyLtvMax,
        deposit=deposit, ltv=ltv, securedRoute=securedRoute,
        underwritingRoute=securedRoute and "SECURED_AGRICULTURAL" or "STANDARD"
    }
end

function RFF_BrokerService:findMortgageOffer(case, lender, lenderIndex)
    local originalRequested = math.max(1000, safeNumber(case.requestedAmount))
    local requested = math.max(1000, roundDown(originalRequested * math.min(1.00, math.max(0.50, safeNumber(lender.specialismAmountFactor or 1))), 1000))
    local full = self:evaluateMortgageAmount(case, lender, lenderIndex, requested)
    if full ~= nil then return requested, full end

    local low, high = 1000, math.min(requested, self:getMortgageValuation(case, lenderIndex) * safeNumber(lender.propertyLtvMax))
    local bestAmount, bestEvaluation = 0, nil
    for _ = 1, 20 do
        local candidate = math.max(1000, roundDown((low + high) * 0.5, 1000))
        local evaluation = self:evaluateMortgageAmount(case, lender, lenderIndex, candidate)
        if evaluation ~= nil then
            bestAmount, bestEvaluation = candidate, evaluation
            low = candidate + 1000
        else
            high = candidate - 1000
        end
        if high < low then break end
    end
    if bestAmount < math.max(10000, requested * 0.50) then return nil, nil end
    return bestAmount, bestEvaluation
end

function RFF_BrokerService:generateOffers(case)
    case.offers = {}
    if case.product == RFF_LoanService.TYPE_MORTGAGE then
        local farmland = self.propertyFinance ~= nil and self.propertyFinance:getFarmland(case.farmlandId) or nil
        if farmland == nil or g_farmlandManager:getFarmlandOwner(case.farmlandId) ~= FarmlandManager.NO_OWNER_FARM_ID or math.abs(safeNumber(farmland.price)-safeNumber(case.purchasePrice)) > 1 then
            case.status = self.STATUS_NO_OFFERS
            return 0
        end
    end

    local brokerBenefits = self:getBrokerBenefits(case.farmId)
    for lenderIndex, lender in ipairs(self.LENDERS) do
        local relationship = self:getLenderRelationship(case.farmId, lender.id, true)
        relationship.applications = safeNumber(relationship.applications) + 1
        local effectiveLender = self:getEffectiveLender(case.farmId, lender, case)

        local amount, evaluation
        if effectiveLender.dealFitAvailable == false then
            amount, evaluation = nil, nil
        elseif case.product == RFF_LoanService.TYPE_MORTGAGE then
            amount, evaluation = self:findMortgageOffer(case, effectiveLender, lenderIndex)
        else
            amount, evaluation = self:findGeneralOffer(case, effectiveLender)
        end

        if amount ~= nil and evaluation ~= nil then
            local brokerFee = math.max(self.BROKER_MIN_FEE * brokerBenefits.feeFactor, amount * self.BROKER_FEE_PERCENT * brokerBenefits.feeFactor)
            local arrangementFee = amount * safeNumber(effectiveLender.feePercent)
            local offer = {
                lenderId=lender.id, amount=amount, months=case.requestedMonths,
                interestRate=safeNumber(evaluation.interestRate), monthlyPayment=safeNumber(evaluation.monthlyPayment),
                grade=evaluation.grade or "C", arrangementFee=arrangementFee, brokerFee=brokerFee,
                lenderValuation=safeNumber(evaluation.lenderValuation), deposit=safeNumber(evaluation.deposit),
                propertyLtv=safeNumber(evaluation.propertyLtv), propertyLtvLimit=safeNumber(evaluation.propertyLtvLimit),
                dscr=evaluation.dscr, underwritingRoute=evaluation.underwritingRoute or "STANDARD", securedRoute=evaluation.securedRoute == true,
                relationshipTier=effectiveLender.relationshipBenefits ~= nil and effectiveLender.relationshipBenefits.code or "NEW",
                marketState=effectiveLender.marketState or "SELECTIVE", dealFit=effectiveLender.dealFit or "STANDARD"
            }
            table.insert(case.offers, offer)
            relationship.offersMade = safeNumber(relationship.offersMade) + 1
        end
    end

    if #case.offers > 0 then
        case.status = self.STATUS_OFFERS_READY
        case.offerExpiryHour = self:getCurrentHourStamp() + self:getOfferValidityHours(case)
    else
        case.status = self.STATUS_NO_OFFERS
    end
    return #case.offers
end

function RFF_BrokerService:getPhoneSender()
    if RFF_NotificationService ~= nil then
        return RFF_NotificationService:getText("rff_broker_title", "Agricultural Finance Broker")
    end
    return "Agricultural Finance Broker"
end

function RFF_BrokerService:getPhoneTitle()
    if RFF_NotificationService ~= nil then
        return RFF_NotificationService:getText("rff_phone_title_broker", "Broker Update")
    end
    return "Broker Update"
end

function RFF_BrokerService:notifyPhone(case, messageKey)
    if case == nil or RFF_NotificationService == nil then return false end
    local message = RFF_NotificationService:formatText(messageKey, "Broker case #%d has been updated.", case.id or 0)
    return RFF_NotificationService:pushPhone(case.farmId, self:getPhoneSender(), self:getPhoneTitle(), message, "broker")
end

function RFF_BrokerService:notify(case, key)
    if g_currentMission == nil or g_i18n == nil then return end
    local text = g_i18n:getText(key)
    if text == nil then return end
    text = string.format(text, case ~= nil and case.id or 0)

    local phoneKeys = {
        rff_notification_broker_offers_ready = "rff_phone_broker_offers_ready",
        rff_notification_broker_no_offers = "rff_phone_broker_no_offers",
        rff_notification_broker_offers_expired = "rff_phone_broker_offers_expired"
    }
    if case ~= nil and RFF_NotificationService ~= nil then
        local phoneKey = phoneKeys[key]
        local message = phoneKey ~= nil and RFF_NotificationService:formatText(phoneKey, text, case.id or 0) or text
        if RFF_NotificationService:send(case.farmId, self:getPhoneSender(), self:getPhoneTitle(), message, "broker", text, false) then
            return
        end
    end

    if g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, text)
    end
end

function RFF_BrokerService:processTime()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local now = self:getCurrentHourStamp()
    for _, case in ipairs(self.repository.brokerCases or {}) do
        if case.status == self.STATUS_INSTRUCTED and now >= safeNumber(case.lendersApproachedHour) then
            case.status = self.STATUS_LENDERS_APPROACHED
            self:notifyPhone(case, "rff_phone_broker_lenders_approached")
        end
        if case.status == self.STATUS_LENDERS_APPROACHED and now >= safeNumber(case.indicativeHour) then
            case.status = self.STATUS_INDICATIVE_RESPONSES
            self:notifyPhone(case, "rff_phone_broker_indicative")
        end
        if case.status == self.STATUS_INDICATIVE_RESPONSES and now >= safeNumber(case.offersPreparingHour) then
            case.status = self.STATUS_OFFERS_PREPARING
            self:notifyPhone(case, "rff_phone_broker_preparing")
        end
        if case.status == self.STATUS_OFFERS_PREPARING and now >= safeNumber(case.offersReadyHour) then
            local count = self:generateOffers(case)
            self:notify(case, count > 0 and "rff_notification_broker_offers_ready" or "rff_notification_broker_no_offers")
        elseif case.status == self.STATUS_OFFERS_READY and safeNumber(case.offerExpiryHour) > 0 and now >= safeNumber(case.offerExpiryHour) then
            case.status = self.STATUS_EXPIRED
            self:notify(case, "rff_notification_broker_offers_expired")
        end
    end
end

function RFF_BrokerService:onHourChanged()
    self:processTime()
end

function RFF_BrokerService:onDayChanged()
    self:processTime()
end

function RFF_BrokerService:forceProcessAll(farmId)
    local count = 0
    for _, case in ipairs(self.repository ~= nil and self.repository.brokerCases or {}) do
        if (farmId == nil or case.farmId == farmId) and self:isPending(case) then
            self:generateOffers(case)
            count = count + 1
        end
    end
    return count
end

function RFF_BrokerService:withdrawCase(case)
    if case == nil or not self:isOpen(case) then return false end
    case.status = self.STATUS_WITHDRAWN
    return true
end

function RFF_BrokerService:acceptOffer(case, offerIndex)
    if g_currentMission == nil or not g_currentMission:getIsServer() or case == nil or case.status ~= self.STATUS_OFFERS_READY then return nil, "invalid" end
    offerIndex = math.max(1, math.min(#(case.offers or {}), math.floor(safeNumber(offerIndex))))
    local offer = case.offers ~= nil and case.offers[offerIndex] or nil
    if offer == nil then return nil, "invalid_offer" end
    if safeNumber(case.offerExpiryHour) > 0 and self:getCurrentHourStamp() >= safeNumber(case.offerExpiryHour) then
        case.status = self.STATUS_EXPIRED
        return nil, "expired"
    end

    local totalFees = safeNumber(offer.arrangementFee) + safeNumber(offer.brokerFee)
    local loan, reason
    if case.product == RFF_LoanService.TYPE_MORTGAGE then
        local cashRequired = safeNumber(offer.deposit) + totalFees
        if getFarmMoney(case.farmId) < cashRequired then return nil, "funds" end
        local application = {
            id=case.sourceApplicationId or 0, farmId=case.farmId, farmlandId=case.farmlandId,
            purchasePrice=case.purchasePrice, requestedMonths=case.requestedMonths,
            offeredAmount=offer.amount, offeredMonths=offer.months, offeredRate=offer.interestRate,
            offeredPayment=offer.monthlyPayment, offeredGrade=offer.grade, lenderValuation=offer.lenderValuation,
            offeredDeposit=offer.deposit, offeredPropertyLtv=offer.propertyLtv, propertyLtvLimit=offer.propertyLtvLimit,
            lenderId=offer.lenderId, lenderNameKey=(self:getLenderById(offer.lenderId) or {}).nameKey,
            brokered=true, brokerCaseId=case.id, arrangementFee=offer.arrangementFee, brokerFee=offer.brokerFee
        }
        loan, reason = self.propertyFinance:completeMortgageFromApplication(application)
        if loan ~= nil and totalFees > 0 then
            if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(case.farmId, "Broker / arrangement fees") end
            g_currentMission:addMoney(-totalFees, case.farmId, feeMoneyType(), true, true)
        end
    else
        if (case.product == RFF_LoanService.TYPE_REVOLVING or case.product == RFF_LoanService.TYPE_OVERDRAFT) and getFarmMoney(case.farmId) < totalFees then return nil, "funds" end
        local formalOffer = {
            approved=true, interestRate=offer.interestRate, monthlyPayment=offer.monthlyPayment, grade=offer.grade,
            lenderId=offer.lenderId, lenderNameKey=(self:getLenderById(offer.lenderId) or {}).nameKey,
            brokered=true, brokerCaseId=case.id, arrangementFee=offer.arrangementFee, brokerFee=offer.brokerFee
        }
        loan, reason = self.loanService:createLoanFromOffer(case.farmId, offer.amount, offer.months, case.product, case.purpose, formalOffer)
        if loan ~= nil and totalFees > 0 then
            if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(case.farmId, "Broker / arrangement fees") end
            g_currentMission:addMoney(-totalFees, case.farmId, feeMoneyType(), true, true)
        end
    end
    if loan == nil then return nil, reason or "loan_create_failed" end

    case.status = self.STATUS_ACCEPTED
    case.acceptedHour = self:getCurrentHourStamp()
    case.acceptedOfferIndex = offerIndex
    case.acceptedLenderId = offer.lenderId
    case.linkedLoanId = loan.id or 0
    case.brokerFee = safeNumber(offer.brokerFee)
    case.arrangementFee = safeNumber(offer.arrangementFee)

    local brokerRel = self:getBrokerRelationship(case.farmId, true)
    brokerRel.acceptedDeals = safeNumber(brokerRel.acceptedDeals) + 1
    brokerRel.successfulIntroductions = safeNumber(brokerRel.successfulIntroductions) + 1
    brokerRel.feesPaid = safeNumber(brokerRel.feesPaid) + safeNumber(offer.brokerFee)
    brokerRel.relationshipPoints = safeNumber(brokerRel.relationshipPoints) + 3

    local lenderRel = self:getLenderRelationship(case.farmId, offer.lenderId, true)
    lenderRel.acceptedDeals = safeNumber(lenderRel.acceptedDeals) + 1
    lenderRel.totalVolume = safeNumber(lenderRel.totalVolume) + safeNumber(offer.amount)
    lenderRel.relationshipPoints = safeNumber(lenderRel.relationshipPoints) + 3

    for _, app in ipairs(self.repository:getApplicationsByFarm(case.farmId) or {}) do
        if app.id == case.sourceApplicationId and app.status == RFF_ApplicationService.STATUS_OFFERED then
            app.status = RFF_ApplicationService.STATUS_WITHDRAWN
            app.outcome = "WITHDRAWN"
        end
    end
    if RFF_NotificationService ~= nil then
        local lender = self:getLenderById(offer.lenderId)
        local sender = RFF_NotificationService:getSender(lender ~= nil and lender.nameKey or nil, "Lender")
        local title = RFF_NotificationService:getText("rff_phone_title_completed", "Finance Completed")
        local message = RFF_NotificationService:formatText("rff_phone_broker_completed", "Broker case #%d has completed and the finance agreement is now active.", case.id or 0)
        RFF_NotificationService:pushPhone(case.farmId, sender, title, message, "broker")
    end
    return loan, nil
end
