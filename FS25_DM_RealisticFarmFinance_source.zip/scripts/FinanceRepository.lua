RFF_FinanceRepository = {}
RFF_FinanceRepository.__index = RFF_FinanceRepository

RFF_FinanceRepository.TRACKED_OPERATING_INCOME = {
    harvestIncome = true,
    soldProducts = true,
    soldWood = true,
    soldAnimals = true,
    soldMilk = true,
    propertyIncome = true,
    incomeBga = true,
    missionIncome = true,
    soldBales = true,
    invoiceIncome = true,
    schemePayout = true,
    grantReceived = true
}

local function safeNumber(value)
    if type(value) == "number" and value == value then
        return value
    end
    return 0
end

function RFF_FinanceRepository.new()
    local self = setmetatable({}, RFF_FinanceRepository)
    self.farms = {}
    self.loans = {}
    self.tenancies = {}
    self.applications = {}
    self.brokerCases = {}
    self.preApprovedOffers = {}
    self.brokerRelationships = {}
    self.lenderRelationships = {}
    self.assetFinance = {}
    self.vehicleInsurancePolicies = {}
    self.trafficCourtesyIncidents = {}
    self.driverOffences = {}
    self.speedingNotices = {}
    self.roadsideChecks = {}
    self.insuranceClaims = {}
    self.insuranceLosses = {}
    self.insuranceVeterinaryExpenses = {}
    self.nextAssetFinanceId = 1
    self.nextVehicleInsurancePolicyId = 1
    self.nextTrafficCourtesyIncidentId = 1
    self.nextDriverOffenceId = 1
    self.nextInsuranceClaimId = 1
    self.nextInsuranceLossId = 1
    self.nextInsuranceVeterinaryExpenseId = 1
    self.nextLoanId = 1
    self.nextTenancyId = 1
    self.nextApplicationId = 1
    self.nextBrokerCaseId = 1
    self.nextPreApprovedOfferId = 1
    self.pendingTransactionDescriptions = {}
    self.loaded = false
    return self
end

function RFF_FinanceRepository:getCurrentPeriodIndex()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    if env == nil then
        return 0
    end
    return (env.currentYear or 0) * 12 + (env.currentPeriod or 0)
end

function RFF_FinanceRepository:getFarmState(farmId, create)
    local state = self.farms[farmId]
    if state == nil and create then
        local current = self:getCurrentPeriodIndex()
        state = {
            firstTrackedPeriod = current,
            periods = {},
            bankPositiveBalanceSum = 0,
            bankBalanceSamples = 0,
            bankLastInterestCredit = 0,
            bankLastInterestRate = 0,
            bankLastAverageBalance = 0,
            bankLastInterestPeriod = 0,
            bankLastSamplePeriod = 0,
            bankLastUnauthorisedDay = 0,
            bankUnauthorisedInterestPaid = 0,
            bankUnauthorisedFeesPaid = 0,
            adminLastProcessedPeriod = current,
            adminArrears = 0,
            adminLastCharge = 0,
            adminLastMonthlyCharge = 0,
            adminLastAnnualFilingCharge = 0,
            adminLastAnnualFilingYear = -1,
            adminLastLateFee = 0,
            adminTotalPaid = 0,
            adminMissedPayments = 0,
            insuranceTier = "STANDARD",
            insuranceNextTier = "STANDARD",
            insuranceStatus = "ACTIVE",
            insuranceNextRenewalPeriod = current + 1,
            insurancePremiumDue = 0,
            insuranceLastPremium = 0,
            insuranceLastValuation = 0,
            insuranceLastRenewalPeriod = 0,
            insuranceGraceUntilPeriod = 0,
            insuranceTotalPaid = 0,
            insuranceMissedPremiums = 0,
            insuranceRenewalNoticePeriod = 0,
            vehicleInsuranceMigrated = false,
            vehicleInsuranceTier = "STANDARD",
            vehicleInsuranceNextTier = "STANDARD",
            vehicleInsuranceStatus = "ACTIVE",
            vehicleInsuranceNextRenewalPeriod = current + 1,
            vehicleInsurancePremiumDue = 0,
            vehicleInsuranceLastPremium = 0,
            vehicleInsuranceLastValuation = 0,
            vehicleInsuranceLastRenewalPeriod = 0,
            vehicleInsuranceGraceUntilPeriod = 0,
            vehicleInsuranceTotalPaid = 0,
            vehicleInsuranceMissedPremiums = 0,
            vehicleInsuranceRenewalNoticePeriod = 0,
            -- New farms start with no individual vehicle policies. Loaded saves
            -- without this flag are migrated once after their vehicles exist.
            vehicleInsurancePerVehicleMigrated = true,
            driverQualificationVersion = 4,
            driverLicenceMode = "FULL",
            driverCategoryB = true,
            driverCategoryF = false,
            driverCategoryH = false,
            driverCategoryC = false,
            driverAdr = false,
            driverPenaltyPoints = 0,
            driverPointsVersion = 1,
            driverSpecialistRevoked = false,
            driverPenaltiesEnabled = false,
            speedingEnforcementEnabled = false,
            roadsideChecksEnabled = false,
            roadsideCooldownUntil = 0,
            speedingCooldownUntil = 0,
            speedingWindowRemaining = 0,
            vehicleInsurancePointsEnabled = false,
            roadSpeedHudEnabled = true,
            driverRestrictionEnd = 0,
            driverRestrictionRepeats = 0,
            driverRestrictionServedPoints = 0,
            driverAssessmentCategory = "",
            driverAssessmentStatus = "NONE",
            driverAssessmentBookedDay = 0,
            driverAssessmentAvailableDay = 0,
            driverAssessmentDeadlineDay = 0,
            driverAssessmentReturnDeadlineHour = 0,
            driverAssessmentVehicleUniqueId = "",
            driverAssessmentVehicleName = "",
            driverAssessmentDistance = 0,
            driverAssessmentRoadDistance = 0,
            driverAssessmentReverseDistance = 0,
            driverAssessmentMovingSeconds = 0,
            driverAssessmentLeftTurnDegrees = 0,
            driverAssessmentRightTurnDegrees = 0,
            driverAssessmentSpeedFaultSeconds = 0,
            driverAssessmentCollisionCount = 0,
            driverAssessmentTheoryIndex = 0,
            driverAssessmentTheoryScore = 0,
            driverAssessmentFailureReason = "",
            driverAssessmentLastResultCategory = "",
            driverAssessmentLastResult = "",
            movementAuthorisations = {},
            taxReturnYear = 0,
            taxReturnStatus = "NONE",
            taxReturnOpenPeriod = 0,
            taxReturnFiledPeriod = 0,
            taxReturnMethod = "NONE",
            taxReturnSignedBy = "",
            taxReturnBookIncome = 0,
            taxReturnBookTaxedIncome = 0,
            taxReturnBookExpenses = 0,
            taxReturnBookTax = 0,
            taxReturnLossRollover = 0,
            taxReturnTaxRate = 0,
            taxReturnIncomeFactor = 1,
            taxReturnExpenseFactor = 1,
            taxReturnDeclaredIncome = 0,
            taxReturnDeclaredTaxedIncome = 0,
            taxReturnDeclaredExpenses = 0,
            taxReturnFiledTax = 0,
            taxReturnTaxSaving = 0,
            taxReturnAdjustment = 0,
            taxReturnAdjustmentApplied = false,
            taxReturnAccountantFee = 0,
            taxReturnWasForcedTest = false,
            taxComplianceFlags = 0,
            taxComplianceCleanFilings = 0,
            taxComplianceAggressiveFilings = 0,
            taxComplianceLiability = 0,
            taxComplianceLastInterestPeriod = 0,
            taxInvestigationStatus = "NONE",
            taxInvestigationStartPeriod = 0,
            taxInvestigationOutcomePeriod = 0,
            taxInvestigationLastOutcome = "NONE",
            taxInvestigationAdjustment = 0,
            taxInvestigationPenalty = 0,
            taxInvestigationInterest = 0,
            legacyLoanMigrationVersion = 0,
            legacyLoanImportedAmount = 0,
            legacyLoanImportedId = 0,
            externalFinanceMigrationIds = ""
        }
        self.farms[farmId] = state
    end
    return state
end

function RFF_FinanceRepository:getPeriod(farmId, periodIndex, create)
    local state = self:getFarmState(farmId, create)
    if state == nil then
        return nil
    end

    local period = state.periods[periodIndex]
    if period == nil and create then
        local env = g_currentMission ~= nil and g_currentMission.environment or nil
        period = {
            inflows = 0,
            outflows = 0,
            operatingIncome = 0,
            openingBalance = nil,
            closingBalance = nil,
            transactions = {},
            statementTruncated = false,
            year = env ~= nil and env.currentYear or nil,
            periodNumber = env ~= nil and env.currentPeriod or nil,
            snapshot = nil
        }
        state.periods[periodIndex] = period
    end
    return period
end

RFF_FinanceRepository.MAX_STATEMENT_TRANSACTIONS_PER_PERIOD = nil

RFF_FinanceRepository.STATEMENT_DESCRIPTIONS = {
    harvestIncome = "Harvest income",
    soldProducts = "Product sales",
    soldWood = "Timber sales",
    soldAnimals = "Livestock sales",
    soldMilk = "Milk sales",
    propertyIncome = "Property income",
    incomeBga = "BGA income",
    missionIncome = "Contract income",
    soldBales = "Bale sales",
    invoiceIncome = "Invoice income",
    schemePayout = "Scheme payment",
    grantReceived = "Grant received",
    vehicleRunningCost = "Vehicle running cost",
    wagePayment = "Wages",
    purchaseFuel = "Fuel purchase",
    fieldBuy = "Land purchase",
    fieldLease = "Land / tenancy payment",
    constructionCost = "Construction",
    propertyMaintenance = "Property maintenance",
    animalUpkeep = "Livestock costs",
    loanInterest = "Loan / finance interest",
    leasingCosts = "Lease payment / charge",
    interestPaid = "Bank interest"
}

local function humanizeStatistic(statistic)
    if statistic == nil or statistic == "" then return nil end
    local text = tostring(statistic):gsub("_", " ")
    text = text:gsub("(%l)(%u)", "%1 %2")
    text = text:gsub("^%l", string.upper)
    return text
end

function RFF_FinanceRepository:setNextTransactionDescription(farmId, description)
    if farmId == nil or farmId <= 0 or description == nil or description == "" then return end
    self.pendingTransactionDescriptions = self.pendingTransactionDescriptions or {}
    self.pendingTransactionDescriptions[farmId] = tostring(description)
end

function RFF_FinanceRepository:getTransactionDescription(farmId, amount, moneyType)
    self.pendingTransactionDescriptions = self.pendingTransactionDescriptions or {}
    local pending = self.pendingTransactionDescriptions[farmId]
    self.pendingTransactionDescriptions[farmId] = nil
    if pending ~= nil and pending ~= "" then return pending end

    local statistic = moneyType ~= nil and moneyType.statistic or nil
    if statistic == "loanPrincipal" then
        return amount > 0 and "Finance advance" or "Loan / finance repayment"
    elseif statistic == "loanInterest" then
        return amount > 0 and "Finance interest credit" or "Loan / finance interest"
    elseif statistic == "leasingCosts" then
        return amount > 0 and "Lease / finance refund" or "Lease payment / charge"
    elseif statistic == "interestPaid" then
        return amount > 0 and "Bank interest credit" or "Bank interest charge"
    end

    local mapped = statistic ~= nil and self.STATEMENT_DESCRIPTIONS[statistic] or nil
    if mapped ~= nil then return mapped end
    return humanizeStatistic(statistic) or (amount > 0 and "Account credit" or "Account debit")
end

function RFF_FinanceRepository:onMoneyChange(farm, amount, moneyType)
    if not self.loaded or farm == nil or farm.farmId == nil or farm.farmId <= 0 or amount == nil or amount == 0 then
        return
    end

    local farmId = farm.farmId
    local currentIndex = self:getCurrentPeriodIndex()
    local state = self:getFarmState(farmId, true)
    local balanceAfter = safeNumber(farm.money)
    local balanceBefore = balanceAfter - amount

    -- The first transaction in a new period gives us an exact contractual opening balance.
    local previousPeriod = state ~= nil and state.periods[currentIndex - 1] or nil
    if previousPeriod ~= nil and previousPeriod.closingBalance == nil then
        previousPeriod.closingBalance = balanceBefore
    end

    local period = self:getPeriod(farmId, currentIndex, true)
    period.transactions = period.transactions or {}
    if period.openingBalance == nil then period.openingBalance = balanceBefore end

    if amount > 0 then
        period.inflows = period.inflows + amount
    else
        period.outflows = period.outflows + math.abs(amount)
    end

    local statistic = moneyType ~= nil and moneyType.statistic or nil
    if amount > 0 and statistic ~= nil and self.TRACKED_OPERATING_INCOME[statistic] then
        period.operatingIncome = period.operatingIncome + amount
    end

    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    local transaction = {
        day = env ~= nil and (env.currentDayInPeriod or env.currentDay or 1) or 1,
        year = env ~= nil and (env.currentYear or 0) or 0,
        periodNumber = env ~= nil and (env.currentPeriod or 0) or 0,
        amount = amount,
        balance = balanceAfter,
        description = self:getTransactionDescription(farmId, amount, moneyType),
        statistic = statistic or ""
    }
    table.insert(period.transactions, transaction)
    -- v0.9.4.0+: retain the complete period statement. The GUI uses a virtualised SmoothList,
    -- so busy months no longer need to discard older transaction rows for display performance.
end

function RFF_FinanceRepository:getStatementPeriods(farmId)
    local state = self:getFarmState(farmId, false)
    local indexes = {}
    if state ~= nil then
        for index in pairs(state.periods or {}) do table.insert(indexes, index) end
    end
    table.sort(indexes, function(a, b) return a > b end)
    return indexes
end

function RFF_FinanceRepository:getStatementPeriod(farmId, periodIndex)
    return self:getPeriod(farmId, periodIndex, false)
end

function RFF_FinanceRepository:getTrackedPeriodCount(farmId)
    local state = self:getFarmState(farmId, false)
    if state == nil then
        return 0
    end

    local current = self:getCurrentPeriodIndex()
    if state.firstTrackedPeriod == nil or current < state.firstTrackedPeriod then
        return 0
    end
    return current - state.firstTrackedPeriod + 1
end

function RFF_FinanceRepository:getTrailingOperatingIncome(farmId, maxPeriods)
    local state = self:getFarmState(farmId, false)
    if state == nil then
        return 0
    end

    local observed = self:getTrackedPeriodCount(farmId)
    if observed <= 0 then
        return 0
    end

    local count = math.min(maxPeriods or 12, observed)
    local current = self:getCurrentPeriodIndex()
    local weightedSum = 0
    local weightSum = 0
    local weight = 1.0

    for offset = 0, count - 1 do
        local period = state.periods[current - offset]
        local income = period ~= nil and period.operatingIncome or 0
        weightedSum = weightedSum + income * weight
        weightSum = weightSum + weight
        weight = weight * 0.85
    end

    if weightSum <= 0 then
        return 0
    end
    return weightedSum / weightSum
end


function RFF_FinanceRepository:getOutstandingBusinessObligations(farmId)
    local state = self:getFarmState(farmId, false)
    if state == nil then return 0 end
    local vehicleInsuranceDue = 0
    if state.vehicleInsurancePerVehicleMigrated == true then
        for _, policy in ipairs(self.vehicleInsurancePolicies or {}) do
            if policy.farmId == farmId then vehicleInsuranceDue = vehicleInsuranceDue + math.max(0, safeNumber(policy.premiumDue)) end
        end
    else
        vehicleInsuranceDue = math.max(0, safeNumber(state.vehicleInsurancePremiumDue))
    end
    return math.max(0, safeNumber(state.adminArrears))
        + math.max(0, safeNumber(state.insurancePremiumDue))
        + vehicleInsuranceDue
        + math.max(0, safeNumber(state.taxComplianceLiability))
end

function RFF_FinanceRepository:getNextVehicleInsurancePolicyId()
    local id = self.nextVehicleInsurancePolicyId or 1
    self.nextVehicleInsurancePolicyId = id + 1
    return id
end

function RFF_FinanceRepository:addVehicleInsurancePolicy(policy)
    if policy ~= nil then table.insert(self.vehicleInsurancePolicies, policy) end
end

function RFF_FinanceRepository:getVehicleInsurancePoliciesByFarm(farmId)
    local result = {}
    for _, policy in ipairs(self.vehicleInsurancePolicies or {}) do
        if policy.farmId == farmId then table.insert(result, policy) end
    end
    table.sort(result, function(a, b)
        local aName = string.lower(tostring(a.vehicleName or ""))
        local bName = string.lower(tostring(b.vehicleName or ""))
        if aName == bName then return (a.id or 0) < (b.id or 0) end
        return aName < bName
    end)
    return result
end

function RFF_FinanceRepository:getVehicleInsurancePolicyByVehicle(farmId, vehicleUniqueId)
    vehicleUniqueId = tostring(vehicleUniqueId or "")
    if vehicleUniqueId == "" then return nil end
    for _, policy in ipairs(self.vehicleInsurancePolicies or {}) do
        if policy.farmId == farmId and tostring(policy.vehicleUniqueId or "") == vehicleUniqueId then return policy end
    end
    return nil
end

function RFF_FinanceRepository:getNextTrafficCourtesyIncidentId()
    local id = self.nextTrafficCourtesyIncidentId or 1
    self.nextTrafficCourtesyIncidentId = id + 1
    return id
end

function RFF_FinanceRepository:addTrafficCourtesyIncident(incident)
    if incident ~= nil then table.insert(self.trafficCourtesyIncidents, incident) end
end

function RFF_FinanceRepository:getTrafficCourtesyIncidentsByFarm(farmId)
    local result = {}
    for _, incident in ipairs(self.trafficCourtesyIncidents or {}) do
        if incident.farmId == farmId then table.insert(result, incident) end
    end
    table.sort(result, function(a, b)
        if (a.incidentDay or 0) == (b.incidentDay or 0) then return (a.id or 0) > (b.id or 0) end
        return (a.incidentDay or 0) > (b.incidentDay or 0)
    end)
    return result
end

function RFF_FinanceRepository:getTrafficCourtesyIncidentById(farmId, incidentId)
    for _, incident in ipairs(self.trafficCourtesyIncidents or {}) do
        if incident.farmId == farmId and (incident.id or 0) == incidentId then return incident end
    end
    return nil
end

function RFF_FinanceRepository:getTrafficCourtesyIncidentByExternalId(externalIncidentId)
    externalIncidentId = tostring(externalIncidentId or "")
    if externalIncidentId == "" then return nil end
    for _, incident in ipairs(self.trafficCourtesyIncidents or {}) do
        if tostring(incident.externalIncidentId or "") == externalIncidentId then return incident end
        local grouped = "," .. tostring(incident.groupedExternalIncidentIds or "") .. ","
        if string.find(grouped, "," .. externalIncidentId .. ",", 1, true) ~= nil then return incident end
    end
    return nil
end

function RFF_FinanceRepository:getNextDriverOffenceId()
    local id = self.nextDriverOffenceId or 1
    self.nextDriverOffenceId = id + 1
    return id
end

function RFF_FinanceRepository:addDriverOffence(offence)
    if offence ~= nil then table.insert(self.driverOffences, offence) end
end

function RFF_FinanceRepository:getDriverOffencesByFarm(farmId)
    local result = {}
    for _, offence in ipairs(self.driverOffences or {}) do
        if offence.farmId == farmId then table.insert(result, offence) end
    end
    table.sort(result, function(a, b)
        if (a.incidentDay or 0) == (b.incidentDay or 0) then return (a.id or 0) > (b.id or 0) end
        return (a.incidentDay or 0) > (b.incidentDay or 0)
    end)
    return result
end

function RFF_FinanceRepository:getDriverOffenceByExternalId(externalIncidentId)
    externalIncidentId = tostring(externalIncidentId or "")
    if externalIncidentId == "" then return nil end
    for _, offence in ipairs(self.driverOffences or {}) do
        if tostring(offence.externalIncidentId or "") == externalIncidentId then return offence end
    end
    return nil
end

function RFF_FinanceRepository:clearDriverOffencesByFarm(farmId)
    for index = #(self.driverOffences or {}), 1, -1 do
        if self.driverOffences[index].farmId == farmId then table.remove(self.driverOffences, index) end
    end
end


function RFF_FinanceRepository:getNextInsuranceClaimId()
    local id = self.nextInsuranceClaimId or 1
    self.nextInsuranceClaimId = id + 1
    return id
end

function RFF_FinanceRepository:addInsuranceClaim(claim)
    if claim ~= nil then table.insert(self.insuranceClaims, claim) end
end

function RFF_FinanceRepository:getInsuranceClaimsByFarm(farmId)
    local result = {}
    for _, claim in ipairs(self.insuranceClaims or {}) do
        if claim.farmId == farmId then table.insert(result, claim) end
    end
    table.sort(result, function(a, b) return (a.id or 0) > (b.id or 0) end)
    return result
end

function RFF_FinanceRepository:getInsuranceClaimById(farmId, claimId)
    for _, claim in ipairs(self.insuranceClaims or {}) do
        if claim.farmId == farmId and (claim.id or 0) == claimId then return claim end
    end
    return nil
end

function RFF_FinanceRepository:getInsuranceClaimByExternalId(externalIncidentId)
    externalIncidentId = tostring(externalIncidentId or "")
    if externalIncidentId == "" then return nil end
    for _, claim in ipairs(self.insuranceClaims or {}) do
        if tostring(claim.externalIncidentId or "") == externalIncidentId then return claim end
        local grouped = "," .. tostring(claim.groupedExternalIncidentIds or "") .. ","
        if string.find(grouped, "," .. externalIncidentId .. ",", 1, true) ~= nil then return claim end
    end
    return nil
end

function RFF_FinanceRepository:getNextInsuranceLossId()
    local id = self.nextInsuranceLossId or 1
    self.nextInsuranceLossId = id + 1
    return id
end

function RFF_FinanceRepository:addInsuranceLoss(loss)
    if loss ~= nil then table.insert(self.insuranceLosses, loss) end
end

function RFF_FinanceRepository:getInsuranceLossesByFarm(farmId)
    local result = {}
    for _, loss in ipairs(self.insuranceLosses or {}) do
        if loss.farmId == farmId then table.insert(result, loss) end
    end
    table.sort(result, function(a, b) return (a.id or 0) > (b.id or 0) end)
    return result
end

function RFF_FinanceRepository:getInsuranceLossById(farmId, lossId)
    for _, loss in ipairs(self.insuranceLosses or {}) do
        if loss.farmId == farmId and (loss.id or 0) == lossId then return loss end
    end
    return nil
end

function RFF_FinanceRepository:getNextInsuranceVeterinaryExpenseId()
    local id = self.nextInsuranceVeterinaryExpenseId or 1
    self.nextInsuranceVeterinaryExpenseId = id + 1
    return id
end

function RFF_FinanceRepository:addInsuranceVeterinaryExpense(expense)
    if expense ~= nil then table.insert(self.insuranceVeterinaryExpenses, expense) end
end

function RFF_FinanceRepository:getInsuranceVeterinaryExpensesByFarm(farmId)
    local result = {}
    for _, expense in ipairs(self.insuranceVeterinaryExpenses or {}) do
        if expense.farmId == farmId then table.insert(result, expense) end
    end
    table.sort(result, function(a, b)
        if (a.incidentPeriod or 0) == (b.incidentPeriod or 0) then return (a.id or 0) > (b.id or 0) end
        return (a.incidentPeriod or 0) > (b.incidentPeriod or 0)
    end)
    return result
end

function RFF_FinanceRepository:getInsuranceVeterinaryExpenseById(farmId, expenseId)
    for _, expense in ipairs(self.insuranceVeterinaryExpenses or {}) do
        if expense.farmId == farmId and (expense.id or 0) == expenseId then return expense end
    end
    return nil
end

function RFF_FinanceRepository:getNextAssetFinanceId()
    local id = self.nextAssetFinanceId or 1
    self.nextAssetFinanceId = id + 1
    return id
end

function RFF_FinanceRepository:addAssetFinance(agreement)
    if agreement ~= nil then table.insert(self.assetFinance, agreement) end
end

function RFF_FinanceRepository:getAssetFinanceByFarm(farmId, activeOnly)
    local result = {}
    for _, agreement in ipairs(self.assetFinance or {}) do
        local active = agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE"
        if agreement.farmId == farmId and (not activeOnly or active) then table.insert(result, agreement) end
    end
    return result
end

function RFF_FinanceRepository:getAssetFinanceByVehicle(uniqueId, activeOnly)
    if uniqueId == nil or uniqueId == "" then return nil end
    for _, agreement in ipairs(self.assetFinance or {}) do
        local active = agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE"
        if agreement.vehicleUniqueId == uniqueId and (not activeOnly or active) then return agreement end
    end
    return nil
end

function RFF_FinanceRepository:getOutstandingAssetFinanceBalance(farmId)
    local total = 0
    for _, agreement in ipairs(self.assetFinance or {}) do
        if agreement.farmId == farmId and (agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE") then
            if agreement.product ~= "OPERATING_LEASE" then
                total = total + math.max(0, safeNumber(agreement.principal))
            end
            total = total + math.max(0, safeNumber(agreement.arrearsBalance))
        end
    end
    return total
end

function RFF_FinanceRepository:getRefundableAssetFinanceDeposits(farmId)
    local total = 0
    for _, agreement in ipairs(self.assetFinance or {}) do
        if agreement.farmId == farmId and (agreement.status == "ACTIVE" or agreement.status == "RETURN_DUE") and agreement.product == "OPERATING_LEASE" then
            total = total + math.max(0, safeNumber(agreement.refundableDeposit))
        end
    end
    return total
end

function RFF_FinanceRepository:getNextTenancyId()
    local id = self.nextTenancyId or 1
    self.nextTenancyId = id + 1
    return id
end

function RFF_FinanceRepository:addTenancy(tenancy)
    if tenancy ~= nil then
        table.insert(self.tenancies, tenancy)
    end
end

function RFF_FinanceRepository:getTenancyById(farmId, tenancyId)
    tenancyId = tonumber(tenancyId) or 0
    for _, tenancy in ipairs(self.tenancies or {}) do
        if tenancy.id == tenancyId and (farmId == nil or tenancy.farmId == farmId) then return tenancy end
    end
    return nil
end

local TENANCY_POSSESSION_STATES = {ACTIVE=true, NOTICE_SERVED=true, RENEWAL_OFFERED=true, EXPIRING=true}

local function tenancyGrantsPossession(tenancy)
    return tenancy ~= nil and TENANCY_POSSESSION_STATES[tenancy.status or "ACTIVE"] == true
end

local function tenancyContainsFarmland(tenancy, farmlandId)
    farmlandId = tonumber(farmlandId) or 0
    for _, id in ipairs(tenancy.farmlandIds or {}) do
        if (tonumber(id) or 0) == farmlandId then return true end
    end
    return (tonumber(tenancy.farmlandId) or 0) == farmlandId
end

function RFF_FinanceRepository:getTenanciesByFarm(farmId, activeOnly)
    local result = {}
    for _, tenancy in ipairs(self.tenancies or {}) do
        if tenancy.farmId == farmId and (not activeOnly or tenancyGrantsPossession(tenancy)) then
            table.insert(result, tenancy)
        end
    end
    return result
end

function RFF_FinanceRepository:getTenancyByFarmland(farmlandId, activeOnly)
    for _, tenancy in ipairs(self.tenancies or {}) do
        if tenancyContainsFarmland(tenancy, farmlandId) and (not activeOnly or tenancyGrantsPossession(tenancy)) then
            return tenancy
        end
    end
    return nil
end

function RFF_FinanceRepository:getRefundableTenancyDeposits(farmId)
    local total = 0
    for _, tenancy in ipairs(self.tenancies or {}) do
        if tenancy.farmId == farmId and tenancyGrantsPossession(tenancy) and not tenancy.depositForfeited then
            total = total + math.max(0, safeNumber(tenancy.depositHeld or tenancy.securityDeposit))
        end
    end
    return total
end

function RFF_FinanceRepository:getMonthlyTenancyRent(farmId)
    local total = 0
    for _, tenancy in ipairs(self.tenancies or {}) do
        if tenancy.farmId == farmId and tenancyGrantsPossession(tenancy) then
            total = total + math.max(0, safeNumber(tenancy.annualRent or (safeNumber(tenancy.monthlyRent) * 12))) / 12
        end
    end
    return total
end

function RFF_FinanceRepository:getTenancyArrears(farmId)
    local total = 0
    for _, tenancy in ipairs(self.tenancies or {}) do
        if tenancy.farmId == farmId then total = total + math.max(0, safeNumber(tenancy.arrears or tenancy.rentDue)) end
    end
    return total
end


function RFF_FinanceRepository:getNextBrokerCaseId()
    local id = self.nextBrokerCaseId or 1
    self.nextBrokerCaseId = id + 1
    return id
end

function RFF_FinanceRepository:addBrokerCase(case)
    if case ~= nil then table.insert(self.brokerCases, case) end
end

function RFF_FinanceRepository:getBrokerCasesByFarm(farmId)
    local result = {}
    for _, case in ipairs(self.brokerCases or {}) do
        if case.farmId == farmId then table.insert(result, case) end
    end
    return result
end

function RFF_FinanceRepository:getNextPreApprovedOfferId()
    local id = self.nextPreApprovedOfferId or 1
    self.nextPreApprovedOfferId = id + 1
    return id
end

function RFF_FinanceRepository:addPreApprovedOffer(offer)
    if offer ~= nil then table.insert(self.preApprovedOffers, offer) end
end

function RFF_FinanceRepository:getPreApprovedOffersByFarm(farmId)
    local result = {}
    for _, offer in ipairs(self.preApprovedOffers or {}) do
        if offer.farmId == farmId then table.insert(result, offer) end
    end
    return result
end

function RFF_FinanceRepository:getBrokerRelationship(farmId, create)
    local rel = self.brokerRelationships[farmId]
    if rel == nil and create then
        rel = {farmId=farmId, casesInstructed=0, acceptedDeals=0, successfulIntroductions=0, feesPaid=0, relationshipPoints=0}
        self.brokerRelationships[farmId] = rel
    end
    return rel
end

function RFF_FinanceRepository:getLenderRelationship(farmId, lenderId, create)
    self.lenderRelationships[farmId] = self.lenderRelationships[farmId] or {}
    local rel = self.lenderRelationships[farmId][lenderId]
    if rel == nil and create then
        rel = {farmId=farmId, lenderId=lenderId, applications=0, offersMade=0, acceptedDeals=0, totalVolume=0, relationshipPoints=0,
            successfulPayments=0, missedPayments=0, completedAgreements=0, forcedRecoveries=0, mortgagePossessions=0,
            voluntarySurrenders=0, voluntaryPropertySales=0, restructures=0, arrearsCured=0, forbearanceArrangements=0,
            brokenForbearanceArrangements=0, rescueExits=0, rescueDeals=0, lastInteractionPeriod=0,
            proactiveOffersMade=0, proactiveOffersAccepted=0, proactiveOffersDeclined=0, lastProactiveOfferPeriod=0}
        self.lenderRelationships[farmId][lenderId] = rel
    end
    return rel
end

function RFF_FinanceRepository:getNextApplicationId()
    local id = self.nextApplicationId or 1
    self.nextApplicationId = id + 1
    return id
end

function RFF_FinanceRepository:addApplication(application)
    if application ~= nil then
        table.insert(self.applications, application)
    end
end

function RFF_FinanceRepository:getApplicationsByFarm(farmId)
    local result = {}
    for _, application in ipairs(self.applications or {}) do
        if application.farmId == farmId then
            table.insert(result, application)
        end
    end
    return result
end

function RFF_FinanceRepository:getNextLoanId()
    local id = self.nextLoanId or 1
    self.nextLoanId = id + 1
    return id
end

function RFF_FinanceRepository:addLoan(loan)
    if loan == nil then
        return
    end
    table.insert(self.loans, loan)
end

function RFF_FinanceRepository:getLoansByFarm(farmId, activeOnly)
    local result = {}
    for _, loan in ipairs(self.loans or {}) do
        if loan.farmId == farmId and (not activeOnly or not loan.paidOff) then
            table.insert(result, loan)
        end
    end
    return result
end

function RFF_FinanceRepository:getActiveOverdraft(farmId)
    local latest = nil
    for _, loan in ipairs(self.loans or {}) do
        if loan.farmId == farmId and loan.type == "OVERDRAFT" and not loan.paidOff then
            if latest == nil or safeNumber(loan.id) > safeNumber(latest.id) then latest = loan end
        end
    end
    return latest
end

function RFF_FinanceRepository:getOverdraftLimit(farmId)
    local loan = self:getActiveOverdraft(farmId)
    if loan == nil or loan.overdraftSuspended == true then return 0 end
    return math.max(0, safeNumber(loan.creditLimit))
end

function RFF_FinanceRepository:getAvailableFunds(farmId)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    if farm == nil then return 0 end
    return safeNumber(farm.money) + self:getOverdraftLimit(farmId)
end

function RFF_FinanceRepository:getBankAccountLiability(farmId)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    if farm == nil then return 0 end
    return math.max(0, -safeNumber(farm.money))
end

function RFF_FinanceRepository:getOverdraftBreachAmount(farmId)
    local loan = self:getActiveOverdraft(farmId)
    local debit = self:getBankAccountLiability(farmId)
    if debit <= 0 then return 0 end
    if loan == nil or loan.overdraftSuspended == true then return debit end
    return math.max(0, debit - math.max(0, safeNumber(loan.creditLimit)))
end

function RFF_FinanceRepository:getRepaymentRecord(farmId)
    local record = {
        paymentsMade = 0,
        missedPayments = 0,
        completedAgreements = 0,
        cleanCompletedAgreements = 0,
        interestPaid = 0,
        principalPaid = 0,
        currentArrears = 0,
        agreementsInArrears = 0,
        agreementsInDefault = 0,
        defaultEvents = 0,
        forcedPropertyRecoveryEvents = 0,
        lastForcedPropertyRecoveryPeriod = 0,
        consecutiveMissedPayments = 0,
        maxConsecutiveMissedPayments = 0,
        lastMissedPeriod = 0,
        lastSuccessfulPaymentPeriod = 0
    }
    local function include(entity)
        record.paymentsMade = record.paymentsMade + safeNumber(entity.paymentsMade)
        record.missedPayments = record.missedPayments + safeNumber(entity.missedPayments)
        record.interestPaid = record.interestPaid + safeNumber(entity.interestPaid)
        record.principalPaid = record.principalPaid + safeNumber(entity.principalPaid)
        local arrears = math.max(0, safeNumber(entity.arrearsBalance))
        record.currentArrears = record.currentArrears + arrears
        if arrears > 0.01 then record.agreementsInArrears = record.agreementsInArrears + 1 end
        local entityOpen = entity.paidOff ~= true and (entity.status == nil or entity.status == "ACTIVE" or entity.status == "RETURN_DUE")
        if entityOpen and (entity.currentDefault == true or entity.arrearsStage == "DEFAULT_NOTICE" or entity.arrearsStage == "RECOVERY") then
            record.agreementsInDefault = record.agreementsInDefault + 1
        end
        record.defaultEvents = record.defaultEvents + math.max(0, safeNumber(entity.defaultEvents))
        record.consecutiveMissedPayments = math.max(record.consecutiveMissedPayments, safeNumber(entity.consecutiveMissedPayments))
        record.maxConsecutiveMissedPayments = math.max(record.maxConsecutiveMissedPayments, safeNumber(entity.maxConsecutiveMissedPayments))
        record.lastMissedPeriod = math.max(record.lastMissedPeriod, safeNumber(entity.lastMissedPeriod))
        record.lastSuccessfulPaymentPeriod = math.max(record.lastSuccessfulPaymentPeriod, safeNumber(entity.lastSuccessfulPaymentPeriod))
    end

    for _, loan in ipairs(self.loans or {}) do
        if loan.farmId == farmId then
            include(loan)
            if loan.mortgageRecovered == true and loan.mortgageRecoveryMethod == "MORTGAGE_POSSESSION" then
                record.forcedPropertyRecoveryEvents = record.forcedPropertyRecoveryEvents + 1
                record.lastForcedPropertyRecoveryPeriod = math.max(record.lastForcedPropertyRecoveryPeriod, safeNumber(loan.mortgageRecoveredPeriod))
            end
            if loan.paidOff then
                record.completedAgreements = record.completedAgreements + 1
                if safeNumber(loan.missedPayments) == 0 then record.cleanCompletedAgreements = record.cleanCompletedAgreements + 1 end
            end
        end
    end
    for _, agreement in ipairs(self.assetFinance or {}) do
        if agreement.farmId == farmId then
            include(agreement)
            if agreement.status == "COMPLETED" or agreement.status == "RETURNED" or agreement.status == "RECOVERED" or agreement.status == "SURRENDERED" then
                record.completedAgreements = record.completedAgreements + 1
                if safeNumber(agreement.missedPayments) == 0 and agreement.status ~= "RECOVERED" and agreement.status ~= "SURRENDERED" then record.cleanCompletedAgreements = record.cleanCompletedAgreements + 1 end
            end
        end
    end
    return record
end

function RFF_FinanceRepository:getRecoveryShortfallBalance(farmId)
    local total = 0
    for _, loan in ipairs(self.loans or {}) do
        if loan.farmId == farmId and not loan.paidOff and loan.type == "RECOVERY_SHORTFALL" then
            total = total + math.max(0, safeNumber(loan.principal)) + math.max(0, safeNumber(loan.arrearsBalance))
        end
    end
    return total
end

function RFF_FinanceRepository:getCropAdvanceLiability(farmId)
    local total = 0
    for _, a in ipairs(self.cropAdvances or {}) do
        if a.farmId == farmId and a.status == "ACTIVE" and (a.committedLitres or 0) > 0 then
            total = total + (a.advance or 0) * math.max(0, 1 - (a.deliveredLitres or 0) / a.committedLitres)
        end
    end
    return total
end

function RFF_FinanceRepository:getOutstandingLoanBalance(farmId)
    local total = 0
    for _, loan in ipairs(self.loans or {}) do
        if loan.farmId == farmId and not loan.paidOff then
            if loan.type == "REVOLVING" then
                total = total + math.max(0, safeNumber(loan.drawnAmount))
            elseif loan.type ~= "OVERDRAFT" then
                total = total + math.max(0, safeNumber(loan.principal))
            end
            total = total + math.max(0, safeNumber(loan.arrearsBalance))
        end
    end
    return total
end

function RFF_FinanceRepository:captureSnapshot(farmId)
    if RFF_FarmValuation == nil then
        return
    end

    local period = self:getPeriod(farmId, self:getCurrentPeriodIndex(), true)
    period.snapshot = RFF_FarmValuation:calculate(farmId, self)
end

function RFF_FinanceRepository:getLatestSnapshot(farmId)
    local state = self:getFarmState(farmId, false)
    if state == nil then
        return nil, nil
    end

    local latestIndex = nil
    local latest = nil
    for index, period in pairs(state.periods) do
        if period.snapshot ~= nil and (latestIndex == nil or index > latestIndex) then
            latestIndex = index
            latest = period.snapshot
        end
    end
    return latest, latestIndex
end

function RFF_FinanceRepository:onPeriodChanged()
    if not self.loaded or g_currentMission == nil or not g_currentMission:getIsServer() then
        return
    end

    local currentIndex = self:getCurrentPeriodIndex()
    for farmId, state in pairs(self.farms) do
        local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
        local balance = farm ~= nil and safeNumber(farm.money) or nil
        local previous = state ~= nil and state.periods[currentIndex - 1] or nil
        if previous ~= nil and previous.closingBalance == nil and balance ~= nil then previous.closingBalance = balance end
        local currentPeriod = self:getPeriod(farmId, currentIndex, true)
        if currentPeriod.openingBalance == nil and balance ~= nil then currentPeriod.openingBalance = balance end
        self:captureSnapshot(farmId)
    end

    self:pruneHistory(36)
end

function RFF_FinanceRepository:pruneHistory(maxPeriods)
    local current = self:getCurrentPeriodIndex()
    local cutoff = current - (maxPeriods or 36) + 1
    for _, state in pairs(self.farms) do
        for index, _ in pairs(state.periods) do
            if index < cutoff then
                state.periods[index] = nil
            end
        end
    end
end

function RFF_FinanceRepository:ensureCurrentFarm()
    if g_currentMission == nil then
        return
    end

    local farmId = g_currentMission:getFarmId()
    if farmId ~= nil and farmId > 0 then
        self:getFarmState(farmId, true)
        self:getPeriod(farmId, self:getCurrentPeriodIndex(), true)
        self:captureSnapshot(farmId)
    end
end

function RFF_FinanceRepository:loadFromXMLFile()
    self.startupPeriod=nil
    self.cropAdvances = {}
    self.farms = {}
    self.loans = {}
    self.tenancies = {}
    self.applications = {}
    self.brokerCases = {}
    self.preApprovedOffers = {}
    self.brokerRelationships = {}
    self.lenderRelationships = {}
    self.assetFinance = {}
    self.vehicleInsurancePolicies = {}
    self.trafficCourtesyIncidents = {}
    self.driverOffences = {}
    self.speedingNotices = {}
    self.roadsideChecks = {}
    self.insuranceClaims = {}
    self.insuranceLosses = {}
    self.insuranceVeterinaryExpenses = {}
    self.nextAssetFinanceId = 1
    self.nextVehicleInsurancePolicyId = 1
    self.nextTrafficCourtesyIncidentId = 1
    self.nextDriverOffenceId = 1
    self.nextInsuranceClaimId = 1
    self.nextInsuranceLossId = 1
    self.nextInsuranceVeterinaryExpenseId = 1
    self.nextLoanId = 1
    self.nextTenancyId = 1
    self.nextApplicationId = 1
    self.nextBrokerCaseId = 1
    self.nextPreApprovedOfferId = 1
    self.pendingTransactionDescriptions = {}

    local savegameDir = g_currentMission ~= nil and g_currentMission.missionInfo.savegameDirectory or nil
    if savegameDir ~= nil then
        local path = savegameDir .. "/realisticFarmFinance.xml"
        local xmlFile = XMLFile.loadIfExists("realisticFarmFinance", path, "realisticFarmFinance")
        if xmlFile ~= nil then
            if RFF_CropAdvanceService ~= nil then RFF_CropAdvanceService.load(self, xmlFile) end
            if RFF_EconomyService ~= nil then RFF_EconomyService.load(self, xmlFile) end
            if RFF_SavingsService ~= nil then RFF_SavingsService.load(self, xmlFile) end
            if RFF_FinancialAdviserService ~= nil then RFF_FinancialAdviserService.load(self, xmlFile) end
            if RFF_InvestmentService ~= nil then RFF_InvestmentService.load(self, xmlFile) end
            if RFF_DealershipService ~= nil then RFF_DealershipService.load(self, xmlFile) end
            if RFF_NewSaveSetup ~= nil then RFF_NewSaveSetup.load(self, xmlFile) end
            self.nextLoanId = xmlFile:getInt("realisticFarmFinance#nextLoanId") or 1
            self.nextTenancyId = xmlFile:getInt("realisticFarmFinance#nextTenancyId") or 1
            self.nextApplicationId = xmlFile:getInt("realisticFarmFinance#nextApplicationId") or 1
            self.nextBrokerCaseId = xmlFile:getInt("realisticFarmFinance#nextBrokerCaseId") or 1
            self.nextPreApprovedOfferId = xmlFile:getInt("realisticFarmFinance#nextPreApprovedOfferId") or 1
            self.nextAssetFinanceId = xmlFile:getInt("realisticFarmFinance#nextAssetFinanceId") or 1
            self.nextVehicleInsurancePolicyId = xmlFile:getInt("realisticFarmFinance#nextVehicleInsurancePolicyId") or 1
            self.nextTrafficCourtesyIncidentId = xmlFile:getInt("realisticFarmFinance#nextTrafficCourtesyIncidentId") or 1
            self.nextDriverOffenceId = xmlFile:getInt("realisticFarmFinance#nextDriverOffenceId") or 1
            self.nextInsuranceClaimId = xmlFile:getInt("realisticFarmFinance#nextInsuranceClaimId") or 1
            self.nextInsuranceLossId = xmlFile:getInt("realisticFarmFinance#nextInsuranceLossId") or 1
            self.nextInsuranceVeterinaryExpenseId = xmlFile:getInt("realisticFarmFinance#nextInsuranceVeterinaryExpenseId") or 1

            local farmIndex = 0
            while true do
                local farmKey = string.format("realisticFarmFinance.farm(%d)", farmIndex)
                if not xmlFile:hasProperty(farmKey) then
                    break
                end

                local farmId = xmlFile:getInt(farmKey .. "#id") or 0
                if farmId > 0 then
                    local state = {
                        firstTrackedPeriod = xmlFile:getInt(farmKey .. "#firstTrackedPeriod") or self:getCurrentPeriodIndex(),
                        periods = {},
                        bankPositiveBalanceSum = xmlFile:getFloat(farmKey .. "#bankPositiveBalanceSum") or 0,
                        bankBalanceSamples = xmlFile:getInt(farmKey .. "#bankBalanceSamples") or 0,
                        bankLastInterestCredit = xmlFile:getFloat(farmKey .. "#bankLastInterestCredit") or 0,
                        bankLastInterestRate = xmlFile:getFloat(farmKey .. "#bankLastInterestRate") or 0,
                        bankLastAverageBalance = xmlFile:getFloat(farmKey .. "#bankLastAverageBalance") or 0,
                        bankLastInterestPeriod = xmlFile:getInt(farmKey .. "#bankLastInterestPeriod") or 0,
                        bankLastSamplePeriod = xmlFile:getInt(farmKey .. "#bankLastSamplePeriod") or 0,
                        bankLastUnauthorisedDay = xmlFile:getInt(farmKey .. "#bankLastUnauthorisedDay") or 0,
                        bankUnauthorisedInterestPaid = xmlFile:getFloat(farmKey .. "#bankUnauthorisedInterestPaid") or 0,
                        bankUnauthorisedFeesPaid = xmlFile:getFloat(farmKey .. "#bankUnauthorisedFeesPaid") or 0,
                        adminLastProcessedPeriod = xmlFile:getInt(farmKey .. "#adminLastProcessedPeriod") or self:getCurrentPeriodIndex(),
                        adminArrears = xmlFile:getFloat(farmKey .. "#adminArrears") or 0,
                        adminLastCharge = xmlFile:getFloat(farmKey .. "#adminLastCharge") or 0,
                        adminLastMonthlyCharge = xmlFile:getFloat(farmKey .. "#adminLastMonthlyCharge") or 0,
                        adminLastAnnualFilingCharge = xmlFile:getFloat(farmKey .. "#adminLastAnnualFilingCharge") or 0,
                        adminLastAnnualFilingYear = xmlFile:getInt(farmKey .. "#adminLastAnnualFilingYear") or -1,
                        adminLastLateFee = xmlFile:getFloat(farmKey .. "#adminLastLateFee") or 0,
                        adminTotalPaid = xmlFile:getFloat(farmKey .. "#adminTotalPaid") or 0,
                        adminMissedPayments = xmlFile:getInt(farmKey .. "#adminMissedPayments") or 0,
                        insuranceTier = xmlFile:getString(farmKey .. "#insuranceTier") or "STANDARD",
                        insuranceNextTier = xmlFile:getString(farmKey .. "#insuranceNextTier") or "STANDARD",
                        insuranceStatus = xmlFile:getString(farmKey .. "#insuranceStatus") or "ACTIVE",
                        insuranceNextRenewalPeriod = xmlFile:getInt(farmKey .. "#insuranceNextRenewalPeriod") or (self:getCurrentPeriodIndex() + 1),
                        insurancePremiumDue = xmlFile:getFloat(farmKey .. "#insurancePremiumDue") or 0,
                        insuranceLastPremium = xmlFile:getFloat(farmKey .. "#insuranceLastPremium") or 0,
                        insuranceLastValuation = xmlFile:getFloat(farmKey .. "#insuranceLastValuation") or 0,
                        insuranceLastRenewalPeriod = xmlFile:getInt(farmKey .. "#insuranceLastRenewalPeriod") or 0,
                        insuranceGraceUntilPeriod = xmlFile:getInt(farmKey .. "#insuranceGraceUntilPeriod") or 0,
                        insuranceTotalPaid = xmlFile:getFloat(farmKey .. "#insuranceTotalPaid") or 0,
                        insuranceMissedPremiums = xmlFile:getInt(farmKey .. "#insuranceMissedPremiums") or 0,
                        insuranceRenewalNoticePeriod = xmlFile:getInt(farmKey .. "#insuranceRenewalNoticePeriod") or 0,
                        vehicleInsuranceMigrated = xmlFile:getBool(farmKey .. "#vehicleInsuranceMigrated") or false,
                        vehicleInsuranceTier = xmlFile:getString(farmKey .. "#vehicleInsuranceTier"),
                        vehicleInsuranceNextTier = xmlFile:getString(farmKey .. "#vehicleInsuranceNextTier"),
                        vehicleInsuranceStatus = xmlFile:getString(farmKey .. "#vehicleInsuranceStatus"),
                        vehicleInsuranceNextRenewalPeriod = xmlFile:getInt(farmKey .. "#vehicleInsuranceNextRenewalPeriod"),
                        vehicleInsurancePremiumDue = xmlFile:getFloat(farmKey .. "#vehicleInsurancePremiumDue"),
                        vehicleInsuranceLastPremium = xmlFile:getFloat(farmKey .. "#vehicleInsuranceLastPremium"),
                        vehicleInsuranceLastValuation = xmlFile:getFloat(farmKey .. "#vehicleInsuranceLastValuation"),
                        vehicleInsuranceLastRenewalPeriod = xmlFile:getInt(farmKey .. "#vehicleInsuranceLastRenewalPeriod"),
                        vehicleInsuranceGraceUntilPeriod = xmlFile:getInt(farmKey .. "#vehicleInsuranceGraceUntilPeriod"),
                        vehicleInsuranceTotalPaid = xmlFile:getFloat(farmKey .. "#vehicleInsuranceTotalPaid"),
                        vehicleInsuranceMissedPremiums = xmlFile:getInt(farmKey .. "#vehicleInsuranceMissedPremiums"),
                        vehicleInsuranceRenewalNoticePeriod = xmlFile:getInt(farmKey .. "#vehicleInsuranceRenewalNoticePeriod"),
                        vehicleInsurancePerVehicleMigrated = xmlFile:getBool(farmKey .. "#vehicleInsurancePerVehicleMigrated") or false,
                        driverQualificationVersion = xmlFile:getInt(farmKey .. "#driverQualificationVersion") or 1,
                        driverLicenceMode = xmlFile:getString(farmKey .. "#driverLicenceMode"),
                        driverCategoryB = xmlFile:getBool(farmKey .. "#driverCategoryB") ~= false,
                        driverCategoryF = xmlFile:getBool(farmKey .. "#driverCategoryF") == true,
                        driverCategoryH = xmlFile:getBool(farmKey .. "#driverCategoryH") == true,
                        driverCategoryC = xmlFile:getBool(farmKey .. "#driverCategoryC") == true,
                        driverAdr = xmlFile:getBool(farmKey .. "#driverAdr") == true,
                        driverPenaltyPoints = xmlFile:getInt(farmKey .. "#driverPenaltyPoints") or 0,
                        driverPointsVersion = xmlFile:getInt(farmKey .. "#driverPointsVersion") or 0,
                        driverSpecialistRevoked = xmlFile:getBool(farmKey .. "#driverSpecialistRevoked") == true,
                        driverPenaltiesEnabled = xmlFile:getBool(farmKey .. "#driverPenaltiesEnabled") == true,
                        speedingEnforcementEnabled = xmlFile:getBool(farmKey .. "#speedingEnforcementEnabled") == true,
                        roadsideChecksEnabled = xmlFile:getBool(farmKey .. "#roadsideChecksEnabled") == true,
                        roadsideCheckRemaining = xmlFile:getFloat(farmKey .. "#roadsideCheckRemaining"),
                        roadsideCooldownUntil = xmlFile:getFloat(farmKey .. "#roadsideCooldownUntil") or 0,
                        speedingCheckRemaining = xmlFile:getFloat(farmKey .. "#speedingCheckRemaining"),
                        speedingWindowRemaining = xmlFile:getFloat(farmKey .. "#speedingWindowRemaining") or 0,
                        speedingCooldownUntil = xmlFile:getFloat(farmKey .. "#speedingCooldownUntil") or 0,
                        vehicleInsurancePointsEnabled = xmlFile:getBool(farmKey .. "#vehicleInsurancePointsEnabled") == true,
                        roadSpeedHudEnabled = xmlFile:getBool(farmKey .. "#roadSpeedHudEnabled") ~= false,
                        driverRestrictionEnd = xmlFile:getFloat(farmKey .. "#driverRestrictionEnd") or 0,
                        driverRestrictionRepeats = xmlFile:getInt(farmKey .. "#driverRestrictionRepeats") or 0,
                        driverRestrictionServedPoints = xmlFile:getInt(farmKey .. "#driverRestrictionServedPoints") or 0,
                        driverAssessmentCategory = xmlFile:getString(farmKey .. "#driverAssessmentCategory") or "",
                        driverAssessmentStatus = xmlFile:getString(farmKey .. "#driverAssessmentStatus") or "NONE",
                        driverAssessmentBookedDay = xmlFile:getInt(farmKey .. "#driverAssessmentBookedDay") or 0,
                        driverAssessmentAvailableDay = xmlFile:getInt(farmKey .. "#driverAssessmentAvailableDay") or 0,
                        driverAssessmentDeadlineDay = xmlFile:getInt(farmKey .. "#driverAssessmentDeadlineDay") or 0,
                        driverAssessmentReturnDeadlineHour = xmlFile:getFloat(farmKey .. "#driverAssessmentReturnDeadlineHour") or 0,
                        driverAssessmentVehicleUniqueId = xmlFile:getString(farmKey .. "#driverAssessmentVehicleUniqueId") or "",
                        driverAssessmentVehicleName = xmlFile:getString(farmKey .. "#driverAssessmentVehicleName") or "",
                        driverAssessmentDistance = xmlFile:getFloat(farmKey .. "#driverAssessmentDistance") or 0,
                        driverAssessmentRoadDistance = xmlFile:getFloat(farmKey .. "#driverAssessmentRoadDistance") or 0,
                        driverAssessmentReverseDistance = xmlFile:getFloat(farmKey .. "#driverAssessmentReverseDistance") or 0,
                        driverAssessmentMovingSeconds = xmlFile:getFloat(farmKey .. "#driverAssessmentMovingSeconds") or 0,
                        driverAssessmentLeftTurnDegrees = xmlFile:getFloat(farmKey .. "#driverAssessmentLeftTurnDegrees") or 0,
                        driverAssessmentRightTurnDegrees = xmlFile:getFloat(farmKey .. "#driverAssessmentRightTurnDegrees") or 0,
                        driverAssessmentSpeedFaultSeconds = xmlFile:getFloat(farmKey .. "#driverAssessmentSpeedFaultSeconds") or 0,
                        driverAssessmentCollisionCount = xmlFile:getInt(farmKey .. "#driverAssessmentCollisionCount") or 0,
                        driverAssessmentTheoryIndex = xmlFile:getInt(farmKey .. "#driverAssessmentTheoryIndex") or 0,
                        driverAssessmentTheoryScore = xmlFile:getInt(farmKey .. "#driverAssessmentTheoryScore") or 0,
                        driverAssessmentFailureReason = xmlFile:getString(farmKey .. "#driverAssessmentFailureReason") or "",
                        driverAssessmentLastResultCategory = xmlFile:getString(farmKey .. "#driverAssessmentLastResultCategory") or "",
                        driverAssessmentLastResult = xmlFile:getString(farmKey .. "#driverAssessmentLastResult") or "",
                        movementAuthorisations = {},
                        taxReturnYear = xmlFile:getInt(farmKey .. "#taxReturnYear") or 0,
                        taxReturnStatus = xmlFile:getString(farmKey .. "#taxReturnStatus") or "NONE",
                        taxReturnOpenPeriod = xmlFile:getInt(farmKey .. "#taxReturnOpenPeriod") or 0,
                        taxReturnFiledPeriod = xmlFile:getInt(farmKey .. "#taxReturnFiledPeriod") or 0,
                        taxReturnMethod = xmlFile:getString(farmKey .. "#taxReturnMethod") or "NONE",
                        taxReturnSignedBy = xmlFile:getString(farmKey .. "#taxReturnSignedBy") or "",
                        taxReturnBookIncome = xmlFile:getFloat(farmKey .. "#taxReturnBookIncome") or 0,
                        taxReturnBookTaxedIncome = xmlFile:getFloat(farmKey .. "#taxReturnBookTaxedIncome") or 0,
                        taxReturnBookExpenses = xmlFile:getFloat(farmKey .. "#taxReturnBookExpenses") or 0,
                        taxReturnBookTax = xmlFile:getFloat(farmKey .. "#taxReturnBookTax") or 0,
                        taxReturnLossRollover = xmlFile:getFloat(farmKey .. "#taxReturnLossRollover") or 0,
                        taxReturnTaxRate = xmlFile:getFloat(farmKey .. "#taxReturnTaxRate") or 0,
                        taxReturnIncomeFactor = xmlFile:getFloat(farmKey .. "#taxReturnIncomeFactor") or 1,
                        taxReturnExpenseFactor = xmlFile:getFloat(farmKey .. "#taxReturnExpenseFactor") or 1,
                        taxReturnDeclaredIncome = xmlFile:getFloat(farmKey .. "#taxReturnDeclaredIncome") or 0,
                        taxReturnDeclaredTaxedIncome = xmlFile:getFloat(farmKey .. "#taxReturnDeclaredTaxedIncome") or 0,
                        taxReturnDeclaredExpenses = xmlFile:getFloat(farmKey .. "#taxReturnDeclaredExpenses") or 0,
                        taxReturnFiledTax = xmlFile:getFloat(farmKey .. "#taxReturnFiledTax") or 0,
                        taxReturnTaxSaving = xmlFile:getFloat(farmKey .. "#taxReturnTaxSaving") or 0,
                        taxReturnAdjustment = xmlFile:getFloat(farmKey .. "#taxReturnAdjustment") or 0,
                        taxReturnAdjustmentApplied = xmlFile:getBool(farmKey .. "#taxReturnAdjustmentApplied") == true,
                        taxReturnAccountantFee = xmlFile:getFloat(farmKey .. "#taxReturnAccountantFee") or 0,
                        taxReturnWasForcedTest = xmlFile:getBool(farmKey .. "#taxReturnWasForcedTest") == true,
                        taxComplianceFlags = xmlFile:getInt(farmKey .. "#taxComplianceFlags") or 0,
                        taxComplianceCleanFilings = xmlFile:getInt(farmKey .. "#taxComplianceCleanFilings") or 0,
                        taxComplianceAggressiveFilings = xmlFile:getInt(farmKey .. "#taxComplianceAggressiveFilings") or 0,
                        taxComplianceLiability = xmlFile:getFloat(farmKey .. "#taxComplianceLiability") or 0,
                        taxComplianceLastInterestPeriod = xmlFile:getInt(farmKey .. "#taxComplianceLastInterestPeriod") or 0,
                        taxInvestigationStatus = xmlFile:getString(farmKey .. "#taxInvestigationStatus") or "NONE",
                        taxInvestigationStartPeriod = xmlFile:getInt(farmKey .. "#taxInvestigationStartPeriod") or 0,
                        taxInvestigationOutcomePeriod = xmlFile:getInt(farmKey .. "#taxInvestigationOutcomePeriod") or 0,
                        taxInvestigationLastOutcome = xmlFile:getString(farmKey .. "#taxInvestigationLastOutcome") or "NONE",
                        taxInvestigationAdjustment = xmlFile:getFloat(farmKey .. "#taxInvestigationAdjustment") or 0,
                        taxInvestigationPenalty = xmlFile:getFloat(farmKey .. "#taxInvestigationPenalty") or 0,
                        taxInvestigationInterest = xmlFile:getFloat(farmKey .. "#taxInvestigationInterest") or 0,
                        legacyLoanMigrationVersion = xmlFile:getInt(farmKey .. "#legacyLoanMigrationVersion") or 0,
                        legacyLoanImportedAmount = xmlFile:getFloat(farmKey .. "#legacyLoanImportedAmount") or 0,
                        legacyLoanImportedId = xmlFile:getInt(farmKey .. "#legacyLoanImportedId") or 0,
                        externalFinanceMigrationIds = xmlFile:getString(farmKey .. "#externalFinanceMigrationIds") or ""
                    }

                    local movementAuthorisationIndex = 0
                    while true do
                        local authorisationKey = string.format("%s.movementAuthorisation(%d)", farmKey, movementAuthorisationIndex)
                        if not xmlFile:hasProperty(authorisationKey) then break end
                        local vehicleUniqueId = xmlFile:getString(authorisationKey .. "#vehicleUniqueId") or ""
                        if vehicleUniqueId ~= "" then
                            state.movementAuthorisations[vehicleUniqueId] = {
                                vehicleUniqueId=vehicleUniqueId,
                                vehicleName=xmlFile:getString(authorisationKey .. "#vehicleName") or "Vehicle",
                                authorisedWidth=xmlFile:getFloat(authorisationKey .. "#authorisedWidth") or 0,
                                issuedHour=xmlFile:getFloat(authorisationKey .. "#issuedHour") or 0,
                                expiresHour=xmlFile:getFloat(authorisationKey .. "#expiresHour") or 0
                            }
                        end
                        movementAuthorisationIndex = movementAuthorisationIndex + 1
                    end

                    local periodIndex = 0
                    while true do
                        local periodKey = string.format("%s.period(%d)", farmKey, periodIndex)
                        if not xmlFile:hasProperty(periodKey) then
                            break
                        end

                        local absoluteIndex = xmlFile:getInt(periodKey .. "#index")
                        if absoluteIndex ~= nil then
                            local period = {
                                inflows = xmlFile:getFloat(periodKey .. "#inflows") or 0,
                                outflows = xmlFile:getFloat(periodKey .. "#outflows") or 0,
                                operatingIncome = xmlFile:getFloat(periodKey .. "#operatingIncome") or 0,
                                openingBalance = xmlFile:getFloat(periodKey .. "#openingBalance"),
                                closingBalance = xmlFile:getFloat(periodKey .. "#closingBalance"),
                                year = xmlFile:getInt(periodKey .. "#year"),
                                periodNumber = xmlFile:getInt(periodKey .. "#periodNumber"),
                                statementTruncated = xmlFile:getBool(periodKey .. "#statementTruncated") or false,
                                transactions = {},
                                snapshot = nil
                            }

                            local transactionIndex = 0
                            while true do
                                local transactionKey = string.format("%s.transaction(%d)", periodKey, transactionIndex)
                                if not xmlFile:hasProperty(transactionKey) then break end
                                table.insert(period.transactions, {
                                    day = xmlFile:getInt(transactionKey .. "#day") or 1,
                                    year = xmlFile:getInt(transactionKey .. "#year") or 0,
                                    periodNumber = xmlFile:getInt(transactionKey .. "#periodNumber") or 0,
                                    amount = xmlFile:getFloat(transactionKey .. "#amount") or 0,
                                    balance = xmlFile:getFloat(transactionKey .. "#balance") or 0,
                                    description = xmlFile:getString(transactionKey .. "#description") or "Account transaction",
                                    statistic = xmlFile:getString(transactionKey .. "#statistic") or ""
                                })
                                transactionIndex = transactionIndex + 1
                            end

                            if xmlFile:getBool(periodKey .. ".snapshot#valid") then
                                period.snapshot = {
                                    cash = xmlFile:getFloat(periodKey .. ".snapshot#cash") or 0,
                                    farmland = xmlFile:getFloat(periodKey .. ".snapshot#farmland") or 0,
                                    buildings = xmlFile:getFloat(periodKey .. ".snapshot#buildings") or 0,
                                    equipment = xmlFile:getFloat(periodKey .. ".snapshot#equipment") or 0,
                                    livestock = xmlFile:getFloat(periodKey .. ".snapshot#livestock") or 0,
                                    inventory = xmlFile:getFloat(periodKey .. ".snapshot#inventory") or 0,
                                    refundableDeposits = xmlFile:getFloat(periodKey .. ".snapshot#refundableDeposits") or 0,
                                    totalAssets = xmlFile:getFloat(periodKey .. ".snapshot#totalAssets") or 0,
                                    liabilities = xmlFile:getFloat(periodKey .. ".snapshot#liabilities") or 0,
                                    netWorth = xmlFile:getFloat(periodKey .. ".snapshot#netWorth") or 0
                                }
                            end
                            state.periods[absoluteIndex] = period
                        end
                        periodIndex = periodIndex + 1
                    end
                    self.farms[farmId] = state
                end
                farmIndex = farmIndex + 1
            end

            local loanIndex = 0
            while true do
                local loanKey = string.format("realisticFarmFinance.loan(%d)", loanIndex)
                if not xmlFile:hasProperty(loanKey) then
                    break
                end

                local id = xmlFile:getInt(loanKey .. "#id")
                local farmId = xmlFile:getInt(loanKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local loan = {
                        id = id,
                        farmId = farmId,
                        type = xmlFile:getString(loanKey .. "#type") or "TERM",
                        purpose = xmlFile:getString(loanKey .. "#purpose") or "GENERAL",
                        originalAmount = xmlFile:getFloat(loanKey .. "#originalAmount") or 0,
                        creditLimit = xmlFile:getFloat(loanKey .. "#creditLimit") or 0,
                        principal = xmlFile:getFloat(loanKey .. "#principal") or 0,
                        drawnAmount = xmlFile:getFloat(loanKey .. "#drawnAmount") or 0,
                        interestRate = xmlFile:getFloat(loanKey .. "#interestRate") or 0,
                        termMonths = xmlFile:getInt(loanKey .. "#termMonths") or 0,
                        remainingMonths = xmlFile:getInt(loanKey .. "#remainingMonths") or 0,
                        monthlyPayment = xmlFile:getFloat(loanKey .. "#monthlyPayment") or 0,
                        riskGrade = xmlFile:getString(loanKey .. "#riskGrade") or "C",
                        createdPeriod = xmlFile:getInt(loanKey .. "#createdPeriod") or self:getCurrentPeriodIndex(),
                        lastPaymentPeriod = xmlFile:getInt(loanKey .. "#lastPaymentPeriod") or self:getCurrentPeriodIndex(),
                        paymentsMade = xmlFile:getInt(loanKey .. "#paymentsMade") or 0,
                        missedPayments = xmlFile:getInt(loanKey .. "#missedPayments") or 0,
                        arrearsPrincipal = xmlFile:getFloat(loanKey .. "#arrearsPrincipal") or 0,
                        arrearsInterest = xmlFile:getFloat(loanKey .. "#arrearsInterest") or 0,
                        arrearsRent = 0,
                        arrearsFees = xmlFile:getFloat(loanKey .. "#arrearsFees") or 0,
                        arrearsBalance = xmlFile:getFloat(loanKey .. "#arrearsBalance") or 0,
                        arrearsAgeMonths = xmlFile:getInt(loanKey .. "#arrearsAgeMonths") or 0,
                        arrearsStage = xmlFile:getString(loanKey .. "#arrearsStage") or "CURRENT",
                        defaultInterestAccrued = xmlFile:getFloat(loanKey .. "#defaultInterestAccrued") or 0,
                        adminChargesAccrued = xmlFile:getFloat(loanKey .. "#adminChargesAccrued") or 0,
                        defaultEvents = xmlFile:getInt(loanKey .. "#defaultEvents") or 0,
                        currentDefault = xmlFile:getBool(loanKey .. "#currentDefault") or false,
                        defaultRecorded = xmlFile:getBool(loanKey .. "#defaultRecorded") or false,
                        recoveryEligible = xmlFile:getBool(loanKey .. "#recoveryEligible") or false,
                        lastDefaultManagementPeriod = xmlFile:getInt(loanKey .. "#lastDefaultManagementPeriod") or 0,
                        consecutiveMissedPayments = xmlFile:getInt(loanKey .. "#consecutiveMissedPayments") or 0,
                        maxConsecutiveMissedPayments = xmlFile:getInt(loanKey .. "#maxConsecutiveMissedPayments") or 0,
                        lastMissedPeriod = xmlFile:getInt(loanKey .. "#lastMissedPeriod") or 0,
                        lastSuccessfulPaymentPeriod = xmlFile:getInt(loanKey .. "#lastSuccessfulPaymentPeriod") or 0,
                        lastArrearsClearedPeriod = xmlFile:getInt(loanKey .. "#lastArrearsClearedPeriod") or 0,
                        arrearsSchemaVersion = xmlFile:getInt(loanKey .. "#arrearsSchemaVersion") or 0,
                        principalPaid = xmlFile:getFloat(loanKey .. "#principalPaid") or 0,
                        interestPaid = xmlFile:getFloat(loanKey .. "#interestPaid") or 0,
                        completedPeriod = xmlFile:getInt(loanKey .. "#completedPeriod") or 0,
                        paidOff = xmlFile:getBool(loanKey .. "#paidOff") or false,
                        legacyImported = xmlFile:getBool(loanKey .. "#legacyImported") or false,
                        relationshipCompletionRecorded = xmlFile:getBool(loanKey .. "#relationshipCompletionRecorded") or false,
                        securityFarmlandId = xmlFile:getInt(loanKey .. "#securityFarmlandId") or 0,
                        securityFarmlandIds = xmlFile:getString(loanKey .. "#securityFarmlandIds") or "",
                        securityFarmlandCount = xmlFile:getInt(loanKey .. "#securityFarmlandCount") or 0,
                        releasedSecurityFarmlandIds = xmlFile:getString(loanKey .. "#releasedSecurityFarmlandIds") or "",
                        releasedSecurityFarmlandCount = xmlFile:getInt(loanKey .. "#releasedSecurityFarmlandCount") or 0,
                        purchasePrice = xmlFile:getFloat(loanKey .. "#purchasePrice") or 0,
                        depositPaid = xmlFile:getFloat(loanKey .. "#depositPaid") or 0,
                        lenderValuation = xmlFile:getFloat(loanKey .. "#lenderValuation") or 0,
                        propertyLtv = xmlFile:getFloat(loanKey .. "#propertyLtv") or 0,
                        propertyLtvLimit = xmlFile:getFloat(loanKey .. "#propertyLtvLimit") or 0,
                        applicationId = xmlFile:getInt(loanKey .. "#applicationId") or 0,
                        propertyFinanceMode = xmlFile:getString(loanKey .. "#propertyFinanceMode") or "",
                        equityRelease = xmlFile:getBool(loanKey .. "#equityRelease") or false,
                        holdingEquityRelease = xmlFile:getBool(loanKey .. "#holdingEquityRelease") or false,
                        equityReleasedAmount = xmlFile:getFloat(loanKey .. "#equityReleasedAmount") or 0,
                        lenderId = xmlFile:getString(loanKey .. "#lenderId") or "PRIMARY_BANK",
                        lenderNameKey = xmlFile:getString(loanKey .. "#lenderNameKey") or "rff_lender_primary_bank",
                        brokered = xmlFile:getBool(loanKey .. "#brokered") or false,
                        brokerCaseId = xmlFile:getInt(loanKey .. "#brokerCaseId") or 0,
                        arrangementFee = xmlFile:getFloat(loanKey .. "#arrangementFee") or 0,
                        brokerFee = xmlFile:getFloat(loanKey .. "#brokerFee") or 0,
                        overdraftSuspended = xmlFile:getBool(loanKey .. "#overdraftSuspended") or false,
                        overdraftOverLimit = xmlFile:getFloat(loanKey .. "#overdraftOverLimit") or 0,
                        overdraftLimitBreaches = xmlFile:getInt(loanKey .. "#overdraftLimitBreaches") or 0,
                        lastOverdraftBreachPeriod = xmlFile:getInt(loanKey .. "#lastOverdraftBreachPeriod") or 0,
                        overdraftReviewCount = xmlFile:getInt(loanKey .. "#overdraftReviewCount") or 0,
                        overdraftWarningTwoMonths = xmlFile:getBool(loanKey .. "#overdraftWarningTwoMonths") or false,
                        overdraftWarningOneMonth = xmlFile:getBool(loanKey .. "#overdraftWarningOneMonth") or false,
                        recoveryLiability = xmlFile:getBool(loanKey .. "#recoveryLiability") or false,
                        sourceRecoveryType = xmlFile:getString(loanKey .. "#sourceRecoveryType") or "",
                        sourceAssetAgreementId = xmlFile:getInt(loanKey .. "#sourceAssetAgreementId") or 0,
                        sourceAssetName = xmlFile:getString(loanKey .. "#sourceAssetName") or "",
                        sourceMortgageLoanId = xmlFile:getInt(loanKey .. "#sourceMortgageLoanId") or 0,
                        sourceFarmlandId = xmlFile:getInt(loanKey .. "#sourceFarmlandId") or 0,
                        capitalisedInterest = xmlFile:getFloat(loanKey .. "#capitalisedInterest") or 0,
                        capitalisedAdminCharges = xmlFile:getFloat(loanKey .. "#capitalisedAdminCharges") or 0,
                        recoveryMethod = xmlFile:getString(loanKey .. "#recoveryMethod") or "",
                        recoveryRealisedValue = xmlFile:getFloat(loanKey .. "#recoveryRealisedValue") or 0,
                        recoveryCosts = xmlFile:getFloat(loanKey .. "#recoveryCosts") or 0,
                        mortgageRestructureCount = xmlFile:getInt(loanKey .. "#mortgageRestructureCount") or 0,
                        mortgageLastRestructurePeriod = xmlFile:getInt(loanKey .. "#mortgageLastRestructurePeriod") or 0,
                        mortgageCapitalisedArrears = xmlFile:getFloat(loanKey .. "#mortgageCapitalisedArrears") or 0,
                        mortgageRateBeforeRestructure = xmlFile:getFloat(loanKey .. "#mortgageRateBeforeRestructure") or 0,
                        mortgagePaymentBeforeRestructure = xmlFile:getFloat(loanKey .. "#mortgagePaymentBeforeRestructure") or 0,
                        mortgageRecoveryEligiblePeriod = xmlFile:getInt(loanKey .. "#mortgageRecoveryEligiblePeriod") or 0,
                        mortgageRecoveryPending = xmlFile:getBool(loanKey .. "#mortgageRecoveryPending") or false,
                        mortgageRecovered = xmlFile:getBool(loanKey .. "#mortgageRecovered") or false,
                        mortgageRecoveredPeriod = xmlFile:getInt(loanKey .. "#mortgageRecoveredPeriod") or 0,
                        mortgageRecoveryMethod = xmlFile:getString(loanKey .. "#mortgageRecoveryMethod") or "",
                        mortgageMarketValue = xmlFile:getFloat(loanKey .. "#mortgageMarketValue") or 0,
                        mortgageRealisedValue = xmlFile:getFloat(loanKey .. "#mortgageRealisedValue") or 0,
                        mortgageRecoveryCosts = xmlFile:getFloat(loanKey .. "#mortgageRecoveryCosts") or 0,
                        mortgageDebtAtRecovery = xmlFile:getFloat(loanKey .. "#mortgageDebtAtRecovery") or 0,
                        mortgageRecoveryShortfall = xmlFile:getFloat(loanKey .. "#mortgageRecoveryShortfall") or 0,
                        mortgageRecoverySurplus = xmlFile:getFloat(loanKey .. "#mortgageRecoverySurplus") or 0,
                        mortgageRecoveredFixtureCount = xmlFile:getInt(loanKey .. "#mortgageRecoveredFixtureCount") or 0,
                        mortgageRecoveredFixtureMarketValue = xmlFile:getFloat(loanKey .. "#mortgageRecoveredFixtureMarketValue") or 0,
                        mortgageRecoveredFixtureRealisedValue = xmlFile:getFloat(loanKey .. "#mortgageRecoveredFixtureRealisedValue") or 0,
                        mortgageForcedLivestockCount = xmlFile:getInt(loanKey .. "#mortgageForcedLivestockCount") or 0,
                        mortgageForcedLivestockMarketValue = xmlFile:getFloat(loanKey .. "#mortgageForcedLivestockMarketValue") or 0,
                        mortgageForcedLivestockProceeds = xmlFile:getFloat(loanKey .. "#mortgageForcedLivestockProceeds") or 0,
                        mortgageRecoveryPlaceablesDeleted = xmlFile:getInt(loanKey .. "#mortgageRecoveryPlaceablesDeleted") or 0,
                        mortgageRecoveryPlaceablesTransferred = xmlFile:getInt(loanKey .. "#mortgageRecoveryPlaceablesTransferred") or 0,
                        mortgageRecoveryPlaceablesPromotedToFarmland = xmlFile:getInt(loanKey .. "#mortgageRecoveryPlaceablesPromotedToFarmland") or 0,
                        mortgageRecoveryPlaceableFailures = xmlFile:getInt(loanKey .. "#mortgageRecoveryPlaceableFailures") or 0,
                        mortgageRecoveryAnimalClusterFailures = xmlFile:getInt(loanKey .. "#mortgageRecoveryAnimalClusterFailures") or 0,
                        mortgageRecoveryLiabilityLoanId = xmlFile:getInt(loanKey .. "#mortgageRecoveryLiabilityLoanId") or 0,
                        mortgageRecoveredFarmlandIds = xmlFile:getString(loanKey .. "#mortgageRecoveredFarmlandIds") or "",
                        mortgageRecoveredFarmlandCount = xmlFile:getInt(loanKey .. "#mortgageRecoveredFarmlandCount") or 0,
                        refinanced = xmlFile:getBool(loanKey .. "#refinanced") or false,
                        refinancedPeriod = xmlFile:getInt(loanKey .. "#refinancedPeriod") or 0,
                        refinancedByLoanId = xmlFile:getInt(loanKey .. "#refinancedByLoanId") or 0,
                        refinance = xmlFile:getBool(loanKey .. "#refinance") or false,
                        consolidation = xmlFile:getBool(loanKey .. "#consolidation") or false,
                        refinanceSourceLoanIds = xmlFile:getString(loanKey .. "#refinanceSourceLoanIds") or "",
                        refinanceSourceCount = xmlFile:getInt(loanKey .. "#refinanceSourceCount") or 0,
                        refinanceSettlementAmount = xmlFile:getFloat(loanKey .. "#refinanceSettlementAmount") or 0,
                        refinancePreviousDebtService = xmlFile:getFloat(loanKey .. "#refinancePreviousDebtService") or 0,
                        refinancePreviousProjectedInterest = xmlFile:getFloat(loanKey .. "#refinancePreviousProjectedInterest") or 0,
                        refinanceMarketState = xmlFile:getString(loanKey .. "#refinanceMarketState") or "",
                        refinanceDealFit = xmlFile:getString(loanKey .. "#refinanceDealFit") or "",
                        refinanceRelationshipTier = xmlFile:getString(loanKey .. "#refinanceRelationshipTier") or "",
                        forbearanceCount = xmlFile:getInt(loanKey .. "#forbearanceCount") or 0,
                        forbearanceLastPeriod = xmlFile:getInt(loanKey .. "#forbearanceLastPeriod") or 0,
                        forbearanceLastType = xmlFile:getString(loanKey .. "#forbearanceLastType") or "",
                        forbearanceMode = xmlFile:getString(loanKey .. "#forbearanceMode") or "",
                        forbearanceRemainingPeriods = xmlFile:getInt(loanKey .. "#forbearanceRemainingPeriods") or 0,
                        forbearanceCapitalisedArrears = xmlFile:getFloat(loanKey .. "#forbearanceCapitalisedArrears") or 0,
                        forbearanceCapitalisedInterest = xmlFile:getFloat(loanKey .. "#forbearanceCapitalisedInterest") or 0,
                        forbearanceOriginalPayment = xmlFile:getFloat(loanKey .. "#forbearanceOriginalPayment") or 0,
                        forbearanceOriginalRate = xmlFile:getFloat(loanKey .. "#forbearanceOriginalRate") or 0,
                        forbearanceBroken = xmlFile:getBool(loanKey .. "#forbearanceBroken") or false,
                        forbearanceOfferStatus = xmlFile:getString(loanKey .. "#forbearanceOfferStatus") or "",
                        forbearanceOfferType = xmlFile:getString(loanKey .. "#forbearanceOfferType") or "",
                        forbearanceOfferCreatedPeriod = xmlFile:getInt(loanKey .. "#forbearanceOfferCreatedPeriod") or 0,
                        forbearanceOfferExpiryPeriod = xmlFile:getInt(loanKey .. "#forbearanceOfferExpiryPeriod") or 0,
                        forbearanceOfferLastPeriod = xmlFile:getInt(loanKey .. "#forbearanceOfferLastPeriod") or 0,
                        rescueRefinanced = xmlFile:getBool(loanKey .. "#rescueRefinanced") or false,
                        rescueRefinancedPeriod = xmlFile:getInt(loanKey .. "#rescueRefinancedPeriod") or 0,
                        rescueRefinancedByLoanId = xmlFile:getInt(loanKey .. "#rescueRefinancedByLoanId") or 0,
                        rescueSettlementAmount = xmlFile:getFloat(loanKey .. "#rescueSettlementAmount") or 0,
                        rescueFinance = xmlFile:getBool(loanKey .. "#rescueFinance") or false,
                        rescueSourceLoanId = xmlFile:getInt(loanKey .. "#rescueSourceLoanId") or 0,
                        rescuePreviousPayment = xmlFile:getFloat(loanKey .. "#rescuePreviousPayment") or 0,
                        rescuePreviousLenderId = xmlFile:getString(loanKey .. "#rescuePreviousLenderId") or "",
                        rescueMarketState = xmlFile:getString(loanKey .. "#rescueMarketState") or "",
                        rescueDealFit = xmlFile:getString(loanKey .. "#rescueDealFit") or "",
                        rescueRelationshipTier = xmlFile:getString(loanKey .. "#rescueRelationshipTier") or ""
                    }
                    table.insert(self.loans, loan)
                    self.nextLoanId = math.max(self.nextLoanId, id + 1)
                end
                loanIndex = loanIndex + 1
            end

            local assetIndex = 0
            while true do
                local assetKey = string.format("realisticFarmFinance.assetFinance(%d)", assetIndex)
                if not xmlFile:hasProperty(assetKey) then break end
                local id = xmlFile:getInt(assetKey .. "#id")
                local farmId = xmlFile:getInt(assetKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local agreement = {
                        id=id, farmId=farmId, product=xmlFile:getString(assetKey .. "#product") or "HIRE_PURCHASE",
                        vehicleUniqueId=xmlFile:getString(assetKey .. "#vehicleUniqueId") or "", vehicleName=xmlFile:getString(assetKey .. "#vehicleName") or "Financed asset",
                        storeItemXml=xmlFile:getString(assetKey .. "#storeItemXml") or "", basePrice=xmlFile:getFloat(assetKey .. "#basePrice") or 0,
                        depositPercent=xmlFile:getFloat(assetKey .. "#depositPercent") or 0, depositPaid=xmlFile:getFloat(assetKey .. "#depositPaid") or 0,
                        refundableDeposit=xmlFile:getFloat(assetKey .. "#refundableDeposit") or 0, originalFinanced=xmlFile:getFloat(assetKey .. "#originalFinanced") or 0,
                        principal=xmlFile:getFloat(assetKey .. "#principal") or 0, balloonAmount=xmlFile:getFloat(assetKey .. "#balloonAmount") or 0,
                        residualValue=xmlFile:getFloat(assetKey .. "#residualValue") or 0, interestRate=xmlFile:getFloat(assetKey .. "#interestRate") or 0,
                        termMonths=xmlFile:getInt(assetKey .. "#termMonths") or 0, remainingMonths=xmlFile:getInt(assetKey .. "#remainingMonths") or 0,
                        monthlyPayment=xmlFile:getFloat(assetKey .. "#monthlyPayment") or 0, riskGrade=xmlFile:getString(assetKey .. "#riskGrade") or "C",
                        lenderId=xmlFile:getString(assetKey .. "#lenderId") or "", lenderNameKey=xmlFile:getString(assetKey .. "#lenderNameKey") or "",
                        lenderMarketState=xmlFile:getString(assetKey .. "#lenderMarketState") or "SELECTIVE",
                        lenderDealFit=xmlFile:getString(assetKey .. "#lenderDealFit") or "STANDARD",
                        lenderAssignmentLegacy=xmlFile:getBool(assetKey .. "#lenderAssignmentLegacy") or false,
                        relationshipDealRecorded=xmlFile:getBool(assetKey .. "#relationshipDealRecorded") or false,
                        relationshipCompletionRecorded=xmlFile:getBool(assetKey .. "#relationshipCompletionRecorded") or false,
                        relationshipRecoveryRecorded=xmlFile:getBool(assetKey .. "#relationshipRecoveryRecorded") or false,
                        createdPeriod=xmlFile:getInt(assetKey .. "#createdPeriod") or self:getCurrentPeriodIndex(), lastPaymentPeriod=xmlFile:getInt(assetKey .. "#lastPaymentPeriod") or self:getCurrentPeriodIndex(),
                        paymentsMade=xmlFile:getInt(assetKey .. "#paymentsMade") or 0, missedPayments=xmlFile:getInt(assetKey .. "#missedPayments") or 0,
                        arrearsPrincipal=xmlFile:getFloat(assetKey .. "#arrearsPrincipal") or 0, arrearsInterest=xmlFile:getFloat(assetKey .. "#arrearsInterest") or 0,
                        arrearsRent=xmlFile:getFloat(assetKey .. "#arrearsRent") or 0, arrearsFees=xmlFile:getFloat(assetKey .. "#arrearsFees") or 0,
                        arrearsBalance=xmlFile:getFloat(assetKey .. "#arrearsBalance") or 0,
                        arrearsAgeMonths=xmlFile:getInt(assetKey .. "#arrearsAgeMonths") or 0,
                        arrearsStage=xmlFile:getString(assetKey .. "#arrearsStage") or "CURRENT",
                        defaultInterestAccrued=xmlFile:getFloat(assetKey .. "#defaultInterestAccrued") or 0,
                        adminChargesAccrued=xmlFile:getFloat(assetKey .. "#adminChargesAccrued") or 0,
                        defaultEvents=xmlFile:getInt(assetKey .. "#defaultEvents") or 0,
                        currentDefault=xmlFile:getBool(assetKey .. "#currentDefault") or false,
                        defaultRecorded=xmlFile:getBool(assetKey .. "#defaultRecorded") or false,
                        recoveryEligible=xmlFile:getBool(assetKey .. "#recoveryEligible") or false,
                        lastDefaultManagementPeriod=xmlFile:getInt(assetKey .. "#lastDefaultManagementPeriod") or 0,
                        consecutiveMissedPayments=xmlFile:getInt(assetKey .. "#consecutiveMissedPayments") or 0,
                        maxConsecutiveMissedPayments=xmlFile:getInt(assetKey .. "#maxConsecutiveMissedPayments") or 0,
                        lastMissedPeriod=xmlFile:getInt(assetKey .. "#lastMissedPeriod") or 0,
                        lastSuccessfulPaymentPeriod=xmlFile:getInt(assetKey .. "#lastSuccessfulPaymentPeriod") or 0,
                        lastArrearsClearedPeriod=xmlFile:getInt(assetKey .. "#lastArrearsClearedPeriod") or 0,
                        arrearsSchemaVersion=xmlFile:getInt(assetKey .. "#arrearsSchemaVersion") or 0,
                        principalPaid=xmlFile:getFloat(assetKey .. "#principalPaid") or 0, interestPaid=xmlFile:getFloat(assetKey .. "#interestPaid") or 0,
                        leaseRentPaid=xmlFile:getFloat(assetKey .. "#leaseRentPaid") or 0, completedPeriod=xmlFile:getInt(assetKey .. "#completedPeriod") or 0,
                        status=xmlFile:getString(assetKey .. "#status") or "ACTIVE", titleRetained=xmlFile:getBool(assetKey .. "#titleRetained") or false,
                        returnDue=xmlFile:getBool(assetKey .. "#returnDue") or false, returned=xmlFile:getBool(assetKey .. "#returned") or false,
                        leaseWarningTwoMonths=xmlFile:getBool(assetKey .. "#leaseWarningTwoMonths") or false,
                        leaseWarningOneMonth=xmlFile:getBool(assetKey .. "#leaseWarningOneMonth") or false,
                        returnedPeriod=xmlFile:getInt(assetKey .. "#returnedPeriod") or 0,
                        returnRepairCost=xmlFile:getFloat(assetKey .. "#returnRepairCost") or 0,
                        returnMaintenancePenalty=xmlFile:getFloat(assetKey .. "#returnMaintenancePenalty") or 0,
                        returnWashingCost=xmlFile:getFloat(assetKey .. "#returnWashingCost") or 0,
                        returnEarlyTerminationCharge=xmlFile:getFloat(assetKey .. "#returnEarlyTerminationCharge") or 0,
                        returnEarlyTerminated=xmlFile:getBool(assetKey .. "#returnEarlyTerminated") or false,
                        returnRemainingMonths=xmlFile:getInt(assetKey .. "#returnRemainingMonths") or 0,
                        returnFutureRent=xmlFile:getFloat(assetKey .. "#returnFutureRent") or 0,
                        returnArrearsApplied=xmlFile:getFloat(assetKey .. "#returnArrearsApplied") or 0,
                        returnDeductions=xmlFile:getFloat(assetKey .. "#returnDeductions") or 0,
                        returnDepositRefund=xmlFile:getFloat(assetKey .. "#returnDepositRefund") or 0,
                        returnAdditionalCharge=xmlFile:getFloat(assetKey .. "#returnAdditionalCharge") or 0,
                        returnDamage=xmlFile:getFloat(assetKey .. "#returnDamage") or 0,
                        returnDirt=xmlFile:getFloat(assetKey .. "#returnDirt") or 0,
                        returnAdsApplied=xmlFile:getBool(assetKey .. "#returnAdsApplied") or false,
                        returnAdsCondition=xmlFile:getFloat(assetKey .. "#returnAdsCondition") or 0,
                        returnAdsServiceLevel=xmlFile:getFloat(assetKey .. "#returnAdsServiceLevel") or 0,
                        returnAdsBreakdownCount=xmlFile:getInt(assetKey .. "#returnAdsBreakdownCount") or 0,
                        recoveryEligiblePeriod=xmlFile:getInt(assetKey .. "#recoveryEligiblePeriod") or 0,
                        recoveryPending=xmlFile:getBool(assetKey .. "#recoveryPending") or false,
                        lastRecoveryBlockedPeriod=xmlFile:getInt(assetKey .. "#lastRecoveryBlockedPeriod") or 0,
                        recovered=xmlFile:getBool(assetKey .. "#recovered") or false,
                        recoveredPeriod=xmlFile:getInt(assetKey .. "#recoveredPeriod") or 0,
                        recoveryMethod=xmlFile:getString(assetKey .. "#recoveryMethod") or "",
                        recoveryMarketValue=xmlFile:getFloat(assetKey .. "#recoveryMarketValue") or 0,
                        recoveryAdjustedMarketValue=xmlFile:getFloat(assetKey .. "#recoveryAdjustedMarketValue") or 0,
                        recoveryTechnicalAdjustment=xmlFile:getFloat(assetKey .. "#recoveryTechnicalAdjustment") or 0,
                        recoveryRealisedValue=xmlFile:getFloat(assetKey .. "#recoveryRealisedValue") or 0,
                        recoveryCosts=xmlFile:getFloat(assetKey .. "#recoveryCosts") or 0,
                        recoveryDebtAtRecovery=xmlFile:getFloat(assetKey .. "#recoveryDebtAtRecovery") or 0,
                        recoveryDepositApplied=xmlFile:getFloat(assetKey .. "#recoveryDepositApplied") or 0,
                        recoveryShortfall=xmlFile:getFloat(assetKey .. "#recoveryShortfall") or 0,
                        recoverySurplus=xmlFile:getFloat(assetKey .. "#recoverySurplus") or 0,
                        recoveryLiabilityLoanId=xmlFile:getInt(assetKey .. "#recoveryLiabilityLoanId") or 0,
                        recoveryAdsApplied=xmlFile:getBool(assetKey .. "#recoveryAdsApplied") or false,
                        recoveryAdsCondition=xmlFile:getFloat(assetKey .. "#recoveryAdsCondition") or 0,
                        recoveryAdsServiceLevel=xmlFile:getFloat(assetKey .. "#recoveryAdsServiceLevel") or 0,
                        recoveryAdsBreakdownCount=xmlFile:getInt(assetKey .. "#recoveryAdsBreakdownCount") or 0,
                        recoveryAdsRepairCost=xmlFile:getFloat(assetKey .. "#recoveryAdsRepairCost") or 0,
                        recoveryAdsMaintenancePenalty=xmlFile:getFloat(assetKey .. "#recoveryAdsMaintenancePenalty") or 0
                    }
                    table.insert(self.assetFinance, agreement)
                    self.nextAssetFinanceId = math.max(self.nextAssetFinanceId, id + 1)
                end
                assetIndex = assetIndex + 1
            end

            local tenancyIndex = 0
            while true do
                local tenancyKey = string.format("realisticFarmFinance.tenancy(%d)", tenancyIndex)
                if not xmlFile:hasProperty(tenancyKey) then
                    break
                end
                local id = xmlFile:getInt(tenancyKey .. "#id")
                local farmId = xmlFile:getInt(tenancyKey .. "#farmId")
                local farmlandId = xmlFile:getInt(tenancyKey .. "#farmlandId")
                if id ~= nil and farmId ~= nil and farmId > 0 and farmlandId ~= nil then
                    local farmlandIds = {}
                    for value in string.gmatch(xmlFile:getString(tenancyKey .. "#farmlandIds") or tostring(farmlandId), "[^,]+") do
                        local parsed = tonumber(value)
                        if parsed ~= nil and parsed > 0 then table.insert(farmlandIds, math.floor(parsed)) end
                    end
                    local tenancy = {
                        id = id, farmId = farmId, farmlandId = farmlandId, farmlandIds = farmlandIds,
                        agreementId = xmlFile:getString(tenancyKey .. "#agreementId") or string.format("RFF-T-%06d", id),
                        landlord = xmlFile:getString(tenancyKey .. "#landlord") or "PRIVATE_LANDOWNER",
                        holdingName = xmlFile:getString(tenancyKey .. "#holdingName") or string.format("Land %d", farmlandId),
                        purchasePrice = xmlFile:getFloat(tenancyKey .. "#purchasePrice") or 0,
                        securityDeposit = xmlFile:getFloat(tenancyKey .. "#securityDeposit") or 0,
                        depositOriginal = xmlFile:getFloat(tenancyKey .. "#depositOriginal") or xmlFile:getFloat(tenancyKey .. "#securityDeposit") or 0,
                        depositHeld = xmlFile:getFloat(tenancyKey .. "#depositHeld") or xmlFile:getFloat(tenancyKey .. "#securityDeposit") or 0,
                        monthlyRent = xmlFile:getFloat(tenancyKey .. "#monthlyRent") or 0,
                        annualRent = xmlFile:getFloat(tenancyKey .. "#annualRent") or (xmlFile:getFloat(tenancyKey .. "#monthlyRent") or 0) * 12,
                        paymentFrequency = xmlFile:getString(tenancyKey .. "#paymentFrequency") or "MONTHLY",
                        paymentIntervalMonths = xmlFile:getInt(tenancyKey .. "#paymentIntervalMonths") or 1,
                        termMonths = xmlFile:getInt(tenancyKey .. "#termMonths") or 0,
                        remainingMonths = xmlFile:getInt(tenancyKey .. "#remainingMonths") or 0,
                        createdPeriod = xmlFile:getInt(tenancyKey .. "#createdPeriod") or self:getCurrentPeriodIndex(),
                        commencementPeriod = xmlFile:getInt(tenancyKey .. "#commencementPeriod") or xmlFile:getInt(tenancyKey .. "#createdPeriod") or self:getCurrentPeriodIndex(),
                        contractualEndPeriod = xmlFile:getInt(tenancyKey .. "#contractualEndPeriod") or ((xmlFile:getInt(tenancyKey .. "#createdPeriod") or self:getCurrentPeriodIndex()) + (xmlFile:getInt(tenancyKey .. "#termMonths") or 0)),
                        nextRentDuePeriod = xmlFile:getInt(tenancyKey .. "#nextRentDuePeriod") or ((xmlFile:getInt(tenancyKey .. "#lastPaymentPeriod") or self:getCurrentPeriodIndex()) + 1),
                        lastPaymentPeriod = xmlFile:getInt(tenancyKey .. "#lastPaymentPeriod") or self:getCurrentPeriodIndex(),
                        paymentsMade = xmlFile:getInt(tenancyKey .. "#paymentsMade") or 0,
                        missedPayments = xmlFile:getInt(tenancyKey .. "#missedPayments") or 0,
                        rentCharged = xmlFile:getFloat(tenancyKey .. "#rentCharged") or 0,
                        rentPaid = xmlFile:getFloat(tenancyKey .. "#rentPaid") or 0,
                        rentDue = xmlFile:getFloat(tenancyKey .. "#rentDue") or 0,
                        arrears = xmlFile:getFloat(tenancyKey .. "#arrears") or 0,
                        status = xmlFile:getString(tenancyKey .. "#status") or "ACTIVE",
                        applicationReference = xmlFile:getString(tenancyKey .. "#applicationReference") or "",
                        applicationStage = xmlFile:getString(tenancyKey .. "#applicationStage") or "",
                        applicationSubmittedDay = xmlFile:getInt(tenancyKey .. "#applicationSubmittedDay") or 0,
                        applicationNextActionDay = xmlFile:getInt(tenancyKey .. "#applicationNextActionDay") or 0,
                        applicationRequestedTermMonths = xmlFile:getInt(tenancyKey .. "#applicationRequestedTermMonths") or 0,
                        applicationCreditScore = xmlFile:getInt(tenancyKey .. "#applicationCreditScore") or 0,
                        applicationCreditBand = xmlFile:getString(tenancyKey .. "#applicationCreditBand") or "",
                        applicationCreditConduct = xmlFile:getString(tenancyKey .. "#applicationCreditConduct") or "",
                        applicationCreditAffordability = xmlFile:getString(tenancyKey .. "#applicationCreditAffordability") or "",
                        applicationMonthlyIncome = xmlFile:getFloat(tenancyKey .. "#applicationMonthlyIncome") or 0,
                        applicationExistingCommitments = xmlFile:getFloat(tenancyKey .. "#applicationExistingCommitments") or 0,
                        applicationDepositMonths = xmlFile:getInt(tenancyKey .. "#applicationDepositMonths") or 0,
                        applicationLegalFee = xmlFile:getFloat(tenancyKey .. "#applicationLegalFee") or 0,
                        applicationUpfrontCashRequired = xmlFile:getFloat(tenancyKey .. "#applicationUpfrontCashRequired") or 0,
                        applicationDecision = xmlFile:getString(tenancyKey .. "#applicationDecision") or "",
                        applicationDecisionReason = xmlFile:getString(tenancyKey .. "#applicationDecisionReason") or "",
                        applicationLandlordIntroduced = xmlFile:getBool(tenancyKey .. "#applicationLandlordIntroduced") or false,
                        depositForfeited = xmlFile:getBool(tenancyKey .. "#depositForfeited") or false,
                        rentReviewIntervalMonths = xmlFile:getInt(tenancyKey .. "#rentReviewIntervalMonths") or 0,
                        nextRentReviewPeriod = xmlFile:getInt(tenancyKey .. "#nextRentReviewPeriod") or 0,
                        breakEnabled = xmlFile:getBool(tenancyKey .. "#breakEnabled") or false,
                        earliestBreakPeriod = xmlFile:getInt(tenancyKey .. "#earliestBreakPeriod") or 0,
                        breakNoticeMonths = xmlFile:getInt(tenancyKey .. "#breakNoticeMonths") or 0,
                        permittedEnterprise = xmlFile:getString(tenancyKey .. "#permittedEnterprise") or "MIXED",
                        agriculturalUsePermitted = xmlFile:getBool(tenancyKey .. "#agriculturalUsePermitted") ~= false,
                        permanentGrassRestriction = xmlFile:getBool(tenancyKey .. "#permanentGrassRestriction") or false,
                        boundaryRemovalRequiresConsent = xmlFile:getBool(tenancyKey .. "#boundaryRemovalRequiresConsent") ~= false,
                        improvementsRequireConsent = xmlFile:getBool(tenancyKey .. "#improvementsRequireConsent") ~= false,
                        tenantMaintenanceObligation = xmlFile:getBool(tenancyKey .. "#tenantMaintenanceObligation") ~= false,
                        landlordVariationNoticeMonths = xmlFile:getInt(tenancyKey .. "#landlordVariationNoticeMonths") or 3,
                        landlordVariationCooldownMonths = xmlFile:getInt(tenancyKey .. "#landlordVariationCooldownMonths") or 12,
                        settlementCompleted = xmlFile:getBool(tenancyKey .. "#settlementCompleted") or false,
                        settlementDepositApplied = xmlFile:getFloat(tenancyKey .. "#settlementDepositApplied") or 0,
                        settlementDepositReturned = xmlFile:getFloat(tenancyKey .. "#settlementDepositReturned") or 0,
                        settlementCovenantCosts = xmlFile:getFloat(tenancyKey .. "#settlementCovenantCosts") or 0,
                        settlementCovenantCostsApplied = xmlFile:getFloat(tenancyKey .. "#settlementCovenantCostsApplied") or 0,
                        settlementDilapidationCosts = xmlFile:getFloat(tenancyKey .. "#settlementDilapidationCosts") or 0,
                        settlementDilapidationCostsApplied = xmlFile:getFloat(tenancyKey .. "#settlementDilapidationCostsApplied") or 0,
                        settlementFinalBalance = xmlFile:getFloat(tenancyKey .. "#settlementFinalBalance") or 0,
                        forfeitureProcessed = xmlFile:getBool(tenancyKey .. "#forfeitureProcessed") or false,
                        forfeiturePeriod = xmlFile:getInt(tenancyKey .. "#forfeiturePeriod") or 0,
                        forfeitedPlaceableCount = xmlFile:getInt(tenancyKey .. "#forfeitedPlaceableCount") or 0,
                        forfeitedPlaceableValue = xmlFile:getFloat(tenancyKey .. "#forfeitedPlaceableValue") or 0,
                        expiryWarning12Sent = xmlFile:getBool(tenancyKey .. "#expiryWarning12Sent") or false,
                        expiryWarning3Sent = xmlFile:getBool(tenancyKey .. "#expiryWarning3Sent") or false,
                        expiryWarning1Sent = xmlFile:getBool(tenancyKey .. "#expiryWarning1Sent") or false,
                        expiryNotificationSent = xmlFile:getBool(tenancyKey .. "#expiryNotificationSent") or false,
                        lastArrearsNotificationPeriod = xmlFile:getInt(tenancyKey .. "#lastArrearsNotificationPeriod") or 0,
                        renewalOfferStatus = xmlFile:getString(tenancyKey .. "#renewalOfferStatus") or "NONE",
                        renewalOfferCreatedPeriod = xmlFile:getInt(tenancyKey .. "#renewalOfferCreatedPeriod") or 0,
                        renewalOfferExpiryPeriod = xmlFile:getInt(tenancyKey .. "#renewalOfferExpiryPeriod") or 0,
                        renewalOfferAnnualRent = xmlFile:getFloat(tenancyKey .. "#renewalOfferAnnualRent") or 0,
                        renewalOfferTermMonths = xmlFile:getInt(tenancyKey .. "#renewalOfferTermMonths") or 0,
                        renewalOfferPaymentFrequency = xmlFile:getString(tenancyKey .. "#renewalOfferPaymentFrequency") or "",
                        successorAgreementId = xmlFile:getInt(tenancyKey .. "#successorAgreementId") or 0,
                        predecessorAgreementId = xmlFile:getInt(tenancyKey .. "#predecessorAgreementId") or 0,
                        noticeServedPeriod = xmlFile:getInt(tenancyKey .. "#noticeServedPeriod") or 0,
                        noticeEffectivePeriod = xmlFile:getInt(tenancyKey .. "#noticeEffectivePeriod") or 0,
                        noticeReason = xmlFile:getString(tenancyKey .. "#noticeReason") or "",
                        breakExercisedPeriod = xmlFile:getInt(tenancyKey .. "#breakExercisedPeriod") or 0,
                        lastRentReviewPeriod = xmlFile:getInt(tenancyKey .. "#lastRentReviewPeriod") or 0,
                        previousAnnualRent = xmlFile:getFloat(tenancyKey .. "#previousAnnualRent") or 0,
                        settlementDepositTransferred = xmlFile:getFloat(tenancyKey .. "#settlementDepositTransferred") or 0,
                        commencementNotificationSent = xmlFile:getBool(tenancyKey .. "#commencementNotificationSent") or false,
                        renewalOriginalAnnualRent = xmlFile:getFloat(tenancyKey .. "#renewalOriginalAnnualRent") or 0,
                        renewalNegotiationStatus = xmlFile:getString(tenancyKey .. "#renewalNegotiationStatus") or "NOT_STARTED",
                        renewalNegotiationPeriod = xmlFile:getInt(tenancyKey .. "#renewalNegotiationPeriod") or 0,
                        renewalNegotiationAttempts = xmlFile:getInt(tenancyKey .. "#renewalNegotiationAttempts") or 0,
                        renewalNegotiatedAnnualRent = xmlFile:getFloat(tenancyKey .. "#renewalNegotiatedAnnualRent") or 0,
                        renewalNegotiationNextDay = xmlFile:getInt(tenancyKey .. "#renewalNegotiationNextDay") or 0,
                        renewalNegotiationLastUpdateDay = xmlFile:getInt(tenancyKey .. "#renewalNegotiationLastUpdateDay") or 0,
                        renewalTenantProposalRent = xmlFile:getFloat(tenancyKey .. "#renewalTenantProposalRent") or 0,
                        renewalLandlordCounterRent = xmlFile:getFloat(tenancyKey .. "#renewalLandlordCounterRent") or 0,
                        renewalLegalReference = xmlFile:getString(tenancyKey .. "#renewalLegalReference") or "",
                        renewalDocumentStatus = xmlFile:getString(tenancyKey .. "#renewalDocumentStatus") or "NONE",
                        renewalCovenantPackageVersion = xmlFile:getInt(tenancyKey .. "#renewalCovenantPackageVersion") or 0,
                        renewalOriginalPermittedEnterprise = xmlFile:getString(tenancyKey .. "#renewalOriginalPermittedEnterprise") or "",
                        renewalOriginalPermanentGrassRestriction = xmlFile:getBool(tenancyKey .. "#renewalOriginalPermanentGrassRestriction") or false,
                        renewalOriginalBoundaryRemovalRequiresConsent = xmlFile:getBool(tenancyKey .. "#renewalOriginalBoundaryRemovalRequiresConsent") or false,
                        renewalOriginalImprovementsRequireConsent = xmlFile:getBool(tenancyKey .. "#renewalOriginalImprovementsRequireConsent") or false,
                        renewalOriginalTenantMaintenanceObligation = xmlFile:getBool(tenancyKey .. "#renewalOriginalTenantMaintenanceObligation") or false,
                        renewalOriginalRentReviewIntervalMonths = xmlFile:getInt(tenancyKey .. "#renewalOriginalRentReviewIntervalMonths") or 0,
                        renewalOriginalBreakEnabled = xmlFile:getBool(tenancyKey .. "#renewalOriginalBreakEnabled") or false,
                        renewalOriginalBreakNoticeMonths = xmlFile:getInt(tenancyKey .. "#renewalOriginalBreakNoticeMonths") or 0,
                        renewalOriginalLandlordVariationNoticeMonths = xmlFile:getInt(tenancyKey .. "#renewalOriginalLandlordVariationNoticeMonths") or 0,
                        renewalOriginalLandlordVariationCooldownMonths = xmlFile:getInt(tenancyKey .. "#renewalOriginalLandlordVariationCooldownMonths") or 0,
                        renewalOfferPermittedEnterprise = xmlFile:getString(tenancyKey .. "#renewalOfferPermittedEnterprise") or "",
                        renewalOfferPermanentGrassRestriction = xmlFile:getBool(tenancyKey .. "#renewalOfferPermanentGrassRestriction") or false,
                        renewalOfferBoundaryRemovalRequiresConsent = xmlFile:getBool(tenancyKey .. "#renewalOfferBoundaryRemovalRequiresConsent") or false,
                        renewalOfferImprovementsRequireConsent = xmlFile:getBool(tenancyKey .. "#renewalOfferImprovementsRequireConsent") or false,
                        renewalOfferTenantMaintenanceObligation = xmlFile:getBool(tenancyKey .. "#renewalOfferTenantMaintenanceObligation") or false,
                        renewalOfferRentReviewIntervalMonths = xmlFile:getInt(tenancyKey .. "#renewalOfferRentReviewIntervalMonths") or 0,
                        renewalOfferBreakEnabled = xmlFile:getBool(tenancyKey .. "#renewalOfferBreakEnabled") or false,
                        renewalOfferBreakNoticeMonths = xmlFile:getInt(tenancyKey .. "#renewalOfferBreakNoticeMonths") or 0,
                        renewalOfferLandlordVariationNoticeMonths = xmlFile:getInt(tenancyKey .. "#renewalOfferLandlordVariationNoticeMonths") or 0,
                        renewalOfferLandlordVariationCooldownMonths = xmlFile:getInt(tenancyKey .. "#renewalOfferLandlordVariationCooldownMonths") or 0,
                        renewalTenantPermittedEnterprise = xmlFile:getString(tenancyKey .. "#renewalTenantPermittedEnterprise") or "",
                        renewalTenantPermanentGrassRestriction = xmlFile:getBool(tenancyKey .. "#renewalTenantPermanentGrassRestriction") or false,
                        renewalTenantBoundaryRemovalRequiresConsent = xmlFile:getBool(tenancyKey .. "#renewalTenantBoundaryRemovalRequiresConsent") or false,
                        renewalTenantImprovementsRequireConsent = xmlFile:getBool(tenancyKey .. "#renewalTenantImprovementsRequireConsent") or false,
                        renewalTenantTenantMaintenanceObligation = xmlFile:getBool(tenancyKey .. "#renewalTenantTenantMaintenanceObligation") or false,
                        renewalTenantRentReviewIntervalMonths = xmlFile:getInt(tenancyKey .. "#renewalTenantRentReviewIntervalMonths") or 0,
                        renewalTenantBreakEnabled = xmlFile:getBool(tenancyKey .. "#renewalTenantBreakEnabled") or false,
                        renewalTenantBreakNoticeMonths = xmlFile:getInt(tenancyKey .. "#renewalTenantBreakNoticeMonths") or 0,
                        renewalTenantLandlordVariationNoticeMonths = xmlFile:getInt(tenancyKey .. "#renewalTenantLandlordVariationNoticeMonths") or 0,
                        renewalTenantLandlordVariationCooldownMonths = xmlFile:getInt(tenancyKey .. "#renewalTenantLandlordVariationCooldownMonths") or 0,
                        landlordRelationshipPoints = xmlFile:getFloat(tenancyKey .. "#landlordRelationshipPoints") or 0,
                        landlordRelationshipInitialized = xmlFile:getBool(tenancyKey .. "#landlordRelationshipInitialized") or false,
                        landlordRelationshipLastReason = xmlFile:getString(tenancyKey .. "#landlordRelationshipLastReason") or "",
                        landlordNegotiationRejections = xmlFile:getInt(tenancyKey .. "#landlordNegotiationRejections") or 0,
                        consentNextId = xmlFile:getInt(tenancyKey .. "#consentNextId") or 1,
                        consentLatestId = xmlFile:getInt(tenancyKey .. "#consentLatestId") or 0,
                        covenantComplianceStatus = xmlFile:getString(tenancyKey .. "#covenantComplianceStatus") or "COMPLIANT",
                        landlordVariationCount = xmlFile:getInt(tenancyKey .. "#landlordVariationCount") or 0,
                        lastLandlordVariationPeriod = xmlFile:getInt(tenancyKey .. "#lastLandlordVariationPeriod") or 0,
                        nextLandlordVariationPeriod = xmlFile:getInt(tenancyKey .. "#nextLandlordVariationPeriod") or 0,
                        npcVoiceSchemaVersion = xmlFile:getInt(tenancyKey .. "#npcVoiceSchemaVersion") or 0,
                        npcVoiceSeed = xmlFile:getInt(tenancyKey .. "#npcVoiceSeed") or 0,
                        npcVoiceId = xmlFile:getString(tenancyKey .. "#npcVoiceId") or "",
                        npcCommunicationStyle = xmlFile:getString(tenancyKey .. "#npcCommunicationStyle") or "",
                        npcFormality = xmlFile:getFloat(tenancyKey .. "#npcFormality") or 0,
                        npcWarmth = xmlFile:getFloat(tenancyKey .. "#npcWarmth") or 0,
                        npcVerbosity = xmlFile:getFloat(tenancyKey .. "#npcVerbosity") or 0,
                        npcPatience = xmlFile:getFloat(tenancyKey .. "#npcPatience") or 0,
                        npcDirectness = xmlFile:getFloat(tenancyKey .. "#npcDirectness") or 0,
                        npcConservatism = xmlFile:getFloat(tenancyKey .. "#npcConservatism") or 0,
                        npcRelationshipWeight = xmlFile:getFloat(tenancyKey .. "#npcRelationshipWeight") or 0,
                        narrativeNextEventId = xmlFile:getInt(tenancyKey .. "#narrativeNextEventId") or 1,
                        narrativeLatestEventId = xmlFile:getInt(tenancyKey .. "#narrativeLatestEventId") or 0,
                        narrativeLatestEventType = xmlFile:getString(tenancyKey .. "#narrativeLatestEventType") or "",
                        narrativeLatestText = xmlFile:getString(tenancyKey .. "#narrativeLatestText") or "",
                        conditionSurveyVersion = xmlFile:getInt(tenancyKey .. "#conditionSurveyVersion") or 0,
                        conditionSurveyPeriod = xmlFile:getInt(tenancyKey .. "#conditionSurveyPeriod") or 0,
                        conditionLastObservedPeriod = xmlFile:getInt(tenancyKey .. "#conditionLastObservedPeriod") or 0,
                        alterationNextId = xmlFile:getInt(tenancyKey .. "#alterationNextId") or 1,
                        alterationLatestId = xmlFile:getInt(tenancyKey .. "#alterationLatestId") or 0,
                        inspectionSchemaVersion = xmlFile:getInt(tenancyKey .. "#inspectionSchemaVersion") or 0,
                        inspectionNextId = xmlFile:getInt(tenancyKey .. "#inspectionNextId") or 1,
                        inspectionLatestId = xmlFile:getInt(tenancyKey .. "#inspectionLatestId") or 0,
                        lastInspectionPeriod = xmlFile:getInt(tenancyKey .. "#lastInspectionPeriod") or 0,
                        nextInspectionPeriod = xmlFile:getInt(tenancyKey .. "#nextInspectionPeriod") or 0,
                        lastInspectionStatus = xmlFile:getString(tenancyKey .. "#lastInspectionStatus") or "NOT_INSPECTED",
                        lastInspectionReference = xmlFile:getString(tenancyKey .. "#lastInspectionReference") or "",
                        lastInspectionSummary = xmlFile:getString(tenancyKey .. "#lastInspectionSummary") or "",
                        breachCaseSchemaVersion = xmlFile:getInt(tenancyKey .. "#breachCaseSchemaVersion") or 0,
                        breachCaseNextId = xmlFile:getInt(tenancyKey .. "#breachCaseNextId") or 1,
                        breachCaseLatestId = xmlFile:getInt(tenancyKey .. "#breachCaseLatestId") or 0,
                        handbackSchemaVersion = xmlFile:getInt(tenancyKey .. "#handbackSchemaVersion") or 0,
                        handbackStatus = xmlFile:getString(tenancyKey .. "#handbackStatus") or "NONE",
                        handbackReference = xmlFile:getString(tenancyKey .. "#handbackReference") or "",
                        handbackInspectionPeriod = xmlFile:getInt(tenancyKey .. "#handbackInspectionPeriod") or 0,
                        handbackRemedyDeadlinePeriod = xmlFile:getInt(tenancyKey .. "#handbackRemedyDeadlinePeriod") or 0,
                        handbackFinalInspectionPeriod = xmlFile:getInt(tenancyKey .. "#handbackFinalInspectionPeriod") or 0,
                        handbackReviewCount = xmlFile:getInt(tenancyKey .. "#handbackReviewCount") or 0,
                        handbackItemCount = xmlFile:getInt(tenancyKey .. "#handbackItemCount") or 0,
                        handbackUnresolvedCount = xmlFile:getInt(tenancyKey .. "#handbackUnresolvedCount") or 0,
                        handbackEstimatedCost = xmlFile:getFloat(tenancyKey .. "#handbackEstimatedCost") or 0,
                        handbackProfessionalFee = xmlFile:getFloat(tenancyKey .. "#handbackProfessionalFee") or 0,
                        handbackFinalCost = xmlFile:getFloat(tenancyKey .. "#handbackFinalCost") or 0,
                        handbackLatestSummary = xmlFile:getString(tenancyKey .. "#handbackLatestSummary") or "",
                        narrativeEvents = {},
                        consentRequests = {},
                        parcelConditions = {},
                        alterations = {},
                        inspectionReports = {},
                        breachCases = {},
                        handbackItems = {}
                    }
                    local narrativeIndex = 0
                    local maxNarrativeId = 0
                    while true do
                        local eventKey = string.format("%s.narrativeEvent(%d)", tenancyKey, narrativeIndex)
                        if not xmlFile:hasProperty(eventKey) then break end
                        local event = {
                            id=xmlFile:getInt(eventKey .. "#id") or (narrativeIndex + 1),
                            token=xmlFile:getString(eventKey .. "#token") or "",
                            eventType=xmlFile:getString(eventKey .. "#eventType") or "CORRESPONDENCE",
                            label=xmlFile:getString(eventKey .. "#label") or "Correspondence",
                            text=xmlFile:getString(eventKey .. "#text") or "",
                            speaker=xmlFile:getString(eventKey .. "#speaker") or "The landlord",
                            day=xmlFile:getInt(eventKey .. "#day") or 0,
                            period=xmlFile:getInt(eventKey .. "#period") or 0,
                            round=xmlFile:getInt(eventKey .. "#round") or 0,
                            seed=xmlFile:getInt(eventKey .. "#seed") or 0,
                            voiceId=xmlFile:getString(eventKey .. "#voiceId") or "",
                            style=xmlFile:getString(eventKey .. "#style") or "BALANCED",
                            documentStatus=xmlFile:getString(eventKey .. "#documentStatus") or "",
                            reference=xmlFile:getString(eventKey .. "#reference") or "",
                            outcome=xmlFile:getString(eventKey .. "#outcome") or "",
                            tenantRent=xmlFile:getFloat(eventKey .. "#tenantRent") or 0,
                            landlordRent=xmlFile:getFloat(eventKey .. "#landlordRent") or 0,
                            termMonths=xmlFile:getInt(eventKey .. "#termMonths") or 0,
                            relationshipCode=xmlFile:getString(eventKey .. "#relationshipCode") or "PROFESSIONAL",
                            relationshipPoints=xmlFile:getFloat(eventKey .. "#relationshipPoints") or 0,
                            memoryCode=xmlFile:getString(eventKey .. "#memoryCode") or "NEW",
                            conditionCode=xmlFile:getString(eventKey .. "#conditionCode") or "",
                            packageSummary=xmlFile:getString(eventKey .. "#packageSummary") or "",
                            packageResponse=xmlFile:getString(eventKey .. "#packageResponse") or "",
                            tenantPackage=xmlFile:getString(eventKey .. "#tenantPackage") or "",
                            landlordPackage=xmlFile:getString(eventKey .. "#landlordPackage") or "",
                            consentType=xmlFile:getString(eventKey .. "#consentType") or "",
                            consentTarget=xmlFile:getString(eventKey .. "#consentTarget") or "",
                            consentConditions=xmlFile:getString(eventKey .. "#consentConditions") or "",
                            variationNoticeMonths=xmlFile:getInt(eventKey .. "#variationNoticeMonths") or 0,
                            variationEffectivePeriod=xmlFile:getInt(eventKey .. "#variationEffectivePeriod") or 0,
                            variationCooldownMonths=xmlFile:getInt(eventKey .. "#variationCooldownMonths") or 0,
                            variationCooldownUntilPeriod=xmlFile:getInt(eventKey .. "#variationCooldownUntilPeriod") or 0
                        }
                        table.insert(tenancy.narrativeEvents, event)
                        maxNarrativeId = math.max(maxNarrativeId, event.id or 0)
                        narrativeIndex = narrativeIndex + 1
                    end
                    tenancy.narrativeNextEventId = math.max(1, tenancy.narrativeNextEventId or 1, maxNarrativeId + 1)
                    if #tenancy.narrativeEvents > 0 then
                        local latestEvent = tenancy.narrativeEvents[#tenancy.narrativeEvents]
                        tenancy.narrativeLatestEventId = latestEvent.id or tenancy.narrativeLatestEventId
                        tenancy.narrativeLatestEventType = latestEvent.eventType or tenancy.narrativeLatestEventType
                        tenancy.narrativeLatestText = latestEvent.text or tenancy.narrativeLatestText
                    end
                    local consentIndex = 0
                    local maxConsentId = 0
                    while true do
                        local consentKey = string.format("%s.consentRequest(%d)", tenancyKey, consentIndex)
                        if not xmlFile:hasProperty(consentKey) then break end
                        local request = {
                            id=xmlFile:getInt(consentKey .. "#id") or (consentIndex + 1),
                            requestType=xmlFile:getString(consentKey .. "#requestType") or "",
                            target=xmlFile:getString(consentKey .. "#target") or "AUTHORITY",
                            status=xmlFile:getString(consentKey .. "#status") or "RECEIVED",
                            submittedDay=xmlFile:getInt(consentKey .. "#submittedDay") or 0,
                            reviewDay=xmlFile:getInt(consentKey .. "#reviewDay") or 0,
                            decisionDay=xmlFile:getInt(consentKey .. "#decisionDay") or 0,
                            nextActionDay=xmlFile:getInt(consentKey .. "#nextActionDay") or 0,
                            reference=xmlFile:getString(consentKey .. "#reference") or "",
                            conditions=xmlFile:getString(consentKey .. "#conditions") or "",
                            decisionReason=xmlFile:getString(consentKey .. "#decisionReason") or "",
                            expiresPeriod=xmlFile:getInt(consentKey .. "#expiresPeriod") or 0,
                            relationshipPoints=xmlFile:getFloat(consentKey .. "#relationshipPoints") or 0,
                            profileId=xmlFile:getString(consentKey .. "#profileId") or "",
                            initiator=xmlFile:getString(consentKey .. "#initiator") or "TENANT",
                            feePayer=xmlFile:getString(consentKey .. "#feePayer") or "",
                            professionalFee=xmlFile:getFloat(consentKey .. "#professionalFee") or 0,
                            feePaid=xmlFile:getFloat(consentKey .. "#feePaid") or 0,
                            feeOutstanding=xmlFile:getFloat(consentKey .. "#feeOutstanding") or 0,
                            feeSettlementNotified=xmlFile:getBool(consentKey .. "#feeSettlementNotified") or false,
                            proposedTermKey=xmlFile:getString(consentKey .. "#proposedTermKey") or "",
                            proposedValue=xmlFile:getString(consentKey .. "#proposedValue") or "",
                            noticeServedPeriod=xmlFile:getInt(consentKey .. "#noticeServedPeriod") or 0,
                            effectivePeriod=xmlFile:getInt(consentKey .. "#effectivePeriod") or 0,
                            cooldownUntilPeriod=xmlFile:getInt(consentKey .. "#cooldownUntilPeriod") or 0
                        }
                        table.insert(tenancy.consentRequests, request)
                        maxConsentId = math.max(maxConsentId, request.id or 0)
                        consentIndex = consentIndex + 1
                    end
                    tenancy.consentNextId = math.max(1, tenancy.consentNextId or 1, maxConsentId + 1)
                    if #tenancy.consentRequests > 0 then
                        tenancy.consentLatestId = tenancy.consentRequests[#tenancy.consentRequests].id or tenancy.consentLatestId
                    end
                    local parcelIndex = 0
                    while true do
                        local parcelKey = string.format("%s.parcelCondition(%d)", tenancyKey, parcelIndex)
                        if not xmlFile:hasProperty(parcelKey) then break end
                        table.insert(tenancy.parcelConditions, {
                            farmlandId=xmlFile:getInt(parcelKey .. "#farmlandId") or 0,
                            initialUse=xmlFile:getString(parcelKey .. "#initialUse") or "UNCLASSIFIED",
                            initialFruitName=xmlFile:getString(parcelKey .. "#initialFruitName") or "",
                            initialGroundName=xmlFile:getString(parcelKey .. "#initialGroundName") or "",
                            currentUse=xmlFile:getString(parcelKey .. "#currentUse") or "UNCLASSIFIED",
                            currentFruitName=xmlFile:getString(parcelKey .. "#currentFruitName") or "",
                            currentGroundName=xmlFile:getString(parcelKey .. "#currentGroundName") or "",
                            surveyedPeriod=xmlFile:getInt(parcelKey .. "#surveyedPeriod") or 0,
                            lastObservedPeriod=xmlFile:getInt(parcelKey .. "#lastObservedPeriod") or 0,
                            initialFieldAreaSqm=xmlFile:getFloat(parcelKey .. "#initialFieldAreaSqm") or 0,
                            currentFieldAreaSqm=xmlFile:getFloat(parcelKey .. "#currentFieldAreaSqm") or 0,
                            officialFieldAreaSqm=xmlFile:getFloat(parcelKey .. "#officialFieldAreaSqm") or 0,
                            boundaryExpansionSqm=xmlFile:getFloat(parcelKey .. "#boundaryExpansionSqm") or 0,
                            boundaryExpansionThresholdSqm=xmlFile:getFloat(parcelKey .. "#boundaryExpansionThresholdSqm") or 0,
                            boundarySurveyAvailable=xmlFile:getBool(parcelKey .. "#boundarySurveyAvailable") or false,
                            boundaryBaselineSource=xmlFile:getString(parcelKey .. "#boundaryBaselineSource") or ""
                        })
                        parcelIndex = parcelIndex + 1
                    end
                    local alterationIndex = 0
                    local maxAlterationId = 0
                    while true do
                        local alterationKey = string.format("%s.alteration(%d)", tenancyKey, alterationIndex)
                        if not xmlFile:hasProperty(alterationKey) then break end
                        local alteration = {
                            id=xmlFile:getInt(alterationKey .. "#id") or (alterationIndex + 1),
                            alterationType=xmlFile:getString(alterationKey .. "#alterationType") or "ALTERATION",
                            farmlandId=xmlFile:getInt(alterationKey .. "#farmlandId") or 0,
                            period=xmlFile:getInt(alterationKey .. "#period") or 0,
                            day=xmlFile:getInt(alterationKey .. "#day") or 0,
                            ownerFarmId=xmlFile:getInt(alterationKey .. "#ownerFarmId") or 0,
                            assetOwnership=xmlFile:getString(alterationKey .. "#assetOwnership") or "UNKNOWN",
                            assetName=xmlFile:getString(alterationKey .. "#assetName") or "",
                            category=xmlFile:getString(alterationKey .. "#category") or "",
                            worldX=xmlFile:getFloat(alterationKey .. "#worldX") or 0,
                            worldZ=xmlFile:getFloat(alterationKey .. "#worldZ") or 0,
                            value=xmlFile:getFloat(alterationKey .. "#value") or 0,
                            quantity=xmlFile:getInt(alterationKey .. "#quantity") or 1,
                            status=xmlFile:getString(alterationKey .. "#status") or "OBSERVED",
                            consentReference=xmlFile:getString(alterationKey .. "#consentReference") or "",
                            details=xmlFile:getString(alterationKey .. "#details") or ""
                        }
                        table.insert(tenancy.alterations, alteration)
                        maxAlterationId = math.max(maxAlterationId, alteration.id or 0)
                        alterationIndex = alterationIndex + 1
                    end
                    tenancy.alterationNextId = math.max(1, tenancy.alterationNextId or 1, maxAlterationId + 1)
                    if #tenancy.alterations > 0 then
                        tenancy.alterationLatestId = tenancy.alterations[#tenancy.alterations].id or tenancy.alterationLatestId
                    end
                    local inspectionIndex = 0
                    local maxInspectionId = 0
                    while true do
                        local inspectionKey = string.format("%s.inspectionReport(%d)", tenancyKey, inspectionIndex)
                        if not xmlFile:hasProperty(inspectionKey) then break end
                        local report = {
                            id=xmlFile:getInt(inspectionKey .. "#id") or (inspectionIndex + 1),
                            reference=xmlFile:getString(inspectionKey .. "#reference") or "",
                            period=xmlFile:getInt(inspectionKey .. "#period") or 0,
                            day=xmlFile:getInt(inspectionKey .. "#day") or 0,
                            trigger=xmlFile:getString(inspectionKey .. "#trigger") or "ROUTINE",
                            status=xmlFile:getString(inspectionKey .. "#status") or "CLEAR",
                            summary=xmlFile:getString(inspectionKey .. "#summary") or "",
                            breachCount=xmlFile:getInt(inspectionKey .. "#breachCount") or 0,
                            authorisedCount=xmlFile:getInt(inspectionKey .. "#authorisedCount") or 0,
                            advisoryCount=xmlFile:getInt(inspectionKey .. "#advisoryCount") or 0,
                            relationshipChange=xmlFile:getFloat(inspectionKey .. "#relationshipChange") or 0
                        }
                        table.insert(tenancy.inspectionReports, report)
                        maxInspectionId = math.max(maxInspectionId, report.id or 0)
                        inspectionIndex = inspectionIndex + 1
                    end
                    tenancy.inspectionNextId = math.max(1, tenancy.inspectionNextId or 1, maxInspectionId + 1)
                    if #tenancy.inspectionReports > 0 then
                        local latestReport = tenancy.inspectionReports[#tenancy.inspectionReports]
                        tenancy.inspectionLatestId = latestReport.id or tenancy.inspectionLatestId
                        tenancy.lastInspectionPeriod = latestReport.period or tenancy.lastInspectionPeriod
                        tenancy.lastInspectionStatus = latestReport.status or tenancy.lastInspectionStatus
                        tenancy.lastInspectionReference = latestReport.reference or tenancy.lastInspectionReference
                        tenancy.lastInspectionSummary = latestReport.summary or tenancy.lastInspectionSummary
                    end
                    local breachCaseIndex = 0
                    local maxBreachCaseId = 0
                    while true do
                        local breachCaseKey = string.format("%s.breachCase(%d)", tenancyKey, breachCaseIndex)
                        if not xmlFile:hasProperty(breachCaseKey) then break end
                        local breachCase = {
                            id=xmlFile:getInt(breachCaseKey .. "#id") or (breachCaseIndex + 1),
                            reference=xmlFile:getString(breachCaseKey .. "#reference") or "",
                            status=xmlFile:getString(breachCaseKey .. "#status") or "REMEDY_NOTICE",
                            openedPeriod=xmlFile:getInt(breachCaseKey .. "#openedPeriod") or 0,
                            remedyDeadlinePeriod=xmlFile:getInt(breachCaseKey .. "#remedyDeadlinePeriod") or 0,
                            nextReviewPeriod=xmlFile:getInt(breachCaseKey .. "#nextReviewPeriod") or 0,
                            closedPeriod=xmlFile:getInt(breachCaseKey .. "#closedPeriod") or 0,
                            sourceInspectionReference=xmlFile:getString(breachCaseKey .. "#sourceInspectionReference") or "",
                            latestInspectionReference=xmlFile:getString(breachCaseKey .. "#latestInspectionReference") or "",
                            breachCount=xmlFile:getInt(breachCaseKey .. "#breachCount") or 0,
                            unresolvedCount=xmlFile:getInt(breachCaseKey .. "#unresolvedCount") or 0,
                            reviewCount=xmlFile:getInt(breachCaseKey .. "#reviewCount") or 0,
                            professionalFee=xmlFile:getFloat(breachCaseKey .. "#professionalFee") or 0,
                            feePaid=xmlFile:getFloat(breachCaseKey .. "#feePaid") or 0,
                            feeOutstanding=xmlFile:getFloat(breachCaseKey .. "#feeOutstanding") or 0,
                            feeSettlementNotified=xmlFile:getBool(breachCaseKey .. "#feeSettlementNotified") or false,
                            remedyMonths=xmlFile:getInt(breachCaseKey .. "#remedyMonths") or 0,
                            reviewMonths=xmlFile:getInt(breachCaseKey .. "#reviewMonths") or 0,
                            terminationNoticeMonths=xmlFile:getInt(breachCaseKey .. "#terminationNoticeMonths") or 0,
                            firstLegalFee=xmlFile:getFloat(breachCaseKey .. "#firstLegalFee") or 0,
                            terminationLegalFee=xmlFile:getFloat(breachCaseKey .. "#terminationLegalFee") or 0,
                            landlordApproach=xmlFile:getString(breachCaseKey .. "#landlordApproach") or "",
                            relationshipCodeAtOpen=xmlFile:getString(breachCaseKey .. "#relationshipCodeAtOpen") or "PROFESSIONAL",
                            relationshipPointsAtOpen=xmlFile:getFloat(breachCaseKey .. "#relationshipPointsAtOpen") or 0,
                            terminationEffectivePeriod=xmlFile:getInt(breachCaseKey .. "#terminationEffectivePeriod") or 0,
                            preNoticeContractualEndPeriod=xmlFile:getInt(breachCaseKey .. "#preNoticeContractualEndPeriod") or 0,
                            preNoticeServedPeriod=xmlFile:getInt(breachCaseKey .. "#preNoticeServedPeriod") or 0,
                            preNoticeEffectivePeriod=xmlFile:getInt(breachCaseKey .. "#preNoticeEffectivePeriod") or 0,
                            preNoticeReason=xmlFile:getString(breachCaseKey .. "#preNoticeReason") or "",
                            preNoticeStatus=xmlFile:getString(breachCaseKey .. "#preNoticeStatus") or "",
                            lastChargeAmount=xmlFile:getFloat(breachCaseKey .. "#lastChargeAmount") or 0,
                            lastChargePeriod=xmlFile:getInt(breachCaseKey .. "#lastChargePeriod") or 0,
                            summary=xmlFile:getString(breachCaseKey .. "#summary") or ""
                        }
                        table.insert(tenancy.breachCases, breachCase)
                        maxBreachCaseId = math.max(maxBreachCaseId, breachCase.id or 0)
                        breachCaseIndex = breachCaseIndex + 1
                    end
                    tenancy.breachCaseNextId = math.max(1, tenancy.breachCaseNextId or 1, maxBreachCaseId + 1)
                    if #tenancy.breachCases > 0 then
                        tenancy.breachCaseLatestId = tenancy.breachCases[#tenancy.breachCases].id or tenancy.breachCaseLatestId
                    end
                    local handbackItemIndex = 0
                    while true do
                        local itemKey = string.format("%s.handbackItem(%d)", tenancyKey, handbackItemIndex)
                        if not xmlFile:hasProperty(itemKey) then break end
                        table.insert(tenancy.handbackItems, {
                            id=xmlFile:getInt(itemKey .. "#id") or (handbackItemIndex + 1),
                            code=xmlFile:getString(itemKey .. "#code") or "HAND_BACK_ITEM",
                            status=xmlFile:getString(itemKey .. "#status") or "OUTSTANDING",
                            farmlandId=xmlFile:getInt(itemKey .. "#farmlandId") or 0,
                            description=xmlFile:getString(itemKey .. "#description") or "",
                            remedy=xmlFile:getString(itemKey .. "#remedy") or "",
                            estimatedCost=xmlFile:getFloat(itemKey .. "#estimatedCost") or 0,
                            consentReference=xmlFile:getString(itemKey .. "#consentReference") or "",
                            alterationId=xmlFile:getInt(itemKey .. "#alterationId") or 0,
                            assetName=xmlFile:getString(itemKey .. "#assetName") or ""
                        })
                        handbackItemIndex = handbackItemIndex + 1
                    end
                    table.insert(self.tenancies, tenancy)
                    self.nextTenancyId = math.max(self.nextTenancyId, id + 1)
                end
                tenancyIndex = tenancyIndex + 1
            end


            local vehicleInsurancePolicyIndex = 0
            while true do
                local policyKey = string.format("realisticFarmFinance.vehicleInsurancePolicy(%d)", vehicleInsurancePolicyIndex)
                if not xmlFile:hasProperty(policyKey) then break end
                local id = xmlFile:getInt(policyKey .. "#id")
                local farmId = xmlFile:getInt(policyKey .. "#farmId")
                local vehicleUniqueId = xmlFile:getString(policyKey .. "#vehicleUniqueId") or ""
                if id ~= nil and farmId ~= nil and farmId > 0 and vehicleUniqueId ~= "" then
                    local policy = {
                        id = id,
                        farmId = farmId,
                        vehicleUniqueId = vehicleUniqueId,
                        vehicleName = xmlFile:getString(policyKey .. "#vehicleName") or "Vehicle",
                        coverType = xmlFile:getString(policyKey .. "#coverType") or "COMPREHENSIVE",
                        status = xmlFile:getString(policyKey .. "#status") or "ACTIVE",
                        source = xmlFile:getString(policyKey .. "#source") or "MIGRATED_FARM_POLICY",
                        startPeriod = xmlFile:getInt(policyKey .. "#startPeriod") or 0,
                        endPeriod = xmlFile:getInt(policyKey .. "#endPeriod") or 0,
                        lastRenewalPeriod = xmlFile:getInt(policyKey .. "#lastRenewalPeriod") or 0,
                        graceUntilPeriod = xmlFile:getInt(policyKey .. "#graceUntilPeriod") or 0,
                        premiumDue = xmlFile:getFloat(policyKey .. "#premiumDue") or 0,
                        lastPremium = xmlFile:getFloat(policyKey .. "#lastPremium") or 0,
                        pricingHistoryVersion = xmlFile:getInt(policyKey .. "#pricingHistoryVersion") or 0,
                        pricingCoverage = {},
                        pricingBasePremium = xmlFile:getFloat(policyKey .. "#pricingBasePremium") or 0,
                        pricingDiscountRate = xmlFile:getFloat(policyKey .. "#pricingDiscountRate") or 0,
                        pricingDiscountAmount = xmlFile:getFloat(policyKey .. "#pricingDiscountAmount") or 0,
                        pricingLoadingRate = xmlFile:getFloat(policyKey .. "#pricingLoadingRate") or 0,
                        pricingLoadingAmount = xmlFile:getFloat(policyKey .. "#pricingLoadingAmount") or 0,
                        pricingClaimCount = xmlFile:getInt(policyKey .. "#pricingClaimCount") or 0,
                        pricingClaimFreeMonths = xmlFile:getInt(policyKey .. "#pricingClaimFreeMonths") or 0,
                        pricingPointsEnabled = xmlFile:getBool(policyKey .. "#pricingPointsEnabled") == true,
                        pricingActivePoints = xmlFile:getInt(policyKey .. "#pricingActivePoints") or 0,
                        pricingPointsRate = xmlFile:getFloat(policyKey .. "#pricingPointsRate") or 0,
                        pricingPointsAmount = xmlFile:getFloat(policyKey .. "#pricingPointsAmount") or 0,
                        totalPaid = xmlFile:getFloat(policyKey .. "#totalPaid") or 0,
                        insuredValue = xmlFile:getFloat(policyKey .. "#insuredValue") or 0,
                        legalCover = xmlFile:getBool(policyKey .. "#legalCover") or false,
                        useScope = xmlFile:getString(policyKey .. "#useScope") or "AGRICULTURAL_ROAD",
                        maxGrossWeight = xmlFile:getFloat(policyKey .. "#maxGrossWeight") or 0,
                        temporaryCoverEndHour = xmlFile:getInt(policyKey .. "#temporaryCoverEndHour") or 0,
                        migrationSourceTier = xmlFile:getString(policyKey .. "#migrationSourceTier") or "",
                        expiryNotified = xmlFile:getBool(policyKey .. "#expiryNotified") or false,
                        autoRenew = xmlFile:getBool(policyKey .. "#autoRenew") == true,
                        autoRenewAttemptEndPeriod = xmlFile:getInt(policyKey .. "#autoRenewAttemptEndPeriod") or 0,
                        lessorInterested = xmlFile:getBool(policyKey .. "#lessorInterested") == true,
                        lessorNameKey = xmlFile:getString(policyKey .. "#lessorNameKey") or "",
                        assetAgreementId = xmlFile:getInt(policyKey .. "#assetAgreementId") or 0
                    }
                    local coverageIndex = 0
                    while true do
                        local coverageKey = string.format("%s.pricingCoverage(%d)", policyKey, coverageIndex)
                        if not xmlFile:hasProperty(coverageKey) then break end
                        local first = xmlFile:getInt(coverageKey .. "#startPeriod") or 0
                        local last = xmlFile:getInt(coverageKey .. "#endPeriod") or 0
                        if first >= 0 and last > first then
                            table.insert(policy.pricingCoverage, {startPeriod=first, endPeriod=last})
                        end
                        coverageIndex = coverageIndex + 1
                    end
                    table.insert(self.vehicleInsurancePolicies, policy)
                    self.nextVehicleInsurancePolicyId = math.max(self.nextVehicleInsurancePolicyId, id + 1)
                end
                vehicleInsurancePolicyIndex = vehicleInsurancePolicyIndex + 1
            end

            local trafficCourtesyIncidentIndex = 0
            while true do
                local incidentKey = string.format("realisticFarmFinance.trafficCourtesyIncident(%d)", trafficCourtesyIncidentIndex)
                if not xmlFile:hasProperty(incidentKey) then break end
                local id = xmlFile:getInt(incidentKey .. "#id")
                local farmId = xmlFile:getInt(incidentKey .. "#farmId")
                local externalIncidentId = xmlFile:getString(incidentKey .. "#externalIncidentId") or ""
                if id ~= nil and farmId ~= nil and farmId > 0 and externalIncidentId ~= "" then
                    local incident = {
                        id = id,
                        farmId = farmId,
                        source = xmlFile:getString(incidentKey .. "#source") or "TRAFFIC_COURTESY",
                        externalIncidentId = externalIncidentId,
                        groupedExternalIncidentIds = xmlFile:getString(incidentKey .. "#groupedExternalIncidentIds") or externalIncidentId,
                        groupedIncidentCount = xmlFile:getInt(incidentKey .. "#groupedIncidentCount") or 1,
                        status = xmlFile:getString(incidentKey .. "#status") or "RECORDED",
                        claimId = xmlFile:getInt(incidentKey .. "#claimId") or 0,
                        incidentDay = xmlFile:getInt(incidentKey .. "#incidentDay") or 0,
                        incidentPeriod = xmlFile:getInt(incidentKey .. "#incidentPeriod") or 0,
                        deadlinePeriod = xmlFile:getInt(incidentKey .. "#deadlinePeriod") or 0,
                        dayTimeMs = xmlFile:getInt(incidentKey .. "#dayTimeMs") or 0,
                        vehicleUniqueId = xmlFile:getString(incidentKey .. "#vehicleUniqueId") or "",
                        vehicleName = xmlFile:getString(incidentKey .. "#vehicleName") or "Vehicle",
                        partId = xmlFile:getString(incidentKey .. "#partId") or "",
                        partName = xmlFile:getString(incidentKey .. "#partName") or "Vehicle",
                        partFilename = xmlFile:getString(incidentKey .. "#partFilename") or "",
                        targetName = xmlFile:getString(incidentKey .. "#targetName") or "Unknown object",
                        targetType = xmlFile:getString(incidentKey .. "#targetType") or "UNKNOWN",
                        targetVehicleName = xmlFile:getString(incidentKey .. "#targetVehicleName") or "",
                        targetVehicleId = xmlFile:getString(incidentKey .. "#targetVehicleId") or "",
                        targetPartId = xmlFile:getString(incidentKey .. "#targetPartId") or "",
                        targetObjectFilename = xmlFile:getString(incidentKey .. "#targetObjectFilename") or "",
                        targetOwnershipQuality = xmlFile:getString(incidentKey .. "#targetOwnershipQuality") or "",
                        targetFarmId = xmlFile:getInt(incidentKey .. "#targetFarmId") or 0,
                        targetVehicleFarmId = xmlFile:getInt(incidentKey .. "#targetVehicleFarmId") or 0,
                        targetFarmlandId = xmlFile:getInt(incidentKey .. "#targetFarmlandId") or 0,
                        x = xmlFile:getFloat(incidentKey .. "#x") or 0,
                        y = xmlFile:getFloat(incidentKey .. "#y") or 0,
                        z = xmlFile:getFloat(incidentKey .. "#z") or 0,
                        locationType = xmlFile:getString(incidentKey .. "#locationType") or "UNKNOWN",
                        sourceSpeedMps = xmlFile:getFloat(incidentKey .. "#sourceSpeedMps") or 0,
                        targetSpeedMps = xmlFile:getFloat(incidentKey .. "#targetSpeedMps") or 0,
                        closingSpeedMps = xmlFile:getFloat(incidentKey .. "#closingSpeedMps") or 0,
                        combinationMassKg = xmlFile:getFloat(incidentKey .. "#combinationMassKg") or 0,
                        targetPartMassKg = xmlFile:getFloat(incidentKey .. "#targetPartMassKg") or 0,
                        severityClass = xmlFile:getString(incidentKey .. "#severityClass") or "UNKNOWN",
                        faultAssessment = xmlFile:getString(incidentKey .. "#faultAssessment") or "UNKNOWN",
                        sourceFaultAssessment = xmlFile:getString(incidentKey .. "#sourceFaultAssessment") or "UNKNOWN",
                        impactZone = xmlFile:getString(incidentKey .. "#impactZone") or "UNKNOWN",
                        targetImpactZone = xmlFile:getString(incidentKey .. "#targetImpactZone") or "UNKNOWN",
                        contactQuality = xmlFile:getString(incidentKey .. "#contactQuality") or "",
                        impactSpeedBasis = xmlFile:getString(incidentKey .. "#impactSpeedBasis") or "",
                        adsSourceDamage = xmlFile:getFloat(incidentKey .. "#adsSourceDamage") or 0,
                        adsTargetDamage = xmlFile:getFloat(incidentKey .. "#adsTargetDamage") or 0,
                        adsSourceSystems = xmlFile:getString(incidentKey .. "#adsSourceSystems") or "",
                        adsTargetSystems = xmlFile:getString(incidentKey .. "#adsTargetSystems") or "",
                        adsSourceBreakdowns = xmlFile:getString(incidentKey .. "#adsSourceBreakdowns") or "",
                        adsTargetBreakdowns = xmlFile:getString(incidentKey .. "#adsTargetBreakdowns") or "",
                        adsLogBaselineId = xmlFile:getInt(incidentKey .. "#adsLogBaselineId") or 0,
                        ownDamageEstimate = xmlFile:getFloat(incidentKey .. "#ownDamageEstimate") or 0,
                        thirdPartyEstimate = xmlFile:getFloat(incidentKey .. "#thirdPartyEstimate") or 0,
                        legalCostEstimate = xmlFile:getFloat(incidentKey .. "#legalCostEstimate") or 0,
                        estimatedClaimTotal = xmlFile:getFloat(incidentKey .. "#estimatedClaimTotal") or 0,
                        estimatedPayout = xmlFile:getFloat(incidentKey .. "#estimatedPayout") or 0,
                        thirdPartyTarget = xmlFile:getBool(incidentKey .. "#thirdPartyTarget") or false,
                        policyId = xmlFile:getInt(incidentKey .. "#policyId") or 0,
                        policyStatusAtIncident = xmlFile:getString(incidentKey .. "#policyStatusAtIncident") or "UNINSURED",
                        policyCoverType = xmlFile:getString(incidentKey .. "#policyCoverType") or "NONE",
                        policyLegalCover = xmlFile:getBool(incidentKey .. "#policyLegalCover") or false,
                        policyUseScope = xmlFile:getString(incidentKey .. "#policyUseScope") or "NONE",
                        policyMaxGrossWeight = xmlFile:getFloat(incidentKey .. "#policyMaxGrossWeight") or 0,
                        policyInsuredValue = xmlFile:getFloat(incidentKey .. "#policyInsuredValue") or 0,
                        licenceSnapshotVersion = xmlFile:getInt(incidentKey .. "#licenceSnapshotVersion") or 0,
                        licenceModeAtIncident = xmlFile:getString(incidentKey .. "#licenceModeAtIncident") or "",
                        licenceRequiredCategory = xmlFile:getString(incidentKey .. "#licenceRequiredCategory") or "",
                        licenceEntitlementHeld = xmlFile:getBool(incidentKey .. "#licenceEntitlementHeld") or false,
                        licenceSpecialistRevoked = xmlFile:getBool(incidentKey .. "#licenceSpecialistRevoked") or false,
                        licenceRulesApplied = xmlFile:getBool(incidentKey .. "#licenceRulesApplied") or false,
                        licenceAdrRequired = xmlFile:getBool(incidentKey .. "#licenceAdrRequired") or false,
                        licenceAdrHeld = xmlFile:getBool(incidentKey .. "#licenceAdrHeld") or false,
                        licenceHazardousLoadName = xmlFile:getString(incidentKey .. "#licenceHazardousLoadName") or "",
                        licenceHazardousLoadLevel = xmlFile:getFloat(incidentKey .. "#licenceHazardousLoadLevel") or 0,
                        licenceCategoryBreach = xmlFile:getBool(incidentKey .. "#licenceCategoryBreach") or false,
                        licenceAdrBreach = xmlFile:getBool(incidentKey .. "#licenceAdrBreach") or false,
                        licenceComplianceStatus = xmlFile:getString(incidentKey .. "#licenceComplianceStatus") or "NOT_ASSESSED"
                    }
                    table.insert(self.trafficCourtesyIncidents, incident)
                    self.nextTrafficCourtesyIncidentId = math.max(self.nextTrafficCourtesyIncidentId, id + 1)
                end
                trafficCourtesyIncidentIndex = trafficCourtesyIncidentIndex + 1
            end

            local driverOffenceIndex = 0
            local roadsideIndex = 0
            while true do
                local key = string.format("realisticFarmFinance.roadsideCheck(%d)",roadsideIndex)
                if not xmlFile:hasProperty(key) then break end
                local report = {}
                for _,name in ipairs({"id","farmId","incidentDay","incidentPeriod","dayTimeMs","fine","points","findingCount"}) do report[name]=xmlFile:getInt(key.."#"..name) or 0 end
                for _,name in ipairs({"requestedHour","expiresHour","completedHour"}) do report[name]=xmlFile:getFloat(key.."#"..name) or 0 end
                for _,name in ipairs({"status","vehicleUniqueId","vehicleName","findings","findingCodes","restrictionMessage"}) do report[name]=xmlFile:getString(key.."#"..name) or "" end
                report.popupShown=xmlFile:getBool(key.."#popupShown")==true
                if report.id>0 and report.farmId>0 and report.vehicleUniqueId~="" and report.fine>=0 and report.points>=0 then table.insert(self.roadsideChecks,report) end
                roadsideIndex=roadsideIndex+1
            end
            local noticeIndex = 0
            while true do
                local key = string.format("realisticFarmFinance.speedingNotice(%d)", noticeIndex)
                if not xmlFile:hasProperty(key) then break end
                local notice = {}
                for _,name in ipairs({"id","farmId","incidentPeriod","incidentDay","dayTimeMs","fine","points"}) do
                    notice[name] = xmlFile:getInt(key .. "#" .. name) or 0
                end
                for _,name in ipairs({"detectedHour","dueHour","deliveredHour","speedKph","limitKph"}) do
                    notice[name] = xmlFile:getFloat(key .. "#" .. name) or 0
                end
                for _,name in ipairs({"status","vehicleUniqueId","vehicleName","limitReason","severityClass","restrictionMessage"}) do
                    notice[name] = xmlFile:getString(key .. "#" .. name) or ""
                end
                if notice.id > 0 and notice.farmId > 0 and notice.limitKph > 0 and notice.dueHour >= notice.detectedHour
                    and notice.fine >= 0 and notice.points >= 0 then table.insert(self.speedingNotices,notice) end
                noticeIndex = noticeIndex + 1
            end
            while true do
                local offenceKey = string.format("realisticFarmFinance.driverOffence(%d)", driverOffenceIndex)
                if not xmlFile:hasProperty(offenceKey) then break end
                local id = xmlFile:getInt(offenceKey .. "#id")
                local farmId = xmlFile:getInt(offenceKey .. "#farmId")
                local externalIncidentId = xmlFile:getString(offenceKey .. "#externalIncidentId") or ""
                if id ~= nil and farmId ~= nil and farmId > 0 and externalIncidentId ~= "" then
                    local offence = {
                        id=id,
                        farmId=farmId,
                        source=xmlFile:getString(offenceKey .. "#source") or "TRAFFIC_COURTESY",
                        externalIncidentId=externalIncidentId,
                        status=xmlFile:getString(offenceKey .. "#status") or "ACTIVE",
                        offenceCode=xmlFile:getString(offenceKey .. "#offenceCode") or "REPORTABLE_COLLISION",
                        locationType=xmlFile:getString(offenceKey .. "#locationType") or "ROAD",
                        incidentDay=xmlFile:getInt(offenceKey .. "#incidentDay") or 0,
                        incidentPeriod=xmlFile:getInt(offenceKey .. "#incidentPeriod") or 0,
                        pointsIssuedAt=xmlFile:getFloat(offenceKey .. "#pointsIssuedAt"),
                        pointsExpireAt=xmlFile:getFloat(offenceKey .. "#pointsExpireAt"),
                        pointsClosedAt=xmlFile:getFloat(offenceKey .. "#pointsClosedAt"),
                        dayTimeMs=xmlFile:getInt(offenceKey .. "#dayTimeMs") or 0,
                        vehicleUniqueId=xmlFile:getString(offenceKey .. "#vehicleUniqueId") or "",
                        vehicleName=xmlFile:getString(offenceKey .. "#vehicleName") or "Vehicle",
                        targetName=xmlFile:getString(offenceKey .. "#targetName") or "Unknown object",
                        severityClass=xmlFile:getString(offenceKey .. "#severityClass") or "MINOR",
                        points=xmlFile:getInt(offenceKey .. "#points") or 0,
                        sourceSpeedKph=xmlFile:getFloat(offenceKey .. "#sourceSpeedKph") or 0,
                        closingSpeedKph=xmlFile:getFloat(offenceKey .. "#closingSpeedKph") or 0,
                        pointsTotalAfter=xmlFile:getInt(offenceKey .. "#pointsTotalAfter") or 0
                    }
                    table.insert(self.driverOffences, offence)
                    self.nextDriverOffenceId = math.max(self.nextDriverOffenceId, id + 1)
                end
                driverOffenceIndex = driverOffenceIndex + 1
            end

            local insuranceClaimIndex = 0
            while true do
                local claimKey = string.format("realisticFarmFinance.insuranceClaim(%d)", insuranceClaimIndex)
                if not xmlFile:hasProperty(claimKey) then break end
                local id = xmlFile:getInt(claimKey .. "#id")
                local farmId = xmlFile:getInt(claimKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local claim = {
                        id = id,
                        farmId = farmId,
                        insurerId = xmlFile:getString(claimKey .. "#insurerId") or "AGRICULTURAL_MUTUAL",
                        source = xmlFile:getString(claimKey .. "#source") or "RLRM",
                        claimType = xmlFile:getString(claimKey .. "#claimType") or "MORTALITY",
                        status = xmlFile:getString(claimKey .. "#status") or "UNDER_REVIEW",
                        lossId = xmlFile:getInt(claimKey .. "#lossId") or 0,
                        incidentDay = xmlFile:getInt(claimKey .. "#incidentDay") or 0,
                        incidentPeriod = xmlFile:getInt(claimKey .. "#incidentPeriod") or 0,
                        submittedDay = xmlFile:getInt(claimKey .. "#submittedDay") or 0,
                        decisionDay = xmlFile:getInt(claimKey .. "#decisionDay") or 0,
                        approvedDay = xmlFile:getInt(claimKey .. "#approvedDay") or 0,
                        settlementDay = xmlFile:getInt(claimKey .. "#settlementDay") or 0,
                        paidDay = xmlFile:getInt(claimKey .. "#paidDay") or 0,
                        policyTier = xmlFile:getString(claimKey .. "#policyTier") or "STANDARD",
                        policyStatusAtIncident = xmlFile:getString(claimKey .. "#policyStatusAtIncident") or "ACTIVE",
                        animalUniqueId = xmlFile:getString(claimKey .. "#animalUniqueId") or "",
                        animalName = xmlFile:getString(claimKey .. "#animalName") or "",
                        animalBreed = xmlFile:getString(claimKey .. "#animalBreed") or "",
                        animalSubType = xmlFile:getString(claimKey .. "#animalSubType") or "",
                        animalType = xmlFile:getString(claimKey .. "#animalType") or "UNKNOWN",
                        animalAge = xmlFile:getInt(claimKey .. "#animalAge") or 0,
                        animalHealth = xmlFile:getFloat(claimKey .. "#animalHealth") or 0,
                        deathReason = xmlFile:getString(claimKey .. "#deathReason") or "UNKNOWN",
                        incidentValue = xmlFile:getFloat(claimKey .. "#incidentValue") or 0,
                        indemnityFactor = xmlFile:getFloat(claimKey .. "#indemnityFactor") or 0,
                        excess = xmlFile:getFloat(claimKey .. "#excess") or 0,
                        amountClaimed = xmlFile:getFloat(claimKey .. "#amountClaimed") or (xmlFile:getFloat(claimKey .. "#incidentValue") or 0),
                        formSignedBy = xmlFile:getString(claimKey .. "#formSignedBy") or "",
                        formVersion = xmlFile:getInt(claimKey .. "#formVersion") or 0,
                        approvedAmount = xmlFile:getFloat(claimKey .. "#approvedAmount") or 0,
                        paidAmount = xmlFile:getFloat(claimKey .. "#paidAmount") or 0,
                        outcomeReason = xmlFile:getString(claimKey .. "#outcomeReason") or "",
                        treatmentDetails = xmlFile:getString(claimKey .. "#treatmentDetails") or "",
                        veterinaryExpenseIds = xmlFile:getString(claimKey .. "#veterinaryExpenseIds") or "",
                        policyId = xmlFile:getInt(claimKey .. "#policyId") or 0,
                        policyCoverType = xmlFile:getString(claimKey .. "#policyCoverType") or "",
                        policyLegalCover = xmlFile:getBool(claimKey .. "#policyLegalCover") or false,
                        policyUseScope = xmlFile:getString(claimKey .. "#policyUseScope") or "",
                        policyMaxGrossWeight = xmlFile:getFloat(claimKey .. "#policyMaxGrossWeight") or 0,
                        vehicleUniqueId = xmlFile:getString(claimKey .. "#vehicleUniqueId") or "",
                        vehicleName = xmlFile:getString(claimKey .. "#vehicleName") or "",
                        incidentLocationType = xmlFile:getString(claimKey .. "#incidentLocationType") or "UNKNOWN",
                        incidentGrossWeight = xmlFile:getFloat(claimKey .. "#incidentGrossWeight") or 0,
                        incidentX = xmlFile:getFloat(claimKey .. "#incidentX") or 0,
                        incidentY = xmlFile:getFloat(claimKey .. "#incidentY") or 0,
                        incidentZ = xmlFile:getFloat(claimKey .. "#incidentZ") or 0,
                        externalIncidentId = xmlFile:getString(claimKey .. "#externalIncidentId") or "",
                        groupedExternalIncidentIds = xmlFile:getString(claimKey .. "#groupedExternalIncidentIds") or (xmlFile:getString(claimKey .. "#externalIncidentId") or ""),
                        groupedIncidentCount = xmlFile:getInt(claimKey .. "#groupedIncidentCount") or 1,
                        incidentDescription = xmlFile:getString(claimKey .. "#incidentDescription") or "",
                        trafficIncidentId = xmlFile:getInt(claimKey .. "#trafficIncidentId") or 0,
                        incidentPartName = xmlFile:getString(claimKey .. "#incidentPartName") or "",
                        incidentTargetName = xmlFile:getString(claimKey .. "#incidentTargetName") or "",
                        incidentTargetType = xmlFile:getString(claimKey .. "#incidentTargetType") or "",
                        incidentSeverity = xmlFile:getString(claimKey .. "#incidentSeverity") or "",
                        incidentImpactZone = xmlFile:getString(claimKey .. "#incidentImpactZone") or "",
                        incidentTargetImpactZone = xmlFile:getString(claimKey .. "#incidentTargetImpactZone") or "",
                        incidentClosingSpeedMps = xmlFile:getFloat(claimKey .. "#incidentClosingSpeedMps") or 0,
                        incidentFaultAssessment = xmlFile:getString(claimKey .. "#incidentFaultAssessment") or "UNKNOWN",
                        incidentAdsSourceDamage = xmlFile:getFloat(claimKey .. "#incidentAdsSourceDamage") or 0,
                        incidentAdsSourceSystems = xmlFile:getString(claimKey .. "#incidentAdsSourceSystems") or "",
                        incidentAdsSourceBreakdowns = xmlFile:getString(claimKey .. "#incidentAdsSourceBreakdowns") or "",
                        trafficWorkflowVersion = xmlFile:getInt(claimKey .. "#trafficWorkflowVersion") or 0,
                        thirdPartyReported = xmlFile:getBool(claimKey .. "#thirdPartyReported") or false,
                        responseDeadlineDay = xmlFile:getInt(claimKey .. "#responseDeadlineDay") or 0,
                        responseWarningSent = xmlFile:getBool(claimKey .. "#responseWarningSent") or false,
                        defaultAfterDay = xmlFile:getInt(claimKey .. "#defaultAfterDay") or 0,
                        responseDay = xmlFile:getInt(claimKey .. "#responseDay") or 0,
                        reviewStatus = xmlFile:getString(claimKey .. "#reviewStatus"),
                        reviewResult = xmlFile:getString(claimKey .. "#reviewResult"),
                        reviewRequestedDay = xmlFile:getInt(claimKey .. "#reviewRequestedDay") or 0,
                        reviewDueDay = xmlFile:getInt(claimKey .. "#reviewDueDay") or 0,
                        reviewCompletedDay = xmlFile:getInt(claimKey .. "#reviewCompletedDay") or 0,
                        reviewCredit = xmlFile:getFloat(claimKey .. "#reviewCredit") or 0,
                        reviewOriginalOwnPaid = xmlFile:getFloat(claimKey .. "#reviewOriginalOwnPaid") or 0,
                        reviewOriginalFarmCharge = xmlFile:getFloat(claimKey .. "#reviewOriginalFarmCharge") or 0,
                        liabilityStatus = xmlFile:getString(claimKey .. "#liabilityStatus") or "NOT_APPLICABLE",
                        liabilityDecisionDay = xmlFile:getInt(claimKey .. "#liabilityDecisionDay") or 0,
                        liabilitySettlementDay = xmlFile:getInt(claimKey .. "#liabilitySettlementDay") or 0,
                        liabilityInsurerPaid = xmlFile:getFloat(claimKey .. "#liabilityInsurerPaid") or 0,
                        liabilityFarmCharge = xmlFile:getFloat(claimKey .. "#liabilityFarmCharge") or 0,
                        liabilityPolicyShortfall = xmlFile:getFloat(claimKey .. "#liabilityPolicyShortfall") or 0,
                        liabilityInsurerRecovery = xmlFile:getFloat(claimKey .. "#liabilityInsurerRecovery") or 0,
                        liabilityExcessConsumed = xmlFile:getFloat(claimKey .. "#liabilityExcessConsumed") or 0,
                        ownDamageEstimate = xmlFile:getFloat(claimKey .. "#ownDamageEstimate") or (xmlFile:getFloat(claimKey .. "#vehicleDamageCost") or 0),
                        ownDamageStatus = xmlFile:getString(claimKey .. "#ownDamageStatus") or "NOT_APPLICABLE",
                        adsRequired = xmlFile:getBool(claimKey .. "#adsRequired") or false,
                        adsLogBaselineId = xmlFile:getInt(claimKey .. "#adsLogBaselineId") or 0,
                        adsInspectionLogId = xmlFile:getInt(claimKey .. "#adsInspectionLogId") or 0,
                        adsInspectionCost = xmlFile:getFloat(claimKey .. "#adsInspectionCost") or 0,
                        adsRepairCost = xmlFile:getFloat(claimKey .. "#adsRepairCost") or 0,
                        adsInspectionIssueCount = xmlFile:getInt(claimKey .. "#adsInspectionIssueCount") or 0,
                        adsWarrantyRepair = xmlFile:getBool(claimKey .. "#adsWarrantyRepair") or false,
                        adsNonOemRepair = xmlFile:getBool(claimKey .. "#adsNonOemRepair") or false,
                        actualOwnDamageCost = xmlFile:getFloat(claimKey .. "#actualOwnDamageCost") or 0,
                        ownDecisionDay = xmlFile:getInt(claimKey .. "#ownDecisionDay") or 0,
                        ownSettlementDay = xmlFile:getInt(claimKey .. "#ownSettlementDay") or 0,
                        ownApprovedAmount = xmlFile:getFloat(claimKey .. "#ownApprovedAmount") or 0,
                        ownPaidAmount = xmlFile:getFloat(claimKey .. "#ownPaidAmount") or 0,
                        defaultCharge = xmlFile:getFloat(claimKey .. "#defaultCharge") or 0,
                        vehicleDamageCost = xmlFile:getFloat(claimKey .. "#vehicleDamageCost") or 0,
                        thirdPartyLiability = xmlFile:getFloat(claimKey .. "#thirdPartyLiability") or 0,
                        legalCosts = xmlFile:getFloat(claimKey .. "#legalCosts") or 0,
                        eligibleVehicleDamage = xmlFile:getFloat(claimKey .. "#eligibleVehicleDamage") or 0,
                        eligibleThirdPartyLiability = xmlFile:getFloat(claimKey .. "#eligibleThirdPartyLiability") or 0,
                        eligibleLegalCosts = xmlFile:getFloat(claimKey .. "#eligibleLegalCosts") or 0,
                        estimatedPayout = xmlFile:getFloat(claimKey .. "#estimatedPayout") or 0,
                        coverageSummary = xmlFile:getString(claimKey .. "#coverageSummary") or "",
                        licenceSnapshotVersion = xmlFile:getInt(claimKey .. "#licenceSnapshotVersion") or 0,
                        licenceModeAtIncident = xmlFile:getString(claimKey .. "#licenceModeAtIncident") or "",
                        licenceRequiredCategory = xmlFile:getString(claimKey .. "#licenceRequiredCategory") or "",
                        licenceEntitlementHeld = xmlFile:getBool(claimKey .. "#licenceEntitlementHeld") or false,
                        licenceSpecialistRevoked = xmlFile:getBool(claimKey .. "#licenceSpecialistRevoked") or false,
                        licenceRulesApplied = xmlFile:getBool(claimKey .. "#licenceRulesApplied") or false,
                        licenceAdrRequired = xmlFile:getBool(claimKey .. "#licenceAdrRequired") or false,
                        licenceAdrHeld = xmlFile:getBool(claimKey .. "#licenceAdrHeld") or false,
                        licenceHazardousLoadName = xmlFile:getString(claimKey .. "#licenceHazardousLoadName") or "",
                        licenceHazardousLoadLevel = xmlFile:getFloat(claimKey .. "#licenceHazardousLoadLevel") or 0,
                        licenceCategoryBreach = xmlFile:getBool(claimKey .. "#licenceCategoryBreach") or false,
                        licenceAdrBreach = xmlFile:getBool(claimKey .. "#licenceAdrBreach") or false,
                        licenceComplianceStatus = xmlFile:getString(claimKey .. "#licenceComplianceStatus") or "NOT_ASSESSED",
                        licenceRecoveryApplies = xmlFile:getBool(claimKey .. "#licenceRecoveryApplies") or false
                    }
                    table.insert(self.insuranceClaims, claim)
                    self.nextInsuranceClaimId = math.max(self.nextInsuranceClaimId, id + 1)
                end
                insuranceClaimIndex = insuranceClaimIndex + 1
            end

            local insuranceLossIndex = 0
            while true do
                local lossKey = string.format("realisticFarmFinance.insuranceLoss(%d)", insuranceLossIndex)
                if not xmlFile:hasProperty(lossKey) then break end
                local id = xmlFile:getInt(lossKey .. "#id")
                local farmId = xmlFile:getInt(lossKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local loss = {
                        id = id,
                        farmId = farmId,
                        source = xmlFile:getString(lossKey .. "#source") or "RLRM",
                        status = (function() local value = xmlFile:getString(lossKey .. "#status") or "RECORDED"; return value == "CLAIMABLE" and "RECORDED" or value end)(),
                        incidentDay = xmlFile:getInt(lossKey .. "#incidentDay") or 0,
                        incidentPeriod = xmlFile:getInt(lossKey .. "#incidentPeriod") or 0,
                        deadlinePeriod = xmlFile:getInt(lossKey .. "#deadlinePeriod") or 0,
                        claimId = xmlFile:getInt(lossKey .. "#claimId") or 0,
                        policyTier = xmlFile:getString(lossKey .. "#policyTier") or "STANDARD",
                        policyStatusAtIncident = xmlFile:getString(lossKey .. "#policyStatusAtIncident") or "ACTIVE",
                        animalUniqueId = xmlFile:getString(lossKey .. "#animalUniqueId") or "",
                        animalName = xmlFile:getString(lossKey .. "#animalName") or "",
                        animalBreed = xmlFile:getString(lossKey .. "#animalBreed") or "",
                        animalSubType = xmlFile:getString(lossKey .. "#animalSubType") or "",
                        animalType = xmlFile:getString(lossKey .. "#animalType") or "UNKNOWN",
                        animalAge = xmlFile:getInt(lossKey .. "#animalAge") or 0,
                        animalHealth = xmlFile:getFloat(lossKey .. "#animalHealth") or 0,
                        deathReason = xmlFile:getString(lossKey .. "#deathReason") or "UNKNOWN",
                        incidentValue = xmlFile:getFloat(lossKey .. "#incidentValue") or 0,
                        indemnityFactor = xmlFile:getFloat(lossKey .. "#indemnityFactor") or 0,
                        excess = xmlFile:getFloat(lossKey .. "#excess") or 0
                    }
                    table.insert(self.insuranceLosses, loss)
                    self.nextInsuranceLossId = math.max(self.nextInsuranceLossId, id + 1)
                end
                insuranceLossIndex = insuranceLossIndex + 1
            end

            local insuranceVeterinaryExpenseIndex = 0
            while true do
                local expenseKey = string.format("realisticFarmFinance.insuranceVeterinaryExpense(%d)", insuranceVeterinaryExpenseIndex)
                if not xmlFile:hasProperty(expenseKey) then break end
                local id = xmlFile:getInt(expenseKey .. "#id")
                local farmId = xmlFile:getInt(expenseKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local expense = {
                        id = id,
                        farmId = farmId,
                        source = xmlFile:getString(expenseKey .. "#source") or "RLRM",
                        status = xmlFile:getString(expenseKey .. "#status") or "RECORDED",
                        incidentDay = xmlFile:getInt(expenseKey .. "#incidentDay") or 0,
                        incidentPeriod = xmlFile:getInt(expenseKey .. "#incidentPeriod") or 0,
                        deadlinePeriod = xmlFile:getInt(expenseKey .. "#deadlinePeriod") or 0,
                        claimId = xmlFile:getInt(expenseKey .. "#claimId") or 0,
                        policyTier = xmlFile:getString(expenseKey .. "#policyTier") or "STANDARD",
                        policyStatusAtIncident = xmlFile:getString(expenseKey .. "#policyStatusAtIncident") or "ACTIVE",
                        animalUniqueId = xmlFile:getString(expenseKey .. "#animalUniqueId") or "",
                        animalName = xmlFile:getString(expenseKey .. "#animalName") or "",
                        animalBreed = xmlFile:getString(expenseKey .. "#animalBreed") or "",
                        animalSubType = xmlFile:getString(expenseKey .. "#animalSubType") or "",
                        animalType = xmlFile:getString(expenseKey .. "#animalType") or "UNKNOWN",
                        diseaseNames = xmlFile:getString(expenseKey .. "#diseaseNames") or "",
                        treatmentCost = xmlFile:getFloat(expenseKey .. "#treatmentCost") or 0
                    }
                    table.insert(self.insuranceVeterinaryExpenses, expense)
                    self.nextInsuranceVeterinaryExpenseId = math.max(self.nextInsuranceVeterinaryExpenseId, id + 1)
                end
                insuranceVeterinaryExpenseIndex = insuranceVeterinaryExpenseIndex + 1
            end

            local applicationIndex = 0
            while true do
                local appKey = string.format("realisticFarmFinance.application(%d)", applicationIndex)
                if not xmlFile:hasProperty(appKey) then
                    break
                end
                local id = xmlFile:getInt(appKey .. "#id")
                local farmId = xmlFile:getInt(appKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local dscr = xmlFile:getFloat(appKey .. "#submissionDscr")
                    local application = {
                        id = id,
                        farmId = farmId,
                        product = xmlFile:getString(appKey .. "#product") or "TERM",
                        purpose = xmlFile:getString(appKey .. "#purpose") or "GENERAL",
                        requestedAmount = xmlFile:getFloat(appKey .. "#requestedAmount") or 0,
                        requestedMonths = xmlFile:getInt(appKey .. "#requestedMonths") or 0,
                        status = xmlFile:getString(appKey .. "#status") or "SUBMITTED",
                        route = xmlFile:getString(appKey .. "#route") or "STANDARD",
                        submittedDay = xmlFile:getInt(appKey .. "#submittedDay") or 0,
                        initialReviewDay = xmlFile:getInt(appKey .. "#initialReviewDay") or 0,
                        decisionDay = xmlFile:getInt(appKey .. "#decisionDay") or 0,
                        expectedMinDays = xmlFile:getInt(appKey .. "#expectedMinDays") or 0,
                        expectedMaxDays = xmlFile:getInt(appKey .. "#expectedMaxDays") or 0,
                        offerExpiryDay = xmlFile:getInt(appKey .. "#offerExpiryDay") or 0,
                        acceptedDay = xmlFile:getInt(appKey .. "#acceptedDay") or 0,
                        submittedHour = xmlFile:getInt(appKey .. "#submittedHour") or 0,
                        initialReviewHour = xmlFile:getInt(appKey .. "#initialReviewHour") or 0,
                        underwritingHour = xmlFile:getInt(appKey .. "#underwritingHour") or 0,
                        finalReviewHour = xmlFile:getInt(appKey .. "#finalReviewHour") or 0,
                        decisionHour = xmlFile:getInt(appKey .. "#decisionHour") or 0,
                        expectedMinHours = xmlFile:getInt(appKey .. "#expectedMinHours") or 0,
                        expectedMaxHours = xmlFile:getInt(appKey .. "#expectedMaxHours") or 0,
                        offerExpiryHour = xmlFile:getInt(appKey .. "#offerExpiryHour") or 0,
                        acceptedHour = xmlFile:getInt(appKey .. "#acceptedHour") or 0,
                        calendarDaysPerPeriod = xmlFile:getInt(appKey .. "#calendarDaysPerPeriod") or 0,
                        farmlandId = xmlFile:getInt(appKey .. "#farmlandId") or 0,
                        securityFarmlandIds = xmlFile:getString(appKey .. "#securityFarmlandIds") or "",
                        securityFarmlandCount = xmlFile:getInt(appKey .. "#securityFarmlandCount") or 0,
                        propertyFinanceMode = xmlFile:getString(appKey .. "#propertyFinanceMode") or "",
                        requestedAdvancePercent = xmlFile:getFloat(appKey .. "#requestedAdvancePercent") or 0,
                        purchasePrice = xmlFile:getFloat(appKey .. "#purchasePrice") or 0,
                        requestedDepositPercent = xmlFile:getFloat(appKey .. "#requestedDepositPercent") or 0,
                        requestedDepositAmount = xmlFile:getFloat(appKey .. "#requestedDepositAmount") or 0,
                        lenderValuation = xmlFile:getFloat(appKey .. "#lenderValuation") or 0,
                        lenderValuationRatio = xmlFile:getFloat(appKey .. "#lenderValuationRatio") or 0,
                        valuationInstructionHour = xmlFile:getInt(appKey .. "#valuationInstructionHour") or 0,
                        valuationReturnHour = xmlFile:getInt(appKey .. "#valuationReturnHour") or 0,
                        valuationCompletedHour = xmlFile:getInt(appKey .. "#valuationCompletedHour") or 0,
                        submissionPropertyLtv = xmlFile:getFloat(appKey .. "#submissionPropertyLtv"),
                        offeredDeposit = xmlFile:getFloat(appKey .. "#offeredDeposit") or 0,
                        offeredPropertyLtv = xmlFile:getFloat(appKey .. "#offeredPropertyLtv") or 0,
                        propertyLtvLimit = xmlFile:getFloat(appKey .. "#propertyLtvLimit") or 0,
                        offeredAmount = xmlFile:getFloat(appKey .. "#offeredAmount") or 0,
                        offeredMonths = xmlFile:getInt(appKey .. "#offeredMonths") or 0,
                        offeredRate = xmlFile:getFloat(appKey .. "#offeredRate") or 0,
                        offeredPayment = xmlFile:getFloat(appKey .. "#offeredPayment") or 0,
                        offeredGrade = xmlFile:getString(appKey .. "#offeredGrade") or "",
                        outcome = xmlFile:getString(appKey .. "#outcome") or "PENDING",
                        decisionReason = xmlFile:getString(appKey .. "#decisionReason") or "",
                        linkedLoanId = xmlFile:getInt(appKey .. "#linkedLoanId") or 0,
                        submissionAssets = xmlFile:getFloat(appKey .. "#submissionAssets") or 0,
                        submissionCollateral = xmlFile:getFloat(appKey .. "#submissionCollateral") or 0,
                        submissionIncome = xmlFile:getFloat(appKey .. "#submissionIncome") or 0,
                        submissionTrackedPeriods = xmlFile:getInt(appKey .. "#submissionTrackedPeriods") or 0,
                        submissionLtv = xmlFile:getFloat(appKey .. "#submissionLtv") or 0,
                        submissionDscr = dscr,
                        submissionIndicativeApproved = xmlFile:getBool(appKey .. "#submissionIndicativeApproved") or false,
                        submissionIndicativeGrade = xmlFile:getString(appKey .. "#submissionIndicativeGrade") or "",
                        submissionIndicativeRate = xmlFile:getFloat(appKey .. "#submissionIndicativeRate") or 0,
                        submissionIndicativePayment = xmlFile:getFloat(appKey .. "#submissionIndicativePayment") or 0,
                        lenderId = xmlFile:getString(appKey .. "#lenderId") or "PRIMARY_BANK",
                        lenderNameKey = xmlFile:getString(appKey .. "#lenderNameKey") or "rff_lender_primary_bank",
                        marketState = xmlFile:getString(appKey .. "#marketState") or "SELECTIVE",
                        dealFit = xmlFile:getString(appKey .. "#dealFit") or "STANDARD"
                    }
                    table.insert(self.applications, application)
                    self.nextApplicationId = math.max(self.nextApplicationId, id + 1)
                end
                applicationIndex = applicationIndex + 1
            end


            local brokerCaseIndex = 0
            while true do
                local caseKey = string.format("realisticFarmFinance.brokerCase(%d)", brokerCaseIndex)
                if not xmlFile:hasProperty(caseKey) then break end
                local id = xmlFile:getInt(caseKey .. "#id")
                local farmId = xmlFile:getInt(caseKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local case = {
                        id=id, farmId=farmId, sourceApplicationId=xmlFile:getInt(caseKey .. "#sourceApplicationId") or 0,
                        product=xmlFile:getString(caseKey .. "#product") or "TERM", purpose=xmlFile:getString(caseKey .. "#purpose") or "GENERAL",
                        requestedAmount=xmlFile:getFloat(caseKey .. "#requestedAmount") or 0, requestedMonths=xmlFile:getInt(caseKey .. "#requestedMonths") or 0,
                        farmlandId=xmlFile:getInt(caseKey .. "#farmlandId") or 0, purchasePrice=xmlFile:getFloat(caseKey .. "#purchasePrice") or 0,
                        requestedDepositAmount=xmlFile:getFloat(caseKey .. "#requestedDepositAmount") or 0,
                        status=xmlFile:getString(caseKey .. "#status") or "INSTRUCTED", instructedHour=xmlFile:getInt(caseKey .. "#instructedHour") or 0,
                        lendersApproachedHour=xmlFile:getInt(caseKey .. "#lendersApproachedHour") or 0, indicativeHour=xmlFile:getInt(caseKey .. "#indicativeHour") or 0,
                        offersPreparingHour=xmlFile:getInt(caseKey .. "#offersPreparingHour") or 0, offersReadyHour=xmlFile:getInt(caseKey .. "#offersReadyHour") or 0,
                        expectedMinHours=xmlFile:getInt(caseKey .. "#expectedMinHours") or 0, expectedMaxHours=xmlFile:getInt(caseKey .. "#expectedMaxHours") or 0,
                        offerExpiryHour=xmlFile:getInt(caseKey .. "#offerExpiryHour") or 0, acceptedHour=xmlFile:getInt(caseKey .. "#acceptedHour") or 0,
                        acceptedOfferIndex=xmlFile:getInt(caseKey .. "#acceptedOfferIndex") or 0, acceptedLenderId=xmlFile:getString(caseKey .. "#acceptedLenderId") or "",
                        linkedLoanId=xmlFile:getInt(caseKey .. "#linkedLoanId") or 0, brokerFee=xmlFile:getFloat(caseKey .. "#brokerFee") or 0,
                        arrangementFee=xmlFile:getFloat(caseKey .. "#arrangementFee") or 0, offers={}
                    }
                    local offerIndex = 0
                    while true do
                        local offerKey = string.format("%s.offer(%d)", caseKey, offerIndex)
                        if not xmlFile:hasProperty(offerKey) then break end
                        table.insert(case.offers, {
                            lenderId=xmlFile:getString(offerKey .. "#lenderId") or "", amount=xmlFile:getFloat(offerKey .. "#amount") or 0,
                            months=xmlFile:getInt(offerKey .. "#months") or 0, interestRate=xmlFile:getFloat(offerKey .. "#interestRate") or 0,
                            monthlyPayment=xmlFile:getFloat(offerKey .. "#monthlyPayment") or 0, grade=xmlFile:getString(offerKey .. "#grade") or "C",
                            arrangementFee=xmlFile:getFloat(offerKey .. "#arrangementFee") or 0, brokerFee=xmlFile:getFloat(offerKey .. "#brokerFee") or 0,
                            lenderValuation=xmlFile:getFloat(offerKey .. "#lenderValuation") or 0, deposit=xmlFile:getFloat(offerKey .. "#deposit") or 0,
                            propertyLtv=xmlFile:getFloat(offerKey .. "#propertyLtv") or 0, propertyLtvLimit=xmlFile:getFloat(offerKey .. "#propertyLtvLimit") or 0,
                            dscr=xmlFile:getFloat(offerKey .. "#dscr"), marketState=xmlFile:getString(offerKey .. "#marketState") or "SELECTIVE",
                            dealFit=xmlFile:getString(offerKey .. "#dealFit") or "STANDARD"
                        })
                        offerIndex = offerIndex + 1
                    end
                    table.insert(self.brokerCases, case)
                    self.nextBrokerCaseId = math.max(self.nextBrokerCaseId, id + 1)
                end
                brokerCaseIndex = brokerCaseIndex + 1
            end

            local proactiveIndex = 0
            while true do
                local offerKey = string.format("realisticFarmFinance.preApprovedOffer(%d)", proactiveIndex)
                if not xmlFile:hasProperty(offerKey) then break end
                local id = xmlFile:getInt(offerKey .. "#id")
                local farmId = xmlFile:getInt(offerKey .. "#farmId")
                if id ~= nil and farmId ~= nil and farmId > 0 then
                    local offer = {
                        id=id, farmId=farmId,
                        lenderId=xmlFile:getString(offerKey .. "#lenderId") or "PRIMARY_BANK",
                        lenderNameKey=xmlFile:getString(offerKey .. "#lenderNameKey") or "rff_lender_primary_bank",
                        product=xmlFile:getString(offerKey .. "#product") or "TERM",
                        purpose=xmlFile:getString(offerKey .. "#purpose") or "GENERAL",
                        amount=xmlFile:getFloat(offerKey .. "#amount") or 0,
                        months=xmlFile:getInt(offerKey .. "#months") or 0,
                        interestRate=xmlFile:getFloat(offerKey .. "#interestRate") or 0,
                        monthlyPayment=xmlFile:getFloat(offerKey .. "#monthlyPayment") or 0,
                        grade=xmlFile:getString(offerKey .. "#grade") or "C",
                        arrangementFee=xmlFile:getFloat(offerKey .. "#arrangementFee") or 0,
                        relationshipTier=xmlFile:getString(offerKey .. "#relationshipTier") or "NEW",
                        relationshipPoints=xmlFile:getFloat(offerKey .. "#relationshipPoints") or 0,
                        marketState=xmlFile:getString(offerKey .. "#marketState") or "SELECTIVE",
                        dealFit=xmlFile:getString(offerKey .. "#dealFit") or "STANDARD",
                        status=xmlFile:getString(offerKey .. "#status") or "OFFERED",
                        createdPeriod=xmlFile:getInt(offerKey .. "#createdPeriod") or 0,
                        expiryPeriod=xmlFile:getInt(offerKey .. "#expiryPeriod") or 0,
                        acceptedPeriod=xmlFile:getInt(offerKey .. "#acceptedPeriod") or 0,
                        declinedPeriod=xmlFile:getInt(offerKey .. "#declinedPeriod") or 0,
                        linkedLoanId=xmlFile:getInt(offerKey .. "#linkedLoanId") or 0
                    }
                    table.insert(self.preApprovedOffers, offer)
                    self.nextPreApprovedOfferId = math.max(self.nextPreApprovedOfferId, id + 1)
                end
                proactiveIndex = proactiveIndex + 1
            end

            local brokerRelIndex = 0
            while true do
                local relKey = string.format("realisticFarmFinance.brokerRelationship(%d)", brokerRelIndex)
                if not xmlFile:hasProperty(relKey) then break end
                local farmId = xmlFile:getInt(relKey .. "#farmId") or 0
                if farmId > 0 then
                    self.brokerRelationships[farmId] = {farmId=farmId, casesInstructed=xmlFile:getInt(relKey .. "#casesInstructed") or 0,
                        acceptedDeals=xmlFile:getInt(relKey .. "#acceptedDeals") or 0, successfulIntroductions=xmlFile:getInt(relKey .. "#successfulIntroductions") or 0,
                        feesPaid=xmlFile:getFloat(relKey .. "#feesPaid") or 0, relationshipPoints=xmlFile:getInt(relKey .. "#relationshipPoints") or 0}
                end
                brokerRelIndex = brokerRelIndex + 1
            end

            local lenderRelIndex = 0
            while true do
                local relKey = string.format("realisticFarmFinance.lenderRelationship(%d)", lenderRelIndex)
                if not xmlFile:hasProperty(relKey) then break end
                local farmId = xmlFile:getInt(relKey .. "#farmId") or 0
                local lenderId = xmlFile:getString(relKey .. "#lenderId") or ""
                if farmId > 0 and lenderId ~= "" then
                    self.lenderRelationships[farmId] = self.lenderRelationships[farmId] or {}
                    self.lenderRelationships[farmId][lenderId] = {farmId=farmId, lenderId=lenderId, applications=xmlFile:getInt(relKey .. "#applications") or 0,
                        offersMade=xmlFile:getInt(relKey .. "#offersMade") or 0, acceptedDeals=xmlFile:getInt(relKey .. "#acceptedDeals") or 0,
                        totalVolume=xmlFile:getFloat(relKey .. "#totalVolume") or 0, relationshipPoints=xmlFile:getFloat(relKey .. "#relationshipPoints") or 0,
                        successfulPayments=xmlFile:getInt(relKey .. "#successfulPayments") or 0, missedPayments=xmlFile:getInt(relKey .. "#missedPayments") or 0,
                        completedAgreements=xmlFile:getInt(relKey .. "#completedAgreements") or 0, forcedRecoveries=xmlFile:getInt(relKey .. "#forcedRecoveries") or 0,
                        mortgagePossessions=xmlFile:getInt(relKey .. "#mortgagePossessions") or 0, voluntarySurrenders=xmlFile:getInt(relKey .. "#voluntarySurrenders") or 0,
                        voluntaryPropertySales=xmlFile:getInt(relKey .. "#voluntaryPropertySales") or 0, restructures=xmlFile:getInt(relKey .. "#restructures") or 0,
                        arrearsCured=xmlFile:getInt(relKey .. "#arrearsCured") or 0, lastInteractionPeriod=xmlFile:getInt(relKey .. "#lastInteractionPeriod") or 0,
                        proactiveOffersMade=xmlFile:getInt(relKey .. "#proactiveOffersMade") or 0, proactiveOffersAccepted=xmlFile:getInt(relKey .. "#proactiveOffersAccepted") or 0,
                        proactiveOffersDeclined=xmlFile:getInt(relKey .. "#proactiveOffersDeclined") or 0, lastProactiveOfferPeriod=xmlFile:getInt(relKey .. "#lastProactiveOfferPeriod") or 0,
                        forbearanceArrangements=xmlFile:getInt(relKey .. "#forbearanceArrangements") or 0, brokenForbearanceArrangements=xmlFile:getInt(relKey .. "#brokenForbearanceArrangements") or 0,
                        rescueExits=xmlFile:getInt(relKey .. "#rescueExits") or 0, rescueDeals=xmlFile:getInt(relKey .. "#rescueDeals") or 0,
                        relationshipSchemaVersion=xmlFile:getInt(relKey .. "#relationshipSchemaVersion") or 0}
                end
                lenderRelIndex = lenderRelIndex + 1
            end

            xmlFile:delete()
        end
    end

    self.loaded = true
    self:ensureCurrentFarm()
    print(string.format("[RealisticFarmFinance] Loaded finance core (%d farm record(s), %d finance agreement(s), %d asset-finance agreement(s), %d vehicle insurance policy record(s), %d Traffic Courtesy incident(s), %d driver offence(s), %d tenancy agreement(s), %d credit application(s), %d broker case(s), %d proactive lender offer(s))", self:getFarmRecordCount(), #self.loans, #self.assetFinance, #self.vehicleInsurancePolicies, #self.trafficCourtesyIncidents, #self.driverOffences, #self.tenancies, #self.applications, #self.brokerCases, #self.preApprovedOffers))
end

function RFF_FinanceRepository:getFarmRecordCount()
    local count = 0
    for _ in pairs(self.farms) do
        count = count + 1
    end
    return count
end

function RFF_FinanceRepository:saveToXMLFile()
    if not self.loaded or g_currentMission == nil or not g_currentMission:getIsServer() then
        return
    end

    self:ensureCurrentFarm()

    local savegameDir = g_currentMission.missionInfo.savegameDirectory
    if savegameDir == nil then
        return
    end

    local path = savegameDir .. "/realisticFarmFinance.xml"
    local xmlFile = XMLFile.create("realisticFarmFinance", path, "realisticFarmFinance")
    xmlFile:setInt("realisticFarmFinance#version", 32)
    xmlFile:setInt("realisticFarmFinance#nextLoanId", self.nextLoanId or 1)
    xmlFile:setInt("realisticFarmFinance#nextTenancyId", self.nextTenancyId or 1)
    xmlFile:setInt("realisticFarmFinance#nextApplicationId", self.nextApplicationId or 1)
    xmlFile:setInt("realisticFarmFinance#nextBrokerCaseId", self.nextBrokerCaseId or 1)
    xmlFile:setInt("realisticFarmFinance#nextPreApprovedOfferId", self.nextPreApprovedOfferId or 1)
    xmlFile:setInt("realisticFarmFinance#nextAssetFinanceId", self.nextAssetFinanceId or 1)
    xmlFile:setInt("realisticFarmFinance#nextVehicleInsurancePolicyId", self.nextVehicleInsurancePolicyId or 1)
    xmlFile:setInt("realisticFarmFinance#nextTrafficCourtesyIncidentId", self.nextTrafficCourtesyIncidentId or 1)
    xmlFile:setInt("realisticFarmFinance#nextDriverOffenceId", self.nextDriverOffenceId or 1)
    xmlFile:setInt("realisticFarmFinance#nextInsuranceClaimId", self.nextInsuranceClaimId or 1)
    xmlFile:setInt("realisticFarmFinance#nextInsuranceLossId", self.nextInsuranceLossId or 1)
    xmlFile:setInt("realisticFarmFinance#nextInsuranceVeterinaryExpenseId", self.nextInsuranceVeterinaryExpenseId or 1)

    local farmIndex = 0
    for farmId, state in pairs(self.farms) do
        local farmKey = string.format("realisticFarmFinance.farm(%d)", farmIndex)
        xmlFile:setInt(farmKey .. "#id", farmId)
        xmlFile:setInt(farmKey .. "#firstTrackedPeriod", state.firstTrackedPeriod or self:getCurrentPeriodIndex())
        xmlFile:setFloat(farmKey .. "#bankPositiveBalanceSum", state.bankPositiveBalanceSum or 0)
        xmlFile:setInt(farmKey .. "#bankBalanceSamples", state.bankBalanceSamples or 0)
        xmlFile:setFloat(farmKey .. "#bankLastInterestCredit", state.bankLastInterestCredit or 0)
        xmlFile:setFloat(farmKey .. "#bankLastInterestRate", state.bankLastInterestRate or 0)
        xmlFile:setFloat(farmKey .. "#bankLastAverageBalance", state.bankLastAverageBalance or 0)
        xmlFile:setInt(farmKey .. "#bankLastInterestPeriod", state.bankLastInterestPeriod or 0)
        xmlFile:setInt(farmKey .. "#bankLastSamplePeriod", state.bankLastSamplePeriod or 0)
        xmlFile:setInt(farmKey .. "#bankLastUnauthorisedDay", state.bankLastUnauthorisedDay or 0)
        xmlFile:setFloat(farmKey .. "#bankUnauthorisedInterestPaid", state.bankUnauthorisedInterestPaid or 0)
        xmlFile:setFloat(farmKey .. "#bankUnauthorisedFeesPaid", state.bankUnauthorisedFeesPaid or 0)
        xmlFile:setInt(farmKey .. "#adminLastProcessedPeriod", state.adminLastProcessedPeriod or self:getCurrentPeriodIndex())
        xmlFile:setFloat(farmKey .. "#adminArrears", state.adminArrears or 0)
        xmlFile:setFloat(farmKey .. "#adminLastCharge", state.adminLastCharge or 0)
        xmlFile:setFloat(farmKey .. "#adminLastMonthlyCharge", state.adminLastMonthlyCharge or 0)
        xmlFile:setFloat(farmKey .. "#adminLastAnnualFilingCharge", state.adminLastAnnualFilingCharge or 0)
        xmlFile:setInt(farmKey .. "#adminLastAnnualFilingYear", state.adminLastAnnualFilingYear or 0)
        xmlFile:setFloat(farmKey .. "#adminLastLateFee", state.adminLastLateFee or 0)
        xmlFile:setFloat(farmKey .. "#adminTotalPaid", state.adminTotalPaid or 0)
        xmlFile:setInt(farmKey .. "#adminMissedPayments", state.adminMissedPayments or 0)
        xmlFile:setString(farmKey .. "#insuranceTier", state.insuranceTier or "STANDARD")
        xmlFile:setString(farmKey .. "#insuranceNextTier", state.insuranceNextTier or state.insuranceTier or "STANDARD")
        xmlFile:setString(farmKey .. "#insuranceStatus", state.insuranceStatus or "ACTIVE")
        xmlFile:setInt(farmKey .. "#insuranceNextRenewalPeriod", state.insuranceNextRenewalPeriod or (self:getCurrentPeriodIndex() + 1))
        xmlFile:setFloat(farmKey .. "#insurancePremiumDue", state.insurancePremiumDue or 0)
        xmlFile:setFloat(farmKey .. "#insuranceLastPremium", state.insuranceLastPremium or 0)
        xmlFile:setFloat(farmKey .. "#insuranceLastValuation", state.insuranceLastValuation or 0)
        xmlFile:setInt(farmKey .. "#insuranceLastRenewalPeriod", state.insuranceLastRenewalPeriod or 0)
        xmlFile:setInt(farmKey .. "#insuranceGraceUntilPeriod", state.insuranceGraceUntilPeriod or 0)
        xmlFile:setFloat(farmKey .. "#insuranceTotalPaid", state.insuranceTotalPaid or 0)
        xmlFile:setInt(farmKey .. "#insuranceMissedPremiums", state.insuranceMissedPremiums or 0)
        xmlFile:setInt(farmKey .. "#insuranceRenewalNoticePeriod", state.insuranceRenewalNoticePeriod or 0)
        xmlFile:setBool(farmKey .. "#vehicleInsuranceMigrated", state.vehicleInsuranceMigrated == true)
        xmlFile:setString(farmKey .. "#vehicleInsuranceTier", state.vehicleInsuranceTier or "STANDARD")
        xmlFile:setString(farmKey .. "#vehicleInsuranceNextTier", state.vehicleInsuranceNextTier or state.vehicleInsuranceTier or "STANDARD")
        xmlFile:setString(farmKey .. "#vehicleInsuranceStatus", state.vehicleInsuranceStatus or "ACTIVE")
        xmlFile:setInt(farmKey .. "#vehicleInsuranceNextRenewalPeriod", state.vehicleInsuranceNextRenewalPeriod or (self:getCurrentPeriodIndex() + 1))
        xmlFile:setFloat(farmKey .. "#vehicleInsurancePremiumDue", state.vehicleInsurancePremiumDue or 0)
        xmlFile:setFloat(farmKey .. "#vehicleInsuranceLastPremium", state.vehicleInsuranceLastPremium or 0)
        xmlFile:setFloat(farmKey .. "#vehicleInsuranceLastValuation", state.vehicleInsuranceLastValuation or 0)
        xmlFile:setInt(farmKey .. "#vehicleInsuranceLastRenewalPeriod", state.vehicleInsuranceLastRenewalPeriod or 0)
        xmlFile:setInt(farmKey .. "#vehicleInsuranceGraceUntilPeriod", state.vehicleInsuranceGraceUntilPeriod or 0)
        xmlFile:setFloat(farmKey .. "#vehicleInsuranceTotalPaid", state.vehicleInsuranceTotalPaid or 0)
        xmlFile:setInt(farmKey .. "#vehicleInsuranceMissedPremiums", state.vehicleInsuranceMissedPremiums or 0)
        xmlFile:setInt(farmKey .. "#vehicleInsuranceRenewalNoticePeriod", state.vehicleInsuranceRenewalNoticePeriod or 0)
        xmlFile:setBool(farmKey .. "#vehicleInsurancePerVehicleMigrated", state.vehicleInsurancePerVehicleMigrated == true)
        xmlFile:setInt(farmKey .. "#driverQualificationVersion", state.driverQualificationVersion or 4)
        xmlFile:setString(farmKey .. "#driverLicenceMode", state.driverLicenceMode or "FULL")
        xmlFile:setBool(farmKey .. "#driverCategoryB", true)
        xmlFile:setBool(farmKey .. "#driverCategoryF", state.driverCategoryF == true)
        xmlFile:setBool(farmKey .. "#driverCategoryH", state.driverCategoryH == true)
        xmlFile:setBool(farmKey .. "#driverCategoryC", state.driverCategoryC == true)
        xmlFile:setBool(farmKey .. "#driverAdr", state.driverAdr == true)
        xmlFile:setInt(farmKey .. "#driverPenaltyPoints", state.driverPenaltyPoints or 0)
        xmlFile:setInt(farmKey .. "#driverPointsVersion", state.driverPointsVersion or 0)
        xmlFile:setBool(farmKey .. "#driverSpecialistRevoked", state.driverSpecialistRevoked == true)
        xmlFile:setBool(farmKey .. "#driverPenaltiesEnabled", state.driverPenaltiesEnabled == true)
        xmlFile:setBool(farmKey .. "#speedingEnforcementEnabled", state.speedingEnforcementEnabled == true)
        xmlFile:setBool(farmKey .. "#roadsideChecksEnabled", state.roadsideChecksEnabled == true)
        if state.roadsideCheckRemaining ~= nil then xmlFile:setFloat(farmKey .. "#roadsideCheckRemaining",state.roadsideCheckRemaining) end
        xmlFile:setFloat(farmKey .. "#roadsideCooldownUntil",state.roadsideCooldownUntil or 0)
        if state.speedingCheckRemaining ~= nil then xmlFile:setFloat(farmKey .. "#speedingCheckRemaining", state.speedingCheckRemaining) end
        xmlFile:setFloat(farmKey .. "#speedingWindowRemaining", state.speedingWindowRemaining or 0)
        xmlFile:setFloat(farmKey .. "#speedingCooldownUntil", state.speedingCooldownUntil or 0)
        xmlFile:setBool(farmKey .. "#vehicleInsurancePointsEnabled", state.vehicleInsurancePointsEnabled == true)
        xmlFile:setBool(farmKey .. "#roadSpeedHudEnabled", state.roadSpeedHudEnabled ~= false)
        xmlFile:setFloat(farmKey .. "#driverRestrictionEnd", state.driverRestrictionEnd or 0)
        xmlFile:setInt(farmKey .. "#driverRestrictionRepeats", state.driverRestrictionRepeats or 0)
        xmlFile:setInt(farmKey .. "#driverRestrictionServedPoints", state.driverRestrictionServedPoints or 0)
        xmlFile:setString(farmKey .. "#driverAssessmentCategory", state.driverAssessmentCategory or "")
        xmlFile:setString(farmKey .. "#driverAssessmentStatus", state.driverAssessmentStatus or "NONE")
        xmlFile:setInt(farmKey .. "#driverAssessmentBookedDay", state.driverAssessmentBookedDay or 0)
        xmlFile:setInt(farmKey .. "#driverAssessmentAvailableDay", state.driverAssessmentAvailableDay or 0)
        xmlFile:setInt(farmKey .. "#driverAssessmentDeadlineDay", state.driverAssessmentDeadlineDay or 0)
        xmlFile:setFloat(farmKey .. "#driverAssessmentReturnDeadlineHour", state.driverAssessmentReturnDeadlineHour or 0)
        xmlFile:setString(farmKey .. "#driverAssessmentVehicleUniqueId", state.driverAssessmentVehicleUniqueId or "")
        xmlFile:setString(farmKey .. "#driverAssessmentVehicleName", state.driverAssessmentVehicleName or "")
        xmlFile:setFloat(farmKey .. "#driverAssessmentDistance", state.driverAssessmentDistance or 0)
        xmlFile:setFloat(farmKey .. "#driverAssessmentRoadDistance", state.driverAssessmentRoadDistance or 0)
        xmlFile:setFloat(farmKey .. "#driverAssessmentReverseDistance", state.driverAssessmentReverseDistance or 0)
        xmlFile:setFloat(farmKey .. "#driverAssessmentMovingSeconds", state.driverAssessmentMovingSeconds or 0)
        xmlFile:setFloat(farmKey .. "#driverAssessmentLeftTurnDegrees", state.driverAssessmentLeftTurnDegrees or 0)
        xmlFile:setFloat(farmKey .. "#driverAssessmentRightTurnDegrees", state.driverAssessmentRightTurnDegrees or 0)
        xmlFile:setFloat(farmKey .. "#driverAssessmentSpeedFaultSeconds", state.driverAssessmentSpeedFaultSeconds or 0)
        xmlFile:setInt(farmKey .. "#driverAssessmentCollisionCount", state.driverAssessmentCollisionCount or 0)
        xmlFile:setInt(farmKey .. "#driverAssessmentTheoryIndex", state.driverAssessmentTheoryIndex or 0)
        xmlFile:setInt(farmKey .. "#driverAssessmentTheoryScore", state.driverAssessmentTheoryScore or 0)
        xmlFile:setString(farmKey .. "#driverAssessmentFailureReason", state.driverAssessmentFailureReason or "")
        xmlFile:setString(farmKey .. "#driverAssessmentLastResultCategory", state.driverAssessmentLastResultCategory or "")
        xmlFile:setString(farmKey .. "#driverAssessmentLastResult", state.driverAssessmentLastResult or "")
        local movementAuthorisations = {}
        for _, authorisation in pairs(type(state.movementAuthorisations) == "table" and state.movementAuthorisations or {}) do
            if type(authorisation) == "table" and tostring(authorisation.vehicleUniqueId or "") ~= ""
                and (authorisation.expiresHour or 0) > 0 then
                movementAuthorisations[#movementAuthorisations + 1] = authorisation
            end
        end
        table.sort(movementAuthorisations, function(a, b)
            return tostring(a.vehicleUniqueId or "") < tostring(b.vehicleUniqueId or "")
        end)
        for authorisationIndex, authorisation in ipairs(movementAuthorisations) do
            local authorisationKey = string.format("%s.movementAuthorisation(%d)", farmKey, authorisationIndex - 1)
            xmlFile:setString(authorisationKey .. "#vehicleUniqueId", authorisation.vehicleUniqueId or "")
            xmlFile:setString(authorisationKey .. "#vehicleName", authorisation.vehicleName or "Vehicle")
            xmlFile:setFloat(authorisationKey .. "#authorisedWidth", authorisation.authorisedWidth or 0)
            xmlFile:setFloat(authorisationKey .. "#issuedHour", authorisation.issuedHour or 0)
            xmlFile:setFloat(authorisationKey .. "#expiresHour", authorisation.expiresHour or 0)
        end
        xmlFile:setInt(farmKey .. "#taxReturnYear", state.taxReturnYear or 0)
        xmlFile:setString(farmKey .. "#taxReturnStatus", state.taxReturnStatus or "NONE")
        xmlFile:setInt(farmKey .. "#taxReturnOpenPeriod", state.taxReturnOpenPeriod or 0)
        xmlFile:setInt(farmKey .. "#taxReturnFiledPeriod", state.taxReturnFiledPeriod or 0)
        xmlFile:setString(farmKey .. "#taxReturnMethod", state.taxReturnMethod or "NONE")
        xmlFile:setString(farmKey .. "#taxReturnSignedBy", state.taxReturnSignedBy or "")
        xmlFile:setFloat(farmKey .. "#taxReturnBookIncome", state.taxReturnBookIncome or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnBookTaxedIncome", state.taxReturnBookTaxedIncome or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnBookExpenses", state.taxReturnBookExpenses or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnBookTax", state.taxReturnBookTax or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnLossRollover", state.taxReturnLossRollover or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnTaxRate", state.taxReturnTaxRate or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnIncomeFactor", state.taxReturnIncomeFactor or 1)
        xmlFile:setFloat(farmKey .. "#taxReturnExpenseFactor", state.taxReturnExpenseFactor or 1)
        xmlFile:setFloat(farmKey .. "#taxReturnDeclaredIncome", state.taxReturnDeclaredIncome or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnDeclaredTaxedIncome", state.taxReturnDeclaredTaxedIncome or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnDeclaredExpenses", state.taxReturnDeclaredExpenses or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnFiledTax", state.taxReturnFiledTax or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnTaxSaving", state.taxReturnTaxSaving or 0)
        xmlFile:setFloat(farmKey .. "#taxReturnAdjustment", state.taxReturnAdjustment or 0)
        xmlFile:setBool(farmKey .. "#taxReturnAdjustmentApplied", state.taxReturnAdjustmentApplied == true)
        xmlFile:setFloat(farmKey .. "#taxReturnAccountantFee", state.taxReturnAccountantFee or 0)
        xmlFile:setBool(farmKey .. "#taxReturnWasForcedTest", state.taxReturnWasForcedTest == true)
        xmlFile:setInt(farmKey .. "#taxComplianceFlags", state.taxComplianceFlags or 0)
        xmlFile:setInt(farmKey .. "#taxComplianceCleanFilings", state.taxComplianceCleanFilings or 0)
        xmlFile:setInt(farmKey .. "#taxComplianceAggressiveFilings", state.taxComplianceAggressiveFilings or 0)
        xmlFile:setFloat(farmKey .. "#taxComplianceLiability", state.taxComplianceLiability or 0)
        xmlFile:setInt(farmKey .. "#taxComplianceLastInterestPeriod", state.taxComplianceLastInterestPeriod or 0)
        xmlFile:setString(farmKey .. "#taxInvestigationStatus", state.taxInvestigationStatus or "NONE")
        xmlFile:setInt(farmKey .. "#taxInvestigationStartPeriod", state.taxInvestigationStartPeriod or 0)
        xmlFile:setInt(farmKey .. "#taxInvestigationOutcomePeriod", state.taxInvestigationOutcomePeriod or 0)
        xmlFile:setString(farmKey .. "#taxInvestigationLastOutcome", state.taxInvestigationLastOutcome or "NONE")
        xmlFile:setFloat(farmKey .. "#taxInvestigationAdjustment", state.taxInvestigationAdjustment or 0)
        xmlFile:setFloat(farmKey .. "#taxInvestigationPenalty", state.taxInvestigationPenalty or 0)
        xmlFile:setFloat(farmKey .. "#taxInvestigationInterest", state.taxInvestigationInterest or 0)
        xmlFile:setInt(farmKey .. "#legacyLoanMigrationVersion", state.legacyLoanMigrationVersion or 0)
        xmlFile:setFloat(farmKey .. "#legacyLoanImportedAmount", state.legacyLoanImportedAmount or 0)
        xmlFile:setInt(farmKey .. "#legacyLoanImportedId", state.legacyLoanImportedId or 0)
        xmlFile:setString(farmKey .. "#externalFinanceMigrationIds", state.externalFinanceMigrationIds or "")

        local indexes = {}
        for index in pairs(state.periods) do
            table.insert(indexes, index)
        end
        table.sort(indexes)

        for periodIndex, absoluteIndex in ipairs(indexes) do
            local period = state.periods[absoluteIndex]
            local periodKey = string.format("%s.period(%d)", farmKey, periodIndex - 1)
            xmlFile:setInt(periodKey .. "#index", absoluteIndex)
            xmlFile:setFloat(periodKey .. "#inflows", period.inflows or 0)
            xmlFile:setFloat(periodKey .. "#outflows", period.outflows or 0)
            xmlFile:setFloat(periodKey .. "#operatingIncome", period.operatingIncome or 0)
            if period.openingBalance ~= nil then xmlFile:setFloat(periodKey .. "#openingBalance", period.openingBalance) end
            if period.closingBalance ~= nil then xmlFile:setFloat(periodKey .. "#closingBalance", period.closingBalance) end
            if period.year ~= nil then xmlFile:setInt(periodKey .. "#year", period.year) end
            if period.periodNumber ~= nil then xmlFile:setInt(periodKey .. "#periodNumber", period.periodNumber) end
            xmlFile:setBool(periodKey .. "#statementTruncated", period.statementTruncated == true)

            for transactionIndex, transaction in ipairs(period.transactions or {}) do
                local transactionKey = string.format("%s.transaction(%d)", periodKey, transactionIndex - 1)
                xmlFile:setInt(transactionKey .. "#day", transaction.day or 1)
                xmlFile:setInt(transactionKey .. "#year", transaction.year or 0)
                xmlFile:setInt(transactionKey .. "#periodNumber", transaction.periodNumber or 0)
                xmlFile:setFloat(transactionKey .. "#amount", transaction.amount or 0)
                xmlFile:setFloat(transactionKey .. "#balance", transaction.balance or 0)
                xmlFile:setString(transactionKey .. "#description", transaction.description or "Account transaction")
                xmlFile:setString(transactionKey .. "#statistic", transaction.statistic or "")
            end

            local snapshot = period.snapshot
            xmlFile:setBool(periodKey .. ".snapshot#valid", snapshot ~= nil)
            if snapshot ~= nil then
                xmlFile:setFloat(periodKey .. ".snapshot#cash", snapshot.cash or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#farmland", snapshot.farmland or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#buildings", snapshot.buildings or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#equipment", snapshot.equipment or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#livestock", snapshot.livestock or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#inventory", snapshot.inventory or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#refundableDeposits", snapshot.refundableDeposits or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#totalAssets", snapshot.totalAssets or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#liabilities", snapshot.liabilities or 0)
                xmlFile:setFloat(periodKey .. ".snapshot#netWorth", snapshot.netWorth or 0)
            end
        end
        farmIndex = farmIndex + 1
    end

    for index, loan in ipairs(self.loans or {}) do
        local loanKey = string.format("realisticFarmFinance.loan(%d)", index - 1)
        xmlFile:setInt(loanKey .. "#id", loan.id or index)
        xmlFile:setInt(loanKey .. "#farmId", loan.farmId or 0)
        xmlFile:setString(loanKey .. "#type", loan.type or "TERM")
        xmlFile:setString(loanKey .. "#purpose", loan.purpose or "GENERAL")
        xmlFile:setFloat(loanKey .. "#originalAmount", loan.originalAmount or 0)
        xmlFile:setFloat(loanKey .. "#creditLimit", loan.creditLimit or 0)
        xmlFile:setFloat(loanKey .. "#principal", loan.principal or 0)
        xmlFile:setFloat(loanKey .. "#drawnAmount", loan.drawnAmount or 0)
        xmlFile:setFloat(loanKey .. "#interestRate", loan.interestRate or 0)
        xmlFile:setInt(loanKey .. "#termMonths", loan.termMonths or 0)
        xmlFile:setInt(loanKey .. "#remainingMonths", loan.remainingMonths or 0)
        xmlFile:setFloat(loanKey .. "#monthlyPayment", loan.monthlyPayment or 0)
        xmlFile:setString(loanKey .. "#riskGrade", loan.riskGrade or "C")
        xmlFile:setInt(loanKey .. "#createdPeriod", loan.createdPeriod or 0)
        xmlFile:setInt(loanKey .. "#lastPaymentPeriod", loan.lastPaymentPeriod or 0)
        xmlFile:setInt(loanKey .. "#paymentsMade", loan.paymentsMade or 0)
        xmlFile:setInt(loanKey .. "#missedPayments", loan.missedPayments or 0)
        xmlFile:setFloat(loanKey .. "#arrearsPrincipal", loan.arrearsPrincipal or 0)
        xmlFile:setFloat(loanKey .. "#arrearsInterest", loan.arrearsInterest or 0)
        xmlFile:setFloat(loanKey .. "#arrearsFees", loan.arrearsFees or 0)
        xmlFile:setFloat(loanKey .. "#arrearsBalance", loan.arrearsBalance or 0)
        xmlFile:setInt(loanKey .. "#arrearsAgeMonths", loan.arrearsAgeMonths or 0)
        xmlFile:setString(loanKey .. "#arrearsStage", loan.arrearsStage or "CURRENT")
        xmlFile:setFloat(loanKey .. "#defaultInterestAccrued", loan.defaultInterestAccrued or 0)
        xmlFile:setFloat(loanKey .. "#adminChargesAccrued", loan.adminChargesAccrued or 0)
        xmlFile:setInt(loanKey .. "#defaultEvents", loan.defaultEvents or 0)
        xmlFile:setBool(loanKey .. "#currentDefault", loan.currentDefault == true)
        xmlFile:setBool(loanKey .. "#defaultRecorded", loan.defaultRecorded == true)
        xmlFile:setBool(loanKey .. "#recoveryEligible", loan.recoveryEligible == true)
        xmlFile:setInt(loanKey .. "#lastDefaultManagementPeriod", loan.lastDefaultManagementPeriod or 0)
        xmlFile:setInt(loanKey .. "#consecutiveMissedPayments", loan.consecutiveMissedPayments or 0)
        xmlFile:setInt(loanKey .. "#maxConsecutiveMissedPayments", loan.maxConsecutiveMissedPayments or 0)
        xmlFile:setInt(loanKey .. "#lastMissedPeriod", loan.lastMissedPeriod or 0)
        xmlFile:setInt(loanKey .. "#lastSuccessfulPaymentPeriod", loan.lastSuccessfulPaymentPeriod or 0)
        xmlFile:setInt(loanKey .. "#lastArrearsClearedPeriod", loan.lastArrearsClearedPeriod or 0)
        xmlFile:setInt(loanKey .. "#arrearsSchemaVersion", 1)
        xmlFile:setFloat(loanKey .. "#principalPaid", loan.principalPaid or 0)
        xmlFile:setFloat(loanKey .. "#interestPaid", loan.interestPaid or 0)
        xmlFile:setInt(loanKey .. "#completedPeriod", loan.completedPeriod or 0)
        xmlFile:setBool(loanKey .. "#paidOff", loan.paidOff == true)
        xmlFile:setBool(loanKey .. "#legacyImported", loan.legacyImported == true)
        xmlFile:setBool(loanKey .. "#relationshipCompletionRecorded", loan.relationshipCompletionRecorded == true)
        xmlFile:setInt(loanKey .. "#securityFarmlandId", loan.securityFarmlandId or 0)
        xmlFile:setString(loanKey .. "#securityFarmlandIds", loan.securityFarmlandIds or "")
        xmlFile:setInt(loanKey .. "#securityFarmlandCount", loan.securityFarmlandCount or 0)
        xmlFile:setString(loanKey .. "#releasedSecurityFarmlandIds", loan.releasedSecurityFarmlandIds or "")
        xmlFile:setInt(loanKey .. "#releasedSecurityFarmlandCount", loan.releasedSecurityFarmlandCount or 0)
        xmlFile:setFloat(loanKey .. "#purchasePrice", loan.purchasePrice or 0)
        xmlFile:setFloat(loanKey .. "#depositPaid", loan.depositPaid or 0)
        xmlFile:setFloat(loanKey .. "#lenderValuation", loan.lenderValuation or 0)
        xmlFile:setFloat(loanKey .. "#propertyLtv", loan.propertyLtv or 0)
        xmlFile:setFloat(loanKey .. "#propertyLtvLimit", loan.propertyLtvLimit or 0)
        xmlFile:setInt(loanKey .. "#applicationId", loan.applicationId or 0)
        xmlFile:setString(loanKey .. "#propertyFinanceMode", loan.propertyFinanceMode or "")
        xmlFile:setBool(loanKey .. "#equityRelease", loan.equityRelease == true)
        xmlFile:setBool(loanKey .. "#holdingEquityRelease", loan.holdingEquityRelease == true)
        xmlFile:setFloat(loanKey .. "#equityReleasedAmount", loan.equityReleasedAmount or 0)
        xmlFile:setString(loanKey .. "#lenderId", loan.lenderId or "PRIMARY_BANK")
        xmlFile:setString(loanKey .. "#lenderNameKey", loan.lenderNameKey or "rff_lender_primary_bank")
        xmlFile:setBool(loanKey .. "#brokered", loan.brokered == true)
        xmlFile:setInt(loanKey .. "#brokerCaseId", loan.brokerCaseId or 0)
        xmlFile:setFloat(loanKey .. "#arrangementFee", loan.arrangementFee or 0)
        xmlFile:setFloat(loanKey .. "#brokerFee", loan.brokerFee or 0)
        xmlFile:setBool(loanKey .. "#overdraftSuspended", loan.overdraftSuspended == true)
        xmlFile:setFloat(loanKey .. "#overdraftOverLimit", loan.overdraftOverLimit or 0)
        xmlFile:setInt(loanKey .. "#overdraftLimitBreaches", loan.overdraftLimitBreaches or 0)
        xmlFile:setInt(loanKey .. "#lastOverdraftBreachPeriod", loan.lastOverdraftBreachPeriod or 0)
        xmlFile:setInt(loanKey .. "#overdraftReviewCount", loan.overdraftReviewCount or 0)
        xmlFile:setBool(loanKey .. "#overdraftWarningTwoMonths", loan.overdraftWarningTwoMonths == true)
        xmlFile:setBool(loanKey .. "#overdraftWarningOneMonth", loan.overdraftWarningOneMonth == true)
        xmlFile:setBool(loanKey .. "#recoveryLiability", loan.recoveryLiability == true)
        xmlFile:setString(loanKey .. "#sourceRecoveryType", loan.sourceRecoveryType or "")
        xmlFile:setInt(loanKey .. "#sourceAssetAgreementId", loan.sourceAssetAgreementId or 0)
        xmlFile:setString(loanKey .. "#sourceAssetName", loan.sourceAssetName or "")
        xmlFile:setInt(loanKey .. "#sourceMortgageLoanId", loan.sourceMortgageLoanId or 0)
        xmlFile:setInt(loanKey .. "#sourceFarmlandId", loan.sourceFarmlandId or 0)
        xmlFile:setFloat(loanKey .. "#capitalisedInterest", loan.capitalisedInterest or 0)
        xmlFile:setFloat(loanKey .. "#capitalisedAdminCharges", loan.capitalisedAdminCharges or 0)
        xmlFile:setString(loanKey .. "#recoveryMethod", loan.recoveryMethod or "")
        xmlFile:setFloat(loanKey .. "#recoveryRealisedValue", loan.recoveryRealisedValue or 0)
        xmlFile:setFloat(loanKey .. "#recoveryCosts", loan.recoveryCosts or 0)
        xmlFile:setInt(loanKey .. "#mortgageRestructureCount", loan.mortgageRestructureCount or 0)
        xmlFile:setInt(loanKey .. "#mortgageLastRestructurePeriod", loan.mortgageLastRestructurePeriod or 0)
        xmlFile:setFloat(loanKey .. "#mortgageCapitalisedArrears", loan.mortgageCapitalisedArrears or 0)
        xmlFile:setFloat(loanKey .. "#mortgageRateBeforeRestructure", loan.mortgageRateBeforeRestructure or 0)
        xmlFile:setFloat(loanKey .. "#mortgagePaymentBeforeRestructure", loan.mortgagePaymentBeforeRestructure or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveryEligiblePeriod", loan.mortgageRecoveryEligiblePeriod or 0)
        xmlFile:setBool(loanKey .. "#mortgageRecoveryPending", loan.mortgageRecoveryPending == true)
        xmlFile:setBool(loanKey .. "#mortgageRecovered", loan.mortgageRecovered == true)
        xmlFile:setInt(loanKey .. "#mortgageRecoveredPeriod", loan.mortgageRecoveredPeriod or 0)
        xmlFile:setString(loanKey .. "#mortgageRecoveryMethod", loan.mortgageRecoveryMethod or "")
        xmlFile:setFloat(loanKey .. "#mortgageMarketValue", loan.mortgageMarketValue or 0)
        xmlFile:setFloat(loanKey .. "#mortgageRealisedValue", loan.mortgageRealisedValue or 0)
        xmlFile:setFloat(loanKey .. "#mortgageRecoveryCosts", loan.mortgageRecoveryCosts or 0)
        xmlFile:setFloat(loanKey .. "#mortgageDebtAtRecovery", loan.mortgageDebtAtRecovery or 0)
        xmlFile:setFloat(loanKey .. "#mortgageRecoveryShortfall", loan.mortgageRecoveryShortfall or 0)
        xmlFile:setFloat(loanKey .. "#mortgageRecoverySurplus", loan.mortgageRecoverySurplus or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveredFixtureCount", loan.mortgageRecoveredFixtureCount or 0)
        xmlFile:setFloat(loanKey .. "#mortgageRecoveredFixtureMarketValue", loan.mortgageRecoveredFixtureMarketValue or 0)
        xmlFile:setFloat(loanKey .. "#mortgageRecoveredFixtureRealisedValue", loan.mortgageRecoveredFixtureRealisedValue or 0)
        xmlFile:setInt(loanKey .. "#mortgageForcedLivestockCount", loan.mortgageForcedLivestockCount or 0)
        xmlFile:setFloat(loanKey .. "#mortgageForcedLivestockMarketValue", loan.mortgageForcedLivestockMarketValue or 0)
        xmlFile:setFloat(loanKey .. "#mortgageForcedLivestockProceeds", loan.mortgageForcedLivestockProceeds or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveryPlaceablesDeleted", loan.mortgageRecoveryPlaceablesDeleted or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveryPlaceablesTransferred", loan.mortgageRecoveryPlaceablesTransferred or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveryPlaceablesPromotedToFarmland", loan.mortgageRecoveryPlaceablesPromotedToFarmland or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveryPlaceableFailures", loan.mortgageRecoveryPlaceableFailures or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveryAnimalClusterFailures", loan.mortgageRecoveryAnimalClusterFailures or 0)
        xmlFile:setInt(loanKey .. "#mortgageRecoveryLiabilityLoanId", loan.mortgageRecoveryLiabilityLoanId or 0)
        xmlFile:setString(loanKey .. "#mortgageRecoveredFarmlandIds", loan.mortgageRecoveredFarmlandIds or "")
        xmlFile:setInt(loanKey .. "#mortgageRecoveredFarmlandCount", loan.mortgageRecoveredFarmlandCount or 0)
        xmlFile:setBool(loanKey .. "#refinanced", loan.refinanced == true)
        xmlFile:setInt(loanKey .. "#refinancedPeriod", loan.refinancedPeriod or 0)
        xmlFile:setInt(loanKey .. "#refinancedByLoanId", loan.refinancedByLoanId or 0)
        xmlFile:setBool(loanKey .. "#refinance", loan.refinance == true)
        xmlFile:setBool(loanKey .. "#consolidation", loan.consolidation == true)
        xmlFile:setString(loanKey .. "#refinanceSourceLoanIds", loan.refinanceSourceLoanIds or "")
        xmlFile:setInt(loanKey .. "#refinanceSourceCount", loan.refinanceSourceCount or 0)
        xmlFile:setFloat(loanKey .. "#refinanceSettlementAmount", loan.refinanceSettlementAmount or 0)
        xmlFile:setFloat(loanKey .. "#refinancePreviousDebtService", loan.refinancePreviousDebtService or 0)
        xmlFile:setFloat(loanKey .. "#refinancePreviousProjectedInterest", loan.refinancePreviousProjectedInterest or 0)
        xmlFile:setString(loanKey .. "#refinanceMarketState", loan.refinanceMarketState or "")
        xmlFile:setString(loanKey .. "#refinanceDealFit", loan.refinanceDealFit or "")
        xmlFile:setString(loanKey .. "#refinanceRelationshipTier", loan.refinanceRelationshipTier or "")
        xmlFile:setInt(loanKey .. "#forbearanceCount", loan.forbearanceCount or 0)
        xmlFile:setInt(loanKey .. "#forbearanceLastPeriod", loan.forbearanceLastPeriod or 0)
        xmlFile:setString(loanKey .. "#forbearanceLastType", loan.forbearanceLastType or "")
        xmlFile:setString(loanKey .. "#forbearanceMode", loan.forbearanceMode or "")
        xmlFile:setInt(loanKey .. "#forbearanceRemainingPeriods", loan.forbearanceRemainingPeriods or 0)
        xmlFile:setFloat(loanKey .. "#forbearanceCapitalisedArrears", loan.forbearanceCapitalisedArrears or 0)
        xmlFile:setFloat(loanKey .. "#forbearanceCapitalisedInterest", loan.forbearanceCapitalisedInterest or 0)
        xmlFile:setFloat(loanKey .. "#forbearanceOriginalPayment", loan.forbearanceOriginalPayment or 0)
        xmlFile:setFloat(loanKey .. "#forbearanceOriginalRate", loan.forbearanceOriginalRate or 0)
        xmlFile:setBool(loanKey .. "#forbearanceBroken", loan.forbearanceBroken == true)
        xmlFile:setString(loanKey .. "#forbearanceOfferStatus", loan.forbearanceOfferStatus or "")
        xmlFile:setString(loanKey .. "#forbearanceOfferType", loan.forbearanceOfferType or "")
        xmlFile:setInt(loanKey .. "#forbearanceOfferCreatedPeriod", loan.forbearanceOfferCreatedPeriod or 0)
        xmlFile:setInt(loanKey .. "#forbearanceOfferExpiryPeriod", loan.forbearanceOfferExpiryPeriod or 0)
        xmlFile:setInt(loanKey .. "#forbearanceOfferLastPeriod", loan.forbearanceOfferLastPeriod or 0)
        xmlFile:setBool(loanKey .. "#rescueRefinanced", loan.rescueRefinanced == true)
        xmlFile:setInt(loanKey .. "#rescueRefinancedPeriod", loan.rescueRefinancedPeriod or 0)
        xmlFile:setInt(loanKey .. "#rescueRefinancedByLoanId", loan.rescueRefinancedByLoanId or 0)
        xmlFile:setFloat(loanKey .. "#rescueSettlementAmount", loan.rescueSettlementAmount or 0)
        xmlFile:setBool(loanKey .. "#rescueFinance", loan.rescueFinance == true)
        xmlFile:setInt(loanKey .. "#rescueSourceLoanId", loan.rescueSourceLoanId or 0)
        xmlFile:setFloat(loanKey .. "#rescuePreviousPayment", loan.rescuePreviousPayment or 0)
        xmlFile:setString(loanKey .. "#rescuePreviousLenderId", loan.rescuePreviousLenderId or "")
        xmlFile:setString(loanKey .. "#rescueMarketState", loan.rescueMarketState or "")
        xmlFile:setString(loanKey .. "#rescueDealFit", loan.rescueDealFit or "")
        xmlFile:setString(loanKey .. "#rescueRelationshipTier", loan.rescueRelationshipTier or "")
    end

    for index, agreement in ipairs(self.assetFinance or {}) do
        local assetKey = string.format("realisticFarmFinance.assetFinance(%d)", index - 1)
        xmlFile:setInt(assetKey .. "#id", agreement.id or index)
        xmlFile:setInt(assetKey .. "#farmId", agreement.farmId or 0)
        xmlFile:setString(assetKey .. "#product", agreement.product or "HIRE_PURCHASE")
        xmlFile:setString(assetKey .. "#vehicleUniqueId", agreement.vehicleUniqueId or "")
        xmlFile:setString(assetKey .. "#vehicleName", agreement.vehicleName or "Financed asset")
        xmlFile:setString(assetKey .. "#storeItemXml", agreement.storeItemXml or "")
        xmlFile:setFloat(assetKey .. "#basePrice", agreement.basePrice or 0)
        xmlFile:setFloat(assetKey .. "#depositPercent", agreement.depositPercent or 0)
        xmlFile:setFloat(assetKey .. "#depositPaid", agreement.depositPaid or 0)
        xmlFile:setFloat(assetKey .. "#refundableDeposit", agreement.refundableDeposit or 0)
        xmlFile:setFloat(assetKey .. "#originalFinanced", agreement.originalFinanced or 0)
        xmlFile:setFloat(assetKey .. "#principal", agreement.principal or 0)
        xmlFile:setFloat(assetKey .. "#balloonAmount", agreement.balloonAmount or 0)
        xmlFile:setFloat(assetKey .. "#residualValue", agreement.residualValue or 0)
        xmlFile:setFloat(assetKey .. "#interestRate", agreement.interestRate or 0)
        xmlFile:setInt(assetKey .. "#termMonths", agreement.termMonths or 0)
        xmlFile:setInt(assetKey .. "#remainingMonths", agreement.remainingMonths or 0)
        xmlFile:setFloat(assetKey .. "#monthlyPayment", agreement.monthlyPayment or 0)
        xmlFile:setString(assetKey .. "#riskGrade", agreement.riskGrade or "C")
        xmlFile:setString(assetKey .. "#lenderId", agreement.lenderId or "")
        xmlFile:setString(assetKey .. "#lenderNameKey", agreement.lenderNameKey or "")
        xmlFile:setString(assetKey .. "#lenderMarketState", agreement.lenderMarketState or "SELECTIVE")
        xmlFile:setString(assetKey .. "#lenderDealFit", agreement.lenderDealFit or "STANDARD")
        xmlFile:setBool(assetKey .. "#lenderAssignmentLegacy", agreement.lenderAssignmentLegacy == true)
        xmlFile:setBool(assetKey .. "#relationshipDealRecorded", agreement.relationshipDealRecorded == true)
        xmlFile:setBool(assetKey .. "#relationshipCompletionRecorded", agreement.relationshipCompletionRecorded == true)
        xmlFile:setBool(assetKey .. "#relationshipRecoveryRecorded", agreement.relationshipRecoveryRecorded == true)
        xmlFile:setInt(assetKey .. "#createdPeriod", agreement.createdPeriod or 0)
        xmlFile:setInt(assetKey .. "#lastPaymentPeriod", agreement.lastPaymentPeriod or 0)
        xmlFile:setInt(assetKey .. "#paymentsMade", agreement.paymentsMade or 0)
        xmlFile:setInt(assetKey .. "#missedPayments", agreement.missedPayments or 0)
        xmlFile:setFloat(assetKey .. "#arrearsPrincipal", agreement.arrearsPrincipal or 0)
        xmlFile:setFloat(assetKey .. "#arrearsInterest", agreement.arrearsInterest or 0)
        xmlFile:setFloat(assetKey .. "#arrearsRent", agreement.arrearsRent or 0)
        xmlFile:setFloat(assetKey .. "#arrearsFees", agreement.arrearsFees or 0)
        xmlFile:setFloat(assetKey .. "#arrearsBalance", agreement.arrearsBalance or 0)
        xmlFile:setInt(assetKey .. "#arrearsAgeMonths", agreement.arrearsAgeMonths or 0)
        xmlFile:setString(assetKey .. "#arrearsStage", agreement.arrearsStage or "CURRENT")
        xmlFile:setFloat(assetKey .. "#defaultInterestAccrued", agreement.defaultInterestAccrued or 0)
        xmlFile:setFloat(assetKey .. "#adminChargesAccrued", agreement.adminChargesAccrued or 0)
        xmlFile:setInt(assetKey .. "#defaultEvents", agreement.defaultEvents or 0)
        xmlFile:setBool(assetKey .. "#currentDefault", agreement.currentDefault == true)
        xmlFile:setBool(assetKey .. "#defaultRecorded", agreement.defaultRecorded == true)
        xmlFile:setBool(assetKey .. "#recoveryEligible", agreement.recoveryEligible == true)
        xmlFile:setInt(assetKey .. "#lastDefaultManagementPeriod", agreement.lastDefaultManagementPeriod or 0)
        xmlFile:setInt(assetKey .. "#consecutiveMissedPayments", agreement.consecutiveMissedPayments or 0)
        xmlFile:setInt(assetKey .. "#maxConsecutiveMissedPayments", agreement.maxConsecutiveMissedPayments or 0)
        xmlFile:setInt(assetKey .. "#lastMissedPeriod", agreement.lastMissedPeriod or 0)
        xmlFile:setInt(assetKey .. "#lastSuccessfulPaymentPeriod", agreement.lastSuccessfulPaymentPeriod or 0)
        xmlFile:setInt(assetKey .. "#lastArrearsClearedPeriod", agreement.lastArrearsClearedPeriod or 0)
        xmlFile:setInt(assetKey .. "#arrearsSchemaVersion", 1)
        xmlFile:setFloat(assetKey .. "#principalPaid", agreement.principalPaid or 0)
        xmlFile:setFloat(assetKey .. "#interestPaid", agreement.interestPaid or 0)
        xmlFile:setFloat(assetKey .. "#leaseRentPaid", agreement.leaseRentPaid or 0)
        xmlFile:setInt(assetKey .. "#completedPeriod", agreement.completedPeriod or 0)
        xmlFile:setString(assetKey .. "#status", agreement.status or "ACTIVE")
        xmlFile:setBool(assetKey .. "#titleRetained", agreement.titleRetained == true)
        xmlFile:setBool(assetKey .. "#returnDue", agreement.returnDue == true)
        xmlFile:setBool(assetKey .. "#returned", agreement.returned == true)
        xmlFile:setBool(assetKey .. "#leaseWarningTwoMonths", agreement.leaseWarningTwoMonths == true)
        xmlFile:setBool(assetKey .. "#leaseWarningOneMonth", agreement.leaseWarningOneMonth == true)
        xmlFile:setInt(assetKey .. "#returnedPeriod", agreement.returnedPeriod or 0)
        xmlFile:setFloat(assetKey .. "#returnRepairCost", agreement.returnRepairCost or 0)
        xmlFile:setFloat(assetKey .. "#returnMaintenancePenalty", agreement.returnMaintenancePenalty or 0)
        xmlFile:setFloat(assetKey .. "#returnWashingCost", agreement.returnWashingCost or 0)
        xmlFile:setFloat(assetKey .. "#returnEarlyTerminationCharge", agreement.returnEarlyTerminationCharge or 0)
        xmlFile:setBool(assetKey .. "#returnEarlyTerminated", agreement.returnEarlyTerminated == true)
        xmlFile:setInt(assetKey .. "#returnRemainingMonths", agreement.returnRemainingMonths or 0)
        xmlFile:setFloat(assetKey .. "#returnFutureRent", agreement.returnFutureRent or 0)
        xmlFile:setFloat(assetKey .. "#returnArrearsApplied", agreement.returnArrearsApplied or 0)
        xmlFile:setFloat(assetKey .. "#returnDeductions", agreement.returnDeductions or 0)
        xmlFile:setFloat(assetKey .. "#returnDepositRefund", agreement.returnDepositRefund or 0)
        xmlFile:setFloat(assetKey .. "#returnAdditionalCharge", agreement.returnAdditionalCharge or 0)
        xmlFile:setFloat(assetKey .. "#returnDamage", agreement.returnDamage or 0)
        xmlFile:setFloat(assetKey .. "#returnDirt", agreement.returnDirt or 0)
        xmlFile:setBool(assetKey .. "#returnAdsApplied", agreement.returnAdsApplied == true)
        xmlFile:setFloat(assetKey .. "#returnAdsCondition", agreement.returnAdsCondition or 0)
        xmlFile:setFloat(assetKey .. "#returnAdsServiceLevel", agreement.returnAdsServiceLevel or 0)
        xmlFile:setInt(assetKey .. "#returnAdsBreakdownCount", agreement.returnAdsBreakdownCount or 0)
        xmlFile:setInt(assetKey .. "#recoveryEligiblePeriod", agreement.recoveryEligiblePeriod or 0)
        xmlFile:setBool(assetKey .. "#recoveryPending", agreement.recoveryPending == true)
        xmlFile:setInt(assetKey .. "#lastRecoveryBlockedPeriod", agreement.lastRecoveryBlockedPeriod or 0)
        xmlFile:setBool(assetKey .. "#recovered", agreement.recovered == true)
        xmlFile:setInt(assetKey .. "#recoveredPeriod", agreement.recoveredPeriod or 0)
        xmlFile:setString(assetKey .. "#recoveryMethod", agreement.recoveryMethod or "")
        xmlFile:setFloat(assetKey .. "#recoveryMarketValue", agreement.recoveryMarketValue or 0)
        xmlFile:setFloat(assetKey .. "#recoveryAdjustedMarketValue", agreement.recoveryAdjustedMarketValue or 0)
        xmlFile:setFloat(assetKey .. "#recoveryTechnicalAdjustment", agreement.recoveryTechnicalAdjustment or 0)
        xmlFile:setFloat(assetKey .. "#recoveryRealisedValue", agreement.recoveryRealisedValue or 0)
        xmlFile:setFloat(assetKey .. "#recoveryCosts", agreement.recoveryCosts or 0)
        xmlFile:setFloat(assetKey .. "#recoveryDebtAtRecovery", agreement.recoveryDebtAtRecovery or 0)
        xmlFile:setFloat(assetKey .. "#recoveryDepositApplied", agreement.recoveryDepositApplied or 0)
        xmlFile:setFloat(assetKey .. "#recoveryShortfall", agreement.recoveryShortfall or 0)
        xmlFile:setFloat(assetKey .. "#recoverySurplus", agreement.recoverySurplus or 0)
        xmlFile:setInt(assetKey .. "#recoveryLiabilityLoanId", agreement.recoveryLiabilityLoanId or 0)
        xmlFile:setBool(assetKey .. "#recoveryAdsApplied", agreement.recoveryAdsApplied == true)
        xmlFile:setFloat(assetKey .. "#recoveryAdsCondition", agreement.recoveryAdsCondition or 0)
        xmlFile:setFloat(assetKey .. "#recoveryAdsServiceLevel", agreement.recoveryAdsServiceLevel or 0)
        xmlFile:setInt(assetKey .. "#recoveryAdsBreakdownCount", agreement.recoveryAdsBreakdownCount or 0)
        xmlFile:setFloat(assetKey .. "#recoveryAdsRepairCost", agreement.recoveryAdsRepairCost or 0)
        xmlFile:setFloat(assetKey .. "#recoveryAdsMaintenancePenalty", agreement.recoveryAdsMaintenancePenalty or 0)
    end

    for index, tenancy in ipairs(self.tenancies or {}) do
        local tenancyKey = string.format("realisticFarmFinance.tenancy(%d)", index - 1)
        xmlFile:setInt(tenancyKey .. "#id", tenancy.id or index)
        xmlFile:setInt(tenancyKey .. "#farmId", tenancy.farmId or 0)
        xmlFile:setInt(tenancyKey .. "#farmlandId", tenancy.farmlandId or 0)
        local farmlandIdsText = ""
        for i, farmlandId in ipairs(tenancy.farmlandIds or {tenancy.farmlandId}) do farmlandIdsText = farmlandIdsText .. (i > 1 and "," or "") .. tostring(farmlandId or 0) end
        xmlFile:setString(tenancyKey .. "#agreementId", tenancy.agreementId or string.format("RFF-T-%06d", tenancy.id or index))
        xmlFile:setString(tenancyKey .. "#farmlandIds", farmlandIdsText)
        xmlFile:setString(tenancyKey .. "#landlord", tenancy.landlord or "PRIVATE_LANDOWNER")
        xmlFile:setString(tenancyKey .. "#holdingName", tenancy.holdingName or "")
        xmlFile:setFloat(tenancyKey .. "#purchasePrice", tenancy.purchasePrice or 0)
        xmlFile:setFloat(tenancyKey .. "#securityDeposit", tenancy.securityDeposit or 0)
        xmlFile:setFloat(tenancyKey .. "#depositOriginal", tenancy.depositOriginal or tenancy.securityDeposit or 0)
        xmlFile:setFloat(tenancyKey .. "#depositHeld", tenancy.depositHeld or tenancy.securityDeposit or 0)
        xmlFile:setFloat(tenancyKey .. "#monthlyRent", tenancy.monthlyRent or 0)
        xmlFile:setFloat(tenancyKey .. "#annualRent", tenancy.annualRent or (tenancy.monthlyRent or 0) * 12)
        xmlFile:setString(tenancyKey .. "#paymentFrequency", tenancy.paymentFrequency or "MONTHLY")
        xmlFile:setInt(tenancyKey .. "#paymentIntervalMonths", tenancy.paymentIntervalMonths or 1)
        xmlFile:setInt(tenancyKey .. "#termMonths", tenancy.termMonths or 0)
        xmlFile:setInt(tenancyKey .. "#remainingMonths", tenancy.remainingMonths or 0)
        xmlFile:setInt(tenancyKey .. "#createdPeriod", tenancy.createdPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#commencementPeriod", tenancy.commencementPeriod or tenancy.createdPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#contractualEndPeriod", tenancy.contractualEndPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#nextRentDuePeriod", tenancy.nextRentDuePeriod or 0)
        xmlFile:setInt(tenancyKey .. "#lastPaymentPeriod", tenancy.lastPaymentPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#paymentsMade", tenancy.paymentsMade or 0)
        xmlFile:setInt(tenancyKey .. "#missedPayments", tenancy.missedPayments or 0)
        xmlFile:setFloat(tenancyKey .. "#rentCharged", tenancy.rentCharged or 0)
        xmlFile:setFloat(tenancyKey .. "#rentPaid", tenancy.rentPaid or 0)
        xmlFile:setFloat(tenancyKey .. "#rentDue", tenancy.rentDue or 0)
        xmlFile:setFloat(tenancyKey .. "#arrears", tenancy.arrears or 0)
        xmlFile:setString(tenancyKey .. "#status", tenancy.status or "ACTIVE")
        xmlFile:setString(tenancyKey .. "#applicationReference", tenancy.applicationReference or "")
        xmlFile:setString(tenancyKey .. "#applicationStage", tenancy.applicationStage or "")
        xmlFile:setInt(tenancyKey .. "#applicationSubmittedDay", tenancy.applicationSubmittedDay or 0)
        xmlFile:setInt(tenancyKey .. "#applicationNextActionDay", tenancy.applicationNextActionDay or 0)
        xmlFile:setInt(tenancyKey .. "#applicationRequestedTermMonths", tenancy.applicationRequestedTermMonths or 0)
        xmlFile:setInt(tenancyKey .. "#applicationCreditScore", tenancy.applicationCreditScore or 0)
        xmlFile:setString(tenancyKey .. "#applicationCreditBand", tenancy.applicationCreditBand or "")
        xmlFile:setString(tenancyKey .. "#applicationCreditConduct", tenancy.applicationCreditConduct or "")
        xmlFile:setString(tenancyKey .. "#applicationCreditAffordability", tenancy.applicationCreditAffordability or "")
        xmlFile:setFloat(tenancyKey .. "#applicationMonthlyIncome", tenancy.applicationMonthlyIncome or 0)
        xmlFile:setFloat(tenancyKey .. "#applicationExistingCommitments", tenancy.applicationExistingCommitments or 0)
        xmlFile:setInt(tenancyKey .. "#applicationDepositMonths", tenancy.applicationDepositMonths or 0)
        xmlFile:setFloat(tenancyKey .. "#applicationLegalFee", tenancy.applicationLegalFee or 0)
        xmlFile:setFloat(tenancyKey .. "#applicationUpfrontCashRequired", tenancy.applicationUpfrontCashRequired or 0)
        xmlFile:setString(tenancyKey .. "#applicationDecision", tenancy.applicationDecision or "")
        xmlFile:setString(tenancyKey .. "#applicationDecisionReason", tenancy.applicationDecisionReason or "")
        xmlFile:setBool(tenancyKey .. "#applicationLandlordIntroduced", tenancy.applicationLandlordIntroduced == true)
        xmlFile:setBool(tenancyKey .. "#depositForfeited", tenancy.depositForfeited == true)
        xmlFile:setInt(tenancyKey .. "#rentReviewIntervalMonths", tenancy.rentReviewIntervalMonths or 0)
        xmlFile:setInt(tenancyKey .. "#nextRentReviewPeriod", tenancy.nextRentReviewPeriod or 0)
        xmlFile:setBool(tenancyKey .. "#breakEnabled", tenancy.breakEnabled == true)
        xmlFile:setInt(tenancyKey .. "#earliestBreakPeriod", tenancy.earliestBreakPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#breakNoticeMonths", tenancy.breakNoticeMonths or 0)
        xmlFile:setString(tenancyKey .. "#permittedEnterprise", tenancy.permittedEnterprise or "MIXED")
        xmlFile:setBool(tenancyKey .. "#agriculturalUsePermitted", tenancy.agriculturalUsePermitted ~= false)
        xmlFile:setBool(tenancyKey .. "#permanentGrassRestriction", tenancy.permanentGrassRestriction == true)
        xmlFile:setBool(tenancyKey .. "#boundaryRemovalRequiresConsent", tenancy.boundaryRemovalRequiresConsent ~= false)
        xmlFile:setBool(tenancyKey .. "#improvementsRequireConsent", tenancy.improvementsRequireConsent ~= false)
        xmlFile:setBool(tenancyKey .. "#tenantMaintenanceObligation", tenancy.tenantMaintenanceObligation ~= false)
        xmlFile:setInt(tenancyKey .. "#landlordVariationNoticeMonths", tenancy.landlordVariationNoticeMonths or 3)
        xmlFile:setInt(tenancyKey .. "#landlordVariationCooldownMonths", tenancy.landlordVariationCooldownMonths or 12)
        xmlFile:setBool(tenancyKey .. "#settlementCompleted", tenancy.settlementCompleted == true)
        xmlFile:setFloat(tenancyKey .. "#settlementDepositApplied", tenancy.settlementDepositApplied or 0)
        xmlFile:setFloat(tenancyKey .. "#settlementDepositReturned", tenancy.settlementDepositReturned or 0)
        xmlFile:setFloat(tenancyKey .. "#settlementCovenantCosts", tenancy.settlementCovenantCosts or 0)
        xmlFile:setFloat(tenancyKey .. "#settlementCovenantCostsApplied", tenancy.settlementCovenantCostsApplied or 0)
        xmlFile:setFloat(tenancyKey .. "#settlementDilapidationCosts", tenancy.settlementDilapidationCosts or 0)
        xmlFile:setFloat(tenancyKey .. "#settlementDilapidationCostsApplied", tenancy.settlementDilapidationCostsApplied or 0)
        xmlFile:setFloat(tenancyKey .. "#settlementFinalBalance", tenancy.settlementFinalBalance or 0)
        xmlFile:setBool(tenancyKey .. "#forfeitureProcessed", tenancy.forfeitureProcessed == true)
        xmlFile:setInt(tenancyKey .. "#forfeiturePeriod", tenancy.forfeiturePeriod or 0)
        xmlFile:setInt(tenancyKey .. "#forfeitedPlaceableCount", tenancy.forfeitedPlaceableCount or 0)
        xmlFile:setFloat(tenancyKey .. "#forfeitedPlaceableValue", tenancy.forfeitedPlaceableValue or 0)
        xmlFile:setBool(tenancyKey .. "#expiryWarning12Sent", tenancy.expiryWarning12Sent == true)
        xmlFile:setBool(tenancyKey .. "#expiryWarning3Sent", tenancy.expiryWarning3Sent == true)
        xmlFile:setBool(tenancyKey .. "#expiryWarning1Sent", tenancy.expiryWarning1Sent == true)
        xmlFile:setBool(tenancyKey .. "#expiryNotificationSent", tenancy.expiryNotificationSent == true)
        xmlFile:setInt(tenancyKey .. "#lastArrearsNotificationPeriod", tenancy.lastArrearsNotificationPeriod or 0)
        xmlFile:setString(tenancyKey .. "#renewalOfferStatus", tenancy.renewalOfferStatus or "NONE")
        xmlFile:setInt(tenancyKey .. "#renewalOfferCreatedPeriod", tenancy.renewalOfferCreatedPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#renewalOfferExpiryPeriod", tenancy.renewalOfferExpiryPeriod or 0)
        xmlFile:setFloat(tenancyKey .. "#renewalOfferAnnualRent", tenancy.renewalOfferAnnualRent or 0)
        xmlFile:setInt(tenancyKey .. "#renewalOfferTermMonths", tenancy.renewalOfferTermMonths or 0)
        xmlFile:setString(tenancyKey .. "#renewalOfferPaymentFrequency", tenancy.renewalOfferPaymentFrequency or "")
        xmlFile:setInt(tenancyKey .. "#successorAgreementId", tenancy.successorAgreementId or 0)
        xmlFile:setInt(tenancyKey .. "#predecessorAgreementId", tenancy.predecessorAgreementId or 0)
        xmlFile:setInt(tenancyKey .. "#noticeServedPeriod", tenancy.noticeServedPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#noticeEffectivePeriod", tenancy.noticeEffectivePeriod or 0)
        xmlFile:setString(tenancyKey .. "#noticeReason", tenancy.noticeReason or "")
        xmlFile:setInt(tenancyKey .. "#breakExercisedPeriod", tenancy.breakExercisedPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#lastRentReviewPeriod", tenancy.lastRentReviewPeriod or 0)
        xmlFile:setFloat(tenancyKey .. "#previousAnnualRent", tenancy.previousAnnualRent or 0)
        xmlFile:setFloat(tenancyKey .. "#settlementDepositTransferred", tenancy.settlementDepositTransferred or 0)
        xmlFile:setBool(tenancyKey .. "#commencementNotificationSent", tenancy.commencementNotificationSent == true)
        xmlFile:setFloat(tenancyKey .. "#renewalOriginalAnnualRent", tenancy.renewalOriginalAnnualRent or 0)
        xmlFile:setString(tenancyKey .. "#renewalNegotiationStatus", tenancy.renewalNegotiationStatus or "NOT_STARTED")
        xmlFile:setInt(tenancyKey .. "#renewalNegotiationPeriod", tenancy.renewalNegotiationPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#renewalNegotiationAttempts", tenancy.renewalNegotiationAttempts or 0)
        xmlFile:setFloat(tenancyKey .. "#renewalNegotiatedAnnualRent", tenancy.renewalNegotiatedAnnualRent or 0)
        xmlFile:setInt(tenancyKey .. "#renewalNegotiationNextDay", tenancy.renewalNegotiationNextDay or 0)
        xmlFile:setInt(tenancyKey .. "#renewalNegotiationLastUpdateDay", tenancy.renewalNegotiationLastUpdateDay or 0)
        xmlFile:setFloat(tenancyKey .. "#renewalTenantProposalRent", tenancy.renewalTenantProposalRent or 0)
        xmlFile:setFloat(tenancyKey .. "#renewalLandlordCounterRent", tenancy.renewalLandlordCounterRent or 0)
        xmlFile:setString(tenancyKey .. "#renewalLegalReference", tenancy.renewalLegalReference or "")
        xmlFile:setString(tenancyKey .. "#renewalDocumentStatus", tenancy.renewalDocumentStatus or "NONE")
        xmlFile:setInt(tenancyKey .. "#renewalCovenantPackageVersion", tenancy.renewalCovenantPackageVersion or 0)
        xmlFile:setString(tenancyKey .. "#renewalOriginalPermittedEnterprise", tenancy.renewalOriginalPermittedEnterprise or "")
        xmlFile:setBool(tenancyKey .. "#renewalOriginalPermanentGrassRestriction", tenancy.renewalOriginalPermanentGrassRestriction == true)
        xmlFile:setBool(tenancyKey .. "#renewalOriginalBoundaryRemovalRequiresConsent", tenancy.renewalOriginalBoundaryRemovalRequiresConsent == true)
        xmlFile:setBool(tenancyKey .. "#renewalOriginalImprovementsRequireConsent", tenancy.renewalOriginalImprovementsRequireConsent == true)
        xmlFile:setBool(tenancyKey .. "#renewalOriginalTenantMaintenanceObligation", tenancy.renewalOriginalTenantMaintenanceObligation == true)
        xmlFile:setInt(tenancyKey .. "#renewalOriginalRentReviewIntervalMonths", tenancy.renewalOriginalRentReviewIntervalMonths or 0)
        xmlFile:setBool(tenancyKey .. "#renewalOriginalBreakEnabled", tenancy.renewalOriginalBreakEnabled == true)
        xmlFile:setInt(tenancyKey .. "#renewalOriginalBreakNoticeMonths", tenancy.renewalOriginalBreakNoticeMonths or 0)
        xmlFile:setInt(tenancyKey .. "#renewalOriginalLandlordVariationNoticeMonths", tenancy.renewalOriginalLandlordVariationNoticeMonths or 0)
        xmlFile:setInt(tenancyKey .. "#renewalOriginalLandlordVariationCooldownMonths", tenancy.renewalOriginalLandlordVariationCooldownMonths or 0)
        xmlFile:setString(tenancyKey .. "#renewalOfferPermittedEnterprise", tenancy.renewalOfferPermittedEnterprise or "")
        xmlFile:setBool(tenancyKey .. "#renewalOfferPermanentGrassRestriction", tenancy.renewalOfferPermanentGrassRestriction == true)
        xmlFile:setBool(tenancyKey .. "#renewalOfferBoundaryRemovalRequiresConsent", tenancy.renewalOfferBoundaryRemovalRequiresConsent == true)
        xmlFile:setBool(tenancyKey .. "#renewalOfferImprovementsRequireConsent", tenancy.renewalOfferImprovementsRequireConsent == true)
        xmlFile:setBool(tenancyKey .. "#renewalOfferTenantMaintenanceObligation", tenancy.renewalOfferTenantMaintenanceObligation == true)
        xmlFile:setInt(tenancyKey .. "#renewalOfferRentReviewIntervalMonths", tenancy.renewalOfferRentReviewIntervalMonths or 0)
        xmlFile:setBool(tenancyKey .. "#renewalOfferBreakEnabled", tenancy.renewalOfferBreakEnabled == true)
        xmlFile:setInt(tenancyKey .. "#renewalOfferBreakNoticeMonths", tenancy.renewalOfferBreakNoticeMonths or 0)
        xmlFile:setInt(tenancyKey .. "#renewalOfferLandlordVariationNoticeMonths", tenancy.renewalOfferLandlordVariationNoticeMonths or 0)
        xmlFile:setInt(tenancyKey .. "#renewalOfferLandlordVariationCooldownMonths", tenancy.renewalOfferLandlordVariationCooldownMonths or 0)
        xmlFile:setString(tenancyKey .. "#renewalTenantPermittedEnterprise", tenancy.renewalTenantPermittedEnterprise or "")
        xmlFile:setBool(tenancyKey .. "#renewalTenantPermanentGrassRestriction", tenancy.renewalTenantPermanentGrassRestriction == true)
        xmlFile:setBool(tenancyKey .. "#renewalTenantBoundaryRemovalRequiresConsent", tenancy.renewalTenantBoundaryRemovalRequiresConsent == true)
        xmlFile:setBool(tenancyKey .. "#renewalTenantImprovementsRequireConsent", tenancy.renewalTenantImprovementsRequireConsent == true)
        xmlFile:setBool(tenancyKey .. "#renewalTenantTenantMaintenanceObligation", tenancy.renewalTenantTenantMaintenanceObligation == true)
        xmlFile:setInt(tenancyKey .. "#renewalTenantRentReviewIntervalMonths", tenancy.renewalTenantRentReviewIntervalMonths or 0)
        xmlFile:setBool(tenancyKey .. "#renewalTenantBreakEnabled", tenancy.renewalTenantBreakEnabled == true)
        xmlFile:setInt(tenancyKey .. "#renewalTenantBreakNoticeMonths", tenancy.renewalTenantBreakNoticeMonths or 0)
        xmlFile:setInt(tenancyKey .. "#renewalTenantLandlordVariationNoticeMonths", tenancy.renewalTenantLandlordVariationNoticeMonths or 0)
        xmlFile:setInt(tenancyKey .. "#renewalTenantLandlordVariationCooldownMonths", tenancy.renewalTenantLandlordVariationCooldownMonths or 0)
        xmlFile:setFloat(tenancyKey .. "#landlordRelationshipPoints", tenancy.landlordRelationshipPoints or 0)
        xmlFile:setBool(tenancyKey .. "#landlordRelationshipInitialized", tenancy.landlordRelationshipInitialized == true)
        xmlFile:setString(tenancyKey .. "#landlordRelationshipLastReason", tenancy.landlordRelationshipLastReason or "")
        xmlFile:setInt(tenancyKey .. "#landlordNegotiationRejections", tenancy.landlordNegotiationRejections or 0)
        xmlFile:setInt(tenancyKey .. "#consentNextId", tenancy.consentNextId or 1)
        xmlFile:setInt(tenancyKey .. "#consentLatestId", tenancy.consentLatestId or 0)
        xmlFile:setString(tenancyKey .. "#covenantComplianceStatus", tenancy.covenantComplianceStatus or "COMPLIANT")
        xmlFile:setInt(tenancyKey .. "#landlordVariationCount", tenancy.landlordVariationCount or 0)
        xmlFile:setInt(tenancyKey .. "#lastLandlordVariationPeriod", tenancy.lastLandlordVariationPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#nextLandlordVariationPeriod", tenancy.nextLandlordVariationPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#npcVoiceSchemaVersion", tenancy.npcVoiceSchemaVersion or 0)
        xmlFile:setInt(tenancyKey .. "#npcVoiceSeed", tenancy.npcVoiceSeed or 0)
        xmlFile:setString(tenancyKey .. "#npcVoiceId", tenancy.npcVoiceId or "")
        xmlFile:setString(tenancyKey .. "#npcCommunicationStyle", tenancy.npcCommunicationStyle or "")
        xmlFile:setFloat(tenancyKey .. "#npcFormality", tenancy.npcFormality or 0)
        xmlFile:setFloat(tenancyKey .. "#npcWarmth", tenancy.npcWarmth or 0)
        xmlFile:setFloat(tenancyKey .. "#npcVerbosity", tenancy.npcVerbosity or 0)
        xmlFile:setFloat(tenancyKey .. "#npcPatience", tenancy.npcPatience or 0)
        xmlFile:setFloat(tenancyKey .. "#npcDirectness", tenancy.npcDirectness or 0)
        xmlFile:setFloat(tenancyKey .. "#npcConservatism", tenancy.npcConservatism or 0)
        xmlFile:setFloat(tenancyKey .. "#npcRelationshipWeight", tenancy.npcRelationshipWeight or 0)
        xmlFile:setInt(tenancyKey .. "#narrativeNextEventId", tenancy.narrativeNextEventId or 1)
        xmlFile:setInt(tenancyKey .. "#narrativeLatestEventId", tenancy.narrativeLatestEventId or 0)
        xmlFile:setString(tenancyKey .. "#narrativeLatestEventType", tenancy.narrativeLatestEventType or "")
        xmlFile:setString(tenancyKey .. "#narrativeLatestText", tenancy.narrativeLatestText or "")
        xmlFile:setInt(tenancyKey .. "#conditionSurveyVersion", tenancy.conditionSurveyVersion or 0)
        xmlFile:setInt(tenancyKey .. "#conditionSurveyPeriod", tenancy.conditionSurveyPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#conditionLastObservedPeriod", tenancy.conditionLastObservedPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#alterationNextId", tenancy.alterationNextId or 1)
        xmlFile:setInt(tenancyKey .. "#alterationLatestId", tenancy.alterationLatestId or 0)
        xmlFile:setInt(tenancyKey .. "#inspectionSchemaVersion", tenancy.inspectionSchemaVersion or 0)
        xmlFile:setInt(tenancyKey .. "#inspectionNextId", tenancy.inspectionNextId or 1)
        xmlFile:setInt(tenancyKey .. "#inspectionLatestId", tenancy.inspectionLatestId or 0)
        xmlFile:setInt(tenancyKey .. "#lastInspectionPeriod", tenancy.lastInspectionPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#nextInspectionPeriod", tenancy.nextInspectionPeriod or 0)
        xmlFile:setString(tenancyKey .. "#lastInspectionStatus", tenancy.lastInspectionStatus or "NOT_INSPECTED")
        xmlFile:setString(tenancyKey .. "#lastInspectionReference", tenancy.lastInspectionReference or "")
        xmlFile:setString(tenancyKey .. "#lastInspectionSummary", tenancy.lastInspectionSummary or "")
        xmlFile:setInt(tenancyKey .. "#breachCaseSchemaVersion", tenancy.breachCaseSchemaVersion or 0)
        xmlFile:setInt(tenancyKey .. "#breachCaseNextId", tenancy.breachCaseNextId or 1)
        xmlFile:setInt(tenancyKey .. "#breachCaseLatestId", tenancy.breachCaseLatestId or 0)
        xmlFile:setInt(tenancyKey .. "#handbackSchemaVersion", tenancy.handbackSchemaVersion or 0)
        xmlFile:setString(tenancyKey .. "#handbackStatus", tenancy.handbackStatus or "NONE")
        xmlFile:setString(tenancyKey .. "#handbackReference", tenancy.handbackReference or "")
        xmlFile:setInt(tenancyKey .. "#handbackInspectionPeriod", tenancy.handbackInspectionPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#handbackRemedyDeadlinePeriod", tenancy.handbackRemedyDeadlinePeriod or 0)
        xmlFile:setInt(tenancyKey .. "#handbackFinalInspectionPeriod", tenancy.handbackFinalInspectionPeriod or 0)
        xmlFile:setInt(tenancyKey .. "#handbackReviewCount", tenancy.handbackReviewCount or 0)
        xmlFile:setInt(tenancyKey .. "#handbackItemCount", tenancy.handbackItemCount or 0)
        xmlFile:setInt(tenancyKey .. "#handbackUnresolvedCount", tenancy.handbackUnresolvedCount or 0)
        xmlFile:setFloat(tenancyKey .. "#handbackEstimatedCost", tenancy.handbackEstimatedCost or 0)
        xmlFile:setFloat(tenancyKey .. "#handbackProfessionalFee", tenancy.handbackProfessionalFee or 0)
        xmlFile:setFloat(tenancyKey .. "#handbackFinalCost", tenancy.handbackFinalCost or 0)
        xmlFile:setString(tenancyKey .. "#handbackLatestSummary", tenancy.handbackLatestSummary or "")
        for eventIndex, event in ipairs(tenancy.narrativeEvents or {}) do
            local eventKey = string.format("%s.narrativeEvent(%d)", tenancyKey, eventIndex - 1)
            xmlFile:setInt(eventKey .. "#id", event.id or eventIndex)
            xmlFile:setString(eventKey .. "#token", event.token or "")
            xmlFile:setString(eventKey .. "#eventType", event.eventType or "CORRESPONDENCE")
            xmlFile:setString(eventKey .. "#label", event.label or "Correspondence")
            xmlFile:setString(eventKey .. "#text", event.text or "")
            xmlFile:setString(eventKey .. "#speaker", event.speaker or "The landlord")
            xmlFile:setInt(eventKey .. "#day", event.day or 0)
            xmlFile:setInt(eventKey .. "#period", event.period or 0)
            xmlFile:setInt(eventKey .. "#round", event.round or 0)
            xmlFile:setInt(eventKey .. "#seed", event.seed or 0)
            xmlFile:setString(eventKey .. "#voiceId", event.voiceId or "")
            xmlFile:setString(eventKey .. "#style", event.style or "BALANCED")
            xmlFile:setString(eventKey .. "#documentStatus", event.documentStatus or "")
            xmlFile:setString(eventKey .. "#reference", event.reference or "")
            xmlFile:setString(eventKey .. "#outcome", event.outcome or "")
            xmlFile:setFloat(eventKey .. "#tenantRent", event.tenantRent or 0)
            xmlFile:setFloat(eventKey .. "#landlordRent", event.landlordRent or 0)
            xmlFile:setInt(eventKey .. "#termMonths", event.termMonths or 0)
            xmlFile:setString(eventKey .. "#relationshipCode", event.relationshipCode or "PROFESSIONAL")
            xmlFile:setFloat(eventKey .. "#relationshipPoints", event.relationshipPoints or 0)
            xmlFile:setString(eventKey .. "#memoryCode", event.memoryCode or "NEW")
            xmlFile:setString(eventKey .. "#conditionCode", event.conditionCode or "")
            xmlFile:setString(eventKey .. "#packageSummary", event.packageSummary or "")
            xmlFile:setString(eventKey .. "#packageResponse", event.packageResponse or "")
            xmlFile:setString(eventKey .. "#tenantPackage", event.tenantPackage or "")
            xmlFile:setString(eventKey .. "#landlordPackage", event.landlordPackage or "")
            xmlFile:setString(eventKey .. "#consentType", event.consentType or "")
            xmlFile:setString(eventKey .. "#consentTarget", event.consentTarget or "")
            xmlFile:setString(eventKey .. "#consentConditions", event.consentConditions or "")
            xmlFile:setInt(eventKey .. "#variationNoticeMonths", event.variationNoticeMonths or 0)
            xmlFile:setInt(eventKey .. "#variationEffectivePeriod", event.variationEffectivePeriod or 0)
            xmlFile:setInt(eventKey .. "#variationCooldownMonths", event.variationCooldownMonths or 0)
            xmlFile:setInt(eventKey .. "#variationCooldownUntilPeriod", event.variationCooldownUntilPeriod or 0)
        end
        for consentIndex, request in ipairs(tenancy.consentRequests or {}) do
            local consentKey = string.format("%s.consentRequest(%d)", tenancyKey, consentIndex - 1)
            xmlFile:setInt(consentKey .. "#id", request.id or consentIndex)
            xmlFile:setString(consentKey .. "#requestType", request.requestType or "")
            xmlFile:setString(consentKey .. "#target", request.target or "AUTHORITY")
            xmlFile:setString(consentKey .. "#status", request.status or "RECEIVED")
            xmlFile:setInt(consentKey .. "#submittedDay", request.submittedDay or 0)
            xmlFile:setInt(consentKey .. "#reviewDay", request.reviewDay or 0)
            xmlFile:setInt(consentKey .. "#decisionDay", request.decisionDay or 0)
            xmlFile:setInt(consentKey .. "#nextActionDay", request.nextActionDay or 0)
            xmlFile:setString(consentKey .. "#reference", request.reference or "")
            xmlFile:setString(consentKey .. "#conditions", request.conditions or "")
            xmlFile:setString(consentKey .. "#decisionReason", request.decisionReason or "")
            xmlFile:setInt(consentKey .. "#expiresPeriod", request.expiresPeriod or 0)
            xmlFile:setFloat(consentKey .. "#relationshipPoints", request.relationshipPoints or 0)
            xmlFile:setString(consentKey .. "#profileId", request.profileId or "")
            xmlFile:setString(consentKey .. "#initiator", request.initiator or "TENANT")
            xmlFile:setString(consentKey .. "#feePayer", request.feePayer or request.initiator or "TENANT")
            xmlFile:setFloat(consentKey .. "#professionalFee", request.professionalFee or 0)
            xmlFile:setFloat(consentKey .. "#feePaid", request.feePaid or 0)
            xmlFile:setFloat(consentKey .. "#feeOutstanding", request.feeOutstanding or 0)
            xmlFile:setBool(consentKey .. "#feeSettlementNotified", request.feeSettlementNotified == true)
            xmlFile:setString(consentKey .. "#proposedTermKey", request.proposedTermKey or "")
            xmlFile:setString(consentKey .. "#proposedValue", request.proposedValue or "")
            xmlFile:setInt(consentKey .. "#noticeServedPeriod", request.noticeServedPeriod or 0)
            xmlFile:setInt(consentKey .. "#effectivePeriod", request.effectivePeriod or 0)
            xmlFile:setInt(consentKey .. "#cooldownUntilPeriod", request.cooldownUntilPeriod or 0)
        end
        for parcelIndex, parcel in ipairs(tenancy.parcelConditions or {}) do
            local parcelKey = string.format("%s.parcelCondition(%d)", tenancyKey, parcelIndex - 1)
            xmlFile:setInt(parcelKey .. "#farmlandId", parcel.farmlandId or 0)
            xmlFile:setString(parcelKey .. "#initialUse", parcel.initialUse or "UNCLASSIFIED")
            xmlFile:setString(parcelKey .. "#initialFruitName", parcel.initialFruitName or "")
            xmlFile:setString(parcelKey .. "#initialGroundName", parcel.initialGroundName or "")
            xmlFile:setString(parcelKey .. "#currentUse", parcel.currentUse or parcel.initialUse or "UNCLASSIFIED")
            xmlFile:setString(parcelKey .. "#currentFruitName", parcel.currentFruitName or parcel.initialFruitName or "")
            xmlFile:setString(parcelKey .. "#currentGroundName", parcel.currentGroundName or parcel.initialGroundName or "")
            xmlFile:setInt(parcelKey .. "#surveyedPeriod", parcel.surveyedPeriod or tenancy.conditionSurveyPeriod or 0)
            xmlFile:setInt(parcelKey .. "#lastObservedPeriod", parcel.lastObservedPeriod or parcel.surveyedPeriod or 0)
            xmlFile:setFloat(parcelKey .. "#initialFieldAreaSqm", parcel.initialFieldAreaSqm or 0)
            xmlFile:setFloat(parcelKey .. "#currentFieldAreaSqm", parcel.currentFieldAreaSqm or 0)
            xmlFile:setFloat(parcelKey .. "#officialFieldAreaSqm", parcel.officialFieldAreaSqm or 0)
            xmlFile:setFloat(parcelKey .. "#boundaryExpansionSqm", parcel.boundaryExpansionSqm or 0)
            xmlFile:setFloat(parcelKey .. "#boundaryExpansionThresholdSqm", parcel.boundaryExpansionThresholdSqm or 0)
            xmlFile:setBool(parcelKey .. "#boundarySurveyAvailable", parcel.boundarySurveyAvailable == true)
            xmlFile:setString(parcelKey .. "#boundaryBaselineSource", parcel.boundaryBaselineSource or "")
        end
        for alterationIndex, alteration in ipairs(tenancy.alterations or {}) do
            local alterationKey = string.format("%s.alteration(%d)", tenancyKey, alterationIndex - 1)
            xmlFile:setInt(alterationKey .. "#id", alteration.id or alterationIndex)
            xmlFile:setString(alterationKey .. "#alterationType", alteration.alterationType or "ALTERATION")
            xmlFile:setInt(alterationKey .. "#farmlandId", alteration.farmlandId or 0)
            xmlFile:setInt(alterationKey .. "#period", alteration.period or 0)
            xmlFile:setInt(alterationKey .. "#day", alteration.day or 0)
            xmlFile:setInt(alterationKey .. "#ownerFarmId", alteration.ownerFarmId or 0)
            xmlFile:setString(alterationKey .. "#assetOwnership", alteration.assetOwnership or "UNKNOWN")
            xmlFile:setString(alterationKey .. "#assetName", alteration.assetName or "")
            xmlFile:setString(alterationKey .. "#category", alteration.category or "")
            xmlFile:setFloat(alterationKey .. "#worldX", alteration.worldX or 0)
            xmlFile:setFloat(alterationKey .. "#worldZ", alteration.worldZ or 0)
            xmlFile:setFloat(alterationKey .. "#value", alteration.value or 0)
            xmlFile:setInt(alterationKey .. "#quantity", alteration.quantity or 1)
            xmlFile:setString(alterationKey .. "#status", alteration.status or "OBSERVED")
            xmlFile:setString(alterationKey .. "#consentReference", alteration.consentReference or "")
            xmlFile:setString(alterationKey .. "#details", alteration.details or "")
        end
        for inspectionIndex, report in ipairs(tenancy.inspectionReports or {}) do
            local inspectionKey = string.format("%s.inspectionReport(%d)", tenancyKey, inspectionIndex - 1)
            xmlFile:setInt(inspectionKey .. "#id", report.id or inspectionIndex)
            xmlFile:setString(inspectionKey .. "#reference", report.reference or "")
            xmlFile:setInt(inspectionKey .. "#period", report.period or 0)
            xmlFile:setInt(inspectionKey .. "#day", report.day or 0)
            xmlFile:setString(inspectionKey .. "#trigger", report.trigger or "ROUTINE")
            xmlFile:setString(inspectionKey .. "#status", report.status or "CLEAR")
            xmlFile:setString(inspectionKey .. "#summary", report.summary or "")
            xmlFile:setInt(inspectionKey .. "#breachCount", report.breachCount or 0)
            xmlFile:setInt(inspectionKey .. "#authorisedCount", report.authorisedCount or 0)
            xmlFile:setInt(inspectionKey .. "#advisoryCount", report.advisoryCount or 0)
            xmlFile:setFloat(inspectionKey .. "#relationshipChange", report.relationshipChange or 0)
        end
        for breachCaseIndex, breachCase in ipairs(tenancy.breachCases or {}) do
            local breachCaseKey = string.format("%s.breachCase(%d)", tenancyKey, breachCaseIndex - 1)
            xmlFile:setInt(breachCaseKey .. "#id", breachCase.id or breachCaseIndex)
            xmlFile:setString(breachCaseKey .. "#reference", breachCase.reference or "")
            xmlFile:setString(breachCaseKey .. "#status", breachCase.status or "REMEDY_NOTICE")
            xmlFile:setInt(breachCaseKey .. "#openedPeriod", breachCase.openedPeriod or 0)
            xmlFile:setInt(breachCaseKey .. "#remedyDeadlinePeriod", breachCase.remedyDeadlinePeriod or 0)
            xmlFile:setInt(breachCaseKey .. "#nextReviewPeriod", breachCase.nextReviewPeriod or 0)
            xmlFile:setInt(breachCaseKey .. "#closedPeriod", breachCase.closedPeriod or 0)
            xmlFile:setString(breachCaseKey .. "#sourceInspectionReference", breachCase.sourceInspectionReference or "")
            xmlFile:setString(breachCaseKey .. "#latestInspectionReference", breachCase.latestInspectionReference or "")
            xmlFile:setInt(breachCaseKey .. "#breachCount", breachCase.breachCount or 0)
            xmlFile:setInt(breachCaseKey .. "#unresolvedCount", breachCase.unresolvedCount or 0)
            xmlFile:setInt(breachCaseKey .. "#reviewCount", breachCase.reviewCount or 0)
            xmlFile:setFloat(breachCaseKey .. "#professionalFee", breachCase.professionalFee or 0)
            xmlFile:setFloat(breachCaseKey .. "#feePaid", breachCase.feePaid or 0)
            xmlFile:setFloat(breachCaseKey .. "#feeOutstanding", breachCase.feeOutstanding or 0)
            xmlFile:setBool(breachCaseKey .. "#feeSettlementNotified", breachCase.feeSettlementNotified == true)
            xmlFile:setInt(breachCaseKey .. "#remedyMonths", breachCase.remedyMonths or 0)
            xmlFile:setInt(breachCaseKey .. "#reviewMonths", breachCase.reviewMonths or 0)
            xmlFile:setInt(breachCaseKey .. "#terminationNoticeMonths", breachCase.terminationNoticeMonths or 0)
            xmlFile:setFloat(breachCaseKey .. "#firstLegalFee", breachCase.firstLegalFee or 0)
            xmlFile:setFloat(breachCaseKey .. "#terminationLegalFee", breachCase.terminationLegalFee or 0)
            xmlFile:setString(breachCaseKey .. "#landlordApproach", breachCase.landlordApproach or "")
            xmlFile:setString(breachCaseKey .. "#relationshipCodeAtOpen", breachCase.relationshipCodeAtOpen or "PROFESSIONAL")
            xmlFile:setFloat(breachCaseKey .. "#relationshipPointsAtOpen", breachCase.relationshipPointsAtOpen or 0)
            xmlFile:setInt(breachCaseKey .. "#terminationEffectivePeriod", breachCase.terminationEffectivePeriod or 0)
            xmlFile:setInt(breachCaseKey .. "#preNoticeContractualEndPeriod", breachCase.preNoticeContractualEndPeriod or 0)
            xmlFile:setInt(breachCaseKey .. "#preNoticeServedPeriod", breachCase.preNoticeServedPeriod or 0)
            xmlFile:setInt(breachCaseKey .. "#preNoticeEffectivePeriod", breachCase.preNoticeEffectivePeriod or 0)
            xmlFile:setString(breachCaseKey .. "#preNoticeReason", breachCase.preNoticeReason or "")
            xmlFile:setString(breachCaseKey .. "#preNoticeStatus", breachCase.preNoticeStatus or "")
            xmlFile:setFloat(breachCaseKey .. "#lastChargeAmount", breachCase.lastChargeAmount or 0)
            xmlFile:setInt(breachCaseKey .. "#lastChargePeriod", breachCase.lastChargePeriod or 0)
            xmlFile:setString(breachCaseKey .. "#summary", breachCase.summary or "")
        end
        for itemIndex, item in ipairs(tenancy.handbackItems or {}) do
            local itemKey = string.format("%s.handbackItem(%d)", tenancyKey, itemIndex - 1)
            xmlFile:setInt(itemKey .. "#id", item.id or itemIndex)
            xmlFile:setString(itemKey .. "#code", item.code or "HAND_BACK_ITEM")
            xmlFile:setString(itemKey .. "#status", item.status or "OUTSTANDING")
            xmlFile:setInt(itemKey .. "#farmlandId", item.farmlandId or 0)
            xmlFile:setString(itemKey .. "#description", item.description or "")
            xmlFile:setString(itemKey .. "#remedy", item.remedy or "")
            xmlFile:setFloat(itemKey .. "#estimatedCost", item.estimatedCost or 0)
            xmlFile:setString(itemKey .. "#consentReference", item.consentReference or "")
            xmlFile:setInt(itemKey .. "#alterationId", item.alterationId or 0)
            xmlFile:setString(itemKey .. "#assetName", item.assetName or "")
        end
    end


    for index, policy in ipairs(self.vehicleInsurancePolicies or {}) do
        local policyKey = string.format("realisticFarmFinance.vehicleInsurancePolicy(%d)", index - 1)
        xmlFile:setInt(policyKey .. "#id", policy.id or index)
        xmlFile:setInt(policyKey .. "#farmId", policy.farmId or 0)
        xmlFile:setString(policyKey .. "#vehicleUniqueId", policy.vehicleUniqueId or "")
        xmlFile:setString(policyKey .. "#vehicleName", policy.vehicleName or "Vehicle")
        xmlFile:setString(policyKey .. "#coverType", policy.coverType or "COMPREHENSIVE")
        xmlFile:setString(policyKey .. "#status", policy.status or "ACTIVE")
        xmlFile:setString(policyKey .. "#source", policy.source or "MIGRATED_FARM_POLICY")
        xmlFile:setInt(policyKey .. "#startPeriod", policy.startPeriod or 0)
        xmlFile:setInt(policyKey .. "#endPeriod", policy.endPeriod or 0)
        xmlFile:setInt(policyKey .. "#lastRenewalPeriod", policy.lastRenewalPeriod or 0)
        xmlFile:setInt(policyKey .. "#graceUntilPeriod", policy.graceUntilPeriod or 0)
        xmlFile:setFloat(policyKey .. "#premiumDue", policy.premiumDue or 0)
        xmlFile:setFloat(policyKey .. "#lastPremium", policy.lastPremium or 0)
        xmlFile:setInt(policyKey .. "#pricingHistoryVersion", policy.pricingHistoryVersion or 0)
        xmlFile:setFloat(policyKey .. "#pricingBasePremium", policy.pricingBasePremium or 0)
        xmlFile:setFloat(policyKey .. "#pricingDiscountRate", policy.pricingDiscountRate or 0)
        xmlFile:setFloat(policyKey .. "#pricingDiscountAmount", policy.pricingDiscountAmount or 0)
        xmlFile:setFloat(policyKey .. "#pricingLoadingRate", policy.pricingLoadingRate or 0)
        xmlFile:setFloat(policyKey .. "#pricingLoadingAmount", policy.pricingLoadingAmount or 0)
        xmlFile:setInt(policyKey .. "#pricingClaimCount", policy.pricingClaimCount or 0)
        xmlFile:setInt(policyKey .. "#pricingClaimFreeMonths", policy.pricingClaimFreeMonths or 0)
        xmlFile:setBool(policyKey .. "#pricingPointsEnabled", policy.pricingPointsEnabled == true)
        xmlFile:setInt(policyKey .. "#pricingActivePoints", policy.pricingActivePoints or 0)
        xmlFile:setFloat(policyKey .. "#pricingPointsRate", policy.pricingPointsRate or 0)
        xmlFile:setFloat(policyKey .. "#pricingPointsAmount", policy.pricingPointsAmount or 0)
        for spanIndex, span in ipairs(policy.pricingCoverage or {}) do
            local coverageKey = string.format("%s.pricingCoverage(%d)", policyKey, spanIndex - 1)
            xmlFile:setInt(coverageKey .. "#startPeriod", span.startPeriod)
            xmlFile:setInt(coverageKey .. "#endPeriod", span.endPeriod)
        end
        xmlFile:setFloat(policyKey .. "#totalPaid", policy.totalPaid or 0)
        xmlFile:setFloat(policyKey .. "#insuredValue", policy.insuredValue or 0)
        xmlFile:setBool(policyKey .. "#legalCover", policy.legalCover == true)
        xmlFile:setString(policyKey .. "#useScope", policy.useScope or "AGRICULTURAL_ROAD")
        xmlFile:setFloat(policyKey .. "#maxGrossWeight", policy.maxGrossWeight or 0)
        xmlFile:setInt(policyKey .. "#temporaryCoverEndHour", policy.temporaryCoverEndHour or 0)
        xmlFile:setString(policyKey .. "#migrationSourceTier", policy.migrationSourceTier or "")
        xmlFile:setBool(policyKey .. "#expiryNotified", policy.expiryNotified == true)
        xmlFile:setBool(policyKey .. "#autoRenew", policy.autoRenew == true)
        xmlFile:setInt(policyKey .. "#autoRenewAttemptEndPeriod", policy.autoRenewAttemptEndPeriod or 0)
        xmlFile:setBool(policyKey .. "#lessorInterested", policy.lessorInterested == true)
        xmlFile:setString(policyKey .. "#lessorNameKey", policy.lessorNameKey or "")
        xmlFile:setInt(policyKey .. "#assetAgreementId", policy.assetAgreementId or 0)
    end

    for index, incident in ipairs(self.trafficCourtesyIncidents or {}) do
        local incidentKey = string.format("realisticFarmFinance.trafficCourtesyIncident(%d)", index - 1)
        xmlFile:setInt(incidentKey .. "#id", incident.id or index)
        xmlFile:setInt(incidentKey .. "#farmId", incident.farmId or 0)
        xmlFile:setString(incidentKey .. "#source", incident.source or "TRAFFIC_COURTESY")
        xmlFile:setString(incidentKey .. "#externalIncidentId", incident.externalIncidentId or "")
        xmlFile:setString(incidentKey .. "#groupedExternalIncidentIds", incident.groupedExternalIncidentIds or incident.externalIncidentId or "")
        xmlFile:setInt(incidentKey .. "#groupedIncidentCount", incident.groupedIncidentCount or 1)
        xmlFile:setString(incidentKey .. "#status", incident.status or "RECORDED")
        xmlFile:setInt(incidentKey .. "#claimId", incident.claimId or 0)
        xmlFile:setInt(incidentKey .. "#incidentDay", incident.incidentDay or 0)
        xmlFile:setInt(incidentKey .. "#incidentPeriod", incident.incidentPeriod or 0)
        xmlFile:setInt(incidentKey .. "#deadlinePeriod", incident.deadlinePeriod or 0)
        xmlFile:setInt(incidentKey .. "#dayTimeMs", incident.dayTimeMs or 0)
        xmlFile:setString(incidentKey .. "#vehicleUniqueId", incident.vehicleUniqueId or "")
        xmlFile:setString(incidentKey .. "#vehicleName", incident.vehicleName or "Vehicle")
        xmlFile:setString(incidentKey .. "#partId", incident.partId or "")
        xmlFile:setString(incidentKey .. "#partName", incident.partName or "Vehicle")
        xmlFile:setString(incidentKey .. "#partFilename", incident.partFilename or "")
        xmlFile:setString(incidentKey .. "#targetName", incident.targetName or "Unknown object")
        xmlFile:setString(incidentKey .. "#targetType", incident.targetType or "UNKNOWN")
        xmlFile:setString(incidentKey .. "#targetVehicleName", incident.targetVehicleName or "")
        xmlFile:setString(incidentKey .. "#targetVehicleId", incident.targetVehicleId or "")
        xmlFile:setString(incidentKey .. "#targetPartId", incident.targetPartId or "")
        xmlFile:setString(incidentKey .. "#targetObjectFilename", incident.targetObjectFilename or "")
        xmlFile:setString(incidentKey .. "#targetOwnershipQuality", incident.targetOwnershipQuality or "")
        xmlFile:setInt(incidentKey .. "#targetFarmId", incident.targetFarmId or 0)
        xmlFile:setInt(incidentKey .. "#targetVehicleFarmId", incident.targetVehicleFarmId or 0)
        xmlFile:setInt(incidentKey .. "#targetFarmlandId", incident.targetFarmlandId or 0)
        xmlFile:setFloat(incidentKey .. "#x", incident.x or 0)
        xmlFile:setFloat(incidentKey .. "#y", incident.y or 0)
        xmlFile:setFloat(incidentKey .. "#z", incident.z or 0)
        xmlFile:setString(incidentKey .. "#locationType", incident.locationType or "UNKNOWN")
        xmlFile:setFloat(incidentKey .. "#sourceSpeedMps", incident.sourceSpeedMps or 0)
        xmlFile:setFloat(incidentKey .. "#targetSpeedMps", incident.targetSpeedMps or 0)
        xmlFile:setFloat(incidentKey .. "#closingSpeedMps", incident.closingSpeedMps or 0)
        xmlFile:setFloat(incidentKey .. "#combinationMassKg", incident.combinationMassKg or 0)
        xmlFile:setFloat(incidentKey .. "#targetPartMassKg", incident.targetPartMassKg or 0)
        xmlFile:setString(incidentKey .. "#severityClass", incident.severityClass or "UNKNOWN")
        xmlFile:setString(incidentKey .. "#faultAssessment", incident.faultAssessment or "UNKNOWN")
        xmlFile:setString(incidentKey .. "#sourceFaultAssessment", incident.sourceFaultAssessment or "UNKNOWN")
        xmlFile:setString(incidentKey .. "#impactZone", incident.impactZone or "UNKNOWN")
        xmlFile:setString(incidentKey .. "#targetImpactZone", incident.targetImpactZone or "UNKNOWN")
        xmlFile:setString(incidentKey .. "#contactQuality", incident.contactQuality or "")
        xmlFile:setString(incidentKey .. "#impactSpeedBasis", incident.impactSpeedBasis or "")
        xmlFile:setFloat(incidentKey .. "#adsSourceDamage", incident.adsSourceDamage or 0)
        xmlFile:setFloat(incidentKey .. "#adsTargetDamage", incident.adsTargetDamage or 0)
        xmlFile:setString(incidentKey .. "#adsSourceSystems", incident.adsSourceSystems or "")
        xmlFile:setString(incidentKey .. "#adsTargetSystems", incident.adsTargetSystems or "")
        xmlFile:setString(incidentKey .. "#adsSourceBreakdowns", incident.adsSourceBreakdowns or "")
        xmlFile:setString(incidentKey .. "#adsTargetBreakdowns", incident.adsTargetBreakdowns or "")
        xmlFile:setInt(incidentKey .. "#adsLogBaselineId", incident.adsLogBaselineId or 0)
        xmlFile:setFloat(incidentKey .. "#ownDamageEstimate", incident.ownDamageEstimate or 0)
        xmlFile:setFloat(incidentKey .. "#thirdPartyEstimate", incident.thirdPartyEstimate or 0)
        xmlFile:setFloat(incidentKey .. "#legalCostEstimate", incident.legalCostEstimate or 0)
        xmlFile:setFloat(incidentKey .. "#estimatedClaimTotal", incident.estimatedClaimTotal or 0)
        xmlFile:setFloat(incidentKey .. "#estimatedPayout", incident.estimatedPayout or 0)
        xmlFile:setBool(incidentKey .. "#thirdPartyTarget", incident.thirdPartyTarget == true)
        xmlFile:setInt(incidentKey .. "#policyId", incident.policyId or 0)
        xmlFile:setString(incidentKey .. "#policyStatusAtIncident", incident.policyStatusAtIncident or "UNINSURED")
        xmlFile:setString(incidentKey .. "#policyCoverType", incident.policyCoverType or "NONE")
        xmlFile:setBool(incidentKey .. "#policyLegalCover", incident.policyLegalCover == true)
        xmlFile:setString(incidentKey .. "#policyUseScope", incident.policyUseScope or "NONE")
        xmlFile:setFloat(incidentKey .. "#policyMaxGrossWeight", incident.policyMaxGrossWeight or 0)
        xmlFile:setFloat(incidentKey .. "#policyInsuredValue", incident.policyInsuredValue or 0)
        xmlFile:setInt(incidentKey .. "#licenceSnapshotVersion", incident.licenceSnapshotVersion or 0)
        xmlFile:setString(incidentKey .. "#licenceModeAtIncident", incident.licenceModeAtIncident or "")
        xmlFile:setString(incidentKey .. "#licenceRequiredCategory", incident.licenceRequiredCategory or "")
        xmlFile:setBool(incidentKey .. "#licenceEntitlementHeld", incident.licenceEntitlementHeld == true)
        xmlFile:setBool(incidentKey .. "#licenceSpecialistRevoked", incident.licenceSpecialistRevoked == true)
        xmlFile:setBool(incidentKey .. "#licenceRulesApplied", incident.licenceRulesApplied == true)
        xmlFile:setBool(incidentKey .. "#licenceAdrRequired", incident.licenceAdrRequired == true)
        xmlFile:setBool(incidentKey .. "#licenceAdrHeld", incident.licenceAdrHeld == true)
        xmlFile:setString(incidentKey .. "#licenceHazardousLoadName", incident.licenceHazardousLoadName or "")
        xmlFile:setFloat(incidentKey .. "#licenceHazardousLoadLevel", incident.licenceHazardousLoadLevel or 0)
        xmlFile:setBool(incidentKey .. "#licenceCategoryBreach", incident.licenceCategoryBreach == true)
        xmlFile:setBool(incidentKey .. "#licenceAdrBreach", incident.licenceAdrBreach == true)
        xmlFile:setString(incidentKey .. "#licenceComplianceStatus", incident.licenceComplianceStatus or "NOT_ASSESSED")
    end

    for index, offence in ipairs(self.driverOffences or {}) do
        local offenceKey = string.format("realisticFarmFinance.driverOffence(%d)", index - 1)
        xmlFile:setInt(offenceKey .. "#id", offence.id or index)
        xmlFile:setInt(offenceKey .. "#farmId", offence.farmId or 0)
        xmlFile:setString(offenceKey .. "#source", offence.source or "TRAFFIC_COURTESY")
        xmlFile:setString(offenceKey .. "#externalIncidentId", offence.externalIncidentId or "")
        xmlFile:setString(offenceKey .. "#status", offence.status or "ACTIVE")
        xmlFile:setString(offenceKey .. "#offenceCode", offence.offenceCode or "REPORTABLE_COLLISION")
        xmlFile:setString(offenceKey .. "#locationType", offence.locationType or "ROAD")
        xmlFile:setInt(offenceKey .. "#incidentDay", offence.incidentDay or 0)
        xmlFile:setInt(offenceKey .. "#incidentPeriod", offence.incidentPeriod or 0)
        if offence.pointsIssuedAt ~= nil then xmlFile:setFloat(offenceKey .. "#pointsIssuedAt", offence.pointsIssuedAt) end
        if offence.pointsExpireAt ~= nil then xmlFile:setFloat(offenceKey .. "#pointsExpireAt", offence.pointsExpireAt) end
        if offence.pointsClosedAt ~= nil then xmlFile:setFloat(offenceKey .. "#pointsClosedAt", offence.pointsClosedAt) end
        xmlFile:setInt(offenceKey .. "#dayTimeMs", offence.dayTimeMs or 0)
        xmlFile:setString(offenceKey .. "#vehicleUniqueId", offence.vehicleUniqueId or "")
        xmlFile:setString(offenceKey .. "#vehicleName", offence.vehicleName or "Vehicle")
        xmlFile:setString(offenceKey .. "#targetName", offence.targetName or "Unknown object")
        xmlFile:setString(offenceKey .. "#severityClass", offence.severityClass or "MINOR")
        xmlFile:setInt(offenceKey .. "#points", offence.points or 0)
        xmlFile:setFloat(offenceKey .. "#sourceSpeedKph", offence.sourceSpeedKph or 0)
        xmlFile:setFloat(offenceKey .. "#closingSpeedKph", offence.closingSpeedKph or 0)
        xmlFile:setInt(offenceKey .. "#pointsTotalAfter", offence.pointsTotalAfter or 0)
    end
    for index, notice in ipairs(self.speedingNotices or {}) do
        local key = string.format("realisticFarmFinance.speedingNotice(%d)",index-1)
        for _,name in ipairs({"id","farmId","incidentPeriod","incidentDay","dayTimeMs","fine","points"}) do
            xmlFile:setInt(key .. "#" .. name,notice[name] or 0)
        end
        for _,name in ipairs({"detectedHour","dueHour","deliveredHour","speedKph","limitKph"}) do
            xmlFile:setFloat(key .. "#" .. name,notice[name] or 0)
        end
        for _,name in ipairs({"status","vehicleUniqueId","vehicleName","limitReason","severityClass","restrictionMessage"}) do
            xmlFile:setString(key .. "#" .. name,tostring(notice[name] or ""))
        end
    end

    for index, report in ipairs(self.roadsideChecks or {}) do
        local key=string.format("realisticFarmFinance.roadsideCheck(%d)",index-1)
        for _,name in ipairs({"id","farmId","incidentDay","incidentPeriod","dayTimeMs","fine","points","findingCount"}) do xmlFile:setInt(key.."#"..name,report[name] or 0) end
        for _,name in ipairs({"requestedHour","expiresHour","completedHour"}) do xmlFile:setFloat(key.."#"..name,report[name] or 0) end
        for _,name in ipairs({"status","vehicleUniqueId","vehicleName","findings","findingCodes","restrictionMessage"}) do xmlFile:setString(key.."#"..name,report[name] or "") end
        xmlFile:setBool(key.."#popupShown",report.popupShown==true)
    end

    for index, claim in ipairs(self.insuranceClaims or {}) do
        local claimKey = string.format("realisticFarmFinance.insuranceClaim(%d)", index - 1)
        xmlFile:setInt(claimKey .. "#id", claim.id or index)
        xmlFile:setInt(claimKey .. "#farmId", claim.farmId or 0)
        xmlFile:setString(claimKey .. "#insurerId", claim.insurerId or "AGRICULTURAL_MUTUAL")
        xmlFile:setString(claimKey .. "#source", claim.source or "RLRM")
        xmlFile:setString(claimKey .. "#claimType", claim.claimType or "MORTALITY")
        xmlFile:setString(claimKey .. "#status", claim.status or "UNDER_REVIEW")
        xmlFile:setInt(claimKey .. "#lossId", claim.lossId or 0)
        xmlFile:setInt(claimKey .. "#incidentDay", claim.incidentDay or 0)
        xmlFile:setInt(claimKey .. "#incidentPeriod", claim.incidentPeriod or 0)
        xmlFile:setInt(claimKey .. "#submittedDay", claim.submittedDay or 0)
        xmlFile:setInt(claimKey .. "#decisionDay", claim.decisionDay or 0)
        xmlFile:setInt(claimKey .. "#approvedDay", claim.approvedDay or 0)
        xmlFile:setInt(claimKey .. "#settlementDay", claim.settlementDay or 0)
        xmlFile:setInt(claimKey .. "#paidDay", claim.paidDay or 0)
        xmlFile:setString(claimKey .. "#policyTier", claim.policyTier or "STANDARD")
        xmlFile:setString(claimKey .. "#policyStatusAtIncident", claim.policyStatusAtIncident or "ACTIVE")
        xmlFile:setString(claimKey .. "#animalUniqueId", claim.animalUniqueId or "")
        xmlFile:setString(claimKey .. "#animalName", claim.animalName or "")
        xmlFile:setString(claimKey .. "#animalBreed", claim.animalBreed or "")
        xmlFile:setString(claimKey .. "#animalSubType", claim.animalSubType or "")
        xmlFile:setString(claimKey .. "#animalType", claim.animalType or "UNKNOWN")
        xmlFile:setInt(claimKey .. "#animalAge", claim.animalAge or 0)
        xmlFile:setFloat(claimKey .. "#animalHealth", claim.animalHealth or 0)
        xmlFile:setString(claimKey .. "#deathReason", claim.deathReason or "UNKNOWN")
        xmlFile:setFloat(claimKey .. "#incidentValue", claim.incidentValue or 0)
        xmlFile:setFloat(claimKey .. "#indemnityFactor", claim.indemnityFactor or 0)
        xmlFile:setFloat(claimKey .. "#excess", claim.excess or 0)
        xmlFile:setFloat(claimKey .. "#amountClaimed", claim.amountClaimed or claim.incidentValue or 0)
        xmlFile:setString(claimKey .. "#formSignedBy", claim.formSignedBy or "")
        xmlFile:setInt(claimKey .. "#formVersion", claim.formVersion or 0)
        xmlFile:setFloat(claimKey .. "#approvedAmount", claim.approvedAmount or 0)
        xmlFile:setFloat(claimKey .. "#paidAmount", claim.paidAmount or 0)
        xmlFile:setString(claimKey .. "#outcomeReason", claim.outcomeReason or "")
        xmlFile:setString(claimKey .. "#treatmentDetails", claim.treatmentDetails or "")
        xmlFile:setString(claimKey .. "#veterinaryExpenseIds", claim.veterinaryExpenseIds or "")
        xmlFile:setInt(claimKey .. "#policyId", claim.policyId or 0)
        xmlFile:setString(claimKey .. "#policyCoverType", claim.policyCoverType or "")
        xmlFile:setBool(claimKey .. "#policyLegalCover", claim.policyLegalCover == true)
        xmlFile:setString(claimKey .. "#policyUseScope", claim.policyUseScope or "")
        xmlFile:setFloat(claimKey .. "#policyMaxGrossWeight", claim.policyMaxGrossWeight or 0)
        xmlFile:setString(claimKey .. "#vehicleUniqueId", claim.vehicleUniqueId or "")
        xmlFile:setString(claimKey .. "#vehicleName", claim.vehicleName or "")
        xmlFile:setString(claimKey .. "#incidentLocationType", claim.incidentLocationType or "UNKNOWN")
        xmlFile:setFloat(claimKey .. "#incidentGrossWeight", claim.incidentGrossWeight or 0)
        xmlFile:setFloat(claimKey .. "#incidentX", claim.incidentX or 0)
        xmlFile:setFloat(claimKey .. "#incidentY", claim.incidentY or 0)
        xmlFile:setFloat(claimKey .. "#incidentZ", claim.incidentZ or 0)
        xmlFile:setString(claimKey .. "#externalIncidentId", claim.externalIncidentId or "")
        xmlFile:setString(claimKey .. "#groupedExternalIncidentIds", claim.groupedExternalIncidentIds or claim.externalIncidentId or "")
        xmlFile:setInt(claimKey .. "#groupedIncidentCount", claim.groupedIncidentCount or 1)
        xmlFile:setString(claimKey .. "#incidentDescription", claim.incidentDescription or "")
        xmlFile:setInt(claimKey .. "#trafficIncidentId", claim.trafficIncidentId or 0)
        xmlFile:setString(claimKey .. "#incidentPartName", claim.incidentPartName or "")
        xmlFile:setString(claimKey .. "#incidentTargetName", claim.incidentTargetName or "")
        xmlFile:setString(claimKey .. "#incidentTargetType", claim.incidentTargetType or "")
        xmlFile:setString(claimKey .. "#incidentSeverity", claim.incidentSeverity or "")
        xmlFile:setString(claimKey .. "#incidentImpactZone", claim.incidentImpactZone or "")
        xmlFile:setString(claimKey .. "#incidentTargetImpactZone", claim.incidentTargetImpactZone or "")
        xmlFile:setFloat(claimKey .. "#incidentClosingSpeedMps", claim.incidentClosingSpeedMps or 0)
        xmlFile:setString(claimKey .. "#incidentFaultAssessment", claim.incidentFaultAssessment or "UNKNOWN")
        xmlFile:setFloat(claimKey .. "#incidentAdsSourceDamage", claim.incidentAdsSourceDamage or 0)
        xmlFile:setString(claimKey .. "#incidentAdsSourceSystems", claim.incidentAdsSourceSystems or "")
        xmlFile:setString(claimKey .. "#incidentAdsSourceBreakdowns", claim.incidentAdsSourceBreakdowns or "")
        xmlFile:setInt(claimKey .. "#trafficWorkflowVersion", claim.trafficWorkflowVersion or 0)
        xmlFile:setBool(claimKey .. "#thirdPartyReported", claim.thirdPartyReported == true)
        xmlFile:setInt(claimKey .. "#responseDeadlineDay", claim.responseDeadlineDay or 0)
        xmlFile:setBool(claimKey .. "#responseWarningSent", claim.responseWarningSent == true)
        xmlFile:setInt(claimKey .. "#defaultAfterDay", claim.defaultAfterDay or 0)
        xmlFile:setInt(claimKey .. "#responseDay", claim.responseDay or 0)
        xmlFile:setString(claimKey .. "#liabilityStatus", claim.liabilityStatus or "NOT_APPLICABLE")
        xmlFile:setInt(claimKey .. "#liabilityDecisionDay", claim.liabilityDecisionDay or 0)
        xmlFile:setInt(claimKey .. "#liabilitySettlementDay", claim.liabilitySettlementDay or 0)
        xmlFile:setFloat(claimKey .. "#liabilityInsurerPaid", claim.liabilityInsurerPaid or 0)
        xmlFile:setFloat(claimKey .. "#liabilityFarmCharge", claim.liabilityFarmCharge or 0)
        xmlFile:setFloat(claimKey .. "#liabilityPolicyShortfall", claim.liabilityPolicyShortfall or 0)
        xmlFile:setFloat(claimKey .. "#liabilityInsurerRecovery", claim.liabilityInsurerRecovery or 0)
        xmlFile:setFloat(claimKey .. "#liabilityExcessConsumed", claim.liabilityExcessConsumed or 0)
        xmlFile:setFloat(claimKey .. "#ownDamageEstimate", claim.ownDamageEstimate or claim.vehicleDamageCost or 0)
        xmlFile:setString(claimKey .. "#ownDamageStatus", claim.ownDamageStatus or "NOT_APPLICABLE")
        xmlFile:setBool(claimKey .. "#adsRequired", claim.adsRequired == true)
        xmlFile:setInt(claimKey .. "#adsLogBaselineId", claim.adsLogBaselineId or 0)
        xmlFile:setInt(claimKey .. "#adsInspectionLogId", claim.adsInspectionLogId or 0)
        xmlFile:setFloat(claimKey .. "#adsInspectionCost", claim.adsInspectionCost or 0)
        xmlFile:setFloat(claimKey .. "#adsRepairCost", claim.adsRepairCost or 0)
        xmlFile:setInt(claimKey .. "#adsInspectionIssueCount", claim.adsInspectionIssueCount or 0)
        xmlFile:setBool(claimKey .. "#adsWarrantyRepair", claim.adsWarrantyRepair == true)
        xmlFile:setBool(claimKey .. "#adsNonOemRepair", claim.adsNonOemRepair == true)
        xmlFile:setFloat(claimKey .. "#actualOwnDamageCost", claim.actualOwnDamageCost or 0)
        xmlFile:setInt(claimKey .. "#ownDecisionDay", claim.ownDecisionDay or 0)
        xmlFile:setInt(claimKey .. "#ownSettlementDay", claim.ownSettlementDay or 0)
        xmlFile:setFloat(claimKey .. "#ownApprovedAmount", claim.ownApprovedAmount or 0)
        xmlFile:setFloat(claimKey .. "#ownPaidAmount", claim.ownPaidAmount or 0)
        if claim.reviewStatus ~= nil and claim.reviewStatus ~= "" then
            xmlFile:setString(claimKey .. "#reviewStatus", claim.reviewStatus)
            xmlFile:setString(claimKey .. "#reviewResult", claim.reviewResult or "")
            xmlFile:setInt(claimKey .. "#reviewRequestedDay", claim.reviewRequestedDay or 0)
            xmlFile:setInt(claimKey .. "#reviewDueDay", claim.reviewDueDay or 0)
            xmlFile:setInt(claimKey .. "#reviewCompletedDay", claim.reviewCompletedDay or 0)
            xmlFile:setFloat(claimKey .. "#reviewCredit", claim.reviewCredit or 0)
            xmlFile:setFloat(claimKey .. "#reviewOriginalOwnPaid", claim.reviewOriginalOwnPaid or 0)
            xmlFile:setFloat(claimKey .. "#reviewOriginalFarmCharge", claim.reviewOriginalFarmCharge or 0)
        end
        xmlFile:setFloat(claimKey .. "#defaultCharge", claim.defaultCharge or 0)
        xmlFile:setFloat(claimKey .. "#vehicleDamageCost", claim.vehicleDamageCost or 0)
        xmlFile:setFloat(claimKey .. "#thirdPartyLiability", claim.thirdPartyLiability or 0)
        xmlFile:setFloat(claimKey .. "#legalCosts", claim.legalCosts or 0)
        xmlFile:setFloat(claimKey .. "#eligibleVehicleDamage", claim.eligibleVehicleDamage or 0)
        xmlFile:setFloat(claimKey .. "#eligibleThirdPartyLiability", claim.eligibleThirdPartyLiability or 0)
        xmlFile:setFloat(claimKey .. "#eligibleLegalCosts", claim.eligibleLegalCosts or 0)
        xmlFile:setFloat(claimKey .. "#estimatedPayout", claim.estimatedPayout or 0)
        xmlFile:setString(claimKey .. "#coverageSummary", claim.coverageSummary or "")
        xmlFile:setInt(claimKey .. "#licenceSnapshotVersion", claim.licenceSnapshotVersion or 0)
        xmlFile:setString(claimKey .. "#licenceModeAtIncident", claim.licenceModeAtIncident or "")
        xmlFile:setString(claimKey .. "#licenceRequiredCategory", claim.licenceRequiredCategory or "")
        xmlFile:setBool(claimKey .. "#licenceEntitlementHeld", claim.licenceEntitlementHeld == true)
        xmlFile:setBool(claimKey .. "#licenceSpecialistRevoked", claim.licenceSpecialistRevoked == true)
        xmlFile:setBool(claimKey .. "#licenceRulesApplied", claim.licenceRulesApplied == true)
        xmlFile:setBool(claimKey .. "#licenceAdrRequired", claim.licenceAdrRequired == true)
        xmlFile:setBool(claimKey .. "#licenceAdrHeld", claim.licenceAdrHeld == true)
        xmlFile:setString(claimKey .. "#licenceHazardousLoadName", claim.licenceHazardousLoadName or "")
        xmlFile:setFloat(claimKey .. "#licenceHazardousLoadLevel", claim.licenceHazardousLoadLevel or 0)
        xmlFile:setBool(claimKey .. "#licenceCategoryBreach", claim.licenceCategoryBreach == true)
        xmlFile:setBool(claimKey .. "#licenceAdrBreach", claim.licenceAdrBreach == true)
        xmlFile:setString(claimKey .. "#licenceComplianceStatus", claim.licenceComplianceStatus or "NOT_ASSESSED")
        xmlFile:setBool(claimKey .. "#licenceRecoveryApplies", claim.licenceRecoveryApplies == true)
    end

    for index, loss in ipairs(self.insuranceLosses or {}) do
        local lossKey = string.format("realisticFarmFinance.insuranceLoss(%d)", index - 1)
        xmlFile:setInt(lossKey .. "#id", loss.id or index)
        xmlFile:setInt(lossKey .. "#farmId", loss.farmId or 0)
        xmlFile:setString(lossKey .. "#source", loss.source or "RLRM")
        xmlFile:setString(lossKey .. "#status", loss.status or "RECORDED")
        xmlFile:setInt(lossKey .. "#incidentDay", loss.incidentDay or 0)
        xmlFile:setInt(lossKey .. "#incidentPeriod", loss.incidentPeriod or 0)
        xmlFile:setInt(lossKey .. "#deadlinePeriod", loss.deadlinePeriod or 0)
        xmlFile:setInt(lossKey .. "#claimId", loss.claimId or 0)
        xmlFile:setString(lossKey .. "#policyTier", loss.policyTier or "STANDARD")
        xmlFile:setString(lossKey .. "#policyStatusAtIncident", loss.policyStatusAtIncident or "ACTIVE")
        xmlFile:setString(lossKey .. "#animalUniqueId", loss.animalUniqueId or "")
        xmlFile:setString(lossKey .. "#animalName", loss.animalName or "")
        xmlFile:setString(lossKey .. "#animalBreed", loss.animalBreed or "")
        xmlFile:setString(lossKey .. "#animalSubType", loss.animalSubType or "")
        xmlFile:setString(lossKey .. "#animalType", loss.animalType or "UNKNOWN")
        xmlFile:setInt(lossKey .. "#animalAge", loss.animalAge or 0)
        xmlFile:setFloat(lossKey .. "#animalHealth", loss.animalHealth or 0)
        xmlFile:setString(lossKey .. "#deathReason", loss.deathReason or "UNKNOWN")
        xmlFile:setFloat(lossKey .. "#incidentValue", loss.incidentValue or 0)
        xmlFile:setFloat(lossKey .. "#indemnityFactor", loss.indemnityFactor or 0)
        xmlFile:setFloat(lossKey .. "#excess", loss.excess or 0)
    end

    for index, expense in ipairs(self.insuranceVeterinaryExpenses or {}) do
        local expenseKey = string.format("realisticFarmFinance.insuranceVeterinaryExpense(%d)", index - 1)
        xmlFile:setInt(expenseKey .. "#id", expense.id or index)
        xmlFile:setInt(expenseKey .. "#farmId", expense.farmId or 0)
        xmlFile:setString(expenseKey .. "#source", expense.source or "RLRM")
        xmlFile:setString(expenseKey .. "#status", expense.status or "RECORDED")
        xmlFile:setInt(expenseKey .. "#incidentDay", expense.incidentDay or 0)
        xmlFile:setInt(expenseKey .. "#incidentPeriod", expense.incidentPeriod or 0)
        xmlFile:setInt(expenseKey .. "#deadlinePeriod", expense.deadlinePeriod or 0)
        xmlFile:setInt(expenseKey .. "#claimId", expense.claimId or 0)
        xmlFile:setString(expenseKey .. "#policyTier", expense.policyTier or "STANDARD")
        xmlFile:setString(expenseKey .. "#policyStatusAtIncident", expense.policyStatusAtIncident or "ACTIVE")
        xmlFile:setString(expenseKey .. "#animalUniqueId", expense.animalUniqueId or "")
        xmlFile:setString(expenseKey .. "#animalName", expense.animalName or "")
        xmlFile:setString(expenseKey .. "#animalBreed", expense.animalBreed or "")
        xmlFile:setString(expenseKey .. "#animalSubType", expense.animalSubType or "")
        xmlFile:setString(expenseKey .. "#animalType", expense.animalType or "UNKNOWN")
        xmlFile:setString(expenseKey .. "#diseaseNames", expense.diseaseNames or "")
        xmlFile:setFloat(expenseKey .. "#treatmentCost", expense.treatmentCost or 0)
    end

    for index, application in ipairs(self.applications or {}) do
        local appKey = string.format("realisticFarmFinance.application(%d)", index - 1)
        xmlFile:setInt(appKey .. "#id", application.id or index)
        xmlFile:setInt(appKey .. "#farmId", application.farmId or 0)
        xmlFile:setString(appKey .. "#product", application.product or "TERM")
        xmlFile:setString(appKey .. "#purpose", application.purpose or "GENERAL")
        xmlFile:setFloat(appKey .. "#requestedAmount", application.requestedAmount or 0)
        xmlFile:setInt(appKey .. "#requestedMonths", application.requestedMonths or 0)
        xmlFile:setString(appKey .. "#status", application.status or "SUBMITTED")
        xmlFile:setString(appKey .. "#route", application.route or "STANDARD")
        xmlFile:setInt(appKey .. "#submittedDay", application.submittedDay or 0)
        xmlFile:setInt(appKey .. "#initialReviewDay", application.initialReviewDay or 0)
        xmlFile:setInt(appKey .. "#decisionDay", application.decisionDay or 0)
        xmlFile:setInt(appKey .. "#expectedMinDays", application.expectedMinDays or 0)
        xmlFile:setInt(appKey .. "#expectedMaxDays", application.expectedMaxDays or 0)
        xmlFile:setInt(appKey .. "#offerExpiryDay", application.offerExpiryDay or 0)
        xmlFile:setInt(appKey .. "#acceptedDay", application.acceptedDay or 0)
        xmlFile:setInt(appKey .. "#submittedHour", application.submittedHour or 0)
        xmlFile:setInt(appKey .. "#initialReviewHour", application.initialReviewHour or 0)
        xmlFile:setInt(appKey .. "#underwritingHour", application.underwritingHour or 0)
        xmlFile:setInt(appKey .. "#finalReviewHour", application.finalReviewHour or 0)
        xmlFile:setInt(appKey .. "#decisionHour", application.decisionHour or 0)
        xmlFile:setInt(appKey .. "#expectedMinHours", application.expectedMinHours or 0)
        xmlFile:setInt(appKey .. "#expectedMaxHours", application.expectedMaxHours or 0)
        xmlFile:setInt(appKey .. "#offerExpiryHour", application.offerExpiryHour or 0)
        xmlFile:setInt(appKey .. "#acceptedHour", application.acceptedHour or 0)
        xmlFile:setInt(appKey .. "#calendarDaysPerPeriod", application.calendarDaysPerPeriod or 0)
        xmlFile:setInt(appKey .. "#farmlandId", application.farmlandId or 0)
        xmlFile:setString(appKey .. "#securityFarmlandIds", application.securityFarmlandIds or "")
        xmlFile:setInt(appKey .. "#securityFarmlandCount", application.securityFarmlandCount or 0)
        xmlFile:setString(appKey .. "#propertyFinanceMode", application.propertyFinanceMode or "")
        xmlFile:setFloat(appKey .. "#requestedAdvancePercent", application.requestedAdvancePercent or 0)
        xmlFile:setFloat(appKey .. "#purchasePrice", application.purchasePrice or 0)
        xmlFile:setFloat(appKey .. "#requestedDepositPercent", application.requestedDepositPercent or 0)
        xmlFile:setFloat(appKey .. "#requestedDepositAmount", application.requestedDepositAmount or 0)
        xmlFile:setFloat(appKey .. "#lenderValuation", application.lenderValuation or 0)
        xmlFile:setFloat(appKey .. "#lenderValuationRatio", application.lenderValuationRatio or 0)
        xmlFile:setInt(appKey .. "#valuationInstructionHour", application.valuationInstructionHour or 0)
        xmlFile:setInt(appKey .. "#valuationReturnHour", application.valuationReturnHour or 0)
        xmlFile:setInt(appKey .. "#valuationCompletedHour", application.valuationCompletedHour or 0)
        if application.submissionPropertyLtv ~= nil then xmlFile:setFloat(appKey .. "#submissionPropertyLtv", application.submissionPropertyLtv) end
        xmlFile:setFloat(appKey .. "#offeredDeposit", application.offeredDeposit or 0)
        xmlFile:setFloat(appKey .. "#offeredPropertyLtv", application.offeredPropertyLtv or 0)
        xmlFile:setFloat(appKey .. "#propertyLtvLimit", application.propertyLtvLimit or 0)
        xmlFile:setFloat(appKey .. "#offeredAmount", application.offeredAmount or 0)
        xmlFile:setInt(appKey .. "#offeredMonths", application.offeredMonths or 0)
        xmlFile:setFloat(appKey .. "#offeredRate", application.offeredRate or 0)
        xmlFile:setFloat(appKey .. "#offeredPayment", application.offeredPayment or 0)
        xmlFile:setString(appKey .. "#offeredGrade", application.offeredGrade or "")
        xmlFile:setString(appKey .. "#outcome", application.outcome or "PENDING")
        xmlFile:setString(appKey .. "#decisionReason", application.decisionReason or "")
        xmlFile:setInt(appKey .. "#linkedLoanId", application.linkedLoanId or 0)
        xmlFile:setFloat(appKey .. "#submissionAssets", application.submissionAssets or 0)
        xmlFile:setFloat(appKey .. "#submissionCollateral", application.submissionCollateral or 0)
        xmlFile:setFloat(appKey .. "#submissionIncome", application.submissionIncome or 0)
        xmlFile:setInt(appKey .. "#submissionTrackedPeriods", application.submissionTrackedPeriods or 0)
        xmlFile:setFloat(appKey .. "#submissionLtv", application.submissionLtv or 0)
        if application.submissionDscr ~= nil then xmlFile:setFloat(appKey .. "#submissionDscr", application.submissionDscr) end
        xmlFile:setBool(appKey .. "#submissionIndicativeApproved", application.submissionIndicativeApproved == true)
        xmlFile:setString(appKey .. "#submissionIndicativeGrade", application.submissionIndicativeGrade or "")
        xmlFile:setFloat(appKey .. "#submissionIndicativeRate", application.submissionIndicativeRate or 0)
        xmlFile:setFloat(appKey .. "#submissionIndicativePayment", application.submissionIndicativePayment or 0)
        xmlFile:setString(appKey .. "#lenderId", application.lenderId or "PRIMARY_BANK")
        xmlFile:setString(appKey .. "#lenderNameKey", application.lenderNameKey or "rff_lender_primary_bank")
        xmlFile:setString(appKey .. "#marketState", application.marketState or "SELECTIVE")
        xmlFile:setString(appKey .. "#dealFit", application.dealFit or "STANDARD")
    end


    for index, case in ipairs(self.brokerCases or {}) do
        local caseKey = string.format("realisticFarmFinance.brokerCase(%d)", index - 1)
        xmlFile:setInt(caseKey .. "#id", case.id or index)
        xmlFile:setInt(caseKey .. "#farmId", case.farmId or 0)
        xmlFile:setInt(caseKey .. "#sourceApplicationId", case.sourceApplicationId or 0)
        xmlFile:setString(caseKey .. "#product", case.product or "TERM")
        xmlFile:setString(caseKey .. "#purpose", case.purpose or "GENERAL")
        xmlFile:setFloat(caseKey .. "#requestedAmount", case.requestedAmount or 0)
        xmlFile:setInt(caseKey .. "#requestedMonths", case.requestedMonths or 0)
        xmlFile:setInt(caseKey .. "#farmlandId", case.farmlandId or 0)
        xmlFile:setFloat(caseKey .. "#purchasePrice", case.purchasePrice or 0)
        xmlFile:setFloat(caseKey .. "#requestedDepositAmount", case.requestedDepositAmount or 0)
        xmlFile:setString(caseKey .. "#status", case.status or "INSTRUCTED")
        xmlFile:setInt(caseKey .. "#instructedHour", case.instructedHour or 0)
        xmlFile:setInt(caseKey .. "#lendersApproachedHour", case.lendersApproachedHour or 0)
        xmlFile:setInt(caseKey .. "#indicativeHour", case.indicativeHour or 0)
        xmlFile:setInt(caseKey .. "#offersPreparingHour", case.offersPreparingHour or 0)
        xmlFile:setInt(caseKey .. "#offersReadyHour", case.offersReadyHour or 0)
        xmlFile:setInt(caseKey .. "#expectedMinHours", case.expectedMinHours or 0)
        xmlFile:setInt(caseKey .. "#expectedMaxHours", case.expectedMaxHours or 0)
        xmlFile:setInt(caseKey .. "#offerExpiryHour", case.offerExpiryHour or 0)
        xmlFile:setInt(caseKey .. "#acceptedHour", case.acceptedHour or 0)
        xmlFile:setInt(caseKey .. "#acceptedOfferIndex", case.acceptedOfferIndex or 0)
        xmlFile:setString(caseKey .. "#acceptedLenderId", case.acceptedLenderId or "")
        xmlFile:setInt(caseKey .. "#linkedLoanId", case.linkedLoanId or 0)
        xmlFile:setFloat(caseKey .. "#brokerFee", case.brokerFee or 0)
        xmlFile:setFloat(caseKey .. "#arrangementFee", case.arrangementFee or 0)
        for offerIndex, offer in ipairs(case.offers or {}) do
            local offerKey = string.format("%s.offer(%d)", caseKey, offerIndex - 1)
            xmlFile:setString(offerKey .. "#lenderId", offer.lenderId or "")
            xmlFile:setFloat(offerKey .. "#amount", offer.amount or 0)
            xmlFile:setInt(offerKey .. "#months", offer.months or 0)
            xmlFile:setFloat(offerKey .. "#interestRate", offer.interestRate or 0)
            xmlFile:setFloat(offerKey .. "#monthlyPayment", offer.monthlyPayment or 0)
            xmlFile:setString(offerKey .. "#grade", offer.grade or "C")
            xmlFile:setFloat(offerKey .. "#arrangementFee", offer.arrangementFee or 0)
            xmlFile:setFloat(offerKey .. "#brokerFee", offer.brokerFee or 0)
            xmlFile:setFloat(offerKey .. "#lenderValuation", offer.lenderValuation or 0)
            xmlFile:setFloat(offerKey .. "#deposit", offer.deposit or 0)
            xmlFile:setFloat(offerKey .. "#propertyLtv", offer.propertyLtv or 0)
            xmlFile:setFloat(offerKey .. "#propertyLtvLimit", offer.propertyLtvLimit or 0)
            if offer.dscr ~= nil then xmlFile:setFloat(offerKey .. "#dscr", offer.dscr) end
            xmlFile:setString(offerKey .. "#marketState", offer.marketState or "SELECTIVE")
            xmlFile:setString(offerKey .. "#dealFit", offer.dealFit or "STANDARD")
        end
    end

    for index, offer in ipairs(self.preApprovedOffers or {}) do
        local offerKey = string.format("realisticFarmFinance.preApprovedOffer(%d)", index - 1)
        xmlFile:setInt(offerKey .. "#id", offer.id or 0)
        xmlFile:setInt(offerKey .. "#farmId", offer.farmId or 0)
        xmlFile:setString(offerKey .. "#lenderId", offer.lenderId or "PRIMARY_BANK")
        xmlFile:setString(offerKey .. "#lenderNameKey", offer.lenderNameKey or "rff_lender_primary_bank")
        xmlFile:setString(offerKey .. "#product", offer.product or "TERM")
        xmlFile:setString(offerKey .. "#purpose", offer.purpose or "GENERAL")
        xmlFile:setFloat(offerKey .. "#amount", offer.amount or 0)
        xmlFile:setInt(offerKey .. "#months", offer.months or 0)
        xmlFile:setFloat(offerKey .. "#interestRate", offer.interestRate or 0)
        xmlFile:setFloat(offerKey .. "#monthlyPayment", offer.monthlyPayment or 0)
        xmlFile:setString(offerKey .. "#grade", offer.grade or "C")
        xmlFile:setFloat(offerKey .. "#arrangementFee", offer.arrangementFee or 0)
        xmlFile:setString(offerKey .. "#relationshipTier", offer.relationshipTier or "NEW")
        xmlFile:setFloat(offerKey .. "#relationshipPoints", offer.relationshipPoints or 0)
        xmlFile:setString(offerKey .. "#marketState", offer.marketState or "SELECTIVE")
        xmlFile:setString(offerKey .. "#dealFit", offer.dealFit or "STANDARD")
        xmlFile:setString(offerKey .. "#status", offer.status or "OFFERED")
        xmlFile:setInt(offerKey .. "#createdPeriod", offer.createdPeriod or 0)
        xmlFile:setInt(offerKey .. "#expiryPeriod", offer.expiryPeriod or 0)
        xmlFile:setInt(offerKey .. "#acceptedPeriod", offer.acceptedPeriod or 0)
        xmlFile:setInt(offerKey .. "#declinedPeriod", offer.declinedPeriod or 0)
        xmlFile:setInt(offerKey .. "#linkedLoanId", offer.linkedLoanId or 0)
    end

    local brokerRelIndex = 0
    for farmId, rel in pairs(self.brokerRelationships or {}) do
        local relKey = string.format("realisticFarmFinance.brokerRelationship(%d)", brokerRelIndex)
        xmlFile:setInt(relKey .. "#farmId", farmId)
        xmlFile:setInt(relKey .. "#casesInstructed", rel.casesInstructed or 0)
        xmlFile:setInt(relKey .. "#acceptedDeals", rel.acceptedDeals or 0)
        xmlFile:setInt(relKey .. "#successfulIntroductions", rel.successfulIntroductions or 0)
        xmlFile:setFloat(relKey .. "#feesPaid", rel.feesPaid or 0)
        xmlFile:setInt(relKey .. "#relationshipPoints", rel.relationshipPoints or 0)
        brokerRelIndex = brokerRelIndex + 1
    end

    local lenderRelIndex = 0
    for farmId, lenders in pairs(self.lenderRelationships or {}) do
        for lenderId, rel in pairs(lenders) do
            local relKey = string.format("realisticFarmFinance.lenderRelationship(%d)", lenderRelIndex)
            xmlFile:setInt(relKey .. "#farmId", farmId)
            xmlFile:setString(relKey .. "#lenderId", lenderId)
            xmlFile:setInt(relKey .. "#applications", rel.applications or 0)
            xmlFile:setInt(relKey .. "#offersMade", rel.offersMade or 0)
            xmlFile:setInt(relKey .. "#acceptedDeals", rel.acceptedDeals or 0)
            xmlFile:setFloat(relKey .. "#totalVolume", rel.totalVolume or 0)
            xmlFile:setFloat(relKey .. "#relationshipPoints", rel.relationshipPoints or 0)
            xmlFile:setInt(relKey .. "#successfulPayments", rel.successfulPayments or 0)
            xmlFile:setInt(relKey .. "#missedPayments", rel.missedPayments or 0)
            xmlFile:setInt(relKey .. "#completedAgreements", rel.completedAgreements or 0)
            xmlFile:setInt(relKey .. "#forcedRecoveries", rel.forcedRecoveries or 0)
            xmlFile:setInt(relKey .. "#mortgagePossessions", rel.mortgagePossessions or 0)
            xmlFile:setInt(relKey .. "#voluntarySurrenders", rel.voluntarySurrenders or 0)
            xmlFile:setInt(relKey .. "#voluntaryPropertySales", rel.voluntaryPropertySales or 0)
            xmlFile:setInt(relKey .. "#restructures", rel.restructures or 0)
            xmlFile:setInt(relKey .. "#arrearsCured", rel.arrearsCured or 0)
            xmlFile:setInt(relKey .. "#lastInteractionPeriod", rel.lastInteractionPeriod or 0)
            xmlFile:setInt(relKey .. "#proactiveOffersMade", rel.proactiveOffersMade or 0)
            xmlFile:setInt(relKey .. "#proactiveOffersAccepted", rel.proactiveOffersAccepted or 0)
            xmlFile:setInt(relKey .. "#proactiveOffersDeclined", rel.proactiveOffersDeclined or 0)
            xmlFile:setInt(relKey .. "#lastProactiveOfferPeriod", rel.lastProactiveOfferPeriod or 0)
            xmlFile:setInt(relKey .. "#forbearanceArrangements", rel.forbearanceArrangements or 0)
            xmlFile:setInt(relKey .. "#brokenForbearanceArrangements", rel.brokenForbearanceArrangements or 0)
            xmlFile:setInt(relKey .. "#rescueExits", rel.rescueExits or 0)
            xmlFile:setInt(relKey .. "#rescueDeals", rel.rescueDeals or 0)
            xmlFile:setInt(relKey .. "#relationshipSchemaVersion", rel.relationshipSchemaVersion or 0)
            lenderRelIndex = lenderRelIndex + 1
        end
    end

    if RFF_CropAdvanceService ~= nil then RFF_CropAdvanceService.save(self, xmlFile) end
    if RFF_EconomyService ~= nil then RFF_EconomyService.save(self, xmlFile) end
    if RFF_SavingsService ~= nil then RFF_SavingsService.save(self, xmlFile) end
    if RFF_FinancialAdviserService ~= nil then RFF_FinancialAdviserService.save(self, xmlFile) end
    if RFF_InvestmentService ~= nil then RFF_InvestmentService.save(self, xmlFile) end
    if RFF_DealershipService ~= nil then RFF_DealershipService.save(self, xmlFile) end
    if RFF_NewSaveSetup ~= nil then RFF_NewSaveSetup.save(self, xmlFile) end
    xmlFile:save()
    xmlFile:delete()
end
