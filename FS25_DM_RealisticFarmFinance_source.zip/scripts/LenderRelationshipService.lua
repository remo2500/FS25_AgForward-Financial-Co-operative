RFF_LenderRelationshipService = {}
RFF_LenderRelationshipService.__index = RFF_LenderRelationshipService

local function safeNumber(value)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then return value end
    return 0
end

RFF_LenderRelationshipService.LENDERS = {
    {id="PRIMARY_BANK", nameKey="rff_lender_primary_bank", styleKey="rff_lender_style_relationship_bank"},
    {id="RURAL_AGRI_BANK", nameKey="rff_lender_rural_agri_bank", styleKey="rff_lender_style_conservative"},
    {id="COUNTY_COMMERCIAL", nameKey="rff_lender_county_commercial", styleKey="rff_lender_style_mainstream"},
    {id="AGRIGROWTH_FINANCE", nameKey="rff_lender_agrigrowth", styleKey="rff_lender_style_specialist"},
    {id="FRONTIER_CAPITAL", nameKey="rff_lender_frontier_capital", styleKey="rff_lender_style_alternative"}
}

RFF_LenderRelationshipService.TIERS = {
    STRAINED = {key="rff_relationship_strained", rateAdjustment=0.75, arrangementFeeFactor=1.10, timingFactor=1.10, ltvBonus=-0.03, dscrTolerance=-0.05},
    NEW = {key="rff_relationship_new", rateAdjustment=0.00, arrangementFeeFactor=1.00, timingFactor=1.00, ltvBonus=0.00, dscrTolerance=0.00},
    DEVELOPING = {key="rff_relationship_developing", rateAdjustment=-0.10, arrangementFeeFactor=0.95, timingFactor=0.96, ltvBonus=0.01, dscrTolerance=0.00},
    PROVEN = {key="rff_relationship_proven", rateAdjustment=-0.25, arrangementFeeFactor=0.875, timingFactor=0.92, ltvBonus=0.025, dscrTolerance=0.03},
    TRUSTED = {key="rff_relationship_trusted", rateAdjustment=-0.50, arrangementFeeFactor=0.75, timingFactor=0.85, ltvBonus=0.05, dscrTolerance=0.05}
}

function RFF_LenderRelationshipService.new(repository)
    local self = setmetatable({}, RFF_LenderRelationshipService)
    self.repository = repository
    return self
end

function RFF_LenderRelationshipService:getLenders()
    return self.LENDERS
end

function RFF_LenderRelationshipService:getLender(lenderId)
    lenderId = lenderId or "PRIMARY_BANK"
    for _, lender in ipairs(self.LENDERS) do
        if lender.id == lenderId then return lender end
    end
    return {id=lenderId, nameKey="rff_lender_primary_bank", styleKey="rff_lender_style_relationship_bank"}
end

function RFF_LenderRelationshipService:getRelationship(farmId, lenderId, create)
    if self.repository == nil then return nil end
    return self.repository:getLenderRelationship(farmId, lenderId or "PRIMARY_BANK", create)
end

function RFF_LenderRelationshipService:getTier(points)
    points = safeNumber(points)
    if points < 0 then return "STRAINED", self.TIERS.STRAINED end
    if points >= 15 then return "TRUSTED", self.TIERS.TRUSTED end
    if points >= 8 then return "PROVEN", self.TIERS.PROVEN end
    if points >= 3 then return "DEVELOPING", self.TIERS.DEVELOPING end
    return "NEW", self.TIERS.NEW
end

function RFF_LenderRelationshipService:getBenefits(farmId, lenderId)
    local rel = self:getRelationship(farmId, lenderId, false)
    local code, tier = self:getTier(rel ~= nil and rel.relationshipPoints or 0)
    return {
        code=code,
        key=tier.key,
        rateAdjustment=tier.rateAdjustment,
        arrangementFeeFactor=tier.arrangementFeeFactor,
        timingFactor=tier.timingFactor,
        ltvBonus=tier.ltvBonus,
        dscrTolerance=tier.dscrTolerance,
        relationship=rel
    }
end

function RFF_LenderRelationshipService:adjustPoints(rel, amount)
    if rel == nil then return end
    rel.relationshipPoints = math.max(-30, math.min(50, safeNumber(rel.relationshipPoints) + safeNumber(amount)))
end

function RFF_LenderRelationshipService:touch(rel)
    if rel == nil then return end
    rel.lastInteractionPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    -- Any relationship touched by the current runtime is already using the v2 model,
    -- which includes asset-finance conduct as well as bank/mortgage conduct.
    rel.relationshipSchemaVersion = math.max(2, safeNumber(rel.relationshipSchemaVersion))
end

function RFF_LenderRelationshipService:recordApplication(farmId, lenderId)
    local rel = self:getRelationship(farmId, lenderId, true)
    if rel == nil then return end
    rel.applications = safeNumber(rel.applications) + 1
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordOffer(farmId, lenderId)
    local rel = self:getRelationship(farmId, lenderId, true)
    if rel == nil then return end
    rel.offersMade = safeNumber(rel.offersMade) + 1
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordAcceptedDeal(farmId, lenderId, amount, pointsAlreadyAwarded)
    local rel = self:getRelationship(farmId, lenderId, true)
    if rel == nil then return end
    if not pointsAlreadyAwarded then
        rel.acceptedDeals = safeNumber(rel.acceptedDeals) + 1
        rel.totalVolume = safeNumber(rel.totalVolume) + math.max(0, safeNumber(amount))
        self:adjustPoints(rel, 3.0)
    end
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordSuccessfulPayment(entity)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.successfulPayments = safeNumber(rel.successfulPayments) + 1
    self:adjustPoints(rel, 0.15)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordMissedPayment(entity)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.missedPayments = safeNumber(rel.missedPayments) + 1
    self:adjustPoints(rel, -1.25)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordArrearsCleared(entity)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.arrearsCured = safeNumber(rel.arrearsCured) + 1
    self:adjustPoints(rel, 0.25)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordAgreementCompleted(entity)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.completedAgreements = safeNumber(rel.completedAgreements) + 1
    self:adjustPoints(rel, 1.5)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordRecovery(entity, isMortgage, voluntary)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    if isMortgage then
        if voluntary then
            rel.voluntaryPropertySales = safeNumber(rel.voluntaryPropertySales) + 1
            self:adjustPoints(rel, -4.0)
        else
            rel.mortgagePossessions = safeNumber(rel.mortgagePossessions) + 1
            self:adjustPoints(rel, -14.0)
        end
    else
        if voluntary then
            rel.voluntarySurrenders = safeNumber(rel.voluntarySurrenders) + 1
            self:adjustPoints(rel, -3.0)
        else
            rel.forcedRecoveries = safeNumber(rel.forcedRecoveries) + 1
            self:adjustPoints(rel, -6.0)
        end
    end
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordMortgageRestructure(entity)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.restructures = safeNumber(rel.restructures) + 1
    self:adjustPoints(rel, -0.75)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordForbearance(entity, arrangementType)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.forbearanceArrangements = safeNumber(rel.forbearanceArrangements) + 1
    local penalty = arrangementType == "PAYMENT_HOLIDAY" and -0.25 or (arrangementType == "INTEREST_ONLY" and -0.50 or -0.75)
    self:adjustPoints(rel, penalty)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordForbearanceBroken(entity)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.brokenForbearanceArrangements = safeNumber(rel.brokenForbearanceArrangements) + 1
    self:adjustPoints(rel, -1.50)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordRescueExit(entity)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.rescueExits = safeNumber(rel.rescueExits) + 1
    self:adjustPoints(rel, -2.00)
    self:touch(rel)
end

function RFF_LenderRelationshipService:recordRescueDeal(entity, amount)
    if entity == nil or safeNumber(entity.farmId) <= 0 then return end
    local rel = self:getRelationship(entity.farmId, entity.lenderId or "PRIMARY_BANK", true)
    if rel == nil then return end
    rel.acceptedDeals = safeNumber(rel.acceptedDeals) + 1
    rel.totalVolume = safeNumber(rel.totalVolume) + math.max(0, safeNumber(amount))
    rel.rescueDeals = safeNumber(rel.rescueDeals) + 1
    self:adjustPoints(rel, 0.50)
    self:touch(rel)
end

function RFF_LenderRelationshipService:getSummary(farmId, lenderId)
    local rel = self:getRelationship(farmId, lenderId, false) or {
        farmId=farmId, lenderId=lenderId, applications=0, offersMade=0, acceptedDeals=0, totalVolume=0,
        relationshipPoints=0, successfulPayments=0, missedPayments=0, completedAgreements=0,
        forcedRecoveries=0, mortgagePossessions=0, voluntarySurrenders=0, voluntaryPropertySales=0,
        restructures=0, arrearsCured=0, forbearanceArrangements=0, brokenForbearanceArrangements=0, rescueExits=0, rescueDeals=0,
        lastInteractionPeriod=0, proactiveOffersMade=0, proactiveOffersAccepted=0, proactiveOffersDeclined=0, lastProactiveOfferPeriod=0
    }
    local benefits = self:getBenefits(farmId, lenderId)
    return rel, benefits
end

function RFF_LenderRelationshipService:assignLegacyAssetLender(agreement)
    if agreement == nil then return nil end
    if agreement.lenderId ~= nil and agreement.lenderId ~= "" then
        if agreement.lenderNameKey == nil or agreement.lenderNameKey == "" then
            agreement.lenderNameKey = self:getLender(agreement.lenderId).nameKey
        end
        return agreement.lenderId
    end

    -- Asset agreements created before v0.6.0.1 never stored a provider. We cannot reconstruct
    -- the historical lender with certainty, so assign a stable plausible provider once and mark it.
    local grade = agreement.riskGrade or "C"
    local product = agreement.product or "HIRE_PURCHASE"
    local lenderId
    if grade == "D" then
        lenderId = "FRONTIER_CAPITAL"
    elseif grade == "C" then
        lenderId = "AGRIGROWTH_FINANCE"
    elseif product == "HIRE_PURCHASE" then
        lenderId = "COUNTY_COMMERCIAL"
    else
        lenderId = "AGRIGROWTH_FINANCE"
    end
    agreement.lenderId = lenderId
    agreement.lenderNameKey = self:getLender(lenderId).nameKey
    agreement.lenderAssignmentLegacy = true
    return lenderId
end

function RFF_LenderRelationshipService:migrateExistingHistory()
    if self.repository == nil then return end

    local farmIds = {}
    for farmId, _ in pairs(self.repository.farms or {}) do farmIds[farmId] = true end
    for _, loan in ipairs(self.repository.loans or {}) do if safeNumber(loan.farmId) > 0 then farmIds[loan.farmId] = true end end
    for _, agreement in ipairs(self.repository.assetFinance or {}) do
        if safeNumber(agreement.farmId) > 0 then
            farmIds[agreement.farmId] = true
            self:assignLegacyAssetLender(agreement)
        end
    end

    for _, lender in ipairs(self.LENDERS) do
        for farmId, _ in pairs(farmIds) do
            local rel = self:getRelationship(farmId, lender.id, true)
            local schema = safeNumber(rel.relationshipSchemaVersion)

            if schema < 1 then
                local deals, volume, successes, misses, completed = 0, 0, 0, 0, 0
                local possessions, voluntarySales = 0, 0
                for _, loan in ipairs(self.repository.loans or {}) do
                    local loanLender = loan.lenderId or "PRIMARY_BANK"
                    if loan.farmId == farmId and loanLender == lender.id and loan.type ~= RFF_LoanService.TYPE_RECOVERY_SHORTFALL then
                        deals = deals + 1
                        volume = volume + math.max(0, safeNumber(loan.originalAmount))
                        successes = successes + math.max(0, safeNumber(loan.paymentsMade))
                        misses = misses + math.max(0, safeNumber(loan.missedPayments))
                        if loan.paidOff == true and loan.mortgageRecovered ~= true then completed = completed + 1 end
                        if loan.mortgageRecovered == true then
                            if loan.mortgageRecoveryMethod == "MORTGAGE_POSSESSION" then possessions = possessions + 1
                            elseif loan.mortgageRecoveryMethod == "VOLUNTARY_PROPERTY_SALE" then voluntarySales = voluntarySales + 1 end
                        end
                    end
                end
                local missingDeals = math.max(0, deals - safeNumber(rel.acceptedDeals))
                local missingSuccesses = math.max(0, successes - safeNumber(rel.successfulPayments))
                local missingMisses = math.max(0, misses - safeNumber(rel.missedPayments))
                local missingCompleted = math.max(0, completed - safeNumber(rel.completedAgreements))
                local missingPossessions = math.max(0, possessions - safeNumber(rel.mortgagePossessions))
                local missingVoluntarySales = math.max(0, voluntarySales - safeNumber(rel.voluntaryPropertySales))

                rel.acceptedDeals = math.max(safeNumber(rel.acceptedDeals), deals)
                rel.totalVolume = math.max(safeNumber(rel.totalVolume), volume)
                rel.successfulPayments = math.max(safeNumber(rel.successfulPayments), successes)
                rel.missedPayments = math.max(safeNumber(rel.missedPayments), misses)
                rel.completedAgreements = math.max(safeNumber(rel.completedAgreements), completed)
                rel.mortgagePossessions = math.max(safeNumber(rel.mortgagePossessions), possessions)
                rel.voluntaryPropertySales = math.max(safeNumber(rel.voluntaryPropertySales), voluntarySales)
                self:adjustPoints(rel, missingDeals * 3.0 + missingSuccesses * 0.15 - missingMisses * 1.25 + missingCompleted * 1.5 - missingPossessions * 14.0 - missingVoluntarySales * 4.0)
                schema = 1
            end

            if schema < 2 then
                for _, agreement in ipairs(self.repository.assetFinance or {}) do
                    local assetLender = self:assignLegacyAssetLender(agreement)
                    if agreement.farmId == farmId and assetLender == lender.id then
                        if agreement.relationshipDealRecorded ~= true then
                            rel.acceptedDeals = safeNumber(rel.acceptedDeals) + 1
                            local volume = agreement.product == "OPERATING_LEASE" and math.max(0, safeNumber(agreement.basePrice)) or math.max(0, safeNumber(agreement.originalFinanced))
                            rel.totalVolume = safeNumber(rel.totalVolume) + volume
                            self:adjustPoints(rel, 3.0)
                            agreement.relationshipDealRecorded = true
                        end

                        local successful = math.max(0, safeNumber(agreement.paymentsMade))
                        local missed = math.max(0, safeNumber(agreement.missedPayments))
                        rel.successfulPayments = safeNumber(rel.successfulPayments) + successful
                        rel.missedPayments = safeNumber(rel.missedPayments) + missed
                        self:adjustPoints(rel, successful * 0.15 - missed * 1.25)

                        if agreement.status == "COMPLETED" or agreement.status == "RETURNED" then
                            rel.completedAgreements = safeNumber(rel.completedAgreements) + 1
                            self:adjustPoints(rel, 1.5)
                            agreement.relationshipCompletionRecorded = true
                        elseif agreement.status == "RECOVERED" then
                            rel.forcedRecoveries = safeNumber(rel.forcedRecoveries) + 1
                            self:adjustPoints(rel, -6.0)
                            agreement.relationshipRecoveryRecorded = true
                        elseif agreement.status == "SURRENDERED" then
                            rel.voluntarySurrenders = safeNumber(rel.voluntarySurrenders) + 1
                            self:adjustPoints(rel, -3.0)
                            agreement.relationshipRecoveryRecorded = true
                        end
                    end
                end
                schema = 2
            end

            rel.relationshipSchemaVersion = schema
        end
    end
end
