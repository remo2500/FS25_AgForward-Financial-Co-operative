-- Capital-safe deposits. Transfers are not trading income; only paid interest
-- uses the bank-interest money type. Every deposit has its own withdrawal terms.
RFF_SavingsService={}
RFF_SavingsService.__index=RFF_SavingsService
local S=RFF_SavingsService
S.PRODUCTS={
    {id="EASY",name="Easy-access savings",months=0},
    {id="NOTICE",name="One-month notice savings",months=0},
    {id="FIXED6",name="6-month fixed deposit",months=6},
    {id="FIXED12",name="12-month fixed deposit",months=12},
    {id="FIXED24",name="24-month fixed deposit",months=24}
}
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<math.huge end
local function round(n) return math.floor(n*100+.5)/100 end
local function server() return g_currentMission~=nil and g_currentMission:getIsServer() end
local function farm(id) return g_farmManager~=nil and g_farmManager:getFarmById(id) or nil end
function S.new(repository)
    local self=setmetatable({repository=repository,timer=0},S)
    repository.savingsService=self
    local modName=RFF_RealisticFarmFinance~=nil and RFF_RealisticFarmFinance.modName or g_currentModName
    self.transferType=MoneyType~=nil and MoneyType.register~=nil and MoneyType.register("rffSavingsTransfer","rff_savings_transfer",modName) or nil
    return self
end
function S:clock()
    local env=g_currentMission~=nil and g_currentMission.environment or nil
    local p=self.repository:getCurrentPeriodIndex()
    if env==nil then return p end
    return p+math.min(.99999999,((env.currentDayInPeriod or 1)-1+(env.dayTime or 0)/86400000)/math.max(1,env.daysPerPeriod or 1))
end
function S.product(id)
    for _,p in ipairs(S.PRODUCTS) do if p.id==id then return p end end
end
function S:rate(product,period)
    local e=self.repository.economyState
    local base=e and e.baseRate or 5.5
    if period~=nil and e~=nil and period<e.period then
        for _,h in ipairs(e.history or {}) do if h.period==period then base=h.baseRate;break end end
    end
    local easy=math.max(.5,base-2.5)
    if product=="EASY" then return round(easy) end
    if product=="NOTICE" then return round(easy+.75) end
    local p=S.product(product)
    if p==nil then return nil end
    local months=p.months
    local outlook=base
    if e~=nil and RFF_EconomyService~=nil then outlook=RFF_EconomyService.forecast(e,months).baseRate end
    -- A falling expected rate path can flatten/invert term offers. No future shocks consulted.
    local termPremium=({[6]=1.25,[12]=1.75,[24]=2.25})[months] or 0
    return round(math.max(.75,(base+outlook)/2-2.5+termPremium))
end
function S:records(farmId)
    local list={}
    for _,a in ipairs(self.repository.savings or {}) do if a.farmId==farmId then list[#list+1]=a end end
    return list
end
function S:find(farmId,id)
    for _,a in ipairs(self:records(farmId)) do if a.id==id then return a end end
end
function S:accrue(a,now)
    if a.status=="CLOSED" then return end
    local stop=a.due>0 and math.min(now,a.due) or now
    local t=a.lastAccrued
    while t<stop-.000000001 do
        local ending=math.min(stop,math.floor(t)+1)
        local rate=S.product(a.product).months>0 and a.rate or self:rate(a.product,math.floor(t))
        a.interest=a.interest+a.principal*rate/100/12*(ending-t)
        t=ending
    end
    a.lastAccrued=math.max(a.lastAccrued,stop)
end
function S:total(farmId)
    local total=0
    for _,a in ipairs(self:records(farmId)) do if a.status~="CLOSED" then total=total+a.principal+a.interest end end
    return total
end
function S:money(farmId,amount,description,interest)
    self.repository:setNextTransactionDescription(farmId,description)
    local kind=interest and MoneyType~=nil and (MoneyType.INTEREST_PAID or MoneyType.OTHER) or self.transferType
    g_currentMission:addMoney(amount,farmId,kind,true,true)
end
function S:open(farmId,product,amount,expectedRate)
    if not server() or not self.repository.loaded then return nil,"Savings are not ready." end
    local f,p=farm(farmId),S.product(product)
    if f==nil or farmId<=0 or p==nil or not finite(amount) or amount<100 or amount>10000000 then return nil,"Enter a deposit between 100 and 10,000,000." end
    amount=round(amount)
    if amount>math.max(0,f.money) then return nil,"Insufficient cash. An overdraft cannot fund a savings deposit." end
    local rate=self:rate(product)
    if expectedRate~=nil and math.abs(rate-expectedRate)>.0001 then return nil,"The quoted rate changed. Please review the new offer." end
    local records=self.repository.savings or {};self.repository.savings=records
    local id=0;for _,a in ipairs(records) do id=math.max(id,a.id) end
    local now=self:clock()
    local a={id=id+1,farmId=farmId,product=product,principal=amount,rate=rate,interest=0,opened=now,lastAccrued=now,
        due=p.months>0 and now+p.months or 0,status="ACTIVE",closed=0,paidInterest=0}
    records[#records+1]=a
    self:money(farmId,-amount,"Savings deposit S-"..a.id.." - "..p.name,false)
    return a
end
function S:close(a,now)
    if a.status=="CLOSED" or farm(a.farmId)==nil then return false end
    self:accrue(a,now)
    a.paidInterest=round(a.interest);a.status="CLOSED";a.closed=now
    self:money(a.farmId,a.principal,"Savings principal returned S-"..a.id,false)
    if a.paidInterest>0 then self:money(a.farmId,a.paidInterest,"Savings interest S-"..a.id,true) end
    if RFF_NotificationService~=nil then
        RFF_NotificationService:send(a.farmId,"Primary Farm Bank","Savings returned",string.format("S-%d: %.2f principal and %.2f interest returned to your current account. View Banking - Savings for the record.",a.id,a.principal,a.paidInterest),"banking",nil,true)
    end
    return true
end
function S:withdraw(farmId,id)
    if not server() or not self.repository.loaded then return false,"Savings are not ready." end
    local a=self:find(farmId,id)
    if a==nil or a.status=="CLOSED" then return false,"This deposit is no longer available." end
    local now=self:clock();self:accrue(a,now)
    if a.product=="NOTICE" and a.status=="ACTIVE" then
        a.status="NOTICE";a.due=now+1
        return true,"Notice lodged. The full balance and interest will return automatically after one game month."
    end
    if a.due>now then return false,"This deposit remains locked until "..self:date(a.due).."." end
    if self:close(a,now) then return true,"Savings returned to your current account." end
    return false,"Farm account unavailable. The deposit remains safe."
end
function S:process()
    if not server() or not self.repository.loaded then return end
    local now=self:clock()
    for _,a in ipairs(self.repository.savings or {}) do
        self:accrue(a,now)
        if a.status~="CLOSED" and a.due>0 and now>=a.due then self:close(a,now) end
    end
end
function S:update(dt)
    self.timer=self.timer-(dt or 0);if self.timer>0 then return end
    self.timer=1000;self:process()
end
function S:date(time)
    local env=g_currentMission~=nil and g_currentMission.environment or nil
    local days=math.max(1,env and env.daysPerPeriod or 1)
    local fraction=time-math.floor(time)
    local minutes=math.floor(fraction*days*1440+.00001)
    return string.format("%s, day %d %02d:%02d",RFF_EconomyService.date(math.floor(time)),math.floor(minutes/1440)+1,math.floor(minutes/60)%24,minutes%60)
end
local FIELDS={"id","farmId","principal","rate","interest","opened","lastAccrued","due","closed","paidInterest"}
function S.save(repository,xml)
    for i,a in ipairs(repository.savings or {}) do
        local key="realisticFarmFinance.savings.deposit("..(i-1)..")"
        for _,field in ipairs(FIELDS) do xml:setString(key.."#"..field,string.format("%.17g",a[field])) end
        xml:setString(key.."#product",a.product);xml:setString(key.."#status",a.status)
    end
end
function S.load(repository,xml)
    repository.savings={};local ids={};local i=0
    while xml:hasProperty("realisticFarmFinance.savings.deposit("..i..")") do
        local key="realisticFarmFinance.savings.deposit("..i..")";local a={};local valid=true
        for _,field in ipairs(FIELDS) do a[field]=tonumber(xml:getString(key.."#"..field));valid=valid and finite(a[field]) end
        a.product=xml:getString(key.."#product");a.status=xml:getString(key.."#status")
        valid=valid and S.product(a.product)~=nil and (a.status=="ACTIVE" or a.status=="NOTICE" or a.status=="CLOSED")
        if valid and a.id>0 and a.id%1==0 and not ids[a.id] and a.farmId>0 and a.principal>0 and a.interest>=0 and a.rate>=0 and a.rate<=20 and a.lastAccrued>=a.opened then
            ids[a.id]=true;repository.savings[#repository.savings+1]=a
        else print("[RFF savings] Invalid or duplicate deposit record "..i.." ignored; restore a backup if this was unexpected.") end
        i=i+1
    end
end
function S:consoleStatus()
    if not server() then return "Server only." end
    self:process()
    for _,a in ipairs(self:records(g_currentMission:getFarmId())) do
        print(string.format("[RFF savings] S-%d %s %s principal=%.2f interest=%.2f rate=%.2f due=%s",a.id,a.product,a.status,a.principal,a.interest,a.rate,a.due>0 and self:date(a.due) or "On demand"))
    end
    return "Savings records printed. No test money or time changes."
end
