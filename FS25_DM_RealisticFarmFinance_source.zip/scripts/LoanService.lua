RFF_LoanService = {}
RFF_LoanService.__index = RFF_LoanService

RFF_LoanService.TYPE_TERM = "TERM"
RFF_LoanService.TYPE_BULLET = "BULLET"
RFF_LoanService.TYPE_REVOLVING = "REVOLVING"
RFF_LoanService.TYPE_OVERDRAFT = "OVERDRAFT"
RFF_LoanService.TYPE_MORTGAGE = "MORTGAGE"
RFF_LoanService.TYPE_RECOVERY_SHORTFALL = "RECOVERY_SHORTFALL"

RFF_LoanService.BASE_RATE = 5.50
RFF_LoanService.RECOVERY_ADMIN_CHARGE = 25
RFF_LoanService.LEGACY_MIGRATION_VERSION = 2
RFF_LoanService.LEGACY_TERM_MONTHS = 60
RFF_LoanService.LEGACY_GRADE = "C"
RFF_LoanService.PRODUCT_SPREAD = {
    [RFF_LoanService.TYPE_TERM] = 0.00,
    [RFF_LoanService.TYPE_BULLET] = 0.50,
    [RFF_LoanService.TYPE_REVOLVING] = 1.00,
    [RFF_LoanService.TYPE_OVERDRAFT] = 1.75,
    [RFF_LoanService.TYPE_MORTGAGE] = -0.25
}
RFF_LoanService.GRADE_SPREAD = {
    A = 0.50,
    B = 1.00,
    C = 2.00,
    D = 3.50
}

local function safeNumber(value)
    if type(value) == "number" and value == value then
        return value
    end
    return 0
end

local function getFarm(farmId)
    return g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
end

local function getLoanPrincipalMoneyType()
    if MoneyType ~= nil then
        return MoneyType.LOAN_PRINCIPAL or MoneyType.OTHER
    end
    return nil
end

local function getLoanInterestMoneyType()
    if MoneyType ~= nil then
        return MoneyType.LOAN_INTEREST or MoneyType.OTHER
    end
    return nil
end

function RFF_LoanService.new(repository)
    local self = setmetatable({}, RFF_LoanService)
    self.repository = repository
    self.relationshipService = nil
    return self
end

function RFF_LoanService:setRelationshipService(service)
    self.relationshipService = service
end

function RFF_LoanService:setForbearanceService(service)
    self.forbearanceService = service
end

function RFF_LoanService:recordRelationshipCompletion(loan)
    if loan == nil or loan.relationshipCompletionRecorded == true then return end
    if self.relationshipService ~= nil then self.relationshipService:recordAgreementCompleted(loan) end
    loan.relationshipCompletionRecorded = true
end

function RFF_LoanService:getBaseRate()
    local state = self.repository ~= nil and self.repository.economyState or nil
    return state ~= nil and state.baseRate or self.BASE_RATE
end

function RFF_LoanService:calculateAnnuityPayment(amount, annualRate, months)
    amount = math.max(0, safeNumber(amount))
    months = math.max(1, math.floor(safeNumber(months)))
    local monthlyRate = safeNumber(annualRate) / 100 / 12
    if monthlyRate <= 0 then
        return amount / months
    end
    local factor = (1 + monthlyRate) ^ months
    return amount * monthlyRate * factor / (factor - 1)
end

function RFF_LoanService:calculateMonthlyPayment(amount, annualRate, months, loanType)
    if loanType == self.TYPE_TERM or loanType == self.TYPE_MORTGAGE then
        return self:calculateAnnuityPayment(amount, annualRate, months)
    elseif loanType == self.TYPE_BULLET then
        return amount * (annualRate / 100) / 12
    elseif loanType == self.TYPE_REVOLVING or loanType == self.TYPE_OVERDRAFT then
        -- Revolving/overdraft affordability is assessed against interest on the full approved limit.
        return amount * (annualRate / 100) / 12
    end
    return 0
end

function RFF_LoanService:getOutstandingBalance(farmId)
    return self.repository ~= nil and self.repository:getOutstandingLoanBalance(farmId) or 0
end

function RFF_LoanService:getMonthlyDebtService(farmId)
    if self.repository == nil then
        return 0
    end

    local total = 0
    local banking=self.repository.bankingService
    if banking then total=banking:getProjectedMonthlyDebitCost(farmId,true) end
    for _, loan in ipairs(self.repository:getLoansByFarm(farmId, true)) do
        if loan.type == self.TYPE_OVERDRAFT and banking then
            -- Already included, along with any borrowing without a facility.
        elseif loan.type == self.TYPE_REVOLVING or loan.type == self.TYPE_OVERDRAFT then
            local utilised = math.max(0, safeNumber(loan.drawnAmount))
            local rate = safeNumber(loan.interestRate)
            if loan.type == self.TYPE_OVERDRAFT and self.repository.getBankAccountLiability ~= nil then
                utilised = self.repository:getBankAccountLiability(farmId)
                if loan.overdraftSuspended == true then rate = rate + 3.00 end
            end
            total = total + utilised * (rate / 100) / 12
        elseif safeNumber(loan.remainingMonths) <= 0 then
            -- The contractual schedule has ended. Any unpaid amount is arrears rather than a future instalment.
        elseif loan.type == self.TYPE_BULLET then
            total = total + safeNumber(loan.principal) * (safeNumber(loan.interestRate) / 100) / 12
        else
            total = total + safeNumber(loan.monthlyPayment)
        end
    end
    if self.repository.getAssetFinanceByFarm ~= nil then
        for _, agreement in ipairs(self.repository:getAssetFinanceByFarm(farmId, true)) do
            if agreement.status == "ACTIVE" and safeNumber(agreement.remainingMonths) > 0 then
                total = total + math.max(0, safeNumber(agreement.monthlyPayment))
            end
        end
    end
    return total
end

function RFF_LoanService:getActiveFacilityCount(farmId)
    if self.repository == nil then return 0 end
    local count = 0
    for _, loan in ipairs(self.repository:getLoansByFarm(farmId, true)) do
        if loan.type ~= self.TYPE_RECOVERY_SHORTFALL then count = count + 1 end
    end
    return count
end

function RFF_LoanService:getMostRecentActiveLoan(farmId)
    if self.repository == nil then
        return nil
    end
    local loans = self.repository:getLoansByFarm(farmId, true)
    local latest = nil
    for _, loan in ipairs(loans) do
        if loan.type ~= self.TYPE_RECOVERY_SHORTFALL and (latest == nil or safeNumber(loan.id) > safeNumber(latest.id)) then
            latest = loan
        end
    end
    return latest
end

function RFF_LoanService:getMostRecentRevolving(farmId)
    if self.repository == nil then
        return nil
    end
    local latest = nil
    for _, loan in ipairs(self.repository:getLoansByFarm(farmId, true)) do
        if loan.type == self.TYPE_REVOLVING and (latest == nil or safeNumber(loan.id) > safeNumber(latest.id)) then
            latest = loan
        end
    end
    return latest
end

function RFF_LoanService:getMostRecentOverdraft(farmId)
    if self.repository == nil then return nil end
    return self.repository.getActiveOverdraft ~= nil and self.repository:getActiveOverdraft(farmId) or nil
end

function RFF_LoanService:getProductSpread(loanType)
    return self.PRODUCT_SPREAD[loanType] or 0
end

function RFF_LoanService:getPricingSpread(grade)
    local state = self.repository ~= nil and self.repository.economyState or nil
    return self:getGradeSpread(grade) + (state ~= nil and state.credit or 0)
end

function RFF_LoanService:getGradeSpread(grade)
    return self.GRADE_SPREAD[grade] or 0
end

function RFF_LoanService:getPaymentConduct(farmId)
    if RFF_PaymentConduct == nil then return nil end
    return RFF_PaymentConduct:evaluate(self.repository, farmId)
end

function RFF_LoanService:getConductRateAdjustment(farmId)
    local conduct = self:getPaymentConduct(farmId)
    return conduct ~= nil and safeNumber(conduct.rateAdjustment) or 0
end

function RFF_LoanService:applyConductToGrade(farmId, grade)
    local conduct = self:getPaymentConduct(farmId)
    if conduct == nil or RFF_PaymentConduct == nil then return grade, conduct end
    return RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade), conduct
end

function RFF_LoanService:scoreStartup(ltv)
    if ltv <= 0.30 then return "A" end
    if ltv <= 0.45 then return "B" end
    if ltv <= 0.55 then return "C" end
    if ltv <= 0.65 then return "D" end
    return nil
end

function RFF_LoanService:scoreDeveloping(dscr, ltv, hasIncome)
    if not hasIncome then
        if ltv <= 0.35 then return "B" end
        if ltv <= 0.45 then return "C" end
        if ltv <= 0.55 then return "D" end
        return nil
    end

    if dscr >= 1.50 and ltv <= 0.55 then return "A" end
    if dscr >= 1.25 and ltv <= 0.65 then return "B" end
    if dscr >= 1.00 and ltv <= 0.75 then return "C" end
    if dscr >= 0.80 and ltv <= 0.85 then return "D" end
    return nil
end

function RFF_LoanService:scoreEstablished(dscr, ltv)
    if dscr >= 1.50 and ltv <= 0.60 then return "A" end
    if dscr >= 1.25 and ltv <= 0.75 then return "B" end
    if dscr >= 1.00 and ltv <= 0.85 then return "C" end
    if dscr >= 0.80 and ltv <= 0.90 then return "D" end
    return nil
end

function RFF_LoanService:evaluateApplication(farmId, amount, months, loanType, valuation, credit, context)
    context = context or {}
    amount = math.max(0, safeNumber(amount))
    months = math.max(1, math.floor(safeNumber(months)))

    local result = {
        approved = false,
        reason = "invalid",
        amount = amount,
        months = months,
        loanType = loanType,
        baseRate = self:getBaseRate(),
        grade = nil,
        interestRate = 0,
        monthlyPayment = 0,
        dscr = nil,
        ltv = math.huge,
        totalDebtService = 0,
        paymentConduct = nil,
        conductRateAdjustment = 0
    }

    if farmId == nil or farmId <= 0 or amount < 1000 or valuation == nil or credit == nil then
        return result
    end

    if loanType == self.TYPE_OVERDRAFT then
        months = 12
        result.months = 12
        if self.repository ~= nil and self.repository.getActiveOverdraft ~= nil and self.repository:getActiveOverdraft(farmId) ~= nil then
            result.reason = "overdraft_exists"
            return result
        end
    end

    local conduct = self:getPaymentConduct(farmId)
    result.paymentConduct = conduct
    result.conductRateAdjustment = conduct ~= nil and safeNumber(conduct.rateAdjustment) or 0
    if conduct ~= nil and conduct.declineNewCredit then
        result.reason = "payment_conduct"
        return result
    end

    local collateral = math.max(0, safeNumber(credit.collateral))
    local excludedLiabilities = math.max(0, safeNumber(context.excludedLiabilities))
    local excludedDebtService = math.max(0, safeNumber(context.excludedDebtService))
    local existingDebt = math.max(0, safeNumber(valuation.liabilities) - excludedLiabilities)
    if collateral <= 0 then
        result.reason = "no_collateral"
        return result
    end

    result.ltv = (existingDebt + amount) / collateral

    local productSpread = self:getProductSpread(loanType)
    local provisionalRate = self:getBaseRate() + productSpread + self:getPricingSpread("B") + result.conductRateAdjustment
    local candidatePayment = self:calculateMonthlyPayment(amount, provisionalRate, months, loanType)
    local tenancyRent = self.repository ~= nil and self.repository:getMonthlyTenancyRent(farmId) or 0
    local additionalDebtService = math.max(0, safeNumber(context.additionalDebtService))
    local existingDebtService = math.max(0, self:getMonthlyDebtService(farmId) + tenancyRent - excludedDebtService + additionalDebtService)
    result.existingDebtService = existingDebtService
    result.excludedLiabilities = excludedLiabilities
    result.excludedDebtService = excludedDebtService
    local totalDebtService = existingDebtService + candidatePayment
    local monthlyIncome = math.max(0, safeNumber(credit.monthlyIncome))
    local hasIncome = monthlyIncome > 0
    local dscr = totalDebtService > 0 and monthlyIncome / totalDebtService or math.huge
    result.dscr = dscr
    result.totalDebtService = totalDebtService

    local trackedPeriods = safeNumber(credit.trackedPeriods)
    local grade = nil
    if trackedPeriods < 3 then
        grade = self:scoreStartup(result.ltv)
        result.dscr = nil
    elseif trackedPeriods < 12 then
        grade = self:scoreDeveloping(dscr, result.ltv, hasIncome)
    else
        grade = self:scoreEstablished(dscr, result.ltv)
    end

    if grade == nil then
        result.reason = trackedPeriods < 3 and "startup_ltv" or "affordability"
        return result
    end

    if conduct ~= nil and RFF_PaymentConduct ~= nil then
        grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade)
    end

    local finalRate = self:getBaseRate() + productSpread + self:getPricingSpread(grade) + result.conductRateAdjustment
    local finalPayment = self:calculateMonthlyPayment(amount, finalRate, months, loanType)
    local finalTotalDebtService = existingDebtService + finalPayment
    local finalDscr = finalTotalDebtService > 0 and monthlyIncome / finalTotalDebtService or math.huge

    -- One conservative re-score after risk pricing increases the rate.
    if trackedPeriods >= 3 and hasIncome then
        local revisedGrade
        if trackedPeriods < 12 then
            revisedGrade = self:scoreDeveloping(finalDscr, result.ltv, true)
        else
            revisedGrade = self:scoreEstablished(finalDscr, result.ltv)
        end

        if revisedGrade == nil then
            result.reason = "affordability_after_pricing"
            result.interestRate = finalRate
            result.monthlyPayment = finalPayment
            result.dscr = finalDscr
            result.totalDebtService = finalTotalDebtService
            return result
        end

        if conduct ~= nil and RFF_PaymentConduct ~= nil then
            revisedGrade = RFF_PaymentConduct:capGrade(revisedGrade, conduct.minimumGrade)
        end

        if revisedGrade ~= grade then
            grade = revisedGrade
            finalRate = self:getBaseRate() + productSpread + self:getPricingSpread(grade) + result.conductRateAdjustment
            finalPayment = self:calculateMonthlyPayment(amount, finalRate, months, loanType)
            finalTotalDebtService = existingDebtService + finalPayment
            finalDscr = finalTotalDebtService > 0 and monthlyIncome / finalTotalDebtService or math.huge
        end
    end

    result.approved = true
    result.reason = "approved"
    result.grade = grade
    result.interestRate = finalRate
    result.monthlyPayment = finalPayment
    result.totalDebtService = finalTotalDebtService
    if trackedPeriods >= 3 and hasIncome then
        result.dscr = finalDscr
    end
    return result
end

function RFF_LoanService:createLoan(farmId, amount, months, loanType, purpose, valuation, credit)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then
        return nil, {approved = false, reason = "server_only"}
    end

    local evaluation = self:evaluateApplication(farmId, amount, months, loanType, valuation, credit)
    if not evaluation.approved then
        return nil, evaluation
    end

    local currentPeriod = self.repository:getCurrentPeriodIndex()
    local loan = {
        id = self.repository:getNextLoanId(),
        farmId = farmId,
        type = loanType,
        purpose = purpose or "GENERAL",
        originalAmount = amount,
        creditLimit = (loanType == self.TYPE_REVOLVING or loanType == self.TYPE_OVERDRAFT) and amount or 0,
        principal = (loanType == self.TYPE_REVOLVING or loanType == self.TYPE_OVERDRAFT) and 0 or amount,
        drawnAmount = 0,
        interestRate = evaluation.interestRate,
        termMonths = loanType == self.TYPE_REVOLVING and 0 or (loanType == self.TYPE_OVERDRAFT and 12 or months),
        remainingMonths = loanType == self.TYPE_REVOLVING and 0 or (loanType == self.TYPE_OVERDRAFT and 12 or months),
        monthlyPayment = (loanType == self.TYPE_REVOLVING or loanType == self.TYPE_OVERDRAFT) and 0 or evaluation.monthlyPayment,
        riskGrade = evaluation.grade,
        createdPeriod = currentPeriod,
        lastPaymentPeriod = currentPeriod,
        paymentsMade = 0,
        missedPayments = 0,
        arrearsPrincipal = 0,
        arrearsInterest = 0,
        arrearsRent = 0,
        arrearsFees = 0,
        arrearsBalance = 0,
        arrearsAgeMonths = 0,
        arrearsStage = "CURRENT",
        defaultInterestAccrued = 0,
        adminChargesAccrued = 0,
        defaultEvents = 0,
        currentDefault = false,
        defaultRecorded = false,
        recoveryEligible = false,
        lastDefaultManagementPeriod = currentPeriod,
        consecutiveMissedPayments = 0,
        maxConsecutiveMissedPayments = 0,
        lastMissedPeriod = 0,
        lastSuccessfulPaymentPeriod = currentPeriod,
        lastArrearsClearedPeriod = 0,
        arrearsSchemaVersion = 1,
        principalPaid = 0,
        interestPaid = 0,
        completedPeriod = 0,
        paidOff = false,
        lenderId = "PRIMARY_BANK",
        lenderNameKey = "rff_lender_primary_bank",
        brokered = false,
        brokerCaseId = 0,
        arrangementFee = 0,
        brokerFee = 0,
        overdraftSuspended = false,
        overdraftOverLimit = 0,
        overdraftLimitBreaches = 0,
        lastOverdraftBreachPeriod = 0,
        overdraftReviewCount = 0,
        overdraftWarningTwoMonths = false,
        overdraftWarningOneMonth = false,
        forbearanceCount = 0,
        forbearanceLastPeriod = 0,
        forbearanceLastType = "",
        forbearanceMode = "",
        forbearanceRemainingPeriods = 0,
        forbearanceCapitalisedArrears = 0,
        forbearanceCapitalisedInterest = 0,
        forbearanceOriginalPayment = 0,
        forbearanceOriginalRate = 0,
        forbearanceBroken = false,
        forbearanceOfferStatus = "",
        forbearanceOfferType = "",
        forbearanceOfferCreatedPeriod = 0,
        forbearanceOfferExpiryPeriod = 0,
        forbearanceOfferLastPeriod = 0
    }

    self.repository:addLoan(loan)

    if loanType ~= self.TYPE_REVOLVING and loanType ~= self.TYPE_OVERDRAFT then
        g_currentMission:addMoney(amount, farmId, getLoanPrincipalMoneyType(), true, true)
    end

    return loan, evaluation
end

function RFF_LoanService:createLoanFromOffer(farmId, amount, months, loanType, purpose, offer, options)
    options = options or {}
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then
        return nil, "server_only"
    end
    if offer == nil or offer.approved ~= true then
        return nil, "invalid_offer"
    end

    amount = math.max(0, safeNumber(amount))
    months = math.max(1, math.floor(safeNumber(months)))
    if farmId == nil or farmId <= 0 or amount < (options.allowSmallBalance == true and 0.01 or 1000) then
        return nil, "invalid"
    end

    -- A formal offer is still subject to the farm remaining in good standing until drawdown.
    if loanType == self.TYPE_OVERDRAFT and self.repository.getActiveOverdraft ~= nil and self.repository:getActiveOverdraft(farmId) ~= nil then
        return nil, "overdraft_exists"
    end
    local conduct = self:getPaymentConduct(farmId)
    if conduct ~= nil and conduct.declineNewCredit and options.allowDistressedCredit ~= true then
        return nil, "payment_conduct"
    end

    local currentPeriod = self.repository:getCurrentPeriodIndex()
    local loan = {
        id = self.repository:getNextLoanId(),
        farmId = farmId,
        type = loanType,
        purpose = purpose or "GENERAL",
        originalAmount = amount,
        creditLimit = (loanType == self.TYPE_REVOLVING or loanType == self.TYPE_OVERDRAFT) and amount or 0,
        principal = (loanType == self.TYPE_REVOLVING or loanType == self.TYPE_OVERDRAFT) and 0 or amount,
        drawnAmount = 0,
        interestRate = safeNumber(offer.interestRate),
        termMonths = loanType == self.TYPE_REVOLVING and 0 or (loanType == self.TYPE_OVERDRAFT and 12 or months),
        remainingMonths = loanType == self.TYPE_REVOLVING and 0 or (loanType == self.TYPE_OVERDRAFT and 12 or months),
        monthlyPayment = (loanType == self.TYPE_REVOLVING or loanType == self.TYPE_OVERDRAFT) and 0 or safeNumber(offer.monthlyPayment),
        riskGrade = offer.grade or "C",
        createdPeriod = currentPeriod,
        lastPaymentPeriod = currentPeriod,
        paymentsMade = 0,
        missedPayments = 0,
        arrearsPrincipal = 0,
        arrearsInterest = 0,
        arrearsRent = 0,
        arrearsFees = 0,
        arrearsBalance = 0,
        arrearsAgeMonths = 0,
        arrearsStage = "CURRENT",
        defaultInterestAccrued = 0,
        adminChargesAccrued = 0,
        defaultEvents = 0,
        currentDefault = false,
        defaultRecorded = false,
        recoveryEligible = false,
        lastDefaultManagementPeriod = currentPeriod,
        consecutiveMissedPayments = 0,
        maxConsecutiveMissedPayments = 0,
        lastMissedPeriod = 0,
        lastSuccessfulPaymentPeriod = currentPeriod,
        lastArrearsClearedPeriod = 0,
        arrearsSchemaVersion = 1,
        principalPaid = 0,
        interestPaid = 0,
        completedPeriod = 0,
        paidOff = false,
        lenderId = offer.lenderId or "PRIMARY_BANK",
        lenderNameKey = offer.lenderNameKey or "rff_lender_primary_bank",
        brokered = offer.brokered == true,
        brokerCaseId = offer.brokerCaseId or 0,
        arrangementFee = safeNumber(offer.arrangementFee),
        brokerFee = safeNumber(offer.brokerFee),
        overdraftSuspended = false,
        overdraftOverLimit = 0,
        overdraftLimitBreaches = 0,
        lastOverdraftBreachPeriod = 0,
        overdraftReviewCount = 0,
        overdraftWarningTwoMonths = false,
        overdraftWarningOneMonth = false
    }

    self.repository:addLoan(loan)
    if options.disburse ~= false and loanType ~= self.TYPE_REVOLVING and loanType ~= self.TYPE_OVERDRAFT then
        g_currentMission:addMoney(amount, farmId, getLoanPrincipalMoneyType(), true, true)
    end
    return loan, nil
end

function RFF_LoanService:canAfford(farmId, amount)
    amount = math.max(0, safeNumber(amount))
    if self.repository ~= nil and self.repository.getAvailableFunds ~= nil then
        return self.repository:getAvailableFunds(farmId) >= amount
    end
    local farm = getFarm(farmId)
    return farm ~= nil and safeNumber(farm.money) >= amount
end

function RFF_LoanService:charge(farmId, amount, moneyType)
    amount = math.max(0, safeNumber(amount))
    if amount <= 0 then
        return
    end
    g_currentMission:addMoney(-amount, farmId, moneyType, true, true)
end

function RFF_LoanService:notifyMissedPayment(loan, amount)
    if g_currentMission == nil then return end
    local text = string.format(g_i18n:getText("rff_payment_missed_notification"),
        self:getLoanDisplayName(loan), g_i18n:formatMoney(math.max(0, safeNumber(amount)), 0, true, true),
        g_i18n:formatMoney(math.max(0, safeNumber(loan.arrearsBalance)), 0, true, true))

    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(loan ~= nil and loan.lenderNameKey or nil, "Primary Farm Bank")
        local title = RFF_NotificationService:getText("rff_phone_title_payment", "Payment Missed")
        if RFF_NotificationService:send(loan ~= nil and loan.farmId or 0, sender, title, text, "payment", text, true) then return end
    end

    if g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, text)
    end
end

function RFF_LoanService:getLoanDisplayName(loan)
    if loan == nil then return "Finance agreement" end
    if loan.legacyImported == true then return "Legacy Farm Loan" end
    if loan.type == self.TYPE_MORTGAGE then return "Agricultural mortgage" end
    if loan.type == self.TYPE_RECOVERY_SHORTFALL then
        if loan.sourceRecoveryType == "PROPERTY" then return "Property recovery shortfall" end
        return "Asset recovery shortfall"
    end
    if loan.type == self.TYPE_BULLET then return "Interest-only / bullet loan" end
    if loan.type == self.TYPE_REVOLVING then return "Revolving credit facility" end
    if loan.type == self.TYPE_OVERDRAFT then return "Overdraft facility" end
    return "Farm term loan"
end

-- Import the pre-RFF Farming Simulator loan exactly once. This must be called at
-- Mission00.onStartMission (not loadItemsFinished): the base game has restored the
-- farm's native loan by that lifecycle point. Enhanced Loan System uses the same
-- proven timing for its vanilla-loan conversion. The vanilla loan only exposes an
-- outstanding balance, not a reliable historic term/rate/payment schedule, so
-- migration creates a neutral 60-month RFF term agreement from the current period.
-- No cash moves: this is a liability transfer, not a repayment or a new advance.
function RFF_LoanService:migrateVanillaLoan(farmId)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then
        return false, "server_only"
    end

    farmId = tonumber(farmId) or (g_currentMission.getFarmId ~= nil and g_currentMission:getFarmId() or 0)
    if farmId == nil or farmId <= 0 then return false, "invalid_farm" end

    local state = self.repository:getFarmState(farmId, true)
    if state == nil then return false, "missing_state" end
    if safeNumber(state.legacyLoanMigrationVersion) >= self.LEGACY_MIGRATION_VERSION then
        return false, "already_migrated"
    end

    local farm = getFarm(farmId)
    if farm == nil then return false, "missing_farm" end

    local amount = math.max(0, safeNumber(farm.loan))
    if amount <= 0.01 then
        state.legacyLoanMigrationVersion = self.LEGACY_MIGRATION_VERSION
        state.legacyLoanImportedAmount = 0
        state.legacyLoanImportedId = 0
        return false, "no_vanilla_loan"
    end

    local currentPeriod = self.repository:getCurrentPeriodIndex()
    local months = self.LEGACY_TERM_MONTHS
    local grade = self.LEGACY_GRADE
    local annualRate = self.BASE_RATE + (self.PRODUCT_SPREAD[self.TYPE_TERM] or 0) + self:getGradeSpread(grade)
    local monthlyPayment = self:calculateMonthlyPayment(amount, annualRate, months, self.TYPE_TERM)

    local loan = {
        id = self.repository:getNextLoanId(),
        farmId = farmId,
        type = self.TYPE_TERM,
        purpose = "LEGACY_FINANCE",
        originalAmount = amount,
        creditLimit = 0,
        principal = amount,
        drawnAmount = 0,
        interestRate = annualRate,
        termMonths = months,
        remainingMonths = months,
        monthlyPayment = monthlyPayment,
        riskGrade = grade,
        createdPeriod = currentPeriod,
        lastPaymentPeriod = currentPeriod,
        paymentsMade = 0,
        missedPayments = 0,
        arrearsPrincipal = 0,
        arrearsInterest = 0,
        arrearsRent = 0,
        arrearsFees = 0,
        arrearsBalance = 0,
        arrearsAgeMonths = 0,
        arrearsStage = "CURRENT",
        defaultInterestAccrued = 0,
        adminChargesAccrued = 0,
        defaultEvents = 0,
        currentDefault = false,
        defaultRecorded = false,
        recoveryEligible = false,
        lastDefaultManagementPeriod = currentPeriod,
        consecutiveMissedPayments = 0,
        maxConsecutiveMissedPayments = 0,
        lastMissedPeriod = 0,
        lastSuccessfulPaymentPeriod = currentPeriod,
        lastArrearsClearedPeriod = 0,
        arrearsSchemaVersion = 1,
        principalPaid = 0,
        interestPaid = 0,
        completedPeriod = 0,
        paidOff = false,
        legacyImported = true,
        lenderId = "PRIMARY_BANK",
        lenderNameKey = "rff_lender_primary_bank",
        brokered = false,
        brokerCaseId = 0,
        arrangementFee = 0,
        brokerFee = 0,
        overdraftSuspended = false,
        overdraftOverLimit = 0,
        overdraftLimitBreaches = 0,
        lastOverdraftBreachPeriod = 0,
        overdraftReviewCount = 0,
        overdraftWarningTwoMonths = false,
        overdraftWarningOneMonth = false,
        forbearanceCount = 0,
        forbearanceLastPeriod = 0,
        forbearanceLastType = "",
        forbearanceMode = "",
        forbearanceRemainingPeriods = 0,
        forbearanceCapitalisedArrears = 0,
        forbearanceCapitalisedInterest = 0,
        forbearanceOriginalPayment = 0,
        forbearanceOriginalRate = 0,
        forbearanceBroken = false,
        forbearanceOfferStatus = "",
        forbearanceOfferType = "",
        forbearanceOfferCreatedPeriod = 0,
        forbearanceOfferExpiryPeriod = 0,
        forbearanceOfferLastPeriod = 0
    }

    self.repository:addLoan(loan)

    -- Remove only the vanilla liability. Deliberately do not call addMoney: the farm's
    -- cash balance must be byte-for-byte economically unchanged by migration.
    farm.loan = 0

    state.legacyLoanMigrationVersion = self.LEGACY_MIGRATION_VERSION
    state.legacyLoanImportedAmount = amount
    state.legacyLoanImportedId = loan.id or 0

    print(string.format("[RealisticFarmFinance] Imported vanilla loan farm=%d amount=%.2f as Legacy Farm Loan #%d term=%d months rate=%.2f%%; farm cash unchanged",
        farmId, amount, loan.id or 0, months, annualRate))
    return true, loan
end

function RFF_LoanService:createRecoveryShortfall(agreement, amount, annualRate, recoveryData)
    if self.repository == nil or agreement == nil then return nil end
    amount = math.max(0, safeNumber(amount))
    if amount <= 0.01 then return nil end
    local current = self.repository:getCurrentPeriodIndex()
    local isProperty = recoveryData ~= nil and recoveryData.sourceType == "PROPERTY"
    local loan = {
        id = self.repository:getNextLoanId(),
        farmId = agreement.farmId,
        type = self.TYPE_RECOVERY_SHORTFALL,
        purpose = isProperty and "PROPERTY_RECOVERY_SHORTFALL" or "ASSET_RECOVERY_SHORTFALL",
        originalAmount = amount,
        principal = amount,
        drawnAmount = 0,
        creditLimit = 0,
        interestRate = math.max(0, safeNumber(annualRate)),
        termMonths = 0,
        remainingMonths = 0,
        monthlyPayment = 0,
        riskGrade = "D",
        lenderId = agreement.lenderId or "PRIMARY_BANK",
        lenderNameKey = agreement.lenderNameKey or "rff_lender_primary_bank",
        createdPeriod = current,
        lastPaymentPeriod = current,
        paymentsMade = 0,
        missedPayments = 0,
        arrearsPrincipal = 0,
        arrearsInterest = 0,
        arrearsRent = 0,
        arrearsFees = 0,
        arrearsBalance = 0,
        arrearsAgeMonths = 4,
        arrearsStage = "RECOVERY",
        defaultInterestAccrued = 0,
        adminChargesAccrued = 0,
        defaultEvents = 0,
        currentDefault = true,
        defaultRecorded = true,
        recoveryEligible = false,
        lastDefaultManagementPeriod = current,
        consecutiveMissedPayments = 0,
        maxConsecutiveMissedPayments = math.max(3, safeNumber(agreement.maxConsecutiveMissedPayments)),
        lastMissedPeriod = math.max(current, safeNumber(agreement.lastMissedPeriod)),
        lastSuccessfulPaymentPeriod = 0,
        lastArrearsClearedPeriod = 0,
        arrearsSchemaVersion = 1,
        principalPaid = 0,
        interestPaid = 0,
        completedPeriod = 0,
        paidOff = false,
        recoveryLiability = true,
        sourceRecoveryType = isProperty and "PROPERTY" or "ASSET",
        sourceAssetAgreementId = isProperty and 0 or (agreement.id or 0),
        sourceAssetName = isProperty and "" or (agreement.vehicleName or "Recovered asset"),
        sourceMortgageLoanId = isProperty and (agreement.id or 0) or 0,
        sourceFarmlandId = isProperty and (agreement.securityFarmlandId or (recoveryData ~= nil and recoveryData.farmlandId) or 0) or 0,
        capitalisedInterest = 0,
        capitalisedAdminCharges = 0,
        recoveryMethod = recoveryData ~= nil and recoveryData.method or "RECOVERY",
        recoveryRealisedValue = recoveryData ~= nil and safeNumber(recoveryData.realisedValue) or 0,
        recoveryCosts = recoveryData ~= nil and safeNumber(recoveryData.recoveryCosts) or 0
    }
    self.repository:addLoan(loan)
    return loan
end

function RFF_LoanService:processRecoveryShortfall(loan)
    if loan == nil or loan.paidOff then return end
    local principal = math.max(0, safeNumber(loan.principal))
    if principal <= 0.01 then
        loan.principal = 0
        loan.paidOff = true
        loan.currentDefault = false
        loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
        return
    end
    local interest = principal * (math.max(0, safeNumber(loan.interestRate)) / 100) / 12
    local admin = self.RECOVERY_ADMIN_CHARGE
    loan.principal = principal + interest + admin
    loan.defaultInterestAccrued = safeNumber(loan.defaultInterestAccrued) + interest
    loan.adminChargesAccrued = safeNumber(loan.adminChargesAccrued) + admin
    loan.capitalisedInterest = safeNumber(loan.capitalisedInterest) + interest
    loan.capitalisedAdminCharges = safeNumber(loan.capitalisedAdminCharges) + admin
    loan.currentDefault = true
    loan.arrearsStage = "RECOVERY"
end

function RFF_LoanService:payArrears(loan)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or loan.paidOff then return false, "invalid", 0 end
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(loan) or math.max(0, safeNumber(loan.arrearsBalance))
    if arrears <= 0.01 then return false, "nothing_due", 0 end
    if not self:canAfford(loan.farmId, arrears) then return false, "funds", arrears end

    local principal = math.max(0, safeNumber(loan.arrearsPrincipal))
    local interest = math.max(0, safeNumber(loan.arrearsInterest))
    local fees = math.max(0, safeNumber(loan.arrearsFees))
    if interest > 0 then self:charge(loan.farmId, interest, getLoanInterestMoneyType()) end
    if principal > 0 then self:charge(loan.farmId, principal, getLoanPrincipalMoneyType()) end
    if fees > 0 then self:charge(loan.farmId, fees, MoneyType ~= nil and (MoneyType.OTHER or getLoanInterestMoneyType()) or nil) end
    loan.interestPaid = safeNumber(loan.interestPaid) + interest
    loan.adminChargesPaid = safeNumber(loan.adminChargesPaid) + fees
    loan.principalPaid = safeNumber(loan.principalPaid) + principal
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(loan, self.repository) else loan.arrearsBalance = 0 end
    if self.relationshipService ~= nil then self.relationshipService:recordArrearsCleared(loan) end

    if loan.type ~= self.TYPE_REVOLVING and loan.type ~= self.TYPE_OVERDRAFT and safeNumber(loan.principal) <= 0.01 and safeNumber(loan.remainingMonths) <= 0 then
        loan.principal = 0
        loan.paidOff = true
        loan.currentDefault = false
        loan.recoveryEligible = false
        loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
        self:recordRelationshipCompletion(loan)
    end
    return true, nil, arrears
end

function RFF_LoanService:migrateLegacyArrears()
    if self.repository == nil then return end
    for _, loan in ipairs(self.repository.loans or {}) do
        if safeNumber(loan.arrearsSchemaVersion) < 1 then
            local misses = math.max(0, math.floor(safeNumber(loan.missedPayments)))
            loan.arrearsPrincipal = math.max(0, safeNumber(loan.arrearsPrincipal))
            loan.arrearsInterest = math.max(0, safeNumber(loan.arrearsInterest))
            loan.arrearsRent = 0
            loan.consecutiveMissedPayments = misses
            loan.maxConsecutiveMissedPayments = math.max(safeNumber(loan.maxConsecutiveMissedPayments), misses)
            if misses > 0 then
                loan.lastMissedPeriod = self.repository:getCurrentPeriodIndex()
                if loan.type == self.TYPE_REVOLVING or loan.type == self.TYPE_OVERDRAFT then
                    loan.arrearsInterest = loan.arrearsInterest + misses * math.max(0, safeNumber(loan.drawnAmount)) * (safeNumber(loan.interestRate) / 100) / 12
                else
                    for _ = 1, misses do
                        if safeNumber(loan.remainingMonths) <= 0 then break end
                        local principal = math.max(0, safeNumber(loan.principal))
                        local interest = principal * (safeNumber(loan.interestRate) / 100) / 12
                        local capital = 0
                        if loan.type == self.TYPE_BULLET then
                            capital = safeNumber(loan.remainingMonths) <= 1 and principal or 0
                        else
                            capital = math.max(0, math.min(principal, math.max(0, safeNumber(loan.monthlyPayment)) - interest))
                            if safeNumber(loan.remainingMonths) <= 1 then capital = principal end
                        end
                        loan.principal = math.max(0, principal - capital)
                        loan.arrearsPrincipal = loan.arrearsPrincipal + capital
                        loan.arrearsInterest = loan.arrearsInterest + interest
                        loan.remainingMonths = math.max(0, safeNumber(loan.remainingMonths) - 1)
                    end
                end
            end
            if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:getArrears(loan) end
            loan.arrearsSchemaVersion = 1
        end
    end
end

function RFF_LoanService:processTermPayment(loan)
    if safeNumber(loan.remainingMonths) <= 0 then return false end
    local monthlyRate = safeNumber(loan.interestRate) / 100 / 12
    local principal = math.max(0, safeNumber(loan.principal))
    local interest = principal * monthlyRate
    local scheduled = math.max(0, safeNumber(loan.monthlyPayment))
    local principalPart = math.max(0, math.min(principal, scheduled - interest))
    local finalPeriod = safeNumber(loan.remainingMonths) <= 1
    if finalPeriod then principalPart = principal end
    local due = interest + principalPart

    -- Contract time always advances. A missed instalment becomes arrears instead of extending the term.
    loan.remainingMonths = math.max(0, safeNumber(loan.remainingMonths) - 1)

    if not self:canAfford(loan.farmId, due) then
        loan.principal = math.max(0, principal - principalPart)
        if RFF_PaymentConduct ~= nil then
            RFF_PaymentConduct:recordMissed(loan, self.repository, principalPart, interest, 0)
        else
            loan.missedPayments = safeNumber(loan.missedPayments) + 1
        end
        if self.relationshipService ~= nil then self.relationshipService:recordMissedPayment(loan) end
        self:notifyMissedPayment(loan, due)
        return false
    end

    self:charge(loan.farmId, interest, getLoanInterestMoneyType())
    self:charge(loan.farmId, principalPart, getLoanPrincipalMoneyType())
    loan.interestPaid = safeNumber(loan.interestPaid) + interest
    loan.principalPaid = safeNumber(loan.principalPaid) + principalPart
    loan.principal = math.max(0, principal - principalPart)
    loan.paymentsMade = safeNumber(loan.paymentsMade) + 1
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordSuccessfulScheduledPayment(loan, self.repository) end
    if self.relationshipService ~= nil then self.relationshipService:recordSuccessfulPayment(loan) end

    if loan.principal <= 0.01 and safeNumber(loan.arrearsBalance) <= 0.01 then
        loan.principal = 0
        loan.remainingMonths = 0
        loan.paidOff = true
        loan.currentDefault = false
        loan.recoveryEligible = false
        loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
        self:recordRelationshipCompletion(loan)
    end
    return true
end

function RFF_LoanService:processBulletPayment(loan)
    if safeNumber(loan.remainingMonths) <= 0 then return false end
    local monthlyRate = safeNumber(loan.interestRate) / 100 / 12
    local principal = math.max(0, safeNumber(loan.principal))
    local interest = principal * monthlyRate
    local principalPart = safeNumber(loan.remainingMonths) <= 1 and principal or 0
    local due = interest + principalPart

    loan.remainingMonths = math.max(0, safeNumber(loan.remainingMonths) - 1)

    if not self:canAfford(loan.farmId, due) then
        loan.principal = math.max(0, principal - principalPart)
        if RFF_PaymentConduct ~= nil then
            RFF_PaymentConduct:recordMissed(loan, self.repository, principalPart, interest, 0)
        else
            loan.missedPayments = safeNumber(loan.missedPayments) + 1
        end
        if self.relationshipService ~= nil then self.relationshipService:recordMissedPayment(loan) end
        self:notifyMissedPayment(loan, due)
        return false
    end

    self:charge(loan.farmId, interest, getLoanInterestMoneyType())
    self:charge(loan.farmId, principalPart, getLoanPrincipalMoneyType())
    loan.interestPaid = safeNumber(loan.interestPaid) + interest
    loan.principalPaid = safeNumber(loan.principalPaid) + principalPart
    loan.principal = math.max(0, principal - principalPart)
    loan.paymentsMade = safeNumber(loan.paymentsMade) + 1
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordSuccessfulScheduledPayment(loan, self.repository) end
    if self.relationshipService ~= nil then self.relationshipService:recordSuccessfulPayment(loan) end

    if loan.principal <= 0.01 and safeNumber(loan.arrearsBalance) <= 0.01 then
        loan.principal = 0
        loan.remainingMonths = 0
        loan.paidOff = true
        loan.currentDefault = false
        loan.recoveryEligible = false
        loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
        self:recordRelationshipCompletion(loan)
    end
    return true
end

function RFF_LoanService:processRevolvingPayment(loan)
    local drawn = math.max(0, safeNumber(loan.drawnAmount))
    if drawn <= 0 then return true end

    local interest = drawn * (safeNumber(loan.interestRate) / 100) / 12
    if not self:canAfford(loan.farmId, interest) then
        if RFF_PaymentConduct ~= nil then
            RFF_PaymentConduct:recordMissed(loan, self.repository, 0, interest, 0)
        else
            loan.missedPayments = safeNumber(loan.missedPayments) + 1
        end
        if self.relationshipService ~= nil then self.relationshipService:recordMissedPayment(loan) end
        self:notifyMissedPayment(loan, interest)
        return false
    end

    self:charge(loan.farmId, interest, getLoanInterestMoneyType())
    loan.interestPaid = safeNumber(loan.interestPaid) + interest
    loan.paymentsMade = safeNumber(loan.paymentsMade) + 1
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordSuccessfulScheduledPayment(loan, self.repository) end
    if self.relationshipService ~= nil then self.relationshipService:recordSuccessfulPayment(loan) end
    return true
end

function RFF_LoanService:processMonthlyPayment(loan)
    if loan == nil or loan.paidOff then return end

    if self.forbearanceService ~= nil and self.forbearanceService.processTemporaryArrangement ~= nil then
        if self.forbearanceService:processTemporaryArrangement(loan) then return end
    end

    if loan.type == self.TYPE_RECOVERY_SHORTFALL then
        self:processRecoveryShortfall(loan)
        return
    end
    if loan.type == self.TYPE_OVERDRAFT then return end
    if loan.type ~= self.TYPE_REVOLVING and safeNumber(loan.remainingMonths) <= 0 then
        return
    end

    if loan.type == self.TYPE_TERM or loan.type == self.TYPE_MORTGAGE then
        self:processTermPayment(loan)
    elseif loan.type == self.TYPE_BULLET then
        self:processBulletPayment(loan)
    elseif loan.type == self.TYPE_REVOLVING then
        self:processRevolvingPayment(loan)
    end
end

function RFF_LoanService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then
        return
    end

    local currentPeriod = self.repository:getCurrentPeriodIndex()
    for _, loan in ipairs(self.repository.loans or {}) do
        if not loan.paidOff and safeNumber(loan.farmId) > 0 then
            local last = safeNumber(loan.lastPaymentPeriod)
            while last < currentPeriod do
                self:processMonthlyPayment(loan)
                last = last + 1
                loan.lastPaymentPeriod = last
            end
        end
    end
end

function RFF_LoanService:drawRevolving(loan, amount)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or loan.type ~= self.TYPE_REVOLVING or loan.paidOff then
        return false, "invalid"
    end
    if safeNumber(loan.arrearsBalance) > 0.01 then return false, "arrears" end

    amount = math.max(0, safeNumber(amount))
    local available = math.max(0, safeNumber(loan.creditLimit) - safeNumber(loan.drawnAmount))
    if amount <= 0 or amount > available then
        return false, "limit"
    end

    loan.drawnAmount = safeNumber(loan.drawnAmount) + amount
    g_currentMission:addMoney(amount, loan.farmId, getLoanPrincipalMoneyType(), true, true)
    return true
end

function RFF_LoanService:repayRevolving(loan, amount)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or loan.type ~= self.TYPE_REVOLVING or loan.paidOff then
        return false, "invalid"
    end
    if safeNumber(loan.arrearsBalance) > 0.01 then return false, "arrears" end

    amount = math.max(0, math.min(safeNumber(amount), safeNumber(loan.drawnAmount)))
    if amount <= 0 then
        return false, "nothing_drawn"
    end
    if not self:canAfford(loan.farmId, amount) then
        return false, "funds"
    end

    self:charge(loan.farmId, amount, getLoanPrincipalMoneyType())
    loan.drawnAmount = math.max(0, safeNumber(loan.drawnAmount) - amount)
    loan.principalPaid = safeNumber(loan.principalPaid) + amount
    return true
end

function RFF_LoanService:getLoanOutstanding(loan)
    if loan == nil or loan.paidOff then return 0 end
    local base
    if loan.type == self.TYPE_OVERDRAFT and self.repository ~= nil and self.repository.getBankAccountLiability ~= nil then
        base = self.repository:getBankAccountLiability(loan.farmId)
    elseif loan.type == self.TYPE_REVOLVING then
        base = math.max(0, safeNumber(loan.drawnAmount))
    else
        base = math.max(0, safeNumber(loan.principal))
    end
    return base + math.max(0, safeNumber(loan.arrearsBalance))
end

function RFF_LoanService:getCurrentInterestDue(loan)
    if loan == nil or loan.paidOff then return 0 end
    if loan.type==self.TYPE_OVERDRAFT and self.repository and self.repository.bankingService then
        return self.repository.bankingService:getProjectedMonthlyDebitCost(loan.farmId,false)
    end
    local outstanding
    local rate = safeNumber(loan.interestRate)
    if loan.type == self.TYPE_OVERDRAFT and self.repository ~= nil and self.repository.getBankAccountLiability ~= nil then
        outstanding = self.repository:getBankAccountLiability(loan.farmId)
        if loan.overdraftSuspended == true then rate = rate + 3.00 end
    elseif loan.type == self.TYPE_REVOLVING then
        outstanding = math.max(0, safeNumber(loan.drawnAmount))
    else
        outstanding = math.max(0, safeNumber(loan.principal))
    end
    return outstanding * (rate / 100) / 12
end

function RFF_LoanService:makeExtraRepayment(loan, amount)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or loan.paidOff then return false, "invalid", 0 end
    if safeNumber(loan.arrearsBalance) > 0.01 then return false, "arrears", math.max(0, safeNumber(loan.arrearsBalance)) end
    if loan.type == self.TYPE_REVOLVING then return self:repayRevolving(loan, amount) end
    if loan.type == self.TYPE_OVERDRAFT then return false, "overdraft_account", 0 end

    local outstanding = math.max(0, safeNumber(loan.principal))
    amount = math.max(0, math.min(safeNumber(amount), outstanding))
    if amount <= 0 then return false, "nothing_due", 0 end
    if not self:canAfford(loan.farmId, amount) then return false, "funds", 0 end

    self:charge(loan.farmId, amount, getLoanPrincipalMoneyType())
    loan.principal = math.max(0, outstanding - amount)
    loan.principalPaid = safeNumber(loan.principalPaid) + amount

    if loan.principal <= 0.01 and safeNumber(loan.arrearsBalance) <= 0.01 then
        loan.principal = 0
        loan.remainingMonths = 0
        loan.paidOff = true
        loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
        self:recordRelationshipCompletion(loan)
    end
    return true, nil, amount
end

function RFF_LoanService:closeLoanAsRefinanced(loan, replacementLoanId)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or loan.paidOff then return false, "invalid", 0 end
    if safeNumber(loan.arrearsBalance) > 0.01 or loan.currentDefault == true then return false, "arrears", self:getLoanOutstanding(loan) end
    if loan.type == self.TYPE_OVERDRAFT or loan.type == self.TYPE_MORTGAGE or loan.type == self.TYPE_RECOVERY_SHORTFALL then
        return false, "product", self:getLoanOutstanding(loan)
    end

    local total = self:getLoanOutstanding(loan)
    if loan.type == self.TYPE_REVOLVING then
        loan.drawnAmount = 0
        loan.creditLimit = 0
    else
        loan.principal = 0
        loan.remainingMonths = 0
    end
    loan.principalPaid = safeNumber(loan.principalPaid) + total
    loan.paidOff = true
    loan.currentDefault = false
    loan.recoveryEligible = false
    loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    loan.refinanced = true
    loan.refinancedPeriod = loan.completedPeriod
    loan.refinancedByLoanId = math.max(0, math.floor(safeNumber(replacementLoanId)))
    self:recordRelationshipCompletion(loan)
    return true, nil, total
end

function RFF_LoanService:settleLoan(loan)
    if g_currentMission == nil or not g_currentMission:getIsServer() or loan == nil or loan.paidOff then return false, "invalid", 0 end

    if loan.type == self.TYPE_OVERDRAFT then
        local used = self.repository ~= nil and self.repository.getBankAccountLiability ~= nil and self.repository:getBankAccountLiability(loan.farmId) or math.max(0, safeNumber(loan.drawnAmount))
        local arrears = math.max(0, safeNumber(loan.arrearsBalance))
        if used > 0.01 or arrears > 0.01 then return false, "overdraft_in_use", used + arrears end
        loan.paidOff = true
        loan.creditLimit = 0
        loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
        self:recordRelationshipCompletion(loan)
        return true, nil, 0
    end

    local base = (loan.type == self.TYPE_REVOLVING or loan.type == self.TYPE_OVERDRAFT) and math.max(0, safeNumber(loan.drawnAmount)) or math.max(0, safeNumber(loan.principal))
    local arrears = math.max(0, safeNumber(loan.arrearsBalance))
    local total = base + arrears
    if total > 0 and not self:canAfford(loan.farmId, total) then return false, "funds", total end

    if arrears > 0 then
        local ok = self:payArrears(loan)
        if not ok then return false, "funds", total end
    end
    if base > 0 then
        self:charge(loan.farmId, base, getLoanPrincipalMoneyType())
        loan.principalPaid = safeNumber(loan.principalPaid) + base
    end

    if loan.type == self.TYPE_REVOLVING then loan.drawnAmount = 0 else loan.principal = 0; loan.remainingMonths = 0 end
    loan.paidOff = true
    loan.currentDefault = false
    loan.recoveryEligible = false
    loan.completedPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    self:recordRelationshipCompletion(loan)
    return true, nil, total
end

function RFF_LoanService:getProjectedSchedule(loan, maxRows)
    local rows = {}
    if loan == nil or loan.paidOff then
        return rows
    end

    maxRows = math.max(1, math.floor(safeNumber(maxRows)))
    if loan.type == self.TYPE_REVOLVING or loan.type == self.TYPE_OVERDRAFT then
        local drawn = math.max(0, safeNumber(loan.drawnAmount))
        local rate = safeNumber(loan.interestRate)
        if loan.type == self.TYPE_OVERDRAFT and self.repository ~= nil and self.repository.getBankAccountLiability ~= nil then
            drawn = self.repository:getBankAccountLiability(loan.farmId)
            if loan.overdraftSuspended == true then rate = rate + 3.00 end
        end
        local interest = drawn * (rate / 100) / 12
        if loan.type==self.TYPE_OVERDRAFT and self.repository.bankingService then
            interest=self.repository.bankingService:getProjectedMonthlyDebitCost(loan.farmId,false)
        end
        table.insert(rows, {
            month = 1,
            payment = interest,
            interest = interest,
            principal = 0,
            closingBalance = drawn,
            revolving = true
        })
        return rows
    end

    local balance = math.max(0, safeNumber(loan.principal))
    local remaining = math.max(0, math.floor(safeNumber(loan.remainingMonths)))
    local monthlyRate = safeNumber(loan.interestRate) / 100 / 12
    local rowCount = math.min(maxRows, remaining)

    for month = 1, rowCount do
        local interest = balance * monthlyRate
        local principal = 0
        local payment = 0

        if loan.type == self.TYPE_BULLET then
            principal = month == remaining and balance or 0
            payment = interest + principal
        else
            local scheduled = math.max(0, safeNumber(loan.monthlyPayment))
            principal = math.max(0, math.min(balance, scheduled - interest))
            if month == remaining then
                principal = balance
            end
            payment = interest + principal
        end

        balance = math.max(0, balance - principal)
        table.insert(rows, {
            month = month,
            payment = payment,
            interest = interest,
            principal = principal,
            closingBalance = balance,
            revolving = false
        })
        if balance <= 0.01 then
            break
        end
    end
    return rows
end
