RFF_AssetFinanceService = {}
RFF_AssetFinanceService.__index = RFF_AssetFinanceService

RFF_AssetFinanceService.TYPE_HIRE_PURCHASE = "HIRE_PURCHASE"
RFF_AssetFinanceService.TYPE_BALLOON = "BALLOON_FINANCE"
RFF_AssetFinanceService.TYPE_OPERATING_LEASE = "OPERATING_LEASE"

RFF_AssetFinanceService.DEPOSIT_OPTIONS = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50}
RFF_AssetFinanceService.TERM_OPTIONS = {24, 36, 48, 60, 72, 84}
RFF_AssetFinanceService.BALLOON_OPTIONS = {20, 25, 30, 35, 40}

RFF_AssetFinanceService.VOLUNTARY_REALISATION_FACTOR = 0.90
RFF_AssetFinanceService.FORCED_REALISATION_FACTOR = 0.80
RFF_AssetFinanceService.VOLUNTARY_RECOVERY_COST_RATE = 0.015
RFF_AssetFinanceService.FORCED_RECOVERY_COST_RATE = 0.035
RFF_AssetFinanceService.MIN_RECOVERY_COST = 250
RFF_AssetFinanceService.MAX_RECOVERY_COST = 5000
RFF_AssetFinanceService.EARLY_TERMINATION_RENT_RATE = 0.35
RFF_AssetFinanceService.EARLY_TERMINATION_MAX_RENTALS = 6

RFF_AssetFinanceService.PRODUCT_RATE_ADJUSTMENT = {
    [RFF_AssetFinanceService.TYPE_HIRE_PURCHASE] = 0.75,
    [RFF_AssetFinanceService.TYPE_BALLOON] = 1.00,
    [RFF_AssetFinanceService.TYPE_OPERATING_LEASE] = 1.25
}

-- Point-of-sale asset finance still uses immediate underwriting, but every agreement now has
-- a real lender identity so pricing, conduct and recovery feed the same relationship model.
RFF_AssetFinanceService.PROVIDERS = {
    {id="PRIMARY_BANK", nameKey="rff_lender_primary_bank", rateAdjustment=0.00, grades={A=true,B=true,C=true}, products={HIRE_PURCHASE=true,BALLOON_FINANCE=true,OPERATING_LEASE=true}, priority=1},
    {id="RURAL_AGRI_BANK", nameKey="rff_lender_rural_agri_bank", rateAdjustment=-0.25, grades={A=true,B=true}, products={HIRE_PURCHASE=true,BALLOON_FINANCE=true}, priority=2},
    {id="COUNTY_COMMERCIAL", nameKey="rff_lender_county_commercial", rateAdjustment=0.10, grades={A=true,B=true,C=true}, products={HIRE_PURCHASE=true,BALLOON_FINANCE=true,OPERATING_LEASE=true}, priority=3},
    {id="AGRIGROWTH_FINANCE", nameKey="rff_lender_agrigrowth", rateAdjustment=0.55, grades={A=true,B=true,C=true,D=true}, products={HIRE_PURCHASE=true,BALLOON_FINANCE=true,OPERATING_LEASE=true}, priority=4},
    {id="FRONTIER_CAPITAL", nameKey="rff_lender_frontier_capital", rateAdjustment=1.50, grades={C=true,D=true}, products={HIRE_PURCHASE=true,BALLOON_FINANCE=true,OPERATING_LEASE=true}, priority=5}
}

RFF_AssetFinanceService.PROVIDER_PRODUCT_ADJUSTMENT = {
    PRIMARY_BANK = {OPERATING_LEASE=0.20},
    RURAL_AGRI_BANK = {HIRE_PURCHASE=-0.10, BALLOON_FINANCE=0.10},
    COUNTY_COMMERCIAL = {OPERATING_LEASE=0.00},
    AGRIGROWTH_FINANCE = {BALLOON_FINANCE=-0.10, OPERATING_LEASE=-0.20},
    FRONTIER_CAPITAL = {OPERATING_LEASE=0.25}
}

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local function getFarm(farmId)
    return g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
end

local function moneyTypeInterest()
    if MoneyType ~= nil then return MoneyType.LOAN_INTEREST or MoneyType.LEASING_COSTS or MoneyType.OTHER end
    return nil
end

local function moneyTypePrincipal()
    if MoneyType ~= nil then return MoneyType.LOAN_PRINCIPAL or MoneyType.LEASING_COSTS or MoneyType.OTHER end
    return nil
end

local function moneyTypeLease()
    if MoneyType ~= nil then return MoneyType.LEASING_COSTS or MoneyType.OTHER end
    return nil
end

local function moneyTypeLeaseReturn()
    if MoneyType ~= nil then return MoneyType.LEASING_COSTS or MoneyType.OTHER end
    return nil
end

local function safeCallNumber(object, methodName)
    if object == nil or object[methodName] == nil then return 0 end
    local ok, value = pcall(object[methodName], object)
    if not ok then return 0 end
    return safeNumber(value)
end

local function getLocalCurrentVehicle()
    if g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil then
        local ok, vehicle = pcall(g_localPlayer.getCurrentVehicle, g_localPlayer)
        if ok and vehicle ~= nil then return vehicle end
    end
    if g_currentMission ~= nil then return g_currentMission.controlledVehicle end
    return nil
end

function RFF_AssetFinanceService.new(repository, loanService)
    local self = setmetatable({}, RFF_AssetFinanceService)
    self.repository = repository
    self.loanService = loanService
    self.relationshipService = nil
    self.marketService = nil
    return self
end

function RFF_AssetFinanceService:setRelationshipService(service)
    self.relationshipService = service
end

function RFF_AssetFinanceService:setMarketService(service)
    self.marketService = service
end

function RFF_AssetFinanceService:getProvider(providerId)
    for _, provider in ipairs(self.PROVIDERS) do
        if provider.id == providerId then return provider end
    end
    return self.PROVIDERS[1]
end

function RFF_AssetFinanceService:getProviderNameKey(providerId)
    local provider = self:getProvider(providerId)
    return provider ~= nil and provider.nameKey or "rff_lender_primary_bank"
end

function RFF_AssetFinanceService:selectProvider(farmId, product, grade, amount)
    grade = grade or "D"
    local best, bestScore = nil, math.huge
    for _, provider in ipairs(self.PROVIDERS) do
        if provider.products[product] == true and provider.grades[grade] == true then
            local relationshipAdjustment = 0
            local relationshipTier = "NEW"
            if self.relationshipService ~= nil then
                local benefits = self.relationshipService:getBenefits(farmId, provider.id)
                relationshipAdjustment = safeNumber(benefits ~= nil and benefits.rateAdjustment or 0)
                relationshipTier = benefits ~= nil and benefits.code or "NEW"
            end
            local productAdjustment = 0
            local tableForProvider = self.PROVIDER_PRODUCT_ADJUSTMENT[provider.id]
            if tableForProvider ~= nil then productAdjustment = safeNumber(tableForProvider[product]) end
            local marketAdjustment = 0
            local marketState = "SELECTIVE"
            local fitAdjustment = 0
            local dealFit = "STANDARD"
            local dealAvailable = true
            if self.marketService ~= nil then
                local market = self.marketService:getMarketAdjustment(provider.id)
                marketAdjustment = safeNumber(market.rateAdjustment)
                marketState = market.state or "SELECTIVE"
                local fit = self.marketService:getDealAdjustment(provider.id, product, "MACHINERY", amount or 0, grade)
                fitAdjustment = safeNumber(fit.rateAdjustment)
                dealFit = fit.code or "STANDARD"
                dealAvailable = fit.available == true
            end
            if dealAvailable then
                local score = safeNumber(provider.rateAdjustment) + productAdjustment + relationshipAdjustment + marketAdjustment + fitAdjustment
                -- Stable tie-breaker keeps provider selection deterministic across reloads.
                score = score + safeNumber(provider.priority) * 0.0001
                if score < bestScore then
                    bestScore = score
                    best = {
                        id=provider.id, nameKey=provider.nameKey,
                        providerRateAdjustment=safeNumber(provider.rateAdjustment) + productAdjustment + marketAdjustment + fitAdjustment,
                        relationshipRateAdjustment=relationshipAdjustment, relationshipTier=relationshipTier, marketState=marketState, dealFit=dealFit,
                        totalRateAdjustment=safeNumber(provider.rateAdjustment) + productAdjustment + relationshipAdjustment + marketAdjustment + fitAdjustment
                    }
                end
            end
        end
    end
    if best == nil then
        local fallback = self:getProvider("FRONTIER_CAPITAL")
        best = {id=fallback.id, nameKey=fallback.nameKey, providerRateAdjustment=safeNumber(fallback.rateAdjustment), relationshipRateAdjustment=0, relationshipTier="NEW", marketState="SELECTIVE", dealFit="STANDARD", totalRateAdjustment=safeNumber(fallback.rateAdjustment)}
    end
    return best
end

function RFF_AssetFinanceService:recordRelationshipCompletion(agreement)
    if agreement == nil or agreement.relationshipCompletionRecorded == true then return end
    if self.relationshipService ~= nil then self.relationshipService:recordAgreementCompleted(agreement) end
    agreement.relationshipCompletionRecorded = true
end

function RFF_AssetFinanceService:getProductTextKey(product)
    if product == self.TYPE_HIRE_PURCHASE then return "rff_asset_product_hp" end
    if product == self.TYPE_BALLOON then return "rff_asset_product_balloon" end
    if product == self.TYPE_OPERATING_LEASE then return "rff_asset_product_operating_lease" end
    return "rff_asset_product_hp"
end

function RFF_AssetFinanceService:getVehicleByUniqueId(uniqueId)
    if uniqueId == nil or uniqueId == "" or g_currentMission == nil or g_currentMission.vehicleSystem == nil then return nil end
    for _, vehicle in pairs(g_currentMission.vehicleSystem.vehicles or {}) do
        if vehicle ~= nil and vehicle.uniqueId == uniqueId then return vehicle end
    end
    return nil
end

function RFF_AssetFinanceService:getAgreementByVehicle(uniqueId, activeOnly)
    if self.repository == nil then return nil end
    return self.repository:getAssetFinanceByVehicle(uniqueId, activeOnly)
end

function RFF_AssetFinanceService:getResidualRatio(termMonths)
    termMonths = math.max(1, safeNumber(termMonths))
    if termMonths <= 24 then return 0.62 end
    if termMonths <= 36 then return 0.54 end
    if termMonths <= 48 then return 0.47 end
    if termMonths <= 60 then return 0.40 end
    if termMonths <= 72 then return 0.34 end
    return 0.29
end

function RFF_AssetFinanceService:calculatePaymentWithResidual(principal, annualRate, months, residual)
    principal = math.max(0, safeNumber(principal))
    residual = math.max(0, safeNumber(residual))
    months = math.max(1, math.floor(safeNumber(months)))
    local r = math.max(0, safeNumber(annualRate)) / 100 / 12
    if r <= 0 then return math.max(0, principal - residual) / months end
    local factor = (1 + r) ^ months
    return math.max(0, (principal - residual / factor) * (r * factor) / (factor - 1))
end

function RFF_AssetFinanceService:getMinimumDepositForGrade(grade, product)
    if product == self.TYPE_OPERATING_LEASE then return 10 end
    local minimum = {A=5, B=10, C=15, D=25}
    return minimum[grade] or 30
end

function RFF_AssetFinanceService:populateQuoteRecommendations(result, farmId, basePrice, depositPercent, months, product, balloonPercent)
    if result == nil or result.approved then return result end

    local farm = getFarm(farmId)
    if farm == nil then return result end

    if result.reason == "funds" then
        result.additionalCashRequired = math.max(0, safeNumber(result.deposit) + safeNumber(result.pendingOrderDepositBalance) - safeNumber(farm.money))
    end

    if result.reason == "deposit" and safeNumber(result.minimumDepositPercent) > depositPercent then
        result.recommendedDepositPercent = result.minimumDepositPercent
        result.recommendedDepositAmount = basePrice * result.minimumDepositPercent / 100
    end

    -- Search the same 5% deposit grid used by the UI for the first structure that would pass.
    if result.recommendedDepositPercent == nil then
        for _, candidateDeposit in ipairs(self.DEPOSIT_OPTIONS) do
            if candidateDeposit > depositPercent and safeNumber(farm.money) >= basePrice * candidateDeposit / 100 then
                local candidate = self:evaluateQuote(farmId, basePrice, candidateDeposit, months, product, balloonPercent, true)
                if candidate ~= nil and candidate.approved then
                    result.recommendedDepositPercent = candidateDeposit
                    result.recommendedDepositAmount = basePrice * candidateDeposit / 100
                    break
                end
            end
        end
    end

    -- A longer term may turn an affordability decline into a supportable monthly commitment.
    for _, candidateMonths in ipairs(self.TERM_OPTIONS) do
        if candidateMonths > months then
            local candidate = self:evaluateQuote(farmId, basePrice, depositPercent, candidateMonths, product, balloonPercent, true)
            if candidate ~= nil and candidate.approved then
                result.recommendedTermMonths = candidateMonths
                result.recommendedTermPayment = candidate.monthlyPayment
                break
            end
        end
    end

    local targetDscr = math.max(0.01, safeNumber(result.dscrTarget))
    local monthlyIncome = math.max(0, safeNumber(result.monthlyIncome))
    local proposedPayment = math.max(0, safeNumber(result.monthlyPayment))
    local existingCommitments = math.max(0, safeNumber(result.existingMonthlyCommitments))
    if monthlyIncome > 0 and proposedPayment > 0 then
        local maximumExisting = math.max(0, monthlyIncome / targetDscr - proposedPayment)
        result.monthlyCommitmentReduction = math.max(0, existingCommitments - maximumExisting)
    end

    if product == self.TYPE_OPERATING_LEASE and proposedPayment > 0 then
        -- The lowest liquidity route intentionally remains conservative: nine months of rental
        -- and a quarter of the asset value remaining as cash after the refundable security deposit.
        local minimumLiquidity = math.max((proposedPayment + safeNumber(result.pendingOrderMonthlyPayments)) * 9, basePrice * 0.25)
        result.additionalLiquidityRequired = math.max(0, minimumLiquidity - math.max(0, safeNumber(result.cashAfterDeposit)))
    end

    return result
end

function RFF_AssetFinanceService:evaluateQuote(farmId, basePrice, depositPercent, months, product, balloonPercent, skipAdvice)
    basePrice = math.max(0, safeNumber(basePrice))
    depositPercent = math.max(0, safeNumber(depositPercent))
    months = math.max(1, math.floor(safeNumber(months)))
    balloonPercent = math.max(0, safeNumber(balloonPercent))
    skipAdvice = skipAdvice == true

    local result = {
        approved = false,
        reason = "invalid",
        product = product,
        basePrice = basePrice,
        depositPercent = depositPercent,
        deposit = basePrice * depositPercent / 100,
        months = months,
        balloonPercent = product == self.TYPE_BALLOON and balloonPercent or 0,
        balloonAmount = 0,
        residualValue = 0,
        amountFinanced = 0,
        interestRate = 0,
        monthlyPayment = 0,
        totalCost = 0,
        grade = nil,
        dscr = nil,
        dscrTarget = 0.80,
        minimumDepositPercent = 0,
        refundableDeposit = product == self.TYPE_OPERATING_LEASE,
        assessmentBasis = "standard",
        providerLtv = nil,
        liquidityReserveMonths = nil,
        securityCoverage = nil,
        securityStrength = "unknown",
        trackedPeriods = 0,
        stageTextKey = nil,
        monthlyIncome = 0,
        existingMonthlyCommitments = 0,
        totalMonthlyCommitments = 0,
        cashAfterDeposit = 0,
        paymentConduct = nil,
        conductRateAdjustment = 0,
        lenderId = nil,
        lenderNameKey = nil,
        providerRateAdjustment = 0,
        relationshipRateAdjustment = 0,
        relationshipTier = "NEW",
        marketState = "SELECTIVE",
        dealFit = "STANDARD"
    }

    if farmId == nil or farmId <= 0 or basePrice < 1000 or self.repository == nil or self.loanService == nil then return result end
    local farm = getFarm(farmId)
    if farm == nil then return result end

    local dealer = self.repository.dealershipService
    local pending = dealer ~= nil and dealer.getPendingFinanceExposure ~= nil
        and dealer:getPendingFinanceExposure(farmId) or {count=0,depositBalance=0,monthlyPayment=0,principal=0,collateral=0}
    result.pendingOrderCount = pending.count
    result.pendingOrderDepositBalance = pending.depositBalance
    result.pendingOrderMonthlyPayments = pending.monthlyPayment
    result.cashAfterDeposit = safeNumber(farm.money) - pending.depositBalance - result.deposit
    if result.cashAfterDeposit < 0 then
        result.reason = "funds"
        if not skipAdvice then self:populateQuoteRecommendations(result, farmId, basePrice, depositPercent, months, product, balloonPercent) end
        return result
    end

    local valuation = RFF_FarmValuation:calculate(farmId, self.repository)
    local credit = RFF_CreditProfile:calculate(farmId, valuation, self.repository)
    -- Quote-only projection: do not post undelivered machines or loans to the
    -- farm ledger. Existing reservation deposits have already left farm cash.
    local projectedValuation = {}
    for key, value in pairs(valuation) do projectedValuation[key] = value end
    valuation = projectedValuation
    valuation.liabilities = safeNumber(valuation.liabilities) + pending.principal
    local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(self.repository, farmId) or nil
    result.paymentConduct = conduct
    result.conductRateAdjustment = conduct ~= nil and safeNumber(conduct.rateAdjustment) or 0

    result.trackedPeriods = math.max(0, math.floor(safeNumber(credit.trackedPeriods)))
    result.stageTextKey = credit.stageTextKey
    result.monthlyIncome = math.max(0, safeNumber(credit.monthlyIncome))
    local tenancyRent = self.repository:getMonthlyTenancyRent(farmId) or 0
    result.existingMonthlyCommitments = math.max(0, self.loanService:getMonthlyDebtService(farmId) + tenancyRent + pending.monthlyPayment)
    if conduct ~= nil and conduct.declineNewCredit then
        result.reason = "payment_conduct"
        return result
    end

    -- Asset finance is secured substantially by the supplied asset. Providers therefore assess
    -- the farm differently from an unsecured cash loan: the asset contributes recovery value,
    -- and strong post-deposit liquidity can support a transaction where seasonal/trailing income
    -- history alone would make the generic bank-loan DSCR look artificially weak.
    local adjustedCredit = {}
    for key, value in pairs(credit) do adjustedCredit[key] = value end
    local assetSecurityFactor = product == self.TYPE_OPERATING_LEASE and 0.80 or 0.65
    adjustedCredit.collateral = math.max(0, safeNumber(credit.collateral) - pending.depositBalance * 0.30) + pending.collateral + basePrice * assetSecurityFactor
    local assessmentContext = {additionalDebtService=pending.monthlyPayment}
    local function getReserveMonths(payment)
        local commitments = payment + pending.monthlyPayment
        return commitments > 0 and math.max(0, result.cashAfterDeposit) / commitments or math.huge
    end

    if product == self.TYPE_OPERATING_LEASE then
        local residual = basePrice * self:getResidualRatio(months)
        result.residualValue = residual
        result.amountFinanced = 0

        -- A lease security deposit is genuinely refundable collateral. It does not buy down the
        -- provider's capital in the way an HP deposit does, so rental is calculated on the full
        -- asset cost less the provider's expected residual value.
        result.securityCoverage = basePrice > 0 and (result.deposit + residual) / basePrice or 0
        if result.securityCoverage >= 0.65 then
            result.securityStrength = "strong"
        elseif result.securityCoverage >= 0.45 then
            result.securityStrength = "moderate"
        else
            result.securityStrength = "weak"
        end

        local baseEval = self.loanService:evaluateApplication(
            farmId,
            math.max(1000, basePrice * 0.35),
            months,
            RFF_LoanService.TYPE_TERM,
            valuation,
            adjustedCredit,
            assessmentContext
        )

        local grade = baseEval.approved and (baseEval.grade or "C") or nil
        local pricingGrade = grade or "C"
        local annualRate = self.loanService:getBaseRate() + (self.loanService:getPricingSpread(pricingGrade) or 0) + (self.PRODUCT_RATE_ADJUSTMENT[product] or 0) + result.conductRateAdjustment
        local monthlyRental = self:calculatePaymentWithResidual(basePrice, annualRate, months, residual)
        local totalCommitments = result.existingMonthlyCommitments + monthlyRental
        local actualDscr = totalCommitments > 0 and result.monthlyIncome / totalCommitments or math.huge

        result.interestRate = annualRate
        result.monthlyPayment = monthlyRental
        result.totalCost = monthlyRental * months
        result.totalMonthlyCommitments = totalCommitments
        result.dscr = result.trackedPeriods < 3 and nil or actualDscr
        result.minimumDepositPercent = self:getMinimumDepositForGrade(grade or "D", product)
        result.liquidityReserveMonths = getReserveMonths(monthlyRental)

        -- If the generic credit route found a grade, still test the actual proposed rental rather
        -- than the proxy loan amount used by the generic engine.
        if grade ~= nil and result.trackedPeriods >= 3 and result.monthlyIncome > 0 and actualDscr < result.dscrTarget then
            grade = nil
        end

        if grade == nil then
            -- Lease-specific alternative assessment. The provider retains ownership of the asset,
            -- so strong liquid reserves and recoverable asset/security value can compensate for a
            -- short or highly seasonal trading-income record.
            local cashToAsset = basePrice > 0 and math.max(0, result.cashAfterDeposit) / basePrice or 0
            local reserveMonths = result.liquidityReserveMonths
            local coverage = result.securityCoverage or 0

            if reserveMonths >= 36 and cashToAsset >= 1.00 and coverage >= 0.55 then
                grade = "B"
            elseif reserveMonths >= 18 and cashToAsset >= 0.50 and coverage >= 0.45 then
                grade = "C"
            elseif reserveMonths >= 9 and cashToAsset >= 0.25 and coverage >= 0.35 then
                grade = "D"
            end

            if grade ~= nil then
                result.assessmentBasis = "lease_liquidity_security"
                result.minimumDepositPercent = self:getMinimumDepositForGrade(grade, product)
                annualRate = self.loanService:getBaseRate() + (self.loanService:getPricingSpread(grade) or 0) + (self.PRODUCT_RATE_ADJUSTMENT[product] or 0) + result.conductRateAdjustment
                monthlyRental = self:calculatePaymentWithResidual(basePrice, annualRate, months, residual)
                totalCommitments = result.existingMonthlyCommitments + monthlyRental
                actualDscr = totalCommitments > 0 and result.monthlyIncome / totalCommitments or math.huge
                result.interestRate = annualRate
                result.monthlyPayment = monthlyRental
                result.totalCost = monthlyRental * months
                result.totalMonthlyCommitments = totalCommitments
                result.dscr = result.trackedPeriods < 3 and nil or actualDscr
                result.liquidityReserveMonths = getReserveMonths(monthlyRental)
            end
        end

        if grade == nil then
            result.reason = baseEval.reason or "affordability"
            if not skipAdvice then self:populateQuoteRecommendations(result, farmId, basePrice, depositPercent, months, product, balloonPercent) end
            return result
        end

        if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end
        result.grade = grade
        local provider = self:selectProvider(farmId, product, grade, basePrice)
        result.lenderId = provider.id
        result.lenderNameKey = provider.nameKey
        result.providerRateAdjustment = provider.providerRateAdjustment
        result.relationshipRateAdjustment = provider.relationshipRateAdjustment
        result.relationshipTier = provider.relationshipTier
        result.marketState = provider.marketState or "SELECTIVE"
        result.dealFit = provider.dealFit or "STANDARD"
        annualRate = self.loanService:getBaseRate() + (self.loanService:getPricingSpread(grade) or 0) + (self.PRODUCT_RATE_ADJUSTMENT[product] or 0) + result.conductRateAdjustment + safeNumber(provider.totalRateAdjustment)
        monthlyRental = self:calculatePaymentWithResidual(basePrice, annualRate, months, residual)
        totalCommitments = result.existingMonthlyCommitments + monthlyRental
        actualDscr = totalCommitments > 0 and result.monthlyIncome / totalCommitments or math.huge
        result.interestRate = annualRate
        result.monthlyPayment = monthlyRental
        result.totalCost = monthlyRental * months
        result.totalMonthlyCommitments = totalCommitments
        result.dscr = result.trackedPeriods < 3 and nil or actualDscr
        result.liquidityReserveMonths = getReserveMonths(monthlyRental)
        result.minimumDepositPercent = self:getMinimumDepositForGrade(grade, product)
        if depositPercent + 0.01 < result.minimumDepositPercent then
            result.reason = "deposit"
            if not skipAdvice then self:populateQuoteRecommendations(result, farmId, basePrice, depositPercent, months, product, balloonPercent) end
            return result
        end

        result.approved = true
        result.reason = "approved"
        return result
    end

    local financed = math.max(0, basePrice - result.deposit)
    result.amountFinanced = financed -- Always expose the amount being assessed, even on a declined quote.
    if financed < 1000 then result.reason = "invalid" return result end

    local balloon = product == self.TYPE_BALLOON and basePrice * balloonPercent / 100 or 0
    balloon = math.min(balloon, financed * 0.75)
    result.balloonAmount = balloon

    local baseEval = self.loanService:evaluateApplication(farmId, financed, months, RFF_LoanService.TYPE_TERM, valuation, adjustedCredit, assessmentContext)
    local grade = baseEval.approved and (baseEval.grade or "C") or nil

    local provisionalRate = self.loanService:getBaseRate() + (self.loanService:getPricingSpread(grade or "C") or 0) + (self.PRODUCT_RATE_ADJUSTMENT[product] or 0) + result.conductRateAdjustment
    local provisionalPayment = self:calculatePaymentWithResidual(financed, provisionalRate, months, balloon)
    result.interestRate = provisionalRate
    result.monthlyPayment = provisionalPayment
    result.totalCost = result.deposit + provisionalPayment * months + balloon
    result.totalMonthlyCommitments = result.existingMonthlyCommitments + provisionalPayment
    result.dscr = result.trackedPeriods < 3 and nil or (result.totalMonthlyCommitments > 0 and result.monthlyIncome / result.totalMonthlyCommitments or math.huge)
    result.liquidityReserveMonths = getReserveMonths(provisionalPayment)

    if grade == nil then
        -- Secondary asset-finance assessment: secured LTV plus liquidity reserve.
        -- This is intentionally product-specific and does not alter ordinary RFF bank/mortgage lending.
        local providerCollateral = math.max(1, safeNumber(adjustedCredit.collateral))
        local providerLtv = (math.max(0, safeNumber(valuation.liabilities)) + financed) / providerCollateral
        result.providerLtv = providerLtv

        if providerLtv <= 0.55 and result.liquidityReserveMonths >= 24 then
            grade = "B"
        elseif providerLtv <= 0.70 and result.liquidityReserveMonths >= 12 then
            grade = "C"
        elseif providerLtv <= 0.82 and result.liquidityReserveMonths >= 6 then
            grade = "D"
        end

        if grade == nil then
            result.reason = baseEval.reason or "affordability"
            result.grade = baseEval.grade
            if not skipAdvice then self:populateQuoteRecommendations(result, farmId, basePrice, depositPercent, months, product, balloonPercent) end
            return result
        end
        result.assessmentBasis = "asset_security_liquidity"
    end

    if conduct ~= nil and RFF_PaymentConduct ~= nil then grade = RFF_PaymentConduct:capGrade(grade, conduct.minimumGrade) end
    result.grade = grade
    result.minimumDepositPercent = self:getMinimumDepositForGrade(result.grade, product)
    if depositPercent + 0.01 < result.minimumDepositPercent then
        result.reason = "deposit"
        if not skipAdvice then self:populateQuoteRecommendations(result, farmId, basePrice, depositPercent, months, product, balloonPercent) end
        return result
    end

    local provider = self:selectProvider(farmId, product, result.grade, basePrice)
    result.lenderId = provider.id
    result.lenderNameKey = provider.nameKey
    result.providerRateAdjustment = provider.providerRateAdjustment
    result.relationshipRateAdjustment = provider.relationshipRateAdjustment
    result.relationshipTier = provider.relationshipTier
    result.marketState = provider.marketState or "SELECTIVE"
    result.dealFit = provider.dealFit or "STANDARD"
    local annualRate = self.loanService:getBaseRate() + (self.loanService:getPricingSpread(result.grade) or 0) + (self.PRODUCT_RATE_ADJUSTMENT[product] or 0) + result.conductRateAdjustment + safeNumber(provider.totalRateAdjustment)
    result.interestRate = annualRate
    result.monthlyPayment = self:calculatePaymentWithResidual(financed, annualRate, months, balloon)
    result.totalCost = result.deposit + result.monthlyPayment * months + balloon
    result.totalMonthlyCommitments = result.existingMonthlyCommitments + result.monthlyPayment
    result.dscr = result.trackedPeriods < 3 and nil or (result.totalMonthlyCommitments > 0 and result.monthlyIncome / result.totalMonthlyCommitments or math.huge)
    result.liquidityReserveMonths = getReserveMonths(result.monthlyPayment)

    if result.providerLtv ~= nil then
        if result.providerLtv <= 0.55 then result.securityStrength = "strong"
        elseif result.providerLtv <= 0.75 then result.securityStrength = "moderate"
        else result.securityStrength = "weak" end
    else
        result.securityStrength = "strong"
    end

    result.approved = true
    result.reason = "approved"
    return result
end

function RFF_AssetFinanceService:createAgreementFromPurchase(data, vehicle)
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil or data == nil or vehicle == nil then return nil end
    local farmId = safeNumber(data.farmId)
    if farmId <= 0 then return nil end

    local currentPeriod = self.repository:getCurrentPeriodIndex()
    local agreement = {
        id = self.repository:getNextAssetFinanceId(),
        farmId = farmId,
        product = data.product or self.TYPE_HIRE_PURCHASE,
        vehicleUniqueId = vehicle.uniqueId or "",
        vehicleName = vehicle.getName ~= nil and vehicle:getName() or (data.vehicleName or "Financed asset"),
        storeItemXml = data.storeItemXml or "",
        basePrice = safeNumber(data.basePrice),
        depositPercent = safeNumber(data.depositPercent),
        depositPaid = safeNumber(data.deposit),
        refundableDeposit = data.product == self.TYPE_OPERATING_LEASE and safeNumber(data.deposit) or 0,
        originalFinanced = safeNumber(data.amountFinanced),
        principal = data.product == self.TYPE_OPERATING_LEASE and 0 or safeNumber(data.amountFinanced),
        balloonAmount = safeNumber(data.balloonAmount),
        residualValue = safeNumber(data.residualValue),
        interestRate = safeNumber(data.interestRate),
        termMonths = math.max(1, math.floor(safeNumber(data.months))),
        remainingMonths = math.max(1, math.floor(safeNumber(data.months))),
        monthlyPayment = safeNumber(data.monthlyPayment),
        riskGrade = data.grade or "C",
        lenderId = data.lenderId or "PRIMARY_BANK",
        lenderNameKey = data.lenderNameKey or self:getProviderNameKey(data.lenderId or "PRIMARY_BANK"),
        lenderMarketState = data.marketState or "SELECTIVE",
        lenderDealFit = data.dealFit or "STANDARD",
        lenderAssignmentLegacy = false,
        relationshipDealRecorded = false,
        relationshipCompletionRecorded = false,
        relationshipRecoveryRecorded = false,
        createdPeriod = currentPeriod,
        lastPaymentPeriod = currentPeriod,
        paymentsMade = 0,
        missedPayments = 0,
        arrearsPrincipal = 0,
        arrearsInterest = 0,
        arrearsRent = 0,
        arrearsFees = 0,
        arrearsBalance = 0,
        arrearsAgeMonths = 0,
        arrearsStage = "CURRENT",
        defaultInterestAccrued = 0,
        adminChargesAccrued = 0,
        defaultEvents = 0,
        currentDefault = false,
        defaultRecorded = false,
        recoveryEligible = false,
        lastDefaultManagementPeriod = currentPeriod,
        consecutiveMissedPayments = 0,
        maxConsecutiveMissedPayments = 0,
        lastMissedPeriod = 0,
        lastSuccessfulPaymentPeriod = currentPeriod,
        lastArrearsClearedPeriod = 0,
        arrearsSchemaVersion = 1,
        principalPaid = 0,
        interestPaid = 0,
        leaseRentPaid = 0,
        completedPeriod = 0,
        status = "ACTIVE",
        titleRetained = data.product ~= self.TYPE_OPERATING_LEASE,
        returnDue = false,
        returned = false,
        leaseWarningTwoMonths = false,
        leaseWarningOneMonth = false,
        returnedPeriod = 0,
        returnRepairCost = 0,
        returnMaintenancePenalty = 0,
        returnWashingCost = 0,
        returnEarlyTerminationCharge = 0,
        returnEarlyTerminated = false,
        returnRemainingMonths = 0,
        returnFutureRent = 0,
        returnArrearsApplied = 0,
        returnDeductions = 0,
        returnDepositRefund = 0,
        returnAdditionalCharge = 0,
        returnDamage = 0,
        returnDirt = 0,
        returnAdsApplied = false,
        returnAdsCondition = 0,
        returnAdsServiceLevel = 0,
        returnAdsBreakdownCount = 0,
        recoveryEligiblePeriod = 0,
        recoveryPending = false,
        lastRecoveryBlockedPeriod = 0,
        recovered = false,
        recoveredPeriod = 0,
        recoveryMethod = "",
        recoveryMarketValue = 0,
        recoveryAdjustedMarketValue = 0,
        recoveryTechnicalAdjustment = 0,
        recoveryRealisedValue = 0,
        recoveryCosts = 0,
        recoveryDebtAtRecovery = 0,
        recoveryDepositApplied = 0,
        recoveryShortfall = 0,
        recoverySurplus = 0,
        recoveryLiabilityLoanId = 0,
        recoveryAdsApplied = false,
        recoveryAdsCondition = 0,
        recoveryAdsServiceLevel = 0,
        recoveryAdsBreakdownCount = 0,
        recoveryAdsRepairCost = 0,
        recoveryAdsMaintenancePenalty = 0
    }
    self.repository:addAssetFinance(agreement)
    if self.relationshipService ~= nil then
        local volume = agreement.product == self.TYPE_OPERATING_LEASE and agreement.basePrice or agreement.originalFinanced
        self.relationshipService:recordAcceptedDeal(agreement.farmId, agreement.lenderId, volume, false)
        agreement.relationshipDealRecorded = true
    end
    return agreement
end

function RFF_AssetFinanceService:canAfford(farmId, amount)
    amount = math.max(0, safeNumber(amount))
    if self.repository ~= nil and self.repository.getAvailableFunds ~= nil then
        return self.repository:getAvailableFunds(farmId) >= amount
    end
    local farm = getFarm(farmId)
    return farm ~= nil and safeNumber(farm.money) >= amount
end

function RFF_AssetFinanceService:charge(farmId, amount, moneyType)
    amount = math.max(0, safeNumber(amount))
    if amount > 0 then g_currentMission:addMoney(-amount, farmId, moneyType, true, true) end
end

function RFF_AssetFinanceService:credit(farmId, amount, moneyType)
    amount = math.max(0, safeNumber(amount))
    if amount > 0 then g_currentMission:addMoney(amount, farmId, moneyType, true, true) end
end

function RFF_AssetFinanceService:notifyLeaseTerm(agreement, monthsRemaining)
    if g_currentMission == nil then return end
    local key = monthsRemaining == 1 and "rff_asset_lease_warning_one_month" or "rff_asset_lease_warning_two_months"
    local text = string.format(g_i18n:getText(key), agreement.vehicleName or "vehicle")

    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(agreement.lenderNameKey, RFF_NotificationService:getText("rff_phone_sender_asset_finance", "Asset Finance Provider"))
        local title = RFF_NotificationService:getText("rff_phone_title_lease", "Lease Reminder")
        if RFF_NotificationService:send(agreement.farmId, sender, title, text, "assetFinance", text, false) then return end
    end

    if g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, text)
    end
end

function RFF_AssetFinanceService:notifyMissedPayment(agreement, amount)
    if g_currentMission == nil then return end
    local text = string.format(g_i18n:getText("rff_asset_payment_missed_notification"),
        agreement.vehicleName or "Financed asset",
        g_i18n:formatMoney(math.max(0, safeNumber(amount)), 0, true, true),
        g_i18n:formatMoney(math.max(0, safeNumber(agreement.arrearsBalance)), 0, true, true))

    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(agreement.lenderNameKey, RFF_NotificationService:getText("rff_phone_sender_asset_finance", "Asset Finance Provider"))
        local title = RFF_NotificationService:getText("rff_phone_title_payment", "Payment Missed")
        if RFF_NotificationService:send(agreement.farmId, sender, title, text, "payment", text, true) then return end
    end

    if g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, text)
    end
end

function RFF_AssetFinanceService:payArrears(agreement)
    if g_currentMission == nil or not g_currentMission:getIsServer() or agreement == nil or agreement.status == "COMPLETED" or agreement.status == "RETURNED" then
        return false, "invalid", 0
    end
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(agreement) or math.max(0, safeNumber(agreement.arrearsBalance))
    if arrears <= 0.01 then return false, "nothing_due", 0 end
    if not self:canAfford(agreement.farmId, arrears) then return false, "funds", arrears end

    local principal = math.max(0, safeNumber(agreement.arrearsPrincipal))
    local interest = math.max(0, safeNumber(agreement.arrearsInterest))
    local rent = math.max(0, safeNumber(agreement.arrearsRent))
    local fees = math.max(0, safeNumber(agreement.arrearsFees))
    if principal > 0 then self:charge(agreement.farmId, principal, moneyTypePrincipal()) end
    if interest > 0 then self:charge(agreement.farmId, interest, moneyTypeInterest()) end
    if rent > 0 then self:charge(agreement.farmId, rent, moneyTypeLease()) end
    if fees > 0 then self:charge(agreement.farmId, fees, MoneyType ~= nil and (MoneyType.OTHER or moneyTypeInterest()) or nil) end
    agreement.principalPaid = safeNumber(agreement.principalPaid) + principal
    agreement.interestPaid = safeNumber(agreement.interestPaid) + interest
    agreement.leaseRentPaid = safeNumber(agreement.leaseRentPaid) + rent
    agreement.adminChargesPaid = safeNumber(agreement.adminChargesPaid) + fees
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(agreement, self.repository) else agreement.arrearsBalance = 0 end
    if self.relationshipService ~= nil then self.relationshipService:recordArrearsCleared(agreement) end

    if agreement.product ~= self.TYPE_OPERATING_LEASE and safeNumber(agreement.principal) <= 0.01 and safeNumber(agreement.remainingMonths) <= 0 then
        agreement.principal = 0
        agreement.status = "COMPLETED"
        agreement.titleRetained = false
        agreement.completedPeriod = self.repository:getCurrentPeriodIndex()
        self:recordRelationshipCompletion(agreement)
    end
    return true, nil, arrears
end

function RFF_AssetFinanceService:migrateLegacyArrears()
    if self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for _, agreement in ipairs(self.repository.assetFinance or {}) do
        if safeNumber(agreement.arrearsSchemaVersion) < 1 then
            local misses = math.max(0, math.floor(safeNumber(agreement.missedPayments)))
            agreement.arrearsPrincipal = math.max(0, safeNumber(agreement.arrearsPrincipal))
            agreement.arrearsInterest = math.max(0, safeNumber(agreement.arrearsInterest))
            agreement.arrearsRent = math.max(0, safeNumber(agreement.arrearsRent))
            agreement.consecutiveMissedPayments = misses
            agreement.maxConsecutiveMissedPayments = math.max(safeNumber(agreement.maxConsecutiveMissedPayments), misses)
            if misses > 0 then
                agreement.lastMissedPeriod = current
                if agreement.product == self.TYPE_OPERATING_LEASE then
                    agreement.arrearsRent = agreement.arrearsRent + misses * math.max(0, safeNumber(agreement.monthlyPayment))
                    agreement.remainingMonths = math.max(0, safeNumber(agreement.remainingMonths) - misses)
                else
                    for _ = 1, misses do
                        if safeNumber(agreement.remainingMonths) <= 0 then break end
                        local principal = math.max(0, safeNumber(agreement.principal))
                        local interest = principal * (safeNumber(agreement.interestRate) / 100) / 12
                        local capital = math.max(0, math.min(principal, math.max(0, safeNumber(agreement.monthlyPayment)) - interest))
                        if safeNumber(agreement.remainingMonths) <= 1 then capital = principal end
                        agreement.principal = math.max(0, principal - capital)
                        agreement.arrearsPrincipal = agreement.arrearsPrincipal + capital
                        agreement.arrearsInterest = agreement.arrearsInterest + interest
                        agreement.remainingMonths = math.max(0, safeNumber(agreement.remainingMonths) - 1)
                    end
                end
            end
            if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:getArrears(agreement) end
            if agreement.product == self.TYPE_OPERATING_LEASE and safeNumber(agreement.remainingMonths) <= 0 and agreement.status == "ACTIVE" then
                agreement.remainingMonths = 0
                agreement.status = "RETURN_DUE"
                agreement.returnDue = true
            end
            agreement.arrearsSchemaVersion = 1
        end
    end
end

function RFF_AssetFinanceService:processOwnedFinancePayment(agreement)
    if safeNumber(agreement.remainingMonths) <= 0 then return false end
    local principal = math.max(0, safeNumber(agreement.principal))
    if principal <= 0 and safeNumber(agreement.arrearsBalance) <= 0.01 then return true end
    local rate = safeNumber(agreement.interestRate) / 100 / 12
    local interest = principal * rate
    local scheduled = math.max(0, safeNumber(agreement.monthlyPayment))
    local capital = math.max(0, math.min(principal, scheduled - interest))
    local finalPeriod = safeNumber(agreement.remainingMonths) <= 1
    if finalPeriod then capital = principal end
    local due = interest + capital

    agreement.remainingMonths = math.max(0, safeNumber(agreement.remainingMonths) - 1)

    if not self:canAfford(agreement.farmId, due) then
        agreement.principal = math.max(0, principal - capital)
        if RFF_PaymentConduct ~= nil then
            RFF_PaymentConduct:recordMissed(agreement, self.repository, capital, interest, 0)
        else
            agreement.missedPayments = safeNumber(agreement.missedPayments) + 1
        end
        if self.relationshipService ~= nil then self.relationshipService:recordMissedPayment(agreement) end
        self:notifyMissedPayment(agreement, due)
        return false
    end

    self:charge(agreement.farmId, interest, moneyTypeInterest())
    self:charge(agreement.farmId, capital, moneyTypePrincipal())
    agreement.interestPaid = safeNumber(agreement.interestPaid) + interest
    agreement.principalPaid = safeNumber(agreement.principalPaid) + capital
    agreement.principal = math.max(0, principal - capital)
    agreement.paymentsMade = safeNumber(agreement.paymentsMade) + 1
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordSuccessfulScheduledPayment(agreement, self.repository) end
    if self.relationshipService ~= nil then self.relationshipService:recordSuccessfulPayment(agreement) end

    if agreement.principal <= 0.01 and safeNumber(agreement.arrearsBalance) <= 0.01 then
        agreement.principal = 0
        agreement.remainingMonths = 0
        agreement.status = "COMPLETED"
        agreement.titleRetained = false
        agreement.completedPeriod = self.repository:getCurrentPeriodIndex()
        self:recordRelationshipCompletion(agreement)
    end
    return true
end

function RFF_AssetFinanceService:processOperatingLeasePayment(agreement)
    if safeNumber(agreement.remainingMonths) <= 0 then return false end
    local rent = math.max(0, safeNumber(agreement.monthlyPayment))
    agreement.remainingMonths = math.max(0, safeNumber(agreement.remainingMonths) - 1)

    local paid = true
    if rent > 0 and not self:canAfford(agreement.farmId, rent) then
        paid = false
        if RFF_PaymentConduct ~= nil then
            RFF_PaymentConduct:recordMissed(agreement, self.repository, 0, 0, rent)
        else
            agreement.missedPayments = safeNumber(agreement.missedPayments) + 1
        end
        if self.relationshipService ~= nil then self.relationshipService:recordMissedPayment(agreement) end
        self:notifyMissedPayment(agreement, rent)
    else
        self:charge(agreement.farmId, rent, moneyTypeLease())
        agreement.leaseRentPaid = safeNumber(agreement.leaseRentPaid) + rent
        agreement.paymentsMade = safeNumber(agreement.paymentsMade) + 1
        if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordSuccessfulScheduledPayment(agreement, self.repository) end
        if self.relationshipService ~= nil then self.relationshipService:recordSuccessfulPayment(agreement) end
    end

    if agreement.remainingMonths == 2 and not agreement.leaseWarningTwoMonths then
        agreement.leaseWarningTwoMonths = true
        self:notifyLeaseTerm(agreement, 2)
    elseif agreement.remainingMonths == 1 and not agreement.leaseWarningOneMonth then
        agreement.leaseWarningOneMonth = true
        self:notifyLeaseTerm(agreement, 1)
    end

    if agreement.remainingMonths <= 0 then
        agreement.remainingMonths = 0
        agreement.status = "RETURN_DUE"
        agreement.returnDue = true
        local text = string.format(g_i18n:getText("rff_asset_lease_return_due_notification"), agreement.vehicleName or "vehicle")
        if RFF_NotificationService ~= nil then
            local sender = RFF_NotificationService:getSender(agreement.lenderNameKey, RFF_NotificationService:getText("rff_phone_sender_asset_finance", "Asset Finance Provider"))
            local title = RFF_NotificationService:getText("rff_phone_title_lease_return", "Lease Return Due")
            RFF_NotificationService:send(agreement.farmId, sender, title, text, "assetFinance", text, true)
        elseif g_currentMission ~= nil and g_currentMission.addIngameNotification ~= nil then
            g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, text)
        end
    end
    return paid
end

function RFF_AssetFinanceService:processMonthlyPayment(agreement)
    if agreement == nil or agreement.status ~= "ACTIVE" then return end
    if safeNumber(agreement.remainingMonths) <= 0 then return end
    if agreement.product == self.TYPE_OPERATING_LEASE then
        self:processOperatingLeasePayment(agreement)
    else
        self:processOwnedFinancePayment(agreement)
    end
end

function RFF_AssetFinanceService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for _, agreement in ipairs(self.repository.assetFinance or {}) do
        if agreement.status == "ACTIVE" then
            local last = safeNumber(agreement.lastPaymentPeriod)
            while last < current and agreement.status == "ACTIVE" do
                self:processMonthlyPayment(agreement)
                last = last + 1
                agreement.lastPaymentPeriod = last
            end
        end
    end
end

function RFF_AssetFinanceService:getRecoveryBlockReason(agreement)
    if agreement == nil or (agreement.status ~= "ACTIVE" and agreement.status ~= "RETURN_DUE") then return "invalid" end
    local vehicle = self:getVehicleByUniqueId(agreement.vehicleUniqueId)
    if vehicle == nil then return "vehicle_missing" end
    if getLocalCurrentVehicle() == vehicle then return "in_use" end
    if vehicle.getRootVehicle ~= nil then
        local ok, root = pcall(vehicle.getRootVehicle, vehicle)
        if ok and root ~= nil and root ~= vehicle then return "attached" end
    end
    if vehicle.getChildVehicles ~= nil then
        local ok, children = pcall(vehicle.getChildVehicles, vehicle)
        if ok and type(children) == "table" and #children > 1 then return "attachments" end
    end
    return nil
end

function RFF_AssetFinanceService:getRecoveryAssessment(agreement, voluntary)
    if agreement == nil then return nil end
    if agreement.recovered == true or agreement.status == "RECOVERED" or agreement.status == "SURRENDERED" then
        return {
            method = agreement.recoveryMethod or "RECOVERY",
            marketValue = safeNumber(agreement.recoveryMarketValue),
            adjustedMarketValue = safeNumber(agreement.recoveryAdjustedMarketValue),
            technicalAdjustment = safeNumber(agreement.recoveryTechnicalAdjustment),
            realisedValue = safeNumber(agreement.recoveryRealisedValue),
            recoveryCosts = safeNumber(agreement.recoveryCosts),
            debt = safeNumber(agreement.recoveryDebtAtRecovery),
            depositApplied = safeNumber(agreement.recoveryDepositApplied),
            shortfall = safeNumber(agreement.recoveryShortfall),
            surplus = safeNumber(agreement.recoverySurplus),
            liabilityLoanId = safeNumber(agreement.recoveryLiabilityLoanId),
            adsApplied = agreement.recoveryAdsApplied == true,
            adsCondition = safeNumber(agreement.recoveryAdsCondition),
            adsServiceLevel = safeNumber(agreement.recoveryAdsServiceLevel),
            adsBreakdownCount = safeNumber(agreement.recoveryAdsBreakdownCount),
            adsRepairCost = safeNumber(agreement.recoveryAdsRepairCost),
            adsMaintenancePenalty = safeNumber(agreement.recoveryAdsMaintenancePenalty),
            recovered = true
        }
    end

    local vehicle = self:getVehicleByUniqueId(agreement.vehicleUniqueId)
    local marketValue = vehicle ~= nil and safeCallNumber(vehicle, "getSellPrice") or 0
    if marketValue <= 0 and vehicle ~= nil then marketValue = safeCallNumber(vehicle, "getPrice") end
    local technical = RFF_ADSIntegration ~= nil and RFF_ADSIntegration:getTechnicalAssessment(vehicle) or {
        adsApplied=false, serviceLevel=0, conditionLevel=0, breakdownCount=0, maintenancePenalty=0, repairCost=0, technicalPenalty=0
    }
    local method = voluntary == true and "VOLUNTARY_SURRENDER" or "FORCED_RECOVERY"
    local factor = voluntary == true and self.VOLUNTARY_REALISATION_FACTOR or self.FORCED_REALISATION_FACTOR
    local costRate = voluntary == true and self.VOLUNTARY_RECOVERY_COST_RATE or self.FORCED_RECOVERY_COST_RATE
    local recoveryCosts = math.min(self.MAX_RECOVERY_COST, math.max(self.MIN_RECOVERY_COST, marketValue * costRate))
    local arrears = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:getArrears(agreement) or math.max(0, safeNumber(agreement.arrearsBalance))

    if agreement.product == self.TYPE_OPERATING_LEASE then
        local lease = self:getLeaseReturnAssessment(agreement)
        local repair = lease ~= nil and safeNumber(lease.repairCost) or 0
        local maintenance = lease ~= nil and safeNumber(lease.maintenancePenalty) or 0
        local cleaning = lease ~= nil and safeNumber(lease.washingCost) or 0
        local deposit = math.max(0, safeNumber(agreement.refundableDeposit))
        local debt = arrears + repair + maintenance + cleaning + recoveryCosts
        local depositApplied = math.min(deposit, debt)
        return {
            method = method, vehicle = vehicle, marketValue = marketValue, adjustedMarketValue = marketValue, technicalAdjustment = repair + maintenance, realisedValue = 0,
            recoveryCosts = recoveryCosts, arrears = arrears, repairCost = repair, maintenancePenalty = maintenance, cleaningCost = cleaning,
            debt = debt, deposit = deposit, depositApplied = depositApplied,
            shortfall = math.max(0, debt - depositApplied), surplus = math.max(0, deposit - debt),
            adsApplied = lease ~= nil and lease.adsApplied == true,
            adsCondition = lease ~= nil and safeNumber(lease.adsCondition) or 0,
            adsServiceLevel = lease ~= nil and safeNumber(lease.adsServiceLevel) or 0,
            adsBreakdownCount = lease ~= nil and safeNumber(lease.adsBreakdownCount) or 0,
            adsRepairCost = repair, adsMaintenancePenalty = maintenance,
            shortfallRate = math.max(self.loanService.BASE_RATE + 4.00, safeNumber(agreement.interestRate) + 4.00), recovered = false
        }
    end

    local principal = math.max(0, safeNumber(agreement.principal))
    local debt = principal + arrears + recoveryCosts
    -- For owned financed assets, ADS does not become a second fee. Instead the
    -- provider's recovery valuation is reduced by the dealer-standard work needed
    -- to place a neglected/broken machine back into saleable condition.
    local technicalAdjustment = technical.adsApplied == true and math.max(0, safeNumber(technical.technicalPenalty)) or 0
    local adjustedMarketValue = math.max(0, marketValue - technicalAdjustment)
    local realisedValue = adjustedMarketValue * factor
    return {
        method = method, vehicle = vehicle, marketValue = marketValue, adjustedMarketValue = adjustedMarketValue, technicalAdjustment = technicalAdjustment, realisedValue = realisedValue,
        recoveryCosts = recoveryCosts, arrears = arrears, principal = principal, debt = debt,
        deposit = 0, depositApplied = 0, shortfall = math.max(0, debt - realisedValue),
        surplus = math.max(0, realisedValue - debt),
        adsApplied = technical.adsApplied == true, adsCondition = safeNumber(technical.conditionLevel), adsServiceLevel = safeNumber(technical.serviceLevel),
        adsBreakdownCount = safeNumber(technical.breakdownCount), adsRepairCost = safeNumber(technical.repairCost), adsMaintenancePenalty = safeNumber(technical.maintenancePenalty),
        shortfallRate = math.max(self.loanService.BASE_RATE + 4.00, safeNumber(agreement.interestRate) + 4.00), recovered = false
    }
end

function RFF_AssetFinanceService:removeRecoveredVehicle(vehicle)
    if vehicle == nil or g_currentMission == nil then return false end
    local ok, err = pcall(function()
        if g_currentMission.removeVehicle ~= nil then
            g_currentMission:removeVehicle(vehicle)
        elseif vehicle.delete ~= nil then
            vehicle:delete()
        else
            error("No vehicle removal method available")
        end
    end)
    if not ok then
        print(string.format("[RealisticFarmFinance] Asset recovery vehicle removal failed: %s", tostring(err)))
        return false
    end
    return true
end

function RFF_AssetFinanceService:notifyRecoveryEligible(agreement)
    if agreement == nil then return end
    local text = string.format(g_i18n:getText("rff_asset_recovery_eligible_notification"), agreement.vehicleName or "asset")
    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(agreement.lenderNameKey, RFF_NotificationService:getText("rff_phone_sender_asset_finance", "Asset Finance Provider"))
        local title = RFF_NotificationService:getText("rff_phone_title_recovery", "Asset Recovery")
        if RFF_NotificationService:send(agreement.farmId, sender, title, text, "payment", text, true) then return end
    end
    if g_currentMission ~= nil and g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, text)
    end
end

function RFF_AssetFinanceService:notifyRecoveryComplete(agreement, assessment, voluntary)
    if agreement == nil or assessment == nil then return end
    local key = voluntary == true and "rff_asset_surrender_complete_notification" or "rff_asset_recovery_complete_notification"
    local text = string.format(g_i18n:getText(key), agreement.vehicleName or "asset",
        g_i18n:formatMoney(assessment.realisedValue or 0, 0, true, true),
        g_i18n:formatMoney(assessment.shortfall or 0, 0, true, true))
    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getSender(agreement.lenderNameKey, RFF_NotificationService:getText("rff_phone_sender_asset_finance", "Asset Finance Provider"))
        local title = RFF_NotificationService:getText("rff_phone_title_recovery", "Asset Recovery")
        if RFF_NotificationService:send(agreement.farmId, sender, title, text, "payment", text, true) then return end
    end
    if g_currentMission ~= nil and g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, text)
    end
end

function RFF_AssetFinanceService:recoverAsset(agreement, voluntary)
    if g_currentMission == nil or not g_currentMission:getIsServer() or agreement == nil then return false, "server", nil end
    if agreement.status ~= "ACTIVE" and agreement.status ~= "RETURN_DUE" then return false, "invalid", nil end
    if voluntary == true then
        if agreement.currentDefault ~= true and agreement.arrearsStage ~= "DEFAULT_NOTICE" and agreement.arrearsStage ~= "RECOVERY" then return false, "not_default", nil end
    elseif agreement.recoveryEligible ~= true then
        return false, "not_eligible", nil
    end

    local block = self:getRecoveryBlockReason(agreement)
    if block ~= nil then return false, block, self:getRecoveryAssessment(agreement, voluntary) end
    local assessment = self:getRecoveryAssessment(agreement, voluntary)
    if assessment == nil or assessment.vehicle == nil then return false, "vehicle_missing", assessment end
    if not self:removeRecoveredVehicle(assessment.vehicle) then return false, "remove_failed", assessment end

    if agreement.product == self.TYPE_OPERATING_LEASE then
        agreement.returnRepairCost = safeNumber(assessment.repairCost)
        agreement.returnMaintenancePenalty = safeNumber(assessment.maintenancePenalty)
        agreement.returnWashingCost = safeNumber(assessment.cleaningCost)
        agreement.returnAdsApplied = assessment.adsApplied == true
        agreement.returnAdsCondition = safeNumber(assessment.adsCondition)
        agreement.returnAdsServiceLevel = safeNumber(assessment.adsServiceLevel)
        agreement.returnAdsBreakdownCount = safeNumber(assessment.adsBreakdownCount)
        agreement.returnArrearsApplied = math.min(safeNumber(assessment.arrears), safeNumber(assessment.depositApplied))
        agreement.returnDeductions = safeNumber(assessment.debt)
        agreement.returnDepositRefund = safeNumber(assessment.surplus)
        agreement.returnAdditionalCharge = safeNumber(assessment.shortfall)
        agreement.refundableDeposit = 0
        if assessment.surplus > 0 then
            if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(agreement.farmId, "Lease recovery deposit refund - " .. (agreement.vehicleName or "asset")) end
            self:credit(agreement.farmId, assessment.surplus, moneyTypeLeaseReturn())
        end
    else
        agreement.principal = 0
        agreement.titleRetained = false
        if assessment.surplus > 0 then
            if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(agreement.farmId, "Asset recovery surplus - " .. (agreement.vehicleName or "asset")) end
            self:credit(agreement.farmId, assessment.surplus, MoneyType ~= nil and (MoneyType.SHOP_VEHICLE_SELL or moneyTypePrincipal()) or nil)
        end
    end

    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(agreement, self.repository) end
    local liability = nil
    if assessment.shortfall > 0.01 and self.loanService ~= nil and self.loanService.createRecoveryShortfall ~= nil then
        liability = self.loanService:createRecoveryShortfall(agreement, assessment.shortfall, assessment.shortfallRate, assessment)
    end

    agreement.recovered = true
    agreement.recoveredPeriod = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    agreement.recoveryMethod = assessment.method
    agreement.recoveryMarketValue = assessment.marketValue
    agreement.recoveryAdjustedMarketValue = assessment.adjustedMarketValue or assessment.marketValue
    agreement.recoveryTechnicalAdjustment = assessment.technicalAdjustment or 0
    agreement.recoveryRealisedValue = assessment.realisedValue
    agreement.recoveryCosts = assessment.recoveryCosts
    agreement.recoveryDebtAtRecovery = assessment.debt
    agreement.recoveryDepositApplied = assessment.depositApplied or 0
    agreement.recoveryShortfall = assessment.shortfall
    agreement.recoverySurplus = assessment.surplus
    agreement.recoveryLiabilityLoanId = liability ~= nil and (liability.id or 0) or 0
    agreement.recoveryAdsApplied = assessment.adsApplied == true
    agreement.recoveryAdsCondition = safeNumber(assessment.adsCondition)
    agreement.recoveryAdsServiceLevel = safeNumber(assessment.adsServiceLevel)
    agreement.recoveryAdsBreakdownCount = safeNumber(assessment.adsBreakdownCount)
    agreement.recoveryAdsRepairCost = safeNumber(assessment.adsRepairCost or assessment.repairCost)
    agreement.recoveryAdsMaintenancePenalty = safeNumber(assessment.adsMaintenancePenalty or assessment.maintenancePenalty)
    agreement.recoveryPending = false
    agreement.recoveryEligible = false
    agreement.currentDefault = false
    agreement.returnDue = false
    agreement.remainingMonths = 0
    agreement.completedPeriod = agreement.recoveredPeriod
    agreement.status = voluntary == true and "SURRENDERED" or "RECOVERED"
    assessment.liabilityLoanId = agreement.recoveryLiabilityLoanId
    if self.relationshipService ~= nil and agreement.relationshipRecoveryRecorded ~= true then
        self.relationshipService:recordRecovery(agreement, false, voluntary == true)
        agreement.relationshipRecoveryRecorded = true
    end
    self:notifyRecoveryComplete(agreement, assessment, voluntary)
    return true, nil, assessment
end

function RFF_AssetFinanceService:attemptForcedRecovery(agreement)
    if agreement == nil or agreement.recoveryEligible ~= true then return false, "not_eligible", nil end
    local current = self.repository ~= nil and self.repository:getCurrentPeriodIndex() or 0
    local eligiblePeriod = math.max(0, safeNumber(agreement.recoveryEligiblePeriod))
    if eligiblePeriod <= 0 then
        agreement.recoveryEligiblePeriod = current
        agreement.recoveryPending = true
        return false, "grace", nil
    end
    if current <= eligiblePeriod then
        agreement.recoveryPending = true
        return false, "grace", nil
    end
    local ok, reason, assessment = self:recoverAsset(agreement, false)
    if not ok and (reason == "in_use" or reason == "attached" or reason == "attachments") then
        agreement.recoveryPending = true
        agreement.lastRecoveryBlockedPeriod = current
    end
    return ok, reason, assessment
end

function RFF_AssetFinanceService:onDayChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() or self.repository == nil then return end
    local current = self.repository:getCurrentPeriodIndex()
    for _, agreement in ipairs(self.repository.assetFinance or {}) do
        if agreement.recoveryPending == true and agreement.recoveryEligible == true and current > math.max(0, safeNumber(agreement.recoveryEligiblePeriod)) then
            self:attemptForcedRecovery(agreement)
        end
    end
end

function RFF_AssetFinanceService:getOutstandingLiability(agreement)
    if agreement == nil or agreement.status == "COMPLETED" or agreement.status == "RETURNED" or agreement.status == "RECOVERED" or agreement.status == "SURRENDERED" then return 0 end
    local arrears = math.max(0, safeNumber(agreement.arrearsBalance))
    if agreement.product == self.TYPE_OPERATING_LEASE then return arrears end
    return math.max(0, safeNumber(agreement.principal)) + arrears
end

function RFF_AssetFinanceService:getSettlementAmount(agreement)
    if agreement == nil or agreement.status ~= "ACTIVE" or agreement.product == self.TYPE_OPERATING_LEASE then return 0 end
    return math.max(0, safeNumber(agreement.principal)) + math.max(0, safeNumber(agreement.arrearsBalance))
end

function RFF_AssetFinanceService:settleAgreement(agreement)
    if g_currentMission == nil or not g_currentMission:getIsServer() or agreement == nil or agreement.status ~= "ACTIVE" or agreement.product == self.TYPE_OPERATING_LEASE then
        return false, "invalid", 0
    end
    local total = self:getSettlementAmount(agreement)
    if total > 0 and not self:canAfford(agreement.farmId, total) then return false, "funds", total end
    local arrears = math.max(0, safeNumber(agreement.arrearsBalance))
    if arrears > 0 then
        local ok = self:payArrears(agreement)
        if not ok then return false, "funds", total end
    end
    local principal = math.max(0, safeNumber(agreement.principal))
    if principal > 0 then
        self:charge(agreement.farmId, principal, moneyTypePrincipal())
        agreement.principalPaid = safeNumber(agreement.principalPaid) + principal
    end
    agreement.principal = 0
    agreement.remainingMonths = 0
    agreement.status = "COMPLETED"
    agreement.titleRetained = false
    agreement.completedPeriod = self.repository:getCurrentPeriodIndex()
    self:recordRelationshipCompletion(agreement)
    return true, nil, total
end

function RFF_AssetFinanceService:getEarlyTerminationCharge(agreement)
    if agreement == nil or agreement.product ~= self.TYPE_OPERATING_LEASE or agreement.status ~= "ACTIVE" then return 0, 0 end
    if agreement.currentDefault == true or agreement.arrearsStage == "DEFAULT_NOTICE" or agreement.arrearsStage == "RECOVERY" then
        return 0, math.max(0, safeNumber(agreement.monthlyPayment)) * math.max(0, math.floor(safeNumber(agreement.remainingMonths)))
    end
    local remainingMonths = math.max(0, math.floor(safeNumber(agreement.remainingMonths)))
    local monthlyRent = math.max(0, safeNumber(agreement.monthlyPayment))
    local futureRent = monthlyRent * remainingMonths
    if remainingMonths <= 0 or monthlyRent <= 0 then return 0, futureRent end

    -- A voluntary early return does not accelerate every remaining rental. Instead
    -- the provider charges 35% of the remaining contractual rentals, capped at
    -- six monthly rentals. This keeps the lease a meaningful commitment while
    -- still providing a realistic exit route for a farm whose circumstances change.
    local percentageCharge = futureRent * self.EARLY_TERMINATION_RENT_RATE
    local cap = monthlyRent * self.EARLY_TERMINATION_MAX_RENTALS
    return math.max(0, math.floor(math.min(percentageCharge, cap) + 0.5)), futureRent
end

function RFF_AssetFinanceService:getLeaseReturnAssessment(agreement)
    if agreement == nil or agreement.product ~= self.TYPE_OPERATING_LEASE then return nil end

    if agreement.status == "RETURNED" then
        return {
            vehicle = nil,
            deposit = math.max(0, safeNumber(agreement.refundableDeposit)),
            repairCost = math.max(0, safeNumber(agreement.returnRepairCost)),
            maintenancePenalty = math.max(0, safeNumber(agreement.returnMaintenancePenalty)),
            washingCost = math.max(0, safeNumber(agreement.returnWashingCost)),
            earlyTerminationCharge = math.max(0, safeNumber(agreement.returnEarlyTerminationCharge)),
            earlyTerminated = agreement.returnEarlyTerminated == true,
            remainingMonthsAtReturn = math.max(0, safeNumber(agreement.returnRemainingMonths)),
            futureRentAtReturn = math.max(0, safeNumber(agreement.returnFutureRent)),
            arrears = math.max(0, safeNumber(agreement.returnArrearsApplied)),
            deductions = math.max(0, safeNumber(agreement.returnDeductions)),
            depositRefund = math.max(0, safeNumber(agreement.returnDepositRefund)),
            additionalCharge = math.max(0, safeNumber(agreement.returnAdditionalCharge)),
            damage = math.max(0, safeNumber(agreement.returnDamage)),
            dirt = math.max(0, safeNumber(agreement.returnDirt)),
            adsApplied = agreement.returnAdsApplied == true,
            adsCondition = safeNumber(agreement.returnAdsCondition),
            adsServiceLevel = safeNumber(agreement.returnAdsServiceLevel),
            adsBreakdownCount = safeNumber(agreement.returnAdsBreakdownCount),
            returned = true
        }
    end

    local vehicle = self:getVehicleByUniqueId(agreement.vehicleUniqueId)
    local deposit = math.max(0, safeNumber(agreement.refundableDeposit))
    local damage = vehicle ~= nil and math.max(0, math.min(1, safeCallNumber(vehicle, "getVehicleDamage"))) or 0
    local dirt = vehicle ~= nil and math.max(0, math.min(1, safeCallNumber(vehicle, "getDirtAmount"))) or 0
    local technical = RFF_ADSIntegration ~= nil and RFF_ADSIntegration:getTechnicalAssessment(vehicle) or nil
    local adsApplied = technical ~= nil and technical.adsApplied == true
    -- ADS vehicles use ADS's own dealer repair/service quotation. Non-ADS
    -- vehicles keep RFF's existing GIANTS repair-price path unchanged.
    local repairCost = adsApplied and math.max(0, safeNumber(technical.repairCost)) or (vehicle ~= nil and math.max(0, safeCallNumber(vehicle, "getRepairPrice")) or 0)
    local maintenancePenalty = adsApplied and math.max(0, safeNumber(technical.maintenancePenalty)) or 0
    local washingCost = deposit * 0.30 * dirt
    local earlyTerminationCharge, futureRent = self:getEarlyTerminationCharge(agreement)
    local arrears = math.max(0, safeNumber(agreement.arrearsBalance))
    local deductions = arrears + repairCost + maintenancePenalty + washingCost + earlyTerminationCharge
    local depositRefund = math.max(0, deposit - deductions)
    local additionalCharge = math.max(0, deductions - deposit)

    return {
        vehicle = vehicle,
        deposit = deposit,
        repairCost = repairCost,
        maintenancePenalty = maintenancePenalty,
        washingCost = washingCost,
        earlyTerminationCharge = earlyTerminationCharge,
        earlyTerminated = agreement.status == "ACTIVE" and earlyTerminationCharge > 0,
        remainingMonthsAtReturn = math.max(0, safeNumber(agreement.remainingMonths)),
        futureRentAtReturn = futureRent,
        arrears = arrears,
        deductions = deductions,
        depositRefund = depositRefund,
        additionalCharge = additionalCharge,
        damage = damage,
        dirt = dirt,
        adsApplied = adsApplied,
        adsCondition = adsApplied and safeNumber(technical.conditionLevel) or 0,
        adsServiceLevel = adsApplied and safeNumber(technical.serviceLevel) or 0,
        adsBreakdownCount = adsApplied and safeNumber(technical.breakdownCount) or 0,
        returned = false
    }
end

function RFF_AssetFinanceService:getLeaseReturnBlockReason(agreement, assessment)
    if agreement == nil or agreement.product ~= self.TYPE_OPERATING_LEASE or (agreement.status ~= "ACTIVE" and agreement.status ~= "RETURN_DUE") then return "invalid" end
    if agreement.currentDefault == true or agreement.arrearsStage == "DEFAULT_NOTICE" or agreement.arrearsStage == "RECOVERY" then return "default" end
    assessment = assessment or self:getLeaseReturnAssessment(agreement)
    local vehicle = assessment ~= nil and assessment.vehicle or nil
    if vehicle == nil then return "vehicle_missing" end

    if getLocalCurrentVehicle() == vehicle then return "in_use" end

    if vehicle.getRootVehicle ~= nil then
        local ok, root = pcall(vehicle.getRootVehicle, vehicle)
        if ok and root ~= nil and root ~= vehicle then return "attached" end
    end

    if vehicle.getChildVehicles ~= nil then
        local ok, children = pcall(vehicle.getChildVehicles, vehicle)
        if ok and type(children) == "table" and #children > 1 then return "attachments" end
    end

    if assessment.additionalCharge > 0 and not self:canAfford(agreement.farmId, assessment.additionalCharge) then return "funds" end
    return nil
end

function RFF_AssetFinanceService:returnOperatingLease(agreement)
    if g_currentMission == nil or not g_currentMission:getIsServer() then return false, "server", nil end
    local assessment = self:getLeaseReturnAssessment(agreement)
    if assessment == nil then return false, "invalid", nil end
    local blockReason = self:getLeaseReturnBlockReason(agreement, assessment)
    if blockReason ~= nil then return false, blockReason, assessment end

    local vehicle = assessment.vehicle
    local ok, err = pcall(function() vehicle:delete() end)
    if not ok then
        print(string.format("[RealisticFarmFinance] Lease return vehicle removal failed for agreement %s: %s", tostring(agreement.id), tostring(err)))
        return false, "remove_failed", assessment
    end

    if assessment.additionalCharge > 0 then
        self:charge(agreement.farmId, assessment.additionalCharge, moneyTypeLeaseReturn())
    end
    if assessment.depositRefund > 0 then
        self:credit(agreement.farmId, assessment.depositRefund, moneyTypeLeaseReturn())
    end

    agreement.returnRepairCost = assessment.repairCost
    agreement.returnMaintenancePenalty = assessment.maintenancePenalty or 0
    agreement.returnWashingCost = assessment.washingCost
    agreement.returnEarlyTerminationCharge = assessment.earlyTerminationCharge or 0
    agreement.returnEarlyTerminated = assessment.earlyTerminated == true
    agreement.returnRemainingMonths = assessment.remainingMonthsAtReturn or 0
    agreement.returnFutureRent = assessment.futureRentAtReturn or 0
    agreement.returnArrearsApplied = assessment.arrears or 0
    agreement.returnDeductions = assessment.deductions
    agreement.returnDepositRefund = assessment.depositRefund
    agreement.returnAdditionalCharge = assessment.additionalCharge
    agreement.returnDamage = assessment.damage
    agreement.returnDirt = assessment.dirt
    agreement.returnAdsApplied = assessment.adsApplied == true
    agreement.returnAdsCondition = assessment.adsCondition or 0
    agreement.returnAdsServiceLevel = assessment.adsServiceLevel or 0
    agreement.returnAdsBreakdownCount = assessment.adsBreakdownCount or 0
    agreement.leaseRentPaid = safeNumber(agreement.leaseRentPaid) + math.max(0, safeNumber(assessment.arrears))
    if RFF_PaymentConduct ~= nil then RFF_PaymentConduct:recordArrearsCleared(agreement, self.repository) end
    if self.relationshipService ~= nil and math.max(0, safeNumber(assessment.arrears)) > 0.01 then self.relationshipService:recordArrearsCleared(agreement) end
    agreement.returnDue = false
    agreement.returned = true
    agreement.status = "RETURNED"
    agreement.returnedPeriod = self.repository:getCurrentPeriodIndex()
    agreement.completedPeriod = agreement.returnedPeriod
    self:recordRelationshipCompletion(agreement)
    return true, nil, assessment
end

function RFF_AssetFinanceService:getMonthlyCommitment(farmId)
    local total = 0
    if self.repository == nil then return total end
    for _, agreement in ipairs(self.repository:getAssetFinanceByFarm(farmId, true)) do
        if agreement.status == "ACTIVE" and safeNumber(agreement.remainingMonths) > 0 then
            total = total + math.max(0, safeNumber(agreement.monthlyPayment))
        end
    end
    return total
end

function RFF_AssetFinanceService:canSellVehicle(vehicle)
    if vehicle == nil or self.repository == nil then return true, nil end
    local dealer=self.repository.dealershipService
    if dealer and dealer.demo and dealer.demo:record(vehicle) then return false,"finance" end
    if dealer and dealer.handover and dealer.handover:forVehicle(vehicle) then return false,"finance" end
    local agreement = self.repository:getAssetFinanceByVehicle(vehicle.uniqueId, true)
    if agreement == nil then return true, nil end
    if agreement.product == self.TYPE_OPERATING_LEASE then return false, "lease" end
    if agreement.status == "ACTIVE" and (safeNumber(agreement.principal) > 0.01 or safeNumber(agreement.arrearsBalance) > 0.01) then return false, "finance" end
    return true, nil
end
