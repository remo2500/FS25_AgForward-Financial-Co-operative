RFF_BankingService = {}
RFF_BankingService.__index = RFF_BankingService

RFF_BankingService.CREDIT_INTEREST_MARGIN = 4.00
RFF_BankingService.MIN_CREDIT_INTEREST_RATE = 0.25
RFF_BankingService.OVERDRAFT_REVIEW_MONTHS = 12
RFF_BankingService.SUSPENDED_RATE_SURCHARGE = 3.00
RFF_BankingService.UNAUTHORISED_RATE = 39.00
RFF_BankingService.UNAUTHORISED_DAILY_FEE = 10

local function safeNumber(value)
    if type(value) == "number" and value == value then return value end
    return 0
end

local function getFarm(farmId)
    return g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
end

local function moneyTypeCreditInterest()
    if MoneyType ~= nil then return MoneyType.INTEREST_PAID or MoneyType.OTHER end
    return nil
end

local function moneyTypeDebitInterest()
    if MoneyType ~= nil then return MoneyType.LOAN_INTEREST or MoneyType.OTHER end
    return nil
end

function RFF_BankingService.new(repository, loanService)
    local self = setmetatable({}, RFF_BankingService)
    self.repository = repository
    self.loanService = loanService
    if repository then repository.bankingService = self end
    return self
end

function RFF_BankingService:getCreditInterestRate()
    local baseRate = self.loanService ~= nil and self.loanService:getBaseRate() or 0
    return math.max(self.MIN_CREDIT_INTEREST_RATE, baseRate - self.CREDIT_INTEREST_MARGIN)
end

function RFF_BankingService:getOverdraftFacility(farmId)
    if self.repository == nil or self.repository.getActiveOverdraft == nil then return nil end
    return self.repository:getActiveOverdraft(farmId)
end

function RFF_BankingService:getOverdraftLimit(farmId)
    local facility = self:getOverdraftFacility(farmId)
    if facility == nil or facility.paidOff or facility.overdraftSuspended == true then return 0 end
    return math.max(0, safeNumber(facility.creditLimit))
end

function RFF_BankingService:getAvailableFunds(farmId)
    local farm = getFarm(farmId)
    if farm == nil then return 0 end
    return safeNumber(farm.money) + self:getOverdraftLimit(farmId)
end

function RFF_BankingService:getProjectedMonthlyDebitCost(farmId,includeAdmin)
    local position=self:getAccountPosition(farmId)
    local rate=position.facility and math.max(0,safeNumber(position.facility.interestRate)) or 0
    local interest=(position.authorisedUsed*rate+position.overLimit*self.UNAUTHORISED_RATE)/100/12
    local days=g_currentMission and g_currentMission.environment and g_currentMission.environment.daysPerPeriod or 1
    local admin=includeAdmin and position.overLimit>0.01 and self.UNAUTHORISED_DAILY_FEE*math.max(1,days) or 0
    return interest+admin
end

function RFF_BankingService:getAccountPosition(farmId)
    local farm = getFarm(farmId)
    local balance = farm ~= nil and safeNumber(farm.money) or 0
    local facility = self:getOverdraftFacility(farmId)
    local limit = facility ~= nil and math.max(0, safeNumber(facility.creditLimit)) or 0
    local used = math.max(0, -balance)
    local authorised = facility ~= nil and not facility.overdraftSuspended and math.min(limit, used) or 0
    local overLimit = math.max(0, used - authorised)
    local available = facility ~= nil and not facility.overdraftSuspended and math.max(0, limit - authorised) or 0
    return {
        balance = balance,
        facility = facility,
        limit = limit,
        used = used,
        authorisedUsed = authorised,
        overLimit = overLimit,
        available = available,
        suspended = facility ~= nil and facility.overdraftSuspended == true or false
    }
end

function RFF_BankingService:syncOverdraft(farmId)
    local position = self:getAccountPosition(farmId)
    local facility = position.facility
    if facility ~= nil then
        facility.drawnAmount = position.authorisedUsed
        facility.overdraftOverLimit = position.overLimit
    end
    return position
end

function RFF_BankingService:recordDailyBalance(farmId)
    if self.repository == nil or farmId == nil or farmId <= 0 then return end
    local farm = getFarm(farmId)
    if farm == nil then return end
    local state = self.repository:getFarmState(farmId, true)
    state.bankPositiveBalanceSum = safeNumber(state.bankPositiveBalanceSum) + math.max(0, safeNumber(farm.money))
    state.bankBalanceSamples = math.max(0, math.floor(safeNumber(state.bankBalanceSamples))) + 1
    state.bankLastSamplePeriod = self.repository:getCurrentPeriodIndex()
    self:syncOverdraft(farmId)
end

function RFF_BankingService:onDayChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() then return end
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if farmId ~= nil and farmId > 0 and farm ~= nil then
            self:processUnauthorisedBorrowing(farmId)
            self:recordDailyBalance(farmId)
        end
    end
end

-- Once per completed game day. No historical catch-up on installing the update:
-- unknown past balances must not be charged using today's balance.
function RFF_BankingService:processUnauthorisedBorrowing(farmId)
    local environment = g_currentMission ~= nil and g_currentMission.environment
    if environment == nil or self.repository == nil then return 0 end
    local day = math.floor(tonumber(environment.currentMonotonicDay or environment.currentDay) or 0)
    if day < 1 then return 0 end
    local state = self.repository:getFarmState(farmId, true)
    if (state.bankLastUnauthorisedDay or 0) >= day then return 0 end
    local position = self:getAccountPosition(farmId)
    state.bankLastUnauthorisedDay = day
    if position.overLimit <= 0.01 then return 0 end
    local days = math.max(1, tonumber(environment.daysPerPeriod) or 1)
    local interest = position.overLimit * self.UNAUTHORISED_RATE / 100 / (12 * days)
    interest = math.floor(interest * 100 + 0.5) / 100
    local fee = self.UNAUTHORISED_DAILY_FEE
    if interest > 0 then
        self.repository:setNextTransactionDescription(farmId, "Unauthorised overdraft interest (39% p.a.)")
        g_currentMission:addMoney(-interest, farmId, moneyTypeDebitInterest(), true, true)
    end
    self.repository:setNextTransactionDescription(farmId, "Unauthorised overdraft daily administration")
    g_currentMission:addMoney(-fee, farmId, MoneyType.OTHER, true, true)
    state.bankUnauthorisedInterestPaid = (state.bankUnauthorisedInterestPaid or 0) + interest
    state.bankUnauthorisedFeesPaid = (state.bankUnauthorisedFeesPaid or 0) + fee
    self:syncOverdraft(farmId)
    return interest + fee
end

function RFF_BankingService:notify(farmId, titleKey, fallbackTitle, textKey, fallbackText, ...)
    local args = {...}
    local template = RFF_NotificationService ~= nil and RFF_NotificationService:getText(textKey, fallbackText) or fallbackText
    local text = #args > 0 and string.format(template, unpack(args)) or template
    if RFF_NotificationService ~= nil then
        local sender = RFF_NotificationService:getText("rff_phone_sender_bank", "Primary Farm Bank")
        local title = RFF_NotificationService:getText(titleKey, fallbackTitle)
        if RFF_NotificationService:send(farmId, sender, title, text, "banking", text, true) then return end
    end
    if g_currentMission ~= nil and g_currentMission.addIngameNotification ~= nil and FSBaseMission ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, text)
    end
end

function RFF_BankingService:processCreditInterest(farmId)
    local farm = getFarm(farmId)
    if farm == nil or self.repository == nil then return 0 end
    local state = self.repository:getFarmState(farmId, true)
    local samples = math.max(0, math.floor(safeNumber(state.bankBalanceSamples)))
    local averagePositiveBalance
    if samples > 0 then
        averagePositiveBalance = math.max(0, safeNumber(state.bankPositiveBalanceSum)) / samples
    else
        averagePositiveBalance = math.max(0, safeNumber(farm.money))
    end

    local rate = self:getCreditInterestRate()
    local interest = averagePositiveBalance * (rate / 100) / 12
    if interest > 0.005 then
        if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(farmId, "Bank account interest credit") end
        g_currentMission:addMoney(interest, farmId, moneyTypeCreditInterest(), true, true)
    else
        interest = 0
    end

    state.bankLastInterestCredit = interest
    state.bankLastInterestRate = rate
    state.bankLastAverageBalance = averagePositiveBalance
    state.bankLastInterestPeriod = self.repository:getCurrentPeriodIndex()
    state.bankPositiveBalanceSum = 0
    state.bankBalanceSamples = 0
    return interest
end

function RFF_BankingService:processOverdraft(farmId)
    local position = self:syncOverdraft(farmId)
    local facility = position.facility
    if facility == nil or facility.paidOff then return end

    local chargeable = position.authorisedUsed
    if chargeable > 0 then
        local rate = math.max(0, safeNumber(facility.interestRate))
        local interest = chargeable * (rate / 100) / 12
        if interest > 0.005 then
            if self.repository ~= nil and self.repository.setNextTransactionDescription ~= nil then self.repository:setNextTransactionDescription(farmId, "Overdraft interest") end
            g_currentMission:addMoney(-interest, farmId, moneyTypeDebitInterest(), true, true)
            facility.interestPaid = safeNumber(facility.interestPaid) + interest
            facility.paymentsMade = safeNumber(facility.paymentsMade) + 1
            facility.lastSuccessfulPaymentPeriod = self.repository:getCurrentPeriodIndex()
        end
    end

    position = self:syncOverdraft(farmId)
    if position.overLimit > 0.01 then
        facility.overdraftLimitBreaches = math.max(0, math.floor(safeNumber(facility.overdraftLimitBreaches))) + 1
        facility.lastOverdraftBreachPeriod = self.repository:getCurrentPeriodIndex()
    end

    if facility.overdraftSuspended == true then return end

    facility.remainingMonths = math.max(0, math.floor(safeNumber(facility.remainingMonths)) - 1)
    if facility.remainingMonths == 2 and facility.overdraftWarningTwoMonths ~= true then
        facility.overdraftWarningTwoMonths = true
        self:notify(farmId, "rff_phone_title_overdraft", "Overdraft Review", "rff_overdraft_review_two_months", "Your overdraft facility is due for review in two months.")
    elseif facility.remainingMonths == 1 and facility.overdraftWarningOneMonth ~= true then
        facility.overdraftWarningOneMonth = true
        self:notify(farmId, "rff_phone_title_overdraft", "Overdraft Review", "rff_overdraft_review_one_month", "Your overdraft facility is due for review next month.")
    elseif facility.remainingMonths <= 0 then
        local conduct = RFF_PaymentConduct ~= nil and RFF_PaymentConduct:evaluate(self.repository, farmId) or nil
        local canRenew = position.overLimit <= 0.01 and safeNumber(facility.arrearsBalance) <= 0.01 and (conduct == nil or conduct.declineNewCredit ~= true)
        if canRenew then
            facility.remainingMonths = self.OVERDRAFT_REVIEW_MONTHS
            facility.termMonths = self.OVERDRAFT_REVIEW_MONTHS
            facility.overdraftReviewCount = math.max(0, math.floor(safeNumber(facility.overdraftReviewCount))) + 1
            facility.overdraftWarningTwoMonths = false
            facility.overdraftWarningOneMonth = false
            self:notify(farmId, "rff_phone_title_overdraft", "Overdraft Review", "rff_overdraft_review_renewed", "Your overdraft facility has been reviewed and renewed for a further 12 months.")
        else
            facility.remainingMonths = 0
            facility.overdraftSuspended = true
            self:notify(farmId, "rff_phone_title_overdraft", "Overdraft Review", "rff_overdraft_review_suspended", "Your overdraft facility was not renewed because the account is not in good standing. Further drawings are suspended; the outstanding debit balance remains payable.")
        end
    end
end

function RFF_BankingService:onPeriodChanged()
    if g_currentMission == nil or not g_currentMission:getIsServer() then return end
    for farmId, farm in pairs(g_farmManager ~= nil and g_farmManager.farmIdToFarm or {}) do
        if farmId ~= nil and farmId > 0 and farm ~= nil then
            self:processCreditInterest(farmId)
            self:processOverdraft(farmId)
        end
    end
end

function RFF_BankingService:getLastInterestCredit(farmId)
    if self.repository == nil then return 0 end
    local state = self.repository:getFarmState(farmId, false)
    return state ~= nil and math.max(0, safeNumber(state.bankLastInterestCredit)) or 0
end

function RFF_BankingService:getLastAverageBalance(farmId)
    if self.repository == nil then return 0 end
    local state = self.repository:getFarmState(farmId, false)
    return state ~= nil and math.max(0, safeNumber(state.bankLastAverageBalance)) or 0
end
