-- Read-only dashboard display. It never changes the motor, points or policies.
RFF_RoadSpeedHud = {}
RFF_RoadSpeedHud.__index = RFF_RoadSpeedHud
RFF_RoadSpeedHud.REFRESH_MS = 250

function RFF_RoadSpeedHud.new(service, modDirectory)
    return setmetatable({service=service,elapsed=0,vehicle=nil,farmId=nil,rules=nil,
        textureFilename=(modDirectory or "") .. "gui/textures/speedCircle.dds",circle=nil}, RFF_RoadSpeedHud)
end

function RFF_RoadSpeedHud:delete()
    if self.circle ~= nil then self.circle:delete(); self.circle = nil end
    self.vehicle, self.rules = nil, nil
end

function RFF_RoadSpeedHud.getPulse(timeMs, speeding)
    if not speeding then return 0 end
    -- One smooth pulse per second. The number and white face never flash.
    return 0.5 - 0.5 * math.cos((tonumber(timeMs) or 0) * math.pi * 2 / 1000)
end

local function call(object, method)
    if object ~= nil and type(object[method]) == "function" then
        local ok, value = pcall(object[method], object)
        if ok then return value end
    end
    return nil
end

function RFF_RoadSpeedHud:isEnabled(farmId)
    local repository = self.service ~= nil and self.service.repository or nil
    local state = repository ~= nil and repository:getFarmState(farmId,false) or nil
    return state == nil or state.roadSpeedHudEnabled ~= false
end

function RFF_RoadSpeedHud:setEnabled(farmId, enabled)
    local repository = self.service ~= nil and self.service.repository or nil
    if repository == nil or type(farmId) ~= "number" or farmId <= 0 then return false end
    local state = repository:getFarmState(farmId,true)
    if state == nil then return false end
    state.roadSpeedHudEnabled = enabled == true
    self.vehicle, self.farmId, self.rules, self.elapsed = nil, nil, nil, 0
    return true
end

function RFF_RoadSpeedHud:getContext()
    local mission = g_currentMission
    local hud = mission ~= nil and mission.hud or nil
    local meter = hud ~= nil and hud.speedMeter or nil
    if self.service == nil or self.service.fleetManagement == nil or hud == nil or meter == nil then return nil end
    if call(g_gui, "getIsGuiVisible") == true or call(hud, "getIsVisible") ~= true
        or call(hud, "getIsFading") == true or call(meter, "getVisible") ~= true
        or meter.isVehicleDrawSafe == false then return nil end
    local vehicle = call(g_localPlayer, "getCurrentVehicle")
    if vehicle == nil or vehicle.spec_motorized == nil or call(vehicle, "getIsAIActive") == true then return nil end
    -- Do not draw against a previous vehicle's HUD during an entry/exit transition.
    if meter.vehicle ~= vehicle then return nil end
    local farmId = call(mission, "getFarmId")
    if type(farmId) ~= "number" or farmId <= 0 then return nil end
    if not self:isEnabled(farmId) then return nil end
    return vehicle, farmId, meter
end

function RFF_RoadSpeedHud:update(dt)
    local vehicle, farmId = self:getContext()
    if vehicle == nil then
        self.vehicle, self.farmId, self.rules, self.elapsed = nil, nil, nil, 0
        return
    end
    self.elapsed = self.elapsed + math.max(0, tonumber(dt) or 0)
    if vehicle ~= self.vehicle or farmId ~= self.farmId or self.rules == nil or self.elapsed >= self.REFRESH_MS then
        self.vehicle, self.farmId, self.elapsed = vehicle, farmId, 0
        -- Only the speed-rule query, not a full finance/insurance assessment.
        self.rules = self.service:getSpeedRules(farmId, vehicle)
    end
end

function RFF_RoadSpeedHud:getDisplay(i18n)
    local rules = self.rules
    if rules == nil then return nil end
    local limit, reason = rules.limitKmh, rules.reason
    if rules.locationType ~= "ROAD" then
        -- Existing points restrictions can still apply off-road, but do not
        -- present a theoretical width/road-use limit as a field-work limit.
        limit, reason = rules.penaltyLimitKmh, rules.penaltyLimitKmh ~= nil and "PENALTY" or "OFF_ROAD"
    end
    local speed = self.service:getVehicleSpeed(self.vehicle)
    return {
        title=i18n:getText("rff_speed_hud_title"),
        value=limit ~= nil and RFF_RoadSpeedRules.formatSpeed(limit, i18n) or "--",
        number=limit ~= nil and string.format("%.0f", i18n:getSpeed(limit)) or "--",
        unit=i18n:getSpeedMeasuringUnit(),
        reason=i18n:getText("rff_speed_hud_" .. string.lower(reason or "off_road")),
        speeding=limit ~= nil and speed > limit + 1,
        fallback=reason == "FALLBACK", limitKmh=limit
    }
end

function RFF_RoadSpeedHud:draw()
    if type(renderText) ~= "function" or type(drawFilledRect) ~= "function" or g_i18n == nil or RenderText == nil then return end
    local vehicle, farmId, meter = self:getContext()
    if vehicle == nil or vehicle ~= self.vehicle or farmId ~= self.farmId or self.rules == nil then return end
    if type(meter.getPosition) ~= "function" or type(meter.scalePixelValuesToScreenVector) ~= "function" then return end
    local display = self:getDisplay(g_i18n)
    if display == nil then return end
    local anchorX, anchorY = meter:getPosition()
    if self.circle == nil then
        if Overlay == nil or type(Overlay.new) ~= "function" then return end
        self.circle = Overlay.new(self.textureFilename,0,0,0,0)
    end
    local width, height = meter:scalePixelValuesToScreenVector(164, 116)
    local _, centreOffset = meter:scalePixelValuesToScreenVector(0, 65)
    -- SpeedMeterDisplay assembles the dial to the left of the side gauges.
    -- Use its scaled dimensions, not last frame's overlay position, and reserve
    -- space for the entire reason label as well as the circular sign/glow.
    local defaultDialWidth, defaultDialCentre = meter:scalePixelValuesToScreenVector(232,116)
    local defaultRightWidth = meter:scalePixelValuesToScreenVector(23,0)
    local defaultSideWidth = meter:scalePixelValuesToScreenVector(72,0)
    local gap = meter:scalePixelValuesToScreenVector(12,0)
    local dialWidth = meter.speedBg ~= nil and meter.speedBg.width or defaultDialWidth
    local rightWidth = meter.speedBgRight ~= nil and meter.speedBgRight.width or defaultRightWidth
    local sideWidth = meter.speedBgScale ~= nil and meter.speedBgScale.width or nil
    if sideWidth == nil or sideWidth <= 0 then sideWidth = defaultSideWidth end
    local dialLeft = anchorX-dialWidth-rightWidth-sideWidth
    local dialCentreY = anchorY+(meter.speedGaugeCenterOffsetY or defaultDialCentre)
    local x = math.max(0,dialLeft-gap-width)
    local y = math.max(0,math.min(1-height,dialCentreY-centreOffset))
    local cx = x+width*0.5
    local cy = y+centreOffset
    local pulse = self.getPulse(g_time,display.speeding)
    local function disc(diameter,r,g,b,a)
        local w,h = meter:scalePixelValuesToScreenVector(diameter,diameter)
        self.circle:setPosition(cx-w*0.5,cy-h*0.5)
        self.circle:setDimension(w,h)
        self.circle:setColor(r,g,b,a)
        self.circle:render()
    end
    if display.speeding then
        disc(108,1,0.05,0.02,0.10*pulse)
        disc(101,1,0.05,0.02,0.20*pulse)
    end
    disc(94,0,0,0,0.35)
    if display.limitKmh == nil then disc(90,0.45,0.45,0.45,1)
    elseif display.fallback then disc(90,1,0.60,0.10,1)
    else disc(90,0.78+0.22*pulse,0.06,0.04,1) end
    disc(76,0.97,0.97,0.97,1)
    local _, labelHeight = meter:scalePixelValuesToScreenVector(0,18)
    drawFilledRect(x,y,width,labelHeight,0,0,0,0.60)
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE)
    setTextColor(1,1,1,1)
    setTextBold(false)
    local function line(text, baseline, pixels, bold, black, maxPixels)
        local _, dy = meter:scalePixelValuesToScreenVector(0, baseline)
        local _, size = meter:scalePixelValuesToScreenVector(0, pixels)
        setTextBold(bold)
        -- Allow for long translations or larger configured speed values.
        if type(getTextWidth) == "function" then
            local textWidth = getTextWidth(size,text)
            local maxWidth = meter:scalePixelValuesToScreenVector(maxPixels,0)
            if textWidth > maxWidth then size=size*maxWidth/textWidth end
        end
        if black then setTextColor(0.02,0.02,0.02,1) else setTextColor(1,1,1,1) end
        renderText(x+width*0.5,y+dy,size,text)
    end
    line(display.number,54,39,false,true,66)
    line(display.unit,37,11,false,true,54)
    line(display.reason,4,12,false,false,156)
    -- Restore the standard text state for other HUD/mod draws.
    setTextBold(false)
    setTextColor(1,1,1,1)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE)
end
