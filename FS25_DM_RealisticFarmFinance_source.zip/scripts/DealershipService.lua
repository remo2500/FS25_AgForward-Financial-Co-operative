-- RFF's original new-machinery order ledger. No reference-mod code or data.
RFF_DealershipService = {}
RFF_DealershipService.__index = RFF_DealershipService
local D = RFF_DealershipService
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<math.huge end
local function round(n) return math.floor(n*100+.5)/100 end
local function farm(id) return g_farmManager and g_farmManager:getFarmById(id) end
local function localServer()
    return g_currentMission and g_currentMission:getIsServer() and not (g_currentMission.missionDynamicInfo and g_currentMission.missionDynamicInfo.isMultiplayer)
end
function D.copy(value,depth)
    depth=depth or 0
    if depth>12 then error("Unsupported configuration nesting") end
    if type(value)=="table" then
        local result={}
        for k,v in pairs(value) do
            if type(k)~="string" and type(k)~="number" then error("Unsupported configuration key") end
            result[k]=D.copy(v,depth+1)
        end
        return result
    elseif value==nil or type(value)=="boolean" or type(value)=="string" or finite(value) then return value end
    error("Unsupported configuration data")
end
function D.new(manager)
    local self=setmetatable({manager=manager,repository=manager.repository,timer=0,cache={}},D)
    self.repository.dealershipService=self
    self.transferType=MoneyType.register("rffDealerDeposit","rff_dealer_deposit",RFF_RealisticFarmFinance.modName)
    return self
end
function D:state()
    self.repository.dealership=self.repository.dealership or {enabled=false,nextId=1,nextStockId=1,stock={},orders={},nextRestock=0}
    return self.repository.dealership
end
function D:clock() return self.manager.savings:clock() end
function D:date(t)
    local days=math.max(1,g_currentMission.environment.daysPerPeriod or 1)
    local period=math.floor(t);local minute=math.floor((t-period)*days*1440+.00001)
    if minute>=days*1440 then period=period+1;minute=0 end
    return string.format("%s, day %d %02d:%02d",RFF_EconomyService.date(period),math.floor(minute/1440)+1,math.floor(minute%1440/60),minute%60)
end
function D:available()
    if self.repository.dealershipLoadError then return false,"Saved dealership ledger needs recovery. Restore the save backup before ordering." end
    if not localServer() then return false,"This first dealership draft is single-player only." end
    if not self.repository.loaded then return false,"Dealership is loading." end
    if g_modIsLoaded and g_modIsLoaded.FS25_RDM_DynamicDealership then
        return false,"Disable Dynamic Dealership before enabling RFF dealership logistics."
    end
    return true
end
function D:active() return self:available() and self:state().enabled end
function D:eligible(item)
    if not item or not item.xmlFilename or not item.showInStore or item.isInAppPurchase then return false end
    local key=item.xmlFilename
    if self.cache[key]~=nil then return self.cache[key] end
    local accepted=false
    -- Positive machinery identification. Unknown/custom consumable categories fail open
    -- to the normal shop, not to a factory delay.
    if StoreItemUtil.getIsVehicle(item) and StoreItemUtil.getCanBeShownInConfigScreen(item) then
        local xml=XMLFile.loadIfExists("rffDealerType",key)
        if xml then
            accepted=not xml:hasProperty("vehicle.multipleItemPurchase") and
                (xml:hasProperty("vehicle.motorized") or xml:hasProperty("vehicle.attachable") or xml:hasProperty("vehicle.wheels")) and
                not xml:hasProperty("vehicle.bale") and not xml:hasProperty("vehicle.pallet")
            xml:delete()
        end
    end
    self.cache[key]=accepted
    return accepted
end
function D.defaultConfigurations(item)
    local configs={}
    for name,options in pairs(item.configurations or {}) do
        -- GIANTS resolves dynamic wheel/tyre templates into concrete defaults.
        -- Index 1 can be a non-selectable template without wheel dimensions.
        local native=item.defaultConfigurationIds and item.defaultConfigurationIds[name]
        if native and options[native] then configs[name]=native end
        if not configs[name] then
            for index,option in ipairs(options) do
                if option.isSelectable~=false and (configs[name]==nil or option.isDefault) then configs[name]=index end
            end
        end
        if not configs[name] and options[1] then configs[name]=1 end
    end
    return configs
end
function D:preparationMonths()
    -- Two actual game days, including saves using five-day months.
    return 2/math.max(1,g_currentMission.environment.daysPerPeriod or 1)
end
function D:findStock(id)
    for _,s in ipairs(self:state().stock) do if s.id==id then return s end end
end
function D:repairLegacyStock()
    if self:state().stockSpecificationVersion==2 then return end
    for _,s in ipairs(self:state().stock) do
        local item=g_storeManager:getItemByXMLFilename(s.xml)
        if item then
            local defaults=D.defaultConfigurations(item)
            local configs=D.copy(s.configurations)
            for name,index in pairs(configs) do
                local option=item.configurations and item.configurations[name] and item.configurations[name][index]
                if not option or option.isSelectable==false then configs[name]=defaults[name] end
            end
            configs=D.resolveConfigurations(item,configs)
            if configs then
                s.configurations=configs
                s.price=round(g_currentMission.economyManager:getBuyPrice(item,configs))
            end
        end
    end
    self:state().stockSpecificationVersion=2
end
function D.resolveConfigurations(item,configs)
    local result=D.defaultConfigurations(item)
    for k,v in pairs(configs or {}) do
        if not item.configurations or not item.configurations[k] or not item.configurations[k][v] then return nil end
        result[k]=v
    end
    for pass=1,12 do
        local changed=false
        for k,v in pairs(result) do
            for _,dep in ipairs(item.configurations[k][v].dependentConfigurations or {}) do
                if not item.configurations[dep.name] or not item.configurations[dep.name][dep.index] then return nil end
                if result[dep.name]~=dep.index then result[dep.name]=dep.index;changed=true end
            end
        end
        if not changed then return result end
    end
    return nil
end
function D.sameConfigurations(item,a,b)
    a=D.resolveConfigurations(item,a);b=D.resolveConfigurations(item,b)
    if not a or not b then return false end
    for k,v in pairs(a) do if b[k]~=v then return false end end
    return true
end
function D:configurationText(item,configs)
    local lines={}
    for k,v in pairs(configs or {}) do
        local option=item and item.configurations and item.configurations[k] and item.configurations[k][v]
        if option then lines[#lines+1]=tostring(k)..": "..tostring(option.name or option.title or v) end
    end
    table.sort(lines)
    if #lines>6 then
        local total=#lines
        while #lines>6 do table.remove(lines) end
        lines[#lines+1]="+ "..(total-6).." options; full specification in shop"
    end
    return #lines>0 and table.concat(lines," | ") or "Standard factory specification"
end
-- Persist stable brand names, not session-specific GIANTS numeric indices.
function D.brandName(item)
    local brand=g_brandManager and g_brandManager:getBrandByIndex(item and item.brandIndex)
    return brand and brand.name~="NONE" and brand.name or nil
end
function D:preferredBrands()
    local source=self:state().preferredBrands;local result={};local seen={}
    for slot=1,3 do
        local name=type(source)=="table" and source[slot] or ""
        if type(name)~="string" or #name>128 or seen[name] then name="" end
        result[slot]=name;seen[name]=true
    end
    self:state().preferredBrands=result
    return result
end
function D:brandChoices()
    if self.brandCatalogue then return self.brandCatalogue end
    local list={};local seen={}
    for _,item in ipairs(g_storeManager:getItems()) do
        local name=D.brandName(item)
        if name and not seen[name] and self:eligible(item) then
            local brand=g_brandManager:getBrandByIndex(item.brandIndex)
            list[#list+1]={name=name,title=brand.title or name};seen[name]=true
        end
    end
    table.sort(list,function(a,b) if a.title==b.title then return a.name<b.name end;return a.title<b.title end)
    self.brandCatalogue=list
    return list
end
function D:setPreferredBrand(slot,name)
    local ok,reason=self:available();if not ok then return false,reason end
    if slot~=1 and slot~=2 and slot~=3 then return false,"Invalid brand slot." end
    local known=name==""
    for _,brand in ipairs(self:brandChoices()) do if brand.name==name then known=true;break end end
    if not known then return false,"This brand has no eligible new machinery in the current shop." end
    local preferred=self:preferredBrands()
    for i=1,3 do if i~=slot and name~="" and preferred[i]==name then return false,"That brand is already selected." end end
    preferred[slot]=name
    return true
end
-- Native shop categories, not brand/model guesses. Mod machinery in these
-- categories receives the same bias; unknown categories keep their normal chance.
local starterWeights={TRACTORSS=4,TRACTORSM=3,TRAILERS=3,MOWERS=3,PLOWS=3,
    CULTIVATORS=3,DISCHARROWS=3,POWERHARROWS=3,SEEDERS=3,PLANTERS=3,
    FERTILIZERSPREADERS=3,SPRAYERS=3,TEDDERS=3,WINDROWERS=3,BALERS=3}
function D.categoryName(item)
    return string.upper(item.categoryName or "MACHINERY")
end
function D.categoryWeight(item)
    return starterWeights[D.categoryName(item)] or 1
end
function D.categoryStockLimit(item)
    return D.categoryWeight(item)>1 and 3 or 2
end
function D:stockWeight(item)
    local weight=D.categoryWeight(item)
    local name=D.brandName(item)
    if name then for _,preferred in ipairs(self:preferredBrands()) do if name==preferred then return weight*4 end end end
    return weight
end
function D:stockRandom()
    local state=self:state();local seed=state.stockRandomSeed
    if not finite(seed) or seed<1 or seed>=2147483647 then
        seed=1+(state.nextStockId*104729+math.floor(self:clock()*1000))%2147483646
    end
    seed=(math.floor(seed)*16807)%2147483647;state.stockRandomSeed=seed
    return seed/2147483647
end
function D:replenish(fullRefresh)
    local state=self:state();local items={};local existing={};local counts={};local live=0
    for _,s in ipairs(state.stock) do
        local category=string.upper(s.category or "MACHINERY")
        existing[s.xml]=true;counts[category]=(counts[category] or 0)+1;live=live+1
    end
    for _,item in ipairs(g_storeManager:getItems()) do if self:eligible(item) and not existing[item.xmlFilename] then items[#items+1]=item end end
    -- Local persisted weighted draw, without replacement. Never consume global game RNG.
    table.sort(items,function(a,b) return a.xmlFilename<b.xmlFilename end)
    local cap=(fullRefresh==true or state.nextRestock==0) and 30 or 4
    local added=0
    while #items>0 and live<30 and added<cap do
        local total=0;local weights={}
        for i,item in ipairs(items) do
            weights[i]=(counts[D.categoryName(item)] or 0)<D.categoryStockLimit(item) and self:stockWeight(item) or 0
            total=total+weights[i]
        end
        if total==0 then break end
        local draw=self:stockRandom()*total;local index=#items
        for i,weight in ipairs(weights) do draw=draw-weight;if draw<0 then index=i;break end end
        local item=table.remove(items,index)
        local category=D.categoryName(item)
        if not existing[item.xmlFilename] and (counts[category] or 0)<D.categoryStockLimit(item) and live<30 and added<cap then
            local configs=D.defaultConfigurations(item);local sets=item.configurationSets or {}
            if #sets>0 then
                local package=sets[(state.nextStockId-1)%#sets+1]
                for k,v in pairs(package.configurations or {}) do configs[k]=v end
            end
            configs=D.resolveConfigurations(item,configs)
            if configs then
                local price=g_currentMission.economyManager:getBuyPrice(item,configs)
                if finite(price) and price>0 then
                    state.stock[#state.stock+1]={id=state.nextStockId,xml=item.xmlFilename,name=item.name or "Machinery",category=category,
                        configurations=configs,price=round(price)}
                    state.nextStockId=state.nextStockId+1;existing[item.xmlFilename]=true
                    counts[category]=(counts[category] or 0)+1;live=live+1;added=added+1
                end
            end
        end
    end
    state.nextRestock=self:clock()+1
end
function D:canRefreshStock()
    if not self:active() then return false end
    local due=self:state().nextManualRefresh
    return due==nil or (finite(due) and self:clock()>=due)
end
function D:refreshStock()
    if not self:canRefreshStock() then return false end
    local state=self:state();local previous=state.stock
    local nextRestock,nextId,seed=state.nextRestock,state.nextStockId,state.stockRandomSeed
    state.stock={}
    local ok,err=pcall(self.replenish,self,true)
    if not ok or #state.stock==0 then
        state.stock=previous;state.nextRestock=nextRestock;state.nextStockId=nextId;state.stockRandomSeed=seed
        if not ok then Logging.warning("[RFF dealership] Refresh failed; stock retained: %s",tostring(err)) end
        return false
    end
    -- Reserved units live in the orders ledger and are not part of this refresh.
    state.nextManualRefresh=self:clock()+6
    return true
end
function D:setEnabled(enabled)
    local ok,reason=self:available();if not ok then return false,reason end
    self:state().enabled=enabled==true
    if enabled and self:state().nextRestock==0 then self:replenish() end
    return true,enabled and "Dealer logistics enabled. New machinery now requires preparation or factory ordering." or "Instant purchasing restored. Existing orders still require collection or cancellation."
end
function D:orders(farmId)
    local result={};for _,o in ipairs(self:state().orders) do if o.farmId==farmId then result[#result+1]=o end end
    return result
end
function D:find(id,farmId)
    for _,o in ipairs(self:orders(farmId)) do if o.id==id then return o end end
end
function D:total(farmId)
    local total=0;for _,o in ipairs(self:orders(farmId)) do if o.status~="DELIVERED" and o.status~="CANCELLED" then total=total+o.deposit end end
    return total
end
-- Undrawn orders are commitments, not live loans. Derive their exposure from the
-- saved ledger so cancellation/delivery releases it without a second balance.
function D:getPendingFinanceExposure(farmId)
    local result={count=0,depositBalance=0,monthlyPayment=0,principal=0,collateral=0}
    for _,o in ipairs(self:orders(farmId)) do
        local finance=o.payload and o.payload.finance
        if finance and o.status~="DELIVERED" and o.status~="CANCELLED" then
            result.count=result.count+1
            result.depositBalance=result.depositBalance+math.max(0,o.payable-o.deposit)
            result.monthlyPayment=result.monthlyPayment+math.max(0,finance.monthlyPayment or 0)
            local leased=finance.product=="OPERATING_LEASE"
            result.principal=result.principal+(leased and 0 or math.max(0,finance.amountFinanced or (o.price-o.payable)))
            result.collateral=result.collateral+o.price*(leased and 0.80 or 0.65)
        end
    end
    return result
end
function D:quote(item,configs,farmId,lease,finance,configData,plate,requiredStockId)
    if not self:active() or not self:eligible(item) or not farm(farmId) then return nil,"Dealership ordering is unavailable." end
    configs=D.resolveConfigurations(item,configs)
    if not configs then return nil,"The specification is not valid. Reopen the vehicle configuration." end
    local stock
    for _,s in ipairs(self:state().stock) do if s.xml==item.xmlFilename and D.sameConfigurations(item,s.configurations,configs) then stock=s;break end end
    if requiredStockId then
        stock=self:findStock(requiredStockId)
        if not stock or stock.xml~=item.xmlFilename or not D.sameConfigurations(item,stock.configurations,configs) then
            return nil,"This stock unit is no longer available or its specification changed. Please return to dealer stock. No factory order has been substituted."
        end
    end
    local price=stock and stock.price or g_currentMission.economyManager:getBuyPrice(item,configs)
    if not finite(price) or price<=0 then return nil,"Price unavailable." end
    local demoDiscount=false
    if self.demo and not lease then price,demoDiscount=self.demo:discount(item,price) end
    price=round(price)
    local payment=lease and "HIRE" or "CASH";local payable=price
    if finance then
        local q=self.manager.assetFinance:evaluateQuote(farmId,price,finance.depositPercent,finance.months,finance.product,finance.balloonPercent)
        if not q.approved then return nil,"Finance is no longer approved. Please obtain a fresh finance quote." end
        if math.abs(price-finance.basePrice)>.01 then return nil,"Stock pricing changed. Reopen finance against the current specification." end
        finance=D.copy(finance);payable=finance.deposit;payment=finance.product
    elseif lease then
        if item.allowLeasing~=true then return nil,"This machine cannot be hired." end
        payable=g_currentMission.economyManager:getInitialLeasingPrice(price)
    end
    if not finite(payable) or payable<0 then return nil,"Payment unavailable." end
    local economy=self.repository.economyState or {}
    local supply=math.max(-1,math.min(1,tonumber(economy.supply) or 0))
    local factory=stock and 0 or ((price>=250000 and 3 or 2)-supply*.25)
    local now=self:clock();local due=now+factory+self:preparationMonths()
    local ok,payload=pcall(D.copy,{configurations=configs,configurationData=configData or {},licensePlateData=plate,finance=finance})
    if not ok then return nil,"This mod's configuration data cannot be safely stored. No order or payment has been made." end
    return {farmId=farmId,xml=item.xmlFilename,name=item.name or "Machinery",price=price,payable=round(payable),
        deposit=round(math.min(price*.1,payable)),payment=payment,lease=lease==true,stockId=stock and stock.id or 0,
        route=stock and "STOCK" or "FACTORY",opened=now,arrival=now+factory,due=due,expires=due+1,
        payload=payload,token=self:state().nextId,demoDiscount=demoDiscount}
end
function D:money(id,amount,description)
    self.repository:setNextTransactionDescription(id,description)
    g_currentMission:addMoney(amount,id,self.transferType,true,true)
end
function D:availableFunds(farmId)
    local f=farm(farmId)
    if not f or not finite(f.money) then return 0 end
    local limit=self.repository.getOverdraftLimit and self.repository:getOverdraftLimit(farmId) or 0
    return f.money+(finite(limit) and math.max(0,limit) or 0)
end
function D:place(q)
    if not q or not self:active() or q.token~=self:state().nextId then return nil,"Order changed. Please review it again." end
    local item=g_storeManager:getItemByXMLFilename(q.xml)
    local latest,reason=self:quote(item,q.payload.configurations,q.farmId,q.lease,q.payload.finance,q.payload.configurationData,q.payload.licensePlateData,q.stockId>0 and q.stockId or nil)
    if not latest then return nil,reason end
    if latest.price~=q.price or latest.payable~=q.payable or latest.stockId~=q.stockId or self:clock()-q.opened>.05 then return nil,"Price, availability or date changed. Please review again." end
    local f=farm(q.farmId)
    if not finite(f.money) or self:availableFunds(q.farmId)<q.deposit then return nil,"Insufficient available funds (cash and authorised overdraft) for the reservation deposit." end
    if #self:orders(q.farmId)>=500 then return nil,"Order history limit reached." end
    local o=D.copy(q);o.id=self:state().nextId;o.token=nil;o.status="ORDERED";o.ads="Pending handover"
    self:state().nextId=o.id+1;self:state().orders[#self:state().orders+1]=o
    if o.stockId>0 then for i,s in ipairs(self:state().stock) do if s.id==o.stockId then o.stock=D.copy(s);table.remove(self:state().stock,i);break end end end
    self:money(o.farmId,-o.deposit,"Dealer reservation D-"..o.id.." - "..o.name)
    self:notify(o,"Order confirmed","Expected at the dealership: "..self:date(o.due)..". Repayments and hire begin at handover. Moving the delivery first starts the hourly handover charge.")
    return o,"Order confirmed. Track it in RFF: Vehicles - Dealership."
end
function D:notify(o,title,message)
    if RFF_NotificationService and RFF_NotificationService.send then
        pcall(RFF_NotificationService.send,RFF_NotificationService,o.farmId,"RFF Dealership",title,"D-"..o.id.." | "..o.name.."\n"..message,
            "dealership",title..". View RFF: Vehicles - Dealership.",false)
    end
end
function D:cancel(id,farmId)
    if not localServer() or not self.repository.loaded then return false,"Dealership unavailable." end
    local o=self:find(id,farmId)
    if not o or (o.status~="ORDERED" and o.status~="READY") then return false,"This order cannot be cancelled." end
    if not farm(farmId) then return false,"Farm account unavailable; reservation retained." end
    if self.handover then
        local allowed,message=self.handover:cancel(o)
        if not allowed then return false,message end
    end
    o.status="CANCELLED";o.closed=self:clock()
    if o.stock then self:state().stock[#self:state().stock+1]=o.stock;o.stock=nil end
    self:money(farmId,o.deposit,"Dealer reservation refunded D-"..o.id)
    return true,"Order cancelled; reservation deposit refunded in full."
end
function D:update(dt)
    self.timer=self.timer-(dt or 0);if self.timer>0 then return end;self.timer=1000
    if not localServer() or not self.repository.loaded then return end
    local state=self:state();local now=self:clock()
    if self:active() and now>=state.nextRestock then self:replenish() end
    for _,o in ipairs(state.orders) do
        if o.status=="ORDERED" and now>=o.due then
            o.status="READY";self:notify(o,"Machinery ready","Collect by "..self:date(o.expires)..". The remaining payment is due at handover.")
        end
        if (o.status=="READY" or o.status=="ORDERED") and now>o.expires and o.useStartedHour==nil then
            if self:cancel(o.id,o.farmId) then self:notify(o,"Reservation expired","The collection window has ended. Your deposit was refunded; no finance agreement was started.") end
        end
    end
end
function D:collect(id,farmId)
    local ok,reason=self:available();if not ok then return false,reason end
    local o=self:find(id,farmId);local now=self:clock()
    if self.handover then
        if not o or not farm(farmId) or now<o.due then return false,"This order is not ready for handover." end
        return self.handover:collect(o)
    end
    if not o or o.status~="READY" or now<o.due or now>o.expires then return false,"This order is not ready for collection." end
    for _,other in ipairs(self:state().orders) do if other.status=="COLLECTING" then return false,"Another vehicle handover is in progress." end end
    local item=g_storeManager:getItemByXMLFilename(o.xml)
    if not item or not D.sameConfigurations(item,o.payload.configurations,o.payload.configurations) then return false,"The vehicle mod or specification is missing. Restore it or cancel for a refund." end
    local f=farm(farmId);local balance=round(o.payable-o.deposit)
    if not f or not finite(f.money) or self:availableFunds(farmId)<balance then return false,"Insufficient available funds (cash and authorised overdraft) for handover. Collect before the deadline or cancel for a refund." end
    if not g_currentMission.slotSystem:hasEnoughSlots(item) then return false,"Insufficient vehicle slots. Free space and try again." end
    if not g_currentMission.storeSpawnPlaces then return false,"Dealership spawn locations are not ready." end
    local data=BuyVehicleData.new()
    data:setStoreItem(item);data:setOwnerFarmId(farmId);data:setConfigurations(D.copy(o.payload.configurations))
    data:setConfigurationData(D.copy(o.payload.configurationData));data:setLicensePlateData(D.copy(o.payload.licensePlateData))
    data:setLeaseVehicle(o.lease);data:setPrice(o.payable)
    data.rffAssetFinanceData=D.copy(o.payload.finance);data.rffDealerReservedDeposit=o.deposit;data.rffDealerOrderId=o.id
    o.status="COLLECTING"
    local started,err=pcall(data.buy,data,g_currentMission.storeSpawnPlaces,g_currentMission.usedStorePlaces,self.onCollected,self,o)
    if not started then o.status="READY";print("[RFF dealership] Handover error: "..tostring(err));return false,"Handover could not start. Order retained; check the log before retrying." end
    return true,"Handover requested. The machine will appear at the dealership once a delivery space is available."
end
function D:onCollected(vehicles,loadingState,o)
    if o.status~="COLLECTING" then return end
    if loadingState~=VehicleLoadingState.OK or not vehicles or #vehicles==0 then
        o.status="READY";self:notify(o,"Delivery space unavailable","The order is retained. Clear the dealership delivery area and try collecting again.");return
    end
    o.status="DELIVERED";o.closed=self:clock();o.stock=nil
    o.ads="ADS unavailable or unsupported"
    for _,vehicle in ipairs(vehicles) do
        -- Native new-vehicle loading supplies zero hours/damage/wear. Never turn
        -- a used vehicle into a new one through a broad purchase hook.
        if RFF_ADSIntegration and RFF_ADSIntegration.recordDealerHandover then
            local ok,result=pcall(RFF_ADSIntegration.recordDealerHandover,RFF_ADSIntegration,vehicle)
            o.ads=ok and result or "ADS handover record failed; check log"
        end
    end
    self:notify(o,"Machinery handed over","The machine is at the dealership. "..o.ads)
end
function D:consoleStatus(action,id)
    local farmId=g_currentMission:getFarmId();action=string.upper(tostring(action or "STATUS"))
    if action=="READY" then
        if not localServer() then return "Single-player test only." end
        local o=self:find(tonumber(id),farmId)
        if not o or o.status~="ORDERED" then return "Use rffDealer READY <ordered ID>." end
        o.arrival=self:clock();o.due=self:clock();o.expires=o.due+1;o.status="READY"
        return "TEST: this order is ready now. No time, money or other orders changed. Collect in RFF: Vehicles - Dealership."
    end
    for _,o in ipairs(self:orders(farmId)) do print(string.format("[RFF dealer] D-%d %s %s | %s | ready %s | deposit %.2f",o.id,o.name,o.route,o.status,self:date(o.due),o.deposit)) end
    return "Dealer orders printed. Test command: rffDealer READY <ID>."
end

-- Typed XML trees preserve valid mod configuration payloads, without eval/loadstring.
local function writeTree(xml,key,value)
    local kind=type(value);xml:setString(key.."#type",kind)
    if kind=="table" then
        local i=0
        for k,v in pairs(value) do
            local child=key..".entry("..i..")";xml:setString(child.."#key",tostring(k));xml:setString(child.."#keyType",type(k));writeTree(xml,child,v);i=i+1
        end
    else xml:setString(key.."#value",tostring(value)) end
end
local function readTree(xml,key,depth)
    if depth>16 then error("Dealer XML too deep") end
    local kind=xml:getString(key.."#type")
    if kind=="table" then
        local t={};local i=0
        while xml:hasProperty(key..".entry("..i..")") do
            if i>10000 then error("Dealer XML too large") end
            local child=key..".entry("..i..")";local k=xml:getString(child.."#key")
            if xml:getString(child.."#keyType")=="number" then k=tonumber(k) end
            if k==nil then error("Invalid dealer XML key") end
            t[k]=readTree(xml,child,depth+1);i=i+1
        end
        return t
    end
    local v=xml:getString(key.."#value")
    if kind=="number" then v=tonumber(v);if not finite(v) then error("Invalid dealer number") end;return v end
    if kind=="boolean" then return v=="true" end
    if kind=="string" then return v end
    error("Invalid dealer XML type")
end
function D.save(repository,xml)
    if repository.dealership then writeTree(xml,"realisticFarmFinance.dealership",repository.dealership) end
end
function D.load(repository,xml)
    repository.dealership=nil
    if not xml:hasProperty("realisticFarmFinance.dealership") then return end
    local ok,s=pcall(readTree,xml,"realisticFarmFinance.dealership",0)
    local valid=ok and type(s)=="table" and type(s.stock)=="table" and type(s.orders)=="table"
        and finite(s.nextId) and s.nextId>=1 and finite(s.nextStockId) and s.nextStockId>=1 and finite(s.nextRestock)
    if valid then
        local ids={};local statuses={ORDERED=true,READY=true,STAGING=true,COLLECTING=true,REVIEW=true,DELIVERED=true,CANCELLED=true}
        for _,o in ipairs(s.orders) do
            valid=valid and type(o)=="table" and finite(o.id) and o.id>=1 and not ids[o.id]
                and o.id<s.nextId and finite(o.farmId) and o.farmId>0 and type(o.xml)=="string" and type(o.name)=="string"
                and finite(o.price) and o.price>0 and finite(o.payable) and finite(o.deposit) and o.deposit>=0 and o.payable>=o.deposit
                and finite(o.opened) and finite(o.arrival) and finite(o.due) and finite(o.expires)
                and o.arrival>=o.opened and o.due>=o.arrival and o.expires>o.due and statuses[o.status]
                and type(o.payload)=="table" and type(o.payload.configurations)=="table"
                and type(o.payload.configurationData)=="table"
            if not valid then break end
            if o.vehicleIds~=nil then
                valid=type(o.vehicleIds)=="table" and #o.vehicleIds>0
                for _,id in ipairs(valid and o.vehicleIds or {}) do valid=valid and type(id)=="string" and id~="" end
            end
            if o.useStartedHour~=nil then valid=valid and finite(o.useStartedHour) and o.useStartedHour>=0 end
            if o.handoverChargeCents~=nil then valid=valid and finite(o.handoverChargeCents) and o.handoverChargeCents>=0 end
            if o.deliveryOrigins~=nil then
                valid=valid and type(o.deliveryOrigins)=="table"
                for _,p in ipairs(valid and o.deliveryOrigins or {}) do valid=valid and type(p)=="table" and finite(p.x) and finite(p.y) and finite(p.z) end
            end
            if o.representative~=nil then
                local p=o.representative
                valid=valid and type(p)=="table" and finite(p.x) and finite(p.y) and finite(p.z) and finite(p.angle)
            end
            if not valid then break end
            ids[o.id]=true
        end
        for _,stock in ipairs(s.stock) do
            valid=valid and type(stock)=="table" and finite(stock.id) and type(stock.xml)=="string"
                and type(stock.name)=="string" and type(stock.category)=="string" and type(stock.configurations)=="table"
                and finite(stock.price) and stock.price>0
            if not valid then break end
        end
    end
    if not valid then
        repository.dealershipLoadError=true;print("[RFF dealership] Invalid saved ledger. Ordering disabled; restore the save backup.");return
    end
    -- A save during asynchronous loading is not safe to automatically replay.
    for _,o in ipairs(s.orders) do if o.status=="COLLECTING" or o.status=="STAGING" then o.status="REVIEW";o.ads="Interrupted delivery or handover: inspect the save before recovery." end end
    repository.dealership=s
end
